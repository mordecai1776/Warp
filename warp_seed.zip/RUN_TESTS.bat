@echo off
REM WARP2/RUN_TESTS.bat - runs every WARP2 test through run_tests.py, which shows each test in the window as it runs
REM (PASSED green, FAILED red, a running score, a notice when one test is taking long) and saves the same to state\diagnostics\tests.out.txt.
cd /d "%~dp0"
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONPYCACHEPREFIX=%LOCALAPPDATA%\WARP2\pycache"
set "PYTHONUTF8=1"
set "PYTHONPATH=%CD%;%CD%\projects\centering_image;%CD%\projects\behemoth_eye"
echo Running every WARP2 test. Each one shows below as it runs.
py -3.11 -u -B run_tests.py
echo.
echo ALL DONE. You can close this window now.
pause
