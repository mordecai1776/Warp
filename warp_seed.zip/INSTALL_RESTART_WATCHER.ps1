$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$taskName = 'WARP2 Restart Watcher'
$python = Get-Command pyw.exe -ErrorAction SilentlyContinue
if (-not $python) {
    $python = Get-Command pythonw.exe -ErrorAction SilentlyContinue
}
if (-not $python) {
    throw 'Python 3.11+ windowless launcher not found (pyw.exe or pythonw.exe).'
}
$quotedRoot = '"' + $root.Replace('"', '\"') + '"'
$arguments = if ($python.Name -ieq 'pyw.exe') {
    "-3.11 -B -m warp2.control.watcher_service $quotedRoot"
} else {
    "-B -m warp2.control.watcher_service $quotedRoot"
}
$action = New-ScheduledTaskAction -Execute $python.Source -Argument $arguments -WorkingDirectory $root
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
# 2026-10-18 (BUILD_LOG 334): the defaults stop the task when the PC goes on
# battery and do not start it on battery; a stop ends the service and the
# watcher together, with no trace. The watcher must live on battery too.
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 5 `
    -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries -DontStopOnIdleEnd
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
    -Settings $settings -Principal $principal -Description 'Runs the WARP2 restart watcher and retries it after failures.' -Force | Out-Null

# Replace the older Startup-folder launcher only when it exactly matches the
# one this project previously installed; never remove an unrelated user file.
$startupPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'WARP2 restart watcher.bat'
$expectedStartup = '@call "' + (Join-Path $root 'RESTART_WATCHER.bat') + '"'
if (Test-Path -LiteralPath $startupPath) {
    $startupContents = (Get-Content -LiteralPath $startupPath -Raw).Trim()
    if ($startupContents -ieq $expectedStartup) {
        Remove-Item -LiteralPath $startupPath
    }
}

# Transfer the current watcher cleanly to Task Scheduler, if one is running.
$control = Join-Path $root 'state\control'
$beat = Join-Path $control 'watcher.beat'
$handoff = Join-Path $control 'watcher.handoff'
if (Test-Path -LiteralPath $beat) {
    $parts = (Get-Content -LiteralPath $beat -Raw).Trim() -split '\s+'
    $fresh = $false
    if ($parts.Count -ge 2) {
        $age = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0 - [double]$parts[1]
        $fresh = $age -ge 0 -and $age -lt 60
    }
    if ($fresh) {
        New-Item -ItemType File -Path $handoff -Force | Out-Null
        $deadline = [DateTime]::UtcNow.AddSeconds(20)
        while ((Test-Path -LiteralPath $beat) -and [DateTime]::UtcNow -lt $deadline) {
            Start-Sleep -Milliseconds 250
        }
        if (Test-Path -LiteralPath $beat) {
            Remove-Item -LiteralPath $handoff -ErrorAction SilentlyContinue
            throw 'The current watcher did not release its heartbeat; it was left running.'
        }
    }
}
Start-ScheduledTask -TaskName $taskName
Write-Host "Installed '$taskName' for $env:USERNAME. It starts at logon and retries failures up to five times, one minute apart."
Write-Host "Watcher heartbeat: $root\state\control\watcher.beat"
$deadline = [DateTime]::UtcNow.AddSeconds(20)
do {
    Start-Sleep -Milliseconds 250
    $started = $false
    if (Test-Path -LiteralPath $beat) {
        $parts = (Get-Content -LiteralPath $beat -Raw).Trim() -split '\s+'
        if ($parts.Count -ge 2) {
            $age = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0 - [double]$parts[1]
            $started = $age -ge 0 -and $age -lt 60
        }
    }
} while (-not $started -and [DateTime]::UtcNow -lt $deadline)
if (-not $started) {
    throw 'Scheduled watcher did not produce a fresh heartbeat within 20 seconds.'
}
