@echo off
REM WARP2/OPEN_WINDOW.bat - opens the WARP2 window onto the warp that is already running.
REM It does not start, stop or restart anything. Use it when the warp is running
REM with no window (for example after the watcher restarted it on its own).
REM 2026-10-17: the window closed on its own with nothing said. This box now stays
REM open while the window is open, and everything the window says (errors, a crash's
REM stack) goes to state\diagnostics\window.out.txt so Claude can read it.
setlocal
cd /d "%~dp0"
set "PYTHONPYCACHEPREFIX=%LOCALAPPDATA%\WARP2\pycache"
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONUTF8=1"
set "PYTHONFAULTHANDLER=1"
set "VIRTUAL_ENV="
set "OUT=state\diagnostics\window.out.txt"
echo [WARP2] Opening the window onto the running warp...
echo [WARP2] Leave this box open. It closes the window if you close it.
REM 2026-11-01 (Remy): an earlier window's box keeps window.out.txt open, and then nothing could be written to it -
REM the window was never started. Then this window says itself to a file of its own, named by the time it opened.
(echo opened %DATE% %TIME%) 1>"%OUT%" 2>nul || call :own_out
py -3.11 -X faulthandler -B -m warp2.app "%CD%" >> "%OUT%" 2>&1
set "CODE=%ERRORLEVEL%"
echo closed %DATE% %TIME% with code %CODE% >> "%OUT%"
echo.
echo [WARP2] The window closed (code %CODE%). Last lines it said:
powershell -NoProfile -Command "Get-Content -Tail 25 '%OUT%'"
echo.
echo [WARP2] Saved in %OUT%. Tell Claude if it closed on its own.
pause
exit /b

:own_out
for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "OUT=state\diagnostics\window.out.%%T.txt"
echo [WARP2] window.out.txt is held by an earlier window's box; this window says itself in %OUT%.
echo opened %DATE% %TIME% > "%OUT%"
exit /b 0
