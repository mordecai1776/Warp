@echo off







REM WARP3/CHECK_FIXES.bat - runs only the tests for the 2026-10-16 fixes (BUILD_LOG 291-298), a few minutes instead of the full run.







REM Each test shows in the window as it runs (PASSED / FAILED), with a notice when one is taking long.







REM Results are also saved to state\diagnostics\check_fixes_*.xml so Claude can read them.







cd /d "%~dp0"







set "PYTHONDONTWRITEBYTECODE=1"







set "PYTHONPYCACHEPREFIX=%LOCALAPPDATA%\WARP3\pycache"







set "PYTHONUTF8=1"







set "PYTHONPATH=%CD%;%CD%\projects;%CD%\projects\centering_image;%CD%\projects\behemoth_eye;%CD%\projects\master"







echo Checking the 2026-10-16 fixes. Each test shows below as it runs.







py -3.11 -u -B -m pytest -v -p no:cacheprovider -p run_tests -o faulthandler_timeout=600 --junitxml=state\diagnostics\check_fixes_warp2.xml ^







  warp2/tests/test_the_tree_keeps_its_discipline.py ^







  warp2/builders/tests/test_builders_are_scored_and_set_aside_by_score.py ^







  warp2/builders/tests/test_the_gate_never_makes_a_failed_start_worse.py ^







  warp2/tests/test_failed_pytest_reports_are_retained.py ^
  warp2/work/tests/test_the_header_mend_reads_the_gates_own_words.py ^
  warp2/work/tests/test_the_header_mend_names_every_import.py ^

  warp2/work/tests/test_a_session_ended_by_os_error_keeps_the_host.py ^
  warp2/work/tests/test_each_phase_choice_is_written_down.py ^
  warp2/house/tests/test_a_house_ask_waits_its_learned_patience.py ^
  warp2/house/tests/test_the_house_stops_when_the_asker_has_gone.py ^
  warp2/house/tests/test_a_house_chance_waits_its_learned_patience.py ^
  warp2/house/tests/test_a_cut_answer_is_kept_on_the_residency_line.py ^
  warp2/house/tests/test_a_house_line_says_load_and_work_time.py ^
  warp2/house/tests/test_a_house_load_says_where_its_seconds_went.py ^
  warp2/house/tests/test_a_house_model_gives_its_chance_of_yes.py ^
  warp2/house/tests/test_a_house_model_scores_yes_and_no_over_every_word.py ^
  warp2/record/tests/test_a_judged_fail_is_something_taught.py ^
  warp2/store/small_kg/tests/test_ended_since_fold_is_not_rebuilt_each_step.py ^
  warp2/store/small_kg/tests/test_a_new_build_keeps_only_what_is_new.py ^
  projects/behemoth_eye/eye/held_small/tests/test_a_place_kept_before_compaction_reads_in_a_new_process.py ^
  projects/behemoth_eye/pairs/tests/test_a_one_node_network_restores_under_a_low_ceiling.py ^
  warp2/control/tests/test_a_runner_still_coming_up_is_not_an_ended_start.py ^







  warp2/tests/test_a_blank_subject_asks_nothing.py ^







  warp2/work/side/tests/test_picture_receipt_geometry.py ^







  warp2/control/tests/test_restart_requester.py ^







  warp2/record/tests/test_an_answered_child_exits_before_the_next_turn.py ^







  warp2/house/tests/test_test_house_processes_are_owned.py ^







  warp2/house/tests/test_the_house_holds_models_inside_the_warp.py::test_a_house_that_cannot_start_says_why ^







  warp2/record/tests/test_writes.py ^







  warp2/train/tests/test_a_short_answer_is_still_taught.py ^







  warp2/train/tests/test_logic_and_math_train.py ^







  warp2/make/tests/test_a_verdict_needs_a_quorum.py ^







  warp2/make/tests/test_make_parts.py ^







  warp2/make/tests/test_eye_judge.py ^







  warp2/make/tests/test_judges_read_the_fixed_options.py ^







  warp2/make/tests/test_judges_keep_both_readings.py ^







  warp2/train/tests/test_outputs_measure_repeats.py ^







  warp2/make/tests/test_eye_judges.py ^







  warp2/train/tests/test_centroid_cluster_training.py ^







  warp2/record/tests/test_a_child_error_says_where.py ^







  warp2/record/tests/test_a_receipt_names_its_child.py ^







  warp2/work/side/tests/test_an_unscored_round_is_not_a_crash.py ^







  warp2/progress/tests/test_progress_readings.py ^







  warp2/app/tests/test_the_improving_page.py ^







  warp2/app/tests/test_app.py ^







  warp2/work/tests/test_memory_floor.py ^







  warp2/work/tests/test_the_floor_watches_commit.py ^







  warp2/work/tests/test_free_ram_does_not_fail_the_start_up_tests.py ^







  warp2/ask/tests/test_until.py ^







  warp2/record/tests/test_a_slow_answer_is_not_gone.py ^







  warp2/record/tests/test_processes.py ^







  warp2/control/tests/test_a_planned_restart_waits_for_the_open_step.py ^
  warp2/control/tests/test_restart.py ^







  warp2/train/tests/test_the_weigher_checks_memory_between_readings.py ^







  warp2/train/tests/test_weigher.py ^







  warp2/store/tests/test_karma_web.py ^







  warp2/seed/tests/test_seed_bloom.py ^

  warp2/seed/tests/test_warp3_has_its_own_seed_folder.py ^

  warp2/work/side/tests/test_sound_and_video_lessons.py ^

  warp2/tags/media/tests/test_sound_and_video_are_kept_small.py ^
  projects/behemoth_eye/eye/ladder/tests/test_a_video_sees_through_the_flower.py ^
  projects/behemoth_eye/eye/held_small/tests/test_the_book_keeps_itself_small.py ^
  projects/behemoth_eye/eye/held_small/tests/test_nothing_let_go_is_lost.py ^
  projects/behemoth_eye/eye/held_small/tests/test_a_compacted_page_is_let_go_once_all_it_held_is_kept.py ^
  projects/behemoth_eye/eye/held_small/tests/test_a_whole_book_is_made_smaller_in_one_pass.py ^
  projects/behemoth_eye/eye/held_small/tests/test_a_lane_is_kept_against_zipf.py ^
  projects/behemoth_eye/eye/tests/test_each_pair_has_its_own_activation_node.py ^
  projects/behemoth_eye/eye/tests/test_the_master_orders_the_action_side.py ^
  projects/behemoth_eye/eye/tests/test_the_action_sides_relations_hold_only_its_own.py ^
  warp2/progress/tests/test_live_memory_health.py ^
  warp2/room/tests/test_what_is_held_is_let_go_the_moment_memory_is_short.py ^
  warp2/room/tests/test_odd_jobs_are_done_in_memory_that_is_free.py ^
  warp2/room/tests/test_every_odd_job_look_has_its_reason.py ^
  warp2/room/tests/test_look_identity_keeps_build_and_place.py ^
  warp2/house/tests/test_a_house_answer_says_its_tokens.py ^
  warp2/house/tests/test_a_house_chance_says_its_tokens.py ^
  warp2/house/tests/test_a_house_chance_marks_are_not_speed.py ^
  warp2/graph_play/tests/test_each_play_ask_keeps_its_request_id.py ^
  warp2/room/tests/test_helpers_are_only_as_many_as_fit_in_free_memory.py ^
  warp2/work/side/tests/test_the_eye_turn_says_the_master_use_debt.py ^
  warp2/room/tests/test_odd_job_stop_does_not_guess_memory.py ^
  warp2/room/tests/test_side_jobs_do_not_forget_unreadable_state.py ^
  warp2/room/tests/test_the_old_vault_goes_into_the_kg_file_by_file.py ^
  warp2/room/tests/test_side_steps_that_waited_too_long_are_done_as_odd_jobs.py ^
  warp2/room/tests/test_odd_job_child_voice_takes_print_options.py ^
  warp2/app/tests/test_key_value_keeps_its_lines.py ^
  projects/pop_growth_lab/tests/test_every_way_grows_a_node_on_the_real_network.py ^
  projects/pop_growth_lab/tests/test_every_rule_runs_on_a_real_network.py ^
  projects/pop_growth_lab/tests/test_the_dials_and_the_made_shapes.py ^
  projects/pop_growth_lab/tests/test_paths_are_searched_from_one_node.py ^
  projects/pop_growth_lab/tests/test_the_plan_of_ten.py ^
  projects/pop_growth_lab/tests/test_concepts_go_into_concepts_the_eyes_way.py ^
  projects/pop_growth_lab/tests/test_a_concept_is_met_in_different_mixes_of_modalities.py ^
  projects/pop_growth_lab/tests/test_every_setting_is_changed_alone.py ^
  projects/pop_growth_lab/tests/test_learning_is_watched_from_inside.py ^
  projects/pop_growth_lab/tests/test_a_hidden_concept_is_divided_out_and_tried_elsewhere.py ^
  projects/pop_growth_lab/tests/test_concepts_are_merged_and_each_keeps_its_name.py ^
  projects/pop_growth_lab/tests/test_forms_arrive_and_subgroups_follow_the_data.py ^
  projects/pop_growth_lab/tests/test_the_eyes_kept_pairs_are_counted_and_the_merge_is_dry_run.py ^
  projects/pop_growth_lab/tests/test_the_lab_refines_a_kept_pair_and_holds_the_current_best.py ^
  projects/pop_growth_lab/tests/test_the_lab_is_a_mine_that_goes_on.py ^
  projects/pop_growth_lab/tests/test_what_a_refined_pair_is_better_related_to.py ^
  projects/behemoth_eye/eye/tests/test_a_refined_pair_is_taken_in_only_if_it_holds.py ^
  warp2/models/tests/test_the_wait_comes_back_down_to_what_worked.py ^
  warp2/control/tests/test_a_restart_says_how_the_runner_ended.py ^
  warp2/house/tests/test_a_load_waits_while_room_is_coming.py ^
  projects/pop_growth_lab/tests/test_every_rung_in_every_modality.py ^
  projects/behemoth_eye/pairs/tests/test_held_rows_can_rest_and_come_back.py ^
  warp2/work/tests/test_a_runner_short_of_its_own_memory_starts_fresh.py ^
  projects/behemoth_eye/eye/recreate/tests/test_a_picture_is_recreated_exactly_and_its_leftovers_become_concepts.py ^
  projects/behemoth_eye/eye/recreate/tests/test_a_picture_is_recreated_through_the_eye.py ^
  projects/behemoth_eye/eye/recreate/tests/test_concept_sheets_are_atomic_and_tool_imports.py ^
  projects/behemoth_eye/eye/recreate/tests/test_pattern_book_rounding_is_not_a_concept.py ^
  projects/behemoth_eye/eye/recreate/tests/test_a_restored_book_leaves_a_mark.py ^
  design/tests/test_every_by_hand_tool_imports.py ^
  warp2/work/side/tests/test_a_turn_refused_for_room_is_given_back.py ^
  warp2/work/side/tests/test_room_refusal_survives_restart.py ^
  "warp2/work/side/tests/test_every_step_runs.py::test_every_side_step_runs_without_raising[refine_datasets]" ^
  warp2/house/tests/test_a_put_down_for_no_room_is_said.py ^
  projects/behemoth_eye/eye/held_small/tests/test_the_books_use_the_warps_own_compression.py ^
  projects/behemoth_eye/eye/held_small/tests/test_upkeep_stops_at_an_expired_clock.py ^
  warp2/share/tests/test_reaching_the_mark_does_not_eat_the_turn.py ^
  projects/behemoth_eye/eye/tests/test_the_web_key_names_the_inputs_that_moved.py ^
  projects/behemoth_eye/eye/tests/test_reset_checkpoint_dirty.py ^






  warp2/golem/tests/test_surface_golem.py







py -3.11 -u -B -m pytest -v -p no:cacheprovider -p run_tests -o faulthandler_timeout=600 --junitxml=state\diagnostics\check_fixes_projects.xml ^







  projects/behemoth_eye/eye/tests/test_actions_are_saved_alone.py ^
  warp2/store/small_kg/tests/test_a_build_says_its_phase_times.py ^
  warp2/work/side/tests/test_depth_receipt_names_the_eye_home.py ^
  warp2/work/side/tests/test_depth_checkpoint_imports_without_projects_path.py ^
  projects/behemoth_eye/eye/tests/test_a_first_save_waits_for_the_teaching.py ^
  projects/behemoth_eye/eye/tests/test_frozen_eval_is_the_state_folders_own.py ^
  projects/behemoth_eye/eye/tests/test_seen_pictures_from_another_warp_are_named_here.py ^
  projects/behemoth_eye/eye/tests/test_practice_receipt_names_the_frozen_read.py ^
  warp2/store/small_kg/tests/test_both_index_sources_agree_on_one_build.py ^
  projects/behemoth_eye/eye/tests/test_a_resting_part_comes_back_within_a_share.py ^

  projects/behemoth_eye/eye/tests/test_the_concept_web_file_is_compact.py ^

  warp2/wise_men/tests/test_a_silent_answer_says_why.py ^

  projects/behemoth_eye/eye/tests/test_the_save_is_written_in_pieces.py ^







  projects/behemoth_eye/eye/tests/test_a_split_survives_a_failed_solver.py ^
  projects/behemoth_eye/eye/tests/test_a_failed_solver_keeps_its_matrix.py ^
  warp2/control/tests/test_a_listed_runner_reads_alive.py ^
  warp2/control/tests/test_a_long_main_step_reads_overdue.py ^



  projects/behemoth_eye/eye/tests/test_training_leans_on_what_helps.py ^







  projects/behemoth_eye/eye/tests/test_the_map_is_worked_out_not_trained_out.py ^







  warp2/work/side/tests/test_reading_concept_names_lets_the_eye_go.py ^







  warp2/work/side/tests/test_block_teaching_runs_in_a_child.py ^







  warp2/work/tests/test_the_warp_leaves_room_for_the_machine.py ^







  design/tests/test_andrews_words_2026_11_08.py ^







  design/tests/test_andrews_words_2026_11_09.py ^







  projects/behemoth_eye/eye/tests/test_training_is_spent_where_it_is_fastest.py ^







  projects/behemoth_eye/eye/tests/test_a_picture_lesson_uses_both_reads.py ^







  projects/behemoth_eye/eye/ladder/tests/test_a_picture_look_is_read_two_ways.py ^







  projects/adaptive_layers_by_attention/front_rig/tests/test_every_piece_fits_every_other_on_the_wall.py ^







  projects/adaptive_layers_by_attention/front_rig/tests/test_the_front_keeps_where_a_value_came_from.py ^







  projects/master/tests/test_until_writes_no_real_state.py ^







  projects/behemoth_eye/eye/tests/test_save_pace.py ^







  projects/behemoth_eye/eye/tests/test_eye_saves_are_paced.py ^







  projects/behemoth_eye/eye/tests/test_tokens_and_tasks.py ^







  projects/behemoth_eye/eye/tests/test_old_examples_are_replayed.py ^







  projects/behemoth_eye/eye/tests/test_concept_web.py ^







  projects/behemoth_eye/eye/tests/test_a_learned_answer_is_watched.py ^







  projects/behemoth_eye/eye/tests/test_web_and_stages.py ^







  warp2/record/tests/test_stepped_past_is_on_the_record.py ^







  warp2/record/tests/test_supervisor.py ^







  warp2/record/tests/test_late_stacks_are_read_safely.py ^







  warp2/record/tests/test_pathway.py ^







  warp2/work/side/tests/test_a_passed_picture_turn_is_measured.py ^







  warp2/work/side/tests/test_asked_images.py ^







  warp2/work/side/tests/test_the_picture_device_is_a_trial.py ^







  warp2/work/side/tests/test_a_receipt_finds_its_run.py ^







  warp2/research/tests/test_a_decision_point_that_lags_is_a_weak_spot.py ^







  warp2/work/side/tests/test_the_picture_child_writes_its_size.py ^







  warp2/work/side/tests/test_the_cascade_lists_are_measured.py ^







  warp2/work/side/tests/test_the_tag_objects_are_measured.py ^







  warp2/work/side/tests/test_asked_child.py ^







  projects/centering_image/tests/test_the_sharpening_pass_finds_the_eye.py ^







  projects/behemoth_eye/eye/tests/test_painter_training.py ^







  warp2/train/tests/test_a_busy_training_child_is_not_silent.py ^







  projects/centering_image/tests/test_a_verdict_names_its_judge.py ^







  projects/centering_image/tests/test_a_failed_reader_says_what_it_said.py ^







  warp2/work/side/tests/test_a_repair_is_a_temperature.py ^







  warp2/work/side/tests/test_a_repair_counts_when_the_step_passes.py ^







  warp2/work/side/tests/test_runtime_repairs.py ^







  warp2/control/tests/test_the_watcher_beats_while_busy.py ^







  warp2/train/tests/test_the_weigher_is_kept_in_the_warps_eye.py ^







  warp2/train/tests/test_learned_weight.py ^







  projects/behemoth_eye/eye/tests/test_pairs_leave_a_full_card.py ^







  projects/behemoth_eye/eye/tests/test_pairs_leave_a_full_machine.py ^







  projects/behemoth_eye/eye/tests/test_room_making_is_counted.py ^







  warp2/work/side/tests/test_the_size_line_says_what_the_eye_let_go.py ^







  projects/behemoth_eye/eye/tests/test_a_release_says_what_it_gave_back.py ^







  projects/behemoth_eye/eye/tests/test_a_release_runs_the_collector_before_giving_up.py ^







  projects/behemoth_eye/pairs/tests/test_a_pair_let_go_is_freed_at_once.py ^







  warp2/train/tests/test_weighted_training.py ^







  projects/behemoth_eye/pairs/tests/test_edits_keep_ability.py ^







  projects/behemoth_eye/eye/tests/test_tensegrity_and_warp_eye.py ^







  projects/behemoth_eye/eye/tests/test_growth_and_training.py ^







  warp2/control/tests/test_the_watcher_says_where_it_hangs.py ^







  warp2/control/tests/test_a_worker_that_will_not_die_lets_the_service_go_on.py ^







  warp2/control/tests/test_restart.py ^







  warp2/control/tests/test_the_restart_names_the_new_lane.py ^







  warp2/wise_men/tests/test_the_wise_men_read_correct_by_chance.py ^







  warp2/app/tests/test_judge_rows.py ^







  warp2/decide/tests/test_cockpit_tags.py ^







  warp2/decide/tests/test_standing_against_base.py ^







  warp2/control/tests/test_the_runner_keeps_the_watcher_up.py ^







  warp2/decide/tests/test_who_writes_sees_history.py ^







  warp2/control/tests/test_the_memory_map_is_read_on_request.py ^







  warp2/control/tests/test_the_service_leaves_its_own_trace.py ^







  warp2/control/tests/test_a_watcher_death_says_why.py ^







  projects/behemoth_eye/eye/tests/test_eye.py ^







  projects/behemoth_eye/pairs/tests/test_the_eye_owns_its_network_settings.py ^







  warp2/app/tests/test_one_window.py ^







  projects/behemoth_eye/eye/tests/test_cascade_timing.py ^







  warp2/work/side/tests/test_completed_cascade_observations.py ^







  warp2/work/side/tests/test_pair_memory_boundaries.py ^







  projects/behemoth_eye/eye/tests/test_in_flight_capture.py ^







  projects/behemoth_eye/eye/tests/test_a_cascade_ends_at_its_turn.py ^







  projects/behemoth_eye/eye/tests/test_unexplained_read_is_paced.py ^







  projects/behemoth_eye/eye/tests/test_unexplained_read_is_batched.py ^







  projects/behemoth_eye/eye/tests/test_node_counts.py ^







  warp2/work/tests/test_session.py ^







  warp2/work/tests/test_a_sitting_stopped_from_outside_is_listed.py ^







  projects/behemoth_eye/pairs/tests/test_a_new_pair_is_born_at_one_node.py ^







  projects/behemoth_eye/pairs/tests/test_networks_are_tiny_and_grow_by_their_own_growth.py ^







  projects/behemoth_eye/eye/tests/test_depth_action.py ^







  projects/behemoth_eye/eye/ladder/tests/test_flower_areas.py ^







  projects/behemoth_eye/eye/errors/tests/test_lens_bending.py ^







  projects/behemoth_eye/eye/errors/tests/test_lesson_well.py ^







  projects/behemoth_eye/eye/errors/tests/test_error_concept.py ^







  projects/behemoth_eye/eye/errors/tests/test_flower_rows_keep_the_picture_as_a_view.py ^







  projects/behemoth_eye/eye/errors/tests/test_the_positive_alone_runs_one_side.py ^







  warp2/work/side/tests/test_true_image_lessons.py ^







  projects/behemoth_eye/eye/errors/tests/test_makers.py ^







  projects/behemoth_eye/eye/errors/tests/test_unexplained.py ^







  projects/behemoth_eye/eye/errors/tests/test_training_size.py ^







  projects/behemoth_eye/eye/errors/tests/test_nothing_to_see.py ^







  projects/behemoth_eye/eye/errors/tests/test_faint_held_apart.py ^







  warp2/ask/tests/test_blender_held_apart.py ^







  warp2/ask/tests/test_all_pictures.py ^







  warp2/work/side/tests/test_picture_needs.py ^







  warp2/work/side/tests/test_concept_datasets.py ^







  projects/behemoth_eye/eye/errors/tests/test_new_errors.py ^







  projects/behemoth_eye/eye/errors/tests/test_origin_step.py ^







  projects/behemoth_eye/eye/errors/tests/test_error_activation.py ^







  projects/behemoth_eye/eye/errors/tests/test_picture_reading.py ^







  projects/behemoth_eye/eye/errors/tests/test_error_reading.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_picture_head.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_head_reality.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_reality_gate.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_head_readings.py ^







  projects/behemoth_eye/eye/readings/tests/test_readings.py ^







  projects/behemoth_eye/eye/readings/tests/test_measures.py ^







  projects/behemoth_eye/eye/readings/tests/test_edge_bend.py ^







  projects/behemoth_eye/eye/readings/tests/test_light.py ^







  projects/behemoth_eye/eye/tests/test_loops.py ^







  warp2/graph_play/tests/test_graph_play.py ^







  warp2/train/tests/test_closeness.py ^







  warp2/work/side/tests/test_eye_facts.py ^







  warp2/tags/tests/test_proposal_asking.py ^







  warp2/train/tests/test_image_focus.py ^







  projects/behemoth_eye/pairs/tests/test_value_loss_pixel_weights.py ^







  warp2/work/side/tests/test_depth_lessons.py ^







  state/control/commands/drop/fx/tr/test_put_back.py ^







  warp2/work/side/tests/test_side_turns.py ^







  warp2/work/side/tests/test_depth_leads_the_round.py ^







  warp2/ask/tests/test_subconcept_guessing.py ^







  warp2/ask/tests/test_answer_codes_are_not_names.py ^







  warp2/house/tests/test_a_door_answer_that_says_nothing_is_not_taught.py ^







  projects/behemoth_eye/pairs/tests/test_a_network_keeps_its_birth_receipt.py ^







  projects/behemoth_eye/eye/tests/test_node_counts_carry_birth.py ^







  projects/behemoth_eye/eye/tests/test_a_labeled_pairs_subnetwork_is_held.py ^







  projects/behemoth_eye/eye/tests/test_each_subconcept_connection_carries_its_signal.py ^







  projects/behemoth_eye/eye/tests/test_each_look_counts_parent_unserved.py ^







  projects/behemoth_eye/eye/tests/test_the_master_retrains_what_it_used.py ^
  projects/behemoth_eye/eye/tests/test_each_retrain_payment_is_kept.py ^







  projects/behemoth_eye/eye/ladder/tests/test_the_retina_is_a_flower_of_life.py ^







  projects/behemoth_eye/eye/ladder/tests/test_three_flowers_see_each_look.py ^







  projects/behemoth_eye/eye/ladder/tests/test_a_look_is_laid_in_bands.py ^







  projects/behemoth_eye/eye/ladder/tests/test_a_look_is_laid_row_part_times_column_part.py ^







  projects/behemoth_eye/eye/ladder/tests/test_a_levels_looks_are_sampled_together.py ^







  projects/behemoth_eye/eye/growth/tests/test_score_reads_only_the_held_concept.py ^







  warp2/control/tests/test_a_start_in_its_gate_is_waited_for.py ^







  projects/behemoth_eye/eye/tests/test_a_test_cascade_is_not_filed_in_the_live_archive.py ^







  projects/behemoth_eye/eye/tests/test_the_tag_read_is_exact_and_split_over_cores.py ^







  warp2/control/tests/test_the_watcher_beats_through_a_restart.py ^







  warp2/tests/test_a_crashed_test_run_is_not_a_pass.py ^







  warp2/tests/test_a_hung_start_up_test_is_cut_off.py ^







  projects/behemoth_eye/eye/tests/test_far_tags_are_skipped_exactly.py ^







  projects/behemoth_eye/eye/tests/test_refeed_fires_are_counted.py ^







  projects/behemoth_eye/eye/tests/test_refeed_child_fires_are_counted.py ^







  projects/behemoth_eye/eye/ladder/tests/test_glimpse_many.py ^







  projects/behemoth_eye/eye/tests/test_found_tags_are_marked_not_sorted.py ^







  projects/behemoth_eye/pairs/tests/test_only_the_kept_readings_are_copied.py ^







  warp2/control/tests/test_a_restarting_beat_gets_its_own_window.py ^







  warp2/control/tests/test_the_warp_is_checked_when_a_watcher_is_ended.py ^







  design/tests/test_andrews_design.py ^







  warp2/ask/tests/test_subconcepts_are_trained_and_kept.py ^







  projects/behemoth_eye/eye/tests/test_pictures_are_learned_at_full_size_in_colour.py ^







  projects/behemoth_eye/eye/tests/test_the_tag_read_has_a_temperature.py ^







  warp2/work/side/tests/test_the_tag_split_says_carried_moved_new.py ^







  projects/behemoth_eye/eye/tests/test_whole_subject_tags_use_data_units.py ^







  warp2/work/side/tests/test_depth_parts_carry_intention_notes.py ^







  warp2/gate/tests/test_proof.py ^







  warp2/work/side/tests/test_every_proof_check_trains.py ^







  warp2/ask/tests/test_a_round_part_waits_on_the_memory_floor.py ^







  warp2/webs/tests/test_web_tags_match_fast.py ^







  warp2/webs/tests/test_meaning_write_times_each_step.py ^







  warp2/make/tests/test_kg_wiring_counts_degrees_in_one_query.py ^







  warp2/make/tests/test_an_unreachable_judge_is_skipped.py ^







  warp2/train/tests/test_readers_look_only_at_kept_pictures.py ^







  warp2/train/tests/test_unjudged_picture_is_not_called_unverified.py ^







  warp2/webs/tests/test_eat_old.py ^







  warp2/ask/tests/test_each_round_part_says_its_memory.py ^







  warp2/webs/tests/test_web_note_in_turns.py ^







  warp2/store/tests/test_kg_batch_write.py ^







  warp2/integrity/tests/test_batch_write_parts_noted.py ^







  warp2/webs/tests/test_web_note_says_progress.py ^







  warp2/webs/tests/test_webs_turn_times_each_part.py ^







  warp2/webs/tests/test_meaning_says_why_a_web_was_rewritten.py ^







  warp2/webs/tests/test_an_unchanged_web_under_a_new_id_is_counted.py ^







  warp2/webs/tests/test_a_drifted_web_keeps_its_name_under_a_strict_vigilance.py ^







  warp2/webs/tests/test_the_name_bar_keeps_its_best_recorded_value.py ^







  projects/behemoth_eye/eye/tests/test_a_test_without_the_conftest_still_files_nothing_live.py ^







  warp2/ask/tests/test_practice_names_its_subject.py ^







  warp2/train/tests/test_practice_block_says_round.py ^







  design/tests/test_andrews_design.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_head_reality.py ^







  projects/behemoth_eye/eye/errors/tests/test_training_size.py ^







  warp2/work/tests/test_ram_lines_carry_time.py ^







  warp2/work/side/tests/test_concept_datasets.py ^







  warp2/work/side/tests/test_side_turns.py ^







  warp2/work/side/tests/test_true_image_progress_is_measured.py ^







  warp2/make/tests/test_eye_master_trains_a_missing_part.py ^







  warp2/make/tests/test_judge_guesses_before_after.py ^







  projects/behemoth_eye/eye/tests/test_prime_home_is_kept.py ^







  projects/behemoth_eye/eye/tests/test_hidden_finder_no_square.py ^







  warp2/integrity/tests/test_new_parts_noted_1029.py ^







  projects/behemoth_eye/pairs/tests/test_class_probe_rows_are_capped.py ^







  projects/behemoth_eye/eye/tests/test_signal_carried_reads_in_chunks.py ^







  projects/behemoth_eye/eye/tests/test_signal_check_reads_a_spread_of_places.py ^







  projects/behemoth_eye/eye/tests/test_signal_verdict_says_when_sampled.py ^







  projects/behemoth_eye/eye/tests/test_dense_tag_batches_fit_memory.py ^







  warp2/control/tests/test_preflight.py ^







  warp2/control/tests/test_each_status_answer_keeps_a_memory_sample.py ^







  projects/behemoth_eye/eye/tests/test_a_put_back_controller_edits_the_live_network.py ^







  projects/image_video_to_blender/tests/test_a_blender_turn_ends_when_its_time_does.py ^







  warp2/store/tests/test_closing_reads_history_by_index.py ^







  warp2/work/tests/test_card_beat.py ^







  warp2/work/side/tests/test_blender_step.py ^







  projects/behemoth_eye/pairs/tests/test_a_probe_holds_little.py ^







  projects/image_video_to_blender/tests/test_a_half_written_render_is_not_taught.py ^







  warp2/record/tests/test_a_child_answers_a_memory_card.py ^







  projects/behemoth_eye/pairs/tests/test_the_guard_checks_its_own_network.py ^







  projects/behemoth_eye/pairs/tests/test_an_edit_always_has_its_network.py ^







  warp2/control/tests/test_the_card_counts_every_4096_row_tensor.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_a_routed_check_keeps_a_row_per_step.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_a_routed_check_leaves_the_order_as_it_was.py ^







  warp2/work/side/tests/test_blender_frames_are_routed_bent_and_clean.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_a_routed_check_watches_the_not_real_head.py ^







  warp2/work/side/tests/test_a_bend_across_two_heads_is_not_a_number.py ^







  warp2/work/side/tests/test_the_not_real_head_passes_its_own_kinds.py ^







  projects/behemoth_eye/eye/picture_head/tests/test_a_pooled_pass_fixes_only_its_own_sizes.py ^







  warp2/work/side/tests/test_each_kind_keeps_its_own_size_rung.py ^







  warp2/seed/tests/test_the_warp_grows_its_own_seed.py ^







  warp2/control/tests/test_a_big_outside_program_says_who_started_it.py ^







  warp2/control/tests/test_the_watcher_runs_a_bat_it_is_asked_to.py ^







  warp2/webs/tests/test_the_practice_web.py ^







  warp2/work/side/tests/test_a_pooled_pass_counts_only_rungs_climbed.py ^







  warp2/work/side/tests/test_a_pooled_pass_row_names_its_head.py ^







  warp2/work/side/tests/test_each_head_s_share_of_lessons_is_filed.py ^







  warp2/work/side/tests/test_each_frame_s_gap_is_filed.py ^







  warp2/work/side/tests/test_the_reading_fits_the_turn.py ^







  warp2/work/side/tests/test_one_frame_is_not_pooled.py ^







  warp2/work/side/tests/test_one_frame_against_one_frame.py ^







  warp2/work/side/tests/test_true_nought_under_read_budget.py ^







  warp2/work/side/tests/test_a_cut_frame_is_read_at_working_size.py ^







  warp2/work/side/tests/test_the_same_frame_is_read_at_both_sizes.py ^







  warp2/work/side/tests/test_the_taught_frame_gets_its_own_pair.py ^







  warp2/work/side/tests/test_taught_side_not_read_label.py ^







  warp2/work/side/tests/test_tight_read_once.py ^







  warp2/work/side/tests/test_taught_side_is_read_first.py ^







  warp2/work/side/tests/test_one_beside_frame_is_always_read.py ^







  warp2/work/side/tests/test_a_guaranteed_frame_s_overrun_has_its_own_line.py ^







  warp2/work/side/tests/test_each_overrun_line_says_if_it_was_the_tight_test.py ^







  warp2/work/side/tests/test_one_taught_frame_is_always_read.py ^







  warp2/control/tests/test_the_window_is_kept_open_on_a_nexus.py ^







  warp2/work/side/tests/test_the_chat_turn_runs_in_a_child.py ^







  warp2/control/tests/test_a_command_file_runs_like_a_shell.py ^







  projects/behemoth_eye/eye/tests/test_learning_to_say_keeps_to_its_turn.py ^







  projects/behemoth_eye/pairs/tests/test_a_whole_set_network_ends_its_epoch_by_its_probe.py ^







  projects/behemoth_eye/eye/tests/test_the_say_pair_learns_an_answer.py ^







  projects/behemoth_eye/pairs/tests/test_each_removal_files_its_cost.py ^







  projects/behemoth_eye/pairs/tests/test_the_stop_files_its_probe_loss.py ^







  warp2/chat_learning/tests/test_a_slow_page_has_a_whole_call_time.py ^







  projects/behemoth_eye/eye/tests/test_a_lesson_fits_its_rows_while_it_gets_better.py ^







  warp2/models/tests/test_an_unchanged_answer_goes_to_another_model.py ^







  warp2/capability/tests/test_a_dataset_it_cannot_read_is_made_from_search.py ^







  warp2/work/side/tests/test_depth_reteaches_by_error.py ^







  projects/behemoth_eye/eye/tests/test_a_part_with_more_classes_than_wake_can_read.py ^







  warp2/capability/tests/test_the_eye_is_set_beside_the_standard.py ^







  warp2/capability/tests/test_a_grown_concept_gets_its_parts_first.py ^







  warp2/capability/tests/test_the_step_tries_only_what_can_be_read.py ^







  warp2/work/side/tests/test_the_component_wrapper_imports_in_a_fresh_interpreter.py ^







  projects/behemoth_eye/eye/tests/test_no_set_number_drops_what_the_eye_was_shown.py ^







  projects/behemoth_eye/eye/tests/test_a_loop_stops_when_it_settles_not_at_a_count.py ^







  warp2/capability/tests/test_only_a_picture_parts_class_is_a_candidate_for_parts.py ^







  warp2/capability/tests/test_random_parts_takes_a_plain_concept.py ^







  projects/behemoth_eye/eye/tests/test_a_link_made_in_one_child_survives_another_childs_save.py ^







  warp2/capability/tests/test_a_link_is_on_disk_the_moment_it_is_made.py ^







  warp2/record/tests/test_an_unreadable_kept_file_is_never_replaced.py ^







  warp2/ask/tests/test_a_torn_ledger_is_never_replaced.py ^







  projects/behemoth_eye/eye/tests/test_nothing_measured_is_never_a_number.py ^







  projects/behemoth_eye/eye/tests/test_an_error_is_said_not_used_as_an_answer.py ^







  warp2/capability/tests/test_the_hub_not_reached_is_not_a_fact_about_the_dataset.py ^







  projects/behemoth_eye/eye/tests/test_refined_intake_records_refusal_errors.py ^
  design/tests/test_no_new_faults.py ^







  warp2/improve/tests/test_a_revision_that_adds_a_fault_is_not_proven.py ^







  warp2/capability/tests/test_the_step_stays_on_a_set_until_it_settles.py ^







  projects/behemoth_eye/pairs/tests/test_an_edit_is_judged_on_rows_it_never_learned.py ^







  projects/centering_image/tests/test_a_finished_reader_does_not_wait_for_stream_close.py ^







  warp2/work/side/tests/test_practice_runs_the_eye_in_a_child.py ^







  projects/behemoth_eye/eye/tests/test_a_picture_part_reads_through_the_scale.py ^







  projects/behemoth_eye/eye/tests/test_a_part_is_taught_until_it_reads_its_examples_right.py ^







  projects/behemoth_eye/eye/tests/test_a_part_reads_every_one_of_its_classes.py ^







  projects/behemoth_eye/eye/tests/test_a_parts_concepts_end_epochs_by_their_probe.py ^







  projects/behemoth_eye/eye/tests/test_a_concepts_parts_are_read_as_its_company.py ^







  warp2/record/tests/test_a_chat_turn_that_taught_words_worked.py ^







  warp2/chat_learning/tests/test_the_say_lesson_keeps_its_share.py ^







  warp2/chat_learning/tests/test_the_lessons_claim_what_finishing_takes.py ^







  warp2/chat_learning/tests/test_a_lesson_claims_its_setup.py ^







  projects/game_player/tests/test_the_player_looks_ahead.py ^







  warp2/chat_learning/tests/test_held_scenarios_get_a_turn.py ^
  warp2/chat_learning/tests/test_silence_earns_no_trust.py ^







  warp2/ask/tests/test_logic_rules_are_proven_by_truth_table.py ^







  warp2/ask/tests/test_logic_problems_are_checked.py ^







  warp2/ask/tests/test_logic_learning.py ^







  warp2/make/tests/test_a_build_can_finish.py ^







  projects/behemoth_eye/eye/tests/test_parts_are_used_one_look_at_a_time.py ^







  projects/behemoth_eye/eye/tests/test_the_gap_finder_reads_the_relations_once.py ^







  projects/behemoth_eye/eye/tests/test_a_mix_solves_each_candidate_once.py ^







  projects/behemoth_eye/eye/tests/test_the_concept_web_reads_each_reading_once.py ^







  warp2/graph_play/tests/test_sides_by_kind.py ^







  warp2/share/tests/test_two_machines_share_one_public_graph.py ^







  warp2/share/tests/test_the_share_step_writes_and_reads.py ^







  warp2/share/tests/test_the_share_trusts_nothing_unproven.py ^







  warp2/share/tests/test_a_lost_evidence_does_not_stop_the_feed.py ^







  warp2/share/tests/test_a_held_back_fact_is_named_and_sent_when_its_evidence_returns.py ^







  warp2/nexus/tests/test_levels_families_and_coins.py ^







  warp2/work/side/tests/test_side_turns.py ^







  warp2/train/tests/test_readers_stop_when_the_turn_ends.py ^







  projects/behemoth_eye/eye/tests/test_a_held_pair_file_is_moved_in_when_the_hold_passes.py ^







  projects/behemoth_eye/eye/tests/test_a_held_move_is_written_down.py ^







  warp2/tests/test_a_stack_dump_is_not_a_sign_of_life.py ^







  projects/behemoth_eye/eye/tests/test_the_company_is_read_again_only_after_a_fire.py ^







  projects/behemoth_eye/eye/tests/test_kept_rows_are_saved_and_reused.py ^







  projects/behemoth_eye/eye/tests/test_kept_rows_survive_a_save_that_never_read_them.py ^

  projects/behemoth_eye/eye/tests/test_kept_rows_never_turn_big_numbers_to_infinity.py ^

  projects/behemoth_eye/pairs/tests/test_held_rows_are_finite.py ^
  warp2/tags/tests/test_the_warp_looks_for_what_needs_dehydrating_and_tags.py ^

  warp2/record/tests/test_an_unkept_answer_is_the_step_s_error.py ^
  warp2/makers/tests/test_an_empty_answer_cools_the_model.py ^
  warp2/house/tests/test_a_spoilt_card_ends_the_house.py ^
  warp2/webs/tests/test_a_catch_up_names_its_slow_part.py ^
  warp2/webs/tests/test_a_catch_up_asks_which_edges_stand_at_once.py ^
  warp2/webs/tests/test_a_catch_up_counts_standing_and_stated_edges.py ^
  projects/behemoth_eye/eye/tests/test_the_made_line_says_whether_the_edge_set_moved.py ^
  warp2/webs/tests/test_a_batched_catch_up_takes_the_same_rows.py ^
  projects/behemoth_eye/eye/held_small/tests/test_an_epoch_names_the_tensors_it_upgraded.py ^
  projects/behemoth_eye/eye/held_small/tests/test_upgrade_names_are_not_truncated.py ^
  projects/behemoth_eye/eye/tests/test_a_turn_ends_on_the_fine_clock.py ^
  projects/behemoth_eye/eye/tests/test_the_reader_labels_made_lines_apart_from_the_writer.py ^






  warp2/make/tests/test_research_falls_short_by_temperature.py ^







  projects/behemoth_eye/eye/tests/test_mixes_are_worked_out_a_few_at_a_time.py ^

  projects/behemoth_eye/eye/tests/test_mixes_only_for_names_that_moved.py ^

  projects/behemoth_eye/eye/tests/test_the_ending_write_works_out_no_mix.py ^

  warp2/house/tests/test_the_room_is_looked_at_as_each_answer_begins.py ^

  projects/behemoth_eye/eye/tests/test_a_save_times_each_part.py ^
  projects/behemoth_eye/eye/tests/test_a_save_records_its_mix_work.py ^







  warp2/train/tests/test_training_stopped_part_way_keeps_what_it_did.py ^







  projects/behemoth_eye/eye/tests/test_every_mix_reads_the_sums_once.py ^







  warp2/app/tests/test_the_window_words_add_no_known_fault.py ^







  projects/game_builder/tests/test_a_copy_is_fetched_with_its_licence.py ^







  projects/behemoth_eye/eye/tests/test_the_eye_reads_its_looks_together.py ^







  projects/behemoth_eye/eye/tests/test_company_is_read_once_for_all.py ^







  warp2/makers/tests/test_skills_and_practice.py ^







  warp2/makers/tests/test_code_is_fetched_written_tested_and_rewritten.py ^







  projects/game_builder/tests/test_games_are_read_measured_and_chosen.py ^







  warp2/work/side/tests/test_the_game_turn_reads_measures_and_chooses.py ^







  warp2/work/side/tests/test_the_code_turn_finds_writes_and_rewrites.py ^







  warp2/seed/tests/test_three_ways_to_start_from_a_seed.py ^







  projects/behemoth_eye/eye/tests/test_room_making_rests_after_a_pass_gave_nothing.py ^







  warp2/record/tests/test_the_gate_has_the_card_alone.py ^







  warp2/record/tests/test_a_hard_crash_says_where.py ^







  warp2/control/tests/test_a_failed_gate_keeps_its_output.py ^







  warp2/store/tests/test_a_view_read_survives_one_disk_error.py ^







  warp2/capability/tests/test_a_try_says_where_its_time_went.py ^







  warp2/app/tests/test_eye_tree.py ^







  warp2/app/tests/test_the_window_reads_its_costly_parts_paced.py ^







  warp2/work/tests/test_the_memory_floor_does_not_load_the_eye.py ^







  warp2/work/tests/test_the_largest_program_is_found_by_size_first.py ^







  warp2/ui/tests/test_the_whole_table_counts_are_paced_by_their_cost.py ^







  warp2/room/tests/test_each_step_is_fitted_to_the_room_the_machine_has.py ^







  warp2/room/tests/test_a_windows_child_is_measured_and_never_refused.py ^







  warp2/room/tests/test_the_warp_adapts_to_what_it_has.py ^







  warp2/models/tests/test_only_internal_models_are_used.py ^







  warp2/house/tests/test_the_house_holds_models_inside_the_warp.py ^







  warp2/house/tests/test_the_house_reads_pictures.py ^







  warp2/room/tests/test_a_long_lived_process_moves_its_own_fence.py ^







  warp2/house/tests/test_a_house_answer_is_the_answer_not_the_thinking.py ^







  warp2/house/tests/test_the_house_gives_room_back.py ^







  warp2/train/tests/test_a_round_is_judged_job_by_job_and_stops_when_it_stops_learning.py ^







  warp2/record/tests/test_slow_is_not_frozen.py ^







  warp2/record/tests/test_the_warps_own_work_runs_while_it_works.py ^







  warp2/publish/tests/test_what_is_public_is_checked_and_sent_by_the_warp.py ^







  warp2/seed/tests/test_a_phone_is_a_golem_however_strong.py ^







  warp2/room/tests/test_a_process_short_of_room_gives_its_own_back_first.py ^







  warp2/room/tests/test_a_wait_says_what_it_took_back.py ^







  projects/behemoth_eye/eye/tests/test_a_whole_reply_is_made_in_one_pass.py ^







  projects/behemoth_eye/pairs/tests/test_a_saved_network_comes_back_without_being_built_from_nothing.py ^







  projects/behemoth_eye/eye/tests/test_a_lesson_fits_its_turn.py ^







  warp2/train/tests/test_block_teaching_stops_with_its_turn.py ^







  design/tests/test_andrews_words_2026_11_10_everywhere.py ^







  design/tests/test_andrews_words_2026_11_10_tags.py ^







  warp2/tags/dehydrated/tests/test_dehydrated_lane.py ^







  warp2/tags/dehydrated/tests/test_the_warp_reads_the_small_lane.py ^







  warp2/work/side/tests/test_the_warp_keeps_its_kg_small.py ^







  warp2/work/tests/test_only_the_side_steps_run.py ^







  warp2/webs/tests/test_the_connection_layer_held_small.py ^







  warp2/house/tests/test_the_models_learn_the_graphs_web_tags.py ^







  warp2/house/tests/test_web_tag_lessons_read_a_kept_record.py ^







  warp2/house/tests/test_a_tag_lesson_fits_its_turn.py ^







  warp2/house/tests/test_a_tag_turn_is_named_before_it_starts.py ^







  warp2/house/tests/test_a_tag_turn_says_its_clock.py ^







  warp2/house/tests/test_a_tag_turn_says_why_it_stopped.py ^







  warp2/house/tests/test_a_tag_turn_leaves_room_to_save.py ^







  warp2/house/tests/test_a_house_load_failure_keeps_its_stage.py ^
  warp2/house/tests/test_an_adapter_keeps_the_bases_offload_folder.py ^







  projects/behemoth_eye/eye/tests/test_a_token_that_already_has_a_pair_is_taught_not_made_again.py ^







  projects/behemoth_eye/eye/tests/test_two_pairs_claiming_one_token.py ^







  projects/behemoth_eye/eye/held_small/tests/test_a_pair_held_small_reads_back_the_same.py ^







  projects/behemoth_eye/eye/tests/test_pairs_are_read_from_the_tensor_book.py ^







  warp2/house/held_small/tests/test_a_house_model_is_kept_small_and_loaded_from_there.py ^







  warp2/house/held_small/tests/test_the_reader_the_picture_model_and_the_adapter_load_from_their_small_forms.py ^







  warp2/house/held_small/tests/test_a_model_is_taught_from_its_small_form.py ^







  warp2/tags/dehydrated/tests/test_the_warp_reads_the_small_form_first.py ^







  warp2/house/held_small/tests/test_a_made_not_saved_part_in_a_weight_file_is_passed_over.py ^







  projects/behemoth_eye/eye/held_small/tests/test_the_book_lets_go_of_what_nothing_points_at.py ^







  warp2/house/held_small/tests/test_the_house_book_lets_go_when_a_file_is_kept_again.py ^







  warp2/tags/dehydrated/tests/test_the_originals_go_to_deep_storage.py ^







  projects/behemoth_eye/eye/tests/test_the_eyes_own_files_are_read_from_the_tensor_book.py ^







  warp2/house/held_small/tests/test_the_direct_and_training_loaders_fill_from_the_small_form.py ^







  warp2/house/held_small/tests/test_an_adapter_is_put_on_within_the_models_limits.py ^







  projects/behemoth_eye/eye/tests/test_token_trials_stay_inside_the_turn.py ^







  warp2/work/side/tests/test_the_media_turn_uses_the_loops_store.py ^







  warp2/tags/dehydrated/tests/test_sent_segments_do_not_reduce_the_remaining_count.py ^







  projects/behemoth_eye/eye/tests/test_the_save_is_written_in_pieces.py ^







  projects/behemoth_eye/eye/tests/test_two_saves_never_share_a_temporary_file.py ^







  projects/behemoth_eye/eye/tests/test_two_writers_keep_both_learnings.py ^







  projects/behemoth_eye/eye/tests/test_merge_lock_owner.py ^







  projects/behemoth_eye/eye/tests/test_a_living_writer_keeps_its_turn_past_an_hour.py ^







  projects/behemoth_eye/eye/tests/test_a_lost_pair_is_reloaded_not_a_crash.py ^







  projects/behemoth_eye/eye/tests/test_a_save_keeps_what_the_activation_layer_names.py ^

  projects/behemoth_eye/eye/tests/test_a_book_concept_the_layer_lacks_is_joined.py ^
  projects/behemoth_eye/eye/tests/test_concept_pairs_made.py ^






  warp2/webs/tests/test_a_huge_record_does_not_stop_the_oracle.py ^







  warp2/webs/tests/test_a_carried_record_is_never_multiplied.py ^







  warp2/webs/tests/test_the_carry_tally_reaches_the_receipt.py ^







  warp2/house/tests/test_a_house_model_with_no_written_length_answers_in_full.py ^





















  warp2/make/tests/test_a_judge_that_cannot_tell_true_from_false_counts_little.py ^







  warp2/make/tests/test_a_panel_that_cannot_see_decides_nothing.py ^







  warp2/make/tests/test_a_verdict_nobody_could_see_is_not_a_fail.py ^

  warp2/make/tests/test_a_blind_wait_wakes_after_the_sight_span.py ^

  warp2/make/tests/test_a_blind_wake_leaves_a_mark.py ^







  warp2/make/tests/test_a_torn_sight_book_is_left_as_it_is.py ^



  warp2/make/tests/test_the_judges_see_the_state_everywhere.py ^

  warp2/sweep/tests/test_the_sweeps_judges_see_the_state.py ^
  warp2/house/tests/test_a_house_oom_keeps_its_lesson.py ^

  warp2/house/tests/test_an_asker_gives_the_card_back_before_asking.py ^
  warp2/house/tests/test_the_house_keeps_what_it_held.py ^
  warp2/house/tests/test_a_failed_house_ask_keeps_its_reason.py ^
  warp2/house/held_small/tests/test_an_answer_reads_each_weight_once_while_there_is_room.py ^
  warp2/house/held_small/tests/test_an_answer_leaves_room_for_its_attention.py ^
  warp2/house/held_small/tests/test_a_model_is_run_from_the_rows_the_book_keeps.py ^
  projects/behemoth_eye/pairs/tests/test_rest_never_grows_memory.py ^
  projects/behemoth_eye/pairs/tests/test_rest.py ^
  projects/behemoth_eye/pairs/tests/test_compensation_reads_a_level_at_once.py ^
  projects/behemoth_eye/eye/held_small/tests/test_sameness_is_exact_and_never_coerced.py ^
  projects/behemoth_eye/eye/held_small/tests/test_every_save_says_its_read_back.py ^

  projects/behemoth_eye/eye/held_small/tests/test_the_book_says_who_holds_its_write_lock.py ^
  projects/behemoth_eye/eye/held_small/tests/test_a_writer_note_clears_only_itself.py ^
  projects/behemoth_eye/eye/held_small/tests/test_a_writer_waits_past_the_longest_hold.py ^
  projects/behemoth_eye/eye/held_small/tests/test_a_failed_rollback_still_lets_go_of_the_lock.py ^
  warp2/seed/tests/test_the_seed_carries_the_whole_eye_and_public_kg.py ^
  projects/behemoth_eye/eye/tests/test_a_pair_is_sized_without_being_read_back.py ^
  warp2/work/side/tests/test_one_verdict_concepts_are_reported_apart.py ^
  projects/behemoth_eye/eye/tests/test_every_written_save_logs_its_parts.py ^
  projects/behemoth_eye/eye/tests/test_carry_keeps_each_names_looks.py ^
  projects/behemoth_eye/eye/tests/test_the_concept_web_is_not_made_when_nothing_moved.py ^
  projects/behemoth_eye/eye/tests/test_hierarchy_relations_are_kept_when_nothing_moved.py ^
  projects/behemoth_eye/eye/tests/test_save_keys_are_receipted_and_checked_by_trust.py ^
  projects/behemoth_eye/eye/tests/test_carry_trusts_its_own_file_by_stat.py ^
  warp2/webs/tests/test_the_oracle_keeps_who_was_asked.py ^
  warp2/corpus/kinds/tests/test_a_picture_too_wide_for_webp_is_kept_as_rows.py ^
  warp2/house/tests/test_the_house_keeps_a_model_whose_put_down_cannot_help.py ^
  warp2/models/tests/test_a_model_cut_at_its_reach_gets_more_time.py ^
  warp2/house/tests/test_a_model_is_loaded_whole_on_the_card_when_it_can_be.py ^
  warp2/house/tests/test_a_house_ask_carries_its_request_id.py ^
  warp2/webs/tests/test_an_oracle_line_carries_the_house_attempt_id.py ^
  projects/behemoth_eye/eye/tests/test_a_lesson_is_taught_on_what_it_read_when_its_rows_were_marked.py ^
  warp2/house/tests/test_a_pending_house_line_is_rejoined_as_a_new_line.py ^
  warp2/make/tests/test_a_blind_judge_gives_its_tags_at_the_end.py ^
  warp2/work/side/tests/test_the_folder_to_the_kg.py ^
  warp2/corpus/tests/test_outside_folders_come_in_through_the_warps_own_keeper.py ^
  warp2/make/tests/test_a_retry_note_comes_from_the_judge_that_sees.py ^
  projects/behemoth_eye/eye/held_small/tests/test_a_lane_reads_under_either_import_name.py ^
  warp2/work/side/tests/test_a_behind_step_goes_first_once_a_round.py ^
  warp2/corpus/tests/test_a_corpus_finds_its_names_without_opening_every_part.py ^
  warp2/tags/tests/test_a_write_reads_its_things_tags_only_when_a_rule_asks.py ^
  warp2/corpus/tests/test_what_is_not_dehydrated_is_found_and_kept_small.py ^
  warp2/house/held_small/tests/test_a_small_form_miss_is_said_with_its_trace.py ^
  warp2/house/held_small/tests/test_a_small_form_skip_says_why.py ^
  warp2/house/held_small/tests/test_an_adapter_put_on_reads_each_base_weight_once.py ^
  warp2/house/held_small/tests/test_an_adapter_put_on_reads_no_base_weight.py ^
  warp2/house/held_small/tests/test_streamed_tensor_owners_survive_an_adapter.py ^
  warp2/work/side/tests/test_behind_steps_take_every_other_slot.py ^
  warp2/house/tests/test_the_residency_line_names_the_loader_path.py ^
  warp2/room/tests/test_a_refusal_keeps_the_look_that_refused_it.py ^
  warp2/wise_men/tests/test_a_vote_keeps_its_house_request_id.py ^
  warp2/wise_men/tests/test_a_vote_says_how_its_answer_was_heard.py ^
  warp2/room/tests/test_a_free_of_nought_says_if_it_was_read.py





echo.







echo ALL DONE. If everything says PASSED, run WARP3.bat. You can close this window now.







pause







