@echo off
REM WARP2/RESTART_GUI.bat - Safely restarts the WARP2 GUI window without affecting runners.
REM Direct response to Andrew's mandate in muse-186: "and have a restart for the GUI".
setlocal
cd /d "%~dp0"

echo [WARP2] Restarting GUI window...
echo [WARP2] Closing existing GUI window instances...

powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'warp2\.app' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"

timeout /t 1 /nobreak >nul

echo [WARP2] Launching fresh GUI window...
start "" pyw -3.11 -X faulthandler -B -m warp2.app "%CD%"

echo [WARP2] GUI restart command issued.
