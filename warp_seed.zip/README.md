# WARP2

**Path:** `WARP2/README.md`

**Header**
- *Used by:* every session that works on the rebuild; the launchers, once they exist.
- *Uses:* `docs/AUDIT_2026_08_27.md` (the evidence this rebuild answers to), `docs/BUILD_LOG.md` (what has actually landed).
- *Description:* The second warp. Not a copy of `WARP/` and not a refactor of it — a rebuild in which every part must earn its place against measured evidence from the first one. `WARP/` stays untouched and runnable as the reference; nothing is deleted from it.
- *User intention:* Andrew, 2026-08-27 — *"a new version of the warp… see what is working and what does not and what the most recent research says about every part and slowly work it out one piece at a time testing as we go."* One piece at a time. Research before each piece. Nothing moves on until the current piece passes.

---

## The rules this rebuild adds

The four principles (Clean · Adaptive · Smooth · Modular) and the per-file discipline carry over unchanged. The audit adds four more, each answering a measured defect:

1. **Production evidence, or it does not come across.** A part enters WARP2 when a live run has exercised it and the journal shows it. Green tests are necessary, not sufficient — WARP has 105 public symbols that only its own tests ever call.
2. **The output ledger is the scoreboard.** Built and proven counts are visible at all times. A change is good if that ratio moves. WARP's standing figure: 185 built and 30 proven against 20,172 open.
3. **Sourcing is bounded by the ability to build.** Work is derived against a budget taken from measured throughput, never against the size of the graph.
4. **The per-fact cost is designed before anything is stored.** WARP pays ~1.7 KB per tag and 105 GB of state. The storage form is measured against a budget first.

## Starting it

    WARP2.bat                       what is wrong, in one screen
    ALL_STOP.bat                    stop everything, now

or, the same thing without the batch files:

    python -m warp2.run doctor      what is wrong
    python -m warp2.run go --passes 5
    python -m warp2.run window      one page saying where everything stands
    python -m warp2.run stop        raise ALL_STOP
    python -m warp2.run clear       take it down again

### Giving it something to build

Nothing happens until a project has **areas**. An area is a sentence saying
what should exist and what it is for — and that sentence is what the gate
checks the finished artifact against, so it is worth writing properly.

    python -m warp2.run projects                       what it is building
    python -m warp2.run projects open APEX the architecture
    python -m warp2.run projects area APEX "Input Representation" \
        convert arbitrary modalities into fixed-size representations
    python -m warp2.run projects propose APEX docs/SOMETHING.md   [--yes]
    python -m warp2.run projects carry ..\WARP                    (once)

`propose` reads a document for a sentence saying what is still to be built and
offers what it finds. It writes nothing without `--yes`.

### Giving it something to work with

    python -m warp2.run models find [--yes]     ask this machine what it has
    python -m warp2.run models                  how each one has done
    python -m warp2.run machine probe           prove whether local CUDA works
    python -m warp2.run machine size <checkpoint> [tokens] [--free-mb N]

`find` asks the four ports a local runner usually listens on — 11434 Ollama,
8080 llama.cpp, 1234 LM Studio, 8000 vLLM — and offers to write `models.json`.
Without models the loop still runs: it does the work that code can decide
(describing things, confirming half-done effects) and leaves the rest open,
saying so.

Checkpoint sizing is on demand, so the normal endpoint/command path does not
acquire a PyTorch dependency. `machine size` reads the actual weight shards and
decoder config, separates weights, measured sequence overhead and KV cache,
and reports GPU, explicitly degraded CPU (`--allow-cpu`), or refusal plus the
largest context that would fit.

### Looking at it

    python -m warp2.run gate        every clause, and the gate's own defects
    python -m warp2.run terms       the tag network as a picture
    python -m warp2.run look <thing> [--when 2026-08-01T00:00:00+00:00]
    python -m warp2.run merge <contribution.json> [--yes]

`merge` restores THE_LOOM's canonical staged-contribution function. It accepts
WARP2 facts and the Loom's nodes/edges shape, previews by default, requires the
contribution's source, timestamp and reason, validates the complete input before
writing, and only states it with `--yes`. Relations with no WARP2 equivalent are
kept as named legacy-edge facts rather than dropped or guessed.

## Where things live

    warp2/record/     the one guarded pathway, the lanes, the write gateway
    warp2/store/      what is known — facts, the tag network, projects
    warp2/work/       the loop: what to do next, when it is done, who does it
    warp2/gate/       what work is allowed to be, and whether it was
    warp2/models/     who does the work that needs a model
    warp2/vault/      the archive, and the check that reads it
    warp2/run.py      the entry surface
    warp2/observer.py the one page
    state/            the record and the store — not synced, not edited by hand
    docs/             the audit, the research surveys, the build log

Everything under `warp2/` carries its own header saying what uses it, what it
uses, what it is, and the user intention behind it. That is checked by a test.

## Status

Running. It indexes a tree, derives its own work against a bound taken from
measured throughput, does the work that needs no model, judges anything a model
writes against obligations the model was shown, writes files through one
recorded gateway, and closes a unit only when the gap that raised it has
closed. It has never been given a model.

The carry policy changed on 2026-08-29: every WARP and canonical Loom function
must have a callable home or an explicit gated compatibility path in WARP2.
Earlier `LEFT` rows are now carry work, not permanent exclusions. Raw duplicate
scripts and daemons are still not copied when their function already has a
safer WARP2 home.

See `docs/BUILD_LOG.md` for what landed and what broke on the way.
