@echo off
REM ============================================================================
REM  Pathway   : WARP2/ALL_STOP.bat
REM  Used by   : Andrew, when he wants it to stop and does not want to think.
REM  Uses      : warp2/run.py.
REM  Description:
REM    Raises ALL_STOP. One file, one purpose, no arguments needed.
REM  User intention (Andrew):
REM    The stop has to be reachable without thinking. A stop that has
REM    conditions is not a stop.
REM ============================================================================
setlocal
cd /d "%~dp0"
REM The cache goes outside OneDrive here too, so raising the stop cannot
REM itself write bytecode beside the code. NO PURGE LOOP ON THIS PATH ON
REM PURPOSE: a stop that walks the tree first is not a stop.
set "PYTHONPYCACHEPREFIX=%LOCALAPPDATA%\WARP2\pycache"
python -m warp2.run stop %*
endlocal
