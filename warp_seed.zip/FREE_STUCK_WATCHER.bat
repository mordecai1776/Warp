@echo off
REM ============================================================================
REM  Pathway   : WARP2/FREE_STUCK_WATCHER.bat
REM  Used by   : Andrew, when Claude's report says the watcher is stuck.
REM  Uses      : FREE_STUCK_WATCHER.ps1.
REM  Description:
REM    Ends ONLY the restart watcher whose heartbeat has stopped, so its
REM    service starts a fresh one. It never touches the running warp.
REM  User intention (Andrew, 2026-10-16): the warp must never stay down; Claude
REM    may restart it, and anything Andrew must run goes in a .bat.
REM ============================================================================
setlocal
cd /d "%~dp0"
PowerShell -NoProfile -ExecutionPolicy Bypass -File "%CD%\FREE_STUCK_WATCHER.ps1"
echo.
echo [WARP2] Done. You can close this window.
pause
endlocal
