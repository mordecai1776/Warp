@echo off
REM ============================================================================
REM  Pathway   : WARP2/WARP2.bat
REM  Used by   : Andrew, on Windows, by double-clicking or from a prompt.
REM  Uses      : warp2.app (the one window), and as a fallback warp2.ui.observer
REM              (Tk Cockpit) and warp2.ask.window (Action Centre),
REM              warp2.run (continuous go / verbs).
REM  Description:
REM    The master launcher for WARP2. Opens the sovereign GUI cockpit in its own
REM    window, then starts the continuous execution loop.
REM  User intention (Andrew):
REM    "I ran the bat for it and there was no gui and i dont think it continues to run either."
REM    Double-clicking opens the live GUI cockpit window and continuously runs work.
REM
REM    "it needs to be working and doing work" - 2026-09-05, after four launches
REM    that each found ALL_STOP raised, refused, and sent him away to run a
REM    second command. Double-clicking is now enough: if a stop is raised, the
REM    run says who raised it, when and why, names the file holding it, and
REM    ASKS whether to lift it.
REM    2026-10-08, Andrew: "it should lift the all stop automatically when the
REM    bat is run." Running this file IS the deliberate act now: a plain
REM    double-click (no arguments) lifts ALL_STOP before the runner starts. The
REM    watcher's automatic restarts start the runner directly, never this file,
REM    so a stop is still never lifted by the machine itself.
REM ============================================================================
setlocal
cd /d "%~dp0"


REM PURGE STALE BYTECODE BEFORE ANYTHING IMPORTS. This tree lives on OneDrive,
REM where a cached .pyc has been seen shadowing an edited .py, so a fixed
REM source still runs the old broken code and NOTHING SAYS SO. It was measured
REM here on 2026-09-02: a mutation-test run reported a surviving mutant that had
REM never actually been loaded. RUN_SPOT.bat and RUN_BEHEMOTH.bat have carried
REM this guard for weeks; the warp's own launcher never got it.
set "WARP2_CACHE=%LOCALAPPDATA%\WARP2\pycache"
set "PYTHONPYCACHEPREFIX=%WARP2_CACHE%"
set "PYTHONDONTWRITEBYTECODE=1"
if exist "%WARP2_CACHE%" rd /s /q "%WARP2_CACHE%" 2>nul
REM And any __pycache__ that landed in the tree itself, from a launch that did
REM not set the prefix. 48 such folders were in the tree when this was written.
REM Walk from "." - the cd above already put us here. "%~dp0" expands with a
REM TRAILING BACKSLASH, and "...\WARP2\" ends in \" which cmd can read as an
REM escaped quote. Using . cannot go wrong.
for /d /r . %%d in (__pycache__) do @if exist "%%d" rd /s /q "%%d" 2>nul

REM Resolve Python 3.11+
REM Another tool's virtual environment (the Hermes agent's, on 2026-10-06) must
REM never be the one that runs the warp, so its marker is cleared first.
set "VIRTUAL_ENV="
set "WARP_PY="
py -3.11 -c "import sys;sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if not errorlevel 1 set "WARP_PY=py -3.11"
if not defined WARP_PY (
    python -c "import sys;sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
    if not errorlevel 1 set "WARP_PY=python"
)
if not defined WARP_PY (
    echo WARP2 requires Python 3.11 or newer.
    pause
    exit /b 1
)

REM Set PYTHONPATH so apex.core and centering_image modules are discoverable across all processes.
if defined PYTHONPATH (
    set "PYTHONPATH=%CD%;%CD%\projects\centering_image;%CD%\projects\behemoth_eye;%PYTHONPATH%"
) else (
    set "PYTHONPATH=%CD%;%CD%\projects\centering_image;%CD%\projects\behemoth_eye"
)

REM THE RIGHT PYTHON. A continuous run starts only on your own Python with the
REM graphics card usable - never inside another tool's environment
REM (warp2/control/interpreter.py; Andrew, 2026-10-08). WARP2_ALLOW_CPU=1 or
REM WARP2_ALLOW_VENV=1 lets a person say they mean it.
if "%~1"=="" (
    %WARP_PY% -B -m warp2.control.interpreter
    if errorlevel 1 goto wrong_python
)

REM A continuous run (including a watcher restart) starts only when the fast,
REM CPU-safe regression gate passes. One-off diagnostic commands remain direct.
if "%~1"=="" (
    echo [WARP2] Running the prestart regression gate...
    %WARP_PY% -B run_tests.py --preflight
    if errorlevel 1 goto preflight_failed
)

REM Record the interpreter, installed dependency versions and source revision
REM that actually launched this run. A receipt problem is visible but does not
REM prevent the runner from starting.
%WARP_PY% -B -m warp2.control.environment "%CD%"
if errorlevel 1 echo [WARP2] WARNING: environment fingerprint could not be recorded.

REM Resolve a windowless Python for GUI applications, so opening or recovering
REM the cockpit does not create a short-lived console beside the real window.
set "WARP_GUI_PY="
pyw -3.11 -c "import sys;sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if not errorlevel 1 set "WARP_GUI_PY=pyw -3.11"
if not defined WARP_GUI_PY (
    where pythonw >nul 2>&1
    if not errorlevel 1 set "WARP_GUI_PY=pythonw"
)
if not defined WARP_GUI_PY set "WARP_GUI_PY=%WARP_PY%"

REM THE ONE WINDOW. "remake the gui parts into one window and upgrade to the
REM best looking set up we can get" - Andrew, 2026-09-24. Dependencies are
REM installed explicitly by setup.ps1, never during a production launch.
%WARP_PY% -c "import PySide6, qfluentwidgets, pyqtgraph" >nul 2>&1
if errorlevel 1 (
    echo [WARP2] Optional GUI dependencies are missing. Run setup.ps1 to install them.
    goto old_windows
)
start "" /B %WARP_GUI_PY% -B -m warp2.app "%CD%"
goto windows_open

:old_windows
echo [WARP2] The one window could not open. Opening the old two windows.
REM Launch Desktop GUI Cockpit in background window
start "" /B %WARP_GUI_PY% -B -m warp2.ui.observer "%CD%"

REM And the action centre, in its own window beside it.
REM   "I ran the bat and I only got one window - it should either always open
REM    the user part or have a button to open it in the cockpit, do both."
REM    - Andrew, 2026-09-07. Both. The cockpit shows what the machine is doing;
REM    this is the only place a person tells it what to do, and a front door you
REM    have to know a command to open is not one. The cockpit also has an ASK
REM    button, for when this window has been closed and the cockpit is still up.
start "" /B %WARP_GUI_PY% -B -m warp2.ask.window "%CD%"
:windows_open

REM Run continuous execution loop if no arguments provided, or pass arguments through
if not "%~1"=="" goto one_shot
if not exist "state\control" mkdir "state\control"
REM Running the bat is the person's go-ahead: ALL_STOP is lifted here, once,
REM before the runner starts (Andrew, 2026-10-08). The clean-reload loop below
REM does not come back through here, so a stop raised while running stays.
%WARP_PY% -B -m warp2.run clear
>"state\control\run.expected" echo expected since %DATE% %TIME%
echo [WARP2] Window open. Running continuously... Press Ctrl+C or click ALL_STOP in GUI to halt.
:continuous_loop
%WARP_PY% -B -m warp2.run go --continuous
if exist "state\locks\stop.flag" (
    echo [WARP2] ALL_STOP is active. Exiting runner.
    goto person_ended
)
if errorlevel 4 goto unexpected_runner_exit
if errorlevel 3 goto clean_reload
if errorlevel 1 goto unexpected_runner_exit
goto person_ended
:clean_reload
echo [WARP2] Clean reload boundary reached. Restarting the runner...
timeout /t 1 /nobreak >nul
goto continuous_loop
REM A stop or a finished run is a deliberate end: the "runner expected" mark
REM comes down so the restart watcher starts nothing (check F1, 2026-10-09).
REM A crash below keeps the mark, so the watcher can still recover from it.
:person_ended
del /q "state\control\run.expected" 2>nul
goto runner_ended
:unexpected_runner_exit
echo [WARP2] Runner exited unexpectedly. The background watcher may recover it with bounded retries.
goto runner_ended
:one_shot
%WARP_PY% -B -m warp2.run %*
:runner_ended
endlocal
exit /b 0
:wrong_python
echo [WARP2] Runner was not started: this is not the Python the warp runs on.
pause
endlocal
exit /b 1
:preflight_failed
echo [WARP2] Prestart regression failed. Runner was not started; see state\diagnostics\tests.out.txt.
endlocal
exit /b 1
