# WARP2/warp2/gate/checks.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/checks.py
#  Used by   : warp2/gate/contracts.py, which assembles them into contracts.
#  Uses      : stdlib (ast, builtins, re); warp2/gate/clause.py;
#              warp2/gate/{self_reads,placeholder_notes,calls_exist}.py (the
#              checks that read what the code does with itself, the notes it
#              leaves, and whether what it calls exists), warp2/gate/self_import.py
#              (whether a file imports itself).
#  Description:
#    The checks, one obligation each, with the example each one accepts and the
#    example each one refuses. Every check here fired at least once in WARP's
#    production run; the count is on the clause.
#  User intention (Andrew, 2026-08-18):
#    "break the clauses down further." A coarse check cannot see the commonest
#    failure, and a check that reports two findings under one name teaches the
#    work that one obligation is twice as important as it is.
# ============================================================================
from __future__ import annotations

import ast
import builtins
import io
import re
import symtable
import tokenize

from warp2.gate.clause import Clause
from warp2.util import sha256_hex

# Phrases that mean "I did not do the work". DISJOINT from the TODO markers and
# from NotImplementedError on purpose: breaking clauses down is worthless if two
# of them report the same finding under different names.
PLACEHOLDER_MARKERS = (
    "replace with actual", "your code here", "implementation goes here",
    "pass  # stub", "your implementation here", "fill this in",
    "placeholder for actual", "path/to/", "assuming the artifact",
)

# Words that carry no intention on their own, so matching them proves nothing.
_STOPWORDS = frozenset({
    "that", "this", "with", "when", "from", "into", "then", "than", "must",
    "will", "have", "does", "should", "which", "what", "each", "every",
    "there", "their", "been", "were", "such", "only", "also", "more", "most",
})


# Intention: one place a check gives up quietly. A file that will not parse has
# exactly one useful complaint and `parses` owns it — every other check returns
# nothing rather than piling a second finding on the same cause.
def _tree(code: str):
    try:
        return ast.parse(code)
    except SyntaxError:
        return None


def _parses(code: str, _ctx: dict) -> str:
    """Intention: the first check: "" when the code parses, else the syntax error and its line."""
    try:
        ast.parse(code)
    except SyntaxError as exc:
        return f"SyntaxError line {exc.lineno}: {exc.msg}"
    return ""


def _no_placeholders(code: str, _ctx: dict) -> str:
    """Phrases that mean the work was not done. 190 firings in WARP, joint second."""
    lowered = code.lower()
    hits = [marker for marker in PLACEHOLDER_MARKERS if marker in lowered]
    return f"placeholder marker present: {hits[0]}" if hits else ""


def _said_by_the_code(code: str) -> str:
    """The code's own words: everything but string values, plus its docstrings.

    Intention: found 2026-09-24. A test of the gate holds a bad file AS DATA —
    "    pass  # TODO" inside a string — and the gate refused that test as
    unfinished, so worker.py's real, passing test could never prove it. A
    marker inside a string is something the code talks about; a marker in a
    comment or a docstring is something the code says about itself. A file
    that will not tokenize is read whole, as before.
    """
    kept = []
    try:
        for token in tokenize.generate_tokens(io.StringIO(code).readline):
            if token.type != tokenize.STRING and token.type != getattr(tokenize, "FSTRING_MIDDLE", -1):
                kept.append(token.string)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        return code
    tree = _tree(code)
    if tree is not None:
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                doc = ast.get_docstring(node, clean=False)
                if doc:
                    kept.append(doc)
    return " ".join(kept)


def _no_todo_markers(code: str, _ctx: dict) -> str:
    """TODO and FIXME, split out from the placeholder family on purpose.

    Intention: two checks reporting one finding under different names teach
    the work that one obligation is twice as important as it is.
    """
    lowered = _said_by_the_code(code).lower()
    for marker in ("todo:", "fixme", "xxx:"):
        if marker in lowered:
            return f"unfinished marker present: {marker}"
    return ""


def _no_not_implemented(code: str, _ctx: dict) -> str:
    """`raise NotImplementedError` is a declaration that the work is not done.

    Intention: asked of the code, not its strings — the same reason as above.
    """
    if "notimplementederror" in _said_by_the_code(code).lower():
        return "raises NotImplementedError instead of implementing"
    return ""


def _no_wildcard_imports(code: str, _ctx: dict) -> str:
    """A star import hides dependencies. Nothing else — see below for imports."""
    tree = _tree(code)
    if tree is None:
        return ""
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if any(alias.name == "*" for alias in node.names):
                return "wildcard imports are not accepted"
    return ""


# Intention: the relative-import question, taken out of the wildcard check
# because the honest answer is different for a test and for a module, and one
# check returning one refusal could not say so.
def _relative(tree) -> int:
    for node in ast.walk(tree or ast.Module(body=[], type_ignores=[])):
        if isinstance(node, ast.ImportFrom) and node.level and node.level > 0:
            return int(node.level)
    return 0


def _no_relative_imports(code: str, _ctx: dict) -> str:
    """A TEST is collected by its path, so it has no package to be relative to.

    Intention: this half of the old rule is unchanged and still absolute. A
    test file is handed to pytest as a path; there is no parent package, and
    `from .x import y` raises before a single assertion runs.
    """
    tree = _tree(code)
    if tree is None:
        return ""
    return ("relative imports (from . or from ..) do not work in a test — it is "
            "collected by path and has no parent package; import the module by "
            "its own name, or by its path from the project root"
            if _relative(tree) else "")


def _relative_only_in_a_package(code: str, ctx: dict) -> str:
    """A MODULE may be relative when it actually sits in a package.

    Intention: THIS RULE WAS TOO STRICT AND IT WAS BLOCKING A WHOLE PROJECT.
    The old reason — "relative imports break standalone pytest collection" —
    was true while `gate/proof.py` put only the artifact's own folder on the
    path. Since 2026-09-02 it puts the owning PROJECT on the path too, so a
    module inside a package is reachable as `apex.core.x` and its relative
    imports resolve exactly as Python intends. Measured the same day: 22 of the
    eye's 24 core modules are written this way and 279 of its tests pass, while
    the gate would have refused every one of them — so the rule was refusing
    working code, and the loop was told to write the same refusal twice on the
    2026-09-04 run.

    Outside a package it is still refused, because there it genuinely cannot
    work: there is no parent to be relative to.
    """
    tree = _tree(code)
    if tree is None or not _relative(tree):
        return ""
    if ctx.get("in_package"):
        return ""
    where = str(ctx.get("artifact_path") or "this file")
    return (f"relative imports need a package, and {where} is not in one — "
            f"there is no __init__.py beside it, so `from .x import y` has no "
            f"parent to resolve against; import by module name instead")


def _has_definitions(code: str, _ctx: dict) -> str:
    """A module that defines nothing is not an implementation.

    Intention: 16 firings, and it is deliberately the COARSEST of these — it
    catches a file that is only prose or only a call, and it is too blunt to
    see anything else. `no_empty_bodies` exists because of that bluntness.
    """
    tree = _tree(code)
    if tree is None:
        return ""
    kinds = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Assign,
             ast.AnnAssign)
    if any(isinstance(node, kinds) for node in tree.body):
        return ""
    return "module contains no implementation definitions"


def _no_empty_bodies(code: str, _ctx: dict) -> str:
    """A function whose body is only `pass`, a docstring, or `...`.

    Intention: 190 firings in WARP, joint second across 1,238 recorded
    complaints — and it was NOT a stated clause there, so the work was judged
    by it and never told about it. `has_definitions` is too coarse to see it: a
    file full of empty functions does define things.
    """
    tree = _tree(code)
    if tree is None:
        return ""
    empty = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        body = [stmt for stmt in node.body
                if not (isinstance(stmt, ast.Expr)
                        and isinstance(stmt.value, ast.Constant)
                        and isinstance(stmt.value.value, str))]
        if not body or all(isinstance(stmt, ast.Pass) for stmt in body):
            empty.append(node.name)
        elif (len(body) == 1 and isinstance(body[0], ast.Expr)
              and isinstance(body[0].value, ast.Constant)
              and body[0].value.value is Ellipsis):
            empty.append(node.name)
    return f"empty function bodies: {', '.join(empty[:4])}" if empty else ""


def _no_import_time_effects(code: str, _ctx: dict) -> str:
    """Work that runs on import rather than when called.

    Intention: 55 firings. A module that acts while being imported cannot be
    tested without doing whatever it does, and it does it during collection.
    """
    tree = _tree(code)
    if tree is None:
        return ""
    for node in tree.body:
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            name = ast.unparse(node.value.func)
            if name.split(".")[-1] not in {"print"}:
                return f"module executes calls at import time: {name}"
    return ""


# Intention: WHAT "DID SOMETHING" LOOKS LIKE INSIDE A FUNCTION. Any of these
# before the return means the function acted on the world or on its input —
# checked it (raise, assert), changed it (an assignment, a delete), asked
# something else (a call), or waited on something (await, yield).
_ACTS = (ast.Raise, ast.Assert, ast.Call, ast.Assign, ast.AugAssign, ast.AnnAssign,
         ast.Delete, ast.Await, ast.Yield, ast.YieldFrom, ast.NamedExpr)


def _returns_more_than_input(code: str, _ctx: dict) -> str:
    """A function that hands back exactly what it was given, and does nothing else.

    Intention: the shape that parsed, defined things, carried no placeholder
    and did nothing. None of the coarse checks could see it.

    AND ONLY THAT SHAPE (Andrew, 2026-09-23: find "the sweet spot where it
    kicks out the bad and lets in the good"). The first form read the return
    line alone, so a validator — check every field, raise on a bad one, then
    `return self` — was refused as doing nothing. Measured that day: 38 of the
    last two days' refusals were this one clause, almost all of them one
    `validate()` in projects/centering_image/experiment.py that already
    worked, and 48 files on disk had the same shape, so no edit to any of them
    could ever be accepted. A function that checks, changes, calls or waits
    before it returns has done something; only one that does none of those is
    a hand-back.
    """
    tree = _tree(code)
    if tree is None:
        return ""
    guilty = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        args = {a.arg for a in node.args.args}
        if not args:
            continue
        returns = [stmt for stmt in ast.walk(node)
                   if isinstance(stmt, ast.Return) and stmt.value is not None]
        if not returns:
            continue
        acts = any(isinstance(inner, _ACTS)
                   for stmt in node.body for inner in ast.walk(stmt))
        if not acts and all(isinstance(r.value, ast.Name) and r.value.id in args for r in returns):
            guilty.append(node.name)
    return (f"returns its own argument unchanged: {', '.join(guilty[:3])}"
            if guilty else "")


def _uses_every_parameter(code: str, _ctx: dict) -> str:
    """A parameter declared and never read is a promise the signature broke.

    Intention: measured on the second file WARP ever built. The intention asked
    for a layer that receives input AND CONTEXT; the signature accepted
    `context` and the body never mentioned it again. Every clause passed,
    including the intention one, because the WORD was present in the signature.
    Naming a thing is not using it.

    Three exemptions, each for a real pattern, because a check that fires on
    ordinary correct code stops the work: `self`/`cls` are bound rather than
    passed; a leading underscore is the language's own way of saying "accepted
    and deliberately unused"; `*args`/`**kwargs` are forwarding shapes.
    """
    tree = _tree(code)
    if tree is None:
        return ""
    offenders = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        spec = node.args
        declared = list(spec.posonlyargs) + list(spec.args) + list(spec.kwonlyargs)
        names = [a.arg for a in declared
                 if a.arg not in ("self", "cls") and not a.arg.startswith("_")]
        if not names:
            continue
        used = {inner.id for inner in ast.walk(node) if isinstance(inner, ast.Name)}
        for name in names:
            if name not in used:
                offenders.append(f"{node.name}({name})")
    if not offenders:
        return ""
    return (f"parameter declared and never used: {', '.join(offenders[:3])}; "
            f"use it or drop it from the signature")


def _imports_the_artifact(code: str, ctx: dict) -> str:
    """Text-level on purpose: this must still decide when the file will not
    parse, because a syntax error hid this exact complaint on a live run."""
    module = str(ctx.get("artifact_module") or "")
    if not module:
        # Intention: NO ARTIFACT NAMED IS A REFUSAL, NOT A PASS. Returning ""
        # here for two days is how sixty test units for four EMPTY projects
        # reached a model with nothing to import, and it invented `Artifact`
        # every time. There is nothing wrong with the work; the unit should
        # never have been raised, and the complaint says so to the thing that
        # raised it rather than to the thing that was asked to satisfy it.
        return ("no artifact was named for this work — there is nothing here "
                "to write a test against")
    pattern = re.compile(
        r"(?m)^\s*(?:from|import)\s+[^\n#]*\b" + re.escape(module) + r"\b",
        re.IGNORECASE)
    return "" if pattern.search(code) else f"test does not import artifact module {module}"


# Intention: EVERY NAME MUST COME FROM SOMEWHERE, and this is the clause that
# would have stopped the 2026-08-31 run from writing sixty files nobody could
# import. The gate checked that a test parsed, defined test_ functions and
# asserted something — all three of which `from artifact import Artifact` does
# — so unimportable code passed and then failed at collection, and the unit
# sank. Measured against this tree the day it was written: 377 of 393 real
# files clean, and every one of the sixteen it flagged was genuinely broken.
#
# DELIBERATELY FLAT, not a scope analysis. One set of every name the file binds
# anywhere is the conservative reading: it can miss a name used outside its
# scope, and it cannot invent a complaint about a name that is genuinely there.
# A checker's false refusal costs real work; its miss costs one more attempt.
_NAME_SOURCES = frozenset(dir(builtins)) | {
    "__file__", "__name__", "__doc__", "__package__", "__spec__", "__builtins__",
    # `self` out of place is already one clause's finding, and two clauses
    # reporting one cause teaches the work that it matters twice.
    "self", "cls",
}


# Intention: every name this file makes available to itself, from every place
# python can bind one — import, def, class, assignment, loop target, `with as`,
# `except as`, walrus, comprehension, parameter, lambda, global. Kept apart
# from the check that uses it so the binding rules can be read as a list and a
# missing form shows up as a missing line rather than as a false refusal.
def _bound_names(tree) -> set:
    names: set = set()

    def bind(target) -> None:
        """Intention: add every plain name an assignment target binds, going into tuples, lists and
        starred targets.
        """
        if isinstance(target, ast.Name):
            names.add(target.id)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for element in target.elts:
                bind(element)
        elif isinstance(target, ast.Starred):
            bind(target.value)

    def parameters(spec) -> None:
        """Intention: add every parameter name of a function or lambda, including *args and **kwargs."""
        for arg in (list(spec.posonlyargs) + list(spec.args) + list(spec.kwonlyargs)
                    + [one for one in (spec.vararg, spec.kwarg) if one]):
            names.add(arg.arg)

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            names.add(node.name)
            parameters(node.args)
        elif isinstance(node, ast.ClassDef):
            names.add(node.name)
        elif isinstance(node, ast.Lambda):
            parameters(node.args)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                names.add((alias.asname or alias.name).split(".")[0])
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                bind(target)
        elif isinstance(node, (ast.AugAssign, ast.AnnAssign)):
            bind(node.target)
        elif isinstance(node, (ast.For, ast.AsyncFor, ast.comprehension)):
            bind(node.target)
        elif isinstance(node, ast.withitem):
            if node.optional_vars is not None:
                bind(node.optional_vars)
        elif isinstance(node, ast.ExceptHandler):
            if node.name:
                names.add(node.name)
        elif isinstance(node, ast.NamedExpr):
            bind(node.target)
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            names.update(node.names)
    return names


def _names_come_from_somewhere(code: str, _ctx: dict) -> str:
    """A name used and never bound is an ImportError waiting for the runner."""
    tree = _tree(code)
    if tree is None:
        return ""
    known = _bound_names(tree) | _NAME_SOURCES
    missing: list = []
    for node in ast.walk(tree):
        if (isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)
                and node.id not in known and node.id not in missing):
            missing.append(node.id)
    if not missing:
        return ""
    return ("uses names it never imports or defines: "
            + ", ".join(sorted(missing)[:4])
            + "; import the real module and use the names it actually defines")


def _has_test_functions(code: str, _ctx: dict) -> str:
    """A pytest file with no test_ function is collected and runs nothing."""
    if re.search(r"(?m)^\s*(?:async\s+)?def\s+test_[A-Za-z0-9_]*\s*\(", code):
        return ""
    return "pytest file has no test_ functions"


def _asserts_behaviour(code: str, _ctx: dict) -> str:
    """`assert True` is a perfect assertion that examines nothing.

    Intention: six receipts recorded `passed` for nine `assert True` stubs,
    each written into the verification index as hash-bound proof. Recognizes
    both pytest `assert ...` and unittest `self.assert*` calls.
    """
    tree = _tree(code)
    if tree is None:
        return ""
    # Intention: Python's lexical scopes distinguish a captured method receiver
    # from an undefined global, including nested closures and comprehensions.
    try:
        symbols = symtable.symtable(code, "<test>", "exec")
    except SyntaxError:
        return ""
    module_self = next((s for s in symbols.get_symbols() if s.get_name() == "self"), None)
    bound_global = module_self is not None and (module_self.is_assigned() or module_self.is_imported())
    pending = [symbols]
    while pending:
        scope = pending.pop()
        pending.extend(scope.get_children())
        for symbol in scope.get_symbols():
            if (symbol.get_name() == "self" and symbol.is_referenced()
                    and symbol.is_global() and not bound_global):
                return "function uses 'self' without defining it; use plain `assert actual == expected`"

    asserts = [node for node in ast.walk(tree) if isinstance(node, ast.Assert)]
    unittest_asserts = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr.startswith("assert")
    ]
    if not asserts and not unittest_asserts:
        return "tests contain no assertion"
    if asserts and not unittest_asserts:
        constant = [isinstance(node.test, ast.Constant) for node in asserts]
        if all(constant):
            return ("tests assert only constants (`assert True` proves nothing); "
                    "assert what the artifact actually returns")
        shape_only = {"hasattr", "isinstance", "callable"}

        def is_shape(node):
            """Intention: true when an assert only checks shape (hasattr, isinstance, callable), not
            what the artifact does.
            """
            return (isinstance(node.test, ast.Call)
                    and isinstance(node.test.func, ast.Name)
                    and node.test.func.id in shape_only)

        if all(is_shape(node) or isinstance(node.test, ast.Constant) for node in asserts):
            return "tests assert only object shape, not observable artifact behaviour"
    return ""


def _keeps_required_names(code: str, ctx: dict) -> str:
    """A revision must still provide what its paired test imports.

    Intention: 372 firings, 30% of every complaint WARP ever recorded — the
    single largest cause, larger than syntax errors and placeholders combined.
    The candidate passed the gate and then failed its own test at collection
    with `ImportError: cannot import name ...`, because the rewrite dropped a
    name the test relies on.
    """
    required = tuple(ctx.get("required_names") or ())
    if not required:
        return ""
    tree = _tree(code)
    if tree is None:
        return ""
    defined = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            defined.add(node.name)
        elif isinstance(node, ast.Assign):
            defined.update(t.id for t in node.targets if isinstance(t, ast.Name))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            defined.add(node.target.id)
    missing = [name for name in required if name not in defined]
    if missing:
        return ("the paired test imports names this file does not define: "
                + ", ".join(sorted(missing)))
    return ""


def _changes_something(code: str, ctx: dict) -> str:
    """A revision identical to what was refused is not a revision.

    Intention: nine firings in WARP, and it was an engine check rather than a
    clause — so the work was refused for it without ever being told the rule.
    It is a clause here.
    """
    previous = str(ctx.get("previous") or "")
    if not previous:
        return ""
    if code.strip() == previous.strip():
        return "this is byte-identical to the file that was refused; change it"
    return ""


def _keeps_its_contract(code: str, ctx: dict) -> str:
    """A rewrite may not silently drop a public name the file already had.

    Intention: WARP's Socratic check, which asked whether a proposed change
    preserved the public contract before anything deployed or scored it. It is
    a different question from "keeps the names the paired test imports": that
    one is about one test, and this one is about **everybody who was already
    using this file**. A name removed here breaks callers nobody thought to
    look at, and it breaks them at import time — the failure furthest from the
    change that caused it.
    """
    previous = str(ctx.get("previous") or "")
    if not previous:
        return ""
    was = _public_names(previous)
    if not was:
        return ""
    now = _public_names(code)
    if now is None or was is None:
        return ""
    gone = sorted(was - now)
    if gone:
        return ("this drops public names the file already had: "
                + ", ".join(gone[:6])
                + " — keep them, or say why they are going")
    return ""


# Intention: what this file offers the outside world. Leading underscores are
# the language's own way of saying "mine", so removing one of those is not a
# broken promise.
def _public_names(code: str):
    tree = _tree(code)
    if tree is None:
        return None
    found = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if not node.name.startswith("_"):
                found.add(node.name)
        elif isinstance(node, ast.Assign):
            found.update(target.id for target in node.targets
                         if isinstance(target, ast.Name)
                         and not target.id.startswith("_"))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            if not node.target.id.startswith("_"):
                found.add(node.target.id)
    return found


def _intention_coverage(code: str, ctx: dict) -> tuple:
    """How many of an intention's distinctive words the code actually uses.

    Returns (present, needed), or (0, 0) meaning NO OPINION — no intention was
    supplied, or it carries no distinctive words. A check reading this must
    treat needed == 0 as passing: "nobody told us what this is for" is not
    evidence that the work is wrong.

    A FEW DISTINCTIVE TERMS, NOT A PROPORTION, and this calibration was paid
    for on live data. Requiring half the content words of a 31-word intention
    meant 16 words in one generated file; nine consecutive generations were
    refused and none could have passed. A clause nothing can satisfy does not
    raise the standard — it stops the work and teaches nothing.
    """
    intention = " ".join(str(ctx.get("proves_intention") or "").split())
    if not intention:
        return (0, 0)
    words = {w.lower() for w in re.findall(r"[A-Za-z]{4,}", intention)} - _STOPWORDS
    if not words:
        return (0, 0)
    lowered = code.lower()
    needed = 1 if len(words) < 2 else 2
    return (sum(1 for word in words if word in lowered), needed)


def _realizes_its_intention(code: str, ctx: dict) -> str:
    """A built artifact must be ABOUT the intention it was built to realize.

    Intention: measured on the FIRST file WARP ever built. The area said
    "convert arbitrary files and modalities into fixed-size trainable
    representations"; the model returned a 1,051-byte script that computes the
    SHA-256 of itself and prints its own contents. It parsed, defined
    functions, had no placeholders and no empty bodies, so every clause passed
    and the judge recorded `accepted: True, issues: []`. Not one of the
    intention's words appears in it. The gate checked that Python was produced;
    nothing checked that THIS Python was.
    """
    # Intention (2026-10-09, fix 5.7, check D3): read in the CODE — its names,
    # calls and values — not its comments or docstrings. The header writer
    # copies the intention into the comments, so every file built from parts
    # carried the words and passed whatever its code did.
    present, needed = _intention_coverage(code_only(code), ctx)
    if needed == 0 or present >= needed:
        return ""
    return ("the artifact does not mention what it is for; write the thing the "
            "intention describes, using its own terms")


def code_only(code: str) -> str:
    """The source with its comments and docstrings taken out; the source as given when it cannot be read.

    Intention (2026-10-09, fix 5.7): what the file does, without what it
    says about itself. A file that does not parse is judged as written —
    the clauses about parsing say what is wrong with it.
    """
    import ast
    import io
    import tokenize
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return code
    said = set()
    for node in ast.walk(tree):
        body = getattr(node, "body", None)
        if isinstance(body, list) and body and isinstance(body[0], ast.Expr) \
                and isinstance(getattr(body[0], "value", None), ast.Constant) \
                and isinstance(body[0].value.value, str):
            said.add((body[0].lineno, body[0].col_offset))
    kept = []
    try:
        for token in tokenize.generate_tokens(io.StringIO(code).readline):
            if token.type == tokenize.COMMENT:
                continue
            if token.type == tokenize.STRING and token.start in said:
                continue
            kept.append(token.string)
    except (tokenize.TokenError, IndentationError):
        return code
    return " ".join(kept)


def _not_a_copy_of_another_part(code: str, ctx: dict) -> str:
    """Each part of a project does a different job, so no two are the same file.

    Intention: MEASURED, AND IT PASSED EVERY OTHER CLAUSE. Five areas of
    CENTERING_IMAGE were built with one byte-identical file — concept
    population, concept recurrence, firing rule, master handoff and action
    population — and all five units closed, because a build closes when the
    file EXISTS and every clause here judges a file on its own. The intention
    clause did not catch it either: its bar is two distinctive words, which is
    a calibration paid for in refused generations and must not be raised, and
    one file about populations and data honestly meets it for four of those
    five intentions.

    So the thing that was missing was not a higher bar on one file. It was any
    question about the file NEXT to it. This asks that question and nothing
    else: the same bytes twice is one answer submitted twice, whatever it says.
    """
    others = ctx.get("other_artifacts") or {}
    if not others:
        return ""
    twin = others.get(sha256_hex(code.encode("utf-8")))
    if not twin:
        return ""
    return (f"this is the same file, byte for byte, as {twin} — each part of "
            f"this project does a different job, so write the one this "
            f"intention asks for")


def _names_what_it_proves(code: str, ctx: dict) -> str:
    """A design test exists to prove an intention, not to exercise a function.

    Intention: Andrew — design tests are "the ground of the system". One that
    does not restate what it proves is indistinguishable from an ordinary test,
    and the ground silently becomes ordinary coverage.
    """
    present, needed = _intention_coverage(code, ctx)
    if needed == 0 or present >= needed:
        return ""
    return ("the design test does not mention what it proves; state the "
            "intention it is testing")


# Intention: THE HEADER ANDREW ASKS FOR ON EVERY FILE. His standing rule for
# this tree: "Each file will also have a header that will have all files that
# are using said file and what files it uses. As will as a general description
# of the file and a section for user intention notes ... The pathway of the
# file should be at the top of every file." The gate had twenty-two clauses
# and not one of them was that, so every file the loop wrote went in without a
# header and nothing said so — measured 2026-09-20 on the files written that
# week (`rerun_and_recovery.py` begins `import os`). A rule that is never
# checked is a rule the machine cannot learn.
def _the_target(ctx: dict) -> str:
    """Intention: the path of the python file being written, from the WARP2 root; "" when no python file is named."""
    target = str((ctx or {}).get("target") or "").strip().replace("\\", "/")
    target = target[len("WARP2/"):] if target.startswith("WARP2/") else target
    return target if target.endswith(".py") else ""


def _carries_its_header(code: str, ctx: dict) -> str:
    """Whether the file opens with the header this tree requires — the tree's own rule.

    Intention (2026-10-09, fix 7.2, check D12): THE TREE'S RULE, NOT A WEAKER
    ONE. The gate took the path anywhere in the top 80 lines, or only the
    file's name, so files got in that the tree's own check refuses
    (projects/skills/code/bellman_ford_algorithm.py). The rule is now read
    from warp2/integrity/discipline.py, so the two cannot drift. With no file
    named there is no path to require, and NO OPINION is the honest answer
    (the same rule the intention clause follows).
    """
    from warp2.integrity.discipline import header_problems_text
    target = _the_target(ctx)
    if not target:
        return ""
    problems = header_problems_text(str(code), target)
    if not problems:
        return ""
    return "the file's header: " + "; ".join(p.split(": ", 1)[-1] for p in problems)


def _header_line(ctx: dict) -> str:
    """Intention: the clause SPEAKS the header to write, with this file's real path in it, in the tree's exact form."""
    target = _the_target(ctx) or "<this file's path>"
    return (f"open the file with '# WARP2/{target}' on the first line, then a header comment "
            f"with these fields: 'Pathway   : WARP2/{target}', 'Used by   :', 'Uses      :', "
            "'Description:' and 'User intention'")


def _every_part_has_a_note(code: str, ctx: dict) -> str:
    """Whether every function and class, at any depth, carries its own intention note.

    Intention (2026-10-09, fix 7.2): Andrew's standing rule — "Intention notes
    of what a part of the code is meant to do and why it is there ... on every
    part of the code" — asked of the code the gate lets in, by the tree's own
    check (warp2/integrity/discipline.py). A test file says what it is for in
    its names and is not asked. With no python file named, no opinion.
    """
    from warp2.integrity.discipline import bare_parts_text
    target = _the_target(ctx)
    if not target:
        return ""
    bare = bare_parts_text(str(code), target)
    names = [b.split("::", 1)[-1].replace(" has no intention note", "") for b in bare if "::" in b]
    if not names:
        return ""
    return ('give each of these an intention note — a docstring starting "Intention:" that says '
            "what it does and why it is there: " + ", ".join(names))


# --------------------------------------------------------------------------
# The clauses. Each carries the example it accepts and the example it refuses,
# and the suite runs both — an untested predicate is a hole with a name.
# --------------------------------------------------------------------------

_GOOD = "def hold(number):\n    return max(1, number)\n"

PARSES = Clause("parses", "return one complete python file that parses",
                _parses, passes=_GOOD, fails="def hold(:\n")
HAS_DEFINITIONS = Clause("has_definitions", "define the module's real work",
                         _has_definitions, passes=_GOOD, fails="1 + 1\n")
NO_EMPTY = Clause("no_empty_bodies", "give every function a real body",
                  _no_empty_bodies, passes=_GOOD, fails="def hold(n):\n    pass\n")
NO_PLACEHOLDERS = Clause("no_placeholders", "leave no placeholder text",
                         _no_placeholders, passes=_GOOD,
                         fails="def hold(n):\n    return n  # your code here\n")
NO_TODO = Clause("no_todo_markers", "leave no TODO or FIXME", _no_todo_markers,
                 passes=_GOOD, fails="# TODO: write this\ndef hold(n):\n    return n + 1\n")
NO_UNIMPLEMENTED = Clause("no_not_implemented",
                          "implement it, do not raise NotImplementedError",
                          _no_not_implemented, passes=_GOOD,
                          fails="def hold(n):\n    raise NotImplementedError\n")
NO_STAR = Clause("no_wildcard_imports", "import names explicitly, never *",
                 _no_wildcard_imports, passes=_GOOD, fails="from os import *\n")

# Intention (2026-09-25): A FILE THAT IMPORTS ITSELF CANNOT BE IMPORTED — the
# name it asks for is not defined yet when the import runs. Seen in the
# skill:syntax practice, where it stopped the examples from running at all.
# The check lives in warp2/gate/self_import.py beside the mend that fixes it.
from warp2.gate import self_import as _self_import  # noqa: E402

NOT_ITSELF = Clause("does_not_import_itself", "never import the file you are writing",
                    _self_import.check, passes=_GOOD,
                    fails="from projects.thing.hold import hold\n\n" + _GOOD)

# Intention: the two halves of the old import rule, each said to the kind of
# work it is actually true of. A test has no package; a module may have one.
NO_RELATIVE = Clause(
    "no_relative_imports_in_a_test",
    "import the module by name or by its path from the project root",
    _no_relative_imports, passes=_GOOD,
    fails="from .thing import hold\n\ndef test_it():\n    assert hold(0) == 1\n")
RELATIVE_IN_A_PACKAGE = Clause(
    "relative_imports_need_a_package",
    "use a relative import only inside a package, otherwise import by name",
    _relative_only_in_a_package, passes=_GOOD,
    fails="from .neighbour import thing\n\ndef hold(n):\n    return thing(n)\n")
NO_IMPORT_EFFECTS = Clause("no_import_time_effects",
                           "do work when called, not when imported",
                           _no_import_time_effects, passes=_GOOD,
                           fails="def hold(n):\n    return n\nhold(3)\n")
DOES_SOMETHING = Clause("returns_more_than_input",
                        "return a result, not the argument you were given",
                        _returns_more_than_input, passes=_GOOD,
                        fails="def hold(number):\n    return number\n")
USES_PARAMETERS = Clause("uses_every_parameter", "use every parameter you declare",
                         _uses_every_parameter, passes=_GOOD,
                         fails="def hold(number, context):\n    return number + 1\n")
_HEADER_EXAMPLE = ("# WARP2/projects/thing/hold.py\n#\n"
                   "#  Pathway   : WARP2/projects/thing/hold.py\n"
                   "#  Used by   : projects/thing/run.py.\n"
                   "#  Uses      : nothing.\n"
                   "#  Description: holds a number at one or above.\n"
                   "#  User intention: Andrew asked for a floor on the count.\n")
CARRIES_ITS_HEADER = Clause(
    "carries_its_header",
    "open with the header: pathway, used by, uses, description, intention",
    _carries_its_header,
    passes=_HEADER_EXAMPLE + _GOOD,
    fails="# Pathway   : projects/thing/hold.py\n"
          "# Used by   : projects/thing/run.py.\n"
          "# Uses      : nothing.\n"
          "# Description: holds a number at one or above.\n"
          "# User intention: Andrew asked for a floor on the count.\n" + _GOOD,
    speak=_header_line)

# Intention (2026-10-09, fix 7.2): every part the gate lets in says what it is
# for, by the same check the tree keeps.
EVERY_PART_HAS_A_NOTE = Clause(
    "every_part_has_a_note",
    "give every function and class an intention note",
    _every_part_has_a_note,
    passes='def hold(number):\n    """Intention: never let the count go under one."""\n'
           "    return max(1, number)\n",
    fails=_GOOD)

# Intention: the clause SPEAKS its specifics. These three are the ones whose
# complaint can name a concrete thing, and all three cost WARP dearly for not
# naming it in the line the work was shown.
IMPORTS_ARTIFACT = Clause(
    "imports_artifact", "import the artifact module", _imports_the_artifact,
    passes="import shrink\n\ndef test_it():\n    assert shrink.hold(0) == 1\n",
    fails="def test_it():\n    assert 1 == 1\n",
    # Intention: THE LINE AND THE CHECK MUST AGREE EVEN WHEN THERE IS NOTHING
    # TO NAME. Falling back to the bare intention here told a model to "import
    # the artifact module" with no module in the world to import, and then
    # refused it for not importing one — the exact shape of the failure this
    # file exists to prevent, and the one that produced `from artifact import
    # Artifact` sixty times running. When nothing is named the line says that,
    # so the work is told the truth about its own unit instead of an
    # instruction nobody can follow.
    speak=lambda ctx: (f"import the artifact module {ctx['artifact_module']}"
                       if ctx.get("artifact_module")
                       else "no artifact is named for this work — say so, write nothing"),
    # Intention: NO WORK COULD HAVE ANSWERED THIS ONE. When nothing is named,
    # the refusal is aimed at whoever raised the unit, and the scoreboard must
    # not read it as the clause being unsatisfiable. Sourcing stopped raising
    # such units on 2026-08-31 and the loop stopped working the ones already in
    # the queue on 2026-09-04 — and this clause still read as a live defect in
    # the gate months later, because seven old refusals nobody could fix were
    # counted as seven refusals nobody DID fix.
    about_the_unit=("no artifact was named for this work",))
KEEPS_REQUIRED_NAMES = Clause(
    "keeps_required_names", "keep every name the paired test imports",
    _keeps_required_names, passes=_GOOD, fails="def other(n):\n    return n + 1\n",
    speak=lambda ctx: ("keep every name the paired test imports, which are "
                       "exactly: " + ", ".join(sorted(str(n) for n in ctx["required_names"]))
                       if ctx.get("required_names") else ""))
NAMES_THE_INTENTION = Clause(
    "names_the_intention", "state the intention being proved",
    _names_what_it_proves,
    passes="def test_shrink_guard_holds():\n    assert True is True\n",
    fails="def test_it():\n    assert 1 == 1\n",
    # Quoted, and deliberately not cut to the clause cap: this is the one line
    # carrying a fact rather than a rule, and half a sentence is worse than none.
    speak=lambda ctx: (f'state the intention being proved: '
                       f'"{" ".join(str(ctx["proves_intention"]).split())}"'
                       if ctx.get("proves_intention") else ""))
REALIZES_INTENTION = Clause(
    "realizes_the_intention", "write the thing the intention describes",
    _realizes_its_intention, passes=_GOOD, fails="import hashlib\n\ndef me():\n    return hashlib\n",
    speak=lambda ctx: (f'write the thing this describes: '
                       f'"{" ".join(str(ctx["proves_intention"]).split())}"'
                       if ctx.get("proves_intention") else ""))
NOT_A_COPY = Clause(
    "not_a_copy_of_another_part", "write this part, not a copy of another one",
    _not_a_copy_of_another_part,
    passes="def refeed(data):\n    return dict(data)\n",
    fails="def hold(number):\n    return max(1, number)\n",
    speak=lambda ctx: ("write the part this intention asks for — this project "
                       "already has other parts and each one does a different "
                       "job, so do not return the same file as one of them"
                       if ctx.get("other_artifacts") else ""))
CHANGES_SOMETHING = Clause(
    "changes_something", "change something; this was already refused",
    _changes_something,
    passes="def hold(number):\n    return max(2, number)\n", fails=_GOOD)
KEEPS_ITS_CONTRACT = Clause(
    "keeps_its_contract", "keep every public name the file already had",
    _keeps_its_contract,
    passes="def hold(number):\n    return max(1, number)\n\ndef release(n):\n    return n\n",
    fails="def release(n):\n    return n\n",
    speak=lambda ctx: ("keep every public name the file already had, which are "
                       "exactly: " + ", ".join(sorted(_public_names(str(ctx["previous"])) or ()))
                       if ctx.get("previous") else ""))
HAS_TESTS = Clause("has_tests", "define at least one test_ function",
                   _has_test_functions,
                   passes="def test_it():\n    assert 2 == 2\n",
                   fails="def check():\n    assert 2 == 2\n")
ASSERTS_BEHAVIOUR = Clause(
    "asserts_behaviour", "assert what the artifact returns, not that it exists",
    _asserts_behaviour,
    passes="def test_it():\n    assert hold(0) == 1\n",
    fails="def test_it():\n    assert True\n")
NAMES_COME_FROM_SOMEWHERE = Clause(
    "names_come_from_somewhere", "use only names you import or define",
    _names_come_from_somewhere,
    passes="import shrink\n\ndef test_it():\n    assert shrink.hold(0) == 1\n",
    fails="def test_it():\n    assert Artifact().get_result() == 1\n")

# Intention: THE CODE HAS TO WORK, NOT ONLY LOOK RIGHT (Andrew, 2026-09-24:
# "is their output not slop?"). Three files the gate accepted that day could
# not run: castle_adventure.py stored `self.score` over its own `score()`,
# multiscale_asset_representation.py read values nothing set and called
# `bpy.data.asset_levels`, which does not exist, and artifact_contracts.py
# said "Replace this with your actual implementation". Each of these four
# clauses refuses one of them.
def _no_shadowed_methods(code: str, _ctx: dict) -> str:
    """A value stored on self under a method's own name hides the method."""
    from warp2.gate.self_reads import shadowed_methods
    tree = _tree(code)
    hits = shadowed_methods(tree) if tree is not None else []
    if not hits:
        return ""
    cls, name = hits[0]
    return (f"{cls} stores self.{name} over its own method {name}(), so calling "
            f"{name}() will crash; keep the value under another name")


def _sets_what_it_reads(code: str, _ctx: dict) -> str:
    """A self.x that is read and never set crashes on its first read."""
    from warp2.gate.self_reads import read_never_set
    tree = _tree(code)
    hits = read_never_set(tree) if tree is not None else []
    if not hits:
        return ""
    return ("reads values nothing ever sets: "
            + ", ".join(f"{cls}.{name}" for cls, name in hits[:4])
            + "; set each one (in __init__ or where it is made) before it is read")


def _no_placeholder_notes(code: str, _ctx: dict) -> str:
    """A note saying the real work is not done, however it is worded."""
    from warp2.gate.placeholder_notes import found
    said = found(code)
    return f"a note says the work is not really done: {said!r}; do the real work" if said else ""


def _its_calls_exist(code: str, _ctx: dict) -> str:
    """Every module.name the code calls is looked up for real."""
    from warp2.gate.calls_exist import missing
    gone = missing(code)
    if not gone:
        return ""
    return ("calls things that do not exist: " + ", ".join(gone[:4])
            + "; use only what the module really has")


NO_SHADOWED_METHODS = Clause(
    "no_shadowed_methods", "never store a value under the name of one of your methods",
    _no_shadowed_methods,
    passes="class Game:\n    def __init__(self):\n        self.points = 0.0\n\n"
           "    def score(self):\n        return self.points\n",
    fails="class Game:\n    def __init__(self):\n        self.score = 0.0\n\n"
          "    def score(self):\n        return self.score\n")
SETS_WHAT_IT_READS = Clause(
    "sets_what_it_reads", "set every value on self before you read it",
    _sets_what_it_reads,
    passes="class Hold:\n    def __init__(self, n):\n        self.n = n\n\n"
           "    def get(self):\n        return max(1, self.n)\n",
    fails="class Hold:\n    def __init__(self, n):\n        self.n = n\n\n"
          "    def get(self):\n        return max(1, self.m)\n")
NO_PLACEHOLDER_NOTES = Clause(
    "no_placeholder_notes", "do the real work; leave no note saying it is not done",
    _no_placeholder_notes, passes=_GOOD,
    fails="def hold(n):\n    # Replace this with your actual implementation\n    return n + 1\n")
ITS_CALLS_EXIST = Clause(
    "its_calls_exist", "call only what a module really has",
    _its_calls_exist,
    passes="import os\n\ndef hold(n):\n    return os.path.join(str(n), 'x')\n",
    fails="import os\n\ndef hold(n):\n    return os.pathx.join(str(n), 'x')\n")

# The contexts the example pairs are judged under. A clause that only decides
# when it is given something has to be given it here too, or its own example
# would prove nothing.
EXAMPLE_CONTEXT = {
    "imports_artifact": {"artifact_module": "shrink"},
    # Intention: the header clause decides only about a file, so its examples
    # are judged as one (#126).
    "carries_its_header": {"target": "projects/thing/hold.py"},
    "every_part_has_a_note": {"target": "projects/thing/hold.py"},
    "does_not_import_itself": {"write_path": "projects/thing/hold.py"},
    "keeps_required_names": {"required_names": ("hold",)},
    "names_the_intention": {"proves_intention": "the shrink guard holds at one"},
    "realizes_the_intention": {"proves_intention": "hold the number at one"},
    "changes_something": {"previous": _GOOD},
    "keeps_its_contract": {"previous": _GOOD},
    # The example that must be refused IS the twin, so the map holds its digest.
    "not_a_copy_of_another_part": {
        "other_artifacts": {
            sha256_hex(b"def hold(number):\n    return max(1, number)\n"):
                "projects/example/other_part.py"}},
}
