# WARP2/warp2/gate/guard.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/guard.py
#  Used by   : the loop, which builds one and hands it to the pathway as the
#              single guard the door consults.
#  Uses      : warp2/gate/contracts.py, warp2/gate/scoreboard.py,
#              warp2/gate/grandfather.py (a change is judged on what it
#              changes), warp2/record/pathway.py (for Refusal alone).
#  Description:
#    The gate as the pathway sees it: one callable, given the action about to
#    happen, which either says nothing or refuses with every unmet obligation.
#  User intention (Andrew):
#    NO DAEMONS. There is one door and one place a gate can be plugged into, so
#    it can never be half-applied — and the refusal is a recorded outcome, not
#    a crash: "WARP's most useful hour was eight refusals in a row."
# ============================================================================
from __future__ import annotations

import fnmatch

from warp2.gate.contracts import contract_for
from warp2.gate.scoreboard import Scoreboard
from warp2.record.pathway import Refusal


class Gate:
    """The one guard. Judges any action that carries content or writes a path.

    Intention: most actions are not artifact-producing and this must not have
    an opinion about them — a gate that judges everything is a gate nobody can
    reason about. What makes an action judgeable is that it carries the thing
    it is about to write. Everything else passes through untouched, and that is
    a decision stated here rather than an accident of what the checks happen to
    understand.
    """

    def __init__(self, store=None, scoreboard: Scoreboard | None = None) -> None:
        """Intention: set up the store (a throwaway one if none is given), the scoreboard, and the
        judged and refused counts.
        """
        if store is None:
            import tempfile
            from warp2.store.store import Store
            store = Store(tempfile.mkdtemp(prefix="warp2_gate_"))
        self.store = store
        self.scoreboard = scoreboard or Scoreboard(store)
        self.judged = 0
        self.refused = 0

    def __call__(self, action: dict) -> None:
        """Intention: let the gate be plugged in as a guard: judge the action and raise Refusal when it
        decided against it.
        """
        verdict = self.judge(action)
        if verdict["decided"] and not verdict["accepted"]:
            raise Refusal(verdict["said"])

    def judge(self, action: dict) -> dict:
        """Decide about one action, and record what was decided.

        Intention: the verdict says whether it DECIDED, separately from whether
        it accepted. "Nothing to judge" and "this is fine" are different
        answers, and a gate that returns the same value for both cannot be
        audited — the count of things it let through would include everything
        it never looked at.
        """
        content = action.get("content")
        kind = str(action.get("work_kind") or action.get("kind") or "")
        if content is None:
            return self._path_only(action, kind)

        contract = contract_for(kind)
        if contract is None:
            # Intention: an artifact was about to be written under a kind of
            # work nobody has said anything about. Refusing is the answer; a
            # permissive default is how a new call site quietly acquires a
            # capability nobody granted it.
            return {"decided": True, "accepted": False, "kind": kind,
                    "issues": [f"no contract for work of kind {kind!r}"],
                    "watched": [], "said": f"no contract for work of kind {kind!r}"}

        text = content if isinstance(content, str) else str(content)
        context = dict(action.get("context") or {})
        # Intention: THE PATH BEING WRITTEN, for a clause that is about the
        # file itself (does_not_import_itself). A unit's own target is not
        # always the path — practice is aimed at a skill.
        context.setdefault("write_path", str(action.get("target") or ""))
        # Intention: ONE PASS OVER THE CLAUSES, and the name kept beside what
        # it said. This was two passes that each re-ran every check on the same
        # bytes, and neither could tell the scoreboard WHICH complaint a name
        # raised — so a refusal aimed at whoever raised the unit was counted
        # against the clause that was right to raise it.
        said = contract.complaints(text, context)
        # Intention: GRANDFATHERED (Andrew, 2026-09-23). A rule the file on
        # disk already broke is not this change's fault; it is let through
        # here and paid as its own work (warp2/gate/owed.py). Only a change to
        # a file that exists has anything to inherit.
        grandfathered = []
        if context.get("previous"):
            from warp2.gate.grandfather import inherited, split
            said, grandfathered = split(said, inherited(contract, context["previous"], context),
                                        owed=context.get("owed") or ())
        by_name = {clause.name: clause for clause in contract.clauses}
        issues = [complaint for _name, complaint in said if complaint]
        judged_names = [name for name, _complaint in said]
        failed_names = [name for name, complaint in said if complaint]
        blocked_names = [name for name, complaint in said
                         if complaint and by_name[name].blames_the_unit(complaint)]
        self.scoreboard.record(kind, str(action.get("target") or ""),
                               judged_names, failed_names, blocked=blocked_names)

        # Intention: the watches run on EVERY judgement, accepted or refused,
        # and their findings never join `issues`. A watch has no power to stop
        # anything; what it produces is evidence about the clause set.
        watched = contract.notes_from_watches(text, context)
        for note in watched:
            self.scoreboard.watched(note["watch"], str(action.get("target") or ""),
                                    note["saw"])

        where = self._writes_allowed(action, contract)
        if where:
            issues = list(issues) + [where]

        self.judged += 1
        if issues:
            self.refused += 1
        return {"decided": True, "accepted": not issues, "kind": kind,
                "issues": list(issues), "watched": watched,
                "grandfathered": grandfathered,
                "said": self._say(kind, issues)}

    # Intention: an action with no content may still be writing somewhere it
    # was never allowed to write, and that is decidable without reading a byte.
    def _path_only(self, action: dict, kind: str) -> dict:
        contract = contract_for(kind)
        if contract is None or not contract.may_write:
            return {"decided": False, "accepted": True, "kind": kind,
                    "issues": [], "watched": [], "said": ""}
        where = self._writes_allowed(action, contract)
        if not where:
            return {"decided": False, "accepted": True, "kind": kind,
                    "issues": [], "watched": [], "said": ""}
        self.judged += 1
        self.refused += 1
        return {"decided": True, "accepted": False, "kind": kind,
                "issues": [where], "watched": [], "said": self._say(kind, [where])}

    # Intention: "restricted to a smaller set", mechanically. A path outside
    # the contract's homes is refused by pattern, and the pattern is part of
    # the contract a person can read.
    #
    # IT READS `writes`, NOT `produced`, AND THE DIFFERENCE IS NOT COSMETIC.
    # `produced` is lineage — the things in the RECORD this action brought
    # about, which is what the causal slice walks, and most of them are
    # subjects rather than files. `writes` is the filesystem. Reading one as
    # the other refused the loop's own work for writing to `pkg/thing.py::hold`,
    # which is not a path and was never going to be one.
    def _writes_allowed(self, action: dict, contract) -> str:
        if not contract.may_write:
            return ""
        paths = [str(p) for p in (action.get("writes") or ())]
        for path in paths:
            if not any(fnmatch.fnmatch(path, pattern) for pattern in contract.may_write):
                return (f"{contract.kind} may write only "
                        f"{', '.join(contract.may_write)} — not {path}")
        return ""

    # Intention: the refusal names the kind and every unmet obligation, in
    # declaration order, on its own line. One complaint per line so the next
    # attempt can be about all of them rather than the first one.
    @staticmethod
    def _say(kind: str, issues) -> str:
        if not issues:
            return ""
        head = f"{kind or 'this'} was refused for {len(issues)} unmet obligation"
        head += "" if len(issues) == 1 else "s"
        return head + ":\n" + "\n".join(f"- {issue}" for issue in issues)

    def permits(self, kind: str, relative: str) -> str:
        """Where this kind of work may write, as one question with one answer.

        Intention: handed to the write gateway rather than imported by it. The
        record must not depend on the thing that judges the work — if it did, a
        change to the gate could stop the record, which is exactly backwards.
        """
        contract = contract_for(kind)
        if contract is None or not contract.may_write:
            return ""
        return self._writes_allowed({"writes": (relative,)}, contract)

    def health(self) -> dict:
        """Every clause's standing, and the ones that are a defect in the gate."""
        names = sorted({clause.name
                        for contract in _all_contracts()
                        for clause in contract.clauses})
        report = self.scoreboard.health(names)
        report["judged"] = self.judged
        report["refused"] = self.refused
        report["accepted"] = self.judged - self.refused
        return report


# Intention: read from the contracts rather than kept as a second list. Two
# lists of clause names is one list and a lie waiting to happen.
def _all_contracts():
    from warp2.gate.contracts import CONTRACTS
    return tuple({id(c): c for c in CONTRACTS.values()}.values())
