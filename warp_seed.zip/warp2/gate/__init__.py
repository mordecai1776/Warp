# WARP2/warp2/gate/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/__init__.py
#  Used by   : the loop, which plugs a gate into the pathway's one guard hook;
#              the test suite.
#  Uses      : nothing at import time, by design.
#  Description:
#    The gate. What a kind of work is allowed to be, stated in the same object
#    that decides whether it was — plus the gate's own scoreboard, because a
#    standard nobody measures is indistinguishable from a stop.
#  User intention (Andrew, 2026-08-17):
#    "every action type needs its own safegaurds and have its avaialble actions
#    restricted to a smaller set... what the model sees is a lign of pure
#    intention without the gruff of lauange. The pure intention can be tested."
# ============================================================================
