# WARP2/warp2/gate/slop_detector.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/slop_detector.py
#  Used by   : warp2/run.py
#  Uses      : warp2/record/quiet.py (no console window, 2026-10-08),
#               ast, pathlib, subprocess, sys
#  Description:
#    Automated Slop Detector: finds broken files, fake stubs, truncated
#    functions, broken test collections, and failing tests across all
#    projects. Explains everything in simple, clear words.
#  User intention:
#    Not written down in this file yet; noted to ask Andrew (2026-09-18).
# ============================================================================
from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
import subprocess
import sys
from warp2.record.quiet import quiet


# Intention: one finding — which file, which line, what kind of slop, and why
# — so the report can say each thing in plain words.
@dataclass
class SlopItem:
    file_path: str
    line_number: int
    category: str
    reason: str

    def __str__(self) -> str:
        """Intention: one finding as one readable line: [category] file:line - reason."""
        loc = f"{self.file_path}:{self.line_number}" if self.line_number > 0 else self.file_path
        return f"[{self.category}] {loc} - {self.reason}"


class SlopDetector:
    """Audits codebases for low-quality or broken artifacts ('slop')."""

    def __init__(self, root: Path) -> None:
        """Intention: keep the root that file paths are reported against, and the list of findings so far."""
        self.root = Path(root).resolve()
        self.findings: list[SlopItem] = []

    def check_file_syntax_and_truncation(self, path: Path) -> None:
        """Intention: check one python file for read errors, syntax errors, a cut-off end and empty
        stubs, adding findings.
        """
        rel = str(path.resolve().relative_to(self.root))
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            self.findings.append(SlopItem(rel, 0, "UNREADABLE", f"Could not read file: {exc}"))
            return

        # 1. Syntax check
        try:
            tree = ast.parse(content, filename=str(path))
        except SyntaxError as exc:
            self.findings.append(
                SlopItem(rel, exc.lineno or 0, "SYNTAX_ERROR", f"Syntax error: {exc.msg}")
            )
            return

        # 2. Truncation check
        lines = content.splitlines()
        if lines:
            last_line = lines[-1].strip()
            # Check if file ends with an unfinished sentence comment or dangling tokens
            if last_line.startswith("#") and any(
                last_line.endswith(suffix)
                for suffix in ("to check", "to be", "that", "and", "the", "a", "an", "is", "in", "with")
            ):
                self.findings.append(
                    SlopItem(
                        rel,
                        len(lines),
                        "TRUNCATED_FILE",
                        f"File appears truncated at line {len(lines)}: '{last_line}'",
                    )
                )

        # 3. Empty stub check (functions that are only 'pass', '...', or 'raise NotImplementedError')
        protocol_methods = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.ClassDef):
                is_proto = any(
                    (isinstance(base, ast.Name) and base.id in ("Protocol", "ABC"))
                    or (isinstance(base, ast.Attribute) and base.attr in ("Protocol", "ABC"))
                    for base in n.bases
                )
                if is_proto:
                    for item in n.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            protocol_methods.add(item)

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                # Ignore test files, abstract methods, and protocol stubs
                if "tests" in rel or path.name.startswith("test_") or node in protocol_methods:
                    continue
                # Check decorators for @abstractmethod
                is_abstract = any(
                    (isinstance(d, ast.Name) and d.id == "abstractmethod")
                    or (isinstance(d, ast.Attribute) and d.attr == "abstractmethod")
                    for d in node.decorator_list
                )
                if is_abstract:
                    continue

                body = node.body
                # Filter out docstrings
                real_stmts = [
                    stmt for stmt in body
                    if not (isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant) and isinstance(stmt.value.value, str))
                ]
                if len(real_stmts) == 1:
                    first = real_stmts[0]
                    if isinstance(first, ast.Pass):
                        self.findings.append(
                            SlopItem(
                                rel,
                                node.lineno,
                                "EMPTY_STUB",
                                f"Function '{node.name}' has no real logic (only 'pass')",
                            )
                        )
                    elif isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and first.value.value is Ellipsis:
                        self.findings.append(
                            SlopItem(
                                rel,
                                node.lineno,
                                "EMPTY_STUB",
                                f"Function '{node.name}' has no real logic (only '...')",
                            )
                        )
                    elif isinstance(first, ast.Raise) and isinstance(first.exc, ast.Call):
                        if isinstance(first.exc.func, ast.Name) and first.exc.func.id == "NotImplementedError":
                            self.findings.append(
                                SlopItem(
                                    rel,
                                    node.lineno,
                                    "EMPTY_STUB",
                                    f"Function '{node.name}' raises NotImplementedError",
                                )
                            )

    def audit_all_python_files(self, dirs: list[Path]) -> int:
        """Intention: check every python file under the given folders (skipping retired, cache and
        venv) and return how many.
        """
        count = 0
        for d in dirs:
            if not d.exists():
                continue
            for p in d.rglob("*.py"):
                if "_retired" in str(p) or "__pycache__" in str(p) or ".venv" in str(p):
                    continue
                self.check_file_syntax_and_truncation(p)
                count += 1
        return count

    def audit_test_collections(self, test_dirs: list[Path]) -> None:
        """Runs pytest --collect-only to catch broken imports across all test suites."""
        for td in test_dirs:
            if not td.exists():
                continue
            rel = str(td.resolve().relative_to(self.root))
            cmd = [sys.executable, "-m", "pytest", "--collect-only", "-q", str(td)]
            try:
                proc = subprocess.run(cmd, cwd=str(self.root), capture_output=True, text=True, timeout=60, **quiet())
            except subprocess.TimeoutExpired:
                self.findings.append(SlopItem(rel, 0, "BROKEN_TEST_COLLECTION", "Pytest collection timed out after 60s"))
                continue
            if proc.returncode != 0:
                err_lines = [
                    l for l in proc.stdout.splitlines() + proc.stderr.splitlines()
                    if "ERROR" in l or "ImportError" in l or "ModuleNotFoundError" in l
                ]
                summary = "; ".join(err_lines[:3]) if err_lines else "Test collection failed"
                self.findings.append(
                    SlopItem(rel, 0, "BROKEN_TEST_COLLECTION", summary)
                )

    def audit_test_runs(self, test_dirs: list[Path]) -> None:
        """Runs pytest to catch broken tests in active projects."""
        for td in test_dirs:
            if not td.exists():
                continue
            rel = str(td.resolve().relative_to(self.root))
            cmd = [sys.executable, "-m", "pytest", "-q", "--tb=line", str(td)]
            try:
                proc = subprocess.run(cmd, cwd=str(self.root), capture_output=True, text=True, timeout=300, **quiet())
            except subprocess.TimeoutExpired:
                self.findings.append(SlopItem(rel, 0, "TEST_FAILURE", "Test run timed out after 300s"))
                continue
            if proc.returncode != 0:
                failed = [l for l in proc.stdout.splitlines() if "FAILED" in l or "ERROR" in l]
                summary = f"{len(failed)} failure(s): " + ("; ".join(failed[:3])) if failed else "Tests failed"
                self.findings.append(
                    SlopItem(rel, 0, "TEST_FAILURE", summary)
                )


def run_slop_check(root_dir: Path | str = ".", target_projects: list[str] | None = None) -> int:
    """Audits the repo and prints a simple report. Returns 0 if clean, 1 if slop found."""
    root = Path(root_dir).resolve()
    detector = SlopDetector(root)

    print("==================================================", flush=True)
    print("           WARP2 SLOP DETECTOR AUDIT             ", flush=True)
    print("==================================================", flush=True)

    project_names = target_projects or [
        "master",
        "behemoth_eye",
        "centering_image",
        "single_point_of_truth",
        "game_builder",
        "game_player",
    ]
    code_dirs = [root / "projects" / name for name in project_names]
    test_dirs = []
    for name in project_names:
        p_dir = root / "projects" / name
        if (p_dir / "tests").exists():
            test_dirs.append(p_dir / "tests")

    # 1. Check syntax, truncation, and empty stubs
    print("[1/3] Checking file syntax, truncation, and empty stubs...", flush=True)
    file_count = detector.audit_all_python_files(code_dirs)
    print(f"      Scanned {file_count} python files.", flush=True)

    # 2. Check test collection (broken imports)
    print("[2/3] Checking test imports and test collection...", flush=True)
    detector.audit_test_collections(test_dirs)

    # 3. Check test run results
    print("[3/3] Checking test execution...", flush=True)
    detector.audit_test_runs(test_dirs)

    print("\n---------------- AUDIT RESULTS -------------------", flush=True)
    if not detector.findings:
        print("RESULT: CLEAN! No slop detected.", flush=True)
        print(f"Scanned {file_count} files across {len(project_names)} projects with 0 errors.", flush=True)
        print("==================================================", flush=True)
        return 0

    print(f"RESULT: SLOP FOUND! {len(detector.findings)} issue(s) detected:\n", flush=True)
    for idx, item in enumerate(detector.findings, 1):
        print(f"  {idx}. {item}", flush=True)

    print("==================================================", flush=True)
    return 1


if __name__ == "__main__":
    sys.exit(run_slop_check())
