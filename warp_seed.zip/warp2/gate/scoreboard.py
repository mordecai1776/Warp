# WARP2/warp2/gate/scoreboard.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/scoreboard.py
#  Used by   : warp2/gate/guard.py, which records every judgement it makes;
#              the loop, which reads the health report each pass.
#  Uses      : warp2/store/store.py (a clause's standing is a fact like any
#              other), warp2/settings.py.
#  Description:
#    The gate's own scoreboard. Per clause: how often it complained, how often
#    the next attempt fixed it, and whether anything has ever passed or ever
#    failed it.
#  User intention (Andrew):
#    "we need to see what is working and what does not." That has to include
#    the thing doing the judging. WARP's acceptance rate fell from 42% to 6%
#    as clauses were added and nothing in it could tell whether that meant the
#    standard had risen or the work had stopped.
# ============================================================================
from __future__ import annotations

from warp2.settings import number
from warp2.util import now_iso

# How many complaints a clause may raise without one of them ever being fixed
# before it is called out. Small on purpose: the cost of a clause nothing can
# satisfy is every attempt it refuses, and that cost is paid per attempt.
UNREPAIRED_BEFORE_DOUBT = number("WARP2_GATE_UNREPAIRED_BEFORE_DOUBT", 5, minimum=1)

# How many judgements a clause may sit through without ever complaining before
# it is called out as possibly inert.
QUIET_BEFORE_DOUBT = number("WARP2_GATE_QUIET_BEFORE_DOUBT", 50, minimum=1)


class Scoreboard:
    """What the gate has done, kept where everything else is kept.

    Intention: a clause's standing is a fact about a subject, temporal like
    every other fact, so "when did this clause stop being satisfiable" is a
    question the store answers rather than something a person remembers.
    """

    def __init__(self, store) -> None:
        """Intention: keep the store the gate's standing is written to, and the last complaints per target."""
        self.store = store
        # Intention: the last complaint set per target, held for the life of
        # the run. Repair is "the same target's next attempt did not raise it",
        # and that comparison needs one step of memory and nothing more.
        self._last: dict = {}

    # -- writing -------------------------------------------------------------

    def record(self, kind: str, target: str, judged: list, failed: list,
               blocked: list = ()) -> dict:
        """Fold one judgement into every clause that took part in it.

        Intention: BOTH SIDES ARE RECORDED. A clause that complained is a
        clause that fired; a clause that was consulted and said nothing is a
        clause that passed. Counting only the complaints is how a set of rules
        ends up with a member nothing has ever satisfied and nobody notices.
        """
        failed_names = set(failed)
        # Intention: A REFUSAL NO WORK COULD HAVE ANSWERED IS NOT THE CLAUSE
        # FIRING. It is the unit being wrong, and counting it as a firing is
        # what made the gate report a defect in itself that lived in sourcing.
        # It is still counted — in its own column, because a clause that keeps
        # blocking units is telling you something, just not about the work.
        blocked_names = set(blocked) & failed_names
        previous = self._last.get(str(target), set())
        report = {"kind": kind, "target": target, "fired": [], "repaired": [],
                  "blocked": sorted(blocked_names)}
        for name in judged:
            if name in blocked_names:
                self._bump(name, "blocked")
            elif name in failed_names:
                self._bump(name, "fired")
                report["fired"].append(name)
            else:
                self._bump(name, "passed")
                if name in previous:
                    self._bump(name, "repaired")
                    report["repaired"].append(name)
        # Intention: a blocked complaint is not carried into the repair
        # comparison either. "The next attempt stopped raising it" would other-
        # wise credit a repair to whoever fixed the QUEUE, not the work.
        self._last[str(target)] = failed_names - blocked_names
        return report

    def watched(self, name: str, target: str, saw: str) -> None:
        """Intention: record that a watch saw something on a target, counted against the watch, not the work."""
        # Intention: a watch firing is recorded against the WATCH, not against
        # the work — the work did nothing wrong by any rule it was shown. What
        # it is evidence about is the gate.
        subject = name if str(name).startswith("watch:") else f"watch:{name}"
        self._bump(subject, "seen")
        self.store.assert_fact(subject, "has", attr="last_seen_on", value=str(target))
        self.store.assert_fact(subject, "has", attr="last_saw", value=str(saw))

    # Intention: one place a count moves, so a new counter is one line and can
    # never be incremented two different ways in two different callers.
    def _bump(self, name: str, counter: str) -> int:
        subject = f"clause:{name}" if not name.startswith(("clause:", "watch:")) else name
        if subject.startswith("clause:"):
            self.store.assert_fact(subject, "has", attr="kind", value="clause")
        current = self.count(name, counter) + 1
        self.store.assert_fact(subject, "has", attr=counter, value=str(current))
        return current

    # -- reading -------------------------------------------------------------

    def count(self, name: str, counter: str) -> int:
        """Intention: read one counter (fired, passed, repaired, blocked, seen) for a clause or watch; 0 when none."""
        subject = f"clause:{name}" if not name.startswith(("clause:", "watch:")) else name
        facts = self.store.current(subject=subject, attr=counter)
        try:
            return int(facts[0]["value"]) if facts else 0
        except (TypeError, ValueError):
            return 0

    def standing(self, name: str) -> dict:
        """Intention: one clause's counts in one dict, with how often a complaint got repaired on the next try."""
        fired = self.count(name, "fired")
        passed = self.count(name, "passed")
        repaired = self.count(name, "repaired")
        blocked = self.count(name, "blocked")
        return {
            "clause": name, "fired": fired, "passed": passed, "repaired": repaired,
            "blocked": blocked, "counted_from": self._said(name, "counted_from"),
            "judged": fired + passed,
            # The honest measure of whether a complaint was ACTIONABLE: did the
            # next attempt on the same thing stop raising it.
            "repair_rate": round(repaired / fired, 3) if fired else None,
        }

    def _said(self, name: str, attr: str) -> str:
        """Intention: read a clause's text value (like counted_from) from the store; "" when none."""
        # Intention: the one reader for a clause's non-numeric standing, so a
        # subject prefix is decided in one place like the counts are.
        subject = f"clause:{name}" if not name.startswith(("clause:", "watch:")) else name
        facts = self.store.current(subject=subject, attr=attr)
        return str(facts[0]["value"]) if facts else ""

    def recount(self, names, why: str) -> dict:
        """Start a clause's counters again, saying from when and why.

        Intention: A COUNT TAKEN UNDER AN OLD RULE CANNOT BE SPLIT UNDER A NEW
        ONE. `imports_artifact` held seven firings from before blocked
        complaints were separated, and there is no honest way to say now which
        of them were which — the record does not carry it. So they are not
        guessed at and not quietly kept: they are ended, with the date the new
        count starts from and the reason, and the report says "since" from then
        on. Zeroing a measure is a real act, so it leaves a real trace.
        """
        started = now_iso()
        done = []
        for name in names:
            for counter in ("fired", "passed", "repaired", "blocked"):
                subject = (f"clause:{name}"
                           if not str(name).startswith(("clause:", "watch:")) else name)
                self.store.assert_fact(subject, "has", attr=counter, value="0")
            subject = (f"clause:{name}"
                       if not str(name).startswith(("clause:", "watch:")) else name)
            self.store.assert_fact(subject, "has", attr="counted_from", value=started)
            self.store.assert_fact(subject, "has", attr="recount_reason", value=str(why))
            self._last.pop(str(name), None)
            done.append(str(name))
        return {"recounted": done, "from": started, "why": str(why)}

    def health(self, names) -> dict:
        """Which clauses are doing their job, and which are a defect in the gate.

        Intention: TWO WAYS A CLAUSE IS BROKEN, AND BOTH ARE ABOUT THE GATE.
        A clause nothing ever passes is a stop, not a standard — WARP found one
        of those by hand after nine consecutive generations were refused and
        none could have passed, and nothing would have found the second. A
        clause nothing ever fails is a line in a prompt doing no work; four of
        WARP's fired eight times or fewer in 752 judgements.
        """
        report = {"clauses": [], "unpassable": [], "inert": [], "unactionable": [],
                  "blocking": []}
        for name in names:
            standing = self.standing(name)
            report["clauses"].append(standing)
            if standing["fired"] and not standing["passed"]:
                report["unpassable"].append(name)
            if standing["judged"] >= int(QUIET_BEFORE_DOUBT) and not standing["fired"]:
                report["inert"].append(name)
            if (standing["fired"] >= int(UNREPAIRED_BEFORE_DOUBT)
                    and not standing["repaired"]):
                report["unactionable"].append(name)
            # Intention: SAID, BUT AS WHAT IT IS. A clause that keeps refusing
            # units no work could answer is reporting a defect in SOURCING, and
            # burying that under "the gate is fine" would lose the only signal
            # anything has that bad units are still being raised.
            if standing["blocked"] >= int(UNREPAIRED_BEFORE_DOUBT):
                report["blocking"].append(name)
        return report
