# WARP2/warp2/gate/header_mend.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/header_mend.py
#  Used by   : warp2/gate/mend.py (Mend — tried after the other menders, when
#              the refusal names a missing header and the loop handed in the
#              unit's stated intention).
#  Uses      : stdlib ast, pathlib.
#  Description:
#    Writes the header this tree requires onto a refused file, from facts
#    only: the path, the file's own imports, the files in its project that
#    import it, its own docstring, and the intention the work unit was raised
#    with. When the intention is not known it does nothing — it never makes
#    one up.
#  User intention (Andrew):
#    "Each file will also have a header that will have all files that are
#    using said file and what files it uses. As will as a general description
#    of the file and a section for user intention notes ... The pathway of the
#    file should be at the top of every file."
#    2026-09-23: "watch for errors and look for places that can be improved."
#    Measured that morning: 19 of 134 refused writes in a week were refused
#    for the header, and every field of it was already known to the loop.
# ============================================================================
from __future__ import annotations

import ast
from pathlib import Path

MISSING_HEADER = "the file's header is missing"
RULE = "# " + "=" * 76


def _imports(tree: ast.Module) -> list:
    """Intention: the modules this file imports, in the order it imports them."""
    found = []
    for node in tree.body:
        if isinstance(node, ast.Import):
            found += [alias.name for alias in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            found.append(node.module)
    return [name for name in dict.fromkeys(found) if name != "__future__"]


def _as_path(module: str, root: Path) -> str:
    """Intention: a module in the tree is named by its file; anything else by its name."""
    base = root / Path(*module.split("."))
    for candidate in (base.with_suffix(".py"), base / "__init__.py"):
        if candidate.is_file():
            return candidate.relative_to(root).as_posix()
    return module


def _used_by(full: Path, root: Path) -> list:
    """Files in the same project folder that import this one.

    Intention: the project folder only (projects/<name>/ or the file's own
    folder), because that is where a new file's users are and reading the
    whole tree for every mend would cost more than the mend saves.
    """
    rel = full.relative_to(root)
    home = root / Path(*rel.parts[:2]) if rel.parts[0] == "projects" and len(rel.parts) > 2 else full.parent
    stem = full.stem
    users = []
    for other in sorted(home.rglob("*.py")):
        if other == full or "__pycache__" in other.parts:
            continue
        try:
            text = other.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if f"import {stem}" in text or f".{stem} import" in text or f"{stem} import" in text:
            users.append(other.relative_to(root).as_posix())
    return users


def _wrapped(label: str, items: list) -> list:
    """Intention: one header field, one item per line under its label."""
    lines = [f"#  {label:<10}: {items[0]}"]
    lines += [f"#  {'':<10}  {item}" for item in items[1:]]
    return lines


def _paragraph(label: str, text: str) -> list:
    """Intention: a free-text field, wrapped to the tree's width."""
    words, lines, line = str(text).split(), [f"#  {label}:"], "#    "
    for word in words:
        if len(line) + len(word) > 78 and line.strip() != "#":
            lines.append(line.rstrip())
            line = "#    "
        line += word + " "
    if line.strip() != "#":
        lines.append(line.rstrip())
    return lines


def only_the_header(said: str) -> bool:
    """Whether the header is the ONLY thing the gate refused.

    Intention: FOUND BY THE SUITE, 2026-09-23. The header carries the unit's
    intention in words, and the gate's other clause asks whether the file
    mentions what it is for. Mended alongside other refusals, the header
    would answer that clause for code that ignores its intention — words
    standing in for the work. So the header is mended only when nothing
    else is wrong.
    """
    reasons = [line[2:].strip() for line in str(said or "").splitlines() if line.startswith("- ")]
    if not reasons:
        reasons = [str(said or "").strip()]
    return all(reason.startswith(MISSING_HEADER) for reason in reasons if reason)


class HeaderMend:
    """Adds the required header to a file refused for lacking one."""

    def __init__(self, root) -> None:
        """Intention: `root` is WARP2/, which every `# WARP2/...` path is written from."""
        self.root = Path(root)

    def __call__(self, full: Path, content: str, said: str, context: dict | None = None) -> str | None:
        """The file with its header, or None when this refusal is not the header or a fact is missing."""
        if not only_the_header(said):
            return None
        intention = str((context or {}).get("proves_intention") or "").strip()
        if not intention:
            return None
        try:
            tree = ast.parse(content)
            rel = Path(full).resolve().relative_to(self.root.resolve()).as_posix()
        except (SyntaxError, ValueError):
            return None
        doc = (ast.get_docstring(tree) or "").strip().split("\n\n")[0]
        uses = [_as_path(name, self.root) for name in _imports(tree)] or ["nothing; it has no imports"]
        users = _used_by(self.root / rel, self.root) or ["nothing yet; written for its work unit"]
        source = str((context or {}).get("intention_source") or "").strip()
        header = [f"# WARP2/{rel}", "#", RULE, f"#  Pathway   : WARP2/{rel}"]
        header += _wrapped("Used by", users) + _wrapped("Uses", uses)
        header += _paragraph("Description", doc or intention)
        header += _paragraph("User intention", intention + (f" (from: {source})" if source else ""))
        header.append(RULE)
        lines = content.splitlines()
        # Intention: a first line that already names the file is the start of
        # the header a model tried to write, so it is replaced, not doubled.
        # A whole comment block under a `# WARP2/` line is a partial header
        # the gate already judged incomplete, and it goes with that line.
        if lines and lines[0].startswith("# WARP2/"):
            while lines and lines[0].startswith("#"):
                lines = lines[1:]
        elif lines and lines[0].lstrip().startswith("#") and full.name in lines[0]:
            lines = lines[1:]
        return "\n".join(header + lines) + ("\n" if content.endswith("\n") else "")
