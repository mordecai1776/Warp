# WARP2/warp2/gate/candles.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/candles.py
#  Used by   : warp2/work/side/gate_candles.py (GateCandlesStep — weighs the
#              gate once each time its code changes), warp2/gate/tests/
#              test_candles.py.
#  Uses      : warp2/gate/contracts.py (contract_for — the same clauses the gate
#              judges with, called WITHOUT the gate's scoreboard, so weighing
#              the gate never counts as the gate judging), warp2/record/
#              evidence.py (Evidence — the answers the record kept), warp2/gate/
#              mend.py (Mend — the door's own mechanical fixes), the
#              training datasets (state/datasets/<skill>/{train,test}.jsonl);
#              stdlib hashlib, json, pathlib.
#  Description:
#    Standard candles for the gate. Two fixed yardsticks the gate is measured
#    against every time its code changes:
#      * PROVEN GOOD — code a test run proved (the verified training examples).
#        A clause that refuses one of these is refusing work that is known to
#        work: the gate is too tight there.
#      * THE CROWD — every answer the record kept from the models whose
#        weights never change, each with what the gate said then. The answers
#        cannot move, so if the verdicts move the gate moved. Many flips one
#        way is the gate swinging to an extreme.
#  User intention (Andrew, 2026-09-23):
#    "we have to find the sweet spot where it kicks out the bad and lets in the
#    good and forms a knowledge of the different through the crowd that should
#    be given by the models that do not change and all that act like a
#    standard candle ... without that the entire system would just train to
#    one extreme or another. Just make sure that is not the case."
# ============================================================================
from __future__ import annotations

import hashlib
import json
from pathlib import Path

# Intention: the journals the loop writes its actions into. Read, never written.
JOURNALS = "journals"


def gate_print(root) -> str:
    """Which gate this is: a hash of the gate's own code.

    Intention: the yardsticks are measured once per gate. The same code on the
    same fixed answers gives the same verdicts, so measuring it twice teaches
    nothing.
    """
    home = Path(root) / "warp2" / "gate"
    digest = hashlib.sha256()
    for path in sorted(home.glob("*.py")):
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()[:16]


def complaints(kind: str, content: str, context: dict) -> dict:
    """{clause name: complaint} for every clause that complains, judged like the gate.

    Intention: THE SAME CLAUSES, NONE OF THE SIDE EFFECTS. The guard records
    every judgement on its scoreboard; a re-judgement of old answers is not a
    judgement of new work and must not move that standing.
    """
    from warp2.gate.contracts import contract_for
    contract = contract_for(kind)
    if contract is None:
        return {}
    return {name: said for name, said in contract.complaints(str(content), dict(context or {})) if said}


class ProvenGood:
    """Code a real test run proved: the verified training examples."""

    def __init__(self, state_dir) -> None:
        """Intention: keep the state folder the proven training examples are read from."""
        self.state_dir = Path(state_dir)

    def rows(self) -> list:
        """Intention: every verified example in every skill's split, judged as the test it is."""
        out = []
        for path in sorted((self.state_dir / "datasets").glob("*/*.jsonl")):
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except OSError:
                continue
            for line in lines:
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if not (row.get("response") and row.get("test") and row.get("verification")):
                    continue
                target = str(row["test"])
                out.append({"kind": str(row.get("kind") or "test"), "target": target,
                            "content": str(row["response"]),
                            "context": {"target": target,
                                        "artifact_module": Path(str(row.get("artifact") or "")).stem}})
        return out


class Crowd:
    """Every answer the record kept from a model whose weights never change."""

    def __init__(self, state_dir, evidence=None) -> None:
        """Intention: keep the state folder and the evidence record the fixed models' kept answers are read from."""
        from warp2.record.evidence import Evidence
        self.state_dir = Path(state_dir)
        self.evidence = evidence or Evidence(self.state_dir / "evidence")

    def changing(self) -> set:
        """Intention: a model the warp trains has a checkpoints folder; its answers are not a fixed yardstick."""
        home = self.state_dir / "checkpoints"
        return {p.name for p in home.iterdir() if p.is_dir()} if home.is_dir() else set()

    def _held(self, value):
        """Intention: an entry keeps a big payload as a reference; fetch it back, or None."""
        if isinstance(value, dict) and value.get("evidence") and "preview" in value:
            try:
                return json.loads(self.evidence.text(str(value["evidence"])))
            except (KeyError, ValueError, OSError):
                return None
        return value

    def rows(self) -> list:
        """Intention: one row per file an unchanging model answered, with the verdict it got then."""
        changing, out, seen = self.changing(), [], set()
        for journal in sorted((self.state_dir / JOURNALS).glob("*.jsonl")):
            try:
                handle = journal.open(encoding="utf-8", errors="replace")
            except OSError:
                continue
            with handle:
                for line in handle:
                    if '"do_work"' not in line:
                        continue
                    out += self._from(line, changing, seen)
        return out

    def _from(self, line: str, changing: set, seen: set) -> list:
        """Intention: the files one do_work entry carried, if it was a fixed model's answer."""
        try:
            entry = json.loads(line)
        except ValueError:
            return []
        if entry.get("verb") != "do_work":
            return []
        answer = self._held(entry.get("value"))
        if not isinstance(answer, dict) or not isinstance(answer.get("files"), dict):
            return []
        model = str(answer.get("model") or "")
        if not model or model in changing or "issues" not in answer:
            return []
        context = self._held(entry.get("context"))
        context = context if isinstance(context, dict) else {}
        kind = str(entry.get("work_kind") or "")
        rows = []
        for target, content in answer["files"].items():
            # Intention: the same bytes answered twice are one candle, not two.
            key = hashlib.sha256(f"{kind}\0{target}\0{content}".encode("utf-8")).hexdigest()
            if key in seen:
                continue
            seen.add(key)
            rows.append({"kind": kind, "target": str(target), "content": str(content),
                         "context": dict(context, target=str(target)), "model": model,
                         "then": not answer.get("issues")})
        return rows


class GateCandles:
    """Weighs the gate against both yardsticks and says where it is out of balance."""

    def __init__(self, root, state_dir, good=None, crowd=None, mend=None) -> None:
        """Intention: hold the two yardsticks (proven good code and the crowd's answers) and the
        optional mender used to weigh the gate.
        """
        self.root = Path(root)
        self.state_dir = Path(state_dir)
        self.good = good or ProvenGood(state_dir)
        self.crowd = crowd or Crowd(state_dir)
        self._mend = mend

    def mender(self):
        """Intention: the door's own mend, made once — the tree it reads is the same for every row."""
        if self._mend is None:
            from warp2.gate.mend import Mend
            self._mend = Mend(self.root)
        return self._mend

    def at_the_door(self, row: dict, said: dict) -> bool:
        """Whether the door lets this in: refused, mended once, judged again — as `put_down` does.

        Intention: A RULE THE MEND ALWAYS SATISFIES IS NOT A SWING. The header
        clause refuses every file written before it existed, and the door
        writes that header itself. Counting those as refusals would call the
        gate extreme for a rule that costs the work nothing.
        """
        if not said:
            return True
        told = (f"{row['kind']} was refused for {len(said)} unmet obligation"
                + ("" if len(said) == 1 else "s") + ":\n"
                + "\n".join(f"- {one}" for one in said.values()))
        try:
            got = self.mender().mend(row["target"], row["content"], told, row["context"])
        except Exception:
            return False
        return bool(got) and not complaints(row["kind"], got["content"], row["context"])

    def weigh(self) -> dict:
        """The measurement: per clause, proven-good refused and crowd verdicts moved.

        Intention: NO THRESHOLD DECIDES ANYTHING HERE. What is out of balance
        is said as counts over the yardstick, so the numbers can be read the
        same way at any size of record.
          * too_tight  — clauses that refuse proven-good code even after the
                         door's mend, and how often.
          * through_door — the crowd answers the door would let in now, after
                         its mend: what actually gets written.
          * swing      — (answers that moved to refused − moved to accepted,
                         at the door) over the crowd: 0 is steady, +1 the
                         gate refuses everything it used to let in, −1 the
                         reverse.
        """
        clauses: dict = {}
        good_rows = self.good.rows()
        good_refused = 0
        for row in good_rows:
            said = complaints(row["kind"], row["content"], row["context"])
            if self.at_the_door(row, said):
                continue
            good_refused += 1
            for name in said:
                clauses.setdefault(name, _blank())["refused_good"] += 1
        crowd_rows = self.crowd.rows()
        to_refused = to_accepted = accepted_now = through_door = 0
        for row in crowd_rows:
            said = complaints(row["kind"], row["content"], row["context"])
            accepted_now += not said
            # Intention: THE SWING IS READ AT THE DOOR. A rule the mend always
            # satisfies moves no answer in or out, so only the verdict after
            # the mend says whether the gate moved.
            door = self.at_the_door(row, said)
            through_door += door
            if row["then"] and not door:
                to_refused += 1
                for name in said:
                    clauses.setdefault(name, _blank())["newly_refuses"] += 1
            elif not row["then"] and door:
                to_accepted += 1
            for name in said:
                clauses.setdefault(name, _blank())["refuses_crowd"] += 1
        crowd = len(crowd_rows)
        return {"gate": gate_print(self.root),
                "good": len(good_rows), "good_refused": good_refused,
                "crowd": crowd, "crowd_accepted_then": sum(r["then"] for r in crowd_rows),
                "crowd_accepted_now": accepted_now, "crowd_through_door": through_door,
                "moved_to_refused": to_refused, "moved_to_accepted": to_accepted,
                "swing": round((to_refused - to_accepted) / crowd, 4) if crowd else 0.0,
                "too_tight": {name: n["refused_good"] for name, n in sorted(clauses.items())
                              if n["refused_good"]},
                "clauses": clauses}

    def kept(self) -> Path:
        """Intention: where the measurement for this gate is kept."""
        return self.state_dir / "gate" / f"candles_{gate_print(self.root)}.json"

    def measure_once(self) -> dict:
        """The measurement for the gate as it is now — read back if already taken."""
        path = self.kept()
        if path.is_file():
            try:
                return dict(json.loads(path.read_text(encoding="utf-8")), fresh=False)
            except (OSError, ValueError):
                pass
        report = self.weigh()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, indent=1), encoding="utf-8")
        return dict(report, fresh=True)


def _blank() -> dict:
    """Intention: one clause's counts, all starting at nothing."""
    return {"refused_good": 0, "newly_refuses": 0, "refuses_crowd": 0}


def plainly(report: dict) -> str:
    """The measurement in one short line a person can read."""
    tight = ", ".join(f"{name} ({n})" for name, n in report.get("too_tight", {}).items())
    return (f"Gate check: {report['good_refused']} of {report['good']} proven-good files refused"
            + (f" — by {tight}" if tight else "")
            + f"; fixed models' answers accepted {report['crowd_accepted_then']} then, "
              f"{report['crowd_accepted_now']} now, {report.get('crowd_through_door', 0)} after the mend, "
              f"of {report['crowd']} (swing {report['swing']:+.2f}).")
