# WARP2/warp2/gate/grandfather.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/grandfather.py
#  Used by   : warp2/gate/guard.py (Gate.judge — a change is judged on what it
#              changes), warp2/gate/owed.py (what a file on disk still owes).
#  Uses      : nothing from warp2; the contract it is handed.
#  Description:
#    Grandfathering. A rule a file already broke before a change is not the
#    change's fault: the change is let through for it, and the file is noted
#    as OWING that rule, so it is brought up to it as its own piece of work
#    (warp2/gate/owed.py, warp2/work/sources.py `owed_updates`).
#  User intention (Andrew, 2026-09-23):
#    "things should be grandfathered in but there should be a system to update
#    things like that."
# ============================================================================
from __future__ import annotations

# Intention: THE CLAUSES THAT READ THE PREVIOUS FILE THEMSELVES. They compare
# the change with what was there, so judging the previous file by them would
# compare it with itself. The previous file is judged without it.
_ABOUT_THE_CHANGE = ("previous",)


def inherited(contract, previous: str, context: dict | None = None) -> dict:
    """{clause name: complaint} for every clause the file already failed before this change.

    Intention: the SAME clauses, on the bytes that are on disk now, with the
    same context less the previous file.
    """
    if contract is None or not str(previous or "").strip():
        return {}
    before = {key: value for key, value in dict(context or {}).items() if key not in _ABOUT_THE_CHANGE}
    return {name: said for name, said in contract.complaints(str(previous), before) if said}


# Intention: A FILE THAT DOES NOT PARSE IS NEVER LET THROUGH. Nothing in it
# runs, so a change that leaves it unparseable has changed nothing that
# matters; the sweet spot keeps kicking out the bad.
NEVER_INHERITED = ("parses",)


def items(complaint: str) -> set:
    """The named things a complaint lists — `rule: a, b; advice` gives {a, b}.

    Intention: a complaint names WHAT is wrong. Comparing those names, not
    the whole sentence, lets a change that fixed one of two unused parameters
    through while a change that added a new one does not get through.
    """
    text = str(complaint or "")
    # Intention: a list is named after "rule: " — or after "missing ", which is
    # how the header rule names what a header lacks.
    if ": " in text:
        listed = text.split(": ", 1)[1]
    elif " missing " in text:
        listed = text.split(" missing ", 1)[1]
    else:
        return {text.strip()}
    for end in (";", " — ", " - "):
        listed = listed.split(end, 1)[0]
    return {one.strip() for one in listed.split(",") if one.strip()}


def split(said: list, already: dict, owed=()) -> tuple:
    """(complaints that stand, clause names let through as grandfathered).

    Intention: A CHANGE IS JUDGED ON WHAT IT CHANGES. A clause complains about
    the new bytes; if everything it names was already wrong in the old bytes,
    the change did not cause it, and it is let through. Anything NEW it names
    stands. So does a clause named in `owed`: paying that debt is the reason
    the work exists.
    """
    owed = set(owed or ())
    stand, let_through = [], []
    for name, complaint in said:
        if (complaint and name in already and name not in owed and name not in NEVER_INHERITED
                and items(complaint) <= items(already[name])):
            let_through.append(name)
            continue
        stand.append((name, complaint))
    return stand, let_through
