# WARP2/warp2/gate/proof.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/proof.py
#  Used by   : the loop, which is how a `test` unit is actually closed; the
#              store, which holds the `verified_by` fact this writes.
#  Uses      : warp2/gate/{contracts,guard}.py (a test is judged before it is
#              warp2/tags/grounding.py (its writes graded by who is speaking),
#              believed), warp2/store/store.py, warp2/settings.py, warp2/util.py;
#              stdlib subprocess, tempfile (isolated proof captures).
#  Description:
#    Running the test and binding the result to the exact bytes that ran. The
#    gate reads the artifact; this one runs it. A pass is a statement about two
#    specific files, and it stops being true when either of them moves.
#  User intention (Andrew):
#    "A result counts only with a hash-bound verification record from a
#    controlled run — proof, not assertion."
# ============================================================================
from __future__ import annotations

from warp2.tags import grounding

import os
import sys
import tempfile
from uuid import uuid4
from pathlib import Path

from warp2.gate.contracts import contract_for
from warp2.record import bytecode, children

# The folder every project lives under. Same word the store uses; kept here as
# its own constant so the gate does not import the store to answer a question
# about a path.
PROJECTS = "projects"
from warp2.record.children import run_watched
from warp2.settings import fraction
from warp2.util import now_iso, sha256_hex

# How long a verification run may take before it is cancelled. A test that
# cannot finish is not a test that failed — it is its own outcome, and it is
# recorded as one.
TIMEOUT_SECONDS = fraction("WARP2_PROOF_TIMEOUT_SECONDS", 60.0, minimum=1.0)

PASSED = "passed"
FAILED = "failed"
NO_TESTS = "no_tests"
BROKEN_TEST = "broken_test"
INVALID_TEST = "invalid_test"
TIMED_OUT = "timed_out"


# Intention: the one complaint that means "this file will not import", named
# once so the reader below and the clause that produces it cannot drift apart.
# It is matched on the clause's own words rather than on its name because the
# refusal arrives as the line the work was shown, which is the only form the
# gate promises to keep stable.
_UNBOUND_NAME_COMPLAINT = "uses names it never imports or defines"


def _cannot_be_imported(refused: str) -> bool:
    """Intention: true when the refusal says the test uses names it never imports, so the test is
    called broken, not invalid.
    """
    return _UNBOUND_NAME_COMPLAINT in str(refused)


class Proof:
    """Run one test against one artifact, and record what the bytes were.

    Intention: WARP recorded `passed` for nine `assert True` stubs, each one
    written into the verification index as hash-bound proof — so the hash bound
    the wrong thing perfectly. The hash is necessary and it was never
    sufficient: the test has to be worth running BEFORE it is run, and that
    judgement already exists in this package. Both halves, in that order.
    """

    def __init__(self, store, root, gate=None, python: str = "", stop=None) -> None:
        """Intention: keep the store, the project root, the gate, the python to run tests with, and the
        stop signal.
        """
        self.store = store
        self.root = Path(root)
        self.gate = gate
        self.python = python or sys.executable
        # Intention: a verification run can take minutes, and ALL_STOP has to
        # reach it while it is running — not after. The run goes through the
        # watched runner, which kills the test process AND anything the test
        # itself started.
        self.stop = stop

    # -- the run -------------------------------------------------------------

    def check(self, artifact: str, test: str, timeout: float = 0.0,
              override_root: Path | None = None) -> dict:
        """Judge the test, run it, and say exactly what happened.

        Intention: six outcomes, not two. `passed` and `failed` are the ones
        people expect; the other four exist because each of them was mistaken
        for `failed` in WARP and each mistake cost real work — a test that
        never ran, a test that could not be imported, a test that was never
        worth running, and a test that would not stop.
        """
        artifact_path = self._inside(artifact, override_root=override_root)
        test_path = self._inside(test, override_root=override_root)
        if artifact_path is None:
            return self._result(INVALID_TEST, artifact, test,
                                f"the artifact is not a file inside the tree: {artifact}")
        if test_path is None:
            return self._result(INVALID_TEST, artifact, test,
                                f"the test is not a file inside the tree: {test}")

        artifact_bytes = artifact_path.read_bytes()
        test_bytes = test_path.read_bytes()
        digests = {"artifact_sha256": sha256_hex(artifact_bytes),
                   "test_sha256": sha256_hex(test_bytes)}

        # Intention: THE TEST IS JUDGED BEFORE IT IS BELIEVED. A test that the
        # gate would refuse cannot become proof by passing — a file asserting
        # only that True is True passes every run there is.
        refused = self._gate_says(test_path, artifact_path, test_bytes)
        if refused:
            # Intention: WHY IT WAS REFUSED IS THE WHOLE POINT OF HAVING SIX
            # OUTCOMES. A test naming things it never binds cannot be imported,
            # and that is a broken test whoever notices it — the gate reading
            # it here, or pytest blowing up on it a minute later. Calling it
            # `invalid_test` because the gate got there first would route a
            # repairable test to "not worth running" purely on the basis of
            # which of the two happened to see it, which is the same outcome
            # wearing two names.
            outcome = BROKEN_TEST if _cannot_be_imported(refused) else INVALID_TEST
            return self._result(outcome, artifact, test,
                                "the test is not worth running:\n" + refused, digests)

        code, output = self._run(test_path, artifact_path,
                                 timeout or float(TIMEOUT_SECONDS),
                                 override_root=override_root)
        outcome = self._read_exit(code, output, artifact_path)
        result = self._result(outcome, artifact, test, output[-4000:], digests)
        self._record_observation(artifact, test, outcome, output, digests,
                                 code, artifact_bytes, test_bytes)
        if outcome == PASSED:
            self._record_pass(artifact, test, digests)
        return result

    # Intention: pytest's exit codes, read as the four different things they
    # actually mean. Exit 5 is "nothing ran", and calling that a pass is how a
    # file with no test functions becomes evidence.
    def _read_exit(self, code, output: str, artifact_path: Path) -> str:  # noqa: D401
        if code is None:
            return TIMED_OUT
        if code == 0:
            return _what_a_clean_exit_proved(output)
        if code == 5:
            return NO_TESTS
        if code == 2 and _broke_before_the_artifact_ran(output, artifact_path.stem):
            return BROKEN_TEST
        return FAILED

    def _run(self, test_path: Path, artifact_path: Path, seconds: float,
             override_root: Path | None = None):
        """Intention: run pytest on one test file in a fresh process with a clean bytecode cache; give
        back (exit code, output), None on halt or timeout.
        """
        # Intention: PROOF THAT CAN BE SERVED STALE BYTECODE IS NOT PROOF. This
        # line used to be `PYTHONDONTWRITEBYTECODE`, which was measured on
        # 2026-09-02 to stop writes and not reads — a cached .pyc beside the
        # source ran the OLD code while the gate recorded a verdict about the
        # new. An empty cache directory per run is the only form of this that
        # holds; `honest_cache` owns both halves and cleans up after itself.
        with bytecode.honest_cache(dict(os.environ)) as env, tempfile.TemporaryDirectory(prefix="warp2-proof-capture-") as captures:
            # Intention: synthetic proof cascades never enter the live archive,
            # including checks outside the main tree's pytest configuration.
            env["WARP2_RAW_CAPTURE_DIR"] = captures
            roots = self._importable_roots(artifact_path, test_path, override_root=override_root)
            inherited = [p for p in env.get("PYTHONPATH", "").split(os.pathsep) if p]
            env["PYTHONPATH"] = os.pathsep.join(
                list(dict.fromkeys(roots + inherited)))
            command = [self.python, "-m", "pytest", "-q", "-p", "no:cacheprovider",
                       str(test_path)]
            done = run_watched(command, max(0.1, float(seconds)), stop=self.stop,
                               cwd=str(override_root or self.root), env=env)
        if done["how"] == children.FINISHED:
            return done["code"], done["said"]
        # Intention: a halt is not a failure and neither is a timeout. Both
        # come back as "no exit code", which the reader above turns into
        # `timed_out` — a thing that happened to the run, not a verdict on the
        # artifact.
        return None, done["said"]

    # Intention: the gate's own judgement, reused rather than re-derived. If
    # the two ever disagreed about what a good test is, the disagreement would
    # be invisible — one of them refuses work and the other records proof.
    def _gate_says(self, test_path: Path, artifact_path: Path, test_bytes: bytes) -> str:
        contract = contract_for("test")
        if contract is None:
            return ""
        text = test_bytes.decode("utf-8", "replace")
        context = {"artifact_module": artifact_path.stem}
        issues = contract.failures(text, context)
        return "\n".join(f"- {issue}" for issue in issues)

    # -- the record ----------------------------------------------------------

    @grounding.spoken(grounding.PROVEN)
    def _record_observation(self, artifact: str, test: str, outcome: str,
                            output: str, digests: dict, code=None,
                            artifact_bytes: bytes = b"", test_bytes: bytes = b"") -> None:
        """Record the observable point between a known proof and tested reality."""
        if not self.store:
            return
        art_sha = digests.get("artifact_sha256", "")
        test_sha = digests.get("test_sha256", "")
        # Each encounter survives later edits and repeated runs. Payloads use
        # the existing content-addressed lane, so identical source costs once.
        observation = f"observation:{uuid4().hex}"
        from warp2.gate.contracts import obligations
        asked = self.store.current(subject=artifact, attr="asked_for")
        receipt = {
            "artifact": artifact, "test": test, "outcome": outcome,
            "exit_code": code, "observed_at": now_iso(), **digests,
            "artifact_evidence": self.store.evidence.put(artifact_bytes),
            "test_evidence": self.store.evidence.put(test_bytes),
            "output": output,
            "asked_for": self.store.payload(asked[0]) if asked else None,
            "test_obligations": obligations("test", {"artifact_module": Path(artifact).stem}),
        }
        self.store.assert_fact(observation, "has", attr="proof_observation", value=receipt)
        self.store.assert_fact(artifact, "contains", observation)
        self.store.assert_fact(artifact, "has", attr="last_observation", value=observation)
        # Verdict edges describe an immutable byte pair, never all future
        # versions of the file. Inconclusive executions imply neither verdict.
        target = f"proof-target:{art_sha}:{test_sha}"
        if outcome in (PASSED, FAILED):
            self.store.assert_fact(observation,
                                   "supports" if outcome == PASSED else "contradicts", target)
        marker = f"{outcome}:{art_sha[:12]}:{test_sha[:12]}"
        self.store.assert_fact(artifact, "has", attr="observable_reality", value=marker)
        self.store.assert_fact(artifact, "has", attr="last_tested_outcome", value=outcome)
        self.store.assert_fact(artifact, "has", attr="last_tested_test", value=test)
        self.store.assert_fact(artifact, "has", attr="last_tested_at", value=now_iso())
        for relation in ("supports", "contradicts"):
            for fact in self.store.current(subject=test, relation=relation, obj=artifact):
                self.store.invalidate(fact["key"], reason=f"superseded by {observation}")
        for fact in self.store.current(subject=artifact, attr="last_traceback"):
            self.store.invalidate(fact["key"], reason=f"superseded by {observation}")
        if outcome == PASSED:
            self.store.assert_fact(test, "supports", obj=artifact)
        else:
            if outcome == FAILED:
                self.store.assert_fact(test, "contradicts", obj=artifact)
            if output:
                self.store.assert_fact(artifact, "has", attr="last_traceback", value=output[-4000:])
            att_facts = self.store.current(subject="skill:test", attr="attempted")
            att_count = int(att_facts[0]["value"]) if att_facts else 0
            self.store.assert_fact("skill:test", "has", attr="attempted", value=str(att_count + 1))

    # Intention: the fact says WHICH BYTES passed, not merely that something
    # did. That is the whole of "hash-bound": the claim is about two specific
    # files and it can be checked again later without trusting anybody.
    @grounding.spoken(grounding.PROVEN)
    def _record_pass(self, artifact: str, test: str, digests: dict) -> None:
        self.store.assert_fact(artifact, "has", attr="verified_by", value=test)
        self.store.assert_fact(artifact, "has", attr="verified_bytes",
                               value=f"{digests['artifact_sha256']}:{digests['test_sha256']}")
        self.store.assert_fact(artifact, "has", attr="verified_at", value=now_iso())
        self.store.assert_fact(artifact, "derives", test)
        if not self.store.current(subject=artifact, attr="asked_for"):
            from warp2.gate.contracts import obligations
            told = obligations("test", {"artifact_module": Path(artifact).stem})
            prompt = (f"write the test that shows the artifact works: {artifact}\n\n"
                      f"target file: {test}\n\n"
                      f"obligations:\n{told}")
            self.store.assert_fact(artifact, "has", attr="asked_for", value=prompt)
        for area_fact in self.store.current(relation="has", attr="artifact"):
            if area_fact.get("value") == artifact:
                area = area_fact["subject"]
                self.store.assert_fact(area, "has", attr="verified_by", value=test)
                self.store.assert_fact(area, "has", attr="verified_artifact", value=artifact)
        shown_facts = self.store.current(subject="skill:test", attr="shown")
        shown_count = int(shown_facts[0]["value"]) if shown_facts else 0
        self.store.assert_fact("skill:test", "has", attr="shown", value=str(shown_count + 1))
        att_facts = self.store.current(subject="skill:test", attr="attempted")
        att_count = int(att_facts[0]["value"]) if att_facts else 0
        self.store.assert_fact("skill:test", "has", attr="attempted", value=str(att_count + 1))

    def restate(self, artifact: str) -> dict:
        """Is the recorded pass still about the bytes that are there now?

        Intention: A PROOF THAT HAS STOPPED BEING TRUE MUST SAY SO. WARP bound
        its receipts to hashes and then never looked at them again, so a file
        edited after it was verified still read as verified. Here the drift is
        found by asking, and the answer is written as an invalidation with a
        reason rather than a quiet overwrite.
        """
        recorded = self.store.current(subject=artifact, attr="verified_bytes")
        if not recorded:
            return {"artifact": artifact, "state": "never verified"}
        test_facts = self.store.current(subject=artifact, attr="verified_by")
        test = str(test_facts[0]["value"]) if test_facts else ""
        artifact_path = self._inside(artifact)
        test_path = self._inside(test)
        if artifact_path is None or test_path is None:
            reason = "the file the proof was about is gone"
            self._drop(artifact, reason)
            return {"artifact": artifact, "state": "gone", "why": reason}
        now = (f"{sha256_hex(artifact_path.read_bytes())}:"
               f"{sha256_hex(test_path.read_bytes())}")
        if now == str(recorded[0]["value"]):
            return {"artifact": artifact, "state": "still true", "test": test}
        reason = "the bytes changed since it was verified"
        self._drop(artifact, reason)
        return {"artifact": artifact, "state": "drifted", "why": reason, "test": test}

    # Intention: one place a proof is taken away, so it can never be removed
    # without a reason attached to it.
    def _drop(self, artifact: str, reason: str) -> None:
        for attr in ("verified_by", "verified_bytes", "verified_at"):
            for fact in self.store.current(subject=artifact, attr=attr):
                self.store.invalidate(fact["key"], reason=reason)
        for area_fact in self.store.current(relation="has", attr="artifact"):
            if area_fact.get("value") == artifact:
                for fact in self.store.current(subject=area_fact["subject"], attr="verified_by"):
                    self.store.invalidate(fact["key"], reason=reason)

    # -- reading -------------------------------------------------------------

    # Intention: THE BOUNDARY IS THE PROJECT, NOT THE FOLDER, and moving it was
    # a real decision rather than a convenience. The old rule put only the
    # artifact's own folder on the path, on the principle that a verification
    # able to import the whole tree is verifying the tree. That principle is
    # right and is kept — but "one folder" was the wrong reading of it. A
    # project that is package-shaped, like the eye with 22 modules importing
    # each other, cannot be proven a file at a time under it, and the answer to
    # that was never for the code to flatten itself to suit the runner. So the
    # unit is the project: still not the tree, still no reaching into a
    # neighbouring project, still nothing of warp2 itself.
    def _importable_roots(self, artifact_path, test_path, override_root=None) -> list:
        roots = [str(artifact_path.parent), str(test_path.parent)]
        home = self._project_home(artifact_path, override_root=override_root)
        if home is not None:
            roots.append(str(home))
            if (home / "__init__.py").is_file() and home.parent.is_dir():
                roots.append(str(home.parent))
            src = home / "src"
            if src.is_dir():
                roots.append(str(src))
        if override_root is not None:
            roots.insert(0, str(override_root))
            try:
                base = Path(override_root).resolve()
                rel = artifact_path.resolve().relative_to(base)
                if len(rel.parts) > 0 and rel.parts[0] == "warp2":
                    roots.append(str(self.root))
            except (OSError, ValueError):
                pass
        return list(dict.fromkeys(roots))

    # Intention: the owning project, read from the shape of the path rather
    # than asked of the store. The store would answer the same thing, and would
    # make the gate depend on the projection being current at the moment proof
    # runs — a verification that can be wrong because a projection is stale is
    # a verification with a second way to fail.
    def _project_home(self, artifact_path, override_root=None):
        base = Path(override_root).resolve() if override_root else self.root.resolve()
        try:
            inside = artifact_path.resolve().relative_to(base)
        except (OSError, ValueError):
            try:
                inside = artifact_path.resolve().relative_to(self.root.resolve())
            except (OSError, ValueError):
                return None
        parts = inside.parts
        if len(parts) < 2 or parts[0] != PROJECTS:
            return None
        return base / parts[0] / parts[1]

    # Intention: a path that leaves the tree is not a path this may run. Stated
    # once, here, rather than trusted at every call site.
    def _inside(self, name: str, override_root=None):
        if not name:
            return None
        try:
            base = Path(override_root).resolve() if override_root is not None else self.root.resolve()
            p_name = Path(name)
            if p_name.is_absolute():
                p_res = p_name.resolve()
                p_res.relative_to(base)
                return p_res if p_res.is_file() else None
            path = (base / p_name).resolve()
            path.relative_to(base)
            return path if path.is_file() else None
        except (OSError, ValueError):
            return None

    @staticmethod
    def _result(outcome: str, artifact: str, test: str, said: str,
                digests: dict | None = None) -> dict:
        """Intention: build the one result shape every proof outcome is reported in, with the byte
        digests when known.
        """
        return {"outcome": outcome, "artifact": artifact, "test": test,
                "said": said, "passed": outcome == PASSED, **(digests or {})}

    def check_sandboxed(self, artifact: str, test: str, sandbox_root: Path | str,
                        timeout: float = 0.0) -> dict:
        """Run proof verification within an isolated shadow sandbox."""
        return self.check(artifact, test, timeout=timeout, override_root=Path(sandbox_root))


def _broke_before_the_artifact_ran(output: str, artifact_stem: str) -> bool:
    """Whether a collection error belongs to the TEST, not to the artifact.

    Intention: pytest exits 2 when a test module cannot be imported, which
    means the artifact's behaviour was never exercised and NO EDIT TO IT CAN
    CHANGE THE RESULT. Measured live in WARP: one artifact sat queued for
    revision for days, failing every run, because its test's own module body
    named four constants it never imported. It was never a revision; it was a
    broken test, and calling it one routes it to the repair that works.

    An import failure that names the artifact's own module IS the artifact's
    fault — a test asking for something it does not define — so that stays a
    behavioural failure.
    """
    lowered = output.lower()
    if "error" not in lowered:
        return False
    if not ("error collecting" in lowered or "during collection" in lowered):
        return False
    stem = str(artifact_stem or "")
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped.startswith("E "):
            continue
        if (("ImportError" in stripped or "ModuleNotFoundError" in stripped)
                and (not stem or stem in stripped)):
            return False
    return True


# Intention: a timeout hands back whatever the process managed to say, and it
# arrives as bytes or as text depending on how far it got. One place decides
# which, so the caller never has to.
def _text(value) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return value or ""


# Intention (2026-10-09, check D2): A CLEAN EXIT IS NOT ALWAYS A PASS. pytest
# exits 0 when every test was skipped, and that was written down as hash-bound
# proof. A run where nothing passed proved nothing; a run where any part was
# skipped (or only expected to fail) did not run the whole test, so it is not
# proof either — the test must run whole to stand behind its artifact.
def _what_a_clean_exit_proved(output: str) -> str:
    """PASSED only when at least one test passed and none was skipped or xfailed."""
    import re
    counts = {kind: int(n) for n, kind in re.findall(
        r"(\d+) (passed|skipped|xfailed|deselected)", str(output or ""))}
    if counts.get("passed", 0) == 0:
        return NO_TESTS
    if counts.get("skipped", 0) or counts.get("xfailed", 0):
        return FAILED
    return PASSED
