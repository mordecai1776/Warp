# WARP2/warp2/gate/placeholder_notes.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/placeholder_notes.py
#  Used by   : warp2/gate/checks.py (the clause NO_PLACEHOLDER_NOTES).
#  Uses      : stdlib io, re, tokenize, ast.
#  Description:
#    A note in the code that says the work is not really done, however it is
#    worded: "Replace this with your actual implementation", "in a real
#    system you would...", "dummy data for now". The older clause matched a
#    fixed list of exact phrases, and "Replace this with your actual
#    implementation" slipped past it on 2026-09-24 because the list said
#    "replace with actual". This reads the comments and docstrings only, and
#    matches the SHAPE of such a note, not one wording.
#  User intention (Andrew, 2026-09-24): "is their output not slop?"
# ============================================================================
from __future__ import annotations

import ast
import io
import re
import tokenize

# Intention: the shapes, each a few words apart at most, so the wording can vary.
_SHAPES = (
    r"\breplace\b.{0,30}\b(?:actual|real|your|own|proper)\b",
    r"\byour\s+(?:actual|own|real)\s+(?:implementation|code|logic|data|values?)\b",
    r"\bimplement(?:ation)?\b.{0,20}\b(?:goes|go|would go)\s+here\b",
    r"\b(?:dummy|placeholder)\s+(?:data|values?|implementation|logic|output)\b",
    r"\bin\s+a\s+real\s+(?:implementation|application|system|world|scenario|project)\b",
    r"\bthis\s+is\s+(?:just\s+)?(?:a\s+)?(?:placeholder|stub|simplified|simplification|mock)\b",
    r"\b(?:for\s+now|for\s+demonstration|for\s+illustration)\b.{0,30}\b(?:return|use|assume|hard[- ]?code)",
    r"\b(?:add|put|insert|write)\s+(?:your|the\s+actual|real)\b.{0,20}\bhere\b",
)
_PATTERN = re.compile("|".join(_SHAPES), re.IGNORECASE)

# Intention: anything in quotes, straight or curly, single or double.
_QUOTED = re.compile(r'"[^"]*"|“[^”]*”|\'[^\']{3,}\'|‘[^’]*’')


def _comments(code: str) -> list:
    """Intention: every comment's text; a file that will not tokenize gives none."""
    try:
        return [tok.string for tok in tokenize.generate_tokens(io.StringIO(code).readline)
                if tok.type == tokenize.COMMENT]
    except (tokenize.TokenError, IndentationError, SyntaxError):
        return []


def _docstrings(code: str) -> list:
    """Intention: every docstring — module, class and function."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []
    out = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            said = ast.get_docstring(node)
            if said:
                out.append(said)
    return out


def found(code: str) -> str:
    """The first note that says the work is not done, or "" when there is none."""
    for text in _comments(code) + _docstrings(code):
        # Intention: words in quotes are being TALKED ABOUT, not said — a note
        # quoting a bad phrase to explain a rule is not that phrase.
        spoken = _QUOTED.sub(" ", " ".join(text.split()))
        hit = _PATTERN.search(spoken)
        if hit:
            return hit.group(0)
    return ""
