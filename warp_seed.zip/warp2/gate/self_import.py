# WARP2/warp2/gate/self_import.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/self_import.py
#  Used by   : warp2/gate/checks.py (NOT_ITSELF — the clause that refuses it),
#              warp2/gate/mend.py (SelfImportMend — the mend that takes it out).
#  Uses      : stdlib ast, pathlib.
#  Description:
#    Finds a file that imports itself ("from state.practice.syntax import
#    solution_entry" inside state/practice/syntax.py). Such a file cannot be
#    imported: the name it asks for is not defined yet when the import runs.
#    The check says so; the mend removes those import lines, which is the one
#    right answer, because every name they asked for is the file's own.
#  User intention (Andrew):
#    2026-09-25: "fix the one last model thing if you can." The practice for
#    skill:syntax failed with a file that imported itself, and nothing in the
#    gate caught it — the examples then could not even be run.
#    2026-09-18: "build things into the right system to keep those from
#    happening again ... the warp should fix it itself."
# ============================================================================
from __future__ import annotations

import ast
from pathlib import Path, PurePosixPath

# Intention: the complaint's opening words, which the mend looks for.
SELF_IMPORT = "the file imports itself: "


def _parts(path: str) -> tuple:
    """A file's path as module parts ("a/b/c.py" -> ("a", "b", "c")), or ().

    Intention: () for anything but a .py module, and for a package's
    __init__.py — there `from pkg import submodule` is how a package gathers
    its parts, and it works.
    """
    posix = PurePosixPath(str(path or "").replace("\\", "/"))
    if posix.suffix != ".py" or posix.stem == "__init__":
        return ()
    return posix.with_suffix("").parts


def names_itself(module: str, path: str) -> bool:
    """Whether an imported module name is this file.

    Intention: the file can be reached by any tail of its path, depending on
    which folder is on the path — "syntax", "practice.syntax" and
    "state.practice.syntax" are all state/practice/syntax.py — so a name equal
    to any tail that ends at the file is the file.
    """
    wanted = tuple(str(module or "").split("."))
    own = _parts(path)
    return bool(wanted and own) and len(wanted) <= len(own) and own[-len(wanted):] == wanted


def relative_self(node: ast.ImportFrom, path: str) -> str:
    """The relative import's text when it reaches this very file, else "".

    Intention (2026-10-09, check R2): THE RELATIVE FORM IS THE SAME MISTAKE.
    The warp wrote `from . import __main__` into adaptive_layers/__main__.py
    and the rule above, which only read absolute imports, let it through. A
    relative import is resolved from the file's own folder: `level` dots go
    up `level - 1` folders, then the module's parts (and, for `from . import
    name`, the name) follow; it is this file when that lands on its parts.
    """
    own = _parts(path)
    if not own or node.level - 1 > len(own) - 1:
        return ""
    base = list(own[:len(own) - 1 - (node.level - 1)])
    dots = "." * node.level
    if node.module:
        if tuple(base + node.module.split(".")) == own:
            return dots + node.module
        return ""
    for alias in node.names:
        if tuple(base + [alias.name]) == own:
            return dots + alias.name
    return ""


def imports_of_itself(code: str, path: str) -> list:
    """The imports in `code` of the file at `path`, as dicts.

    Intention: each says its lines, the module, whether it is at the top of
    the file, and whether the statement imports only this file — the mend
    takes out only what it can take out whole.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []
    top = {id(node) for node in tree.body}
    found = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and not node.level and names_itself(node.module, path):
            found.append({"first": node.lineno, "last": node.end_lineno, "module": node.module,
                          "top": id(node) in top, "whole": True})
        elif isinstance(node, ast.ImportFrom) and node.level:
            own = relative_self(node, path)
            if own:
                found.append({"first": node.lineno, "last": node.end_lineno, "module": own,
                              "top": id(node) in top,
                              "whole": bool(node.module) or len(node.names) == 1})
        elif isinstance(node, ast.Import):
            own = [alias.name for alias in node.names if names_itself(alias.name, path)]
            if own:
                found.append({"first": node.lineno, "last": node.end_lineno, "module": own[0],
                              "top": id(node) in top, "whole": len(own) == len(node.names)})
    return found


def where_it_is(ctx: dict) -> str:
    """Intention: the path being written, as the gate was told it."""
    return str(ctx.get("write_path") or ctx.get("artifact_path") or "")


def check(code: str, ctx: dict) -> str:
    """Intention: "" unless the file imports itself; then which module, in words a model can act on."""
    path = where_it_is(ctx)
    found = imports_of_itself(code, path) if path else []
    if not found:
        return ""
    modules = ", ".join(sorted({one["module"] for one in found}))
    return (f"{SELF_IMPORT}{modules} is this file ({path}); its names are already "
            f"defined here, so take that import out")


class SelfImportMend:
    """Take out the imports of a file's own module."""

    def __init__(self, root) -> None:
        """Intention: `root` is WARP2/, which the file's path is read from."""
        self.root = Path(root)

    def __call__(self, full, content: str, said: str) -> str | None:
        """The file without its imports of itself, or None when that is not the refusal or it cannot be done exactly."""
        if SELF_IMPORT not in str(said or ""):
            return None
        try:
            path = Path(full).resolve().relative_to(self.root.resolve()).as_posix()
        except ValueError:
            return None
        found = imports_of_itself(content, path)
        # Intention: nothing guesses — an import inside a function, or one that
        # also brings in another module, is left for the model to fix.
        if not found or not all(one["top"] and one["whole"] for one in found):
            return None
        drop = set()
        for one in found:
            drop.update(range(one["first"] - 1, one["last"]))
        lines = content.splitlines()
        kept = [line for at, line in enumerate(lines) if at not in drop]
        return "\n".join(kept) + ("\n" if content.endswith("\n") else "")
