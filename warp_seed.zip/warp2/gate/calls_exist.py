# WARP2/warp2/gate/calls_exist.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/calls_exist.py
#  Used by   : warp2/gate/checks.py (the clause ITS_CALLS_EXIST).
#  Uses      : stdlib ast, json, sys, tempfile, pathlib;
#              warp2/record/children.py (run_watched — the look happens in its
#              own process, so nothing the code imports runs in the loop),
#              warp2/models/patience.py (how long the look may be silent,
#              learned; a look cut off is "could not tell", never a refusal),
#              projects/image_video_to_blender/environment_and_compute_probe.py
#              (detect_blender — Blender's own modules are looked up inside
#              Blender).
#  Description:
#    Every `module.a.b` the code reaches for is looked up for real: the module
#    is imported in a child process and each name is asked for in turn. A name
#    that is not there is a call that will crash the first time it runs —
#    `bpy.data.asset_levels` on 2026-09-24 passed every check the gate had,
#    and does not exist. Blender's modules (bpy, bmesh, mathutils, ...) only
#    exist inside Blender, so they are looked up there. A module that cannot be
#    imported at all is "could not tell", not a refusal: the names clause
#    already catches names that come from nowhere.
#  User intention (Andrew, 2026-09-24): "is their output not slop?" — the
#    gate must know whether the code works, not only how it looks.
# ============================================================================
from __future__ import annotations

import ast
import json
import sys
import tempfile
from pathlib import Path

# Intention: the modules that only exist inside Blender's own Python.
BLENDER_MODULES = {"bpy", "bmesh", "mathutils", "gpu", "bpy_extras", "bl_math", "aud",
                   "idprop", "freestyle", "gpu_extras", "bl_ui", "bgl"}

# Intention: the tree's root, so the tree's own modules can be looked up too.
ROOT = Path(__file__).resolve().parents[2]

# Intention: the line the child's answer follows, so anything the imported
# code prints cannot be mistaken for it.
MARK = "@@CALLS_EXIST@@"

# Intention: the child. It imports each root and walks each chain of names.
_LOOKER = r'''
import importlib, json, sys
asked = json.loads(sys.argv[-1]) if not sys.argv[-1].endswith(".json") else json.load(open(sys.argv[-1]))
missing, unknown = [], []
for row in asked:
    root, names = row["root"], row["names"]
    try:
        try:
            thing = importlib.import_module(root)
        except ImportError:
            head, _, tail = root.rpartition(".")
            thing = getattr(importlib.import_module(head), tail)
    except BaseException:
        unknown.append(root)
        continue
    for i, name in enumerate(names):
        try:
            thing = getattr(thing, name)
        except BaseException:
            missing.append(row["shown"].split(".")[0] + "." + ".".join(names[:i + 1]))
            break
print("@@CALLS_EXIST@@" + json.dumps({"missing": missing, "unknown": unknown}))
'''


def roots_of(tree) -> dict:
    """Name in the file -> the module (or module.name) it was imported as.

    Intention: only names bound by an import and never assigned again — a
    name reused for something else is not the module any more.
    """
    roots = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.asname:
                    roots[alias.asname] = alias.name
                else:
                    head = alias.name.split(".")[0]
                    roots[head] = head
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            for alias in node.names:
                if alias.name != "*":
                    roots[alias.asname or alias.name] = f"{node.module}.{alias.name}"
    for node in ast.walk(tree):
        targets = node.targets if isinstance(node, ast.Assign) else (
            [node.target] if isinstance(node, (ast.AugAssign, ast.AnnAssign, ast.For)) else [])
        for target in targets:
            for part in ast.walk(target):
                if isinstance(part, ast.Name):
                    roots.pop(part.id, None)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for arg in node.args.args + node.args.kwonlyargs:
                roots.pop(arg.arg, None)
    return roots


def _chain(node) -> list:
    """Intention: `a.b.c` as ["a", "b", "c"]; anything not a plain chain gives []."""
    names = []
    while isinstance(node, ast.Attribute):
        names.append(node.attr)
        node = node.value
    if not isinstance(node, ast.Name):
        return []
    return [node.id] + names[::-1]


def chains(tree) -> list:
    """Every longest `module.a.b` the code reads, once each: {root, names, shown}."""
    roots = roots_of(tree)
    inner = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Attribute):
            inner.add(id(node.value))
    out, seen = [], set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Attribute) or id(node) in inner:
            continue
        names = _chain(node)
        if len(names) < 2 or names[0] not in roots:
            continue
        shown = ".".join(names)
        if shown in seen:
            continue
        seen.add(shown)
        out.append({"root": roots[names[0]], "names": names[1:], "shown": shown})
    return out


def _patience():
    """Intention: the learned wait for a look, kept with the machine's other waits."""
    from warp2.models.patience import Patience
    path = ROOT / "state" / "models" / "patience.json"
    return Patience(path if path.parent.is_dir() else None)


def _ask(command: list, name: str) -> dict:
    """Run one look; {"missing": [...], "unknown": [...]} or None when it could not tell."""
    from warp2.record.children import FINISHED, TIMED_OUT, run_watched
    patience = _patience()
    ran = run_watched(command, seconds=patience.whole(name), cwd=str(ROOT),
                      quiet_seconds=patience.silence(name))
    if ran["how"] == TIMED_OUT:
        patience.went_silent(name)
        return None
    if ran["how"] != FINISHED:
        return None
    patience.answered(name)
    for line in reversed(str(ran["said"]).splitlines()):
        if line.startswith(MARK):
            try:
                return json.loads(line[len(MARK):])
            except ValueError:
                return None
    return None


def _blender() -> str:
    """Intention: Blender's program on this machine, or "" when there is none."""
    try:
        try:
            from image_video_to_blender.environment_and_compute_probe import detect_blender
        except ImportError:
            from projects.image_video_to_blender.environment_and_compute_probe import detect_blender
        return str(detect_blender() or "")
    except Exception:
        return ""


def _look(rows: list, in_blender: bool) -> dict | None:
    """Intention: one child for all the rows of one kind; the rows go by file."""
    if not rows:
        return {"missing": [], "unknown": []}
    with tempfile.TemporaryDirectory() as home:
        script = Path(home) / "look.py"
        asked = Path(home) / "asked.json"
        script.write_text(_LOOKER, encoding="utf-8")
        asked.write_text(json.dumps(rows), encoding="utf-8")
        if in_blender:
            blender = _blender()
            if not blender:
                return None
            return _ask([blender, "-b", "--factory-startup", "--python", str(script),
                         "--", str(asked)], "gate look in blender")
        return _ask([sys.executable, "-B", str(script), str(asked)], "gate look")


def missing(code: str) -> list:
    """Every `module.a.b` in the code that does not exist; [] when all do or it cannot tell."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []
    rows = chains(tree)
    blender = [r for r in rows if r["root"].split(".")[0] in BLENDER_MODULES]
    plain = [r for r in rows if r not in blender]
    out = []
    for group, inside in ((plain, False), (blender, True)):
        said = _look(group, inside)
        if said:
            out += said.get("missing", [])
    return out


def missing_many(codes: dict) -> dict:
    """{path: [what does not exist]} for many files in two looks — one plain, one in Blender.

    Intention: the sweep checks hundreds of files; a child each would take
    many minutes (MEASURED 2026-09-24: over 180 s for the project tree). Every
    file's chains go in one look; each missing name is given back to the
    files that reach for it.
    """
    rows, owners = [], {}
    for path, code in codes.items():
        try:
            tree = ast.parse(code)
        except SyntaxError:
            continue
        for row in chains(tree):
            key = (row["root"], tuple(row["names"]), row["shown"])
            if key not in owners:
                owners[key] = []
                rows.append(row)
            owners[key].append(path)
    blender = [r for r in rows if r["root"].split(".")[0] in BLENDER_MODULES]
    plain = [r for r in rows if r not in blender]
    gone = set()
    for group, inside in ((plain, False), (blender, True)):
        said = _look(group, inside)
        if said:
            gone |= set(said.get("missing", []))
    out: dict = {}
    for (root, names, shown), paths in owners.items():
        for i in range(len(names)):
            name = shown.split(".")[0] + "." + ".".join(names[:i + 1])
            if name in gone:
                for path in paths:
                    out.setdefault(path, [])
                    if name not in out[path]:
                        out[path].append(name)
                break
    return out
