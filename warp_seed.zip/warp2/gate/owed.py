# WARP2/warp2/gate/owed.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/owed.py
#  Used by   : warp2/work/side/gate_candles.py (after each new version of the
#              gate, every project file is swept for the rules it does not
#              meet yet), warp2/work/truth.py (`_update_done` — does the file
#              meet the rule now), warp2/work/sources.py (`owed_updates`).
#  Uses      : warp2/gate/contracts.py (contract_for), warp2/store/store.py
#              (an owed rule is an attribute fact on the file:
#              `owes:<clause>` = the complaint); stdlib pathlib.
#  Description:
#    What each file OWES: the rules it was made before and does not meet yet.
#    A file that owes a rule is let through for it when changed
#    (warp2/gate/grandfather.py) and is brought up to it as work of its own.
#  User intention (Andrew, 2026-09-23):
#    "things should be grandfathered in but there should be a system to update
#    things like that."
# ============================================================================
from __future__ import annotations

from pathlib import Path

OWES = "owes:"


def kind_of(path: str) -> str:
    """Intention: a test file is judged as a test; anything else as a module."""
    return "test" if Path(path).name.startswith("test_") else "build"


def update_kind(path: str) -> str:
    """Intention: the work that pays a debt is judged by the rules that found it — a test's by a test's."""
    return "update_test" if kind_of(path) == "test" else "update"


# Intention: RULES A FILE ALONE CANNOT ANSWER. Which module a test is for is
# a fact about the work that made it, not about its bytes, so a sweep that
# guessed it would state debts no update could ever pay.
UNKNOWABLE = ("imports_artifact",)

# Intention: files that are not a module's work: a package marker and the
# test runner's own setup are meant to hold little or nothing.
NOT_WORK = ("__init__.py", "conftest.py")


def context_of(path: str, root=None) -> dict:
    """Intention: the plain facts a file can be judged by from the tree alone — where it is, and whether it is in a package."""
    context = {"target": path}
    if root is not None:
        context["in_package"] = (Path(root) / path).parent.joinpath("__init__.py").is_file()
    return context


def owed_by(content: str, path: str, root=None) -> dict:
    """{clause: complaint} for every rule these bytes do not meet that the file alone can answer."""
    from warp2.gate.contracts import contract_for
    if Path(path).name in NOT_WORK:
        return {}
    contract = contract_for(kind_of(path))
    if contract is None:
        return {}
    return {name: said for name, said in contract.complaints(str(content), context_of(path, root))
            if said and name not in UNKNOWABLE}


class Owed:
    """The rules each project file still owes, kept in the store."""

    def __init__(self, root, store) -> None:
        """Intention: keep the project root and the store the owed rules are read from and written to."""
        self.root = Path(root)
        self.store = store

    def files(self) -> list:
        """Intention: the project files the loop may change — where an update can be written."""
        home = self.root / "projects"
        if not home.is_dir():
            return []
        return sorted(p for p in home.rglob("*.py")
                      if not any(part.startswith(("_retired", "__pycache__", ".")) for part in p.relative_to(home).parts))

    def now(self, path: str) -> dict:
        """What the file on disk owes this moment; {} when it is gone."""
        where = self.root / path
        try:
            return owed_by(where.read_text(encoding="utf-8", errors="replace"), path, self.root)
        except OSError:
            return {}

    def sweep(self) -> dict:
        """Every file judged; a new debt stated, a paid one ended.

        Intention: RUN WHEN THE RULES CHANGE. A new rule is new debt for every
        file made before it; nothing else about a file's debt changes unless
        the file does, and a change is judged at the door.
        """
        stated = ended = files = 0
        held = set(self.held())
        seen = set()
        for full in self.files():
            path = full.relative_to(self.root).as_posix()
            files += 1
            for clause, said in self.now(path).items():
                seen.add((path, clause))
                if (path, clause) not in held:
                    self.store.assert_fact(path, "has", attr=OWES + clause, value=str(said))
                    stated += 1
        for path, clause in held - seen:
            ended += self._end(path, clause)
        return {"files": files, "stated": stated, "ended": ended, "owed": len(seen)}

    def held(self) -> list:
        """Every (file, clause) the store says is owed now.

        Intention: read as two plain columns — `attributed_like` answers in
        tuples, and the clause is the part of the attribute after `owes:`.
        """
        return [(str(row[0]), str(row[1])[len(OWES):]) for row in self.store.attributed_like(OWES)]

    def _end(self, path: str, clause: str) -> int:
        """Intention: a debt is ended by saying it stopped being true, never by deleting it."""
        facts = self.store.current(subject=path, attr=OWES + clause)
        for fact in facts:
            self.store.invalidate(fact["key"], reason=f"{path} meets {clause} now")
        return len(facts)

    def paid(self, path: str, clause: str) -> bool:
        """Whether the file meets the rule now; if so, the debt is ended in the store."""
        if clause in self.now(path):
            return False
        self._end(path, clause)
        return True
