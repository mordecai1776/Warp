# WARP2/warp2/gate/import_table.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/import_table.py
#  Used by   : warp2/gate/mend.py (ImportMend asks it last),
#              warp2/work/loop.py (teaches it every accepted file).
#  Uses      : stdlib ast, json, pathlib.
#  Description:
#    Which import line each name has come in by, learned from the files the
#    gate accepted. A name that has only ever come in one way has exactly one
#    right import, and the import mend can add it without guessing.
#  User intention (Andrew, 2026-09-18):
#    "The warp should continually trying to make everything automations."
#    Each accepted file turns a little more of what a model had to know into
#    something code does exactly.
# ============================================================================
from __future__ import annotations

import ast
import json
from pathlib import Path


def import_lines(content: str) -> dict:
    """Every name a file brings in, and the one line that brings it in.

    Intention: only absolute imports without a star — a relative import or a
    star means different things in different places, so it teaches nothing
    that holds elsewhere.
    """
    try:
        tree = ast.parse(content or "")
    except SyntaxError:
        return {}
    out = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for one in node.names:
                name = one.asname or one.name.split(".")[0]
                out[name] = f"import {one.name}" + (f" as {one.asname}" if one.asname else "")
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            for one in node.names:
                if one.name == "*" or node.module == "__future__":
                    continue
                name = one.asname or one.name
                out[name] = f"from {node.module} import {one.name}" + (f" as {one.asname}" if one.asname else "")
    return out


class ImportTable:
    """Name → every import line it has been accepted with, and how often.

    Intention: kept under the state folder, grown only by accepted files. It
    answers only when a name has one line and no other — the same "exactly
    one answer" rule the rest of the mend keeps.
    """

    def __init__(self, state) -> None:
        """Intention: read once; written each time it learns something new."""
        self.path = Path(state) / "mend" / "imports.json"
        try:
            self.seen = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.seen = {}

    def learn(self, content: str) -> int:
        """Intention: count each name's line from one accepted file; how many were new."""
        fresh = 0
        for name, line in import_lines(content).items():
            lines = self.seen.setdefault(name, {})
            fresh += 0 if line in lines else 1
            lines[line] = lines.get(line, 0) + 1
        if fresh:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.seen, sort_keys=True), encoding="utf-8")
        return fresh

    def line_for(self, name: str) -> str:
        """Intention: the one line this name has come in by, or "" if none or several."""
        lines = self.seen.get(str(name)) or {}
        return next(iter(lines)) if len(lines) == 1 else ""
