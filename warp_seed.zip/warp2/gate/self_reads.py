# WARP2/warp2/gate/self_reads.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/self_reads.py
#  Used by   : warp2/gate/checks.py (the clauses NO_SHADOWED_METHODS and
#              SETS_WHAT_IT_READS).
#  Uses      : stdlib ast.
#  Description:
#    Two mistakes a class makes with its own `self`, found by reading it:
#    a value stored under the same name as one of its methods (so calling the
#    method crashes), and a value read from `self` that nothing ever sets (so
#    the first read crashes). Both passed every check the gate had on
#    2026-09-24 — castle_adventure.py set `self.score` over `score()`, and
#    multiscale_asset_representation.py read `self.coarse_representation`
#    that nothing set.
#  User intention (Andrew, 2026-09-24): "is their output not slop?" — and
#    the make cycle's first step: a gate that knows whether the code works.
# ============================================================================
from __future__ import annotations

import ast

# Intention: bases a class can have and still be read whole from its file.
_PLAIN_BASES = {"object", "Exception", "ValueError", "RuntimeError", "dict", "list",
                "tuple", "str", "int", "float", "Enum", "IntEnum", "NamedTuple",
                "ABC", "Protocol", "Generic"}


def _names_defined_in(cls: ast.ClassDef) -> tuple:
    """(methods, set_names): what the class body defines, and every self.x it sets.

    Intention: a name is SET by the class if it is assigned on self anywhere,
    assigned or annotated in the class body, or defined as a method.
    """
    methods, set_names = set(), set()
    for node in cls.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            methods.add(node.name)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            for target in _targets(node):
                set_names.update(part.id for part in _stored(target) if isinstance(part, ast.Name))
    for node in ast.walk(cls):
        for target in _targets(node):
            set_names.update(part.attr for part in _stored(target) if _is_self_attr(part))
    return methods, set_names


def _targets(node) -> list:
    """Intention: what an assignment of any kind writes to; nothing for other nodes."""
    if isinstance(node, ast.Assign):
        return list(node.targets)
    if isinstance(node, (ast.AugAssign, ast.AnnAssign, ast.For, ast.AsyncFor)):
        return [node.target]
    if isinstance(node, (ast.With, ast.AsyncWith)):
        return [item.optional_vars for item in node.items if item.optional_vars is not None]
    return []


def _stored(target) -> list:
    """The names and attributes a target actually stores into.

    Intention: `a, self.b = ...` stores a and self.b; `d[self.key()] = ...`
    stores into d and only READS self.key — walking the whole target would
    count the read as a store.
    """
    if isinstance(target, (ast.Tuple, ast.List)):
        return [part for element in target.elts for part in _stored(element)]
    if isinstance(target, ast.Starred):
        return _stored(target.value)
    return [target]


def _is_property(node) -> bool:
    """Intention: a method made a property (or its setter) is a value, not a call."""
    for deco in getattr(node, "decorator_list", []):
        if isinstance(deco, ast.Name) and deco.id in ("property", "cached_property"):
            return True
        if isinstance(deco, ast.Attribute) and deco.attr in ("setter", "getter", "deleter",
                                                             "cached_property"):
            return True
    return False


def _is_self_attr(node) -> bool:
    """Intention: `self.<name>`, and nothing else."""
    return (isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name)
            and node.value.id == "self")


def _reads(cls: ast.ClassDef) -> list:
    """Intention: every self.x the class reads, in order, once each."""
    seen = []
    for node in ast.walk(cls):
        if _is_self_attr(node) and isinstance(node.ctx, ast.Load) and node.attr not in seen:
            seen.append(node.attr)
    return seen


def _whole(cls: ast.ClassDef, local: set) -> bool:
    """Whether everything this class can hold is written in this file.

    Intention: a class that inherits from something outside the file, or
    reaches its own fields by name at run time, may be given values this
    reading cannot see — so it is not judged, rather than judged wrongly.
    """
    for base in cls.bases:
        name = base.id if isinstance(base, ast.Name) else getattr(base, "attr", "")
        if name not in _PLAIN_BASES and name not in local:
            return False
    for node in ast.walk(cls):
        if isinstance(node, ast.Name) and node.id in ("setattr", "vars", "__dict__"):
            return False
        if isinstance(node, ast.Attribute) and node.attr in ("__dict__", "__setattr__"):
            return False
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in (
                "__getattr__", "__getattribute__", "__setattr__"):
            return False
    return True


def _plain(attr: str) -> str:
    """Intention: `self.__x` inside class C is `self._C__x` to Python; both read as one.

    Any class's mangled prefix is taken off, because a subclass may read a
    base class's mangled name by hand.
    """
    import re
    hit = re.match(r"^_[A-Za-z][A-Za-z0-9_]*?(__[A-Za-z0-9_]+)$", attr)
    return hit.group(1) if hit and not attr.endswith("__") else attr


def _classes(tree) -> dict:
    """Intention: every class in the file by name."""
    return {node.name: node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)}


def _inherited(cls: ast.ClassDef, classes: dict) -> tuple:
    """Intention: what a class gets from its in-file bases, all the way up."""
    methods, set_names = set(), set()
    for base in cls.bases:
        parent = classes.get(base.id) if isinstance(base, ast.Name) else None
        if parent is not None and parent is not cls:
            got_methods, got_set = _names_defined_in(parent)
            up_methods, up_set = _inherited(parent, {k: v for k, v in classes.items() if v is not parent})
            methods |= got_methods | up_methods
            set_names |= got_set | up_set
    return methods, set_names


def shadowed_methods(tree) -> list:
    """(class, name) where a value is stored on self under a method's own name."""
    out = []
    for name, cls in _classes(tree).items():
        methods = {node.name for node in cls.body
                   if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not _is_property(node)}
        stored = {part.attr for node in ast.walk(cls) for target in _targets(node)
                  for part in _stored(target) if _is_self_attr(part)}
        out += [(name, method) for method in sorted(methods & stored)]
    return out


def read_never_set(tree) -> list:
    """(class, name) where self.name is read and nothing in reach ever sets it."""
    classes = _classes(tree)
    out = []
    for name, cls in classes.items():
        if not _whole(cls, set(classes)):
            continue
        methods, set_names = _names_defined_in(cls)
        up_methods, up_set = _inherited(cls, classes)
        known = {_plain(n) for n in methods | set_names | up_methods | up_set}
        out += [(name, attr) for attr in _reads(cls)
                if _plain(attr) not in known and not attr.startswith("__")]
    return out
