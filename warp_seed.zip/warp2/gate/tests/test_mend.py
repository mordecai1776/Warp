# WARP2/warp2/gate/tests/test_mend.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_mend.py
#  Used by   : pytest.
#  Uses      : warp2/gate/mend.py, warp2/gate/checks.py (the real refusals).
#  Description:
#    A refusal with exactly one right answer is mended; anything with two
#    answers, or none, is left alone. The mended file passes the same check
#    that refused it.
#  User intention (Andrew, 2026-09-18):
#    "build things into the right system to keep those from happening again."
# ============================================================================
from __future__ import annotations

from warp2.gate.checks import _names_come_from_somewhere, _no_import_time_effects
from warp2.gate.mend import Mend


def _project(tmp_path):
    """Intention: a two-file project, the shape of game_builder on 09-17."""
    home = tmp_path / "projects" / "game"
    home.mkdir(parents=True)
    (home / "grid.py").write_text("class Grid:\n    pass\n", encoding="utf-8")
    return tmp_path


RULES = ('# WARP2/projects/game/rules.py\n"""Rules."""\nfrom __future__ import annotations\n\n\n'
         'def legal(grid: Grid, move: Any) -> bool:\n    return grid is not None and move is not None\n')


def test_the_grid_refusal_from_09_17_is_mended(tmp_path):
    """Intention: Grid from the one file that defines it, Any from typing."""
    root = _project(tmp_path)
    said = "build was refused for 1 unmet obligation:\n- " + _names_come_from_somewhere(RULES, {})
    got = Mend(root).mend("projects/game/rules.py", RULES, said)
    assert got["by"] == ["import"]
    assert "from projects.game.grid import Grid" in got["content"]
    assert "from typing import Any" in got["content"]
    assert got["content"].splitlines()[0] == "# WARP2/projects/game/rules.py"
    assert _names_come_from_somewhere(got["content"], {}) == ""


def test_a_name_two_files_define_is_left_alone(tmp_path):
    """Intention: two answers means no answer; the refusal stands."""
    root = _project(tmp_path)
    (root / "projects" / "game" / "board.py").write_text("class Grid:\n    pass\n", encoding="utf-8")
    said = _names_come_from_somewhere(RULES, {})
    assert Mend(root).mend("projects/game/rules.py", RULES, said) is None


def test_calls_at_import_time_move_under_main(tmp_path):
    """Intention: the file still does its job when run, and nothing when imported."""
    code = "def run():\n    return 1\n\n\nrun()\n"
    said = _no_import_time_effects(code, {})
    got = Mend(tmp_path).mend("projects/game/job.py", code, said)
    assert got["by"] == ["import_time"]
    assert 'if __name__ == "__main__":\n    run()' in got["content"]
    assert _no_import_time_effects(got["content"], {}) == ""


def test_a_refusal_code_cannot_fix_changes_nothing(tmp_path):
    """Intention: anything that needs judgement stays the model's job."""
    said = "parameter declared and never used: is_firing(pair_id)"
    assert Mend(tmp_path).mend("projects/game/rules.py", RULES, said) is None


def test_a_path_outside_the_tree_is_never_mended(tmp_path):
    """Intention: the mend only ever touches files under WARP2/."""
    said = _names_come_from_somewhere(RULES, {})
    assert Mend(tmp_path / "tree").mend(str(tmp_path / "elsewhere.py"), RULES, said) is None


def test_unterminated_triple_quote_is_mended(tmp_path):
    """Intention: unclosed triple-quote docstring is closed deterministically."""
    code = '"""Unclosed module docstring\n\ndef add(a: int, b: int) -> int:\n    return a + b\n'
    said = "SyntaxError line 4: unterminated triple-quoted string literal (detected at line 1)"
    got = Mend(tmp_path).mend("projects/game/calc.py", code, said)
    assert got is not None
    assert "delimiter" in got["by"]
    import ast
    assert ast.parse(got["content"])


def test_unterminated_single_line_string_is_mended(tmp_path):
    """Intention: unclosed single or double quote on a line is closed at proper syntax point."""
    code = 'msg = "hello world\nprint(msg)\n'
    said = "SyntaxError line 1: unterminated string literal (detected at line 1)"
    got = Mend(tmp_path).mend("projects/game/msg.py", code, said)
    assert got is not None
    assert "delimiter" in got["by"]
    assert 'msg = "hello world"' in got["content"]
    import ast
    assert ast.parse(got["content"])


def test_unclosed_bracket_is_mended(tmp_path):
    """Intention: unclosed parenthesis or bracket is closed to yield valid AST."""
    code = "items = [1, 2, 3\n"
    said = "SyntaxError line 1: '[' was never closed"
    got = Mend(tmp_path).mend("projects/game/data.py", code, said)
    assert got is not None
    assert "delimiter" in got["by"]
    assert "items = [1, 2, 3]" in got["content"]
    import ast
    assert ast.parse(got["content"])

