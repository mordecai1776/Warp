# WARP2/warp2/gate/tests/test_the_gate_keeps_the_tree_rule.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_the_gate_keeps_the_tree_rule.py
#  Used by   : pytest.
#  Uses      : warp2/gate/{checks,contracts}.py, warp2/integrity/discipline.py.
#  Description:
#    Fix 7.2 (check D12). The gate's header rule is the tree's own rule — the
#    first line is "# WARP2/<path>" and the five fields are there by name —
#    and the gate asks for an intention note on every part of the code it
#    lets in (a test file says what it is for in its names).
#  User intention (Andrew, project standard): "The pathway of the file should
#    be at the top of every file" and "Intention notes ... will be on every
#    part of the code".
# ============================================================================
from __future__ import annotations

from warp2.gate import checks as c
from warp2.gate.contracts import CONTRACTS

TARGET = "projects/thing/hold.py"
HEADER = ("# WARP2/projects/thing/hold.py\n#\n"
          "#  Pathway   : WARP2/projects/thing/hold.py\n"
          "#  Used by   : projects/thing/run.py.\n"
          "#  Uses      : nothing.\n"
          "#  Description: holds a number at one or above.\n"
          "#  User intention: Andrew asked for a floor on the count.\n")
NOTED = 'def hold(number):\n    """Intention: never let the count go under one."""\n    return max(1, number)\n'
BARE = "def hold(number):\n    return max(1, number)\n"


def test_the_header_needs_the_pathway_on_the_first_line():
    """Intention (D12): the path anywhere in the top 80 lines, or only the
    file's name, passed; projects/skills/code/bellman_ford_algorithm.py got
    in like that."""
    loose = "# hold.py\n# used by: run.py\n# uses: nothing\n# description: x\n# user intention: y\n" + NOTED
    assert c.CARRIES_ITS_HEADER.check(loose, {"target": TARGET})
    assert c.CARRIES_ITS_HEADER.check(HEADER + NOTED, {"target": TARGET}) == ""


def test_the_header_names_each_field_as_the_tree_does():
    """Intention: the five fields by the names the tree checks, so a file the
    gate lets in is a file the tree's own check passes."""
    missing = HEADER.replace("#  Uses      : nothing.\n", "")
    said = c.CARRIES_ITS_HEADER.check(missing + NOTED, {"target": TARGET})
    assert "Uses" in said


def test_every_part_the_gate_lets_in_has_a_note():
    """Intention: a function with no note of its own is refused, and the
    complaint names it."""
    said = c.EVERY_PART_HAS_A_NOTE.check(HEADER + BARE, {"target": TARGET})
    assert "hold" in said
    assert c.EVERY_PART_HAS_A_NOTE.check(HEADER + NOTED, {"target": TARGET}) == ""


def test_a_test_file_is_not_asked_for_notes():
    """Intention: a test says what it is for in its name, as in the tree."""
    test = HEADER + "def test_it():\n    assert True\n"
    assert c.EVERY_PART_HAS_A_NOTE.check(test, {"target": "projects/thing/tests/test_hold.py"}) == ""


def test_the_build_and_revise_contracts_ask_for_notes():
    """Intention: the rule is on the spines that write code."""
    for kind in ("build", "revise"):
        assert c.EVERY_PART_HAS_A_NOTE in CONTRACTS[kind].clauses
