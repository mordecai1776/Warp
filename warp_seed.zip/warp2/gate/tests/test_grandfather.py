# WARP2/warp2/gate/tests/test_grandfather.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_grandfather.py
#  Used by   : pytest.
#  Uses      : warp2/gate/{guard,grandfather,owed}.py, warp2/work/{sources,
#              truth}.py, warp2/models/fleet.py, warp2/store/store.py.
#  Description:
#    Grandfathering held to its rule — a change is judged on what it changes —
#    and the debt it leaves held to being paid: stated once, made into work,
#    and ended only when the file on disk meets the rule.
#  User intention (Andrew, 2026-09-23): "things should be grandfathered in but
#    there should be a system to update things like that."
# ============================================================================
from __future__ import annotations

from warp2.gate.grandfather import items, split
from warp2.gate.guard import Gate
from warp2.gate.owed import OWES, Owed
from warp2.store.store import Store

OLD = "def hold(number, context):\n    return max(1, number)\n"


def _store(tmp_path):
    return Store(tmp_path / "state", run="gf", view_path=tmp_path / "view.sqlite3")


def _judge(gate, content, previous, owed=()):
    context = {"target": "projects/a/hold.py", "previous": previous, "owed": list(owed)}
    return gate.judge({"work_kind": "build", "target": "projects/a/hold.py",
                       "content": content, "context": context})


def test_a_rule_the_file_already_broke_does_not_refuse_the_change(tmp_path):
    """Intention: the context parameter was there before; the change is let through for it, and says so."""
    gate = Gate(_store(tmp_path))
    verdict = _judge(gate, "def hold(number, context):\n    return max(2, number)\n", OLD)
    assert verdict["accepted"] and "uses_every_parameter" in verdict["grandfathered"]


def test_anything_new_the_change_breaks_still_refuses(tmp_path):
    """Intention: a NEW context parameter is the change's own, and it stands."""
    gate = Gate(_store(tmp_path))
    verdict = _judge(gate, "def hold(number, context, other):\n    return max(2, number)\n", OLD)
    assert not verdict["accepted"] and "other" in " ".join(verdict["issues"])


def test_the_rule_an_update_is_paying_is_not_grandfathered(tmp_path):
    """Intention: the owed rule is the reason the work exists, so it is judged in full."""
    gate = Gate(_store(tmp_path))
    verdict = _judge(gate, "def hold(number, context):\n    return max(2, number)\n", OLD,
                     owed=("uses_every_parameter",))
    assert not verdict["accepted"]


def test_a_file_that_does_not_parse_is_never_let_through():
    """Intention: nothing in it runs; the bad is still kicked out."""
    said = [("parses", "does not parse: line 1")]
    stand, through = split(said, {"parses": "does not parse: line 1"})
    assert stand == said and through == []
    assert items("parameter declared and never used: a(x), b(y); use it") == {"a(x)", "b(y)"}


def test_a_debt_is_stated_made_into_work_and_ended_when_paid(tmp_path):
    """Intention: the sweep states it, the detector raises it, the check ends it once the file on disk meets the rule."""
    from warp2.work.sources import owed_updates
    from warp2.work.truth import _update_done
    store = _store(tmp_path)
    (tmp_path / "projects" / "a").mkdir(parents=True)
    path = tmp_path / "projects" / "a" / "hold.py"
    path.write_text(OLD, encoding="utf-8")
    store.assert_fact("warp2:root", "has", attr="path", value=str(tmp_path))
    owed = Owed(tmp_path, store)
    first = owed.sweep()
    assert first["stated"] >= 1 and ("projects/a/hold.py", "uses_every_parameter") in owed.held()
    assert owed.sweep()["stated"] == 0
    work = [w for w in owed_updates(store) if w["target"] == "projects/a/hold.py"
            and "uses_every_parameter" in w["id"]]
    assert work and work[0]["kind"] == "update"
    handle = work[0]["id"].split(":", 1)[1]
    assert _update_done(store, "projects/a/hold.py", key=handle)[0] is False
    path.write_text("def hold(number):\n    return max(1, number)\n", encoding="utf-8")
    assert _update_done(store, "projects/a/hold.py", key=handle)[0] is True
    assert not store.current(subject="projects/a/hold.py", attr=OWES + "uses_every_parameter")


def test_an_update_is_chosen_as_a_revision(tmp_path):
    """Intention: the roster names `revise`; an update is chosen and scored as one."""
    from warp2.models.fleet import Fleet, asked_as
    from warp2.store.tagnet import TagNet
    fleet = Fleet(TagNet(_store(tmp_path)))
    fleet.enlist("reviser", ask=lambda p: "", kinds=("revise",))
    assert asked_as("update") == "revise" and fleet.names("update") == ["reviser"]
