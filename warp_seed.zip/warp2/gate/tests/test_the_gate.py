# WARP2/warp2/gate/tests/test_the_gate.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_the_gate.py
#  Used by   : pytest.
#  Uses      : warp2/gate/*, warp2/store/store.py, warp2/record/pathway.py.
#  Description:
#    The gate held to its own rules: every clause is tested by its own two
#    examples, nothing is judged by a rule it was not shown, a watch can never
#    refuse, and the gate keeps a scoreboard about itself.
#  User intention (Andrew, 2026-08-17):
#    "The pure intention can be tested." Including the ones this file states.
# ============================================================================
from __future__ import annotations


def test_assertion_check_understands_receiver_closures():
    """Intention: helper closures may capture self, but unrelated functions may not."""
    from warp2.gate.checks import _asserts_behaviour
    valid = '''class Widget:
    def method(self):
        def callback():
            return self.value
        return callback
def test_result():
    widget = Widget()
    widget.value = 3
    assert widget.method()() == 3
'''
    assert _asserts_behaviour(valid, {}) == ""
    assert "without defining" in _asserts_behaviour(valid + '''
def test_bad():
    self.assertEqual(1, 1)
''', {})
    assert _asserts_behaviour('''def test_local():
    self = 3
    assert self == 3
''', {}) == ""

import sys
from pathlib import Path

import pytest

from warp2.gate import checks
from warp2.gate.clause import CLAUSE_MAX_CHARS, Clause, Watch
from warp2.gate.contracts import CONTRACTS, contract_for, obligations
from warp2.gate.guard import Gate
from warp2.gate.scoreboard import Scoreboard
from warp2.record.pathway import Refusal
from warp2.store.store import Store


def _store(tmp_path):
    return Store(tmp_path / "state", run="gate", view_path=tmp_path / "view.sqlite3")


def _clauses():
    seen = {}
    for contract in CONTRACTS.values():
        for clause in contract.clauses:
            seen[clause.name] = clause
    return sorted(seen.values(), key=lambda c: c.name)


# --------------------------------------------------------------------------
# The ratchet: a verifier is a program, and an untested predicate is a hole.
# --------------------------------------------------------------------------

def test_every_clause_accepts_something_and_refuses_something():
    """A CLAUSE NOTHING CAN PASS IS A STOP, NOT A STANDARD.

    Intention: WARP found one of those by hand — an intention-coverage rule
    that demanded half a 31-word intention's content words, so nine
    consecutive generations were refused and none could have passed. It was
    recalibrated, and nothing would have found the second occurrence. Every
    clause here carries the example it accepts and the example it refuses, and
    this runs both. A clause that cannot show something it accepts is
    unpassable; one that cannot show something it refuses is inert.
    """
    unpassable, inert, unproven = [], [], []
    for clause in _clauses():
        context = checks.EXAMPLE_CONTEXT.get(clause.name, {})
        if not clause.passes or not clause.fails:
            unproven.append(clause.name)
            continue
        if clause.failure(clause.passes, context):
            unpassable.append(f"{clause.name}: {clause.failure(clause.passes, context)}")
        if not clause.failure(clause.fails, context):
            inert.append(clause.name)
    assert not unproven, "no example pair on: " + ", ".join(unproven)
    assert not unpassable, "refuses its own passing example: " + "; ".join(unpassable)
    assert not inert, "accepts its own failing example: " + ", ".join(inert)


def test_every_stated_obligation_fits_on_one_line():
    # Intention: a clause too long to say plainly is nearly always two
    # obligations wearing a coat. The cap is a constraint on the design.
    too_long = [f"{c.name} ({len(c.intention)})" for c in _clauses()
                if len(c.intention) > CLAUSE_MAX_CHARS]
    assert not too_long, "over the clause cap: " + ", ".join(too_long)


def test_a_broken_check_refuses_rather_than_passing_work_through(tmp_path):
    """THE GATE FAILS CLOSED.

    Intention: a predicate that raises has not said the work is acceptable. It
    has said nothing, and nothing is not permission. Measured in the field:
    eleven realistic verifier bugs let through 56-87% of incorrect work.
    """
    def explodes(_code, _ctx):
        raise ValueError("the check itself is broken")

    clause = Clause("broken", "do the thing", explodes)
    complaint = clause.failure("anything at all")
    assert "could not be decided" in complaint
    assert "ValueError" in complaint


# --------------------------------------------------------------------------
# Nothing is judged by a rule it was not shown.
# --------------------------------------------------------------------------

def test_a_clause_that_names_a_thing_carries_the_thing():
    """THE MOST EXPENSIVE DEFECT IN WARP, IN ONE ASSERTION.

    Intention: "the paired test imports names this file does not define" is
    372 of 1,238 recorded complaints — 30%, larger than syntax errors and
    placeholders combined — and the names were known at judging time and never
    once put in front of the model.
    """
    lines = obligations("revise", {"required_names": ("hold", "release")})
    assert "exactly: hold, release" in lines
    told = obligations("test", {"artifact_module": "shrink"})
    assert "import the artifact module shrink" in told
    proved = obligations("design_test", {"proves_intention": "the guard holds at one"})
    assert '"the guard holds at one"' in proved


def test_every_rule_that_can_refuse_is_in_what_the_work_is_told():
    """Intention: everything here is a thing that will be mechanically checked,
    and nothing that will be checked is left out. That sentence is the whole
    contract, so it is asserted rather than believed."""
    for kind, contract in CONTRACTS.items():
        told = obligations(kind, {})
        for clause in contract.clauses:
            assert clause.line({}) in told, f"{kind} judges by an unstated rule: {clause.name}"


def test_a_watch_is_never_in_what_the_work_is_told_and_never_refuses(tmp_path):
    """THE HELD-BACK HALF, AND THE LINE IT MAY NOT CROSS.

    Intention: held-out measurement is the only way to see gaming — visible
    suites saturate while held-out scores diverge. Andrew's rule is that
    nothing may be judged by an unstated rule. Both hold: a watch is unstated
    AND it may only record.
    """
    gate = Gate(_store(tmp_path))
    # Intention: the fixture carries the file header the gate now asks for (#126).
    swallowing = ("# Pathway   : x.py\n"
                  "# Used by   : nothing yet.\n"
                  "# Uses      : nothing.\n"
                  "# Description: holds a number at one.\n"
                  "# User intention: a floor on the count.\n"
                  "def hold(number):\n"
                  "    try:\n"
                  "        return max(1, number)\n"
                  "    except Exception:\n"
                  "        pass\n")
    verdict = gate.judge({"work_kind": "build", "target": "x.py", "content": swallowing,
                          "context": {"proves_intention": "hold the number at one"}})
    assert verdict["accepted"] is True
    assert [note["watch"] for note in verdict["watched"]] == ["swallows_errors"]
    told = obligations("build", {})
    assert "handler" not in told


# --------------------------------------------------------------------------
# What the gate does to an action.
# --------------------------------------------------------------------------

def test_every_unmet_obligation_comes_back_at_once(tmp_path):
    # Intention: work handed one complaint fixes one thing and is refused for
    # the next. WARP measured 23 identical refusals over ten days from that.
    gate = Gate(_store(tmp_path))
    bad = "def hold(number, context):\n    pass  # your code here\n"
    verdict = gate.judge({"work_kind": "build", "target": "x.py", "content": bad})
    assert len(verdict["issues"]) >= 3
    assert any("empty function bodies" in i for i in verdict["issues"])
    assert any("placeholder" in i for i in verdict["issues"])


def test_an_action_nobody_has_written_a_contract_for_is_refused(tmp_path):
    """Intention: None is not a permissive default. An action nobody has said
    anything about is an action nobody granted, and the right answer to that is
    a refusal rather than a shrug."""
    gate = Gate(_store(tmp_path))
    verdict = gate.judge({"work_kind": "improvise", "target": "x.py",
                          "content": "def hold(n):\n    return n + 1\n"})
    assert verdict["accepted"] is False
    assert "no contract" in verdict["said"]
    assert contract_for("improvise") is None


def test_the_gate_has_no_opinion_about_actions_that_carry_no_artifact(tmp_path):
    # Intention: a gate that judges everything is a gate nobody can reason
    # about. "Nothing to judge" and "this is fine" are different answers.
    gate = Gate(_store(tmp_path))
    verdict = gate.judge({"verb": "index_tree", "target": "tree"})
    assert verdict["decided"] is False
    assert gate.judged == 0


def test_where_a_kind_may_write_is_part_of_its_contract(tmp_path):
    """Intention: "restricted to a smaller set", mechanically. Fix the DEFAULT
    so a new call site cannot quietly acquire a capability nobody granted.

    It reads `writes` and not `produced`, and the difference is not cosmetic:
    `produced` is lineage — record subjects the causal slice walks — while
    `writes` is the filesystem. Reading one as the other refused the loop's own
    work for writing to `pkg/thing.py::hold`, which is not a path.
    """
    gate = Gate(_store(tmp_path))
    good = ("# Pathway   : projects/apex/tests/test_shrink.py\n"
            "# Used by   : pytest.\n"
            "# Uses      : shrink.py.\n"
            "# Description: shows the shrink guard holds.\n"
            "# User intention: a floor on the count.\n"
            "import shrink\n\ndef test_it():\n    assert shrink.hold(0) == 1\n")
    inside = gate.judge({"work_kind": "test", "target": "t.py", "content": good,
                         "writes": ("projects/apex/tests/test_shrink.py",),
                         "context": {"artifact_module": "shrink"}})
    assert inside["accepted"] is True
    outside = gate.judge({"work_kind": "test", "target": "t.py", "content": good,
                          "writes": ("models/seated/weights.py",),
                          "context": {"artifact_module": "shrink"}})
    assert outside["accepted"] is False
    assert "may write only" in outside["said"]


def test_the_gate_refuses_through_the_door_as_a_recorded_outcome(tmp_path):
    """Intention: a refusal is a RESULT — evidence about what the system will
    not do. It goes in the record exactly like a success, which is why the
    pathway carries it rather than letting it crash a run."""
    from warp2.record.pathway import Pathway
    store = _store(tmp_path)
    gate = Gate(store)
    door = Pathway(tmp_path, tmp_path / "record", "gate-run", guard=gate)
    result = door.act("write_artifact", lambda: "written", target="x.py",
                      mutating=True, score=500, work_kind="build",
                      content="def hold(n):\n    pass\n")
    assert result["outcome"] == "refused"
    assert "empty function bodies" in result["error"]
    assert [e["outcome"] for e in door.entries() if e["verb"] == "write_artifact"] == ["refused"]


def test_a_refusal_raised_by_the_guard_is_a_refusal_not_a_crash(tmp_path):
    gate = Gate(_store(tmp_path))
    with pytest.raises(Refusal):
        gate({"work_kind": "build", "target": "x.py", "content": "def hold(n):\n    pass\n"})


# --------------------------------------------------------------------------
# The gate's own scoreboard — the thing WARP could not answer about itself.
# --------------------------------------------------------------------------

def test_both_sides_of_a_judgement_are_counted(tmp_path):
    """Intention: counting only the complaints is how a rule set ends up with a
    member nothing has ever satisfied and nobody notices."""
    gate = Gate(_store(tmp_path))
    gate.judge({"work_kind": "build", "target": "x.py",
                "content": "def hold(n):\n    pass\n"})
    board = gate.scoreboard
    assert board.count("no_empty_bodies", "fired") == 1
    assert board.count("parses", "passed") == 1
    assert board.standing("no_empty_bodies")["judged"] == 1


def test_a_complaint_the_next_attempt_fixed_counts_as_repaired(tmp_path):
    """THE HONEST MEASURE OF WHETHER A COMPLAINT WAS ACTIONABLE.

    Intention: WARP's own data can be joined on six targets with more than one
    attempt, so it could not answer this at all. A clause that complains and is
    never once fixed is either unstatable or unpassable, and both are defects
    in the gate rather than in the work.
    """
    gate = Gate(_store(tmp_path))
    gate.judge({"work_kind": "build", "target": "x.py",
                "content": "def hold(n):\n    pass\n"})
    gate.judge({"work_kind": "build", "target": "x.py",
                "content": "def hold(number):\n    return max(1, number)\n",
                "context": {"proves_intention": "hold the number at one"}})
    assert gate.scoreboard.standing("no_empty_bodies")["repaired"] == 1
    assert gate.scoreboard.standing("no_empty_bodies")["repair_rate"] == 1.0


def test_a_clause_nothing_ever_passes_is_named_as_a_defect_in_the_gate(tmp_path):
    # Intention: the failure WARP found by hand, found mechanically instead.
    gate = Gate(_store(tmp_path))
    for _ in range(3):
        gate.judge({"work_kind": "build", "target": "x.py",
                    "content": "def hold(n):\n    pass\n"})
    report = gate.health()
    assert "no_empty_bodies" in report["unpassable"]
    assert report["judged"] == 3 and report["refused"] == 3 and report["accepted"] == 0


def test_a_clause_that_complains_and_is_never_fixed_is_called_out(tmp_path, monkeypatch):
    """Intention: the cost of a clause nothing can satisfy is every attempt it
    refuses, and that cost is paid per attempt — so the doubt threshold is
    small and it is a setting."""
    from warp2.gate import scoreboard as board_mod
    monkeypatch.setattr(board_mod, "UNREPAIRED_BEFORE_DOUBT", 2)
    gate = Gate(_store(tmp_path))
    for index in range(2):
        gate.judge({"work_kind": "build", "target": f"x{index}.py",
                    "content": "def hold(n):\n    pass\n"})
    assert "no_empty_bodies" in gate.health()["unactionable"]


def test_a_watch_that_fires_is_recorded_against_the_watch(tmp_path):
    # Intention: the work did nothing wrong by any rule it was shown. What a
    # watch firing is evidence about is the gate.
    store = _store(tmp_path)
    gate = Gate(store)
    gate.judge({"work_kind": "build", "target": "x.py",
                "content": ("def hold(number):\n    try:\n        return number\n"
                            "    except Exception:\n        pass\n")})
    assert gate.scoreboard.count("watch:swallows_errors", "seen") == 1
    seen = store.current(subject="watch:swallows_errors", attr="last_seen_on")
    assert seen[0]["value"] == "x.py"


def test_a_watch_that_breaks_does_not_stop_anything():
    """Intention: a broken watch is a note, never a refusal. It has no power to
    stop anything, so failing closed would mean failing loudly for no gain —
    the opposite of the rule for a clause, and for the opposite reason."""
    def explodes(_code, _ctx):
        raise RuntimeError("broken watch")

    watch = Watch("broken", explodes)
    assert "could not look" in watch.note("anything")


# The bytes the live run actually produced, kept verbatim. A regression test
# written from a paraphrase tests the paraphrase.
_FROM_THE_RUN = (
    "import os\n"
    "from pathlib import Path\n"
    "from typing import List, Dict, Any, Optional\n"
    "import pytest\n"
    "from artifact import Artifact\n"
    "\n"
    "def test_artifact_works():\n"
    "    artifact = Artifact()\n"
    "    result = artifact.process_data([\"example\", \"data\"])\n"
    "    assert result == [\"processed_example\", \"processed_data\"]\n"
)


def test_a_test_that_cannot_import_is_refused_before_it_is_written():
    """THE SIXTY FILES OF 2026-08-31, REFUSED.

    Intention: this file parses, defines a test_ function, asserts something
    other than a constant and has no placeholder text — so every clause the
    gate had said yes to it, it was written to disk, and it then failed at
    collection because nothing called `Artifact` has ever existed in this tree.
    Sixty attempts, zero closed. `Artifact` is imported here, so the import
    itself is not the tell; what gives it away is that no name it uses can be
    traced to anything. A gate that checks shape and never checks that the
    names resolve is a gate that accepts unimportable code.
    """
    complaint = checks.NAMES_COME_FROM_SOMEWHERE.failure(
        "from pathlib import Path\n\n"
        "def test_it():\n"
        "    assert Artifact().get_result() == 1\n")
    assert "Artifact" in complaint
    contract = contract_for("test")
    assert any("never imports or defines" in issue
               for issue in contract.failures(_FROM_THE_RUN.replace(
                   "from artifact import Artifact\n", ""), {}))


def test_the_clause_refuses_nothing_this_tree_actually_contains():
    """Intention: A CHECKER'S FALSE REFUSAL COSTS REAL WORK; ITS MISS COSTS ONE
    MORE ATTEMPT. So the clause is deliberately flat rather than a scope
    analysis, and the evidence for that choice is this: run over every python
    file WARP2 has, it refuses none of them. Measured when it was added — 377
    of 393 files in the whole tree clean, and all sixteen it refused were
    generated junk. This asserts the half that must never regress.
    """
    import pathlib
    here = pathlib.Path(checks.__file__).resolve().parent.parent
    refused = []
    for path in sorted(here.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if checks.NAMES_COME_FROM_SOMEWHERE.failure(text):
            refused.append(path.name)
    assert refused == []


def test_pytest_fixtures_and_the_ordinary_shapes_are_not_refused():
    """Intention: the forms python binds a name in are a list, and a missing
    one shows up as a refusal of correct code. Every shape that has ever
    appeared in a real test file, in one file, so a missed binding rule fails
    here rather than in front of a model that did nothing wrong."""
    ordinary = (
        "import json\n"
        "import pytest\n"
        "from pathlib import Path as P\n"
        "\n"
        "TOP = 1\n"
        "\n"
        "@pytest.fixture\n"
        "def thing():\n"
        "    return {\"a\": 1}\n"
        "\n"
        "def test_it(thing, tmp_path, capsys):\n"
        "    doubled = [n * 2 for n in range(3)]\n"
        "    for key, value in thing.items():\n"
        "        assert key and value\n"
        "    with open(tmp_path / \"f\", \"w\") as handle:\n"
        "        handle.write(json.dumps(doubled))\n"
        "    try:\n"
        "        raise ValueError(\"x\")\n"
        "    except ValueError as exc:\n"
        "        assert str(exc) == \"x\"\n"
        "    if (total := sum(doubled)) > 0:\n"
        "        assert total == TOP * 6\n"
        "    assert sorted(doubled, key=lambda n: -n)[0] == 4\n"
        "    assert P(tmp_path).exists() and capsys is not None\n"
    )
    assert checks.NAMES_COME_FROM_SOMEWHERE.failure(ordinary) == ""


def test_the_line_and_the_check_agree_when_there_is_nothing_to_name():
    """THE FAILURE THIS FILE EXISTS TO PREVENT, ALMOST REBUILT, 2026-08-31.

    Intention: `imports_artifact` was taught to REFUSE when no artifact is
    named, but its spoken line still fell back to the bare intention — so the
    work would have been told "import the artifact module" with no module in
    the world to import, and then refused for not importing one. That is
    `clause.py`'s own most expensive lesson word for word: a rule stated in one
    place and checked in another, and work punished for an instruction nobody
    could follow. Caught in a dry run against the live store, where two of the
    six projects contain no module at all.
    """
    spoken = checks.IMPORTS_ARTIFACT.line({})
    assert "import the artifact module" not in spoken
    assert "no artifact" in spoken
    # And what it says is what it does: the check refuses that same unit.
    assert checks.IMPORTS_ARTIFACT.failure(
        "def test_it():\n    assert 1 == 1\n", {}) != ""
    # While a named artifact still speaks and checks the ordinary way.
    named = {"artifact_module": "gui"}
    assert checks.IMPORTS_ARTIFACT.line(named) == "import the artifact module gui"
    assert checks.IMPORTS_ARTIFACT.failure(
        "import gui\n\ndef test_it():\n    assert gui.draw() == 1\n", named) == ""


def test_proof_puts_the_project_on_the_path_and_never_the_tree(tmp_path):
    """THE BOUNDARY THAT MOVED, AND THE ONE THAT DID NOT.

    Intention: the old rule put only the artifact's own folder on the path, on
    the principle that a verification able to import the whole tree is verifying
    the tree. The principle is kept; "one folder" was the wrong reading of it,
    because a package-shaped project could not be proven a file at a time and
    the answer was never for the code to flatten itself to suit the runner.

    So: the owning PROJECT is importable, and the tree, warp2, and any
    neighbouring project are not.
    """
    from warp2.gate.proof import Proof

    root = tmp_path
    deep = root / "projects" / "eye" / "apex" / "core"
    (deep / "tests").mkdir(parents=True)
    artifact = deep / "part.py"
    artifact.write_text("x = 1\n", encoding="utf-8")
    test = deep / "tests" / "test_part.py"
    test.write_text("def test_x():\n    assert True\n", encoding="utf-8")

    proof = Proof.__new__(Proof)
    proof.root = root
    roots = proof._importable_roots(artifact, test)

    assert str(root / "projects" / "eye") in roots, "the project is importable"
    assert str(deep) in roots and str(deep / "tests") in roots
    assert str(root) not in roots, "the tree is NOT importable"
    assert str(root / "projects") not in roots, "nor every project at once"
    assert not any(r.endswith("warp2") for r in roots)


def test_a_flat_project_is_unchanged_by_the_wider_boundary(tmp_path):
    """Intention: the change had to buy the eye its proof without altering what
    a flat project already got. Here the project home IS the artifact's folder,
    so the roots come out as the same two they always were."""
    from warp2.gate.proof import Proof

    root = tmp_path
    home = root / "projects" / "master"
    (home / "tests").mkdir(parents=True)
    artifact = home / "batches.py"
    artifact.write_text("x = 1\n", encoding="utf-8")
    test = home / "tests" / "test_batches.py"
    test.write_text("def test_x():\n    assert True\n", encoding="utf-8")

    proof = Proof.__new__(Proof)
    proof.root = root
    assert proof._importable_roots(artifact, test) == [
        str(home), str(home / "tests")]


def test_something_outside_projects_gets_no_project_added(tmp_path):
    """Intention: warp2's own files are not in a project, and nothing may
    quietly hand them a wider path than they had. The absence of a home is a
    normal answer here, not a fault."""
    from warp2.gate.proof import Proof

    root = tmp_path
    where = root / "warp2" / "store"
    (where / "tests").mkdir(parents=True)
    artifact = where / "context.py"
    artifact.write_text("x = 1\n", encoding="utf-8")
    test = where / "tests" / "test_context.py"
    test.write_text("def test_x():\n    assert True\n", encoding="utf-8")

    proof = Proof.__new__(Proof)
    proof.root = root
    assert proof._project_home(artifact) is None
    assert proof._importable_roots(artifact, test) == [
        str(where), str(where / "tests")]


def test_proof_runs_the_test_against_an_empty_bytecode_cache(tmp_path, monkeypatch):
    """PROOF THAT CAN BE SERVED STALE BYTECODE IS NOT PROOF.

    Intention: this line used to read `PYTHONDONTWRITEBYTECODE`, which was
    measured to stop writes and not reads — so a cached .pyc beside an artifact
    ran the OLD code while the gate recorded a verdict about the new one. The
    repair is an EMPTY cache directory per run, and it needs a test at the call
    site: reverting the line survived every other test in this file.
    """
    from warp2.gate import proof as proof_module
    from warp2.gate.proof import Proof

    seen = {}

    def _capture(command, seconds, stop=None, cwd=None, env=None):
        seen["env"] = dict(env or {})
        seen["cache"] = (env or {}).get("PYTHONPYCACHEPREFIX")
        seen["existed"] = Path(seen["cache"]).is_dir() if seen["cache"] else False
        seen["empty"] = (seen["existed"]
                         and not any(Path(seen["cache"]).iterdir()))
        return {"how": "finished", "code": 0, "said": "1 passed"}

    monkeypatch.setattr(proof_module, "run_watched", _capture)
    monkeypatch.setattr(proof_module.children, "FINISHED", "finished",
                        raising=False)

    home = tmp_path / "projects" / "thing"
    (home / "tests").mkdir(parents=True)
    artifact = home / "part.py"
    artifact.write_text("x = 1\n", encoding="utf-8")
    test = home / "tests" / "test_part.py"
    test.write_text("def test_x():\n    assert True\n", encoding="utf-8")

    made = Proof.__new__(Proof)
    made.root = tmp_path
    made.python = sys.executable
    made.stop = None
    made._run(test, artifact, 5.0)

    assert seen["cache"], "a cache directory must be named at all"
    assert Path(seen["cache"]).resolve() not in [tmp_path.resolve(),
                                                 *tmp_path.resolve().parents], (
        "and it must not be inside the tree being verified")
    assert seen["existed"] and seen["empty"], (
        "an empty directory is the only thing that cannot serve an old answer; "
        "PYTHONDONTWRITEBYTECODE alone was measured not to")


def test_the_cache_proof_used_does_not_outlive_the_run(tmp_path, monkeypatch):
    """Intention: a scratch cache that survived would be the reused directory
    that goes stale on its next use, so cleaning up is the property and not
    tidiness. Two runs must not share one."""
    from warp2.gate import proof as proof_module
    from warp2.gate.proof import Proof

    seen = []

    def _capture(command, seconds, stop=None, cwd=None, env=None):
        seen.append((env or {}).get("PYTHONPYCACHEPREFIX"))
        return {"how": "finished", "code": 0, "said": "1 passed"}

    monkeypatch.setattr(proof_module, "run_watched", _capture)
    monkeypatch.setattr(proof_module.children, "FINISHED", "finished",
                        raising=False)

    home = tmp_path / "projects" / "thing"
    (home / "tests").mkdir(parents=True)
    artifact = home / "part.py"
    artifact.write_text("x = 1\n", encoding="utf-8")
    test = home / "tests" / "test_part.py"
    test.write_text("def test_x():\n    assert True\n", encoding="utf-8")

    made = Proof.__new__(Proof)
    made.root = tmp_path
    made.python = sys.executable
    made.stop = None
    made._run(test, artifact, 5.0)
    made._run(test, artifact, 5.0)

    assert len(set(seen)) == 2, "a different cache each run"
    for where in seen:
        assert not Path(where).exists(), "and neither survives its run"


def test_a_module_in_a_package_may_import_relatively_and_one_outside_may_not():
    """THE RULE THAT WAS REFUSING WORKING CODE.

    Intention: the old reason — "relative imports break standalone pytest
    collection" — was true while the proof runner put only the artifact's own
    folder on the path. Since the boundary moved to the owning project, a
    module inside a package is reached as `apex.core.x` and its relative
    imports resolve as Python intends. Measured 2026-09-04: 22 of the eye's 24
    core modules are written that way and 279 of its tests pass, and the gate
    would have refused every one.

    Outside a package it still cannot work, and is still refused.
    """
    body = "from .neighbour import thing\n\n\ndef hold(n):\n    return thing(n)\n"
    build = contract_for("build")

    inside = [x for x in build.failures(body, {"in_package": True,
                                               "artifact_path": "p/pkg/a.py"})
              if "relative" in x]
    assert inside == [], "in a package, this is ordinary Python"

    outside = [x for x in build.failures(body, {"in_package": False,
                                                "artifact_path": "p/flat/a.py"})
               if "relative" in x]
    assert len(outside) == 1
    assert "no __init__.py beside it" in outside[0], "and it says why, not just no"
    assert "p/flat/a.py" in outside[0], "naming the file it is talking about"


def test_a_test_may_never_import_relatively_wherever_it_sits():
    """Intention: the half of the old rule that was always right, kept absolute.
    A test is handed to pytest as a path, so it has no parent package to be
    relative to — being inside a package does not change that, which is exactly
    the case a single shared rule would have got wrong."""
    body = ("from .thing import hold\n\n\ndef test_it():\n    assert hold(0) == 1\n")
    test = contract_for("test")

    for in_package in (True, False):
        found = [x for x in test.failures(body, {"in_package": in_package,
                                                 "artifact_module": "thing"})
                 if "relative" in x]
        assert len(found) == 1, f"refused whether or not in a package ({in_package})"
        assert "collected by path" in found[0]


def test_a_star_import_is_still_refused_now_that_the_rule_was_split():
    """Intention: the wildcard half was tangled with the relative half in one
    function returning one message. Splitting them is where a rule quietly goes
    missing, so the survivor is asserted on its own."""
    build = contract_for("build")
    found = [x for x in build.failures("from os import *\n\n\ndef hold(n):\n    return n\n", {})
             if "wildcard" in x]
    assert found and "not accepted" in found[0]


def test_the_same_file_twice_is_one_answer_submitted_twice(tmp_path):
    """MEASURED, AND IT PASSED EVERY OTHER CLAUSE.

    Intention: five areas of CENTERING_IMAGE were built with one byte-identical
    file and all five units closed, because a build closes when the file exists
    and every other clause judges a file on its own. The intention clause did
    not catch it either — its bar is two distinctive words, a calibration paid
    for in refused generations that must not be raised, and one file about
    populations and data honestly meets it for four of those five intentions.
    What was missing was any question about the file next to it.
    """
    from warp2.gate.checks import NOT_A_COPY
    from warp2.util import sha256_hex

    code = "def refeed(data):\n    return dict(data)\n"
    alone = {"other_artifacts": {}}
    assert NOT_A_COPY.failure(code, alone) == ""

    beside_a_twin = {"other_artifacts": {
        sha256_hex(code.encode("utf-8")): "projects/thing/other_part.py"}}
    complaint = NOT_A_COPY.failure(code, beside_a_twin)
    assert "projects/thing/other_part.py" in complaint

    # A different file beside the same twin is fine.
    other = "def judge(seen):\n    return bool(seen)\n"
    assert NOT_A_COPY.failure(other, beside_a_twin) == ""

    # And the work is told before it writes, not only after.
    assert "does a different job" in NOT_A_COPY.line(beside_a_twin)


def test_a_refusal_no_work_could_answer_is_not_the_clause_failing():
    """THE GATE REPORTING A DEFECT IN SOURCING AS A DEFECT IN ITSELF.

    Intention: `imports_artifact` read 7 fired, 0% repaired for months after
    the hole was shut, and `doctor` called it a defect in the gate every run.
    All seven were "no artifact was named for this work" — a refusal aimed at
    whoever raised the unit, which no work could ever have answered. Counting
    those as unrepaired firings is what made a clause that was doing its job
    exactly right look broken.
    """
    from warp2.gate import checks as c

    named = {"artifact_module": "shrink"}
    unnamed: dict = {}
    work = "def test_it():\n    assert 1 == 1\n"

    about_work = c.IMPORTS_ARTIFACT.failure(work, named)
    about_unit = c.IMPORTS_ARTIFACT.failure(work, unnamed)
    assert about_work and about_unit, "both are still refusals"
    assert not c.IMPORTS_ARTIFACT.blames_the_unit(about_work)
    assert c.IMPORTS_ARTIFACT.blames_the_unit(about_unit)


def test_a_blocked_complaint_is_counted_in_its_own_column(tmp_path):
    from warp2.gate.scoreboard import Scoreboard
    from warp2.store.store import Store

    board = Scoreboard(Store(tmp_path))
    for _ in range(6):
        board.record("test", "project:empty", ["imports_artifact", "parses"],
                     ["imports_artifact"], blocked=["imports_artifact"])
    standing = board.standing("imports_artifact")
    assert standing["blocked"] == 6
    assert standing["fired"] == 0
    health = board.health(["imports_artifact", "parses"])
    assert "imports_artifact" not in health["unactionable"]
    # But it is not silent either: bad units are still being raised.
    assert "imports_artifact" in health["blocking"]


def test_a_recount_says_when_it_started_and_why(tmp_path):
    from warp2.gate.scoreboard import Scoreboard
    from warp2.store.store import Store

    board = Scoreboard(Store(tmp_path))
    for _ in range(6):
        board.record("test", "a", ["imports_artifact"], ["imports_artifact"])
    assert "imports_artifact" in board.health(["imports_artifact"])["unactionable"]

    done = board.recount(["imports_artifact"], why="counted before blocked was split out")
    assert done["recounted"] == ["imports_artifact"]
    standing = board.standing("imports_artifact")
    assert standing["fired"] == 0 and standing["counted_from"] == done["from"]
    assert "imports_artifact" not in board.health(["imports_artifact"])["unactionable"]


def test_one_pass_over_the_clauses_gives_the_name_and_what_it_said():
    from warp2.gate.contracts import contract_for

    said = contract_for("test").complaints("def broken(:\n", {})
    names = [name for name, _ in said]
    assert len(names) == len(set(names)), "every clause once"
    assert any(complaint for _name, complaint in said)


def test_a_marker_inside_a_string_is_talked_about_not_left_unfinished():
    """Intention: found 2026-09-24 — worker.py's real test holds bad files as
    data ("pass  # TODO" in a string), and the gate called the test unfinished,
    so it could never prove anything. A comment or docstring still counts."""
    from warp2.gate.checks import _no_not_implemented, _no_todo_markers
    data = 'BAD = "def f():\\n    pass  # TODO: later\\n    raise NotImplementedError\\n"\n'
    assert _no_todo_markers(data, {}) == ""
    assert _no_not_implemented(data, {}) == ""
    assert _no_todo_markers("x = 1  # TODO: later\n", {})
    assert _no_todo_markers('def f():\n    """TODO: later"""\n    return 1\n', {})
    assert _no_not_implemented("def f():\n    raise NotImplementedError\n", {})
