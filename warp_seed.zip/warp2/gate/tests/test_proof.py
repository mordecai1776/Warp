# WARP2/warp2/gate/tests/test_proof.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_proof.py
#  Used by   : pytest.
#  Uses      : warp2/gate/proof.py, warp2/store/store.py.
#  Description:
#    Proof held to one rule: a pass is a statement about two specific files,
#    and nothing becomes proof by asserting that it is.
#  User intention (Andrew):
#    "A result counts only with a hash-bound verification record from a
#    controlled run — proof, not assertion."
# ============================================================================
from __future__ import annotations

import json
import pytest
from warp2.gate import proof as proof_mod
from warp2.gate.proof import Proof
from warp2.store.store import Store

# Intention: the header every file in this tree carries (#126). The gate
# checks for it now, so a fixture written without one is refused as
# `invalid_test` before it ever runs — which is the clause doing its job.
HEADER = ("# Pathway   : test_shrink.py\n"
          "# Used by   : pytest.\n"
          "# Uses      : shrink.py.\n"
          "# Description: shows the shrink guard holds.\n"
          "# User intention: a floor on the count.\n")

ARTIFACT = ("# Pathway   : shrink.py\n"
            "# Used by   : test_shrink.py.\n"
            "# Uses      : nothing.\n"
            "# Description: holds a number at one or above.\n"
            "# User intention: a floor on the count.\n"
            "def hold(number):\n    return max(1, number)\n")


def test_shadow_proof_refuses_an_artifact_missing_from_the_shadow(tmp_path):
    """Intention: an incomplete shadow cannot quietly prove the live artifact."""
    store, proof = _world(tmp_path, test=(
        "import shrink\n\ndef test_hold():\n    assert shrink.hold(0) == 1\n"))
    shadow = tmp_path / "shadow"
    shadow.mkdir()
    (shadow / "test_shrink.py").write_bytes((proof.root / "test_shrink.py").read_bytes())
    result = proof.check_sandboxed("shrink.py", "test_shrink.py", shadow)
    assert result["outcome"] == proof_mod.INVALID_TEST, result
    assert not store.current(subject="shrink.py", attr="verified_by")
    store.close()


def _world(tmp_path, artifact=ARTIFACT, test=None):
    root = tmp_path / "tree"
    root.mkdir()
    (root / "shrink.py").write_text(artifact, encoding="utf-8")
    if test is not None:
        # Intention: every fixture test file carries the header too (#126).
        headed = test if "user intention" in test.lower() else HEADER + test
        (root / "test_shrink.py").write_text(headed, encoding="utf-8")
    store = Store(tmp_path / "state", run="proof", view_path=tmp_path / "view.sqlite3")
    return store, Proof(store, root)


def test_a_real_test_that_passes_is_recorded_against_the_exact_bytes(tmp_path):
    """THE WHOLE POINT, IN ONE TEST.

    Intention: the fact says WHICH BYTES passed, not merely that something
    did. That is what "hash-bound" means — the claim is about two specific
    files and it can be checked again later without trusting anybody.
    """
    store, proof = _world(tmp_path, test=(
        "import shrink\n\n"
        "def test_the_shrink_guard_holds_at_one():\n"
        "    assert shrink.hold(0) == 1\n"))
    result = proof.check("shrink.py", "test_shrink.py")
    assert result["outcome"] == proof_mod.PASSED
    recorded = store.current(subject="shrink.py", attr="verified_bytes")[0]["value"]
    assert recorded == f"{result['artifact_sha256']}:{result['test_sha256']}"
    assert store.current(subject="shrink.py", attr="verified_by")[0]["value"] == "test_shrink.py"
    assert not store.current(subject="test_shrink.py", relation="contradicts", obj="shrink.py")
    assert not store.current(subject="shrink.py", attr="last_traceback")


@pytest.mark.parametrize("code,output,outcome", [
    (None, "did not finish", proof_mod.TIMED_OUT),
    (5, "no tests ran", proof_mod.NO_TESTS),
    (2, "ERROR collecting test_shrink.py\nE NameError: undefined", proof_mod.BROKEN_TEST),
])
def test_inconclusive_observations_do_not_contradict_artifacts(tmp_path, monkeypatch, code, output, outcome):
    store, proof = _world(tmp_path, test="import shrink\n\ndef test_hold():\n    assert shrink.hold(0) == 1\n")
    monkeypatch.setattr(proof, "_run", lambda *args, **kwargs: (code, output))
    assert proof.check("shrink.py", "test_shrink.py")["outcome"] == outcome
    assert not store.current(relation="contradicts")
    receipt = store.current(attr="proof_observation")[0]
    assert json.loads(store.payload(receipt))["outcome"] == outcome
    store.close()


def test_observation_preserves_full_evidence_across_edits_and_rebuild(tmp_path, monkeypatch):
    store, proof = _world(tmp_path, test="import shrink\n\ndef test_hold():\n    assert shrink.hold(0) == 1\n")
    original = (proof.root / "shrink.py").read_bytes()
    output = "first diagnostic\n" + "x" * 5000
    store.assert_fact("shrink.py", "has", attr="asked_for", value="Keep the user requirement")
    monkeypatch.setattr(proof, "_run", lambda *args, **kwargs: (1, output))
    first = proof.check("shrink.py", "test_shrink.py")
    (proof.root / "shrink.py").write_text(ARTIFACT + "\n# changed\n", encoding="utf-8")
    proof.check("shrink.py", "test_shrink.py")
    store.rebuild()
    receipts = [json.loads(store.payload(f)) for f in store.current(attr="proof_observation")]
    assert len(receipts) == 2
    old = next(r for r in receipts if r["artifact_sha256"] == first["artifact_sha256"])
    assert old["output"] == output
    assert old["exit_code"] == 1
    assert old["asked_for"] == "Keep the user requirement"
    assert old["test_obligations"]
    assert store.evidence.get(old["artifact_evidence"]) == original
    assert len(store.current(subject="shrink.py", relation="contains")) == 2
    store.close()


def test_a_test_that_asserts_nothing_never_becomes_proof(tmp_path):
    """THE DEFECT THIS FILE EXISTS TO END.

    Intention: WARP recorded `passed` for nine `assert True` stubs, each one
    written into the verification index as hash-bound proof — so the hash
    bound the wrong thing perfectly. The test is judged BEFORE it is run,
    using the same gate that refuses the work, and a file that asserts only
    that True is True cannot pass a run it is never given.
    """
    store, proof = _world(tmp_path, test=(
        "import shrink\n\ndef test_it():\n    assert True\n"))
    result = proof.check("shrink.py", "test_shrink.py")
    assert result["outcome"] == proof_mod.INVALID_TEST
    assert "assert True" in result["said"]
    assert store.current(subject="shrink.py", attr="verified_by") == []


def test_a_file_with_no_tests_in_it_is_not_a_pass(tmp_path):
    # Intention: pytest exits 5 when nothing ran. Reading that as success is
    # how a file with no test functions becomes evidence.
    store, proof = _world(tmp_path, test=(
        "import shrink\n\n"
        "def test_the_guard_holds():\n    assert shrink.hold(0) == 1\n"))
    # Rename the function so pytest collects nothing, keeping the file itself
    # acceptable to the gate.
    path = tmp_path / "tree" / "test_shrink.py"
    path.write_text(path.read_text(encoding="utf-8").replace(
        "def test_the_guard_holds", "def check_the_guard_holds"), encoding="utf-8")
    result = proof.check("shrink.py", "test_shrink.py")
    # The gate refuses it first — a file with no test_ function is one of its
    # stated obligations — which is the stronger answer and the right one.
    assert result["outcome"] in (proof_mod.NO_TESTS, proof_mod.INVALID_TEST)
    assert result["passed"] is False


def test_a_failing_test_is_a_failure_and_nothing_is_recorded(tmp_path):
    store, proof = _world(tmp_path, test=(
        "import shrink\n\n"
        "def test_the_shrink_guard_holds_at_one():\n"
        "    assert shrink.hold(0) == 99\n"))
    result = proof.check("shrink.py", "test_shrink.py")
    assert result["outcome"] == proof_mod.FAILED
    assert store.current(subject="shrink.py", attr="verified_by") == []


def test_a_test_that_cannot_be_imported_is_a_broken_test_not_a_failing_artifact(tmp_path):
    """MEASURED LIVE IN WARP, AND IT COST DAYS.

    Intention: one artifact sat queued for revision for days, failing every
    run, because its test's own module body named four constants it never
    imported. The artifact's behaviour was never exercised, so no edit to it
    could change the result. It was never a revision; it is a broken test, and
    calling it one routes it to the repair that works.
    """
    store, proof = _world(tmp_path, test=(
        "import shrink\n"
        "LEVEL = MISSING_CONSTANT\n\n"
        "def test_the_shrink_guard_holds():\n"
        "    assert shrink.hold(0) == 1\n"))
    result = proof.check("shrink.py", "test_shrink.py")
    assert result["outcome"] == proof_mod.BROKEN_TEST


def test_a_proof_that_has_stopped_being_true_says_so(tmp_path):
    """Intention: WARP bound its receipts to hashes and never looked at them
    again, so a file edited after it was verified still read as verified. The
    drift is found by asking, and the answer is an invalidation with a reason
    rather than a quiet overwrite."""
    store, proof = _world(tmp_path, test=(
        "import shrink\n\n"
        "def test_the_shrink_guard_holds_at_one():\n"
        "    assert shrink.hold(0) == 1\n"))
    assert proof.check("shrink.py", "test_shrink.py")["passed"] is True
    assert proof.restate("shrink.py")["state"] == "still true"

    (tmp_path / "tree" / "shrink.py").write_text(
        "def hold(number):\n    return max(2, number)\n", encoding="utf-8")
    verdict = proof.restate("shrink.py")
    assert verdict["state"] == "drifted"
    assert store.current(subject="shrink.py", attr="verified_by") == []
    history = store.history("shrink.py")
    assert any("bytes changed" in str(fact.get("valid_to_reason") or "")
               or fact["valid_to"] for fact in history)


def test_a_path_that_leaves_the_tree_is_not_something_this_may_run(tmp_path):
    # Intention: stated once, here, rather than trusted at every call site.
    store, proof = _world(tmp_path, test="def test_it():\n    assert 1 == 1\n")
    result = proof.check("../../etc/passwd", "test_shrink.py")
    assert result["outcome"] == proof_mod.INVALID_TEST
    assert "not a file inside the tree" in result["said"]


def test_a_test_that_will_not_stop_is_its_own_outcome(tmp_path):
    """Intention: a test that cannot finish is not a test that failed. Calling
    it one sends the work off to fix an artifact that may be perfectly fine."""
    store, proof = _world(tmp_path, test=(
        "import time\nimport shrink\n\n"
        "def test_the_shrink_guard_holds_at_one():\n"
        "    time.sleep(30)\n"
        "    assert shrink.hold(0) == 1\n"))
    result = proof.check("shrink.py", "test_shrink.py", timeout=2.0)
    assert result["outcome"] == proof_mod.TIMED_OUT
    assert "did not finish" in result["said"]


def test_proof_verifies_in_sandbox_override_root(tmp_path):
    store, proof = _world(tmp_path)
    sandbox_root = tmp_path / "sandbox_dir"
    sandbox_root.mkdir()
    (sandbox_root / "shrink.py").write_text(ARTIFACT, encoding="utf-8")
    (sandbox_root / "test_shrink.py").write_text(
        HEADER +
        "import shrink\n\n"
        "def test_the_shrink_guard_holds_at_one():\n"
        "    assert shrink.hold(0) == 1\n", encoding="utf-8")
    result = proof.check("shrink.py", "test_shrink.py", override_root=sandbox_root)
    assert result["outcome"] == proof_mod.PASSED
    assert result["passed"] is True


def test_observable_point_records_reality_on_pass_and_failure(tmp_path):
    """Intention: the observable point between a known proof and tested reality
    is recorded for all outcomes so empirical reality is never lost."""
    # 1. Failure case
    store, proof = _world(tmp_path, test=(
        "import shrink\n\n"
        "def test_failing():\n"
        "    assert shrink.hold(0) == 99\n"))
    res_fail = proof.check("shrink.py", "test_shrink.py")
    assert res_fail["outcome"] == proof_mod.FAILED
    assert not store.current(subject="shrink.py", attr="verified_by")
    # But observable reality IS anchored:
    obs = store.current(subject="shrink.py", attr="observable_reality")
    assert obs and obs[0]["value"].startswith("failed:")
    assert store.current(subject="shrink.py", attr="last_tested_outcome")[0]["value"] == "failed"
    assert store.current(subject="test_shrink.py", relation="contradicts", obj="shrink.py")
    assert store.current(subject="shrink.py", attr="last_traceback")

    # 2. Pass case
    (proof.root / "test_shrink.py").write_text(
        HEADER + "import shrink\n\ndef test_passing():\n    assert shrink.hold(0) == 1\n",
        encoding="utf-8")
    res_pass = proof.check("shrink.py", "test_shrink.py")
    assert res_pass["outcome"] == proof_mod.PASSED
    obs_pass = store.current(subject="shrink.py", attr="observable_reality")
    assert obs_pass and obs_pass[0]["value"].startswith("passed:")
    assert store.current(subject="test_shrink.py", relation="supports", obj="shrink.py")
    assert store.current(subject="shrink.py", attr="verified_by")[0]["value"] == "test_shrink.py"


def test_a_test_that_only_skipped_is_not_proof():
    """Intention: found 2026-10-09 (check D2). pytest exits 0 when every test
    is skipped, and that was recorded as hash-bound proof."""
    from warp2.gate.proof import FAILED, NO_TESTS, PASSED, _what_a_clean_exit_proved
    assert _what_a_clean_exit_proved("s\n1 skipped in 0.01s") == NO_TESTS
    assert _what_a_clean_exit_proved(".s\n1 passed, 1 skipped in 0.02s") == FAILED
    assert _what_a_clean_exit_proved("..\n2 passed in 0.02s") == PASSED


def test_a_project_package_with_init_includes_project_parent_in_importable_roots(tmp_path):
    """Intention: when a project folder has __init__.py, it is a package; its parent
    directory must be importable so tests can import the package by name (e.g. from behemoth_eye...)."""
    from warp2.gate.proof import Proof
    proof = Proof(store=None, root=tmp_path)
    proj = tmp_path / "projects" / "my_pkg"
    proj.mkdir(parents=True)
    (proj / "__init__.py").write_text("", encoding="utf-8")
    art = proj / "mod.py"
    art.write_text("x = 1\n", encoding="utf-8")
    tst = proj / "tests" / "test_mod.py"
    tst.parent.mkdir()
    tst.write_text("def test_x(): pass\n", encoding="utf-8")
    roots = proof._importable_roots(art, tst)
    assert str(tmp_path / "projects") in roots
    assert str(proj) in roots

