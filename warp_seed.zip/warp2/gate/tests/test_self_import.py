# WARP2/warp2/gate/tests/test_self_import.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_self_import.py
#  Used by   : pytest (run_tests.py, RUN_TESTS.bat).
#  Uses      : warp2/gate/self_import.py, warp2/gate/mend.py,
#              warp2/gate/contracts.py, warp2/models/worker.py.
#  Description:
#    A file that imports itself is refused on every code spine and mended by
#    taking the import out; a package's __init__ is left alone; practice is
#    told what its skill is.
#  User intention (Andrew, 2026-09-25): "fix the one last model thing if you
#    can" — the skill:syntax practice file imported itself.
# ============================================================================
from __future__ import annotations

from pathlib import Path

SEEN = ("from typing import List\n"
        "from state.practice.syntax import solution_entry\n\n"
        "def solution_entry(items: List[int], wanted: int) -> int:\n"
        "    return items.index(wanted) if wanted in items else -1\n")


def test_a_file_that_imports_itself_is_refused_on_every_code_spine():
    """Intention: build, test, revise and practice all carry the clause, and it names the module."""
    from warp2.gate.contracts import contract_for
    for kind in ("build", "test", "revise", "practice"):
        assert "does_not_import_itself" in {c.name for c in contract_for(kind).clauses}
    from warp2.gate import self_import
    said = self_import.check(SEEN, {"write_path": "state/practice/syntax.py"})
    assert said.startswith(self_import.SELF_IMPORT) and "state.practice.syntax" in said
    assert self_import.check(SEEN, {"write_path": "state/practice/other.py"}) == ""
    assert self_import.check("from pkg import part\n", {"write_path": "projects/p/pkg/__init__.py"}) == ""


def test_the_mend_takes_the_import_out_and_nothing_else(tmp_path):
    """Intention: the mended file parses, still has its other import, and no longer imports itself."""
    from warp2.gate import self_import
    from warp2.gate.mend import Mend
    said = self_import.check(SEEN, {"write_path": "state/practice/syntax.py"})
    mended = Mend(tmp_path).mend("state/practice/syntax.py", SEEN, said)
    assert mended is not None and "self_import" in mended["by"]
    assert "from typing import List" in mended["content"]
    assert self_import.check(mended["content"], {"write_path": "state/practice/syntax.py"}) == ""
    inside = "def f():\n    from state.practice.syntax import g\n    return g\n"
    assert self_import.SelfImportMend(tmp_path)(tmp_path / "state/practice/syntax.py", inside,
                                                self_import.SELF_IMPORT + "x") is None


def test_practice_is_told_what_its_skill_is():
    """Intention: the skill's intention and that the examples are a rule, said once; nothing for other work."""
    from warp2.models.worker import Worker
    said = Worker._skill_said({"skill_name": "syntax", "proves_intention": "write python that parses",
                               "entrypoint": "solution_entry"})
    assert said[0] == "the skill: syntax — write python that parses"
    assert "find the rule" in said[1]
    assert Worker._skill_said({}) == []


def test_the_relative_form_is_the_same_mistake():
    """Intention: found 2026-10-09 (check R2). The warp wrote `from . import
    __main__` into adaptive_layers/__main__.py and the rule let it through,
    breaking the program's start. A relative import that lands on the file
    itself is refused and mended like the absolute one."""
    from warp2.gate.self_import import check, imports_of_itself
    path = "projects/adaptive_layers_by_attention/src/adaptive_layers/__main__.py"
    bad = "from . import __main__  # Relative import only inside a package\n\nfrom adaptive_layers.cli import app\n"
    assert "imports itself" in check(bad, {"write_path": path})
    assert imports_of_itself("from .__main__ import main\n", path)
    # a sibling and the package itself are not this file
    assert not check("from . import cli\nfrom .cli import app\nfrom .. import x\n", {"write_path": path})
