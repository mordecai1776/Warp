# WARP2/warp2/gate/tests/test_the_intention_is_read_in_the_code.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_the_intention_is_read_in_the_code.py
#  Used by   : pytest.
#  Uses      : warp2/gate/checks.py (_realizes_its_intention).
#  Description:
#    Whether a file is about its intention is read in its code — names,
#    calls, values — not in its comments or docstrings, where the header
#    writer copies the intention itself.
#  User intention (Andrew): the gate must check that the thing was made, not
#    that its description was. 2026-10-09, "ok lets get it done" — fix 5.7 of
#    claude/warp2_fix_plan_2026_10_09.md (check D3: every file built from
#    parts passed, because its header carried the words).
# ============================================================================
from __future__ import annotations

from warp2.gate.checks import _realizes_its_intention

INTENTION = {"proves_intention": "convert arbitrary files into fixed-size trainable representations"}

HEADER = ("# Pathway   : projects/thing/convert.py\n"
          "# User intention: convert arbitrary files into fixed-size trainable representations.\n")


def test_a_copied_header_does_not_make_unrelated_code_pass():
    """Intention: check D3 — the words in the header passed a file that hashes itself."""
    code = HEADER + 'import hashlib\n\n\ndef me():\n    """Converts files into representations."""\n    return hashlib\n'
    assert _realizes_its_intention(code, INTENTION)


def test_code_that_does_the_thing_passes():
    """Intention: the words in its own names and calls are what count."""
    code = HEADER + ("def convert_files(paths, size):\n"
                     "    representations = [fixed(p, size) for p in paths]\n"
                     "    return representations\n")
    assert _realizes_its_intention(code, INTENTION) == ""
