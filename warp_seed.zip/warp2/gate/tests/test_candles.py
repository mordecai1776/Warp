# WARP2/warp2/gate/tests/test_candles.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_candles.py
#  Used by   : pytest.
#  Uses      : warp2/gate/{candles,checks,watches}.py.
#  Description:
#    The gate held to its standard candles: proven-good code must get through,
#    a fixed crowd's verdicts moving says the gate moved, and the narrowed
#    hand-back check lets a validator in while still refusing a hand-back.
#  User intention (Andrew, 2026-09-23): find "the sweet spot where it kicks
#    out the bad and lets in the good" — "just make sure" the gate does not
#    swing "to one extreme or another".
# ============================================================================
from __future__ import annotations

import json

from warp2.gate import checks
from warp2.gate.candles import Crowd, GateCandles, ProvenGood, plainly
from warp2.gate.watches import _bigger_than_proven


class Rows:
    """Intention: a yardstick whose rows the test decides."""

    def __init__(self, rows) -> None:
        self._rows = rows

    def rows(self) -> list:
        return list(self._rows)


class NoMend:
    """Intention: a door that mends nothing, so a refusal stays a refusal."""

    def mend(self, *args, **kwargs):
        return None


GOOD = "def hold(number):\n    return max(1, number)\n"
HAND_BACK = "def hold(number):\n    return number\n"


def test_a_validator_that_returns_itself_did_something():
    """Intention: the shape measured 2026-09-23 — check, raise on a bad field,
    then `return self` — refused 38 times in two days and on 48 files."""
    validator = ("class Config:\n"
                 "    def validate(self):\n"
                 "        if self.tasks < 0:\n"
                 "            raise ValueError('tasks must be zero or more')\n"
                 "        return self\n")
    assert checks._returns_more_than_input(validator, {}) == ""
    changed = "def grow(items, extra):\n    items.append(extra)\n    return items\n"
    assert checks._returns_more_than_input(changed, {}) == ""


def test_a_hand_back_is_still_refused():
    """Intention: the sweet spot, not a hole — a function that does nothing but hand back its input still fails."""
    assert "hold" in checks._returns_more_than_input(HAND_BACK, {})
    stub = "def apply_constraints(self, reconstruction):\n    return reconstruction\n"
    assert "apply_constraints" in checks._returns_more_than_input(stub, {})


def test_proven_good_code_refused_names_the_clause(tmp_path):
    """Intention: a clause that refuses code a test proved is the gate being too tight, said by name."""
    good = Rows([{"kind": "build", "target": "projects/a/hold.py", "content": GOOD, "context": {}},
                 {"kind": "build", "target": "projects/a/back.py", "content": HAND_BACK, "context": {}}])
    report = GateCandles(tmp_path, tmp_path / "state", good=good, crowd=Rows([]), mend=NoMend()).weigh()
    assert report["good"] == 2 and report["good_refused"] == 1
    assert report["too_tight"]["returns_more_than_input"] == 1


def test_the_crowd_says_when_the_gate_swings(tmp_path):
    """Intention: fixed answers cannot move, so a verdict that moved is the gate moving."""
    crowd = Rows([
        {"kind": "build", "target": "projects/a/one.py", "content": HAND_BACK, "context": {}, "then": True},
        {"kind": "build", "target": "projects/a/two.py", "content": HAND_BACK, "context": {}, "then": True},
        {"kind": "build", "target": "projects/a/three.py", "content": GOOD, "context": {}, "then": True},
        {"kind": "build", "target": "projects/a/four.py", "content": GOOD, "context": {}, "then": False},
    ])
    report = GateCandles(tmp_path, tmp_path / "state", good=Rows([]), crowd=crowd, mend=NoMend()).weigh()
    assert report["moved_to_refused"] == 2 and report["moved_to_accepted"] == 1
    assert report["swing"] == 0.25
    assert "swing +0.25" in plainly(report)


def test_the_gate_is_weighed_once_per_version(tmp_path):
    """Intention: the same gate on the same fixed answers says the same thing; it is measured once and kept."""
    (tmp_path / "warp2" / "gate").mkdir(parents=True)
    (tmp_path / "warp2" / "gate" / "checks.py").write_text("# one\n", encoding="utf-8")
    candles = GateCandles(tmp_path, tmp_path / "state", good=Rows([]), crowd=Rows([]), mend=NoMend())
    assert candles.measure_once()["fresh"] is True
    assert candles.measure_once()["fresh"] is False
    (tmp_path / "warp2" / "gate" / "checks.py").write_text("# two\n", encoding="utf-8")
    assert candles.measure_once()["fresh"] is True


def test_the_yardsticks_are_read_from_the_record(tmp_path):
    """Intention: proven good from the verified examples; the crowd from do_work answers of models that never train."""
    state = tmp_path / "state"
    (state / "datasets" / "skill").mkdir(parents=True)
    (state / "datasets" / "skill" / "train.jsonl").write_text(json.dumps(
        {"kind": "test", "test": "projects/a/tests/test_hold.py", "response": GOOD,
         "artifact": "projects/a/hold.py", "verification": "pytest passed"}) + "\n", encoding="utf-8")
    (state / "checkpoints" / "trained-one").mkdir(parents=True)
    (state / "journals").mkdir()
    lines = [{"verb": "do_work", "work_kind": "build", "context": {"proves_intention": "hold"},
              "value": {"model": model, "issues": [], "files": {"projects/a/hold.py": GOOD}}}
             for model in ("fixed:1b", "trained-one", "fixed:1b")]
    (state / "journals" / "run.jsonl").write_text("\n".join(json.dumps(x) for x in lines) + "\n", encoding="utf-8")
    good = ProvenGood(state).rows()
    assert good[0]["context"]["artifact_module"] == "hold"
    crowd = Crowd(state).rows()
    # Intention: the trained model is left out, and the same answer twice is one candle.
    assert [row["model"] for row in crowd] == ["fixed:1b"] and crowd[0]["then"] is True


def test_the_size_watch_names_a_part_past_its_models_proven_size():
    """Intention: it only observes, and only when it is told the size."""
    code = "def small(n):\n    return n + 1\n\n\ndef big(n):\n" + "".join(f"    n += {i}\n" for i in range(40)) + "    return n\n"
    assert _bigger_than_proven(code, {}) == ""
    said = _bigger_than_proven(code, {"reliable_chars": 200})
    assert "big" in said and "small" not in said
