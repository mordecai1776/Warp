# WARP2/warp2/gate/tests/test_runs_checks.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/tests/test_runs_checks.py
#  Used by   : the test suite.
#  Uses      : warp2/gate/{self_reads,placeholder_notes,calls_exist,checks,contracts}.py.
#  Description:
#    The gate knows whether code works, not only how it looks: the three
#    kinds of slop the gate accepted on 2026-09-24 are refused, and the
#    honest shapes next to them are not.
#  User intention (Andrew, 2026-09-24): "is their output not slop?"
# ============================================================================
from __future__ import annotations

import ast

from warp2.gate import checks as c
from warp2.gate.calls_exist import chains, missing
from warp2.gate.placeholder_notes import found
from warp2.gate.self_reads import read_never_set, shadowed_methods


def test_a_value_over_a_method_is_found_but_a_property_is_not():
    """Intention: castle_adventure's self.score over score(); a property setter is fine."""
    bad = "class G:\n    def __init__(self):\n        self.score = 0\n    def score(self):\n        return 1\n"
    good = ("class G:\n    def __init__(self):\n        self.seen = 0\n"
            "    @property\n    def seen(self):\n        return self._s\n"
            "    @seen.setter\n    def seen(self, v):\n        self._s = v\n")
    assert shadowed_methods(ast.parse(bad)) == [("G", "score")]
    assert shadowed_methods(ast.parse(good)) == []


def test_a_read_nothing_sets_is_found_and_honest_shapes_are_not():
    """Intention: tuple class fields, mangled names, in-file bases and dict keys all count."""
    bad = "class A:\n    def get(self):\n        return self.coarse\n"
    good = ("class Base:\n    kind, shape = 'p', 2\n    def __init__(self):\n        self.__n = 1\n"
            "class A(Base):\n    def get(self, d):\n        d[self.key()] = self.kind\n"
            "        return self._Base__n\n    def key(self):\n        return self.shape\n")
    assert read_never_set(ast.parse(bad)) == [("A", "coarse")]
    assert read_never_set(ast.parse(good)) == []


def test_a_class_from_outside_the_file_is_not_judged():
    """Intention: what an outside base gives cannot be seen here, so it is left alone."""
    code = "import torch\nclass Net(torch.nn.Module):\n    def f(self):\n        return self.training\n"
    assert read_never_set(ast.parse(code)) == []


def test_placeholder_notes_are_found_however_worded_but_not_when_quoted():
    """Intention: the shape of the note, not one wording; a quoted phrase is talked about."""
    assert found("def f():\n    # Replace this with your actual implementation\n    return 1\n")
    assert found('def f():\n    """In a real system this would read the file."""\n    return 1\n')
    assert not found('def f():\n    # the old gate missed "Replace this with your actual code"\n    return 1\n')
    assert not found("def f():\n    # sample values from the prior\n    return 1\n")


def test_calls_that_do_not_exist_are_found_by_looking():
    """Intention: bpy.data.asset_levels-shaped mistakes, looked up for real."""
    code = "import os\nimport json as j\n\ndef f(x):\n    return os.path.join(x) + j.dumpz(x)\n"
    assert [row["shown"] for row in chains(ast.parse(code))] == ["os.path.join", "j.dumpz"]
    assert missing(code) == ["j.dumpz"]
    assert missing("import no_such_module_here\n\ndef f():\n    return no_such_module_here.a\n") == []


def test_the_code_spines_carry_the_four_new_clauses():
    """Intention: build, revise and practice are refused for all four; tests for calls."""
    from warp2.gate.contracts import contract_for
    for kind in ("build", "revise", "practice"):
        names = {clause.name for clause in contract_for(kind).clauses}
        assert {"no_shadowed_methods", "sets_what_it_reads", "no_placeholder_notes",
                "its_calls_exist"} <= names
    assert "its_calls_exist" in {clause.name for clause in contract_for("test").clauses}
    for clause in (c.NO_SHADOWED_METHODS, c.SETS_WHAT_IT_READS, c.NO_PLACEHOLDER_NOTES,
                   c.ITS_CALLS_EXIST):
        assert clause.check(clause.passes, {}) == "" and clause.check(clause.fails, {})
