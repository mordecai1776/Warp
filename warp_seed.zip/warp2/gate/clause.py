# WARP2/warp2/gate/clause.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/clause.py
#  Used by   : warp2/gate/checks.py (which builds clauses), contracts.py,
#              guard.py, scoreboard.py.
#  Uses      : stdlib only. IMPORTS NOTHING FROM warp2, deliberately — the
#              thing that judges the work must not be breakable by the work.
#  Description:
#    The three shapes the gate is made of. A clause is one obligation: the line
#    the work is shown and the check that decides, in one object so they cannot
#    drift. A watch is a check that may never refuse. A contract is what one
#    kind of work is, in the only terms that can be enforced.
#  User intention (Andrew, 2026-08-17):
#    "a lign of pure intention without the gruff of lauange. The pure intention
#    can be tested." The line and the test are the same thing here.
# ============================================================================
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

# A stated obligation that will not fit on one line is nearly always two
# obligations wearing a coat. The cap is a constraint on the DESIGN, not on the
# prose — the justification belongs in the file, where a person reads it once.
CLAUSE_MAX_CHARS = 72


@dataclass(frozen=True)
class Clause:
    """One obligation: the line the work is shown, and the check that decides.

    Intention: THE MOST EXPENSIVE LESSON IN WARP, KEPT WHOLE. The failure of
    2026-08-17 was not a missing rule — the gate said "test does not import
    artifact module" correctly, 23 times, to a model that had never been shown
    that requirement. A prompt written in one place and a check written in
    another drift, and every drift is work punished for missing an instruction
    nobody gave. So both live here, and they cannot disagree because there is
    only one of them.

    `check(code, context) -> str` returns "" when satisfied, or the complaint.
    The complaint is carried into the next attempt, so it is written as
    something that can be acted on rather than as a verdict.

    `passes` and `fails` are examples the clause must accept and must refuse.
    They are not documentation: the suite runs them. A verifier is a program,
    and an untested predicate is a hole with a name.
    """

    name: str
    intention: str
    check: Callable[[str, dict], str]
    passes: str = ""
    fails: str = ""
    speak: Callable[[dict], str] | None = None
    # Complaints this clause raises that NO work could have answered — the unit
    # should never have been given to anybody. Intention: a refusal aimed at
    # whoever raised the work is not evidence the clause is unactionable, and
    # counting it as one made the gate report a defect in itself that was
    # really a defect in sourcing. `imports_artifact` sat at 7 fired and 0%
    # repaired for exactly this reason, long after the sourcing hole was shut.
    about_the_unit: tuple = ()

    def line(self, context: dict | None = None) -> str:
        """The obligation as the work is told it — carrying its specifics.

        Intention: A CLAUSE THAT NAMES A THING MUST CARRY THE THING. Measured
        across 752 WARP judgements: "the paired test imports names this file
        does not define" is 30% of every complaint ever recorded, larger than
        syntax errors and placeholders combined — and the names were known to
        the checker at judging time and never once put in front of the model.
        The line read "keep every name the paired test imports" to something
        that had not been shown the test. Naming them costs a few characters.
        """
        if self.speak is None:
            return self.intention
        spoken = self.speak(dict(context or {}))
        return spoken or self.intention

    def blames_the_unit(self, complaint: str) -> bool:
        """Is this complaint about the work, or about the unit it was given?

        Intention: the clause is the only thing that knows. A caller matching
        prose would be a second statement of the same fact, in the file least
        likely to be updated when the words change.
        """
        said = str(complaint or "")
        return any(phrase and phrase in said for phrase in self.about_the_unit)

    def failure(self, code: str, context: dict | None = None) -> str:
        """The complaint, or "" — and a complaint if the check itself broke.

        Intention: THE GATE FAILS CLOSED. A predicate that raises has not said
        the work is acceptable; it has said nothing, and nothing is not
        permission. Measured elsewhere in the field: eleven realistic verifier
        bugs let through 56–87% of incorrect work, against 0.0% for the strict
        versions — a checker is a program and it has bugs.
        """
        try:
            return self.check(code, dict(context or {})) or ""
        except Exception as exc:
            return f"{self.name} could not be decided: {type(exc).__name__}: {exc}"


@dataclass(frozen=True)
class Watch:
    """A check that may only observe. It never refuses and never costs an attempt.

    Intention: the 2026 finding, and the resolution of a real tension. Held-out
    measurement says you cannot see gaming with only the checks you show —
    visible suites saturate while held-out scores diverge, by up to 100 points
    on long work. Andrew's rule says nothing may be judged by an unstated rule.
    Both are right about different things: a STATED clause may refuse, and an
    UNSTATED watch may only record. A watch that starts firing is evidence the
    stated set has a hole, and the answer to that is to write the missing
    clause — which is work, not a refusal.
    """

    name: str
    look: Callable[[str, dict], str]
    why: str = ""

    def note(self, code: str, context: dict | None = None) -> str:
        """Intention: run the watch's look on the code and return what it saw; a watch that breaks
        gives a note, never a refusal.
        """
        try:
            return self.look(code, dict(context or {})) or ""
        except Exception as exc:
            # A broken watch is a note, never a refusal — it has no power to
            # stop anything, so failing closed would mean failing loudly for
            # no gain.
            return f"{self.name} could not look: {type(exc).__name__}"


@dataclass(frozen=True)
class Contract:
    """What one kind of work is, in the only terms that can be enforced."""

    kind: str
    purpose: str
    clauses: tuple = ()
    watches: tuple = ()
    produces: tuple = ()
    may_write: tuple = ()
    needs_a_model: bool = True
    notes: str = ""
    replaces: str = field(default="")

    def obligations(self, context: dict | None = None) -> tuple:
        """Exactly what the work is told, in order. No preamble, no courtesy.

        Intention: everything here is a thing that will be mechanically
        checked, and nothing that will be checked is left out. That sentence is
        the whole contract between this file and whatever does the work.
        """
        return tuple(clause.line(context) for clause in self.clauses)

    def complaints(self, code: str, context: dict | None = None) -> list:
        """Every clause's verdict, as (name, complaint) pairs, in order.

        Intention: ONE EVALUATION, NOT TWO. The guard used to build its issue
        list and its failed-name list with two separate passes over the same
        clauses on the same bytes — twice the work, and two answers that could
        differ if any check were not pure. It also had no way to pair a name
        with what it actually said, which is what the scoreboard needs to tell
        a complaint about the work from a complaint about the unit.
        """
        return [(clause.name, clause.failure(code, context))
                for clause in self.clauses]

    def failures(self, code: str, context: dict | None = None) -> list:
        """Every unmet obligation, in declaration order.

        Intention: ALL of them, never the first. Work handed one complaint
        fixes one thing and is refused for the next; the measured cost of that
        in WARP was 23 identical refusals over ten days.
        """
        found = [clause.failure(code, context) for clause in self.clauses]
        return [issue for issue in found if issue]

    def notes_from_watches(self, code: str, context: dict | None = None) -> list:
        """Intention: what each watch saw on this code, kept apart from failures so a watch can never refuse."""
        # Intention: gathered separately from failures and returned separately,
        # so there is no path by which a watch can become a refusal by
        # accident. The separation is structural, not a convention.
        seen = [(watch.name, watch.note(code, context)) for watch in self.watches]
        return [{"watch": name, "saw": saw} for name, saw in seen if saw]
