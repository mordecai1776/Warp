# WARP2/warp2/gate/watches.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/watches.py
#  Used by   : warp2/gate/contracts.py, which attaches them to every kind of
#              work a model does; warp2/models/worker.py hands in
#              `reliable_chars` for the size watch.
#  Uses      : stdlib only (ast). Nothing from warp2 except the Watch shape.
#  Description:
#    Checks that may never refuse. They exist to catch the shapes that satisfy
#    every stated obligation and still do not do the work — which is the one
#    thing a set of stated rules cannot see about itself.
#  User intention (Andrew):
#    Nothing may be judged by a rule it was not shown. These do not judge. When
#    one starts firing it means a clause is missing, and writing that clause is
#    work — it goes in the queue, it does not become a refusal in the dark.
# ============================================================================
from __future__ import annotations

import ast

from warp2.gate.clause import Watch


# Intention: the same quiet give-up the clauses use. A file that will not
# parse has one useful complaint and the `parses` clause owns it; a watch has
# nothing to add and says nothing.
def _tree(code: str):
    try:
        return ast.parse(code)
    except SyntaxError:
        return None


def _prints_instead_of_returning(code: str, _ctx: dict) -> str:
    """A function whose only effect is printing.

    Intention: the field calls this stdout spoofing — a checker that reads
    output accepts printed expected text as correctness. Nothing here reads
    stdout, so this cannot be gamed the same way; it is watched because a
    function that only prints is a function whose result nothing can test.
    """
    tree = _tree(code)
    if tree is None:
        return ""
    guilty = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        body = [s for s in node.body
                if not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant))]
        if not body:
            continue
        calls = [s for s in body if isinstance(s, ast.Expr) and isinstance(s.value, ast.Call)]
        prints = [s for s in calls
                  if ast.unparse(s.value.func).split(".")[-1] == "print"]
        returns = [s for s in ast.walk(node)
                   if isinstance(s, ast.Return) and s.value is not None]
        if prints and not returns and len(body) == len(prints):
            guilty.append(node.name)
    return f"only prints, returns nothing: {', '.join(guilty[:3])}" if guilty else ""


def _swallows_errors(code: str, _ctx: dict) -> str:
    """`except: pass` — the shape that makes anything appear to work."""
    tree = _tree(code)
    if tree is None:
        return ""
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            body = [s for s in node.body if not isinstance(s, ast.Pass)]
            if not body:
                return "an exception handler that does nothing"
    return ""


def _mocks_the_thing_under_test(code: str, ctx: dict) -> str:
    """A test that replaces the artifact it is meant to be testing.

    Intention: this passes every stated obligation — it imports the module, it
    defines test functions, it asserts on a returned value — and tests nothing
    at all, because the thing that returned the value was the mock.
    """
    module = str(ctx.get("artifact_module") or "")
    if not module or "patch" not in code:
        return ""
    for line in code.splitlines():
        if "patch" in line and module in line:
            return f"patches the artifact module it is testing: {module}"
    return ""


def _asserts_far_fewer_things_than_it_defines(code: str, _ctx: dict) -> str:
    """More test functions than assertions means some of them assert nothing."""
    tree = _tree(code)
    if tree is None:
        return ""
    tests = [n for n in ast.walk(tree)
             if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
             and n.name.startswith("test_")]
    if not tests:
        return ""
    bare = [t.name for t in tests
            if not any(isinstance(s, ast.Assert) for s in ast.walk(t))]
    return f"test functions with no assertion: {', '.join(bare[:3])}" if bare else ""


def _bigger_than_proven(code: str, ctx: dict) -> str:
    """A part of the file bigger than the model writing it has ever reliably written.

    Intention: THE LIMIT A PART MAY GROW TO (Andrew, 2026-09-23: "a limit they
    could grow to where that limit was their proven reliable size and there
    should be a check for this in the final common problem sweep of each
    file"). The size is measured per model by warp2/parts/reliable_size.py
    and handed in as `reliable_chars`. A file may be any size — it is worked
    in its parts — but a single function or method past that size cannot be
    written back by the model that owns it, so it is a part that needs
    splitting. This only observes; it never refuses.
    """
    room = int(ctx.get("reliable_chars") or 0)
    tree = _tree(code) if room else None
    if tree is None:
        return ""
    lines = code.splitlines(keepends=True)
    big = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        start = min([node.lineno] + [d.lineno for d in node.decorator_list])
        size = len("".join(lines[start - 1:(node.end_lineno or node.lineno)]))
        if size > room:
            big.append((size / room, node.name))
    # Intention: SAID AS HOW MANY TIMES TOO BIG, largest first — a weight to
    # split by, not a yes or no.
    big.sort(reverse=True)
    return (f"parts bigger than this model has proven it can write ({room} characters): "
            + ", ".join(f"{name} (x{ratio:.1f})" for ratio, name in big[:4])) if big else ""


WATCHES = (
    Watch("prints_instead_of_returning", _prints_instead_of_returning,
          why="a function whose result nothing can read cannot be tested"),
    Watch("swallows_errors", _swallows_errors,
          why="an empty handler makes any failure look like success"),
    Watch("mocks_the_thing_under_test", _mocks_the_thing_under_test,
          why="passes every stated obligation and tests nothing"),
    Watch("tests_without_assertions", _asserts_far_fewer_things_than_it_defines,
          why="the file-level assertion check cannot see a single empty test"),
    Watch("bigger_than_proven", _bigger_than_proven,
          why="a part past its model's proven size cannot be written back whole"),
)
