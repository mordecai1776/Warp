# WARP2/warp2/gate/contracts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/contracts.py
#  Used by   : warp2/gate/guard.py; the models piece, which asks what a kind of
#              work is obliged to do before it does any.
#  Uses      : warp2/gate/clause.py, warp2/gate/checks.py, warp2/gate/watches.py.
#  Description:
#    One contract per kind of work: the obligations it is judged by, the
#    watches that only observe, what it may produce and where it may write.
#  User intention (Andrew, 2026-08-17):
#    "every action type needs its own safegaurds and have its avaialble actions
#    restricted to a smaller set."
# ============================================================================
from __future__ import annotations

from warp2.gate import checks as c
from warp2.gate.clause import Contract
from warp2.gate.watches import WATCHES

# Intention: the shared spines. A kind's clause list is written as "this spine
# plus what makes this kind different", so a rule added to the spine reaches
# every kind that shares it and cannot be added to one and forgotten in another.
_HONESTY = (c.NO_PLACEHOLDERS, c.NO_TODO, c.NO_UNIMPLEMENTED, c.NO_STAR)

# Intention: THE CODE HAS TO WORK (Andrew, 2026-09-24: "is their output not
# slop?"). On every spine that writes code that runs: a class must not hide
# its own methods or read what it never set, no note may say the work is not
# done, and what it calls must exist. Tests keep their own rules and are left
# out of the note clause — a test may speak of mock data honestly.
_RUNS = (c.NO_SHADOWED_METHODS, c.SETS_WHAT_IT_READS, c.NO_PLACEHOLDER_NOTES,
         c.ITS_CALLS_EXIST)

# Intention: A FILE THAT CANNOT IMPORT IS NOT A FILE, whichever kind of work
# made it, so this sits on all three spines rather than on the one that
# measured it. The 2026-08-31 run wrote sixty files that parsed, defined test_
# functions and asserted something — and imported a class called `Artifact`
# that has never existed in this tree. Every clause the gate had said yes;
# every unit then sank at collection. Checked against this tree the day it was
# added: 377 of 393 files clean, and all sixteen it refused were broken.
# A file that imports itself cannot import either (2026-09-25, skill:syntax).
_IMPORTABLE = (c.NAMES_COME_FROM_SOMEWHERE, c.NOT_ITSELF)

# Intention: THE IMPORT RULE IS NOT THE SAME FOR A TEST AND FOR A MODULE, and
# saying it once for both is what made the gate refuse a whole working project.
# A test is collected by path and has no parent package, so a relative import
# in one cannot resolve — that stays absolute. A module inside a package is
# reached as `apex.core.x` now that the proof runner puts the project on the
# path, so its relative imports resolve the way Python intends, and refusing
# them was refusing code that runs.
# Intention: THE HEADER IS PART OF WRITING THE FILE (#126). Andrew's rule for
# this tree is that every file opens with its pathway, what uses it, what it
# uses, a description and his intention notes. It is on the build, revise and
# test spines, so every file the loop writes carries one. And every part of
# the code it writes carries its own intention note (build and revise; fix 7.2).
# A swallowed error stays a watch (held back, never told, never refusing), not a
# clause: it measures what the work does unasked (fix 7.6 kept it so).
_BUILD = (c.PARSES, c.HAS_DEFINITIONS, c.NO_EMPTY, c.DOES_SOMETHING,
          c.NO_IMPORT_EFFECTS, c.RELATIVE_IN_A_PACKAGE) + _IMPORTABLE + _HONESTY + (
              c.REALIZES_INTENTION, c.USES_PARAMETERS, c.NOT_A_COPY,
              c.CARRIES_ITS_HEADER, c.EVERY_PART_HAS_A_NOTE) + _RUNS

_TEST = (c.PARSES, c.IMPORTS_ARTIFACT, c.HAS_TESTS, c.ASSERTS_BEHAVIOUR,
         c.NO_IMPORT_EFFECTS, c.NO_RELATIVE) + _IMPORTABLE + _HONESTY + (
             c.CARRIES_ITS_HEADER, c.ITS_CALLS_EXIST)

_REVISE = (c.PARSES, c.CHANGES_SOMETHING, c.KEEPS_ITS_CONTRACT,
           c.KEEPS_REQUIRED_NAMES,
           c.HAS_DEFINITIONS, c.NO_EMPTY, c.DOES_SOMETHING,
           c.NO_IMPORT_EFFECTS, c.RELATIVE_IN_A_PACKAGE) + _IMPORTABLE + _HONESTY + (
               c.CARRIES_ITS_HEADER, c.EVERY_PART_HAS_A_NOTE) + _RUNS

_PRACTICE = (c.PARSES, c.HAS_DEFINITIONS, c.NO_EMPTY, c.DOES_SOMETHING,
             c.NO_IMPORT_EFFECTS) + _IMPORTABLE + _HONESTY + _RUNS

CONTRACTS = {
    "build": Contract(
        kind="build", purpose="write the artifact an intention calls for",
        clauses=_BUILD, watches=WATCHES, produces=("python_file",),
        may_write=("projects/**",)),
    "test": Contract(
        kind="test", purpose="write the test that shows the artifact works",
        clauses=_TEST, watches=WATCHES, produces=("python_test_file",),
        may_write=("projects/**/tests/**",)),
    "revise": Contract(
        kind="revise", purpose="repair an artifact its own test refuses",
        clauses=_REVISE, watches=WATCHES, produces=("python_file",),
        may_write=("projects/**", "warp2/ui/**", "warp2/ask/**")),
    "practice": Contract(
        kind="practice",
        purpose="train on a skill from the curriculum to achieve mastery",
        clauses=_PRACTICE, watches=WATCHES, produces=("proof", "receipt"),
        may_write=("state/**", "scratch/**")),
    "design_test": Contract(
        kind="design_test",
        purpose="prove a stated intention, not merely exercise the code",
        clauses=_TEST + (c.NAMES_THE_INTENTION,), watches=WATCHES,
        produces=("python_test_file",), may_write=("projects/**/tests/**",)),
    # --- decidable without a model. Recorded so a regression is catchable. ---
    "confirm": Contract(
        kind="confirm", purpose="find out whether an unconfirmed effect landed",
        produces=("receipt",), may_write=("state/**",), needs_a_model=False,
        notes="the receipt is the only thing in this system that binds"),
    # Intention: PAYING WHAT A FILE OWES (Andrew, 2026-09-23: "things should
    # be grandfathered in but there should be a system to update things like
    # that"). Judged by the SAME rules the debt was found by (warp2/gate/
    # owed.py judges a module as a build and a test as a test), plus what any
    # change to an existing file must keep. The rule it owes is named in the
    # context as `owed`, so that one rule is not grandfathered here.
    "update": Contract(
        kind="update", purpose="bring a file up to a rule it was made before",
        clauses=_BUILD + (c.CHANGES_SOMETHING, c.KEEPS_ITS_CONTRACT, c.KEEPS_REQUIRED_NAMES),
        watches=WATCHES, produces=("python_file",), may_write=("projects/**",)),
    # Intention: A PART TOO BIG FOR ANY MODEL TO WRITE BACK, MADE SMALLER BY
    # A MODEL (Andrew, 2026-09-23: breaking down is "meant to be done by
    # models and work with the logic system"). The model splits it; the
    # rules of any change to an existing file judge it, and the part keeps
    # its name so everything that uses it still does.
    "split": Contract(
        kind="split", purpose="split one part into smaller parts that do the same",
        clauses=_REVISE, watches=WATCHES, produces=("python_file",),
        may_write=("projects/**",)),
    "update_test": Contract(
        kind="update_test", purpose="bring a test up to a rule it was made before",
        clauses=_TEST + (c.CHANGES_SOMETHING, c.KEEPS_ITS_CONTRACT),
        watches=WATCHES, produces=("python_test_file",), may_write=("projects/**/tests/**",)),
    # Intention: THE MODELS IMPROVE THE WARP ITSELF (Andrew, 2026-09-25:
    # "make sure that the models can improve all the parts of the warp itself
    # they just have to prove the new parts in a project first"). Judged as any
    # change to an existing file is; written only into the self project, where
    # it is proven in a copy of the warp and swapped in at the next restart
    # (warp2/improve/). The model writes the part's real path; the loop puts it
    # in the self project.
    "improve": Contract(
        kind="improve", purpose="improve a part of the warp itself",
        clauses=_REVISE, watches=WATCHES, produces=("python_file",),
        may_write=("projects/_warp_self/**",)),
    "connect": Contract(
        kind="connect", purpose="give a built part a caller, or remove it",
        clauses=_REVISE, watches=WATCHES, produces=("python_file",),
        may_write=("projects/**",)),
    "research": Contract(
        kind="research", purpose="go and look up what a stated intention needs",
        produces=("finding",), may_write=("state/**",), needs_a_model=False,
        notes="capped below certainty — outside evidence informs, it never proves"),
    "describe": Contract(
        kind="describe", purpose="make a thing findable by its own words",
        produces=("terms",), may_write=("state/**",), needs_a_model=False),
}


def contract_for(kind: str):
    """The contract for a kind of work, or None when the kind is unknown.

    Intention: None is deliberately NOT a permissive default. A caller that
    cannot find a contract has found an action nobody has said anything about,
    and the right response to that is a refusal, not a shrug. Same shape as the
    lock homes: fix the DEFAULT so a new call site cannot quietly acquire a
    capability nobody granted it.
    """
    return CONTRACTS.get(str(kind or "").strip().lower())


def obligations(kind: str, context: dict | None = None) -> str:
    """The obligations for a kind, numbered, as the work should receive them.

    Intention: one obligation per line, numbered so a refusal can point at one.
    No preamble, no explanation, no courtesy — everything here is a thing that
    will be mechanically checked, and nothing that will be checked is left out.
    """
    contract = contract_for(kind)
    if contract is None:
        return ""
    lines = contract.obligations(context)
    return "\n".join(f"{index}. {line}" for index, line in enumerate(lines, start=1))
