# WARP2/warp2/gate/mend.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/gate/mend.py
#  Used by   : warp2/work/loop.py (put_down: a refused write is mended once,
#              when the refusal is one only code can fix exactly),
#              warp2/parts/imports_fill.py (the imports of a file built in parts).
#  Uses      : stdlib ast, io, sys, tokenize, typing (to know which names they hold);
#              warp2/gate/import_table.py (what accepted files imported),
#              warp2/gate/header_mend.py (the required header, from facts),
#              warp2/gate/self_import.py (a file's imports of itself taken out).
#  Description:
#    Mechanical fixes for refusals that have exactly one right answer: a name
#    used without its import, when only one place in the tree defines it;
#    calls left at the top of a module, moved under `if __name__ == "__main__"`;
#    and unclosed string literals / delimiters closed deterministically.
#    The mended bytes go through the same gate again. Nothing here guesses.
#  User intention (Andrew, 2026-09-18):
#    "build things into the right system to keep those from happening again."
#    "it should warn me the warp should fix it itself."
#    On 09-17 `projects/game_builder/rules.py` was refused three times for the
#    same missing `Grid`, and `warp_internal_model_bridge.py` twice for `Any`,
#    after the model had been told the reason. A small model does not always
#    learn from being told. The mistake is still counted for training; the
#    corrected file is what gets written — "corrected code only as the
#    training text, with the mistake setting the weight".
# ============================================================================
from __future__ import annotations

import ast
import io
import sys
import tokenize
import typing
from pathlib import Path

from warp2.gate.self_import import SelfImportMend

MISSING = "uses names it never imports or defines: "
AT_IMPORT = "module executes calls at import time: "


def _module_of(path: Path, root: Path) -> str:
    """Intention: the dotted name a file is imported by from the tree's root."""
    parts = list(path.relative_to(root).with_suffix("").parts)
    return ".".join(parts[:-1] if parts[-1] == "__init__" else parts)


class ImportMend:
    """Add the one import a missing name can only mean.

    Intention: three sources, tried in order, and a name that matches none —
    or more than one place — is left alone. `typing` names; standard library
    modules used as modules; and a class or function defined at the top of
    exactly one other file in the same project.
    """

    def __init__(self, root, table=None) -> None:
        """Intention: `root` is WARP2/, where `projects.<name>...` imports start.

        `table` is the learned ImportTable, asked last: what accepted files
        have always imported a name by.
        """
        self.root = Path(root)
        self.table = table

    def names(self, said: str) -> list:
        """Intention: the names the gate listed, in its own words."""
        if MISSING not in said:
            return []
        listed = said.split(MISSING, 1)[1].split(";", 1)[0]
        return [one.strip() for one in listed.split(",") if one.strip().isidentifier()]

    def line_for(self, name: str, path: Path) -> str:
        """The import line for one name, or "" when there is not exactly one answer."""
        if hasattr(typing, name) and not name.startswith("_"):
            return f"from typing import {name}"
        if name in getattr(sys, "stdlib_module_names", ()):
            return f"import {name}"
        found = self.defined_in_project(name, path)
        if len(found) == 1:
            return f"from {found[0]} import {name}"
        if not found and self.table is not None:
            return self.table.line_for(name)
        return ""

    def defined_in_project(self, name: str, path: Path) -> list:
        """Every module in the same project that defines this name at its top."""
        rel = path.relative_to(self.root)
        if len(rel.parts) < 3 or rel.parts[0] != "projects":
            return []
        home = self.root / rel.parts[0] / rel.parts[1]
        out = []
        for other in sorted(home.rglob("*.py")):
            if other == path or any(p.startswith(("_retired", "__pycache__", "test")) for p in other.relative_to(home).parts):
                continue
            try:
                tree = ast.parse(other.read_text(encoding="utf-8", errors="replace"))
            except SyntaxError:
                continue
            if any(isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
                   for n in tree.body):
                out.append(_module_of(other, self.root))
        return out

    def known_only(self, path: Path, content: str, said: str) -> str:
        """The content with every import that HAS one answer added; the rest left.

        Intention: for a file being built rather than one being mended — its
        other names may still be written, so one unknown name must not stop
        the known ones going in. Used by warp2/parts/imports_fill.py.
        """
        lines = [self.line_for(name, path) for name in self.names(said)]
        fresh = [line for line in lines if line and line not in content.splitlines()]
        return _insert_imports(content, fresh) if fresh else content

    def __call__(self, path: Path, content: str, said: str) -> str | None:
        """The content with the imports added, or None if any name has no single answer."""
        wanted = self.names(said)
        if not wanted:
            return None
        lines = [self.line_for(name, path) for name in wanted]
        if not all(lines):
            return None
        return _insert_imports(content, lines)


class ImportTimeMend:
    """Move top-level calls under `if __name__ == "__main__":`.

    Intention: the file keeps doing the same thing when run, and stops doing
    it when imported, which is what the refusal asks for. Only bare call
    statements move; nothing else in the module changes.
    """

    def __call__(self, path: Path, content: str, said: str) -> str | None:
        """Intention: None when the refusal is not this one or the file does not parse."""
        if AT_IMPORT not in said:
            return None
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return None
        calls = [n for n in tree.body if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
                 and ast.unparse(n.value.func).split(".")[-1] != "print"]
        if not calls:
            return None
        lines = content.splitlines()
        moved, drop = [], set()
        for node in calls:
            moved += lines[node.lineno - 1:node.end_lineno]
            drop.update(range(node.lineno - 1, node.end_lineno))
        kept = [line for at, line in enumerate(lines) if at not in drop]
        body = "\n".join("    " + line.strip() if line.strip() else "" for line in moved)
        return "\n".join(kept).rstrip() + '\n\n\nif __name__ == "__main__":\n' + body + "\n"


def _insert_imports(content: str, lines: list) -> str:
    """Put import lines after the header, the docstring and any `__future__` import.

    Intention: where a person would put them, so the header stays line one.
    """
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return "\n".join(lines) + "\n" + content
    after = 0
    for node in tree.body:
        is_doc = (isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant)
                  and isinstance(node.value.value, str) and after == 0)
        future = isinstance(node, ast.ImportFrom) and node.module == "__future__"
        if is_doc or future:
            after = node.end_lineno
        else:
            break
    rows = content.splitlines()
    lead = 0
    while lead < len(rows) and (rows[lead].startswith("#") or not rows[lead].strip()):
        lead += 1
    after = max(after, lead)
    fresh = [line for line in lines if line not in rows]
    return "\n".join(rows[:after] + fresh + rows[after:]) + ("\n" if content.endswith("\n") else "")



class DelimiterMend:
    """Mechanically close unterminated string literals and unclosed delimiters.

    Intention: when a model truncates output or leaves a string or bracket
    unclosed, close it deterministically so the syntax parses cleanly into an
    AST without guessing logic. The mended bytes pass through the gate checks.
    Andrew, 2026-09-18: "it should warn me the warp should fix it itself."
    """

    MATCHING = {"(": ")", "[": "]", "{": "}"}
    DELIMITER_PHRASES = (
        "unterminated", "eol while scanning", "unclosed", "was never closed",
    )

    def __call__(self, path: Path, content: str, said: str) -> str | None:
        """Intention: None when the file already parses or cannot be fixed deterministically."""
        try:
            ast.parse(content)
            return None
        except SyntaxError as exc:
            msg = (exc.msg or "").lower()
            if not any(k in msg or k in said.lower() for k in self.DELIMITER_PHRASES):
                return None

        fixed = self._fix_triple_quotes(content)
        if fixed is not None:
            return fixed

        fixed = self._fix_line_quotes(content)
        if fixed is not None:
            return fixed

        fixed = self._fix_brackets(content)
        if fixed is not None:
            return fixed

        return None

    def _fix_triple_quotes(self, content: str) -> str | None:
        """Intention: find an unclosed triple quote and insert the matching delimiter."""
        delim = None
        sline = 1
        scol = 0
        try:
            list(tokenize.tokenize(io.BytesIO(content.encode("utf-8")).readline))
        except tokenize.TokenError as exc:
            if "EOF in multi-line string" in str(exc.args[0]) and len(exc.args) > 1:
                sline, scol = exc.args[1]
        except Exception:  # Intention: any other tokenizer failure is not an unclosed triple quote; the count of quotes below decides instead.
            pass

        lines = content.splitlines(keepends=True)
        if 1 <= sline <= len(lines):
            line = lines[sline - 1]
            if '"""' in line[scol:]:
                delim = '"""'
            elif "'''" in line[scol:]:
                delim = "'''"

        if not delim:
            dq_count = content.count('"""')
            sq_count = content.count("'''")
            if dq_count % 2 == 1:
                delim = '"""'
            elif sq_count % 2 == 1:
                delim = "'''"

        if not delim:
            return None

        # Candidate 1: Append at EOF
        cand = content.rstrip() + "\n" + delim + "\n"
        try:
            ast.parse(cand)
            return cand
        except SyntaxError:
            pass

        # Candidate 2: Close immediately at end of starting line
        if 1 <= sline <= len(lines):
            mod_lines = list(lines)
            mod_lines[sline - 1] = mod_lines[sline - 1].rstrip() + delim + "\n"
            cand = "".join(mod_lines)
            try:
                ast.parse(cand)
                return cand
            except SyntaxError:
                pass

        # Candidate 3: Close before the next definition, import, or class after sline
        for i in range(sline, len(lines)):
            lstrip = lines[i].lstrip()
            if lstrip.startswith(("def ", "class ", "async def ", "import ", "from ", "@", "if __name__")):
                mod_lines = list(lines)
                mod_lines.insert(i, delim + "\n\n")
                cand = "".join(mod_lines)
                try:
                    ast.parse(cand)
                    return cand
                except SyntaxError:
                    pass

        return None

    def _fix_line_quotes(self, content: str) -> str | None:
        """Intention: fix unterminated single or double quotes on a single line."""
        try:
            ast.parse(content)
            return None
        except SyntaxError as exc:
            lineno = exc.lineno or 1
            offset = exc.offset or 1

        lines = content.splitlines(keepends=True)
        if not (1 <= lineno <= len(lines)):
            return None

        line = lines[lineno - 1]
        quote_char = None
        if 0 <= offset - 1 < len(line) and line[offset - 1] in ('"', "'"):
            quote_char = line[offset - 1]
        else:
            dq = line.count('"') - line.count('\\"')
            sq = line.count("'") - line.count("\\'")
            if dq % 2 == 1:
                quote_char = '"'
            elif sq % 2 == 1:
                quote_char = "'"

        if not quote_char:
            return None

        clean_line = line.rstrip("\r\n")
        ending = line[len(clean_line):] or "\n"

        for pos in range(len(clean_line), max(offset - 1, 0), -1):
            cand_line = clean_line[:pos] + quote_char + clean_line[pos:] + ending
            cand_lines = list(lines)
            cand_lines[lineno - 1] = cand_line
            cand_text = "".join(cand_lines)
            try:
                ast.parse(cand_text)
                return cand_text
            except SyntaxError:
                continue

        return None

    def _fix_brackets(self, content: str) -> str | None:
        """Intention: close unclosed parenthesis, square bracket, or brace."""
        try:
            ast.parse(content)
            return None
        except SyntaxError as exc:
            msg = exc.msg or ""
            lineno = exc.lineno or 1

        closing = None
        for op, cl in self.MATCHING.items():
            if f"'{op}' was never closed" in msg:
                closing = cl
                break

        if not closing:
            stack = []
            for ch in content:
                if ch in "([{":
                    stack.append(self.MATCHING[ch])
                elif ch in ")]}":
                    if stack and stack[-1] == ch:
                        stack.pop()
            if stack:
                closing = "".join(reversed(stack))

        if not closing:
            return None

        cand = content.rstrip() + closing + "\n"
        try:
            ast.parse(cand)
            return cand
        except SyntaxError:
            pass

        lines = content.splitlines(keepends=True)
        if 1 <= lineno <= len(lines):
            mod_lines = list(lines)
            clean_line = mod_lines[lineno - 1].rstrip("\r\n")
            mod_lines[lineno - 1] = clean_line + closing + "\n"
            cand = "".join(mod_lines)
            try:
                ast.parse(cand)
                return cand
            except SyntaxError:
                pass

        return None


class Mend:
    """Every mend there is, tried in turn; each fixes what it can, once.

    Intention: applied one after another, so a file refused for two mendable
    reasons comes out with both fixed. If nothing changed, the answer is None
    and the refusal stands exactly as it was.
    """

    def __init__(self, root, table=None) -> None:
        """Intention: the menders in the order they run."""
        self.root = Path(root)
        self.menders = (
            ("delimiter", DelimiterMend()),
            ("import", ImportMend(root, table)),
            ("import_time", ImportTimeMend()),
            # Intention: a file's imports of itself taken out (2026-09-25).
            ("self_import", SelfImportMend(root)),
        )

    def mend(self, path: str, content: str, said: str, context: dict | None = None) -> dict | None:
        """The mended content and which menders changed it, or None.

        Intention: `context` is what the loop showed the worker. Only the
        header mend reads it, for the intention the unit was raised with.
        """
        full = (self.root / path) if not Path(path).is_absolute() else Path(path)
        try:
            full.relative_to(self.root)
        except ValueError:
            return None
        text, used = content, []
        for name, mender in self.menders:
            got = mender(full, text, said)
            if got is not None and got != text:
                text, used = got, used + [name]
        # Intention: LAST, so the header describes the imports the other
        # menders may have just added.
        from warp2.gate.header_mend import HeaderMend
        got = HeaderMend(self.root)(full, text, said, context)
        if got is not None and got != text:
            text, used = got, used + ["header"]
        return {"content": text, "by": used} if used else None
