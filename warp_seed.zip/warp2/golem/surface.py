# WARP2/warp2/golem/surface.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/golem/surface.py
#  Used by   : warp2/golem/__init__.py, warp2/run.py (the `golem` command),
#              warp2/golem/tests/test_surface_golem.py.
#  Uses      : warp2/store/store.py (Store, store_home),
#              warp2/train/mistakes.py (Mistakes),
#              warp2/util.py (atomic_write_bytes, ensure_dir, now_iso, sha256_hex).
#  Description:
#    Implements the Surface Golem (`Seraph Golem` instance, `muse-84` & `muse-85`):
#      1. Capability Acquisition (`observe_capability` & `repeat_capability`):
#         watches a capability trace `(input, action, output)`, dehydrates it
#         into Prime-Space tags, supports both `model_search` and
#         `self_improvement` engines, and tracks continuous temperature deltas
#         and slopes on replay (no pass/fail bars, `muse-83`).
#      2. Two Plasticity Regimes (`NEXUS_REGIME` vs `GOLEM_REGIME`):
#         at the Nexus level, surface self-reformation is contained (only
#         bounded parameter tweaks allowed); at the Surface Golem level, it
#         runs wild to reshape visuals, interface, and behavior to the user's
#         intention.
#      3. User Rejection as a System-Wide Flag (`reject_reformation`):
#         when a user dislikes a Golem change, the change is reverted, stamped
#         as a negative mark in `Mistakes` / `KarmaWeb` (`BUILD_LOG 343`), and
#         queued in `state/golem/nexus_spool.jsonl` so parent Nexuses and the
#         whole web see the user's "no".
#  User intention (Andrew, 2026-10-18, muse-84 & muse-85):
#    "1. Capability acquisition: the system must be able to SEE a capability
#    and REPEAT it. Observe -> reproduce... 2. Self-reformation toward user
#    intention: the instance reshapes itself — visuals, interface, behavior,
#    everything — to fit the user's intention. 3. Two regimes: at the NEXUS
#    level, keep reformation CONTAINED (stable hub). At the SURFACE/GOLEM level
#    (Seraph Golem instances), let it RUN WILD — the edge is the testing
#    ground. 4. User rejection is a system flag."
# ============================================================================
from __future__ import annotations

import ast
import json
import re
from pathlib import Path

from warp2.store.store import Store, store_home
from warp2.train.mistakes import Mistakes
from warp2.util import atomic_write_bytes, ensure_dir, now_iso, sha256_hex

NEXUS_REGIME = "nexus_contained"
GOLEM_REGIME = "golem_wild"

# Intention: the two compounding engines from muse-84 item 6.
ENGINE_MODEL_SEARCH = "model_search"
ENGINE_SELF_IMPROVEMENT = "self_improvement"
VALID_ENGINES = (ENGINE_MODEL_SEARCH, ENGINE_SELF_IMPROVEMENT)

# Intention: in the contained Nexus regime, only safe operational tuning keys may change;
# wild UI/visual/layout/behavior reshaping belongs to the Surface Golem regime.
_NEXUS_ALLOWED_KEYS = frozenset({"batch_size", "concurrency", "cache_mb", "poll_seconds"})
_WORD_RE = re.compile(r"[a-zA-Z][a-zA-Z0-9_]{2,24}")


def dehydrate_trace_tags(trace_input: str, trace_action: str, trace_output: str, limit: int = 12) -> list[str]:
    """Dehydrate a watched `(input, action, output)` trace into compact Prime-Space tag tokens.

    Intention: the unit the Eye and Golem ingest from a watched capability is
    its tag signature across what arrived (`in:`), what was done (`act:`), and
    what came out (`out:`).
    """
    tags: list[str] = []
    seen: set[str] = set()
    for prefix, text in (("in", trace_input), ("act", trace_action), ("out", trace_output)):
        for match in _WORD_RE.findall(str(text or "").lower()):
            tag = f"{prefix}:{match}"
            if tag not in seen:
                seen.add(tag)
                tags.append(tag)
                if len(tags) >= limit:
                    return tags
    return tags


class SurfaceGolem:
    """A Seraph Golem surface instance (or contained Nexus hub) with capability acquisition and user-intention plasticity."""

    def __init__(
        self,
        state_dir: Path | str,
        regime: str = GOLEM_REGIME,
        instance_id: str = "seraph-golem-0",
        store: Store | None = None,
    ) -> None:
        """Intention: initialize the Golem state directory, plasticity regime, and backing KG store."""
        self.state_dir = Path(state_dir)
        self.regime = NEXUS_REGIME if regime == NEXUS_REGIME else GOLEM_REGIME
        self.instance_id = str(instance_id or "seraph-golem-0")
        self.home = ensure_dir(self.state_dir / "golem")
        self.surface_path = self.home / "surface.json"
        self.capabilities_path = self.home / "capabilities.json"
        self.spool_path = self.home / "nexus_spool.jsonl"
        self._external_store = store is not None
        self.store = store if store is not None else Store(store_home(self.state_dir))
        self.mistakes = Mistakes(self.store)

    def _load_json(self, path: Path, default: dict) -> dict:
        """Intention: safe JSON reader with fallback default."""
        if not path.is_file():
            return dict(default)
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else dict(default)
        except Exception:
            return dict(default)

    def _save_json(self, path: Path, payload: dict) -> None:
        """Intention: atomic JSON writer using warp2.util.atomic_write_bytes."""
        atomic_write_bytes(path, json.dumps(payload, indent=2, sort_keys=True).encode("utf-8"))

    def _append_spool(self, event: dict) -> None:
        """Intention: append an upstream event to the Nexus failsafe spool (`muse-84` & `muse-85`)."""
        ensure_dir(self.spool_path.parent)
        with self.spool_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({**event, "instance_id": self.instance_id, "at": now_iso()}, sort_keys=True) + "\n")

    def surface_state(self) -> dict:
        """Return the current surface state (visuals, interface, behavior, history)."""
        return self._load_json(
            self.surface_path,
            {
                "instance_id": self.instance_id,
                "regime": self.regime,
                "intention": "",
                "config": {"theme": "default", "layout": "standard", "behavior": "balanced"},
                "reformations": [],
            },
        )

    def reform(self, user_intention: str, changes: dict) -> dict:
        """Reshape the instance toward `user_intention` according to its regime (`golem_wild` vs `nexus_contained`).

        Intention: "At the NEXUS level, keep reformation CONTAINED (stable hub).
        At the SURFACE/GOLEM level (Seraph Golem instances), let it RUN WILD —
        the edge is the testing ground." (muse-84).
        """
        state = self.surface_state()
        previous_config = dict(state.get("config") or {})

        if self.regime == NEXUS_REGIME:
            blocked = [k for k in changes if k not in _NEXUS_ALLOWED_KEYS]
            if blocked:
                return {
                    "applied": False,
                    "contained": True,
                    "regime": self.regime,
                    "blocked_keys": sorted(blocked),
                    "why": "Nexus regime is contained; wild surface/UI reformation is restricted to Surface Golem instances",
                }

        updated_config = {**previous_config, **dict(changes or {})}
        ref_id = sha256_hex(f"{self.instance_id}|{user_intention}|{json.dumps(changes, sort_keys=True)}|{now_iso()}".encode("utf-8"))[:12]
        entry = {
            "id": ref_id,
            "user_intention": str(user_intention),
            "changes": dict(changes or {}),
            "previous_config": previous_config,
            "status": "active",
            "at": now_iso(),
        }
        state["intention"] = str(user_intention)
        state["config"] = updated_config
        state.setdefault("reformations", []).append(entry)
        self._save_json(self.surface_path, state)

        node = f"golem:{self.instance_id}"
        self.store.assert_fact(node, "has", attr="kind", value="surface_golem")
        self.store.assert_fact(node, "has", attr="regime", value=self.regime)
        self.store.assert_fact(node, "has", attr="user_intention", value=str(user_intention))
        self.store.assert_fact(node, "has", attr="last_reformation", value=ref_id)
        return {"applied": True, "contained": False, "reformation_id": ref_id, "config": updated_config}

    def reject_reformation(self, reformation_id: str, reason: str = "user disliked surface change") -> dict:
        """Revert a reformation when the user says 'no' and broadcast a system-wide negative stamp to the Nexus.

        Intention: "User rejection is a system flag: if a user dislikes the
        changes, that's a flag for the entire system, propagated up to the
        nexuses. The user's 'no' is a negative stamp the whole web sees." (muse-84).
        """
        state = self.surface_state()
        reformations = state.get("reformations") or []
        target_entry = None
        for entry in reversed(reformations):
            if entry.get("id") == reformation_id:
                target_entry = entry
                break
        if target_entry is None:
            return {"reverted": False, "why": f"reformation {reformation_id} not found"}

        state["config"] = dict(target_entry.get("previous_config") or {})
        target_entry["status"] = "rejected_by_user"
        target_entry["rejected_reason"] = str(reason)
        self._save_json(self.surface_path, state)

        target_node = f"golem:{self.instance_id}:reformation:{reformation_id}"
        self.mistakes.note(
            target_node,
            f"user_rejection: {reason}",
            stamped_by=f"user:{self.instance_id}",
            appeal_check="require explicit user re-approval on surface preview",
        )
        flag = {
            "event": "user_rejection_flag",
            "target": target_node,
            "reformation_id": reformation_id,
            "user_intention": target_entry.get("user_intention", ""),
            "rejected_changes": target_entry.get("changes", {}),
            "reason": str(reason),
        }
        self._append_spool(flag)
        return {"reverted": True, "target": target_node, "config": state["config"], "flag": flag}

    def observe_capability(
        self,
        name: str,
        trace_input: str,
        trace_action: str,
        trace_output: str,
        engine: str = ENGINE_SELF_IMPROVEMENT,
        model_id: str = "",
    ) -> dict:
        """Observe a capability trace, dehydrate it into Prime-Space tags, and register it for repetition.

        Intention: "Capability acquisition: the system must be able to SEE a
        capability and REPEAT it. Observe -> reproduce." Supports both engines
        (`model_search` and `self_improvement`, muse-84).
        """
        chosen_engine = engine if engine in VALID_ENGINES else ENGINE_SELF_IMPROVEMENT
        tags = dehydrate_trace_tags(trace_input, trace_action, trace_output)
        caps = self._load_json(self.capabilities_path, {"capabilities": {}})
        existing = (caps.get("capabilities") or {}).get(name) or {}
        history = list(existing.get("temperatures") or [])

        record = {
            "name": str(name),
            "engine": chosen_engine,
            "model_id": str(model_id or existing.get("model_id") or ""),
            "tags": tags,
            "trace_example": {
                "input": str(trace_input),
                "action": str(trace_action),
                "output": str(trace_output),
            },
            "temperatures": history,
            "observed_at": now_iso(),
        }
        caps.setdefault("capabilities", {})[str(name)] = record
        self._save_json(self.capabilities_path, caps)

        node = f"capability:{name}"
        self.store.assert_fact(node, "has", attr="kind", value="capability")
        self.store.assert_fact(node, "has", attr="engine", value=chosen_engine)
        self.store.assert_fact(node, "has", attr="tags", value=",".join(tags))
        if model_id:
            self.store.assert_fact(node, "has", attr="model_id", value=str(model_id))
        return record

    def repeat_capability(self, name: str, new_input: str, temperature: float | None = None) -> dict:
        """Repeat an observed capability on `new_input` and update its continuous temperature delta and slope.

        Intention: no pass/fail promotion bars (muse-83) — every repetition
        records `(temperature, previous_temperature, delta, slope)` so the Golem
        always uses the best capability/model provisionally.
        """
        caps = self._load_json(self.capabilities_path, {"capabilities": {}})
        record = (caps.get("capabilities") or {}).get(str(name))
        if not record:
            return {"repeated": False, "why": f"capability {name} has not been observed yet"}

        history = list(record.get("temperatures") or [])
        prev_temp = float(history[-1]) if history else None
        cur_temp = round(float(temperature), 4) if isinstance(temperature, (int, float)) else prev_temp
        delta = round(cur_temp - prev_temp, 4) if (cur_temp is not None and prev_temp is not None) else None

        if isinstance(temperature, (int, float)):
            history.append(cur_temp)
            record["temperatures"] = history[-50:]

        slope = None
        if len(history) >= 2:
            slope = round((float(history[-1]) - float(history[0])) / (len(history) - 1), 4)

        record["last_repeated_at"] = now_iso()
        record["last_input"] = str(new_input)
        caps["capabilities"][str(name)] = record
        self._save_json(self.capabilities_path, caps)

        node = f"capability:{name}"
        if cur_temp is not None:
            self.store.assert_fact(node, "has", attr="temperature", value=str(cur_temp))
        if delta is not None:
            self.store.assert_fact(node, "has", attr="temperature_delta", value=str(delta))
        if slope is not None:
            self.store.assert_fact(node, "has", attr="temperature_slope", value=str(slope))

        return {
            "repeated": True,
            "name": str(name),
            "engine": record.get("engine", ENGINE_SELF_IMPROVEMENT),
            "model_id": record.get("model_id", ""),
            "tags": list(record.get("tags") or []),
            "action_template": (record.get("trace_example") or {}).get("action", ""),
            "temperature": cur_temp,
            "previous_temperature": prev_temp,
            "delta": delta,
            "slope": slope,
        }

    def pending_nexus_flags(self) -> list[dict]:
        """Read all upstream flags and capability deltas queued in the failsafe Nexus spool."""
        if not self.spool_path.is_file():
            return []
        rows: list[dict] = []
        for line in self.spool_path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                rows.append(json.loads(line))
            except ValueError:
                continue
        return rows

    def accept_project_capability(
        self,
        project_name: str,
        root_dir: Path | str,
        temperature: float = 0.75,
    ) -> dict:
        """Accept a built project under `projects/<project_name>` and register it as a live capability.

        Intention (Andrew, 2026-10-18): "are the projects still being done
        because they should be and have a pathway where they can be accepted and
        added into the code as a capability that is what they were meant for."
        Verifies that the project's Python files parse cleanly, extracts its
        public entrypoints, registers `project:<name>` in `capabilities.json`
        and the KG, and queues it for Nexus/Golem sync.
        """
        clean_name = str(project_name).replace("project:", "").strip()
        proj_dir = Path(root_dir).resolve() / "projects" / clean_name
        if not proj_dir.is_dir():
            return {"accepted": False, "why": f"project directory {proj_dir} does not exist"}

        py_files = [
            p
            for p in sorted(proj_dir.rglob("*.py"))
            if "__pycache__" not in p.parts and "tests" not in p.parts and not p.name.startswith("test_")
        ]
        if not py_files:
            return {"accepted": False, "why": f"project {clean_name} has no production .py modules"}

        modules: list[str] = []
        entrypoints: list[str] = []
        summary_doc = ""
        root_resolved = Path(root_dir).resolve()

        for py_path in py_files:
            try:
                src = py_path.read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(src, filename=str(py_path))
            except SyntaxError as exc:
                return {"accepted": False, "why": f"syntax error in {py_path.name}: {exc}"}

            rel_mod = py_path.relative_to(root_resolved).as_posix()
            modules.append(rel_mod)
            if not summary_doc:
                doc = ast.get_docstring(tree) or ""
                if doc:
                    summary_doc = " ".join(doc.strip().splitlines()[:2])
            for node in tree.body:
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    if not node.name.startswith("_"):
                        entrypoints.append(f"{py_path.stem}.{node.name}")

        cap_key = f"project:{clean_name}"
        tags = dehydrate_trace_tags(
            clean_name,
            " ".join(entrypoints[:8]) or "project_module",
            summary_doc or " ".join(modules[:4]),
        )
        caps = self._load_json(self.capabilities_path, {"capabilities": {}})
        existing = (caps.get("capabilities") or {}).get(cap_key) or {}
        history = list(existing.get("temperatures") or [])
        if isinstance(temperature, (int, float)):
            history.append(round(float(temperature), 4))

        record = {
            "name": cap_key,
            "kind": "project",
            "project": clean_name,
            "engine": ENGINE_SELF_IMPROVEMENT,
            "modules": modules,
            "entrypoints": entrypoints[:24],
            "says": summary_doc or f"Accepted project capability `{clean_name}` ({len(modules)} module(s)).",
            "tags": tags,
            "trace_example": {
                "input": clean_name,
                "action": f"import projects.{clean_name} ({', '.join(entrypoints[:5])})",
                "output": summary_doc or f"{len(modules)} verified modules",
            },
            "temperatures": history[-50:],
            "accepted_at": now_iso(),
        }
        caps.setdefault("capabilities", {})[cap_key] = record
        self._save_json(self.capabilities_path, caps)

        cap_node = f"capability:{cap_key}"
        proj_node = f"project:{clean_name}"
        self.store.assert_fact(cap_node, "has", attr="kind", value="project_capability")
        self.store.assert_fact(cap_node, "has", attr="project", value=clean_name)
        self.store.assert_fact(cap_node, "has", attr="modules", value=",".join(modules[:12]))
        self.store.assert_fact(cap_node, "has", attr="entrypoints", value=",".join(entrypoints[:12]))
        self.store.assert_fact(cap_node, "has", attr="tags", value=",".join(tags))
        self.store.assert_fact(proj_node, "has", attr="accepted_as_capability", value="true")
        self.store.assert_fact(proj_node, "has", attr="capability_node", value=cap_node)

        self._append_spool(
            {
                "event": "project_capability_accepted",
                "capability": cap_key,
                "project": clean_name,
                "modules": modules,
                "entrypoints": entrypoints[:12],
            }
        )
        return {"accepted": True, "capability": cap_key, "record": record}

    def check_progression_signal(self, name: str) -> dict:
        """Check whether a capability is progressing or stalled, and fire `'look_for_progression'` if stalled.

        Intention (muse-87): self-examination checks if the system is doing
        better (`delta > 0` or `slope > 0`). When a capability's temperature
        stalls or drops (`delta <= 0` or `slope <= 0`), emit a
        `look_for_progression` signal so the Golem/Nexus triggers `model_search`
        and opens self-improvement work.
        """
        caps = self._load_json(self.capabilities_path, {"capabilities": {}})
        record = (caps.get("capabilities") or {}).get(str(name))
        if not record:
            return {"checked": False, "why": f"capability {name} not found"}

        temps = [float(x) for x in (record.get("temperatures") or []) if isinstance(x, (int, float))]
        if len(temps) < 2:
            return {"checked": True, "name": str(name), "progressing": True, "signal": "warming_up"}

        delta = round(temps[-1] - temps[-2], 4)
        slope = round((temps[-1] - temps[0]) / (len(temps) - 1), 4)
        progressing = delta > 0.0 and slope >= 0.0

        node = f"capability:{name}"
        if not progressing:
            record["needs_progression"] = True
            record["recommended_next_engine"] = (
                ENGINE_MODEL_SEARCH
                if record.get("engine") == ENGINE_SELF_IMPROVEMENT
                else ENGINE_SELF_IMPROVEMENT
            )
            caps["capabilities"][str(name)] = record
            self._save_json(self.capabilities_path, caps)
            self.store.assert_fact(node, "has", attr="needs_progression", value="true")
            self.store.assert_fact(node, "has", attr="progression_signal", value="look_for_progression")
            signal_event = {
                "event": "look_for_progression",
                "capability": str(name),
                "temperature": temps[-1],
                "delta": delta,
                "slope": slope,
                "recommended_next_engine": record["recommended_next_engine"],
            }
            self._append_spool(signal_event)
            return {
                "checked": True,
                "name": str(name),
                "progressing": False,
                "signal": "look_for_progression",
                "delta": delta,
                "slope": slope,
                "recommended_next_engine": record["recommended_next_engine"],
            }

        self.store.assert_fact(node, "has", attr="needs_progression", value="false")
        self.store.assert_fact(node, "has", attr="progression_signal", value="progressing")
        return {
            "checked": True,
            "name": str(name),
            "progressing": True,
            "signal": "progressing",
            "delta": delta,
            "slope": slope,
        }

    def sync_communications(self, relay_dir: Path | str) -> dict:
        """Two-way communication bridge between this Golem/Nexus instance and a shared relay folder.

        Intention (Andrew, 2026-10-18): "we need to also have the comunication
        system in as well". Pushes queued Nexus spool events (user rejection
        flags, progression signals, hardware blooms, and accepted capabilities)
        out to `<relay_dir>/golem_channel/` and pulls remote flags and
        capabilities from peer Golems/Nexuses into local state and the KG.
        """
        channel = ensure_dir(Path(relay_dir).resolve() / "golem_channel")
        pending = self.pending_nexus_flags()

        outbox_file = channel / f"events_{self.instance_id}.jsonl"
        sent_events = 0
        if pending:
            with outbox_file.open("a", encoding="utf-8") as stream:
                for item in pending:
                    stream.write(json.dumps(item, sort_keys=True) + "\n")
                    sent_events += 1
            archive_spool = self.home / "synced_spool.jsonl"
            with archive_spool.open("a", encoding="utf-8") as stream:
                for item in pending:
                    stream.write(json.dumps(item, sort_keys=True) + "\n")
            self.spool_path.unlink(missing_ok=True)

        local_caps = self._load_json(self.capabilities_path, {"capabilities": {}})
        caps_map = dict(local_caps.get("capabilities") or {})
        shared_caps_file = channel / f"capabilities_{self.instance_id}.json"
        self._save_json(
            shared_caps_file,
            {"instance_id": self.instance_id, "regime": self.regime, "capabilities": caps_map, "updated_at": now_iso()},
        )

        received_caps = 0
        received_flags = 0

        for peer_caps_path in sorted(channel.glob("capabilities_*.json")):
            if peer_caps_path.name == shared_caps_file.name:
                continue
            peer_data = self._load_json(peer_caps_path, {})
            for cname, crecord in (peer_data.get("capabilities") or {}).items():
                if not isinstance(crecord, dict):
                    continue
                local_rec = caps_map.get(cname)
                peer_temps = [float(x) for x in (crecord.get("temperatures") or []) if isinstance(x, (int, float))]
                local_temps = [
                    float(x) for x in ((local_rec or {}).get("temperatures") or []) if isinstance(x, (int, float))
                ]
                peer_best = max(peer_temps) if peer_temps else -1.0
                local_best = max(local_temps) if local_temps else -1.0
                if local_rec is None or peer_best > local_best:
                    caps_map[cname] = dict(crecord)
                    received_caps += 1
                    cnode = f"capability:{cname}"
                    self.store.assert_fact(cnode, "has", attr="kind", value=str(crecord.get("kind") or "capability"))
                    self.store.assert_fact(
                        cnode, "has", attr="engine", value=str(crecord.get("engine") or ENGINE_SELF_IMPROVEMENT)
                    )
                    self.store.assert_fact(cnode, "has", attr="synced_from", value=str(peer_data.get("instance_id", "")))

        if received_caps > 0:
            local_caps["capabilities"] = caps_map
            self._save_json(self.capabilities_path, local_caps)

        seen_Sync = self._load_json(self.home / "seen_peer_events.json", {"ids": []})
        seen_ids = set(seen_Sync.get("ids") or [])
        for peer_events_path in sorted(channel.glob("events_*.jsonl")):
            if peer_events_path.name == outbox_file.name:
                continue
            for line in peer_events_path.read_text(encoding="utf-8", errors="replace").splitlines():
                try:
                    ev = json.loads(line)
                except ValueError:
                    continue
                ev_sig = sha256_hex(line.encode("utf-8"))[:16]
                if ev_sig in seen_ids:
                    continue
                seen_ids.add(ev_sig)
                received_flags += 1
                if ev.get("event") == "user_rejection_flag" and ev.get("target"):
                    self.mistakes.note(
                        str(ev["target"]),
                        f"peer_user_rejection: {ev.get('reason', 'rejected on peer golem')}",
                        stamped_by=f"peer:{ev.get('instance_id', 'golem')}",
                        appeal_check="require explicit user re-approval on surface preview",
                    )
                elif ev.get("event") == "look_for_progression" and ev.get("capability"):
                    self.store.assert_fact(
                        f"capability:{ev['capability']}", "has", attr="needs_progression", value="true"
                    )

        self._save_json(self.home / "seen_peer_events.json", {"ids": sorted(seen_ids)[-500:]})
        return {
            "channel": str(channel),
            "sent_events": sent_events,
            "shared_capabilities": len(caps_map),
            "received_capabilities": received_caps,
            "received_flags": received_flags,
        }

