# WARP2/warp2/golem/tests/test_surface_golem.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/golem/tests/test_surface_golem.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/golem/surface.py, warp2/store/karma.py, warp2/store/store.py.
#  Description:
#    Verifies the Surface Golem (`Seraph Golem`, `muse-84` & `muse-85`):
#      1. Capability acquisition (`observe_capability` -> `dehydrate_trace_tags`
#         -> `repeat_capability` with continuous temperature deltas & slopes).
#      2. Self-reformation toward user intention in `golem_wild` vs containment
#         in `nexus_contained`.
#      3. User rejection reverting the surface change, stamping a negative mark
#         in `KarmaWeb`, and queueing a system-wide flag in `nexus_spool.jsonl`.
#  User intention (Andrew, 2026-10-18, muse-84):
#    "1. Capability acquisition: the system must be able to SEE a capability
#    and REPEAT it... 2. Self-reformation toward user intention... 3. Two
#    regimes: at the NEXUS level, keep reformation CONTAINED (stable hub). At
#    the SURFACE/GOLEM level (Seraph Golem instances), let it RUN WILD...
#    4. User rejection is a system flag."
# ============================================================================
from __future__ import annotations

from warp2.golem import surface
from warp2.store.karma import KarmaWeb
from warp2.store.store import Store, store_home


def test_nexus_contains_wild_reformation_while_surface_golem_reshapes_and_propagates_user_rejection(tmp_path):
    """Intention: Nexus blocks wild UI/behavior changes; Surface Golem applies them, and user rejection reverts + flags KarmaWeb & Nexus spool."""
    store = Store(store_home(tmp_path))
    try:
        nexus = surface.SurfaceGolem(tmp_path, regime=surface.NEXUS_REGIME, instance_id="hub-1", store=store)
        blocked = nexus.reform("make the whole screen neon and hide menus", {"theme": "neon", "layout": "minimal"})
        assert blocked["applied"] is False and blocked["contained"] is True
        assert "layout" in blocked["blocked_keys"] and "theme" in blocked["blocked_keys"]

        # Contained tuning keys ARE allowed at the Nexus level.
        allowed = nexus.reform("tune batch size", {"batch_size": 16})
        assert allowed["applied"] is True and allowed["contained"] is False

        # At the Surface Golem level, visual/interface/behavior reformation runs wild.
        golem = surface.SurfaceGolem(tmp_path, regime=surface.GOLEM_REGIME, instance_id="seraph-1", store=store)
        wild = golem.reform(
            "focus purely on fast sketch comparison",
            {"theme": "high_contrast", "layout": "split_canvas", "behavior": "fast_sketch"},
        )
        assert wild["applied"] is True and wild["contained"] is False
        assert golem.surface_state()["config"]["layout"] == "split_canvas"

        # User dislikes the change -> reverts config, creates active Karma tension, and queues Nexus spool flag.
        rej = golem.reject_reformation(wild["reformation_id"], reason="split canvas hid the prompt bar")
        assert rej["reverted"] is True
        assert golem.surface_state()["config"]["layout"] == "standard"

        kw = KarmaWeb(store=store)
        tensions = {t.source: t for t in kw.active_tensions()}
        assert rej["target"] in tensions
        assert "split canvas hid the prompt bar" in tensions[rej["target"]].counter_force

        flags = golem.pending_nexus_flags()
        assert len(flags) == 1
        assert flags[0]["event"] == "user_rejection_flag"
        assert flags[0]["reformation_id"] == wild["reformation_id"]
    finally:
        store.close()


def test_golem_observes_capability_dehydrates_tags_and_repeats_with_temperature_slope(tmp_path):
    """Intention: observe a capability trace, dehydrate into Prime-Space tags, and track continuous temperature deltas/slopes on repeat."""
    store = Store(store_home(tmp_path))
    try:
        golem = surface.SurfaceGolem(tmp_path, regime=surface.GOLEM_REGIME, instance_id="seraph-2", store=store)
        obs = golem.observe_capability(
            "svg_icon_mint",
            trace_input="draw a crisp vector gear icon",
            trace_action="invoke local_svg_coder with viewBox 0 0 24 24",
            trace_output="<svg viewBox='0 0 24 24'><circle cx='12' cy='12' r='8'/></svg>",
            engine=surface.ENGINE_MODEL_SEARCH,
            model_id="qwen2.5-coder:7b",
        )
        assert obs["engine"] == surface.ENGINE_MODEL_SEARCH
        assert any(t.startswith("in:") for t in obs["tags"])
        assert any(t.startswith("act:") for t in obs["tags"])
        assert any(t.startswith("out:") for t in obs["tags"])

        r1 = golem.repeat_capability("svg_icon_mint", "draw a vector bell icon", temperature=0.62)
        assert r1["repeated"] is True
        assert r1["temperature"] == 0.62 and r1["previous_temperature"] is None and r1["delta"] is None

        r2 = golem.repeat_capability("svg_icon_mint", "draw a vector star icon", temperature=0.78)
        assert r2["temperature"] == 0.78
        assert r2["previous_temperature"] == 0.62
        assert r2["delta"] == 0.16
        assert r2["slope"] == 0.16

        attrs = {f["attr"]: f["value"] for f in store.current(subject="capability:svg_icon_mint")}
        assert attrs.get("temperature") == "0.78"
        assert attrs.get("temperature_delta") == "0.16"
        assert attrs.get("temperature_slope") == "0.16"
    finally:
        store.close()


def test_project_acceptance_two_way_comms_progression_and_gui_capabilities(tmp_path):
    """Intention: built projects are accepted as capabilities, progression signals fire when stalled, two-way comms sync across Golems/Nexuses, and the GUI surfaces them."""
    from warp2.app.capabilities import Capabilities

    root_dir = tmp_path / "workspace"
    proj_dir = root_dir / "projects" / "vector_forge"
    proj_dir.mkdir(parents=True)
    (proj_dir / "forge.py").write_text(
        '"""Vector forge capability module."""\n\ndef render_svg(shape: str) -> str:\n    """Intention: render a shape to SVG."""\n    return f"<svg>{shape}</svg>"\n',
        encoding="utf-8",
    )

    state_a = tmp_path / "state_a"
    state_b = tmp_path / "state_b"
    relay_dir = tmp_path / "shared_relay"

    store_a = Store(store_home(state_a))
    store_b = Store(store_home(state_b))
    try:
        golem_a = surface.SurfaceGolem(state_a, regime=surface.GOLEM_REGIME, instance_id="golem-a", store=store_a)
        accepted = golem_a.accept_project_capability("vector_forge", root_dir, temperature=0.84)
        assert accepted["accepted"] is True
        assert accepted["capability"] == "project:vector_forge"
        assert "forge.render_svg" in accepted["record"]["entrypoints"]

        # When a capability stalls or drops in temperature, check_progression_signal emits look_for_progression.
        golem_a.repeat_capability("project:vector_forge", "circle", temperature=0.79)
        prog = golem_a.check_progression_signal("project:vector_forge")
        assert prog["progressing"] is False
        assert prog["signal"] == "look_for_progression"
        assert prog["recommended_next_engine"] == surface.ENGINE_MODEL_SEARCH

        # Sync Golem A to the shared relay channel, then sync Nexus B from the same channel.
        sync_a = golem_a.sync_communications(relay_dir)
        assert sync_a["sent_events"] >= 2
        assert sync_a["shared_capabilities"] == 1

        nexus_b = surface.SurfaceGolem(state_b, regime=surface.NEXUS_REGIME, instance_id="nexus-b", store=store_b)
        sync_b = nexus_b.sync_communications(relay_dir)
        assert sync_b["received_capabilities"] == 1
        assert sync_b["received_flags"] >= 1

        # Verify GUI Capabilities reads the accepted project and Surface Golem state.
        gui_caps = Capabilities(root_dir, state_a).all(entries=[])
        cap_by_key = {c["key"]: c for c in gui_caps}
        assert "cap:project:vector_forge" in cap_by_key
        assert cap_by_key["cap:project:vector_forge"]["kind"] == "project"
    finally:
        store_a.close()
        store_b.close()

