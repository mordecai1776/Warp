# WARP2/warp2/golem/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/golem/__init__.py
#  Used by   : warp2/run.py, warp2/golem/surface.py,
#              warp2/golem/tests/test_surface_golem.py.
#  Uses      : warp2/golem/surface.py.
#  Description:
#    Package entry for the Surface Golem (`Seraph Golem`): capability
#    acquisition (`observe -> dehydrate -> repeat`), self-reformation toward
#    user intention across the `nexus` (contained) and `golem` (wild) regimes,
#    and user-rejection negative-stamp propagation to the Nexus spool.
#  User intention (Andrew, 2026-10-18, muse-84 & muse-85):
#    "1. Capability acquisition: the system must be able to SEE a capability
#    and REPEAT it... 2. Self-reformation toward user intention... 3. Two
#    regimes: at the NEXUS level, keep reformation CONTAINED (stable hub). At
#    the SURFACE/GOLEM level (Seraph Golem instances), let it RUN WILD...
#    4. User rejection is a system flag."
# ============================================================================
from __future__ import annotations

from warp2.golem.surface import GOLEM_REGIME, NEXUS_REGIME, SurfaceGolem, dehydrate_trace_tags

__all__ = [
    "GOLEM_REGIME",
    "NEXUS_REGIME",
    "SurfaceGolem",
    "dehydrate_trace_tags",
]
