# WARP2/warp2/capability/project_maker.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/project_maker.py
#  Used by   : warp2/work/side/capability.py, warp2/capability/tests.
#  Uses      : warp2/store/projects.py (Projects.open, add_area — through the
#              loop's own Projects), warp2/capability/notes.py (TaskNotes).
#  Description:
#    When the Eye cannot do a task models are trained for — the task's data
#    is not a shape it can take yet, or it has tried and is still no better
#    than guessing — a project is opened for it, with the areas that would
#    make it able: a way to read the task's input, the Eye's part for the
#    task, and a check against unseen examples. The build lane then builds
#    them like any other project. One project a task, opened once.
#  User intention (Andrew):
#    2026-09-24: "if it needs to make a new project it should do so."
# ============================================================================
from __future__ import annotations

# Intention: how many tries with nothing over guessing before the task is
# given a project of its own. Two: one dataset can be a bad draw; two is a
# pattern worth building for.
TRIES_BEFORE_PROJECT = 2


def project_name(task_id: str) -> str:
    """Intention: the project a task's ability is built in, named for the task."""
    return "eye_" + "".join(ch if ch.isalnum() else "_" for ch in str(task_id)).strip("_")


def needs_project(summary: dict, tries: list) -> str:
    """Why this task needs a project of its own, or "" when it does not (yet).

    Intention: two kinds of "cannot": the Eye could not even be asked (every
    try was a shape it cannot take, or data it could not read), or it was
    asked and learned nothing, try after try.
    """
    if len(tries) < TRIES_BEFORE_PROJECT:
        return ""
    asked = [t for t in tries if "right" in t]
    if not asked:
        return "the Eye cannot take this task's data yet: " + str(tries[-1].get("said") or "")
    if (summary.get("best_over_guessing") or 0.0) <= 0.0:
        return f"after {len(asked)} tries the Eye is no better than guessing"
    return ""


def open_for(projects, task: dict, why: str) -> dict:
    """Open the task's project with its three areas; nothing if it is already open.

    Intention: the areas say what each piece is FOR, because the gate judges
    what is built against that sentence.
    """
    name = project_name(task["id"])
    if projects.store.current(subject=f"project:{name}", attr="kind"):
        return {"opened": False, "project": name, "why": "already open"}
    label = task.get("label") or task["id"]
    projects.open(name, intention=(f"Make the WARP's Eye able to do {label} — what models trained for "
                                   f"{label} do: {task.get('summary') or label}. Why: {why}."),
                  source="capability")
    projects.add_area(name, "input", f"read the input of {label} examples from the task's datasets "
                                     f"into pieces the Eye's heads can take")
    projects.add_area(name, "part", f"the Eye's part for {label}: learn from the task's datasets and "
                                    f"answer the way models trained for {label} answer")
    projects.add_area(name, "check", f"measure the Eye's {label} part on examples it has not seen, "
                                     f"against always guessing, and write it in state/capability/notes.jsonl")
    return {"opened": True, "project": name, "why": why}
