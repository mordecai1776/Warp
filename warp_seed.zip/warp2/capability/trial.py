# WARP2/warp2/capability/trial.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/trial.py
#  Used by   : warp2/work/side/capability.py, warp2/capability/tests.
#  Uses      : warp2/capability/examples.py (HubRows, shaped),
#              warp2/capability/notes.py (TaskNotes),
#              projects/behemoth_eye/eye/warp_eye.py (EyeBook — the WARP's one
#              Eye, a part per task), warp2/refine/modality.py (_fetch — a
#              picture's bytes), warp2/capability/searched_set.py (SearchedSet —
#              pictures found by search for the classes a card names),
#              warp2/capability/rate_check.py (RateCheck — the Eye beside the
#              smallest standard learners on the same examples); torch,
#              PIL (only when a try runs).
#  Description:
#    One try of the Eye at one task on one dataset: the examples are split
#    four to one, the Eye's part for the task learns the four and is asked
#    the one it has not seen, and what it got right is set against what
#    always giving the commonest answer would get. The try is written down
#    whatever happens — a dataset that could not be read, or a shape the Eye
#    cannot take, is a note too.
#    BUILD_LOG (2026-11-04): when the dataset cannot be read or is not shaped
#    for the Eye, and the hub's card names the classes of a picture dataset,
#    the warp makes its own from picture search (SearchedSet) and tries on
#    that; the note says it was made so. A renamed dataset is noted under its
#    new name, with the old one beside it.
#    BUILD_LOG 1477 (2026-11-09): each try's note says where its time went
#    (parts first, the lesson, what grew) and the memory free around it.
#    BUILD_LOG (2026-11-05): every try is set beside standard learners taught
#    the same examples (RateCheck): the smallest that does the task (the
#    minimum), and what the Eye cost against it (efficiency). The note keeps
#    it, with the caveats for the Eye's different design.
#  User intention (Andrew):
#    2026-09-24: "try to get the eye to do it and take notes on how it does."
#    2026-11-04: "why it is not making its own dataset from search"; "Let's do all 3".
# ============================================================================
from __future__ import annotations

import io
import random
import time
from collections import Counter

# Intention: the side a picture is read at — small, so a try costs seconds,
# and the same for every picture so one part reads them all alike.
PICTURE_SIDE = 32


def free_memory_mb() -> int | None:
    """Intention: the memory free on the machine now, in MB; None when it cannot be read here."""
    try:
        import psutil
    except ImportError:  # fault: ok - None is "cannot be read here", said as such in the note
        return None
    return int(psutil.virtual_memory().available // (1024 * 1024))


class EyeTrial:
    """One try of the Eye at a task, and its note."""

    def __init__(self, state_dir, notes, rows=None, book=None, fetch=None, searched=None, rate=None) -> None:
        """Intention: keep the state folder, the notes, the hub rows and the optional book, fetch and searched set a
        trial uses.
        """
        from warp2.capability.examples import HubRows
        self.state_dir = state_dir
        self.notes = notes
        self.rows = rows or HubRows()
        self._book = book
        self._fetch = fetch
        self._searched = searched
        self._rate = rate

    def rate(self):
        """Intention: the check against the standard learners, made when first needed."""
        if self._rate is None:
            from warp2.capability.rate_check import RateCheck
            self._rate = RateCheck()
        return self._rate

    @staticmethod
    def eye_weights(book, part: str, classes: list):
        """Intention: how many weights the Eye's concepts for this part hold (normal and inverse networks); None when
        they cannot be counted."""
        try:
            pairs = book.warp.eye.concepts.pairs
            total = 0
            for c in classes:
                pair = pairs[f"{part}: {c}"].pair
                for side in (pair.normal, pair.inverse):
                    total += sum(p.numel() for p in side.model.parameters())
            return int(total)
        except Exception:
            return None

    def searched(self):
        """Intention: the maker of a dataset from picture search, made when first needed (the root is state's parent)."""
        if self._searched is None:
            from pathlib import Path
            from warp2.capability.searched_set import SearchedSet
            self._searched = SearchedSet(Path(self.state_dir).parent, self.state_dir)
        return self._searched

    def book(self):
        """Intention: the one Eye, opened only when a try reaches it."""
        if self._book is None:
            from projects.behemoth_eye.eye.warp_eye import EyeBook
            self._book = EyeBook(self.state_dir)
        return self._book

    def _picture(self, cell):
        """Intention: a viewer picture cell ({src: …}) as a 3×side×side tensor in 0..1, or None."""
        import numpy as np
        import torch
        from PIL import Image
        src = cell.get("src") if isinstance(cell, dict) else None
        # Intention (2026-11-04): a picture found by search is a file on disk ({path: …}), read as it is.
        path = cell.get("path") if isinstance(cell, dict) else None
        if not src and not path:
            return None
        fetch = self._fetch
        if fetch is None and not path:
            from warp2.refine.modality import _fetch as fetch
        try:
            with (Image.open(path) if path else Image.open(io.BytesIO(fetch(src)))) as image:
                small = image.convert("RGB").resize((PICTURE_SIDE, PICTURE_SIDE))
                array = np.asarray(small, dtype=np.float32) / 255.0
        except Exception:
            return None
        return torch.from_numpy(array.transpose(2, 0, 1).copy())

    def _inputs(self, kind: str, values: list) -> tuple:
        """Intention: each value as the Eye takes it; a picture that could not be had is dropped (its index is not kept)."""
        if kind == "image":
            made = [(i, self._picture(v)) for i, v in enumerate(values)]
            return [i for i, t in made if t is not None], [t for _, t in made if t is not None], "image"
        tags = [[{"name": "text", "weight": 1.0, "says": str(v)[:600], "holds": []}] for v in values]
        return list(range(len(values))), tags, "vector"

    def _parts_first(self, book, part: str, classes: list) -> dict:
        """Intention: the classes' known, untaught parts taught now (warp2/capability/components.py); a failure is
        noted, never a lost try."""
        try:
            from pathlib import Path
            from warp2.capability.components import Prerequisites
            return Prerequisites(Path(self.state_dir).parent, self.state_dir).first(book, part, classes)
        except Exception as error:  # noqa: BLE001
            return {"error": f"{type(error).__name__}: {error}"[:200]}

    def _grown(self, book) -> list:
        """Intention: the concept pairs that grew in this lesson, noted in the components book for the side step."""
        try:
            from warp2.capability.components import ComponentBook
            return [list(row) for row in ComponentBook(self.state_dir).saw(book.warp.eye, parts=getattr(book.warp, "parts", {}))]
        except Exception as error:  # noqa: BLE001
            return [["error", f"{type(error).__name__}: {error}"[:200]]]

    def run(self, task: dict, dataset: str, wanted: int, seed: int) -> dict:
        """Read, shape, learn, ask, compare, note. Returns the note."""
        from warp2.capability.examples import shaped
        began = time.monotonic()
        base = {"task": task["id"], "dataset": dataset, "wanted": int(wanted)}
        from warp2.chat_learning.datasets import NotReached
        try:
            read = self.rows.read(dataset, wanted, seed)
        except NotReached as exc:
            # Intention (2026-11-07): noted as this turn's failure to reach the hub, not as the dataset being empty.
            return self.notes.add(dict(base, said=f"the hub was not reached: {exc.why}", shape="not reached"))
        base["dataset"] = str(read.get("dataset") or dataset)
        if read.get("renamed_from"):
            base["renamed_from"] = read["renamed_from"]
        shape = {"why": read["why"]} if "why" in read else shaped(read["features"], read["rows"])
        made = False
        if "why" in shape:
            # Intention (2026-11-04): what cannot be read or taken is made from picture search when its card allows.
            what = "unread" if "why" in read else "not yet"
            if not read.get("card"):
                return self.notes.add(dict(base, said=shape["why"], shape=what))
            found = self.searched().pairs(read["card"], wanted, seed)
            if "why" in found:
                return self.notes.add(dict(base, said=f"{shape['why']}; not made from search: {found['why']}",
                                           shape=what))
            # Intention: found class by class, so mixed before the four-to-one split (as the hub rows are).
            pairs = list(found["pairs"])
            random.Random(int(seed)).shuffle(pairs)
            shape, made = {"kind": "image", "pairs": pairs, "classes": found["classes"]}, True
            base["made_from"] = "picture search"
        kept, inputs, kind = self._inputs(shape["kind"], [v for v, _ in shape["pairs"]])
        labels = [shape["pairs"][i][1] for i in kept]
        if len(set(labels)) < 2 or len(labels) < 5:
            return self.notes.add(dict(base, said=f"only {len(labels)} usable examples", shape="thin"))
        cut = max(1, len(labels) // 5)
        train_x, train_y, test_x, test_y = inputs[cut:], labels[cut:], inputs[:cut], labels[:cut]
        classes = sorted(set(labels))
        part = f"task: {task['id']}"
        # Intention: the Eye's own names for the two kinds of part
        # (projects/behemoth_eye/pairs/fronts.py IMAGE, VECTOR).
        eye_kind = "image" if kind == "image" else "vector"
        book = self.book()
        # Intention (Andrew, 2026-11-05: "We have to build from the bottom up"): the parts already known for the
        # task's classes are taught first; after the lesson, what grew is noted for the component search.
        first_at = time.monotonic()
        first = self._parts_first(book, part, classes)
        learned_at = time.monotonic()
        free_before = free_memory_mb()
        lesson = (book.learn(part, train_x, train_y, classes, eye_kind) or {}).get("task") or {}
        taught_at = time.monotonic()
        grown = self._grown(book)
        learn_seconds = round(time.monotonic() - learned_at, 2)
        # Intention (BUILD_LOG 1477, measured 2026-11-09: one feature-extraction try took 16,960 s where the two
        # before took 233 s and 569 s, with 0.8 GB free on the machine): where the time went, and how much memory was
        # free around the lesson, so a slow try says why next time.
        took = {"parts_first": round(learned_at - first_at, 2), "lesson": round(taught_at - learned_at, 2),
                "grown": round(time.monotonic() - taught_at, 2),
                "free_mb": {"before": free_before, "after": free_memory_mb()},
                # Intention (BUILD_LOG 1499): a lesson fits its turn - how many examples it read, how many it left for
                # want of time, and how many steps it then taught them, so a try that was cut short says so.
                "read": lesson.get("taught"), "left": lesson.get("left"), "steps": lesson.get("steps")}
        read_back = book.read(part, test_x)
        guessed = [max(shares, key=shares.get) for shares in read_back]
        right = sum(g == t for g, t in zip(guessed, test_y)) / len(test_y)
        guessing = Counter(test_y).most_common(1)[0][1] / len(test_y)
        book.save()
        seconds = round(time.monotonic() - began, 1)
        over = right - guessing
        said = (("(pictures found by search for its classes) " if made else "")
                + f"the Eye got {right:.0%} of {len(test_y)} unseen {shape['kind']} examples right "
                f"against {guessing:.0%} for always guessing the commonest — "
                + ("it is learning this" if over > 0 else "no better than guessing yet"))
        # Intention (Andrew, 2026-11-05: "test the minimum and second to test efficiency"): the standards on the same
        # examples. A check that fails is said in the note; it never loses the try.
        extra = {}
        try:
            rate = self.rate().check(eye_kind, train_x, train_y, test_x, test_y, classes, guessing,
                                     {"right": right, "seconds": learn_seconds,
                                      "weights": self.eye_weights(book, part, classes)})
            extra = {"rate": rate}
            said += "; " + rate["verdict"]
        except Exception as error:  # noqa: BLE001 — the try is noted whether or not the check could run
            extra = {"rate_error": f"{type(error).__name__}: {error}"[:300]}
        extra["took"] = took
        if first:
            extra["parts_first"] = first
        if grown:
            extra["grown"] = grown
        return self.notes.add(dict(base, shape=shape["kind"], examples=len(labels), classes=len(classes),
                                   right=round(right, 4), guessing=round(guessing, 4), unseen=len(test_y),
                                   seconds=seconds, split=read.get("split", ""), said=said, **extra))
