# WARP2/warp2/capability/staying.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/staying.py
#  Used by   : warp2/capability/readable.py (Pick.order, Pick.choose - which task and dataset a capability turn
#              goes to), warp2/capability/tests/test_the_step_stays_on_a_set_until_it_settles.py.
#  Uses      : warp2/capability/notes.py (TaskNotes - every try so far).
#  Description:
#    The basics at their limit: a set the Eye has started on is STAYED ON, with more examples each turn, until its
#    held-out score has stopped rising - then it is left, and the note says so. "Stopped rising" is measured, not a
#    count: the last rise is no more than one unseen example's worth (1 / unseen). Before this a set got one turn
#    of 100 examples and the step moved to the next never-tried task; CIFAR-10 scored 5% against 20% guessing on
#    2026-11-07 08:59 and would have been left for weeks.
#  User intention (Andrew, 2026-11-07 04:49): "you have to take the basics at the limit it is at right now and work
#    from there. Once the basics are mastered, we should be able to start seeing improvements ... keep working on
#    making the small parts better until they feed into the larger parts."
# ============================================================================
"""Stay on a set while its score is still rising; leave when it has settled."""
from __future__ import annotations


class Staying:
    """Intention: for one task, whether the Eye is still rising on its last set, and what the next try should be."""

    def __init__(self, notes) -> None:
        """Intention: the tries so far (TaskNotes or a stand-in with .of(task))."""
        self.notes = notes

    def measured(self, task: str) -> list:
        """Intention: the task's tries that scored something, oldest first."""
        return [row for row in self.notes.of(task) if isinstance(row.get("right"), (int, float)) and row.get("dataset")]

    def next_try(self, task: str):
        """Intention: (dataset, examples) to stay on - the same set, twice the examples - while the score is still
        rising or has only one point; None when the task has no measured try or has settled."""
        tries = self.measured(task)
        if not tries:
            return None
        last = tries[-1]
        same = [row for row in tries if row.get("dataset") == last.get("dataset")]
        if len(same) >= 2 and self.settled(same[-2], same[-1]):
            return None
        return str(last["dataset"]), int(last.get("wanted") or last.get("examples") or 0) * 2

    @staticmethod
    def settled(before: dict, after: dict) -> bool:
        """Intention: the rise from one try to the next is no more than one unseen example's worth. With the unseen
        count not noted (an older row), nothing is known yet - not settled."""
        unseen = after.get("unseen")
        if not isinstance(unseen, (int, float)) or unseen <= 0:
            return False
        rise = float(after["right"]) - float(before["right"])
        return rise <= 1.0 / float(unseen)

    def why_left(self, task: str) -> str:
        """Intention: the words for a task that has settled, for the note; "" when it has not."""
        tries = self.measured(task)
        if len(tries) < 2 or self.next_try(task) is not None:
            return ""
        last = tries[-1]
        return (f"{last['dataset']}: settled at {float(last['right']):.0%} right after {len(tries)} tries "
                f"({int(last.get('examples') or 0)} examples)")
