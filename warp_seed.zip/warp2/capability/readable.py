# WARP2/warp2/capability/readable.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/readable.py
#  Used by   : warp2/work/side/capability.py (CapabilityStep - which task and dataset to try this turn),
#              warp2/capability/tests/test_the_step_tries_only_what_can_be_read.py.
#  Uses      : warp2/capability/examples.py (HubRows.facts - what the hub says about a dataset),
#              warp2/capability/notes.py (TaskNotes - what earlier tries found), projects/behemoth_eye/eye/turn_clock.py.
#  Description:
#    The pick for a capability turn: the first task, in the step's own order (never tried first, then the one tried
#    longest ago), that has a dataset the Eye can be shown - not gated, known to the hub, and not one an earlier try
#    already found empty. Measured 2026-11-05/06: 93 of 99 tries since 09-24 found no data, and 4 of the last 6
#    turns went to datasets the hub cannot serve. Looking costs one hub answer a dataset; a whole task that has
#    nothing readable is passed over this turn, not tried. The looking stops with the turn.
#  User intention (Andrew, 2026-09-24): "it should look for anything a model has been trained to do and try to get
#    the eye to do it"; 2026-11-06 00:06: Adaptive - "situations adapt to something, not settle for a certain point
#    of view" (the hub's order was a point of view).
# ============================================================================
"""Which task and dataset a capability turn can actually be shown."""
from __future__ import annotations


class WhyNot:
    """Intention: why one dataset cannot be shown this turn, in words - or "" when it can."""

    def __init__(self, rows, notes_rows: list) -> None:
        """Intention: the hub reader (HubRows or a stand-in with .facts) and every earlier try, as rows."""
        self.rows = rows
        self.empty = {}
        for row in notes_rows:
            # a try that fell on the hub not being reached says nothing about the dataset (shape "not reached")
            if row.get("dataset") and not isinstance(row.get("right"), (int, float)) and row.get("shape") in ("unread", "no data"):
                self.empty[str(row["dataset"])] = str(row.get("said", ""))[:120]

    def of(self, dataset: str) -> str:
        """Intention: an earlier try found it empty; the hub does not know it; it is gated; the viewer cannot serve it;
        no column is a named class (measured 2026-11-06: the three turns after the first pick failed on the last two)."""
        if dataset in self.empty:
            return f"an earlier try found no data: {self.empty[dataset]}"
        card = self.rows.facts(dataset)
        if not card:
            return "the hub says nothing about it (gone, private, or not reached)"
        if card.get("gated"):
            return "gated - it needs a Hugging Face login with its terms accepted"
        named = str(card.get("id") or dataset)
        return self.viewer_of(named)

    def viewer_of(self, dataset: str) -> str:
        """Intention: the viewer's splits and first page - none, or no column that names a class, says why."""
        get = getattr(self.rows, "get", None)
        viewer = getattr(self.rows, "viewer", None)
        if get is None or not viewer:
            return ""
        import urllib.parse
        splits = get(f"{viewer}/splits?" + urllib.parse.urlencode({"dataset": dataset})) or {}
        rows = splits.get("splits", []) if isinstance(splits, dict) else []
        if not rows:
            return "the hub's viewer cannot read any split (disabled, too big, or runs its own code)"
        split = rows[0]
        first = get(f"{viewer}/rows?" + urllib.parse.urlencode(
            {"dataset": dataset, "config": split["config"], "split": split["split"], "offset": "0", "length": "1"}))
        features = first.get("features", []) if isinstance(first, dict) else []
        if not features:
            return "the hub's viewer gave no rows"
        from warp2.capability.examples import shaped
        kinds = [str((f or {}).get("type", {}).get("_type", "")) for f in features]
        said = shaped(features, [r.get("row", r) for r in first.get("rows", [])])
        if said.get("why", "").startswith("no column is a named class"):
            return f"no column is a named class (columns are {', '.join(k for k in kinds if k) or 'unknown'})"
        return ""


class Pick:
    """Intention: the first (task, dataset, examples) that can be shown; what was passed over on the way."""

    def __init__(self, step, notes, rows=None) -> None:
        """Intention: the step's own task order and dataset order are used; `rows` is HubRows unless a test gives one."""
        self.step, self.notes = step, notes
        self._rows = rows

    def rows(self):
        """Intention: the hub reader, made when first needed."""
        if self._rows is None:
            from warp2.capability.examples import HubRows
            self._rows = HubRows()
        return self._rows

    def order(self, tasks: list) -> list:
        """Intention (Andrew, 2026-11-07: the basics at their limit first): a task the Eye is still rising on is
        stayed on before anything else (warp2/capability/staying.py); then never tried, in the hub's order; then by
        the oldest last try."""
        from warp2.capability.staying import Staying
        staying = Staying(self.notes)
        tried = {}
        for row in self.notes.rows():
            tried[row.get("task")] = row.get("when", "")
        rising = sorted((t for t in tasks if staying.next_try(t["id"]) is not None), key=lambda t: tried.get(t["id"], ""), reverse=True)
        fresh = [t for t in tasks if t["id"] not in tried]
        old = sorted((t for t in tasks if t["id"] in tried and t not in rising), key=lambda t: tried.get(t["id"], ""))
        return rising + fresh + old

    def choose(self, tasks: list) -> dict:
        """Intention: {task, dataset, wanted, skipped: [(task, dataset, why)]} - or {skipped} alone when nothing can
        be shown before the turn ends."""
        from projects.behemoth_eye.eye.turn_clock import over
        from warp2.chat_learning.datasets import NotReached
        why_not = WhyNot(self.rows(), self.notes.rows())
        skipped = []
        from warp2.capability.staying import Staying
        staying = Staying(self.notes)
        for task in self.order(tasks):
            # Intention (2026-11-07): the same set, twice the examples, while its score is still rising.
            first, wanted = staying.next_try(task["id"]) or self.step._what_next(task, self.notes)
            names = self.step._datasets(task)
            for dataset in [first] + [n for n in names if n != first] if first else names:
                if over(None):
                    return {"skipped": skipped, "why": "the turn ended while looking"}
                try:
                    why = why_not.of(dataset)
                except NotReached as exc:
                    # Intention (2026-11-07): the hub not reached is said about THIS TURN, never about the dataset.
                    return {"skipped": skipped, "shape": "not reached", "why": f"the hub was not reached: {exc.why}"}
                if not why:
                    return {"task": task, "dataset": dataset, "wanted": wanted, "skipped": skipped}
                skipped.append((task["id"], dataset, why))
            if not names and not first:
                skipped.append((task["id"], "", "the hub has no dataset for this task"))
        return {"skipped": skipped, "why": "no task has a dataset that can be shown"}
