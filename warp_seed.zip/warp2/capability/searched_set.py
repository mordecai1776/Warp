# WARP2/warp2/capability/searched_set.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/searched_set.py
#  Used by   : warp2/capability/trial.py (EyeTrial — when a dataset cannot be
#              read or is not shaped for the Eye),
#              warp2/capability/tests/test_a_dataset_it_cannot_read_is_made_from_search.py.
#  Uses      : warp2/train/dataset_curator.py (DatasetCurator — the dataset
#              generation system: hub pictures and picture search, curated),
#              projects/behemoth_eye/eye/turn_clock.py (over — the turn's
#              clock); (stdlib) inspect, random, pathlib.
#  Description:
#    When a task's dataset cannot be read (gated, renamed past reach, run by
#    its own code) or is not shaped for the Eye, but its hub card names the
#    classes of a picture dataset, the warp makes its own: for some of those
#    classes, the dataset generation system finds pictures by searching each
#    class's name, and each picture is labelled with the class it was found
#    for. How many classes: enough for the try's examples at the pictures
#    the generation system gathers per topic (its own min_samples), at least
#    two. It stops adding classes when the step's turn is over. Not every
#    task can be made this way: a task whose answer is not a class (a
#    question, a caption, a depth) gets no pictures, and says so.
#  User intention (Andrew, 2026-11-04): "how to get around that gate or why it
#    is not making its own dataset from search"; "Let's do all 3".
#    2026-09-28: "whenever it tryies to learn something new it should always
#    get or make as many datasets with said thing".
# ============================================================================
"""A picture dataset made from search for the classes a hub card names."""
from __future__ import annotations

import inspect
import random
from pathlib import Path


class CardClasses:
    """Intention: the class names a hub card gives, and whether its input is a picture."""

    @staticmethod
    def _configs(card: dict) -> list:
        """Intention: the card's dataset_info as a list of configs (it is one config or several)."""
        info = ((card or {}).get("cardData") or {}).get("dataset_info")
        if isinstance(info, dict):
            return [info]
        return [c for c in info if isinstance(c, dict)] if isinstance(info, list) else []

    @staticmethod
    def _names(feature: dict) -> list:
        """Intention: a class_label feature's names in their order (given as a list or as {index: name})."""
        dtype = (feature or {}).get("dtype")
        names = (dtype.get("class_label") or {}).get("names") if isinstance(dtype, dict) else None
        if isinstance(names, dict):
            return [str(names[k]) for k in sorted(names, key=lambda k: int(k) if str(k).isdigit() else str(k))]
        return [str(n) for n in names] if isinstance(names, list) else []

    def of(self, card: dict) -> tuple:
        """Intention: (class names, whether there is a picture column) of the first config that names classes."""
        for config in self._configs(card):
            features = [f for f in (config.get("features") or []) if isinstance(f, dict)]
            picture = any(f.get("dtype") == "image" for f in features)
            for feature in features:
                names = self._names(feature)
                if names:
                    return names, picture
        return [], False


def per_topic() -> int:
    """Intention: the pictures the dataset generation system gathers per topic — its own min_samples, read from it."""
    from warp2.train.dataset_curator import DatasetCurator
    return int(inspect.signature(DatasetCurator.discover_and_create_needed).parameters["min_samples"].default)


class SearchedSet:
    """Intention: pictures found by searching each class's name, each labelled with that class."""

    def __init__(self, root, state, curator=None, per=None) -> None:
        """Intention: the generation system (made when first needed; passed in by tests) and pictures per class."""
        self.root, self.state = Path(root), Path(state)
        self._curator = curator
        self._per = per

    def curator(self):
        """Intention: the dataset generation system, made when first needed."""
        if self._curator is None:
            from warp2.train.dataset_curator import DatasetCurator
            self._curator = DatasetCurator(self.root, self.state)
        return self._curator

    def per(self) -> int:
        """Intention: pictures asked for per class."""
        return int(self._per) if self._per else per_topic()

    def _found(self, name: str) -> list:
        """Intention: the pictures on disk the generation system has for one class name."""
        paths = []
        for manifest in self.curator().discover_and_create_needed([name], min_samples=self.per()):
            for sample in list(manifest.get("train_samples") or []) + list(manifest.get("test_samples") or []):
                path = Path(str(sample.get("image_path") or ""))
                if path.is_file():
                    paths.append(path)
        return paths

    def pairs(self, card: dict, wanted: int, seed: int) -> dict:
        """Intention: {pairs: [({"path": …}, class)], classes, searched} — or {"why": …} in words when it cannot."""
        from projects.behemoth_eye.eye.turn_clock import over
        names, picture = CardClasses().of(card)
        if not names:
            return {"why": "its card names no classes to search for"}
        if not picture:
            return {"why": "its input is not a picture, so a picture search cannot stand in for it"}
        count = max(2, min(len(names), int(wanted) // max(1, self.per())))
        chosen = random.Random(int(seed)).sample(names, count)
        pairs, had = [], []
        for name in chosen:
            found = self._found(name)
            if found:
                had.append(name)
                pairs += [({"path": str(p)}, name) for p in found]
            if over(None) and len(had) >= 2:
                break
        if len(had) < 2:
            return {"why": f"picture search found pictures for {len(had)} of {len(chosen)} of its classes"}
        return {"pairs": pairs, "classes": sorted(had), "searched": chosen}
