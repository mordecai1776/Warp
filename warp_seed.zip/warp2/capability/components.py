# WARP2/warp2/capability/components.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/components.py
#  Used by   : warp2/work/side/components.py (ComponentsStep — a grown concept's parts searched and taught),
#              warp2/capability/trial.py (EyeTrial — the known parts of a task's classes taught FIRST),
#              warp2/capability/tests/test_a_grown_concept_gets_its_parts_first.py.
#  Uses      : projects/behemoth_eye/eye/grown.py (Grown — what grew), warp2/ask/subconcepts.py (SubconceptGuesser — the small models name a concept's parts),
#              warp2/capability/searched_set.py (SearchedSet._found — pictures found by searching a name),
#              warp2/capability/trial.py (EyeTrial._picture — a picture file as the Eye takes it),
#              projects/behemoth_eye/eye/grown.py (Grown), projects/behemoth_eye/eye/warp_eye.py (EyeBook);
#              (stdlib) json, time, pathlib.
#  Description:
#    The component search. A concept is made of prerequisite concepts (a dress: fabric, stitches, buttons,
#    a collar). When a concept's pair is bigger than the Eye's average pair (eye/grown.py), that is the sign
#    those are missing, so: the small models are asked what the concept is made of; a part the Eye already
#    has a concept for (a prior concept) is linked at once; the rest get pictures found by searching their
#    names and the Eye learns them as one part ("parts: dress", one concept per part); while they are being
#    taught the whole's own pair is held from growing; and when they are taught the whole is LINKED to them
#    (eye/prerequisites.py) so its reads use them as company - every part, there is no limit on how many
#    feed a concept. A concept flagged again after its parts are in is asked one level deeper (the parts of
#    its parts). Concept pairs the Eye already has are also tried at random as parts and kept when they
#    help (RandomParts). The components book
#    (state/capability/components.json) keeps, per concept, the size last noted, the parts named, which
#    were taught and from how many pictures, and which links were made.
#    Bottom up: before a task is taught, the parts already known for its classes are taught first.
#  User intention (Andrew, 2026-11-05 17:37): "Take, for instance, the point of fashion: hats, dresses, pants,
#    stitches, buttons, fabrics. All those things should have been in place before it started writing on
#    those. We have to build from the bottom up." 18:57: "Let's go with number 2 [a named prerequisite link
#    the read uses as company], but let's make the growth signal a bigger than average signal ... have it
#    look for it then, and have its prior concepts look for it then ... I like the idea of freezing while
#    it's running its previous concept pairs, but we need to make sure that it can look for new ones on
#    its own. That's a big thing."
# ============================================================================
"""A concept's prerequisite parts: named by the models, found by search, taught first."""
from __future__ import annotations

import json
import time
from pathlib import Path


def plain(concept: str) -> str:
    """Intention: the word a concept is searched by — "task: image-classification: Dress" is searched as "dress"."""
    return " ".join(str(concept).split(": ")[-1].lower().split())


def parts_part(concept: str) -> str:
    """Intention: the Eye part that holds a concept's parts, one concept each ("parts: dress")."""
    return f"parts: {plain(concept)}"


class ComponentBook:
    """Intention: what is known about each concept's parts, kept on disk."""

    def __init__(self, state) -> None:
        """Intention: the book of this state folder, read when first needed."""
        self.path = Path(state) / "capability" / "components.json"
        self._data = None

    def data(self) -> dict:
        """Intention: {concept: {nodes, parts, taught, searched_at}}."""
        if self._data is None:
            # Intention (2026-11-07): no book yet is an empty book; a book that cannot be read stops the caller.
            from warp2.record.kept_file import read_kept
            self._data = read_kept(self.path, dict)
        return self._data

    def saw(self, eye, parts: dict | None = None) -> list:
        """Intention: the Eye looked at by whoever has it open: what grew among the picture parts' classes (the Eye's
        parts, parts.json) is made pending, every count noted, saved."""
        from projects.behemoth_eye.eye.grown import Grown
        grown = Grown.since(eye, self.noted_nodes(), parts=parts)
        known = {row[0] for row in self.pending()}
        self.set_pending(self.pending() + [row for row in grown if row[0] not in known])
        # Intention (2026-11-06, Andrew: a flat count "would directly fly in the face of the adaptive concept"): a size
        # is the bigger pole of a pair ({normal, inverse}); anything else is an older grown module still loaded in
        # this process, and is said so, not papered over.
        sizes = {}
        for name, s in Grown.nodes(eye).items():
            if not isinstance(s, dict) or "normal" not in s or "inverse" not in s:
                raise TypeError(f"{name}: a flat count {s!r} - an older grown module is loaded in this process; restart the child")
            sizes[name] = max(s.values())
        self.note_nodes(sizes)
        self.save()
        return grown

    def entry(self, concept: str) -> dict:
        """Intention: a concept's page, made when first asked for."""
        return self.data().setdefault(str(concept), {"nodes": 1, "parts": [], "taught": {}, "linked": [],
                                                     "searched_at": ""})

    def pending(self) -> list:
        """Intention: [(concept, noted, now, side, average)] bigger than average since the last look and not yet
        searched, furthest over the average first."""
        return [tuple(row) for row in self.data().get("_pending", [])]

    def set_pending(self, grown: list) -> None:
        """Intention: the growth noted by whoever had the Eye open (a try, a lesson), for the side step to answer."""
        self.data()["_pending"] = [list(row) for row in grown]

    def answered(self, concept: str) -> None:
        """Intention: a concept whose parts were searched is no longer pending."""
        self.data()["_pending"] = [row for row in self.data().get("_pending", []) if row[0] != concept]

    def noted_nodes(self) -> dict:
        """Intention: {concept: nodes} as last noted, for Grown.since."""
        return {name: int(page.get("nodes", 1)) for name, page in self.data().items() if not name.startswith("_")}

    def note_nodes(self, nodes: dict) -> None:
        """Intention: every concept's node count as it stands now."""
        for name, count in nodes.items():
            self.entry(name)["nodes"] = int(count)

    def untaught(self, concept: str) -> list:
        """Intention: the parts named for a concept that have not been taught yet."""
        page = self.entry(concept)
        return [p for p in page.get("parts", []) if p not in page.get("taught", {})]

    def save(self) -> None:
        """Intention: written whole, atomically where the tree offers it."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        text = json.dumps(self.data(), indent=1, ensure_ascii=False)
        try:
            from warp2.util import atomic_write_bytes
            atomic_write_bytes(self.path, text.encode("utf-8"))
        except Exception:  # noqa: BLE001 — the plain write when the helper is not there
            self.path.write_text(text, encoding="utf-8")


class PartPictures:
    """Intention: pictures for a part's name, found by search, as the Eye takes them."""

    def __init__(self, root, state, found=None, picture=None) -> None:
        """Intention: `found(name) -> [paths]` and `picture(cell) -> tensor` are the tree's own unless tests give theirs."""
        self.root, self.state = Path(root), Path(state)
        self._found, self._picture = found, picture

    def found(self, name: str) -> list:
        """Intention: the picture files the dataset generation system has, or finds, for a name."""
        if self._found is not None:
            return list(self._found(name))
        from warp2.capability.searched_set import SearchedSet
        return SearchedSet(self.root, self.state)._found(name)

    def picture(self, path) -> object:
        """Intention: one file as a 3×side×side tensor, or None."""
        if self._picture is not None:
            return self._picture(path)
        from warp2.capability.notes import TaskNotes
        from warp2.capability.trial import EyeTrial
        return EyeTrial(self.state, TaskNotes(self.state))._picture({"path": str(path)})

    def of(self, name: str) -> list:
        """Intention: the tensors for a name; files that cannot be read are dropped."""
        out = []
        for path in self.found(name):
            tensor = self.picture(path)
            if tensor is not None:
                out.append(tensor)
        return out


class ComponentSearch:
    """Intention: one concept's parts named, found and taught — the search a grown pair asks for."""

    def __init__(self, root, state, guesser=None, pictures=None) -> None:
        """Intention: the models' guesser and the picture finder are the tree's own unless tests give theirs."""
        self.root, self.state = Path(root), Path(state)
        self.book = ComponentBook(state)
        self._guesser, self._pictures = guesser, pictures

    def guesser(self):
        """Intention: the small models' guesser, made when first needed."""
        if self._guesser is None:
            from warp2.ask.subconcepts import SubconceptGuesser
            self._guesser = SubconceptGuesser(self.root, self.state)
        return self._guesser

    def pictures(self) -> PartPictures:
        """Intention: the picture finder, made when first needed."""
        if self._pictures is None:
            self._pictures = PartPictures(self.root, self.state)
        return self._pictures

    def named(self, concept: str) -> list:
        """Intention: the parts the models say a concept is made of. Asked once for the concept itself; a concept
        flagged again after that is taken one level deeper - the parts of its parts - so it keeps looking for new
        ones on its own (Andrew: "That's a big thing")."""
        page = self.book.entry(concept)
        guesser = self.guesser()
        if not page.get("parts"):
            word = plain(concept)
            guesser.guess(word, kinds=("parts",))
            names = list(guesser.book.entry(word).get("parts", []))
            page["parts"] = [guesser.full_name(word, n, "parts") for n in names]
        else:
            for part in [p for p in page["parts"] if p in page.get("taught", {})]:
                if guesser.book.asked(part, "parts"):
                    continue
                guesser.guess(part, kinds=("parts",), models_per_question=1)
                for deeper in guesser.book.entry(part).get("parts", []):
                    full = guesser.full_name(part, deeper, "parts")
                    if full not in page["parts"]:
                        page["parts"].append(full)
        page["searched_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self.book.save()
        return list(page["parts"])

    @staticmethod
    def kind_of(eye_book, concept: str) -> str:
        """Intention: what the whole's part reads - the modality of its kept examples as the Eye names it ("picture", a
        web of tags, records), or "" when nothing is kept."""
        task = str(concept).rsplit(": ", 1)[0]
        kept = getattr(getattr(eye_book, "warp", None), "pending", {}).get(task, [])
        for k in kept:
            if len(k) > 1 and k[1]:
                return str(k[1])
        kinds = getattr(eye_book, "parts", {}) or {}
        page = kinds.get(task) if isinstance(kinds, dict) else None
        return str(page.get("kind", "")) if isinstance(page, dict) else ""

    @staticmethod
    def _pairs(eye_book) -> dict:
        """Intention: the Eye's concept pairs by name."""
        return dict(getattr(getattr(getattr(eye_book, "warp", None), "eye", None).concepts, "pairs", {}) or {})

    def prior(self, eye_book, concept: str, parts: list) -> dict:
        """Intention: {part: existing concept} for each part the Eye already has a concept for - by the part's
        plain name, or the name without the whole's word ("dress buttons" matches a concept named "buttons")."""
        have = {plain(name): name for name in self._pairs(eye_book) if name != concept}
        found = {}
        for part in parts:
            own = plain(concept).split()
            short = " ".join(w for w in plain(part).split() if w not in own) or plain(part)
            for key in (plain(part), short):
                if key in have:
                    found[part] = have[key]
                    break
        return found

    def link(self, eye_book, concept: str, names: list) -> list:
        """Intention: the whole linked to these concept names in the Eye's prerequisite book; noted in the page."""
        eye = eye_book.warp.eye
        linked = eye.prerequisites.link(concept, names)
        # Intention (2026-11-07): the link is on disk the moment it is made - the child's paced save never wrote it.
        eye_book.warp.save_prerequisites()
        page = self.book.entry(concept)
        page["linked"] = list(linked)
        self.book.save()
        self.rows_again(eye_book, concept)
        return linked

    @staticmethod
    def rows_again(eye_book, concept: str) -> int:
        """Intention: the whole's part reads its kept examples again next lesson, now with the parts as company - the
        kept rows are the Eye's reading, and that reading just changed (EyePart.learn reads a row that is None)."""
        task = str(concept).rsplit(": ", 1)[0]
        kept = getattr(getattr(eye_book, "warp", None), "pending", {}).get(task, [])
        for i, k in enumerate(kept):
            kept[i] = tuple(k[:4]) + (None,)
        return len(kept)

    def hold(self, eye_book, concept: str, held: bool) -> bool:
        """Intention: the whole's own pair held from growing (both networks) while its parts are taught, and let
        go after; whether the pair was found."""
        pair = getattr(self._pairs(eye_book).get(concept), "pair", None)
        if pair is None:
            return False
        for side in ("normal", "inverse"):
            net = getattr(pair, side, None)
            if net is not None:
                net.growth_held = bool(held)
        return True

    def missing(self, eye_book, concept: str, parts: list) -> list:
        """Intention: the parts the Eye has no concept for yet (as this concept's parts part would name them)."""
        have = set(self._pairs(eye_book))
        return [p for p in parts if f"{parts_part(concept)}: {p}" not in have]

    def teach(self, eye_book, concept: str, parts: list) -> dict:
        """Intention: the parts with pictures learned as one Eye part, one concept each; what each got. The pictures
        are looked for while the turn lasts; a part not reached stays pending for the next turn."""
        from projects.behemoth_eye.eye.turn_clock import over
        inputs, labels, got = [], [], {}
        for part in parts:
            if over(None) and got:
                break
            found = self.pictures().of(part)
            got[part] = len(found)
            inputs += found
            labels += [part] * len(found)
        classes = sorted({l for l in labels})
        if not classes:
            return {"taught": {}, "got": got, "why": "picture search found pictures for none of the parts"}
        if len(classes) < 2:
            # Intention: a concept is an is/is-not pair, so a lone part needs something it is not - the whole
            # itself, pictures found by its own name ("dress" beside "dress fabric").
            whole = plain(concept)
            found = self.pictures().of(whole)
            if not found:
                return {"taught": {}, "got": got, "why": f"one part had pictures and none were found for {whole} to set beside it"}
            inputs += found
            labels += [whole] * len(found)
            classes = sorted(set(labels))
        self.hold(eye_book, concept, True)
        try:
            eye_book.learn(parts_part(concept), inputs, labels, classes, "image")
        finally:
            self.hold(eye_book, concept, False)
        taught = [p for p in classes if p in parts]
        page = self.book.entry(concept)
        for part in taught:
            page["taught"][part] = {"pictures": got[part], "at": time.strftime("%Y-%m-%d %H:%M:%S")}
        self.book.save()
        # Intention (Andrew, 2026-11-05 19:06): no limit on how many parts feed a concept - every one is linked.
        self.link(eye_book, concept, [f"{parts_part(concept)}: {p}" for p in taught])
        return {"taught": {p: got[p] for p in taught}, "got": got}

    def run(self, eye_book, concept: str) -> dict:
        """Intention: the whole search for one flagged concept: named; the parts the Eye already has linked at once
        (its prior concepts); the rest found and taught, then linked."""
        kind = self.kind_of(eye_book, concept)
        if kind and kind != "picture":
            # Intention (2026-11-06, measured live: the first pending concepts were a text task's classes): parts are
            # found as pictures; a concept read from words or sound has no picture to search for yet. Answered, not
            # searched, so the step moves on; the search for words' parts is its own build.
            return {"concept": concept, "parts": [], "why": f"a {kind or 'non-picture'} concept; parts are found as pictures only, so far"}
        parts = self.named(concept)
        if not parts:
            return {"concept": concept, "parts": [], "why": "the models named no parts"}
        prior = self.prior(eye_book, concept, parts)
        if prior:
            self.link(eye_book, concept, list(prior.values()))
            page = self.book.entry(concept)
            for part, name in prior.items():
                page["taught"].setdefault(part, {"prior": name, "at": time.strftime("%Y-%m-%d %H:%M:%S")})
            self.book.save()
        todo = [p for p in self.missing(eye_book, concept, parts) if p not in prior]
        said = {"concept": concept, "parts": parts, "prior": prior}
        if not todo:
            said.update({"taught": {}, "why": "every part is already a concept"})
        else:
            said.update(self.teach(eye_book, concept, todo))
        said["random"] = RandomParts(self).try_(eye_book, concept)
        return said


class RandomParts:
    """Intention: concept pairs the Eye already has, tried at random as parts of a concept and kept when they help.

    Andrew (2026-11-05 22:04): "It should also be trying to use random concept pairs as subparts of everything to look
    for when it helps." Help is measured on the whole's own kept examples: how far apart its pair reads the examples
    that are it from the ones that are not, read with the candidate as company against without. A candidate that widens
    the gap stays linked; one that does not is unlinked. As many are tried as the turn allows.
    """

    def __init__(self, search: "ComponentSearch", measure=None, pick=None) -> None:
        """Intention: `measure(eye_book, concept) -> float` and `pick(names) -> list` are the real ones unless tests give theirs."""
        self.search = search
        self._measure, self._pick = measure, pick

    def candidates(self, eye_book, concept: str) -> list:
        """Intention: every concept pair that is not the whole, not already under it, and not one it is under."""
        eye = eye_book.warp.eye
        under = set(eye.prerequisites.tree(concept))
        above = set()
        todo = [concept]
        while todo:
            name = todo.pop()
            for whole in eye.prerequisites.wholes_of(name):
                if whole not in above:
                    above.add(whole)
                    todo.append(whole)
        names = [n for n in self.search._pairs(eye_book) if n != concept and n not in under and n not in above]
        if self._pick is not None:
            return list(self._pick(names))
        import random
        random.shuffle(names)
        return names

    def measure(self, eye_book, concept: str) -> float:
        """Intention: the gap between what the whole's pair reads for its own examples and for the others, read with
        its parts as company (None when it has no kept examples)."""
        if self._measure is not None:
            return self._measure(eye_book, concept)
        import torch
        eye = eye_book.warp.eye
        # Intention (2026-11-07, measured live: seq 15,894 stopped on a concept with no "task: " in front): a plain
        # concept is its own task and label, as ComponentSearch reads it (rsplit(": ", 1)[0]).
        pieces = str(concept).rsplit(": ", 1)
        task, label = pieces[0], pieces[-1]
        kept = eye_book.warp.pending.get(task, [])
        if not kept:
            return None
        pair = eye.concepts.pairs[concept]
        mine, others = [], []
        with torch.no_grad():
            for k in kept:
                rows = eye.piece_rows(eye_book.warp.piece(k[0], k[1]), [concept], part=task)
                (mine if str(k[2]) == label else others).append(float(pair.strength(rows, aside=False).mean()))
        if not mine or not others:
            return None
        return sum(mine) / len(mine) - sum(others) / len(others)

    def try_(self, eye_book, concept: str) -> dict:
        """Intention: candidates tried one by one while the turn lasts; the ones that helped stay linked."""
        from projects.behemoth_eye.eye.turn_clock import over
        eye = eye_book.warp.eye
        base = self.measure(eye_book, concept)
        kept, dropped = [], []
        if base is None:
            return {"kept": kept, "dropped": dropped, "why": "nothing kept to measure on"}
        for name in self.candidates(eye_book, concept):
            if over(None):
                break
            eye.prerequisites.link(concept, [name])
            gap = self.measure(eye_book, concept)
            if gap is not None and gap > base:
                base = gap
                kept.append(name)
            else:
                eye.prerequisites.links[concept].remove(name)
                dropped.append(name)
        if kept:
            page = self.search.book.entry(concept)
            page["linked"] = eye.prerequisites.of(concept)
            page.setdefault("random", []).extend(kept)
            self.search.book.save()
            self.search.rows_again(eye_book, concept)
        return {"kept": kept, "dropped": dropped, "gap": round(base, 4)}


class Prerequisites:
    """Intention: bottom up — the parts already known for a task's classes are taught before the task is."""

    def __init__(self, root, state, search=None) -> None:
        """Intention: the component search of this state folder."""
        self.search = search or ComponentSearch(root, state)

    def first(self, eye_book, part: str, classes: list) -> dict:
        """Intention: for each class whose parts are named but not all taught, those parts taught now; what was."""
        done = {}
        for c in classes:
            concept = f"{part}: {c}"
            todo = [p for p in self.search.book.untaught(concept)
                    if p in self.search.missing(eye_book, concept, [p])]
            if todo:
                done[concept] = self.search.teach(eye_book, concept, todo)
        return done
