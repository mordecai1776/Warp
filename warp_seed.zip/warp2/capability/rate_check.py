# WARP2/warp2/capability/rate_check.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/rate_check.py
#  Used by   : warp2/capability/trial.py (EyeTrial — after every Eye try),
#              warp2/capability/tests/test_the_eye_is_set_beside_the_standard.py.
#  Uses      : torch; (stdlib) math, time.
#  Description:
#    Every try of the Eye is set beside standard learners taught the SAME
#    examples and asked the SAME unseen ones, smallest first: a nearest match
#    (keeps every example), a line fit, a small standard network (a small CNN for
#    pictures, a small MLP for words). Two tests, as Andrew set them:
#    1. THE MINIMUM — the smallest standard (by what it keeps) that does the task (right on
#       unseen clearly above always guessing the commonest: more than two
#       standard errors of the guess on that many unseen examples). Is the Eye
#       at least that good?
#    2. EFFICIENCY — what each took to get there: weights, seconds, and right
#       above guessing for each; the Eye's cost beside the minimum's.
#    The caveats for the Eye's different design are kept in the note, not
#    hidden: it starts at one node and grows, it wakes at most a few classes
#    per read, it keeps what it learned for every other task, while each
#    standard learns one task and is thrown away.
#    Standards are taught until a doubling round of steps no longer lowers
#    their training loss, or until they have had the same time the Eye had to
#    learn (BUILD_LOG, 2026-11-05: the turn's clock was used, and the Eye had
#    used up the turn, so each standard got one step) — no set number of steps.
#  User intention (Andrew, 2026-11-05): "we need to make sure that the eye
#    learns at the rate of the current standard with cavoites for the
#    difference of design"; "proportional code it gets the minimum to do a task.
#    One so we test the minimum and second to test efficiency." BUILD_LOG.
# ============================================================================
"""The Eye beside the smallest standard learners that do the same task."""
from __future__ import annotations

import math
import time

import torch

# Intention: the caveats for the difference of design, said with every check.
CAVEATS = ("the Eye starts at one node and grows; the standards start at full size",
           "the Eye wakes only a few classes per read; the standards read every class",
           "the Eye keeps what it learned for every other task; each standard learns this one and is thrown away",
           # Intention (Andrew, 2026-11-05 23:22): "the eye itself is not learning just fashion. It's learning every
           # component of that fashion ... something that learns everything from base principles."
           "the Eye learns every component of the task (its parts, their parts), not the task alone; each standard learns the task alone")


def clears_guessing(right: float, guessing: float, unseen: int) -> bool:
    """Intention: right is clearly above guessing — by more than two standard errors of the guess on `unseen`."""
    spread = math.sqrt(max(guessing * (1.0 - guessing), 1e-12) / max(int(unseen), 1))
    return float(right) > float(guessing) + 2.0 * spread


class Words:
    """Intention: texts as counts of the words seen in training — the vocabulary comes from the data, not a number."""

    def __init__(self, texts: list) -> None:
        """Intention: every word the training texts use, in the order first seen."""
        self.index = {}
        for text in texts:
            for word in str(text).lower().split():
                self.index.setdefault(word, len(self.index))

    def rows(self, texts: list) -> torch.Tensor:
        """Intention: one row of word counts per text (words not seen in training are left out)."""
        out = torch.zeros(len(texts), max(len(self.index), 1))
        for i, text in enumerate(texts):
            for word in str(text).lower().split():
                if word in self.index:
                    out[i, self.index[word]] += 1.0
        return out


def as_rows(inputs: list, kind: str, words: Words = None) -> torch.Tensor:
    """Intention: what the Eye was shown, as numbers a standard reads — pictures as they are; words as word counts."""
    if kind == "image":
        return torch.stack([x.float() for x in inputs])
    texts = [" ".join(str(t.get("says", "")) for t in row) if isinstance(row, list) else str(row) for row in inputs]
    return words.rows(texts)


def texts_of(inputs: list) -> list:
    """Intention: the words of each input the Eye was shown as tags."""
    return [" ".join(str(t.get("says", "")) for t in row) if isinstance(row, list) else str(row) for row in inputs]


class NearestMatch:
    """Intention: the floor — the answer of the closest training example; nothing is learned, every example is kept."""

    name = "nearest match"

    def fit(self, x: torch.Tensor, y: torch.Tensor, classes: int, budget: float = None) -> None:
        """Intention: keep the training examples (no time is needed)."""
        self.x, self.y = x.flatten(1), y

    def answer(self, x: torch.Tensor) -> list:
        """Intention: the class of the nearest kept example."""
        return self.y[torch.cdist(x.flatten(1), self.x).argmin(1)].tolist()

    def weights(self) -> int:
        """Intention: it learns nothing, but it keeps every training example whole — its size is every number kept."""
        return int(self.x.numel())


class Taught:
    """Intention: a standard network taught by steps until a doubling round of steps no longer lowers its loss."""

    name = ""

    def build(self, x: torch.Tensor, classes: int) -> torch.nn.Module:
        """Intention: the network, made for the shape of the examples."""
        raise NotImplementedError

    def fit(self, x: torch.Tensor, y: torch.Tensor, classes: int, budget: float = None) -> None:
        """Intention: rounds of 1, 2, 4 ... steps (Adam at the library's own rate); stop when every training example
        is right (it has learned what it was shown), when two rounds in a row brought no lower loss than the best
        so far, or when it has had `budget` seconds (the time the Eye had; None is no limit).

        Intention: measured 2026-11-05 — a line fit's loss rises for a few steps before it falls (0.56 at step 2,
        0.61 at step 4, 0.53 at step 9), so one round with no gain stopped it at 7 steps and 50%. A second round,
        twice as long, settles it.
        """
        import time
        began = time.monotonic()
        torch.manual_seed(0)
        self.net = self.build(x, classes)
        opt = torch.optim.Adam(self.net.parameters())
        best, size, flat, self.steps = float("inf"), 1, 0, 0
        while True:
            lowest = float("inf")
            for _ in range(size):
                opt.zero_grad()
                out = self.net(x)
                loss = torch.nn.functional.cross_entropy(out, y)
                loss.backward()
                opt.step()
                self.steps += 1
                lowest = min(lowest, float(loss.detach()))
            if bool((out.argmax(1) == y).all()) or (budget and time.monotonic() - began >= float(budget)):
                return
            flat = flat + 1 if lowest >= best else 0
            if flat >= 2:
                return
            best, size = min(best, lowest), size * 2

    def answer(self, x: torch.Tensor) -> list:
        """Intention: the class it scores highest."""
        with torch.no_grad():
            return self.net(x).argmax(1).tolist()

    def weights(self) -> int:
        """Intention: how many weights it learned."""
        return sum(p.numel() for p in self.net.parameters())


class LineFit(Taught):
    """Intention: a line fit (logistic regression) — every input number weighed once per class."""

    name = "line fit"

    def build(self, x: torch.Tensor, classes: int) -> torch.nn.Module:
        """Intention: one linear layer from the flattened input to the classes."""
        return torch.nn.Sequential(torch.nn.Flatten(), torch.nn.Linear(x[0].numel(), classes))


class SmallNet(Taught):
    """Intention: the small standard network — a two-layer CNN for pictures, a one-hidden-layer MLP for words."""

    name = "small standard network"

    def build(self, x: torch.Tensor, classes: int) -> torch.nn.Module:
        """Intention: for a picture, two 3x3 convolutions with pooling; for word counts, one hidden layer as wide as
        the input is long (no set width)."""
        if x.dim() == 4:
            side = (x.shape[2] // 4) * (x.shape[3] // 4)
            return torch.nn.Sequential(
                torch.nn.Conv2d(x.shape[1], 16, 3, padding=1), torch.nn.ReLU(), torch.nn.MaxPool2d(2),
                torch.nn.Conv2d(16, 32, 3, padding=1), torch.nn.ReLU(), torch.nn.MaxPool2d(2),
                torch.nn.Flatten(), torch.nn.Linear(32 * side, classes))
        width = x.shape[1]
        return torch.nn.Sequential(torch.nn.Linear(width, width), torch.nn.ReLU(), torch.nn.Linear(width, classes))


def standards() -> list:
    """Intention: the standard learners, smallest first."""
    return [NearestMatch(), LineFit(), SmallNet()]


class RateCheck:
    """Intention: the Eye's try set beside the standards — the minimum, and the efficiency of each."""

    def measured(self, learner, train_x, train_y, test_x, test_y, classes: int, budget: float = None) -> dict:
        """Intention: one standard taught (for at most `budget` seconds) and asked; right on unseen, weights, seconds."""
        began = time.monotonic()
        learner.fit(train_x, train_y, classes, budget)
        got = learner.answer(test_x)
        right = sum(int(g == t) for g, t in zip(got, test_y.tolist())) / max(len(got), 1)
        return {"name": learner.name, "right": round(right, 4), "weights": int(learner.weights()),
                "seconds": round(time.monotonic() - began, 2), "steps": int(getattr(learner, "steps", 0))}

    def check(self, kind: str, train_in: list, train_labels: list, test_in: list, test_labels: list,
              classes: list, guessing: float, eye: dict) -> dict:
        """Intention: every standard measured; the minimum named; the Eye set beside it — at least as good, and what
        it cost against what the minimum cost. `eye` is {right, seconds, weights}."""
        words = None if kind == "image" else Words(texts_of(train_in))
        train_x, test_x = as_rows(train_in, kind, words), as_rows(test_in, kind, words)
        index = {c: i for i, c in enumerate(classes)}
        train_y = torch.tensor([index[c] for c in train_labels])
        test_y = torch.tensor([index[c] for c in test_labels])
        # Intention: each standard has the same time the Eye had to learn - the same budget, so the efficiency is fair.
        budget = float(eye["seconds"]) if eye.get("seconds") else None
        rows = [self.measured(s, train_x, train_y, test_x, test_y, len(classes), budget) for s in standards()]
        unseen = len(test_labels)
        for row in rows:
            row["does_the_task"] = clears_guessing(row["right"], guessing, unseen)
            row["over_guessing"] = round(row["right"] - guessing, 4)
        # Intention: THE MINIMUM is the smallest by what it keeps (weights; every kept number for the nearest match)
        # among those that do the task.
        minimum = min((r for r in rows if r["does_the_task"]), key=lambda r: r["weights"], default=None)
        best = max(rows, key=lambda r: r["right"])
        eye_right = float(eye.get("right", 0.0))
        said = {"standards": rows, "caveats": list(CAVEATS),
                "eye": {"right": round(eye_right, 4), "seconds": eye.get("seconds"), "weights": eye.get("weights"),
                        "does_the_task": clears_guessing(eye_right, guessing, unseen),
                        "over_guessing": round(eye_right - guessing, 4)},
                "best_standard": best["name"], "behind_best": round(best["right"] - eye_right, 4)}
        if minimum is None:
            said["minimum"] = None
            said["verdict"] = "no standard does this task on these examples - more examples are needed to judge"
            return said
        said["minimum"] = minimum["name"]
        said["behind_minimum"] = round(minimum["right"] - eye_right, 4)
        said["eye_reaches_minimum"] = eye_right >= minimum["right"] - 2.0 * math.sqrt(
            max(minimum["right"] * (1.0 - minimum["right"]), 1e-12) / max(unseen, 1))
        said["cost_against_minimum"] = {
            "seconds": round(float(eye.get("seconds") or 0.0) / max(minimum["seconds"], 1e-3), 2),
            "weights": (round(float(eye["weights"]) / minimum["weights"], 2)
                        if eye.get("weights") and minimum["weights"] else None)}
        said["verdict"] = ("the Eye reaches the minimum" if said["eye_reaches_minimum"]
                           else f"the Eye is behind the minimum ({minimum['name']}) by "
                                f"{said['behind_minimum']:.0%} - find why")
        return said
