# WARP2/warp2/capability/tests/test_the_step_stays_on_a_set_until_it_settles.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_the_step_stays_on_a_set_until_it_settles.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/capability/staying.py (Staying), warp2/capability/readable.py (Pick), warp2/capability/notes.py,
#              warp2/capability/trial.py (the note's unseen count).
#  Description:
#    A set the Eye has started on is stayed on, with twice the examples, ahead of every never-tried task, until
#    its held-out score stops rising by more than one unseen example's worth; then it is left and the reason is said.
#  User intention (Andrew, 2026-11-07 04:49): "take the basics at the limit it is at right now and work from there".
# ============================================================================
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))

from warp2.capability.notes import TaskNotes  # noqa: E402
from warp2.capability.readable import Pick  # noqa: E402
from warp2.capability.staying import Staying  # noqa: E402


class _Hub:
    """Intention: every dataset is open and readable."""
    viewer = ""

    def facts(self, dataset):
        return {"id": dataset}


def _step(datasets):
    from warp2.work.side.capability import CapabilityStep
    step = CapabilityStep.__new__(CapabilityStep)
    step._datasets = lambda task: list(datasets.get(task["id"], []))
    step._what_next = lambda task, notes: CapabilityStep._what_next(step, task, notes)
    return step


def _notes(tmp_path, rows):
    notes = TaskNotes(tmp_path)
    notes.path.parent.mkdir(parents=True, exist_ok=True)
    notes.path.write_text("".join(json.dumps(r) + "\n" for r in rows), encoding="utf-8")
    return notes


def test_one_try_below_guessing_is_stayed_on_with_twice_the_examples(tmp_path):
    """Intention: CIFAR scored 5% vs 20% once: the next pick is CIFAR again, 200 examples, before the never-tried task."""
    notes = _notes(tmp_path, [{"task": "A", "dataset": "a/cifar", "shape": "image", "examples": 100, "wanted": 100,
                               "right": 0.05, "guessing": 0.2, "unseen": 20, "when": "2026-11-07T08:59:00"}])
    pick = Pick(_step({"A": ["a/cifar"], "B": ["b/open"]}), notes, rows=_Hub()).choose([{"id": "B"}, {"id": "A"}])
    assert pick["task"]["id"] == "A" and pick["dataset"] == "a/cifar" and pick["wanted"] == 200


def test_a_set_whose_rise_is_within_one_example_is_left_and_said(tmp_path):
    """Intention: two tries, 0.40 then 0.42 with 50 unseen (one example is 0.02): settled; B is picked; the why says so."""
    rows = [{"task": "A", "dataset": "a/cifar", "shape": "image", "examples": 200, "wanted": 200, "right": 0.40, "guessing": 0.2, "unseen": 40, "when": "2026-11-07T09:00:00"},
            {"task": "A", "dataset": "a/cifar", "shape": "image", "examples": 250, "wanted": 400, "right": 0.42, "guessing": 0.2, "unseen": 50, "when": "2026-11-07T10:00:00"}]
    notes = _notes(tmp_path, rows)
    assert Staying(notes).next_try("A") is None
    assert "settled at 42%" in Staying(notes).why_left("A")
    pick = Pick(_step({"A": ["a/cifar"], "B": ["b/open"]}), notes, rows=_Hub()).choose([{"id": "A"}, {"id": "B"}])
    assert pick["task"]["id"] == "B"


def test_a_set_still_rising_is_stayed_on(tmp_path):
    """Intention: 0.40 then 0.50 with 50 unseen: rising; stayed on with 800 examples."""
    rows = [{"task": "A", "dataset": "a/cifar", "shape": "image", "examples": 200, "wanted": 200, "right": 0.40, "guessing": 0.2, "unseen": 40, "when": "2026-11-07T09:00:00"},
            {"task": "A", "dataset": "a/cifar", "shape": "image", "examples": 400, "wanted": 400, "right": 0.50, "guessing": 0.2, "unseen": 50, "when": "2026-11-07T10:00:00"}]
    assert Staying(_notes(tmp_path, rows)).next_try("A") == ("a/cifar", 800)


def test_the_try_notes_how_many_were_unseen():
    """Intention: the note carries the unseen count the settling rule reads."""
    import inspect
    from warp2.capability import trial
    assert "unseen=len(test_y)" in inspect.getsource(trial)
