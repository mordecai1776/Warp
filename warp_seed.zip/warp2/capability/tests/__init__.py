# WARP2/warp2/capability/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/__init__.py
#  Used by   : pytest, to find the capability tests.
#  Uses      : nothing.
#  Description:
#    Makes warp2/capability/tests a package.
#  User intention (Andrew):
#    2026-09-24: the Eye tries what models are trained to do, with notes.
# ============================================================================
