# WARP2/warp2/capability/tests/test_a_try_says_where_its_time_went.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_a_try_says_where_its_time_went.py
#  Used by   : pytest.
#  Uses      : warp2/capability/{trial,notes}.py.
#  Description:
#    A try's note says how long the parts-first teaching, the lesson and the
#    growth notes each took, and the memory free before and after the lesson.
#  User intention (Andrew, 2026-11-09 09:49, on "why the Eye's test-task run
#    takes hours"): "Yes" (BUILD_LOG 1477).
# ============================================================================
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))

from warp2.capability.notes import TaskNotes  # noqa: E402
from warp2.capability.trial import EyeTrial, free_memory_mb  # noqa: E402


class _Rows:
    """Intention: twenty short texts, two kinds."""

    def read(self, dataset, wanted, seed):
        rows = [{"sentence": f"good {i}" if i % 2 else f"bad {i}", "label": i % 2} for i in range(20)]
        return {"features": [{"name": "sentence", "type": {"_type": "Value", "dtype": "string"}},
                             {"name": "label", "type": {"_type": "ClassLabel", "names": ["bad", "good"]}}],
                "rows": rows, "split": "default/train"}


class _SlowBook:
    """Intention: a lesson that takes a measurable while."""

    def learn(self, part, x, y, classes, kind):
        time.sleep(0.2)

    def read(self, part, x):
        return [{"good": 1.0, "bad": 0.0} if "good" in row[0]["says"] else {"good": 0.0, "bad": 1.0} for row in x]

    def save(self):
        pass


def test_a_try_says_where_its_time_went_and_the_memory_free(tmp_path):
    """Intention: the lesson's own seconds, apart from the rest, and the free memory around it."""
    note = EyeTrial(tmp_path, TaskNotes(tmp_path), rows=_Rows(), book=_SlowBook()).run(
        {"id": "text-classification"}, "d", 20, 1)
    took = note["took"]
    assert took["lesson"] > 0 and took["lesson"] >= took["grown"] and "parts_first" in took
    free = free_memory_mb()
    assert set(took["free_mb"]) == {"before", "after"} and (free is None or took["free_mb"]["before"] > 0)
