# WARP2/warp2/capability/tests/test_the_eye_is_set_beside_the_standard.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_the_eye_is_set_beside_the_standard.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/capability/rate_check.py (RateCheck, clears_guessing, Words, LineFit),
#              warp2/capability/trial.py (EyeTrial), warp2/capability/notes.py (TaskNotes); torch.
#  Description:
#    Every Eye try is set beside standard learners on the same examples: the minimum is the smallest (by what it
#    keeps) that does the task; the Eye is judged against it and its cost set beside the minimum's; the caveats for
#    the Eye's design go with it; a standard is taught until it has learned what it was shown; words become counts
#    of the words seen in training; and a try's note carries the check.
#  User intention (Andrew, 2026-11-05): "we need to make sure that the eye learns at the rate of the current
#    standard with cavoites for the difference of design"; "proportional code it gets the minimum to do a task. One
#    so we test the minimum and second to test efficiency."
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))

from warp2.capability.notes import TaskNotes  # noqa: E402
from warp2.capability.rate_check import CAVEATS, LineFit, RateCheck, Words, clears_guessing  # noqa: E402
from warp2.capability.trial import EyeTrial  # noqa: E402


def _pictures(n, value, seed):
    """Intention: n noisy pictures around one brightness."""
    torch.manual_seed(seed)
    return [torch.clamp(torch.full((3, 16, 16), value) + 0.2 * torch.randn(3, 16, 16), 0, 1) for _ in range(n)]


def _dark_and_bright():
    """Intention: a task any small standard can do — dark pictures and bright ones."""
    train = _pictures(20, 0.2, 1) + _pictures(20, 0.8, 2)
    test = _pictures(10, 0.2, 3) + _pictures(10, 0.8, 4)
    return train, ["dark"] * 20 + ["bright"] * 20, test, ["dark"] * 10 + ["bright"] * 10


def test_clearly_above_guessing_is_two_standard_errors():
    """Intention: 50% guessing on 20 unseen: the bar is 50% + 2 x 11.2% = 72.4%."""
    assert not clears_guessing(0.70, 0.5, 20)
    assert clears_guessing(0.75, 0.5, 20)


def test_the_minimum_is_the_smallest_that_does_the_task_and_the_eye_is_judged_against_it():
    """Intention: the smallest standard by what it keeps among those that do it; behind it says find why; the cost
    against it is said; the caveats go with it."""
    train, train_y, test, test_y = _dark_and_bright()
    said = RateCheck().check("image", train, train_y, test, test_y, ["bright", "dark"], 0.5,
                             {"right": 0.5, "seconds": 10.0, "weights": 5000})
    doers = [r for r in said["standards"] if r["does_the_task"]]
    assert doers and said["minimum"] == min(doers, key=lambda r: r["weights"])["name"]
    nearest = next(r for r in said["standards"] if r["name"] == "nearest match")
    assert nearest["weights"] == 40 * 3 * 16 * 16, "the nearest match keeps every example"
    assert said["eye_reaches_minimum"] is False and "find why" in said["verdict"]
    assert said["cost_against_minimum"]["weights"] > 0 and said["cost_against_minimum"]["seconds"] > 0
    assert said["caveats"] == list(CAVEATS)
    # Intention (Andrew, 2026-11-05 23:22): the Eye learns every component of the task, not the task alone - said every time.
    assert any("every component" in c for c in said["caveats"])
    good = RateCheck().check("image", train, train_y, test, test_y, ["bright", "dark"], 0.5,
                             {"right": 1.0, "seconds": 1.0, "weights": 100})
    assert good["eye_reaches_minimum"] is True and good["verdict"] == "the Eye reaches the minimum"


def test_a_standard_is_taught_until_it_has_learned_what_it_was_shown():
    """Intention: no set number of steps — it stops once every training example is right."""
    train, train_y, _, _ = _dark_and_bright()
    x = torch.stack(train)
    y = torch.tensor([0 if c == "bright" else 1 for c in train_y])
    fit = LineFit()
    fit.fit(x, y, 2)
    assert fit.steps > 7, "not cut off by the first round with no gain"
    with torch.no_grad():
        assert (fit.net(x).argmax(1) == y).float().mean() >= 0.9


def test_words_are_counted_from_the_words_seen_in_training():
    """Intention: the vocabulary is the training texts' words; an unseen word adds nothing."""
    words = Words(["good fine", "bad"])
    rows = words.rows(["good good bad", "never seen"])
    assert rows.shape == (2, 3) and rows[0].tolist() == [2.0, 0.0, 1.0] and rows[1].sum() == 0


def test_a_try_carries_the_check_in_its_note(tmp_path):
    """Intention: the Eye's right, beside every standard's, kept in the try's note and said."""

    class _Rows:
        def read(self, dataset, wanted, seed):
            rows = [{"sentence": f"good {i}" if i % 2 else f"bad {i}", "label": i % 2} for i in range(20)]
            return {"features": [{"name": "sentence", "type": {"_type": "Value", "dtype": "string"}},
                                 {"name": "label", "type": {"_type": "ClassLabel", "names": ["bad", "good"]}}],
                    "rows": rows, "split": "default/train"}

    class _Book:
        def learn(self, part, x, y, classes, kind):
            pass

        def read(self, part, x):
            return [{"good": 1.0, "bad": 0.0} if "good" in row[0]["says"] else {"good": 0.0, "bad": 1.0} for row in x]

        def save(self):
            pass

    note = EyeTrial(tmp_path, TaskNotes(tmp_path), rows=_Rows(), book=_Book()).run(
        {"id": "text-classification"}, "d", 20, 1)
    assert note["right"] == 1.0
    rate = note["rate"]
    assert [r["name"] for r in rate["standards"]] == ["nearest match", "line fit", "small standard network"]
    assert rate["eye"]["right"] == 1.0 and rate["verdict"] in note["said"]
