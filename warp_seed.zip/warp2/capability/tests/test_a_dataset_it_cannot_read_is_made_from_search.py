# WARP2/warp2/capability/tests/test_a_dataset_it_cannot_read_is_made_from_search.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_a_dataset_it_cannot_read_is_made_from_search.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/capability/examples.py (HubRows), warp2/capability/searched_set.py
#              (CardClasses, SearchedSet), warp2/capability/trial.py (EyeTrial),
#              warp2/capability/notes.py (TaskNotes); numpy, PIL.
#  Description:
#    A renamed dataset is read under its new name; a gated one is not read and
#    says it needs a login; the viewer's own reason is said; the classes a
#    hub card names are read; and when a dataset cannot be read but its card
#    names the classes of a picture dataset, the try is made on pictures
#    found by searching each class, labelled with it.
#  User intention (Andrew, 2026-11-04): "how to get around that gate or why it
#    is not making its own dataset from search"; "Let's do all 3".
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))

from warp2.capability.examples import HubRows  # noqa: E402
from warp2.capability.notes import TaskNotes  # noqa: E402
from warp2.capability.searched_set import CardClasses, SearchedSet  # noqa: E402
from warp2.capability.trial import EyeTrial  # noqa: E402

HUB = "https://huggingface.co/api/datasets"
CARD = {"id": "zalando/fm", "gated": False, "cardData": {"dataset_info": {"features": [
    {"name": "image", "dtype": "image"},
    {"name": "label", "dtype": {"class_label": {"names": {"0": "shirt", "1": "boot", "10": "bag", "2": "coat"}}}}]}}}
# Intention: a card with two picture classes, so the try below searches both.
TWO = {"id": "fb/x", "cardData": {"dataset_info": {"features": [
    {"name": "image", "dtype": "image"}, {"name": "label", "dtype": {"class_label": {"names": ["shirt", "boot"]}}}]}}}
FEATURES = [{"name": "image", "type": {"_type": "Image"}},
            {"name": "label", "type": {"_type": "ClassLabel", "names": ["shirt", "boot"]}}]


def test_a_renamed_dataset_is_read_under_its_new_name():
    """Intention: the hub sends the old name on; the viewer is asked with the new one."""
    asked = []

    def get(url):
        asked.append(url)
        if url == f"{HUB}/fashion_mnist":
            return CARD
        if "/splits?" in url:
            return {"splits": [{"config": "c", "split": "train"}]}
        if "/rows?" in url:
            return {"rows": [{"row": {"image": {"src": "s"}, "label": i % 2}} for i in range(10)],
                    "features": FEATURES, "num_rows_total": 10}
        return None

    got = HubRows(get=get).read("fashion_mnist", 10, 1)
    assert got["dataset"] == "zalando/fm" and got["renamed_from"] == "fashion_mnist" and len(got["rows"]) == 10
    assert all("fashion_mnist" not in url for url in asked if "datasets-server" in url)


def test_a_gated_dataset_is_not_read_and_says_it_needs_a_login():
    """Intention: no viewer call for a gated dataset; the reason is the login, not "too big"."""
    asked = []

    def get(url):
        asked.append(url)
        return {"id": "lab/x", "gated": "manual"} if url.startswith(HUB) else None

    got = HubRows(get=get).read("lab/x", 10, 1)
    assert "gated" in got["why"] and "login" in got["why"] and got["card"]["gated"] == "manual"
    assert not [url for url in asked if "datasets-server" in url]


def test_the_viewers_own_reason_is_said():
    """Intention: a dataset that runs its own code says so, instead of "gated, private or too big"."""
    got = HubRows(get=lambda url: {"id": "fb/vqa"} if url.startswith(HUB) else None,
                  why=lambda url: "it runs arbitrary Python code").read("fb/vqa", 10, 1)
    assert got["why"] == "fb/vqa: the hub's viewer could not read any split (it runs arbitrary Python code)"


def test_a_cards_classes_are_read_in_order():
    """Intention: names in their index order, and whether the input is a picture."""
    assert CardClasses().of(CARD) == (["shirt", "boot", "coat", "bag"], True)
    text = {"cardData": {"dataset_info": [{"features": [{"name": "t", "dtype": "string"},
                                                        {"name": "l", "dtype": {"class_label": {"names": ["a", "b"]}}}]}]}}
    assert CardClasses().of(text) == (["a", "b"], False)
    assert CardClasses().of({}) == ([], False)


def _pictures(tmp_path, name, count):
    """Intention: `count` small picture files for one class, as the generation system would leave them."""
    out = []
    for i in range(count):
        path = tmp_path / f"{name}_{i}.png"
        Image.fromarray(np.full((6, 6, 3), 40 if name == "shirt" else 200, dtype=np.uint8)).save(path)
        out.append(path)
    return out


class _Curator:
    """Intention: the generation system's answer — a manifest of found pictures for each topic asked."""

    def __init__(self, tmp_path, have=("shirt", "boot", "coat", "bag")):
        self.tmp_path, self.have, self.asked = tmp_path, have, []

    def discover_and_create_needed(self, topics, min_samples=15):
        self.asked.append((tuple(topics), min_samples))
        name = topics[0]
        if name not in self.have:
            return []
        found = _pictures(self.tmp_path, name, 5)
        return [{"train_samples": [{"image_path": str(p)} for p in found[:4]],
                 "test_samples": [{"image_path": str(found[4])}]}]


def test_pictures_are_found_for_classes_and_labelled_with_them(tmp_path):
    """Intention: enough classes for the examples at the pictures per topic, at least two; each picture keeps its class."""
    curator = _Curator(tmp_path)
    got = SearchedSet(tmp_path, tmp_path, curator=curator, per=5).pairs(CARD, 10, 3)
    assert len(got["searched"]) == 2 and len(got["classes"]) == 2
    assert all(size == 5 for _, size in curator.asked)
    assert {label for _, label in got["pairs"]} == set(got["classes"]) and len(got["pairs"]) == 10
    assert all(Path(cell["path"]).is_file() for cell, _ in got["pairs"])
    none = SearchedSet(tmp_path, tmp_path, curator=_Curator(tmp_path, have=()), per=5).pairs(CARD, 10, 3)
    assert none == {"why": "picture search found pictures for 0 of 2 of its classes"}
    assert "no classes" in SearchedSet(tmp_path, tmp_path, curator=curator, per=5).pairs({}, 10, 3)["why"]


def test_a_dataset_it_cannot_read_is_tried_on_pictures_found_by_search(tmp_path):
    """Intention: unread, but its card names picture classes: the Eye learns four parts of the found pictures, is
    asked the fifth, and the note says the pictures were found by search."""

    class _Rows:
        def read(self, dataset, wanted, seed):
            return {"why": "fb/x: the hub's viewer could not read any split (it runs arbitrary Python code)",
                    "dataset": dataset, "card": TWO}

    class _Book:
        learned = []

        def learn(self, part, x, y, classes, kind):
            _Book.learned.append((part, len(x), classes, kind))

        def read(self, part, x):
            return [{"shirt": 1.0, "boot": 0.0} if float(t.mean()) < 0.5 else {"shirt": 0.0, "boot": 1.0} for t in x]

        def save(self):
            pass

    searched = SearchedSet(tmp_path, tmp_path, curator=_Curator(tmp_path, have=("shirt", "boot")), per=5)
    notes = TaskNotes(tmp_path)
    note = EyeTrial(tmp_path, notes, rows=_Rows(), book=_Book(), searched=searched).run(
        {"id": "image-classification"}, "fb/x", 10, 7)
    assert note["made_from"] == "picture search" and note["shape"] == "image"
    assert _Book.learned and _Book.learned[0][3] == "image" and sorted(_Book.learned[0][2]) == ["boot", "shirt"]
    assert note["said"].startswith("(pictures found by search for its classes)")


def test_without_a_card_the_note_is_as_it_was(tmp_path):
    """Intention: nothing to search for — the reason it could not be read is the whole note."""

    class _Unread:
        def read(self, dataset, wanted, seed):
            return {"why": "gated"}

    note = EyeTrial(tmp_path, TaskNotes(tmp_path), rows=_Unread()).run({"id": "t"}, "d", 10, 1)
    assert note["said"] == "gated" and "made_from" not in note
