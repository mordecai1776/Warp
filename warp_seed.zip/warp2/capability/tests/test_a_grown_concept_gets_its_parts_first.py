# WARP2/warp2/capability/tests/test_a_grown_concept_gets_its_parts_first.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_a_grown_concept_gets_its_parts_first.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : projects/behemoth_eye/eye/grown.py (Grown), warp2/capability/components.py (ComponentBook,
#              ComponentSearch, Prerequisites, parts_part), warp2/work/side/components.py (ComponentsStep,
#              ComponentSearchInChild), warp2/capability/trial.py (EyeTrial); torch.
#  Description:
#    A concept pair bigger than the Eye's average pair (its positive or its negative side) is the sign it lacks
#    its prerequisite parts; the parts are named by the models, a part the Eye already has is linked at once,
#    the rest are found by search and taught as concepts of their own while the whole is held from growing,
#    then linked; a concept flagged again is asked one level deeper; the side step answers a pending flag in a
#    child; and a try teaches the parts already known for its classes before the task itself (bottom up).
#  User intention (Andrew, 2026-11-05 17:37): "We need to have a component search for when a concept pair grows
#    ... We have to build from the bottom up." 18:57: "let's make the growth signal a bigger than average signal
#    ... have its prior concepts look for it then ... freezing while it's running its previous concept pairs,
#    but we need to make sure that it can look for new ones on its own."
# ============================================================================
from __future__ import annotations

import pickle
import sys
from pathlib import Path
from types import SimpleNamespace

import torch

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))

from projects.behemoth_eye.eye.grown import Grown  # noqa: E402
from warp2.capability.components import (ComponentBook, ComponentSearch, Prerequisites, RandomParts,  # noqa: E402
                                         parts_part)


def _eye(normal: dict, inverse: dict):
    """Intention: a stand-in Eye whose pairs say how many nodes each network has."""
    pairs = {}
    for name in normal:
        pairs[name] = SimpleNamespace(pair=SimpleNamespace(normal=SimpleNamespace(nodes=lambda n=normal[name]: n),
                                                           inverse=SimpleNamespace(nodes=lambda n=inverse[name]: n)))
    return SimpleNamespace(concepts=SimpleNamespace(pairs=pairs))


class _Guesser:
    """Intention: the models' answer, given: a dress is made of fabric, buttons, a collar."""

    def __init__(self):
        self.book = SimpleNamespace(entry=lambda word: {"parts": ["fabric", "buttons", "collar"]})
        self.asked = []

    def guess(self, concept, kinds=("types", "parts"), models_per_question=2):
        self.asked.append(concept)
        return {"parts": ["fabric", "buttons", "collar"]}

    def full_name(self, concept, name, kind):
        return f"{concept} {name}"


class _Pictures:
    """Intention: three pictures found for every part but the collar (search found none)."""

    def of(self, name):
        torch.manual_seed(len(name))
        return [] if "collar" in name else [torch.rand(3, 16, 16) for _ in range(3)]


def test_a_pair_bigger_than_the_average_on_either_side_is_flagged_once_per_growth():
    """Intention: averages 3 (normal) and 4 (inverse): b is over on its normal side, a on its inverse side, c on
    neither; furthest over first; a concept already noted at its size is not flagged again until it grows."""
    eye = _eye({"a": 1, "b": 6, "c": 2}, {"a": 10, "b": 1, "c": 1})
    found = Grown.since(eye, {"a": 1, "b": 1, "c": 1})
    assert [(r[0], r[1], r[2], r[3]) for r in found] == [("a", 1, 10, "inverse"), ("b", 1, 6, "normal")]
    assert found[0][4] == 4.0 and found[1][4] == 3.0
    assert Grown.since(eye, {"a": 10, "b": 6, "c": 1}) == []
    assert Grown.since(eye, {"a": 10, "b": 5}) == [("b", 5, 6, "normal", 3.0)]


def test_the_book_keeps_what_grew_pending_until_it_is_answered(tmp_path):
    """Intention: whoever has the Eye open notes the growth; the side step reads it without opening the Eye."""
    book = ComponentBook(tmp_path)
    assert book.saw(_eye({"x": 4, "y": 1}, {"x": 1, "y": 1})) == [("x", 1, 4, "normal", 2.5)]
    again = ComponentBook(tmp_path)
    assert again.pending() == [("x", 1, 4, "normal", 2.5)] and again.noted_nodes() == {"x": 4, "y": 1}
    again.answered("x")
    again.save()
    assert ComponentBook(tmp_path).pending() == []


def test_a_grown_concepts_parts_are_named_found_and_taught_as_concepts(tmp_path):
    """Intention: the parts with pictures become concepts of their own under "parts: dress"; the one search found
    nothing for is kept as a part, not taught."""
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    eye_book = EyeBook(tmp_path, device="cpu")
    guesser = _Guesser()
    search = ComponentSearch(tmp_path, tmp_path, guesser=guesser, pictures=_Pictures())
    concept = "task: image-classification: Dress"
    said = search.run(eye_book, concept)
    assert guesser.asked == ["dress"]
    assert said["parts"] == ["dress fabric", "dress buttons", "dress collar"]
    assert said["taught"] == {"dress buttons": 3, "dress fabric": 3}
    pairs = eye_book.warp.eye.concepts.pairs
    assert f"{parts_part(concept)}: dress fabric" in pairs and f"{parts_part(concept)}: dress buttons" in pairs
    assert f"{parts_part(concept)}: dress collar" not in pairs
    page = ComponentBook(tmp_path).entry(concept)
    assert sorted(page["taught"]) == ["dress buttons", "dress fabric"]
    # Intention: the whole is linked to the parts taught, and its hold was let go after the lesson.
    assert eye_book.warp.eye.prerequisites.of(concept) == [f"{parts_part(concept)}: dress buttons",
                                                           f"{parts_part(concept)}: dress fabric"]
    assert page["linked"] == eye_book.warp.eye.prerequisites.of(concept)


def test_a_part_the_eye_already_has_is_linked_without_a_search(tmp_path):
    """Intention: a prior concept named like the part ("buttons" for "dress buttons") is linked at once; only the
    rest are searched and taught; nothing is searched for the prior one."""
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    eye_book = EyeBook(tmp_path, device="cpu")
    eye_book.learn("task: s", torch.rand(4, 3, 16, 16), ["buttons", "zips"] * 2, ["buttons", "zips"], "image")
    searched = []

    class _Seen(_Pictures):
        def of(self, name):
            searched.append(name)
            return super().of(name)

    search = ComponentSearch(tmp_path, tmp_path, guesser=_Guesser(), pictures=_Seen())
    said = search.run(eye_book, "task: image-classification: Dress")
    assert said["prior"] == {"dress buttons": "task: s: buttons"}
    # Intention: the lone new part is set beside pictures of the whole itself ("dress"), never beside the prior one.
    assert "dress buttons" not in searched and "dress" in searched and said["taught"] == {"dress fabric": 3}
    links = eye_book.warp.eye.prerequisites.of("task: image-classification: Dress")
    assert links[0] == "task: s: buttons" and links[1].endswith("dress fabric")


def test_every_part_feeds_the_whole_with_no_limit(tmp_path):
    """Intention (Andrew, 19:06): forty parts, forty links, all read as company."""
    from projects.behemoth_eye.eye.prerequisites import PrerequisiteBook
    book = PrerequisiteBook()
    names = [f"part {i}" for i in range(40)]
    assert book.link("whole", names) == names and len(book.of("whole")) == 40


def test_the_whole_is_held_from_growing_while_its_parts_are_taught(tmp_path):
    """Intention: both of the whole's networks are held during the parts' lesson and let go after."""
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    eye_book = EyeBook(tmp_path, device="cpu")
    concept = "task: t: Dress"
    eye_book.learn("task: t", torch.rand(4, 3, 16, 16), ["Dress", "Bag"] * 2, ["Bag", "Dress"], "image")
    seen = []
    real = eye_book.learn

    def learn(part, x, y, classes, kind, **kw):
        pair = eye_book.warp.eye.concepts.pairs[concept].pair
        seen.append((pair.normal.growth_held, pair.inverse.growth_held))
        return real(part, x, y, classes, kind, **kw)

    eye_book.learn = learn
    search = ComponentSearch(tmp_path, tmp_path, guesser=_Guesser(), pictures=_Pictures())
    search.run(eye_book, concept)
    pair = eye_book.warp.eye.concepts.pairs[concept].pair
    assert seen == [(True, True)] and (pair.normal.growth_held, pair.inverse.growth_held) == (False, False)


def test_a_concept_flagged_again_is_asked_one_level_deeper(tmp_path):
    """Intention: parts named and taught once; flagged again, the parts of its taught parts are asked for."""
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    eye_book = EyeBook(tmp_path, device="cpu")
    asked = []

    class _Deeper(_Guesser):
        def __init__(self):
            super().__init__()
            self.pages = {"dress": {"parts": ["fabric"]}, "dress fabric": {"parts": ["weave"]}}
            self.book = SimpleNamespace(entry=lambda w: self.pages.get(w, {"parts": []}),
                                        asked=lambda w, kind: w in asked)

        def guess(self, concept, kinds=("types", "parts"), models_per_question=2):
            asked.append(concept)
            return {}

    search = ComponentSearch(tmp_path, tmp_path, guesser=_Deeper(), pictures=_Pictures())
    concept = "task: t: Dress"
    first = search.named(concept)
    assert first == ["dress fabric"] and asked == ["dress"]
    search.book.entry(concept)["taught"]["dress fabric"] = {"pictures": 3}
    again = search.named(concept)
    assert again == ["dress fabric", "dress fabric weave"] and asked == ["dress", "dress fabric"]


def test_the_known_parts_are_taught_before_the_task(tmp_path):
    """Intention: bottom up — a class whose parts are named but not taught gets them taught first; one already
    taught is left alone."""
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    eye_book = EyeBook(tmp_path, device="cpu")
    book = ComponentBook(tmp_path)
    book.entry("task: t: Dress")["parts"] = ["dress fabric", "dress buttons"]
    book.entry("task: t: Bag")["parts"] = ["bag strap"]
    book.entry("task: t: Bag")["taught"] = {"bag strap": {"pictures": 3}}
    book.save()
    search = ComponentSearch(tmp_path, tmp_path, guesser=_Guesser(), pictures=_Pictures())
    done = Prerequisites(tmp_path, tmp_path, search=search).first(eye_book, "task: t", ["Bag", "Dress"])
    assert list(done) == ["task: t: Dress"] and done["task: t: Dress"]["taught"] == {"dress buttons": 3,
                                                                                      "dress fabric": 3}


def test_the_side_step_answers_a_pending_growth_in_a_child(tmp_path):
    """Intention: a pending growth gives a child body that pickles; nothing pending gives none; the told line says
    what grew and what was taught."""
    from warp2.work.side.components import ComponentSearchInChild, ComponentsStep
    told = []
    shared = SimpleNamespace(root=tmp_path, state=tmp_path, loop=SimpleNamespace(store=None),
                             tell=lambda text, **kw: told.append(text))
    step = ComponentsStep(shared)
    assert step.child() is None
    book = ComponentBook(tmp_path)
    book.set_pending([("task: t: Dress", 1, 7, "normal", 2.5)])
    book.save()
    body = step.child()
    assert isinstance(body, ComponentSearchInChild) and body.concept == "task: t: Dress"
    assert pickle.loads(pickle.dumps(body)).concept == body.concept
    step.after_child({"concept": "task: t: Dress", "parts": ["dress fabric"], "taught": {"dress fabric": 3}})
    assert told and "normal side 7 nodes, average 2.5" in told[0] and "dress fabric (3 pictures)" in told[0]


def test_a_try_notes_what_grew(tmp_path):
    """Intention: after its lesson a try looks at the Eye for growth, so the side step can answer it."""
    from warp2.capability.notes import TaskNotes
    from warp2.capability.trial import EyeTrial

    class _Rows:
        def read(self, dataset, wanted, seed):
            rows = [{"sentence": f"good {i}" if i % 2 else f"bad {i}", "label": i % 2} for i in range(20)]
            return {"features": [{"name": "sentence", "type": {"_type": "Value", "dtype": "string"}},
                                 {"name": "label", "type": {"_type": "ClassLabel", "names": ["bad", "good"]}}],
                    "rows": rows, "split": "default/train"}

    class _Book:
        # the parts say this task's part reads pictures (only a picture part's class can be a candidate, 2026-11-07)
        warp = SimpleNamespace(eye=_eye({"task: text-classification: good": 6, "other": 2},
                                        {"task: text-classification: good": 1, "other": 1}),
                               parts={"task: text-classification": {"classes": ["good", "bad"], "kind": "image"}})

        def learn(self, part, x, y, classes, kind):
            pass

        def read(self, part, x):
            return [{"good": 1.0, "bad": 0.0} if "good" in row[0]["says"] else {"good": 0.0, "bad": 1.0} for row in x]

        def save(self):
            pass

    EyeTrial(tmp_path, TaskNotes(tmp_path), rows=_Rows(), book=_Book()).run({"id": "text-classification"}, "d", 20, 1)
    assert ComponentBook(tmp_path).pending() == [("task: text-classification: good", 1, 6, "normal", 4.0)]


def test_random_concept_pairs_are_tried_as_parts_and_kept_when_they_help(tmp_path):
    """Intention (Andrew, 22:04): of the Eye's other pairs, tried at random, the one that widens the whole's own gap
    stays linked, the one that does not is unlinked; neither the whole nor what is already under it is tried."""
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    eye_book = EyeBook(tmp_path, device="cpu")
    eye_book.learn("task: t", torch.rand(4, 3, 16, 16), ["Dress", "Bag"] * 2, ["Bag", "Dress"], "image")
    eye_book.learn("task: u", torch.rand(4, 3, 16, 16), ["edge", "curve"] * 2, ["curve", "edge"], "image")
    concept = "task: t: Dress"
    eye = eye_book.warp.eye
    eye.prerequisites.link(concept, ["task: t: Bag"])

    def measure(book, name):
        return 1.0 + (0.5 if "task: u: edge" in book.warp.eye.prerequisites.of(name) else 0.0)

    search = ComponentSearch(tmp_path, tmp_path, guesser=_Guesser(), pictures=_Pictures())
    tried = RandomParts(search, measure=measure, pick=sorted)
    cands = tried.candidates(eye_book, concept)
    assert concept not in cands and "task: t: Bag" not in cands and "task: u: edge" in cands
    said = tried.try_(eye_book, concept)
    assert "task: u: edge" in said["kept"] and "task: u: curve" in said["dropped"]
    assert eye.prerequisites.of(concept) == ["task: t: Bag", "task: u: edge"]
    assert ComponentBook(tmp_path).entry(concept)["random"] == ["task: u: edge"]


def test_a_concept_read_from_words_is_answered_not_searched(tmp_path):
    """Intention (measured live 2026-11-06 00:01: the first pending concepts were a text task's classes): parts are
    pictures so far; a words concept is answered with why, and nothing is asked of the models or the search."""
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    eye_book = EyeBook(tmp_path, device="cpu")
    tags = [[{"name": "text", "weight": 1.0, "says": f"word {i}", "holds": []}] for i in range(4)]
    eye_book.learn("task: words", tags, ["yes", "no"] * 2, ["no", "yes"], "vector")
    guesser = _Guesser()
    search = ComponentSearch(tmp_path, tmp_path, guesser=guesser, pictures=_Pictures())
    assert ComponentSearch.kind_of(eye_book, "task: words: yes") not in ("", "picture")
    said = search.run(eye_book, "task: words: yes")
    assert said["parts"] == [] and "pictures only" in said["why"] and guesser.asked == []


def test_a_words_concept_pending_is_answered_in_the_runner_without_the_eye(tmp_path):
    """Intention (measured 2026-11-06: three ~200 s child turns to say "pictures only"): with parts.json saying a
    part reads a web of tags, every such pending concept is answered from the book in one turn with no child; the
    first picture concept still gets one."""
    import json
    from warp2.work.side.components import ComponentSearchInChild, ComponentsStep
    (tmp_path / "models" / "eye").mkdir(parents=True)
    (tmp_path / "models" / "eye" / "parts.json").write_text(json.dumps(
        {"task: words": {"classes": ["yes", "no"], "kind": "vector"}, "task: pics": {"classes": ["a", "b"], "kind": "image"}}))
    told = []
    shared = SimpleNamespace(root=tmp_path, state=tmp_path, loop=SimpleNamespace(store=None), tell=lambda text, **kw: told.append(text))
    book = ComponentBook(tmp_path)
    book.set_pending([("task: words: yes", 1, 7, "normal", 2.5), ("task: words: no", 1, 6, "normal", 2.5)])
    book.save()
    step = ComponentsStep(shared)
    assert step.child() is None
    said = step.body()
    assert said["said"] == "answered without opening the Eye" and said["concepts"] == ["task: words: yes", "task: words: no"]
    assert ComponentBook(tmp_path).pending() == [] and len(told) == 2 and "task: words: no" in told[1]
    book = ComponentBook(tmp_path)
    book.set_pending([("task: words: yes", 1, 8, "normal", 2.5), ("task: pics: a", 1, 6, "inverse", 2.5)])
    book.save()
    step2 = ComponentsStep(shared)
    assert isinstance(step2.child(), ComponentSearchInChild) and step2._grew[0] == "task: pics: a"
    assert ComponentBook(tmp_path).pending() == [("task: pics: a", 1, 6, "inverse", 2.5)]
