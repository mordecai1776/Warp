# WARP2/warp2/capability/tests/test_the_step_tries_only_what_can_be_read.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_the_step_tries_only_what_can_be_read.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/capability/readable.py (WhyNot, Pick), warp2/capability/notes.py (TaskNotes),
#              warp2/work/side/capability.py (CapabilityStep).
#  Description:
#    A capability turn goes to the first task with a dataset that can be shown: a gated one, one the hub does not
#    know, one an earlier try found empty, one the viewer cannot serve and one with no named class are passed over
#    (and said), a task with nothing readable is passed
#    over whole, and the step's own order (never tried first, then the oldest) is kept.
#  User intention (Andrew, 2026-11-06): Adaptive - "situations adapt to something, not settle for a certain point of
#    view"; measured: 93 of 99 tries since 09-24 found no data.
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))

from warp2.capability.notes import TaskNotes  # noqa: E402
from warp2.capability.readable import Pick, WhyNot  # noqa: E402


CLASS = [{"name": "image", "type": {"_type": "Image"}}, {"name": "label", "type": {"_type": "ClassLabel", "names": ["a", "b"]}}]
AUDIO = [{"name": "audio", "type": {"_type": "Audio"}}, {"name": "text", "type": {"_type": "Value", "dtype": "string"}}]


class _Hub:
    """Intention: the hub's word on each dataset, and its viewer's: splits and a first row."""

    cards = {"a/gated": {"id": "a/gated", "gated": True}, "a/open": {"id": "a/open"}, "b/open": {"id": "b/open"},
             "c/open": {"id": "c/open"}, "a/noviewer": {"id": "a/noviewer"}, "a/audio": {"id": "a/audio"}}
    viewer = "viewer"
    features = {"a/audio": AUDIO}

    def __init__(self):
        self.asked = []

    def facts(self, dataset):
        self.asked.append(dataset)
        return dict(self.cards.get(dataset, {}))

    def get(self, url):
        import urllib.parse
        q = dict(urllib.parse.parse_qsl(url.split("?", 1)[1]))
        if url.startswith("viewer/splits"):
            return {} if q["dataset"] == "a/noviewer" else {"splits": [{"config": "default", "split": "train"}]}
        feats = self.features.get(q["dataset"], CLASS)
        return {"features": feats, "rows": [{"row": {f["name"]: 0 for f in feats}}]}


def _step(datasets: dict):
    """Intention: a stand-in step with the real step's two orderings."""
    from warp2.work.side.capability import CapabilityStep
    step = CapabilityStep.__new__(CapabilityStep)
    step._datasets = lambda task: list(datasets.get(task["id"], []))
    step._what_next = lambda task, notes: CapabilityStep._what_next(step, task, notes)
    return step


def test_a_gated_an_unknown_and_an_empty_dataset_are_passed_over_and_said(tmp_path):
    """Intention: task A's datasets are gated, unknown, found-empty-before, then open: the open one is picked."""
    notes = TaskNotes(tmp_path)
    notes.add({"task": "A", "dataset": "a/empty", "shape": "unread", "said": "a/empty: the hub's viewer could not read any split"})
    hub = _Hub()
    step = _step({"A": ["a/gated", "a/nowhere", "a/empty", "a/noviewer", "a/audio", "a/open"]})
    pick = Pick(step, notes, rows=hub).choose([{"id": "A"}])
    assert pick["task"]["id"] == "A" and pick["dataset"] == "a/open"
    assert [s[1] for s in pick["skipped"]] == ["a/gated", "a/nowhere", "a/empty", "a/noviewer", "a/audio"]
    whys = [s[2] for s in pick["skipped"]]
    assert "gated" in whys[0] and "nothing" in whys[1] and "earlier try" in whys[2]
    assert "viewer cannot read" in whys[3] and whys[4].startswith("no column is a named class")
    assert "a/empty" not in hub.asked, "a dataset found empty before is not asked of the hub again"


def test_a_task_with_nothing_readable_is_passed_over_whole(tmp_path):
    """Intention: task A has only a gated dataset; task B is never tried and open: B is picked, A is in the skipped."""
    notes = TaskNotes(tmp_path)
    step = _step({"A": ["a/gated"], "B": ["b/open"]})
    pick = Pick(step, notes, rows=_Hub()).choose([{"id": "A"}, {"id": "B"}])
    assert pick["task"]["id"] == "B" and pick["dataset"] == "b/open"
    assert pick["skipped"] == [("A", "a/gated", "gated - it needs a Hugging Face login with its terms accepted")]


def test_the_order_is_never_tried_first_then_the_oldest(tmp_path):
    """Intention: C never tried comes before A and B; A tried longer ago comes before B."""
    import json
    notes = TaskNotes(tmp_path)
    notes.path.parent.mkdir(parents=True, exist_ok=True)
    # A and B have each settled (two tries, no rise, the unseen count noted) - a set still rising comes first now
    # (warp2/capability/staying.py, 2026-11-07), so this test is about settled ones.
    notes.path.write_text(json.dumps({"task": "A", "dataset": "a/open", "right": 0.5, "unseen": 20, "when": "2026-10-31T00:00:00"}) + "\n"
                          + json.dumps({"task": "A", "dataset": "a/open", "right": 0.5, "unseen": 20, "when": "2026-11-01T00:00:00"}) + "\n"
                          + json.dumps({"task": "B", "dataset": "b/open", "right": 0.5, "unseen": 20, "when": "2026-11-01T12:00:00"}) + "\n"
                          + json.dumps({"task": "B", "dataset": "b/open", "right": 0.5, "unseen": 20, "when": "2026-11-02T00:00:00"}) + "\n",
                          encoding="utf-8")
    step = _step({"A": ["a/open"], "B": ["b/open"], "C": ["c/open"]})
    pick = Pick(step, notes, rows=_Hub())
    assert [t["id"] for t in pick.order([{"id": "A"}, {"id": "B"}, {"id": "C"}])] == ["C", "A", "B"]


def test_nothing_readable_anywhere_is_said(tmp_path):
    """Intention: every dataset gated: no pick, the skipped list, and why."""
    step = _step({"A": ["a/gated"]})
    pick = Pick(step, TaskNotes(tmp_path), rows=_Hub()).choose([{"id": "A"}])
    assert "task" not in pick and pick["why"] == "no task has a dataset that can be shown" and len(pick["skipped"]) == 1


def test_why_not_reads_the_earlier_tries(tmp_path):
    """Intention: only a try with no answer and an unread/no-data shape counts as found empty."""
    why = WhyNot(_Hub(), [{"dataset": "x", "shape": "unread", "said": "x: gated"}, {"dataset": "y", "right": 0.4, "shape": "image"}])
    assert why.of("x").startswith("an earlier try") and why.of("y") == "the hub says nothing about it (gone, private, or not reached)"
