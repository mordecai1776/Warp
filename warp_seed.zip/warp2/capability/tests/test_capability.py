# WARP2/warp2/capability/tests/test_capability.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_capability.py
#  Used by   : pytest (RUN_TESTS.bat).
#  Uses      : warp2/capability/{tasks,notes,examples,trial,project_maker}.py.
#  Description:
#    The task list is read and kept; a dataset's rows are read in the shape
#    the Eye takes (a picture or a text in, a named class out) or said to be
#    another shape; a try is noted with what the Eye got right against
#    guessing; and a task the Eye cannot do gets one project, once.
#  User intention (Andrew):
#    2026-09-24: "look for anything a model has been trained to do and try to
#    get the eye to do it and take notes on how it does"; "if it needs to
#    make a new project it should do so."
# ============================================================================
from warp2.capability.examples import shaped
from warp2.capability.notes import TaskNotes
from warp2.capability.project_maker import needs_project, open_for, project_name
from warp2.capability.tasks import ModelTasks

TEXT = [{"name": "sentence", "type": {"_type": "Value", "dtype": "string"}},
        {"name": "label", "type": {"_type": "ClassLabel", "names": ["bad", "good"]}}]


def test_the_task_list_is_read_and_kept_for_when_the_hub_is_away(tmp_path):
    """Intention: fresh when it can be, the last one seen when it cannot."""
    hub = {"image-classification": {"label": "Image Classification", "summary": "s",
                                    "datasets": [{"id": "cifar100"}]}}
    first = ModelTasks(tmp_path, get=lambda url: hub).all()
    assert first == [{"id": "image-classification", "label": "Image Classification",
                      "summary": "s", "datasets": ["cifar100"]}]
    assert ModelTasks(tmp_path, get=lambda url: None).all() == first


def test_rows_are_shaped_as_input_and_named_class_or_said_to_be_other():
    """Intention: the one shape the Eye's parts learn, and every other said in words."""
    rows = [{"sentence": "fine", "label": 1}, {"sentence": "awful", "label": 0}]
    got = shaped(TEXT, rows)
    assert got["kind"] == "text" and got["classes"] == ["bad", "good"]
    assert ("fine", "good") in got["pairs"]
    other = shaped([{"name": "depth", "type": {"_type": "Image"}}], [{"depth": {"src": "x"}}])
    assert "not a label" in other["why"]


def test_notes_say_how_it_does_over_guessing(tmp_path):
    """Intention: right on unseen minus always-the-commonest is the one number that says it can."""
    notes = TaskNotes(tmp_path)
    notes.add({"task": "t", "dataset": "d", "right": 0.6, "guessing": 0.5, "examples": 100})
    notes.add({"task": "t", "dataset": "d", "right": 0.8, "guessing": 0.5, "examples": 200})
    said = notes.summary("t")
    assert said["tries"] == 2 and said["best_over_guessing"] == 0.3 and said["last_examples"] == 200


def test_a_task_it_cannot_do_gets_one_project(tmp_path):
    """Intention: two tries it could not take, one project with three areas; asked again, nothing new."""
    from warp2.store.projects import Projects
    from warp2.store.store import Store
    notes = TaskNotes(tmp_path)
    for _ in range(2):
        notes.add({"task": "depth-estimation", "dataset": "d", "said": "not a label", "shape": "not yet"})
    why = needs_project(notes.summary("depth-estimation"), notes.of("depth-estimation"))
    assert why.startswith("the Eye cannot take")
    projects = Projects(Store(tmp_path / "state"), tmp_path / "tree")
    task = {"id": "depth-estimation", "label": "Depth Estimation", "summary": "how far each pixel is"}
    made = open_for(projects, task, why)
    assert made["opened"] and made["project"] == project_name("depth-estimation") == "eye_depth_estimation"
    areas = projects.store.current(subject="project:eye_depth_estimation", relation="contains")
    assert len([a for a in areas if str(a.get("object", "")).startswith("area:")]) == 3
    assert open_for(projects, task, why)["opened"] is False


def test_a_try_is_noted_whatever_happens(tmp_path):
    """Intention: a dataset that cannot be read is a note too, not a silence."""
    from warp2.capability.trial import EyeTrial

    class _Unread:
        def read(self, dataset, wanted, seed):
            return {"why": "gated"}

    notes = TaskNotes(tmp_path)
    note = EyeTrial(tmp_path, notes, rows=_Unread()).run({"id": "t"}, "d", 10, 1)
    assert note["said"] == "gated" and notes.summary("t")["tries"] == 1


def test_a_try_teaches_four_parts_and_asks_the_fifth(tmp_path):
    """Intention: the Eye's part learns what it is shown and is judged only on what it was not."""
    from warp2.capability.trial import EyeTrial

    class _Rows:
        def read(self, dataset, wanted, seed):
            rows = [{"sentence": f"good {i}" if i % 2 else f"bad {i}", "label": i % 2} for i in range(20)]
            return {"features": TEXT, "rows": rows, "split": "default/train"}

    class _Book:
        learned, asked = [], []

        def learn(self, part, x, y, classes, kind):
            _Book.learned.append((part, len(x), classes))

        def read(self, part, x):
            _Book.asked.append(len(x))
            return [{"good": 1.0, "bad": 0.0} if "good" in row[0]["says"] else {"good": 0.0, "bad": 1.0}
                    for row in x]

        def save(self):
            pass

    notes = TaskNotes(tmp_path)
    note = EyeTrial(tmp_path, notes, rows=_Rows(), book=_Book()).run({"id": "text-classification"}, "d", 20, 1)
    assert _Book.learned == [("task: text-classification", 16, ["bad", "good"])] and _Book.asked == [4]
    assert note["right"] == 1.0 and note["guessing"] == 0.5 and "learning this" in note["said"]
