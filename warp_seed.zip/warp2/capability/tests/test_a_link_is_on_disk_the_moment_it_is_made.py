# WARP2/warp2/capability/tests/test_a_link_is_on_disk_the_moment_it_is_made.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_a_link_is_on_disk_the_moment_it_is_made.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/capability/components.py (ComponentSearch.link), projects/behemoth_eye/eye/warp_eye.py
#              (WarpEye.save_prerequisites), warp2/work/side/components.py (ComponentSearchInChild).
#  Description:
#    A part link is written to prerequisites.json the moment the search makes it, and the child's Eye save at the
#    end of a search is forced - never held back by the save pace. Measured 2026-11-07: the child's book.save()
#    was paced, so it only marked the Eye unsaved; the child ended; sphere's links (21:13 UTC) never reached disk.
#  User intention (Andrew, 2026-11-06 00:06): "Clean is nothing left behind."
# ============================================================================
from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))


def test_the_link_is_written_at_once(tmp_path):
    """Intention: after link(), prerequisites.json beside the Eye holds the link, whatever the save pace says."""
    from projects.behemoth_eye.eye.prerequisites import PrerequisiteBook
    from projects.behemoth_eye.eye.warp_eye import WarpEye
    from warp2.capability.components import ComponentSearch
    home = tmp_path / "models" / "eye"; home.mkdir(parents=True)
    we = WarpEye.__new__(WarpEye)
    we.home = home
    we.eye = SimpleNamespace(prerequisites=PrerequisiteBook())
    we.pending = {}
    eye_book = SimpleNamespace(warp=we)
    search = ComponentSearch.__new__(ComponentSearch)
    from warp2.capability.components import ComponentBook
    search.book = ComponentBook(tmp_path)
    search.link(eye_book, "task: pics: coat", ["parts: coat: collar"])
    assert json.loads((home / "prerequisites.json").read_text(encoding="utf-8")) == {"task: pics: coat": ["parts: coat: collar"]}


def test_the_childs_save_is_forced(monkeypatch, tmp_path):
    """Intention: the search child saves the Eye with force=True at the end."""
    from warp2.work.side import components as module
    forced = {}

    class _Warp:
        eye = SimpleNamespace(prerequisites=None)

        def save(self, force=False):
            forced["force"] = force
            return []

    class _Book:
        def __init__(self, state):
            self.warp = _Warp()

        def save(self):
            return self.warp.save()

    class _Search:
        def __init__(self, root, state):
            self.book = SimpleNamespace(answered=lambda c: None, saw=lambda eye, parts=None: [])

        def run(self, book, concept):
            return {"parts": []}
    monkeypatch.setattr("projects.behemoth_eye.eye.warp_eye.EyeBook", _Book)
    monkeypatch.setattr("warp2.capability.components.ComponentSearch", _Search)
    module.ComponentSearchInChild(tmp_path, tmp_path, "task: pics: a")()
    assert forced == {"force": True}
