# WARP2/warp2/capability/tests/test_random_parts_takes_a_plain_concept.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_random_parts_takes_a_plain_concept.py
#  Used by   : pytest and CHECK_FIXES.bat.
#  Uses      : warp2.capability.components (RandomParts.measure, RandomParts.try_).
#  Description:
#    A concept with no "task: " in front (a picture concept such as "sphere")
#    is its own task and label, the same way ComponentSearch reads it. The
#    random-parts try must answer for it, not stop the whole component search
#    with "not enough values to unpack" (seen live: seq 15,894, 2026-11-07).
#  User intention (Andrew, 2026-11-05 22:04): "It should also be trying to use
#    random concept pairs as subparts of everything to look for when it helps."
# ============================================================================
import types
import unittest

from warp2.capability.components import RandomParts


class _Search:
    """Intention: the search RandomParts belongs to; these cases never reach its book."""
    book = None


def _eye_book(pending):
    """Intention: an Eye book whose warp holds only `pending` kept examples."""
    return types.SimpleNamespace(warp=types.SimpleNamespace(eye=types.SimpleNamespace(), pending=pending))


class _Seen(dict):
    """Intention: pending examples that note which task was asked for."""

    def __init__(self):
        super().__init__()
        self.asked = []

    def get(self, key, default=None):
        self.asked.append(key)
        return default


class RandomPartsTakesAPlainConcept(unittest.TestCase):
    """Intention: plain and task-named concepts both measured without error."""

    def test_a_plain_concept_is_measured(self):
        self.assertIsNone(RandomParts(_Search()).measure(_eye_book({}), "sphere"))

    def test_a_plain_concept_is_its_own_task(self):
        seen = _Seen()
        RandomParts(_Search()).measure(_eye_book(seen), "sphere")
        self.assertEqual(seen.asked, ["sphere"])

    def test_a_task_named_concept_still_reads_its_task(self):
        seen = _Seen()
        RandomParts(_Search()).measure(_eye_book(seen), "task: audio-text-to-text: status")
        self.assertEqual(seen.asked, ["task: audio-text-to-text"])

    def test_the_try_answers_for_a_plain_concept(self):
        said = RandomParts(_Search()).try_(_eye_book({}), "sphere")
        self.assertEqual(said["why"], "nothing kept to measure on")


if __name__ == "__main__":
    unittest.main()
