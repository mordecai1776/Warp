# WARP2/warp2/capability/tests/test_only_a_picture_parts_class_is_a_candidate_for_parts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_only_a_picture_parts_class_is_a_candidate_for_parts.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : projects/behemoth_eye/eye/grown.py (Grown.since), warp2/capability/components.py (ComponentBook.saw).
#  Description:
#    Only a class of a part that reads pictures can be a candidate for the parts search. A bare concept pair
#    ("sphere", a made one) or a class of a words part is never made pending, however big its pair - the search is
#    for what a picture is made of. Measured 2026-11-07 03:13 UTC: "sphere" went to a child and the search fell over
#    on its name; 78 words concepts had queued before that, each costing a ~200 s child to say "pictures only".
#  User intention (Andrew, 2026-11-06 15:34): "Why the hell did it even allow anything but pictures to go in?"
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))

PARTS = {"task: pics": {"classes": ["a", "b"], "kind": "image"}, "task: words": {"classes": ["yes", "no"], "kind": "vector"}}


def _eye(sizes: dict):
    """Intention: an Eye stand-in whose pairs say their sizes."""
    def pair(n):
        return SimpleNamespace(pair=SimpleNamespace(normal=SimpleNamespace(nodes=lambda: n), inverse=SimpleNamespace(nodes=lambda: 1)))
    return SimpleNamespace(concepts=SimpleNamespace(pairs={name: pair(n) for name, n in sizes.items()}))


def test_a_bare_pair_and_a_words_class_are_never_candidates():
    """Intention: three pairs over the average; only the picture part's class comes back."""
    from projects.behemoth_eye.eye.grown import Grown
    eye = _eye({"sphere": 10, "task: pics: a": 10, "task: words: yes": 10, "task: pics: b": 1, "task: words: no": 1})
    assert [row[0] for row in Grown.since(eye, {}, parts=PARTS)] == ["task: pics: a"]


def test_the_book_takes_only_picture_classes_as_pending(tmp_path):
    """Intention: the book, given the parts, makes pending only the picture class; the sizes of all are still noted."""
    from warp2.capability.components import ComponentBook
    eye = _eye({"sphere": 10, "task: pics: a": 10, "task: words: yes": 10, "task: pics: b": 1})
    book = ComponentBook(tmp_path)
    grown = book.saw(eye, parts=PARTS)
    assert [row[0] for row in grown] == ["task: pics: a"]
    assert [row[0] for row in ComponentBook(tmp_path).pending()] == ["task: pics: a"]
    assert ComponentBook(tmp_path).noted_nodes()["sphere"] == 10
