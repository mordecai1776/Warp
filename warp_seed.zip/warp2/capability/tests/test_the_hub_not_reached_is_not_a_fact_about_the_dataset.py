# WARP2/warp2/capability/tests/test_the_hub_not_reached_is_not_a_fact_about_the_dataset.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tests/test_the_hub_not_reached_is_not_a_fact_about_the_dataset.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/chat_learning/datasets.py (get_json, NotReached), warp2/capability/readable.py (WhyNot, Pick),
#              warp2/work/side/capability.py (CapabilityStep.body).
#  Description:
#    A hub that was not reached (network down, timeout) is said as that, this turn, and is not written into the
#    notes as a property of the dataset. Before this the picker read "not reached" as "the hub says nothing about
#    it (gone, private, or not reached)", and a dataset whose try fell on a network failure was passed over on
#    every later pick as "an earlier try found no data".
#  User intention (Andrew, 2026-11-06 00:06): Adaptive - "situations adapt to something, not settle for a certain
#    point of view"; design/plans/AUDIT_2026-11-07.md group C.
# ============================================================================
from __future__ import annotations

import sys
import urllib.error
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))


def test_get_json_says_not_reached_and_keeps_none_for_the_hubs_own_no(monkeypatch):
    """Intention: a URLError raises NotReached naming the address; an HTTP 404 is still None (the hub answered)."""
    from warp2.chat_learning import datasets

    def down(req, timeout=None):
        raise urllib.error.URLError("name resolution failed")
    monkeypatch.setattr(datasets.urllib.request, "urlopen", down)
    with pytest.raises(datasets.NotReached, match="example.org"):
        datasets.get_json("https://example.org/api")

    def gone(req, timeout=None):
        raise urllib.error.HTTPError("https://example.org/api", 404, "gone", {}, None)
    monkeypatch.setattr(datasets.urllib.request, "urlopen", gone)
    assert datasets.get_json("https://example.org/api") is None


def test_the_picker_stops_looking_when_the_hub_is_not_reached(tmp_path):
    """Intention: the first dataset raises NotReached: no pick, the why says not reached, nothing is said about
    the datasets, and the shape is "not reached" so a later WhyNot does not count it as found empty."""
    from warp2.capability.notes import TaskNotes
    from warp2.capability.readable import Pick, WhyNot
    from warp2.chat_learning.datasets import NotReached
    from warp2.work.side.capability import CapabilityStep

    class _Hub:
        def facts(self, dataset):
            raise NotReached("https://hub/" + dataset, "timed out")
    step = CapabilityStep.__new__(CapabilityStep)
    step._datasets = lambda task: ["a/open"]
    step._what_next = lambda task, notes: ("", 100)
    pick = Pick(step, TaskNotes(tmp_path), rows=_Hub()).choose([{"id": "A"}])
    assert "task" not in pick and pick["shape"] == "not reached" and "not reached" in pick["why"]
    assert pick["skipped"] == []
    why = WhyNot(_Hub(), [{"dataset": "a/open", "shape": "not reached", "said": "the hub was not reached"}])
    assert "a/open" not in why.empty
