# WARP2/warp2/capability/tasks.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/tasks.py
#  Used by   : warp2/work/side/capability.py (CapabilityStep — which task the
#              Eye tries next), warp2/capability/tests.
#  Uses      : warp2/chat_learning/datasets.py (get_json — one web page as
#              JSON); stdlib json, pathlib.
#  Description:
#    Every task models are trained to do, as the Hugging Face hub lists them
#    (image classification, depth estimation, speech recognition, …), each
#    with the datasets the hub recommends for it. Kept on disk, so a machine
#    that cannot reach the hub still knows the list it last saw.
#  User intention (Andrew):
#    2026-09-24: "it should look for anything a model has been trained to do
#    and try to get the eye to do it and take notes on how it does."
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

# Intention: the hub's own list of what models are trained for.
TASKS_URL = "https://huggingface.co/api/tasks"


class ModelTasks:
    """The tasks models are trained for, read from the hub and kept."""

    def __init__(self, state_dir, get=None) -> None:
        """Intention: set where the kept task list lives and keep the hub getter (the real one unless a test
        passes one).
        """
        from warp2.chat_learning import datasets
        self.home = Path(state_dir) / "capability"
        self.kept = self.home / "tasks.json"
        self.get = get or datasets.get_json

    def all(self) -> list:
        """Every task as {id, label, datasets}; the hub's answer when it gives one, else the last kept.

        Intention: READ FRESH, KEPT FOR WHEN IT CANNOT BE. The hub adds tasks
        as models learn new things, so the list is asked for each time; the
        copy is only the answer when the hub cannot be reached.
        """
        found = self.get(TASKS_URL)
        if isinstance(found, dict) and found:
            tasks = [{"id": str(key),
                      "label": str((value or {}).get("label") or key),
                      "summary": str((value or {}).get("summary") or ""),
                      "datasets": [str(d.get("id")) for d in (value or {}).get("datasets") or []
                                   if isinstance(d, dict) and d.get("id")]}
                     for key, value in sorted(found.items())]
            self.home.mkdir(parents=True, exist_ok=True)
            self.kept.write_text(json.dumps(tasks, indent=1), encoding="utf-8")
            return tasks
        try:
            return json.loads(self.kept.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
