# WARP2/warp2/capability/examples.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/examples.py
#  Used by   : warp2/capability/trial.py, warp2/capability/tests.
#  Uses      : warp2/chat_learning/datasets.py (HUB, VIEWER, get_json — the
#              hub's facts about a dataset and its dataset viewer); stdlib
#              json, random, urllib.
#  Description:
#    A task's examples from one hub dataset: rows read from spread-out places
#    in its first readable split (a split is often sorted by answer, so the
#    first page alone can hold one answer only), and what they ask — the
#    column that is the input (a picture or a text) and the column that is
#    the answer (a named class). When a dataset is not shaped as input-and-
#    answer, it says so in words instead.
#    BUILD_LOG (2026-11-04): before reading, the hub is asked about the
#    dataset. A renamed dataset is read under its new name (the hub sends
#    the old name on to it); a gated one is not read, and says it needs a
#    login; when the viewer cannot read one, its own reason is said (most
#    "gated, private or too big" notes were renamed or code-run datasets).
#    The hub's facts (its card) go back with the answer, so a try can make
#    its own pictures for the classes the card names.
#  User intention (Andrew):
#    2026-09-24: "it should look for anything a model has been trained to do
#    and try to get the eye to do it and take notes on how it does."
#    2026-11-04: "how to get around that gate or why it is not making its own
#    dataset from search"; "Let's do all 3".
# ============================================================================
from __future__ import annotations

import json
import random
import time
import urllib.error
import urllib.parse
import urllib.request

# Intention: rows per read from the viewer — the most it gives at once.
PAGE = 100


def _kind(feature: dict) -> str:
    """Intention: a column's type as the viewer names it ("Image", "ClassLabel", "Value", …)."""
    kind = (feature or {}).get("type") or {}
    return str(kind.get("_type") or "") if isinstance(kind, dict) else ""


def viewer_error(url: str, timeout: float = 20.0) -> str:
    """Intention: the hub viewer's own reason a page cannot be had ("" when it gives none, or the page is fine).

    Intention (2026-11-04): get_json says only None for a refused page, so
    every unread dataset was noted "gated, private or too big". Asked on
    this PC's behalf the same night: fashion_mnist and VideoChatGPT were
    renamed, facebook/textvqa runs its own code (not gated at all), and only
    some were really gated.
    """
    from warp2.chat_learning import datasets
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "WARP2/2.0 (compatible; research-agent)"})
        with urllib.request.urlopen(request, timeout=timeout):
            return ""
    except urllib.error.HTTPError as refused:
        try:
            body = datasets.read_whole(refused, time.monotonic() + timeout, 65536)
            return str(json.loads((body or b"{}").decode("utf-8")).get("error") or "")[:300]
        except Exception:
            return ""
    except Exception:
        return ""


class HubRows:
    """Rows of one hub dataset, from spread-out places, with its column types."""

    def __init__(self, get=None, why=None) -> None:
        """Intention: keep the hub JSON getter (the real one unless a test passes its own), the viewer's reason-teller
        (the real one only with the real getter, so a test never reaches the hub), and the hub's addresses.
        """
        from warp2.chat_learning import datasets
        self.get = get or datasets.get_json
        self.why = why or (viewer_error if get is None else (lambda url: ""))
        self.hub = datasets.HUB
        self.viewer = datasets.VIEWER

    def facts(self, dataset: str) -> dict:
        """Intention: what the hub says about a dataset — its current name (a renamed one is sent on to it), whether
        it is gated, its card — or {} when the hub says nothing (gone, private, or not reached)."""
        found = self.get(f"{self.hub}/{urllib.parse.quote(str(dataset), safe='/')}")
        return found if isinstance(found, dict) else {}

    def read(self, dataset: str, wanted: int, seed: int) -> dict:
        """{features, rows, split, dataset, card} of about `wanted` rows, or {"why": …, "dataset", "card"} when it
        cannot be read; "renamed_from" when the hub sent its old name on."""
        card = self.facts(dataset)
        named = str(card.get("id") or dataset)
        said = {"dataset": named, "card": card}
        if named != str(dataset):
            said["renamed_from"] = str(dataset)
        if card.get("gated"):
            return dict(said, why=f"{named}: gated - it needs a Hugging Face login with its terms accepted")
        dataset = named
        splits = self.get(f"{self.viewer}/splits?" + urllib.parse.urlencode({"dataset": dataset})) or {}
        for split in splits.get("splits", []) if isinstance(splits, dict) else []:
            ask = {"dataset": dataset, "config": split["config"], "split": split["split"]}
            first = self.get(f"{self.viewer}/rows?" + urllib.parse.urlencode(dict(ask, offset="0", length=str(PAGE))))
            if not (isinstance(first, dict) and first.get("rows")):
                continue
            total = int(first.get("num_rows_total") or len(first["rows"]))
            rows = [r["row"] for r in first["rows"]]
            rng = random.Random(int(seed))
            # Intention: MORE PAGES FROM SPREAD-OUT PLACES so diverse classes are reached across the split.
            tries = 0
            needed = max(int(wanted), min(total, 200) if total > PAGE else int(wanted))
            while len(rows) < needed and total > PAGE and tries < 5:
                tries += 1
                at = rng.randrange(0, max(1, total - PAGE))
                page = self.get(f"{self.viewer}/rows?" + urllib.parse.urlencode(dict(ask, offset=str(at), length=str(PAGE))))
                if isinstance(page, dict) and page.get("rows"):
                    rows += [r["row"] for r in page["rows"]]
            rng.shuffle(rows)
            return dict(said, features=first.get("features") or [], rows=rows[:int(wanted)],
                        split=f"{split['config']}/{split['split']}", total=total)
        reason = self.why(f"{self.viewer}/splits?" + urllib.parse.urlencode({"dataset": dataset}))
        return dict(said, why=f"{dataset}: the hub's viewer could not read any split ("
                              + (reason or "gated, private or too big") + ")")


def shaped(features: list, rows: list) -> dict:
    """What the rows ask, as {kind, pairs, classes} — or {"why": …} in words.

    Intention: THE ANSWER IS A NAMED CLASS — the one shape the Eye's parts
    already learn. A picture or a text in, a class out. Any other shape is
    said plainly, so the notes show what the Eye cannot take yet, and a
    project can be made for it.
    """
    answer = next((f for f in features if _kind(f) == "ClassLabel"), None)
    if answer is None:
        answer = next((f for f in features if str((f or {}).get("name") or "").lower() in ("label", "labels", "target", "category", "class", "sentiment")
                       and _kind(f) == "Value"), None)
    picture = next((f for f in features if _kind(f) == "Image"), None)
    text = next((f for f in features if _kind(f) == "Value"
                 and str((f.get("type") or {}).get("dtype")) == "string" and f is not answer), None)
    if answer is None:
        kinds = sorted({_kind(f) for f in features if _kind(f)})
        return {"why": f"no column is a named class (columns are {', '.join(kinds) or 'unknown'}) — "
                       "the answer is not a label the Eye's parts can learn yet"}
    source = picture or text
    if source is None:
        kinds = sorted({_kind(f) for f in features if _kind(f)})
        return {"why": f"the input is not a picture or a text (columns are {', '.join(kinds)}) — "
                       "the Eye has no head for it here yet"}
    names = list((answer.get("type") or {}).get("names") or [])
    pairs = []
    for row in rows:
        value, label = row.get(source["name"]), row.get(answer["name"])
        if value in (None, ""):
            continue
        if names:
            if not isinstance(label, int) or not 0 <= label < len(names):
                continue
            lbl_str = str(names[label])
        else:
            lbl_str = str(label)
        pairs.append((value, lbl_str))
    seen = sorted({label for _, label in pairs})
    if len(seen) < 2:
        return {"why": f"only {len(seen)} answer came up in {len(pairs)} rows — nothing to tell apart"}
    return {"kind": "image" if picture is not None else "text", "pairs": pairs, "classes": seen,
            "input": source["name"], "answer": answer["name"]}
