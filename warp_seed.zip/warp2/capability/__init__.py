# WARP2/warp2/capability/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/__init__.py
#  Used by   : Python, to make warp2/capability a package.
#  Uses      : nothing.
#  Description:
#    The Eye taking on what models are trained to do: the list of tasks
#    (tasks.py), a task's examples (examples.py), one try (trial.py), the
#    notes on every try (notes.py), and a project opened when a task needs
#    one (project_maker.py).
#  User intention (Andrew):
#    2026-09-24: "it should look for anything a model has been trained to do
#    and try to get the eye to do it and take notes on how it does" — and
#    "if it needs to make a new project it should do so."
# ============================================================================
