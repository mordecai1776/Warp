# WARP2/warp2/capability/notes.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/capability/notes.py
#  Used by   : warp2/work/side/capability.py, warp2/capability/trial.py,
#              warp2/capability/project_maker.py, warp2/capability/tests.
#  Uses      : stdlib json, pathlib, time.
#  Description:
#    The notes on how the Eye does at each task models are trained for: every
#    try, as a line — which dataset, how many examples, what the Eye got
#    right on examples it had not seen, what guessing would have got, how long
#    it took, and in words what happened. Read back as one summary a task.
#  User intention (Andrew):
#    2026-09-24: "try to get the eye to do it and take notes on how it does."
# ============================================================================
from __future__ import annotations

import json
import time
from pathlib import Path


class TaskNotes:
    """Every try of the Eye at a task, kept a line a try."""

    def __init__(self, state_dir) -> None:
        """Intention: set where the notes file lives, under the state folder's capability folder."""
        self.path = Path(state_dir) / "capability" / "notes.jsonl"

    def add(self, row: dict) -> dict:
        """Intention: one try written down, with when."""
        row = dict(row, when=time.strftime("%Y-%m-%dT%H:%M:%S"))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as out:
            out.write(json.dumps(row) + "\n")
        return row

    def rows(self) -> list:
        """Intention: every try so far, oldest first; no file yet is an empty list. A torn line is said with its number
        (2026-11-07) - one used to make every past try vanish, and the picker then tried everything again."""
        if not self.path.is_file():
            return []
        rows = []
        for number, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except ValueError as exc:
                raise ValueError(f"{self.path} line {number} is not JSON: {exc}") from exc
        return rows

    def of(self, task: str) -> list:
        """Intention: the tries at one task, oldest first."""
        return [row for row in self.rows() if row.get("task") == task]

    def summary(self, task: str) -> dict:
        """How the Eye stands at a task: tries, the best it did over guessing, the last word.

        Intention: "over guessing" is the one number that says the Eye can do
        a thing at all — right on unseen examples minus what always giving
        the commonest answer would get.
        """
        tries = self.of(task)
        if not tries:
            return {"task": task, "tries": 0}
        lifts = [float(t.get("right", 0.0)) - float(t.get("guessing", 0.0)) for t in tries if "right" in t]
        return {"task": task, "tries": len(tries),
                "best_over_guessing": round(max(lifts), 4) if lifts else None,
                "last_over_guessing": round(lifts[-1], 4) if lifts else None,
                "last_examples": int(tries[-1].get("examples") or 0),
                "last_said": str(tries[-1].get("said") or "")}
