# WARP2/warp2/app/window.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/window.py
#  Used by   : warp2/app/main.py.
#  Uses      : qfluentwidgets (FluentWindow, navigation), warp2/app/feed.py,
#              warp2/app/pages/*.py (with pages/improving.py — is it
#              improving), warp2/app/capabilities.py (a tab for each
#              capability), warp2/app/parts/now_view.py (what it is doing now,
#              down the right, on every tab).
#              warp2/app/one_window.py (one window: a newer one replaces it).
#  Description:
#    The one window: a Fluent side menu down the left, every page in the
#    middle, what the warp is doing now always in view down the right, one
#    feed reading the machine for all of them. Every capability has its own
#    tab under Capabilities, and a new one appears when the warp grows one.
#    Each page is told of every new reading and draws it only while showing.
#  User intention (Andrew, 2026-09-25): "remake the gui parts into one window".
#    2026-11-09 (BUILD_LOG 1480): "lets get rid of the eye in use now" - the
#    Eye's in-use panel is no longer carried down the right.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QSize
from qfluentwidgets import FluentIcon, FluentWindow, InfoBar, InfoBarPosition, NavigationItemPosition

from warp2.app.feed import Feed

def pages() -> tuple:
    """Every page, in the order of the side menu — (key, class, icon, name, at the bottom).

    Intention: the classes named by import, not by a string, so what the
    window opens is what the tree can see it opens (the tree-discipline test,
    2026-09-25). Imported here, when the window is made, not when this module
    is read.
    """
    from warp2.app.pages.capabilities import CapabilitiesPage
    from warp2.app.pages.connections import ConnectionsPage
    from warp2.app.pages.structure import StructurePage
    from warp2.app.pages.chat import ChatPage
    from warp2.app.pages.eye_tree import EyeTreePage
    from warp2.app.pages.games import GamesPage
    from warp2.app.pages.improving import ImprovingPage
    from warp2.app.pages.home import HomePage
    from warp2.app.pages.knowledge import KnowledgePage
    from warp2.app.pages.make import MakePage
    from warp2.app.pages.models import ModelsPage
    from warp2.app.pages.pictures import PicturesPage
    from warp2.app.pages.problems import ProblemsPage
    from warp2.app.pages.system import SystemPage
    from warp2.app.pages.webs import WebsPage
    from warp2.app.pages.work import WorkPage
    # Intention (Andrew, 2026-10-02: "clean it up more"): Activity and
    # Projects are gone from the menu — Activity repeated Home's last actions,
    # the capability tabs and the right panel; Projects repeated the holdings
    # tile and the chat's project list (its tile now opens Code structure).
    # Their files are in archive/2026-10-02_gui_clean_up/. The two code pages
    # sit at the bottom, with the developer's tools.
    return (
        ("home", HomePage, FluentIcon.HOME, "Home", False),
        # Intention (Andrew, 2026-10-16): "I want to know if the entire system's
        # improving as a whole" — the answer, second only to Home.
        ("improving", ImprovingPage, getattr(FluentIcon, "SPEED_HIGH", FluentIcon.INFO), "Is it improving?", False),
        ("chat", ChatPage, FluentIcon.CHAT, "Chat", False),
        ("capabilities", CapabilitiesPage, FluentIcon.APPLICATION, "Capabilities", False),
        ("connections", ConnectionsPage, getattr(FluentIcon, "WIFI", FluentIcon.SYNC), "Communications & connections", False),
        ("work", WorkPage, FluentIcon.CHECKBOX, "Work", False),
        ("models", ModelsPage, FluentIcon.ROBOT, "Models", False),
        ("eye_tree", EyeTreePage, FluentIcon.VIEW, "Eye tree", False),
        ("knowledge", KnowledgePage, FluentIcon.IOT, "Knowledge", False),
        ("webs", WebsPage, FluentIcon.TILES, "Webs & tags", False),
        ("make", MakePage, FluentIcon.DEVELOPER_TOOLS, "Make cycle", False),
        ("problems", ProblemsPage, FluentIcon.INFO, "Problems", False),
        ("pictures", PicturesPage, FluentIcon.PHOTO, "Pictures", False),
        ("games", GamesPage, FluentIcon.GAME, "Games", False),
        ("structure", StructurePage, FluentIcon.CODE, "Code structure", True),
        ("system", SystemPage, FluentIcon.APPLICATION, "System map", True),
    )


class WarpWindow(FluentWindow):
    """Everything a person sees of WARP2, in one window."""

    def __init__(self, root, state) -> None:
        """Intention: the feed started and every page made and put in the side menu."""
        super().__init__()
        self.setWindowTitle("WARP2")
        self.resize(QSize(1440, 920))
        self.setMinimumSize(QSize(1000, 680))
        self.feed = Feed(root, state)
        self.pages: dict = {}
        for key, made_by, icon, words, bottom in pages():
            page = made_by(self.feed)
            self.pages[key] = page
            self.addSubInterface(page, icon, words,
                                 NavigationItemPosition.BOTTOM if bottom else NavigationItemPosition.TOP)
            self.feed.snapshot.connect(page.take)
        self.navigationInterface.setExpandWidth(220)
        # Intention: EVERY CAPABILITY ITS OWN TAB, under Capabilities, and a new
        # one added the moment the record shows a new capability (Andrew,
        # 2026-09-25: "make new tabs when it grows a capability").
        from warp2.app.capabilities import Capabilities
        self.capabilities = Capabilities(root, state)
        self.cap_pages: dict = {}
        self._growing = False
        self.feed.snapshot.connect(self._grow)
        # Intention: WHAT IT IS DOING NOW, ALWAYS IN VIEW down the right
        # (Andrew, 2026-09-25: "have the current active thing pop up to the
        # right of the window ... like added on as a new constant view").
        from warp2.app.parts.now_view import NowView
        self.now = NowView(self.feed)
        self.widgetLayout.addWidget(self.now)
        for opener in (self.now, self.pages["capabilities"], self.pages["home"]):
            opener.open_cap = self.open_cap
        for key in ("home", "capabilities", "chat"):
            self.pages[key].open_page = self.open_page
        self.feed.trouble.connect(self._trouble)
        self._troubled = ""
        self._pending_cap = None
        self.reload_requested = False
        # Intention: ONE WINDOW (Andrew: "one launcher, one window"): this
        # window claims it, and a newer window's claim closes this one
        # (warp2/app/one_window.py). Seen 2026-10-24: three windows at once.
        from warp2.app.one_window import OneWindow
        self.one = OneWindow(self.feed.state)
        self.one.claim()
        self.replaced = False
        self._gui_root = self.feed.root
        self._gui_reload_flag = self.feed.state / "locks" / "gui_reload.flag"
        self._gui_snapshot = self._gui_source_snapshot()
        from PySide6.QtCore import QTimer
        self._reload_timer = QTimer(self)
        self._reload_timer.setInterval(2000)
        self._reload_timer.timeout.connect(self._poll_reload)
        self._reload_timer.start()
        self.feed.start()
        self._grow({})

    def _gui_source_snapshot(self) -> tuple:
        """Intention: deterministic mtime/size fingerprint of GUI, seed, and golem source files so code changes trigger a live GUI reload."""
        found = []
        for sub in ("warp2/app", "warp2/seed", "warp2/golem"):
            folder = self._gui_root / sub
            if not folder.is_dir():
                continue
            for path in sorted(folder.rglob("*.py")):
                if "__pycache__" in path.parts or "tests" in path.parts:
                    continue
                try:
                    stat = path.stat()
                except OSError:
                    continue
                found.append((path.relative_to(self._gui_root).as_posix(), stat.st_mtime_ns, stat.st_size))
        return tuple(found)

    def _check_gui_reload(self) -> bool:
        """Intention: detect whether GUI source files changed on disk or a GUI reload flag was raised."""
        if self._gui_reload_flag.exists():
            try:
                self._gui_reload_flag.unlink(missing_ok=True)
            except OSError:
                pass
            return True
        current = self._gui_source_snapshot()
        if self._gui_snapshot and current and current != self._gui_snapshot:
            return True
        return False

    def _poll_reload(self) -> None:
        """Intention: every 2 seconds, close if a newer window has claimed the one window; else check for GUI code edits or gui_reload.flag and trigger an in-place window rebuild."""
        if not self.reload_requested and not self.replaced and self.one.replaced():
            self.replaced = True
            self._reload_timer.stop()
            self.close()
            return
        if self.reload_requested or not self._check_gui_reload():
            return
        self.reload_requested = True
        self._reload_timer.stop()
        self.close()

    def _grow(self, _snapshot: dict) -> None:
        """Intention: read capabilities off the window's thread and add a tab for each new one."""
        self._poll_reload()
        if self.reload_requested or self._growing:
            return
        self._growing = True
        from warp2.app.parts.worker import later
        later(self.capabilities.all, self._add_caps, lambda _w: setattr(self, "_growing", False))

    def _add_caps(self, caps: list) -> None:
        """Intention: a tab for each new capability, under Capabilities, with its kind's icon."""
        from warp2.app.pages.capability import CapabilityPage
        self._growing = False
        icons = {"step": FluentIcon.SYNC, "phase": FluentIcon.CALENDAR, "work": FluentIcon.CHECKBOX,
                 "running": FluentIcon.SETTING, "project": FluentIcon.CODE, "golem": FluentIcon.ROBOT}
        for cap in caps:
            if cap["key"] in self.cap_pages:
                continue
            page = CapabilityPage(self.feed, cap)
            self.cap_pages[cap["key"]] = page
            self.addSubInterface(page, icons.get(cap["kind"], FluentIcon.APPLICATION), cap["name"],
                                 NavigationItemPosition.TOP, parent=self.pages["capabilities"])
            self.feed.snapshot.connect(page.take)
            page.take(self.feed.last)
        if self._pending_cap in self.cap_pages:
            key, self._pending_cap = self._pending_cap, None
            self.switchTo(self.cap_pages[key])

    def open_cap(self, key: str) -> None:
        """Intention: a capability's own tab brought to the front."""
        page = self.cap_pages.get(key)
        if page is not None:
            self._pending_cap = None
            self.switchTo(page)
        else:
            self._pending_cap = key
            self._grow({})

    def open_page(self, key: str) -> None:
        """Intention: a holding opens its existing page in the one window."""
        if key in self.pages:
            self.switchTo(self.pages[key])

    def _trouble(self, words: str) -> None:
        """Intention: a reading that failed said once, in a note that fades — never a frozen window."""
        if words == self._troubled:
            return
        self._troubled = words
        InfoBar.warning("Could not read the machine", words[:300], duration=6000,
                        position=InfoBarPosition.TOP_RIGHT, parent=self)

    def closeEvent(self, event) -> None:
        """Intention: a Nexus point window cannot be closed unless the user explicitly asks for it (or it is hot-reloading in place, or a newer window replaced it)."""
        import os
        import time
        closed_mark = self.feed.state / "locks" / ".." / "control" / "window.closed_by_user"
        if not self.reload_requested and not getattr(self, "replaced", False) and "PYTEST_CURRENT_TEST" not in os.environ and not closed_mark.exists():
            from PySide6.QtWidgets import QMessageBox
            ans = QMessageBox.question(
                self,
                "Nexus Point — Keep Window Open?",
                "This window is an active Nexus point handle for communications and oversight.\n\n"
                "Did you explicitly want to close the Nexus window?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if ans != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            try:
                closed_mark.parent.mkdir(parents=True, exist_ok=True)
                closed_mark.write_text(f"closed by user at {time.strftime('%Y-%m-%d %H:%M:%S')}\n", encoding="utf-8")
            except OSError:
                pass
        for page in self.pages.values():
            if hasattr(page, "close_page"):
                page.close_page()
        self.feed.close()
        super().closeEvent(event)
