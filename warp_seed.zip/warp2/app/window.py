# WARP3/warp2/app/window.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/app/window.py
#  Used by   : warp2/app/main.py.
#  Uses      : qfluentwidgets (FluentWindow, navigation), warp2/app/feed.py,
#              warp2/app/lean/parts.py (every page, made only when shown),
#              warp2/app/lean/slot.py (a page's place in the menu, holding it
#              only while shown), warp2/app/capabilities.py (a tab for each
#              capability), warp2/app/parts/now_view.py (what it is doing now,
#              down the right, on every tab), warp2/app/parts/worker.py,
#              warp2/app/one_window.py (one window: a newer one replaces it).
#  Description:
#    The one window: a Fluent side menu down the left with every page, the
#    page in the middle, what the warp is doing now always in view down the
#    right, one feed reading the machine for all of them. Every capability
#    has its own tab under Capabilities, and a new one appears when the warp
#    grows one.
#    LEAN (BUILD_LOG 1642c): every page and every capability's tab is in the
#    menu from the start, but each is only a small empty slot until it is
#    shown; the page is made when its tab is shown and let go when another is
#    - so the window holds one page at a time, not all of them (it made every
#    page at start: 2,210 widgets on a scratch workspace, 7.4 GB private on
#    the real one, 2026-11-09).
#  User intention (Andrew, 2026-09-25): "remake the gui parts into one window".
#    2026-11-09 (BUILD_LOG 1480): "lets get rid of the eye in use now" - the
#    Eye's in-use panel is no longer carried down the right.
#    2026-11-14 12:41: "change it to be leaner and use less resources ... have
#    it be able open up all the parts that it has in it and that way we get
#    the best of both worlds"; 13:23, of the bare window of 1640c: "the
#    windows dont work it needs more info in it and it needs to look a lot
#    better" - the one window back, lean inside.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QSize
from qfluentwidgets import FluentIcon, FluentWindow, InfoBar, InfoBarPosition, NavigationItemPosition

from warp2.app.feed import Feed
from warp2.app.lean.parts import PARTS, capability
from warp2.app.lean.slot import PageSlot


def icon(name: str):
    """Intention: a Fluent icon by its name; the application icon when this version of the library has no such one."""
    return getattr(FluentIcon, name, FluentIcon.APPLICATION)


class WarpWindow(FluentWindow):
    """Everything a person sees of WARP3, in one window - each page made only while it is shown."""

    def __init__(self, root, state) -> None:
        """Intention: the feed started, every page's slot put in the side menu, the first page shown."""
        super().__init__()
        self.setWindowTitle("WARP3")
        self.resize(QSize(1440, 920))
        self.setMinimumSize(QSize(1000, 680))
        self.feed = Feed(root, state)
        self.pages: dict = {}
        for key, words, _holds, icon_name, bottom, maker in PARTS:
            slot = PageSlot(key, maker, self.feed, self.openers())
            self.pages[key] = slot
            self.addSubInterface(slot, icon(icon_name), words,
                                 NavigationItemPosition.BOTTOM if bottom else NavigationItemPosition.TOP)
        self.navigationInterface.setExpandWidth(220)
        # Intention: EVERY CAPABILITY ITS OWN TAB, under Capabilities, and a new
        # one added the moment the record shows a new capability (Andrew,
        # 2026-09-25: "make new tabs when it grows a capability") - each a slot too.
        from warp2.app.capabilities import Capabilities
        self.capabilities = Capabilities(root, state)
        self.cap_pages: dict = {}
        self._growing = False
        self.feed.snapshot.connect(self._grow)
        # Intention: WHAT IT IS DOING NOW, ALWAYS IN VIEW down the right
        # (Andrew, 2026-09-25: "have the current active thing pop up to the
        # right of the window ... like added on as a new constant view").
        from warp2.app.parts.now_view import NowView
        self.now = NowView(self.feed)
        self.widgetLayout.addWidget(self.now)
        self.now.open_cap = self.open_cap
        self.feed.trouble.connect(self._trouble)
        self._troubled = ""
        self._pending_cap = None
        self.reload_requested = False
        self.stackedWidget.currentChanged.connect(lambda _index: self._shown())
        # Intention: ONE WINDOW (Andrew: "one launcher, one window"): this
        # window claims it, and a newer window's claim closes this one
        # (warp2/app/one_window.py). Seen 2026-10-24: three windows at once.
        from warp2.app.one_window import OneWindow
        self.one = OneWindow(self.feed.state)
        self.one.claim()
        self.replaced = False
        self._gui_root = self.feed.root
        self._gui_reload_flag = self.feed.state / "locks" / "gui_reload.flag"
        self._gui_snapshot = self._gui_source_snapshot()
        self._checking_reload = False
        self._last_source_scan = 0.0
        from PySide6.QtCore import QTimer
        self._reload_timer = QTimer(self)
        self._reload_timer.setInterval(2000)
        self._reload_timer.timeout.connect(self._poll_reload)
        self._reload_timer.start()
        self.feed.start()
        self._shown()
        self._grow({})

    def openers(self) -> dict:
        """Intention: {name a page uses: what it does here} - a page that opens another page or a capability's tab."""
        return {"open_page": self.open_page, "open_cap": self.open_cap}

    def slots(self) -> list:
        """Intention: every page's and every capability's slot."""
        return list(self.pages.values()) + list(self.cap_pages.values())

    def _shown(self) -> None:
        """Intention: the page now shown is made (if it is not); every other page is let go - one page held at a
        time."""
        current = self.stackedWidget.currentWidget()
        for slot in self.slots():
            if slot is current:
                slot.fill()
            else:
                slot.empty()

    def page(self, key: str):
        """Intention: the page made in a slot now, or None - for a caller that needs the page itself."""
        slot = self.pages.get(key) or self.cap_pages.get(key)
        return slot.page if slot is not None else None

    def _gui_source_snapshot(self) -> tuple:
        """Intention: deterministic mtime/size fingerprint of GUI, seed, and golem source files so code changes
        trigger a live GUI reload."""
        found = []
        for sub in ("warp2/app", "warp2/seed", "warp2/golem"):
            folder = self._gui_root / sub
            if not folder.is_dir():
                continue
            for path in sorted(folder.rglob("*.py")):
                if "__pycache__" in path.parts or "tests" in path.parts:
                    continue
                try:
                    stat = path.stat()
                except OSError:  # fault: ok a file that went between the listing and the look is not in the print
                    continue
                found.append((path.relative_to(self._gui_root).as_posix(), stat.st_mtime_ns, stat.st_size))
        return tuple(found)

    def _check_gui_reload(self) -> bool:
        """Intention: detect whether GUI source files changed on disk or a GUI reload flag was raised."""
        if self._gui_reload_flag.exists():
            try:
                self._gui_reload_flag.unlink(missing_ok=True)
            except OSError as exc:
                self._trouble(f"the reload flag could not be taken down: {exc}")
            return True
        current = self._gui_source_snapshot()
        return bool(self._gui_snapshot and current and current != self._gui_snapshot)

    def _on_gui_snapshot(self, current: tuple) -> None:
        """Intention: finish an off-thread source scan and trigger reload only if GUI source files changed."""
        self._checking_reload = False
        if not self.reload_requested and self._gui_snapshot and current and current != self._gui_snapshot:
            self.reload_requested = True
            self._reload_timer.stop()
            self.close()

    def _poll_reload(self) -> None:
        """Intention: every 2 seconds, close if a newer window claimed the one window or gui_reload.flag was raised;
        scan source mtimes off the UI thread at most once every 10 seconds so the window never stutters."""
        import time
        if not self.reload_requested and not self.replaced and self.one.replaced():
            self.replaced = True
            self._reload_timer.stop()
            self.close()
            return
        if self.reload_requested:
            return
        if self._gui_reload_flag.exists():
            try:
                self._gui_reload_flag.unlink(missing_ok=True)
            except OSError as exc:
                self._trouble(f"the reload flag could not be taken down: {exc}")
            self.reload_requested = True
            self._reload_timer.stop()
            self.close()
            return
        now = time.monotonic()
        if not self._checking_reload and (now - self._last_source_scan) >= 10.0:
            self._checking_reload = True
            self._last_source_scan = now
            from warp2.app.parts.worker import later
            later(self._gui_source_snapshot, self._on_gui_snapshot,
                  lambda _w: setattr(self, "_checking_reload", False))

    def _grow(self, _snapshot: dict) -> None:
        """Intention: read capabilities off the window's thread and add a tab for each new one."""
        self._poll_reload()
        if self.reload_requested or self._growing:
            return
        self._growing = True
        from warp2.app.parts.worker import later
        later(self.capabilities.all, self._add_caps, lambda _w: setattr(self, "_growing", False))

    def _add_caps(self, caps: list) -> None:
        """Intention: a tab for each new capability, under Capabilities, with its kind's icon - a slot, made when
        shown."""
        self._growing = False
        icons = {"step": FluentIcon.SYNC, "phase": FluentIcon.CALENDAR, "work": FluentIcon.CHECKBOX,
                 "running": FluentIcon.SETTING, "project": FluentIcon.CODE, "golem": FluentIcon.ROBOT}
        for cap in caps:
            if cap["key"] in self.cap_pages:
                continue
            slot = PageSlot(f"cap:{cap['key']}", capability(cap), self.feed, self.openers())
            self.cap_pages[cap["key"]] = slot
            self.addSubInterface(slot, icons.get(cap["kind"], FluentIcon.APPLICATION), cap["name"],
                                 NavigationItemPosition.TOP, parent=self.pages["capabilities"])
        if self._pending_cap in self.cap_pages:
            key, self._pending_cap = self._pending_cap, None
            self.switchTo(self.cap_pages[key])

    def open_cap(self, key: str) -> None:
        """Intention: a capability's own tab brought to the front."""
        slot = self.cap_pages.get(key)
        if slot is not None:
            self._pending_cap = None
            self.switchTo(slot)
        else:
            self._pending_cap = key
            self._grow({})

    def open_page(self, key: str) -> None:
        """Intention: a holding opens its page in the one window."""
        if key in self.pages:
            self.switchTo(self.pages[key])

    def _trouble(self, words: str) -> None:
        """Intention: a reading that failed said once, in a note that fades — never a frozen window."""
        if words == self._troubled:
            return
        self._troubled = words
        InfoBar.warning("Could not read the machine", words, duration=6000,
                        position=InfoBarPosition.TOP_RIGHT, parent=self)

    def closeEvent(self, event) -> None:
        """Intention: a Nexus point window cannot be closed unless the user explicitly asks for it (or it is
        hot-reloading in place, or a newer window replaced it)."""
        import os
        import time
        closed_mark = self.feed.state / "control" / "window.closed_by_user"
        if not self.reload_requested and not getattr(self, "replaced", False) \
                and "PYTEST_CURRENT_TEST" not in os.environ and not closed_mark.exists():
            from PySide6.QtWidgets import QMessageBox
            ans = QMessageBox.question(
                self,
                "Nexus Point — Keep Window Open?",
                "This window is an active Nexus point handle for communications and oversight.\n\n"
                "Did you explicitly want to close the Nexus window?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if ans != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            try:
                closed_mark.parent.mkdir(parents=True, exist_ok=True)
                closed_mark.write_text(f"closed by user at {time.strftime('%Y-%m-%d %H:%M:%S')}\n", encoding="utf-8")
            except OSError as exc:
                self._trouble(f"could not note that the window was closed: {exc}")
        for slot in self.slots():
            slot.empty()
        self.feed.close()
        super().closeEvent(event)
