# WARP2/warp2/app/feed.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/feed.py
#  Used by   : warp2/app/window.py (one feed for the whole window).
#  Uses      : PySide6.QtCore (QObject, QThread, Signal), warp2/ui/snapshot.py
#              (ObserverSnapshot — the same read-only gather the old cockpit
#              used), warp2/ask/doing.py (what the warp is on now),
#              warp2/record/stop.py (Halt), warp2/record/processes.py (is the runner up),
#              warp2/control/inside.py (what the window holds, when asked),
#              warp2/control/overdue.py (step_in_flight - the main runner's step now),
#              warp2/work/memory_gate.py (floor_bytes - the memory the runner waits for).
#  Description:
#    What the window knows about the machine, read away from the window so
#    it never freezes: a full reading (the snapshot) and a quick one (stopped
#    or running, and what it is doing). The full reading is taken again after
#    a pause that grows with how long it took — a slow store is read less
#    often — and every reading keeps a short history, so the charts show how
#    things moved, not only where they are.
#    2026-11-08 (BUILD_LOG 1455): the quick reading also carries the main
#    runner's step in flight (the journals only get a line when a step ends,
#    so a two-hour step was never shown) and the memory floor the runner
#    really waits on; each part is read on its own, so one that fails says
#    "can't tell" instead of "not running" or freezing the rest.
#    2026-11-09 (BUILD_LOG 1479): the floor is read paced by its own cost
#    (parts/paced.py) - it walks every process on the machine.
#  User intention (Andrew): "a check to make sure it is still running", runs
#    "show visual cues", and the old lesson: a window that reads on a fast
#    timer freezes the thing it is watching.
# ============================================================================
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QObject, QThread, QTimer, Signal
from warp2.record.swallowed import noted

# Intention: the shortest pause between full readings, and how many times its
# own cost it waits — a reading that took one second is next taken after four.
LEAST_PAUSE = 2.0
COST_TIMES = 4.0


class Reader(QThread):
    """Reads the machine, again and again, off the window's thread."""

    # Intention (2026-10-02, measured): THE READING IS PASSED, NOT COPIED.
    # Declared as dict, Qt handed every connected page its own converted copy,
    # and each page keeps its newest until it is shown — thirteen copies of
    # an 18,629-edge reading, most of the window's 3.5 GB. As object, every
    # page holds the same one; no page writes into it.
    gathered = Signal(object)
    quick = Signal(dict)
    failed = Signal(str)

    def __init__(self, root, state) -> None:
        """Intention: where to read; nothing is opened until the thread runs."""
        super().__init__()
        self.root, self.state = Path(root), Path(state)
        self.running = True
        self.asked = False

    def ask_now(self) -> None:
        """Intention: the next full reading is taken at once (a page wants it)."""
        self.asked = True

    def _quick(self) -> dict:
        """Stopped or not, and what it is on - cheap, read every second.

        Intention (2026-11-08, BUILD_LOG 1455): every part read on its own. A part that cannot be read is None or
        {} - "can't tell" - never a guess: a failed process read used to say "not running" and offer Start beside
        a live runner, and a failed health read froze every other reading with it.
        """
        stopped, why = None, ""
        try:
            from warp2.record.stop import Halt
            halt = Halt(self.state)
            stopped = halt.raised()
            why = str(halt.record().get("reason", "")) if stopped else ""
        except Exception as exc:
            noted("warp2/app/feed.py:Reader._quick:stop", exc)
        try:
            from warp2.ask.doing import Doing
            doing = Doing(self.state).says()
        except Exception:
            doing = "Warp: cannot tell just now"
        try:
            from warp2.record.processes import Processes
            running = any(p.get("role") == "run" and p.get("state") == "running" for p in Processes().snapshot())
        except Exception as exc:
            noted("warp2/app/feed.py:Reader._quick:processes", exc)
            running = None
        return {"stopped": stopped, "why": why, "running": running, "doing": doing, "at": time.time(),
                "health": self._part("health", self._health), "step": self._part("step", self._step),
                "floor_mb": self._part("floor", self._floor_mb)}

    def _part(self, name: str, read):
        """Intention: one part of the quick reading; what could not be read is noted and left empty."""
        try:
            return read()
        except Exception as exc:
            noted(f"warp2/app/feed.py:Reader._quick:{name}", exc)
            return None

    def _health(self) -> dict:
        """Intention: the runner's beat, memory and restarts (warp2/progress/health.py)."""
        from warp2.progress.health import Health
        return Health(self.state).read()

    def _step(self) -> dict:
        """Intention: the main runner's step in flight, how long it has run and its usual time (warp2/control/overdue.py)."""
        from warp2.control.overdue import step_in_flight
        return step_in_flight(self.state)

    def _floor_mb(self):
        """The free memory the runner waits for, as it measures it (warp2/work/memory_gate.py), paced by its own cost.

        Intention (BUILD_LOG 1479, measured 2026-11-09 14:35 with py-spy): reading the floor walks every process on
        the machine, and it was a quarter of the window's busy time when read every second. It is read again only
        after its own cost times COST_TIMES (parts/paced.py); between, the last reading stands.
        """
        from warp2.app.parts.paced import Paced
        pace = self.__dict__.setdefault("floor_pace", Paced())
        if pace.due():
            from warp2.work.memory_gate import floor_bytes
            with pace.reading():
                self.floor_last = round(floor_bytes() / 2 ** 20)
        return self.__dict__.get("floor_last")

    def run(self) -> None:
        """Intention: full readings with a cost-based pause; live readings run independently."""
        from warp2.ui.snapshot import ObserverSnapshot
        while self.running:
            began = time.monotonic()
            try:
                self.gathered.emit(ObserverSnapshot(self.root, self.state).gather())
            except Exception as exc:
                self.failed.emit(f"{type(exc).__name__}: {exc}")
            cost = time.monotonic() - began
            until = time.monotonic() + max(LEAST_PAUSE, COST_TIMES * cost)
            self.asked = False
            while self.running and not self.asked and time.monotonic() < until:
                self.msleep(100)
                self._memory_if_asked()

    def _memory_if_asked(self) -> None:
        """Intention (2026-10-02): what the window holds, when asked (warp2/control/inside.py) — measured that day at 21.5 GB two minutes after it opened. Looked at once a second."""
        now = int(time.monotonic())
        if now == getattr(self, "_looked_at", None):
            return
        self._looked_at = now
        try:
            from warp2.control.inside import answer_memory
            answer_memory(self.state, "window")
        except Exception as exc:
            noted("warp2/app/feed.py:Reader._memory_if_asked", exc)

    def stop(self) -> None:
        """Intention: the thread ends at its next look."""
        self.running = False


class History:
    """A short record of numbers over time, for the charts."""

    def __init__(self) -> None:
        """Intention: one list of (time, value) per name."""
        self.series: dict = {}

    def add(self, name: str, value, at: float | None = None) -> None:
        """Intention: one reading kept; older ones fade out as the list outgrows what a chart shows well."""
        if value is None:
            return
        row = self.series.setdefault(name, [])
        row.append((at if at is not None else time.time(), float(value)))
        # Intention: a chart a person reads at a glance shows a few hundred
        # points; past that the oldest half is thinned, not cut — every other
        # old point kept, so the long view stays and the recent stays sharp.
        if len(row) > 600:
            old, new = row[:300], row[300:]
            self.series[name] = old[::2] + new

    def of(self, name: str) -> tuple:
        """Intention: (times, values) for one name, empty when there is none."""
        row = self.series.get(name, [])
        return [t for t, _ in row], [v for _, v in row]


class Feed(QObject):
    """The one feed the whole window reads from."""

    snapshot = Signal(object)
    standing = Signal(dict)
    trouble = Signal(str)

    def __init__(self, root, state) -> None:
        """Intention: the reader started, its readings kept and passed on."""
        super().__init__()
        self.root, self.state = Path(root), Path(state)
        self.last: dict = {}
        self.stand: dict = {}
        self.history = History()
        self.cache_file = self.state / "ui" / "last_snapshot.json"
        if self.cache_file.is_file():
            try:
                import json
                self.last = json.loads(self.cache_file.read_text(encoding="utf-8"))
                # Intention (BUILD_LOG 1455): a reading from the last session is said to be one, and its health is
                # not shown as today's.
                self.last["cached"] = True
                (self.last.get("progress") or {}).pop("health", None)
            except Exception:
                self.last = {}
        self.reader = Reader(self.root, self.state)
        self.reader.gathered.connect(self._gathered)
        self.reader.quick.connect(self._quick)
        self.reader.failed.connect(self.trouble.emit)
        self._checking = False
        self.quick_timer = QTimer(self)
        self.quick_timer.setInterval(1000)
        self.quick_timer.timeout.connect(self._check)

    def _check(self) -> None:
        """Intention: live activity keeps refreshing even during a slow full snapshot."""
        if self._checking:
            return
        from warp2.app.parts.worker import later
        self._checking = True

        def received(stand):
            """Intention: the quick reading came back — allow the next check and pass the reading on."""
            self._checking = False
            self._quick(stand)

        def failed(words):
            """Intention: the quick reading failed — allow the next check and report the words as trouble."""
            self._checking = False
            self.trouble.emit(words)
        later(self.reader._quick, received, failed)

    def start(self) -> None:
        """Intention: reading begins; emit cached snapshot immediately so GUI is populated on first frame."""
        if self.last:
            QTimer.singleShot(0, lambda: self.snapshot.emit(self.last))
        self.reader.start()
        self.quick_timer.start()
        self._check()

    def close(self) -> None:
        """Intention: reading stops and the thread is waited for."""
        self.quick_timer.stop()
        self.reader.stop()
        self.reader.wait(5000)

    def _gathered(self, snap: dict) -> None:
        """Intention: a full reading kept, its numbers added to the history, saved to cache, and passed on."""
        self.last = snap
        ledger = snap.get("ledger") or {}
        kg = snap.get("kg") or {}
        self.history.add("facts", kg.get("total_facts"))
        self.history.add("done", ledger.get("done"))
        self.history.add("open", ledger.get("open"))
        self.history.add("sunk", ledger.get("sunk"))
        try:
            from warp2.util import atomic_write_bytes
            import json
            atomic_write_bytes(self.cache_file, json.dumps(snap).encode("utf-8"))
        except Exception as exc:
            noted("warp2/app/feed.py:Feed._gathered", exc)
        self.snapshot.emit(snap)

    def _quick(self, stand: dict) -> None:
        """Intention: the quick reading kept and passed on."""
        self.stand = stand
        self.standing.emit(stand)
