# WARP2/warp2/app/main.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/main.py
#  Used by   : warp2/app/__main__.py, warp2/run.py (`cockpit`, `ask`), WARP2.bat.
#  Uses      : PySide6 (QApplication), warp2/app/theme.py, warp2/app/window.py,
#              warp2/control/inside.py (what the window holds, when asked),
#              warp2/room/own_fence.py (the window's own fence, BUILD_LOG 1485).
#  Description:
#    Starts the one window: sharp on high-resolution screens, the dark Fluent
#    theme, Windows 11's Mica backdrop where it is there, and the window.
#  User intention (Andrew): one launcher, one window.
#    2026-11-09 17:45: "adapt this to the gui" - the window is fenced to its
#    own room, moved every two seconds (BUILD_LOG 1485).
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path

from warp2.record.swallowed import noted


def _purge_gui_modules() -> None:
    """Intention: reload GUI and its progress readers together, so new cards cannot keep old health data."""
    import importlib
    importlib.invalidate_caches()
    for mod_name in list(sys.modules):
        if mod_name == "warp2.app.main":
            continue
        if mod_name.startswith(("warp2.app.", "warp2.seed", "warp2.golem", "warp2.progress")) or mod_name == "warp2.app":
            sys.modules.pop(mod_name, None)


def launch(root=".", state=None) -> int:
    """Intention: the window shown until a person closes it; automatically reloads itself in place within 2 seconds whenever GUI source files change."""
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("WARP2")
    root_path = Path(root).resolve()
    state_path = Path(state) if state else root_path / "state"
    _report_memory_when_asked(state_path)
    saved_geom = None
    while True:
        from warp2.app import theme
        theme.apply()
        from warp2.app.window import WarpWindow
        window = WarpWindow(root_path, state_path)
        if saved_geom is not None:
            window.setGeometry(saved_geom)
        window.show()
        code = app.exec()
        if not getattr(window, "reload_requested", False):
            return code
        saved_geom = window.geometry()
        window.deleteLater()
        _purge_gui_modules()


def _own_fence():
    """Intention (Andrew, 2026-11-09 17:45: "adapt this to the gui"; BUILD_LOG 1485): the window fenced to what it
    holds plus the room there is (warp2/room/own_fence.py) - measured 2026-10-02 at 28.9 GB and 2026-11-09 at 9 GB
    peak on a 16 GB machine; None when the fence cannot be made, and the window runs as before."""
    try:
        from warp2.room.own_fence import OwnFence
        return OwnFence()
    except Exception as exc:
        noted("warp2/app/main.py:_own_fence", exc)
        return None


def _report_memory_when_asked(state) -> None:
    """Intention (2026-10-02): the window says what it holds when asked (warp2/control/inside.py), from its own small thread — measured that day at 28.9 GB eighty seconds after it opened, while its feed was busy and could not answer."""
    import threading
    import time as _time

    def looking():
        """Intention: the thread's loop — answer any memory question every 2 seconds; a failed answer is skipped.
        (BUILD_LOG 1485) On the same beat the window's own fence is moved to the room there is now."""
        from warp2.control.inside import answer_memory
        fenced = _own_fence()
        while True:
            try:
                answer_memory(state, "window")
                if fenced is not None:
                    fenced.again()
            except Exception as exc:
                noted("warp2/app/main.py:_report_memory_when_asked.looking", exc)
            _time.sleep(2.0)

    threading.Thread(target=looking, name="window-memory", daemon=True).start()

