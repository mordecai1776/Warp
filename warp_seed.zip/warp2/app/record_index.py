# WARP2/warp2/app/record_index.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/record_index.py
#  Used by   : warp2/app/capabilities.py (which capabilities have ever run,
#              and their whole record).
#  Uses      : stdlib json, pathlib, threading.
#  Description:
#    Each verb's whole record across the warp's journals — how many runs, how
#    many ended well, how many errors, when it last ended well and when it last
#    ran. Each journal is read once, then only what has been added since, so
#    the window can ask every time without reading 47 MB each time.
#  User intention (Andrew, 2026-10-02): "make sure the gui does not show
#    things it does not do". (Measured that day: the capability tabs counted
#    only each journal's last 2,000 lines, so a step that ran yesterday read
#    "never · 0 runs", and steps that never once succeeded had tabs.)
# ============================================================================
"""Every verb's whole record, read incrementally."""
from __future__ import annotations

import json
import threading
from pathlib import Path

# Intention: the outcomes that mean a step did what it is for — the same
# words the journals write when an action ends well.
ENDED_WELL = ("ok", "noted", "opened", "sealed")

_LOCK = threading.Lock()
_READ: dict = {}


def _blank() -> dict:
    """Intention: an empty count row (runs, ok, errors, last times) for a verb seen for the first time."""
    return {"runs": 0, "ok": 0, "errors": 0, "last_ok": "", "last": ""}


def _take(verbs: dict, entry: dict) -> None:
    """Intention: one journal entry added to its verb's record."""
    verb = str(entry.get("verb") or "")
    if not verb:
        return
    row = verbs.setdefault(verb, _blank())
    when = str(entry.get("ts") or "")
    outcome = str(entry.get("outcome") or "")
    row["runs"] += 1
    row["last"] = max(row["last"], when)
    if outcome in ENDED_WELL:
        row["ok"] += 1
        row["last_ok"] = max(row["last_ok"], when)
    elif outcome == "error":
        row["errors"] += 1


def _read_on(path: Path) -> dict:
    """Intention: one journal's verbs, reading only the whole lines added since the last look."""
    key = str(path)
    seen = _READ.setdefault(key, {"offset": 0, "verbs": {}})
    try:
        size = path.stat().st_size
    except OSError:
        return seen["verbs"]
    if size < seen["offset"]:
        seen.update(offset=0, verbs={})
    if size == seen["offset"]:
        return seen["verbs"]
    with path.open("rb") as stream:
        stream.seek(seen["offset"])
        added = stream.read(size - seen["offset"])
    end = added.rfind(b"\n")
    if end < 0:
        return seen["verbs"]
    for line in added[:end].split(b"\n"):
        try:
            entry = json.loads(line)
        except ValueError:
            continue
        if isinstance(entry, dict):
            _take(seen["verbs"], entry)
    seen["offset"] += end + 1
    return seen["verbs"]


def record_of(state, journals) -> dict:
    """Every verb's record over the named journals: {verb: {runs, ok, errors, last_ok, last}}."""
    out: dict = {}
    with _LOCK:
        for name in journals:
            path = Path(state) / "journals" / name
            if not path.is_file():
                continue
            for verb, row in _read_on(path).items():
                into = out.setdefault(verb, _blank())
                into["runs"] += row["runs"]
                into["ok"] += row["ok"]
                into["errors"] += row["errors"]
                into["last_ok"] = max(into["last_ok"], row["last_ok"])
                into["last"] = max(into["last"], row["last"])
    return out


def over(record: dict, verbs) -> dict:
    """Intention: a capability's record — its verbs' records added together."""
    out = _blank()
    for verb in verbs:
        row = record.get(verb)
        if not row:
            continue
        out["runs"] += row["runs"]
        out["ok"] += row["ok"]
        out["errors"] += row["errors"]
        out["last_ok"] = max(out["last_ok"], row["last_ok"])
        out["last"] = max(out["last"], row["last"])
    return out
