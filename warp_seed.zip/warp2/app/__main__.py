# WARP2/warp2/app/__main__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/__main__.py
#  Used by   : `python -m warp2.app [root] [state]` (WARP2.bat).
#  Uses      : warp2/app/main.py (launch).
#  Description:
#    Opens the one window.
#  User intention (Andrew): one launcher, one window.
# ============================================================================
from __future__ import annotations

import sys

from warp2.app.main import launch

if __name__ == "__main__":
    args = sys.argv[1:]
    sys.exit(launch(args[0] if args else ".", args[1] if len(args) > 1 else None))
