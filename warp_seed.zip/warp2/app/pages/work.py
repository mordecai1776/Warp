# WARP2/warp2/app/pages/work.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/work.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/app/parts/{page,cards,table}.py, warp2/app/theme.py.
#  Description:
#    The work queue: how much is done, open and set down, and the open units
#    in the order the queue would take them, with their kind and rank.
#  User intention (Andrew): the old Work Queue tab, in the one window.
# ============================================================================
from __future__ import annotations

from warp2.app import theme
from warp2.app.parts.cards import Panel, ShareBar, StatCard
from warp2.app.parts.page import Page, row
from warp2.app.parts.table import Table


class WorkPage(Page):
    """The work queue."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the three counts, the share bar and the open units."""
        super().__init__("work", "Work", "What is waiting, in the order it will be taken.", parent)
        self.done = StatCard("Done", colour=theme.GOOD)
        self.open = StatCard("Open", colour=theme.ACCENT)
        self.sunk = StatCard("Set down", colour=theme.WARN)
        self.body.addLayout(row(self.done, self.open, self.sunk))
        self.share = ShareBar()
        self.body.addWidget(self.share)
        panel = Panel("Open units")
        self.table = Table(["Unit", "Kind", "Target", "Rank"], stretch=2)
        self.table.setMinimumHeight(460)
        panel.add(self.table)
        self.body.addWidget(panel)

    def draw(self, snap: dict) -> None:
        """Intention: the counts and the open units from one reading."""
        ledger = snap.get("ledger") or {}
        self.done.set(f"{ledger.get('done', 0):,}")
        self.open.set(f"{ledger.get('open', 0):,}")
        self.sunk.set(f"{ledger.get('sunk', 0):,}")
        self.share.set([(ledger.get("done", 0), theme.GOOD), (ledger.get("open", 0), theme.ACCENT),
                        (ledger.get("sunk", 0), theme.WARN)])
        items = snap.get("open_items") or []
        self.table.fill([(i.get("item"), i.get("kind"), i.get("target"), f"{float(i.get('rank') or 0):.3f}")
                         for i in items])
