# WARP2/warp2/app/pages/connections.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/connections.py
#  Used by   : warp2/app/window.py (the Communications & connections tab).
#  Uses      : warp2/seed/bloom.py (probe_hardware, fit_hardware,
#              recommend_for_device, record_bloom, spawn_instance),
#              warp2/golem/surface.py (SurfaceGolem),
#              warp2/app/parts/{page,cards,table,worker}.py,
#              PySide6, qfluentwidgets.
#  Description:
#    The Communications & Connections page in the one window:
#      1. Seed Hardware Check, Device Recommendations, and Spawned Instances
#         (Nexus contained hub vs wild Surface Golem vs Failsafe Relay).
#      2. Live Two-Way Communications & Relay Feed (the Google Drive Eye Relay
#         inboxes `from-antigravity`, `from-muse`, `from-grok`, `from-claude`,
#         the `golem_channel` shared capability/event packets, and the local
#         offline failsafe spool `nexus_spool.jsonl`) with a full message
#         reader and a one-click "Sync communications" button.
#      3. Project-to-Capability Acceptance table showing every project in
#         `projects/` and whether it has been accepted as a live capability,
#         with one-click acceptance.
#  User intention (Andrew, 2026-10-18):
#    "ok we need to also have the comunication system in as well does it have
#    a way to do so also we need to change the gui to fit the new capabilities
#    and on a outside note are the projects still being done because they
#    should be and have a pathway where they can be accepted and added into
#    the code as a capability that is what they were meant for."
# ============================================================================
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from PySide6.QtWidgets import QHBoxLayout
from qfluentwidgets import FluentIcon, PlainTextEdit, PrimaryPushButton, PushButton

from warp2.app import theme
from warp2.app.parts.cards import KeyValue, Panel, StatCard
from warp2.app.parts.page import Page, row
from warp2.app.parts.table import Table
from warp2.app.parts.worker import later

DEFAULT_RELAY_DIR = Path(r"G:\My Drive\Eye Relay")


def _relay_root(state: Path) -> Path:
    """Intention: prefer the live Google Drive Eye Relay when present, else use state/relay_channel."""
    if DEFAULT_RELAY_DIR.is_dir():
        return DEFAULT_RELAY_DIR
    return state / "relay_channel"


def gather_connections(root: Path, state: Path) -> dict:
    """Gather hardware bloom, spawned Golem/Nexus instances, relay messages, and project capability status off-thread.

    Intention: automatically pull in any new capabilities or flags from the
    shared relay channel (`sync_communications`) and read everything the
    machine knows about its hardware fit, spawned instances, relay
    communications, and project acceptance without blocking the GUI thread.
    """
    root, state = Path(root), Path(state)
    relay = _relay_root(state)
    if relay.is_dir():
        try:
            from warp2.golem import surface
            sg = surface.SurfaceGolem(state)
            try:
                sg.sync_communications(relay)
            finally:
                if not sg._external_store:
                    sg.store.close()
        except Exception as err:
            from warp2.record import swallowed
            swallowed.noted("connections: sync_communications", err)

    bloom_path = state / "seed" / "bloom.json"
    spawn_path = state / "seed" / "spawned_instance.json"
    surface_path = state / "golem" / "surface.json"
    caps_path = state / "golem" / "capabilities.json"
    spool_path = state / "golem" / "nexus_spool.jsonl"
    synced_path = state / "golem" / "synced_spool.jsonl"

    bloom_data: dict = {}
    if bloom_path.is_file():
        try:
            bloom_data = json.loads(bloom_path.read_text(encoding="utf-8"))
        except Exception:
            bloom_data = {}

    spawn_data: dict = {}
    if spawn_path.is_file():
        try:
            spawn_data = json.loads(spawn_path.read_text(encoding="utf-8"))
        except Exception:
            spawn_data = {}

    surface_data: dict = {}
    if surface_path.is_file():
        try:
            surface_data = json.loads(surface_path.read_text(encoding="utf-8"))
        except Exception:
            surface_data = {}

    caps_map: dict = {}
    if caps_path.is_file():
        try:
            caps_map = (json.loads(caps_path.read_text(encoding="utf-8")).get("capabilities") or {})
        except Exception:
            caps_map = {}

    spool_rows: list[dict] = []
    for p, tag in ((spool_path, "pending_spool"), (synced_path, "synced_spool")):
        if p.is_file():
            for line in p.read_text(encoding="utf-8", errors="replace").splitlines()[-40:]:
                try:
                    item = json.loads(line)
                    item["_source"] = tag
                    spool_rows.append(item)
                except ValueError:
                    continue

    relay = _relay_root(state)
    messages: list[dict] = []
    if relay.is_dir():
        for folder_name in ("from-antigravity", "from-muse", "from-grok", "from-claude"):
            folder = relay / folder_name
            if not folder.is_dir():
                continue
            files = sorted(folder.glob("*.md"), key=lambda f: f.stat().st_mtime, reverse=True)[:12]
            for fpath in files:
                try:
                    st = fpath.stat()
                    when = datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")
                    body = fpath.read_text(encoding="utf-8", errors="replace")
                    first_line = next((ln.strip("# ").strip() for ln in body.splitlines() if ln.strip()), fpath.name)
                    messages.append({
                        "when": when,
                        "sort_key": st.st_mtime,
                        "channel": folder_name,
                        "kind": "relay_message",
                        "title": f"{fpath.name} — {first_line[:90]}",
                        "body": body[:8000],
                    })
                except OSError:
                    continue

        golem_chan = relay / "golem_channel"
        if golem_chan.is_dir():
            for ev_file in sorted(golem_chan.glob("events_*.jsonl")):
                try:
                    lines = ev_file.read_text(encoding="utf-8", errors="replace").splitlines()[-20:]
                except OSError:
                    continue
                for line in lines:
                    try:
                        ev = json.loads(line)
                    except ValueError:
                        continue
                    messages.append({
                        "when": str(ev.get("at") or "")[:16].replace("T", " "),
                        "sort_key": 0.0,
                        "channel": f"golem_channel/{ev_file.stem}",
                        "kind": str(ev.get("event") or "golem_event"),
                        "title": f"{ev.get('event', 'event')}: {ev.get('capability') or ev.get('target') or ev.get('instance_id', '')}",
                        "body": json.dumps(ev, indent=2, sort_keys=True),
                    })

    for item in reversed(spool_rows[-20:]):
        messages.append({
            "when": str(item.get("at") or "")[:16].replace("T", " "),
            "sort_key": 0.0,
            "channel": str(item.get("_source") or "spool"),
            "kind": str(item.get("event") or "spool_event"),
            "title": f"{item.get('event', 'spool')}: {item.get('capability') or item.get('target') or ''}",
            "body": json.dumps(item, indent=2, sort_keys=True),
        })

    messages.sort(key=lambda m: (m["when"], m["title"]), reverse=True)

    project_rows: list[dict] = []
    projects_dir = root / "projects"
    if projects_dir.is_dir():
        for child in sorted(projects_dir.iterdir()):
            if not child.is_dir() or child.name.startswith("_"):
                continue
            py_count = sum(
                1
                for p in child.rglob("*.py")
                if "__pycache__" not in p.parts and "tests" not in p.parts and not p.name.startswith("test_")
            )
            cap_key = f"project:{child.name}"
            rec = caps_map.get(cap_key)
            temps = (rec or {}).get("temperatures") or []
            temp_str = f"{float(temps[-1]):.2f}" if temps and isinstance(temps[-1], (int, float)) else "—"
            entries = ", ".join(((rec or {}).get("entrypoints") or [])[:5]) or "—"
            project_rows.append({
                "name": child.name,
                "accepted": rec is not None,
                "status": "Accepted capability" if rec is not None else ("Ready to accept" if py_count > 0 else "Empty"),
                "modules": py_count,
                "temperature": temp_str,
                "entrypoints": entries,
            })

    return {
        "relay_dir": str(relay),
        "bloom": bloom_data,
        "spawn": spawn_data,
        "surface": surface_data,
        "capabilities": caps_map,
        "pending_spool": sum(1 for r in spool_rows if r.get("_source") == "pending_spool"),
        "messages": messages[:60],
        "projects": project_rows,
    }


class ConnectionsPage(Page):
    """Communications, Seed hardware recommendations, spawned Golem/Nexus instances, and Project capability acceptance."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: build the live controls, status cards, relay message viewer, hardware/instance panel, and project acceptance table."""
        super().__init__(
            "connections",
            "Communications & connections",
            "Two-way Eye Relay & Golem channel, Seed device check & recommendations, spawned Nexus/Golem instances, and Project capability acceptance.",
            parent,
        )
        self.feed = feed
        self._busy = False
        self._messages: list[dict] = []
        self._projects: list[dict] = []

        self.sync_btn = PrimaryPushButton(FluentIcon.SYNC, "Sync communications")
        self.sync_btn.clicked.connect(self._sync_now)
        self.bloom_btn = PushButton(FluentIcon.IOT, "Check device & bloom")
        self.bloom_btn.clicked.connect(self._bloom_now)
        self.accept_all_btn = PushButton(FluentIcon.ACCEPT, "Accept built projects")
        self.accept_all_btn.clicked.connect(self._accept_all_projects)
        self.tools.addWidget(self.sync_btn)
        self.tools.addWidget(self.bloom_btn)
        self.tools.addWidget(self.accept_all_btn)

        self.tier_card = StatCard("Device tier & role", colour=theme.GOOD)
        self.model_card = StatCard("Recommended model", colour=theme.ACCENT)
        self.spawn_card = StatCard("Spawned instances", colour="#A78BFA")
        self.comms_card = StatCard("Relay & channel msgs", colour="#38BDF8")
        self.caps_card = StatCard("Golem & project caps", colour="#F472B6")
        self.body.addLayout(row(self.tier_card, self.model_card, self.spawn_card, self.comms_card, self.caps_card))

        top_split = QHBoxLayout()
        top_split.setSpacing(16)
        hw_panel = Panel("Seed device check & recommendations")
        self.hw_kv = KeyValue()
        hw_panel.add(self.hw_kv)
        top_split.addWidget(hw_panel, 1)

        inst_panel = Panel("Spawned Nexus / Surface Golem instances")
        self.inst_table = Table(["Instance ID", "Regime", "Role / Theme", "Reformations", "Pending spool"], stretch=2)
        self.inst_table.setMinimumHeight(210)
        inst_panel.add(self.inst_table)
        top_split.addWidget(inst_panel, 1)
        self.body.addLayout(top_split)

        from qfluentwidgets import LineEdit
        owner_panel = Panel("Nexus owner handle — step in & send early communication for active work")
        owner_row = QHBoxLayout()
        owner_row.setSpacing(10)
        self.early_input = LineEdit()
        self.early_input.setPlaceholderText("Type an early owner directive or communication to inject into the Nexus, Golem channel, and active work...")
        self.early_input.returnPressed.connect(self._send_early_communication)
        self.early_btn = PrimaryPushButton(FluentIcon.SEND, "Step in & send early")
        self.early_btn.clicked.connect(self._send_early_communication)
        owner_row.addWidget(self.early_input, 4)
        owner_row.addWidget(self.early_btn, 1)
        owner_panel.body.addLayout(owner_row)
        self.body.addWidget(owner_panel)

        comms_split = QHBoxLayout()
        comms_split.setSpacing(16)
        msg_panel = Panel("Communications feed (Eye Relay + Golem channel + failsafe spool)")
        self.msg_table = Table(["When", "Channel", "Kind", "Message / Event"], stretch=3)
        self.msg_table.setMinimumHeight(300)
        self.msg_table.cellClicked.connect(self._pick_message)
        msg_panel.add(self.msg_table)
        comms_split.addWidget(msg_panel, 3)

        read_panel = Panel("Picked communication / packet")
        self.reader = PlainTextEdit()
        self.reader.setReadOnly(True)
        self.reader.setMinimumHeight(300)
        read_panel.add(self.reader)
        comms_split.addWidget(read_panel, 2)
        self.body.addLayout(comms_split)

        proj_panel = Panel("Projects -> Capabilities pathway (double-click any project to accept it into live capabilities)")
        self.proj_table = Table(["Project", "Status", "Modules", "Temp", "Public entrypoints"], stretch=4)
        self.proj_table.setMinimumHeight(260)
        self.proj_table.cellDoubleClicked.connect(self._accept_picked_project)
        proj_panel.add(self.proj_table)
        self.body.addWidget(proj_panel)

    def draw(self, _snapshot: dict) -> None:
        """Intention: gather communications, hardware recommendations, and project status off-thread and fill the page."""
        if self._busy:
            return
        self._busy = True
        root, state = self.feed.root, self.feed.state
        later(lambda: gather_connections(root, state), self._fill, lambda _w: setattr(self, "_busy", False))

    def _fill(self, data: dict) -> None:
        """Intention: update all cards, tables, and device recommendations from the off-thread reading."""
        self._busy = False
        bloom = data.get("bloom") or {}
        prof = bloom.get("profile") or {}
        plan = bloom.get("plan") or {}
        rec = bloom.get("recommendation") or {}
        spawn = data.get("spawn") or {}
        surf = data.get("surface") or {}
        caps = data.get("capabilities") or {}

        tier = str(plan.get("tier") or "unprobed")
        role = str(rec.get("recommended_role") or plan.get("eye_mode") or "—")
        self.tier_card.set(tier.upper(), role)
        self.model_card.set(
            str(rec.get("recommended_model_tier") or "—"),
            f"Eye slice: {rec.get('eye_footprint_mb', '—')} MB · bottleneck: {rec.get('bottleneck', '—')}",
        )

        spawned_list = list(spawn.get("spawned_instances") or [])
        self.spawn_card.set(
            str(len(spawned_list)),
            ", ".join(f"{x.get('instance_id')} ({x.get('regime')})" for x in spawned_list[:2]) or "click Check device & bloom",
        )

        self._messages = list(data.get("messages") or [])
        self.comms_card.set(
            str(len(self._messages)),
            f"channel: {Path(str(data.get('relay_dir') or '')).name} · spool: {data.get('pending_spool', 0)} pending",
        )

        proj_accepted = sum(1 for v in caps.values() if isinstance(v, dict) and v.get("kind") == "project")
        self.caps_card.set(str(len(caps)), f"{proj_accepted} accepted from projects")

        gpu = prof.get("gpu") or {}
        notes = rec.get("notes") or []
        kv_rows = [
            ("machine_id", str(prof.get("machine_id") or "—")),
            ("os / arch", f"{prof.get('os', '—')} ({prof.get('arch', '—')})"),
            ("cpu / ram", f"{prof.get('cpu_cores', '—')} cores · {prof.get('ram_total_mb', '—')} MB total ({prof.get('ram_free_mb', '—')} MB free)"),
            ("disk / gpu", f"{prof.get('disk_free_gb', '—')} GB free · GPU: {gpu.get('name', 'none')} ({gpu.get('vram_mb', 0)} MB)"),
            ("memory budget", f"{plan.get('memory_budget_mb', '—')} MB · max active PopPairs: {plan.get('max_active_pairs', '—')}"),
            ("relay folder", str(data.get("relay_dir") or "—")),
        ]
        for idx, note in enumerate(notes[:3], 1):
            kv_rows.append((f"recommendation {idx}", str(note)))
        self.hw_kv.set(kv_rows)

        cfg = surf.get("config") or {}
        reforms = len(surf.get("reformations") or ())
        inst_rows = []
        for item in spawned_list:
            iid = str(item.get("instance_id") or "")
            reg = str(item.get("regime") or "")
            summary = f"theme={cfg.get('theme', 'default')} layout={cfg.get('layout', 'standard')} behavior={cfg.get('behavior', 'balanced')}"
            inst_rows.append((iid, reg, summary, str(reforms), str(data.get("pending_spool", 0))))
        if not inst_rows and surf.get("instance_id"):
            inst_rows.append((
                str(surf.get("instance_id")),
                str(surf.get("regime", "")),
                str(surf.get("intention") or "default"),
                str(reforms),
                str(data.get("pending_spool", 0)),
            ))
        self.inst_table.fill(inst_rows)

        self.msg_table.fill([(m["when"], m["channel"], m["kind"], m["title"]) for m in self._messages])
        if self._messages and not self.reader.toPlainText():
            self.reader.setPlainText(self._messages[0]["body"])

        self._projects = list(data.get("projects") or [])
        proj_colours = {
            (i, 1): (theme.GOOD if p["accepted"] else theme.ACCENT)
            for i, p in enumerate(self._projects)
        }
        self.proj_table.fill(
            [(p["name"], p["status"], str(p["modules"]), p["temperature"], p["entrypoints"]) for p in self._projects],
            keys=[p["name"] for p in self._projects],
            colours=proj_colours,
        )

    def _pick_message(self, row_idx: int, _col: int) -> None:
        """Intention: show the full text of the clicked relay message or Golem packet."""
        if 0 <= row_idx < len(self._messages):
            self.reader.setPlainText(self._messages[row_idx]["body"])

    def _sync_now(self) -> None:
        """Intention: sync Golem/Nexus communications with the relay folder off-thread and redraw."""
        from warp2.golem import surface

        root, state = self.feed.root, self.feed.state

        def work():
            """Intention: flush local spool to relay channel and ingest peer capabilities/flags."""
            sg = surface.SurfaceGolem(state)
            try:
                sg.sync_communications(_relay_root(state))
            finally:
                if not sg._external_store:
                    sg.store.close()
            return gather_connections(root, state)

        later(work, self._fill)

    def _bloom_now(self) -> None:
        """Intention: run hardware check, device recommendations, and Nexus/Golem instance spawning off-thread."""
        from warp2.seed import bloom

        root, state = self.feed.root, self.feed.state

        def work():
            """Intention: probe hardware, fit tier, record recommendations, and spawn instances."""
            prof = bloom.probe_hardware(root)
            plan = bloom.fit_hardware(prof)
            bloom.record_bloom(state, prof, plan)
            bloom.spawn_instance(root, state, prof, plan, relay_dir=_relay_root(state))
            return gather_connections(root, state)

        later(work, self._fill)

    def _accept_all_projects(self) -> None:
        """Intention: accept all built projects in `projects/` as live capabilities and sync."""
        from warp2.golem import surface

        root, state = self.feed.root, self.feed.state

        def work():
            """Intention: scan projects/ and accept every project with valid Python modules."""
            sg = surface.SurfaceGolem(state)
            try:
                projects_dir = Path(root) / "projects"
                if projects_dir.is_dir():
                    for child in sorted(projects_dir.iterdir()):
                        if child.is_dir() and not child.name.startswith("_"):
                            sg.accept_project_capability(child.name, root)
                sg.sync_communications(_relay_root(state))
            finally:
                if not sg._external_store:
                    sg.store.close()
            return gather_connections(root, state)

        later(work, self._fill)

    def _accept_picked_project(self, row_idx: int, _col: int) -> None:
        """Intention: double-clicking a project row accepts that project as a live capability."""
        if not (0 <= row_idx < len(self._projects)):
            return
        proj_name = self._projects[row_idx]["name"]
        from warp2.golem import surface

        root, state = self.feed.root, self.feed.state

        def work():
            """Intention: accept the chosen project and refresh the connections reading."""
            sg = surface.SurfaceGolem(state)
            try:
                sg.accept_project_capability(proj_name, root)
            finally:
                if not sg._external_store:
                    sg.store.close()
            return gather_connections(root, state)

        later(work, self._fill)

    def _send_early_communication(self) -> None:
        """Intention: let the Nexus owner step in and broadcast an early communication directly into the Golem channel, KG, and active work thread."""
        text = self.early_input.text().strip()
        if not text:
            return
        self.early_input.clear()
        from warp2.ask.thread import ANDREW, Thread
        from warp2.golem import surface
        from warp2.util import now_iso, sha256_hex

        root, state = self.feed.root, self.feed.state

        def work():
            """Intention: record the owner's early communication in the work thread, KG, and relay channel."""
            Thread(state).add(ANDREW, f"[EARLY NEXUS COMMUNICATION] {text}")
            sg = surface.SurfaceGolem(state, regime=surface.NEXUS_REGIME, instance_id="owner-nexus")
            try:
                cid = sha256_hex(f"{text}|{now_iso()}".encode("utf-8"))[:12]
                node = f"communication:early:{cid}"
                sg.store.assert_fact(node, "has", attr="kind", value="owner_early_communication")
                sg.store.assert_fact(node, "has", attr="said", value=text)
                sg.store.assert_fact(node, "has", attr="at", value=now_iso())
                sg._append_spool({
                    "event": "owner_early_intervention",
                    "priority": "immediate",
                    "communication_id": cid,
                    "said": text,
                })
                sg.sync_communications(_relay_root(state))
            finally:
                if not sg._external_store:
                    sg.store.close()
            return gather_connections(root, state)

        later(work, self._fill)
