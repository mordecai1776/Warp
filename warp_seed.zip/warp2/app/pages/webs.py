# WARP2/warp2/app/pages/webs.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/webs.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/webs/{home,settings,arbiter}.py and warp2/tags/types.py
#              warp2/app/parts/kg_reads.py (a web's members),
#              (read only), warp2/app/parts/{page,cards,table,worker}.py,
#              warp2/app/theme.py.
#  Description:
#    The connection KG and the tag system: every web by kind (old, use,
#    meaning, task) with its size, how much it helps and how much of that was
#    given or done; the picked web's members, strongest first, with how each
#    is known; the tag types by family and who made them; the learned
#    settings; and what has gone up to the oracle. Read again only when the
#    webs' database changed.
#  User intention (Andrew, 2026-09-24): webs "that continually self assemble
#    from use", tag types in families, and ground truth shown.
# ============================================================================
from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout

from warp2.app import theme
from warp2.app.parts.cards import KeyValue, Panel
from warp2.app.parts.page import Page
from warp2.app.parts.table import Table
from warp2.app.parts.kg_reads import web_members
from warp2.app.parts.worker import later

KINDS = ("old", "use", "meaning", "task", "practice")


def _read(state) -> dict:
    """Intention: the webs, the tag types, the settings and the oracle's queue, all read at once."""
    from warp2.tags.types import TypeBook
    from warp2.webs import arbiter, settings
    from warp2.webs.home import db
    con = db(state)
    try:
        webs = [dict(zip(("id", "kind", "name", "size", "score", "given", "done"), r)) for r in
                con.execute("SELECT id, kind, name, size, score, given, done FROM web ORDER BY kind, score DESC, size DESC")]
        cross = list(con.execute("SELECT a, b, shared FROM web_cross ORDER BY shared DESC"))
    finally:
        con.close()
    book = TypeBook(Path(state) / "store", seed=False)
    return {"webs": webs, "cross": cross, "types": book.types, "settings": settings.best(state),
            "oracle": arbiter.up_for_oracle(state)}


class WebsPage(Page):
    """The webs and the tag system."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the webs, the picked web, the tag types, the settings and the oracle."""
        super().__init__("webs", "Webs & tags", "The webs that assemble from use, and every kind of tag.", parent)
        self.feed = feed
        split = QHBoxLayout()
        split.setSpacing(16)
        left = Panel("Webs")
        self.webs = Table(["Web", "Kind", "Size", "Helps", "Given", "Done"], stretch=0)
        self.webs.setMinimumHeight(460)
        self.webs.itemSelectionChanged.connect(self._pick)
        left.add(self.webs)
        split.addWidget(left, 3)
        right = Panel("Its members")
        self.members = Table(["Member", "Strength", "Grade", "From"], stretch=0)
        self.members.setMinimumHeight(460)
        right.add(self.members)
        split.addWidget(right, 2)
        self.body.addLayout(split)
        lower = QHBoxLayout()
        lower.setSpacing(16)
        types = Panel("Tag types, by the action that applies them")
        self.types = Table(["Family", "Type", "Made by", "Rule"], stretch=3)
        self.types.setMinimumHeight(300)
        types.add(self.types)
        lower.addWidget(types, 3)
        side = QVBoxLayout()
        learned = Panel("Settings learned from the work")
        self.settings = KeyValue()
        learned.add(self.settings)
        side.addWidget(learned)
        oracle = Panel("Sent up to the oracle")
        self.oracle = KeyValue()
        oracle.add(self.oracle)
        side.addWidget(oracle)
        lower.addLayout(side, 2)
        self.body.addLayout(lower)
        self.seen = None

    def draw(self, snap: dict) -> None:
        """Intention: read again off the window's thread, only when the webs' database or the types changed."""
        from warp2.webs.home import folder
        state = Path(self.feed.state)
        try:
            paths = [folder(state) / "webs.sqlite3", state / "store" / "tags" / "types.jsonl"]
            stamp = tuple(p.stat().st_mtime if p.exists() else 0 for p in paths)
        except OSError:
            return
        if stamp == self.seen:
            return
        self.seen = stamp
        later(lambda: _read(state), self._fill)

    def _fill(self, read: dict) -> None:
        """Intention: every part of the page from one reading."""
        from warp2.tags.grounding import NAMES
        webs = read["webs"]
        self.webs.fill([(w["name"], w["kind"], w["size"], f"{w['score'] or 0:.2f}", f"{w['given'] or 0:.1f}",
                         f"{w['done'] or 0:.1f}") for w in webs], keys=[w["id"] for w in webs],
                       colours={(i, 1): theme.KIND.get("web") for i in range(len(webs))})
        rows = sorted(read["types"].values(), key=lambda t: (t["family"], t["name"]))
        self.types.fill([(t["family"], t["name"], t["made_by"], t["rule"].get("code") or str(t["rule"]))
                         for t in rows], keys=[t["name"] for t in rows])
        self.settings.set([(name, f"{row['value']}  ({row['mean']:.0%})") for name, row in read["settings"].items()])
        up = read["oracle"]
        self.oracle.set([("waiting", len(up))] + [("", thing) for thing in up[:12]])
        self._names = NAMES

    def _pick(self) -> None:
        """Intention: the picked web's members read and shown."""
        web = self.webs.picked()
        if not web:
            return
        state = self.feed.state
        later(lambda: web_members(state, web), self._show_members)

    def _show_members(self, rows: list) -> None:
        """Intention: each member with how firmly it belongs and how it is known."""
        from warp2.tags.grounding import NAMES
        self.members.fill([(s, f"{st:.2f}", NAMES.get(lv, "not yet") if lv is not None else "not yet", origin or "")
                           for s, st, lv, origin in rows], keys=[r[0] for r in rows],
                          colours={(i, 2): theme.GRADE.get(r[2], theme.QUIET) for i, r in enumerate(rows)})
