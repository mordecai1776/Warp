# WARP2/warp2/app/pages/knowledge.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/knowledge.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/app/parts/{page,cards,graph,table,worker,kg_controls,
#              kg_filter,kg_reads}.py, warp2/app/theme.py,
#              warp2/tags/{grounding,dehydrate}.py.
#  Description:
#    The KG: a card for each web; a controls bar (kinds, relations, least
#    grade, machinery, highlight a web or a relation; how many things, how
#    deep, which layout, fit, let go of pins; a path between two things); the
#    graph (the most joined things, the neighbourhood of a picked thing, or a
#    path), with back and forward through what was looked at; and beside it
#    the picked thing — every fact true of it now with its grade, what points
#    to it and what it points to. Drag a dot to pin it, double-click to add its
#    neighbours, right-click to take them away.
#  User intention (Andrew): the KG seen as it is; "ground things in logic and
#    previous known results" — so every fact shows how it is known. And
#    2026-09-25: "we need better controle in the kg view" — he chose filters,
#    focus and expand, size and layout, search and paths.
# ============================================================================
from __future__ import annotations

from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QWidget
from qfluentwidgets import BodyLabel, FlowLayout, FluentIcon, PushButton, TransparentToolButton

from warp2.app import theme
from warp2.app.parts import kg_filter as kf
from warp2.app.parts.cards import Panel, StatCard
from warp2.app.parts.graph import GraphView
from warp2.app.parts.kg_controls import Completing, KgControls
from warp2.app.parts.kg_reads import neighbourhood, web_list, web_members
from warp2.app.parts.page import Page
from warp2.app.parts.table import Table
from warp2.app.parts.worker import later

# Intention: how many suggestions the search offers at once.
SUGGEST = 40


class KnowledgePage(Page):
    """The KG."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the web cards, the controls, the graph and the picked thing."""
        super().__init__("knowledge", "Knowledge", "The KG, its webs, and how every fact is known.", parent)
        self.feed = feed
        self._tools()
        holder = QWidget()
        self.webs = FlowLayout(holder, needAni=False)
        self.webs.setHorizontalSpacing(12)
        self.webs.setVerticalSpacing(12)
        self.webs.setContentsMargins(0, 0, 0, 0)
        self.body.addWidget(holder)
        self.web_cards: dict = {}
        controls = Panel("Controls")
        self.controls = KgControls()
        controls.add(self.controls)
        self.body.addWidget(controls)
        self.body.addLayout(self._split())
        self.snap: dict = {}
        self.nodes: list = []
        self.edges: list = []
        self.view = {"mode": "whole"}
        self.history: list = [dict(self.view)]
        self.at = 0
        self.near: dict = {}
        self.marks_read = False
        self.controls.changed.connect(self.redraw)
        self.controls.path_asked.connect(self.find_path)
        self.controls.fit_asked.connect(self.graph.fit)
        self.controls.unpin_asked.connect(self._unpin)
        self.graph.picked_thing.connect(self.pick)
        self.graph.expand_asked.connect(self.expand)
        self.graph.collapse_asked.connect(self.graph.collapse)

    def _tools(self) -> None:
        """Intention: search with suggestions, back and forward, and the whole graph, above the page."""
        self.search = Completing("Find a thing (a file, concept:…, skill:…)")
        self.search.setFixedWidth(320)
        self.search.returnPressed.connect(lambda: self.find(self.search.text()))
        self.back = TransparentToolButton(FluentIcon.LEFT_ARROW)
        self.back.setToolTip("Back")
        self.back.clicked.connect(lambda: self._step(-1))
        self.ahead = TransparentToolButton(FluentIcon.RIGHT_ARROW)
        self.ahead.setToolTip("Forward")
        self.ahead.clicked.connect(lambda: self._step(1))
        whole = PushButton(FluentIcon.ZOOM_OUT, "Whole graph")
        whole.clicked.connect(lambda: self.go({"mode": "whole"}))
        for widget in (self.back, self.ahead, self.search, whole):
            self.tools.addWidget(widget)

    def _split(self) -> QHBoxLayout:
        """Intention: the graph on the left, the picked thing on the right."""
        split = QHBoxLayout()
        split.setSpacing(16)
        self.graph_panel = Panel("Graph")
        self.graph = GraphView()
        self.graph.setMinimumHeight(560)
        self.graph_panel.add(self.graph)
        self.hint = BodyLabel("Click a dot to centre on it · double-click to add its neighbours · "
                              "right-click to take them away · drag to pin")
        self.hint.setStyleSheet(f"color: {theme.QUIET}")
        self.graph_panel.add(self.hint)
        split.addWidget(self.graph_panel, 3)
        side = QVBoxLayout()
        self.thing = Panel("Picked thing")
        self.thing_name = BodyLabel("Pick a dot, or find a thing above.")
        self.thing_name.setWordWrap(True)
        self.thing.add(self.thing_name)
        self.facts = Table(["Fact", "Grade"], stretch=0)
        self.facts.setMinimumHeight(300)
        self.thing.add(self.facts)
        self.links = Table(["Way", "Relation", "Other"], stretch=2)
        self.links.setMinimumHeight(200)
        self.thing.add(self.links)
        side.addWidget(self.thing)
        split.addLayout(side, 2)
        return split

    # -- readings --------------------------------------------------------------

    def draw(self, snap: dict) -> None:
        """Intention: the web cards and what the controls can choose from, every reading; the graph redrawn only for the whole view."""
        self.snap = snap
        kg = snap.get("kg") or {}
        self._cards(kg.get("web_growth") or {})
        self.nodes = [n for n in kg.get("nodes") or [] if n.get("id")]
        self.edges = [e for e in kg.get("edges") or [] if e.get("from") and e.get("to")]
        names = sorted(n["id"] for n in self.nodes)
        self.controls.know(kf.kinds_of(self.nodes), kf.relations_of(self.edges), names, len(self.nodes))
        self.search.know(names)
        if not self.marks_read:
            self.marks_read = True
            later(lambda: web_list(self.feed.state), self._marks, lambda _w: self._marks([]))
        if self.view["mode"] == "whole":
            self.redraw()

    def _cards(self, growth: dict) -> None:
        """Intention: one card per web, how much it holds and how fast it grew today."""
        for name, web in sorted(growth.items(), key=lambda kv: -int(kv[1].get("fact_count") or 0)):
            if name not in self.web_cards:
                card = StatCard(f"{web.get('title') or name}", colour=theme.KIND.get("web"))
                card.setFixedWidth(250)
                card.name.setWordWrap(True)
                self.web_cards[name] = card
                self.webs.addWidget(card)
            rate = web.get("growth_rate")
            self.web_cards[name].set(f"{int(web.get('fact_count') or 0):,}",
                                     f"{web.get('share_pct', 0)}% of the KG · {int(web.get('new_today') or 0):,} today"
                                     + ("" if rate is None else f" (+{rate}%)"))

    def _marks(self, webs: list) -> None:
        """Intention: what can be highlighted — every web, then the relations present."""
        marks = [("web", (str(w[0]), f"{w[2] or w[0]} ({w[1]}, {w[3]})")) for w in webs]
        marks += [("relation", rel) for rel in kf.relations_of(self.edges) if rel]
        self.controls.know_marks(marks)

    # -- where the view is -----------------------------------------------------

    def go(self, view: dict) -> None:
        """Intention: a new view, remembered so back and forward can reach it."""
        self.history = self.history[:self.at + 1] + [dict(view)]
        self.at = len(self.history) - 1
        self.view = dict(view)
        self.redraw()

    def _step(self, by: int) -> None:
        """Intention: back or forward through what was looked at."""
        at = self.at + by
        if 0 <= at < len(self.history):
            self.at = at
            self.view = dict(self.history[at])
            self.redraw()

    def _unpin(self) -> None:
        """Intention: every pin let go, and the view laid out again."""
        self.graph.unpin()
        self.redraw()

    def redraw(self) -> None:
        """Intention: the current view drawn with the current choices."""
        self.back.setEnabled(self.at > 0)
        self.ahead.setEnabled(self.at < len(self.history) - 1)
        chosen = self.controls.chosen()
        mode = self.view["mode"]
        if mode == "focus":
            self._render_focus(chosen)
        elif mode == "path":
            self._render_path(chosen)
        else:
            self._render_whole(chosen)

    def _passing(self, nodes: list, edges: list, chosen: dict, keep=()) -> tuple:
        """Intention: the filters applied, never taking away the things the view is about."""
        kept_nodes, kept_edges = kf.filtered(nodes, edges, chosen["kinds"], chosen["relations"],
                                             chosen["least_grade"], chosen["hide_machinery"])
        have = {n["id"] for n in kept_nodes}
        kept_nodes += [n for n in nodes if n["id"] in set(keep) and n["id"] not in have]
        return kept_nodes, kept_edges

    def _paint_graph(self, nodes: list, edges: list, chosen: dict, focus: str = "", rings=None) -> None:
        """Intention: the graph drawn in the chosen layout, then the chosen highlight put on it."""
        self.graph.show_graph([{"id": n["id"], "label": str(n.get("label") or n["id"]).split(":", 1)[-1][:40],
                                "tip": n.get("definition") or n["id"]} for n in nodes],
                              [(e["from"], e["to"], e.get("relation", "")) for e in edges],
                              focus=focus, layout=chosen["layout"], rings=rings)
        self._highlight(chosen["mark"], edges)

    def _highlight(self, mark: tuple, edges: list) -> None:
        """Intention: a web's members, or the ends of one relation's links, lit; the rest dimmed."""
        kind, value = mark
        if kind == "relation":
            self.graph.highlight({end for e in edges if e.get("relation") == value for end in (e["from"], e["to"])})
        elif kind == "web":
            state = self.feed.state
            later(lambda: web_members(state, value[0]),
                  lambda rows: self.graph.highlight({str(r[0]) for r in rows}))
        elif self.view["mode"] == "path":
            self.graph.highlight(set(self.view.get("chain") or ()))
        else:
            self.graph.highlight(None)

    def _render_whole(self, chosen: dict) -> None:
        """Intention: the most joined things that pass the filters — the KG's shape at a glance."""
        nodes, edges = self._passing(self.nodes, self.edges, chosen)
        nodes, edges = kf.most_joined(nodes, edges, chosen["most"])
        self.graph_panel.heading.setText(f"The {len(nodes):,} most joined things shown, of {len(self.nodes):,}")
        self._paint_graph(nodes, edges, chosen)

    def _render_focus(self, chosen: dict) -> None:
        """Intention: the picked thing's neighbourhood to the chosen depth, read from the store once per depth."""
        subject, depth = self.view["subject"], chosen["depth"]
        read = self.near.get((subject, depth))
        if read is None:
            self.graph_panel.heading.setText(f"Reading around {subject} to depth {depth}…")
            root, state = self.feed.root, self.feed.state
            later(lambda: neighbourhood(root, state, subject, depth),
                  lambda answer: self._read_near(subject, depth, answer),
                  lambda w: self.thing_name.setText(f"{subject} — could not read it: {w}"))
            return
        sub, facts = read
        names = list(dict.fromkeys([subject] + list(sub.get("sub_nodes") or [])))
        known = {n["id"]: n for n in self.nodes}
        nodes = [known.get(name, {"id": name}) for name in names]
        edges = [{"from": e["from"], "to": e["to"], "relation": e.get("relation", "")}
                 for e in sub.get("sub_edges") or [] if e.get("from") and e.get("to")]
        nodes, edges = self._passing(nodes, edges, chosen, keep=(subject,))
        ringed, _links = kf.around(nodes, edges, subject, depth)
        self.graph_panel.heading.setText(f"Around {subject} — depth {depth}, {len(nodes):,} things")
        self._paint_graph(nodes, edges, chosen, focus=subject, rings={n["id"]: n["ring"] for n in ringed})
        self._show_thing(sub, facts)

    def _read_near(self, subject: str, depth: int, answer) -> None:
        """Intention: a neighbourhood kept once read, then drawn if it is still what is looked at."""
        self.near[(subject, depth)] = answer
        if self.view.get("mode") == "focus" and self.view.get("subject") == subject:
            self.redraw()

    def _render_path(self, chosen: dict) -> None:
        """Intention: the chain of things between two, with the links along it, lit."""
        chain = list(self.view.get("chain") or [])
        known = {n["id"]: n for n in self.nodes}
        nodes = [known.get(name, {"id": name}) for name in chain]
        steps = set(zip(chain, chain[1:])) | set(zip(chain[1:], chain))
        edges = [e for e in self.edges if (e["from"], e["to"]) in steps]
        self.graph_panel.heading.setText(f"Path: {' → '.join(chain)}")
        self._paint_graph(nodes, edges, dict(chosen, layout="layers" if chosen["layout"] == "radial" else chosen["layout"]))

    # -- what a person asks for ------------------------------------------------

    def find(self, words: str) -> None:
        """Intention: the thing named, or the best match for the words, picked."""
        hits = kf.matching(self.nodes, words, SUGGEST)
        if hits or str(words or "").strip():
            self.pick((hits or [str(words).strip()])[0])

    def pick(self, subject: str) -> None:
        """Intention: centre on the thing — its neighbourhood drawn and its facts listed."""
        if not subject:
            return
        self.thing_name.setText(f"{subject}  —  reading…")
        self.go({"mode": "focus", "subject": subject})

    def expand(self, name: str) -> None:
        """Intention: one thing's neighbours added to the picture where they are, filtered like the rest."""
        root, state, chosen = self.feed.root, self.feed.state, self.controls.chosen()

        def grow(answer) -> None:
            """Intention: add the node's neighbours and links that pass the filters to the drawn graph, and say how many."""
            sub, _facts = answer
            known = {n["id"]: n for n in self.nodes}
            nodes = [known.get(n, {"id": n}) for n in dict.fromkeys([name] + list(sub.get("sub_nodes") or []))]
            edges = [{"from": e["from"], "to": e["to"], "relation": e.get("relation", "")}
                     for e in sub.get("sub_edges") or [] if e.get("from") and e.get("to")]
            nodes, edges = self._passing(nodes, edges, chosen, keep=(name,))
            added = self.graph.expand(name, [{"id": n["id"], "label": str(n["id"]).split(":", 1)[-1][:40],
                                              "tip": n.get("definition") or n["id"]} for n in nodes],
                                      [(e["from"], e["to"], e.get("relation", "")) for e in edges])
            self.hint.setText(f"{name}: {added} neighbour(s) added — right-click it to take them away")
        later(lambda: neighbourhood(root, state, name, 1), grow,
              lambda w: self.hint.setText(f"could not read around {name}: {w}"))

    def find_path(self, start: str, end: str) -> None:
        """Intention: the shortest chain between two things through the links that pass the filters."""
        a = (kf.matching(self.nodes, start, 1) or [start])[0]
        b = (kf.matching(self.nodes, end, 1) or [end])[0]
        if not a or not b:
            self.hint.setText("Name both ends of the path.")
            return
        chosen = self.controls.chosen()
        _nodes, edges = self._passing(self.nodes, self.edges, chosen, keep=(a, b))
        chain = kf.path_between(edges, a, b)
        if not chain:
            self.hint.setText(f"No path from {a} to {b} through the {len(edges):,} links shown — "
                              f"try showing more kinds or relations.")
            return
        self.hint.setText(f"{len(chain) - 1} step(s) from {a} to {b}")
        self.go({"mode": "path", "chain": chain})

    def _show_thing(self, sub: dict, facts: list) -> None:
        """Intention: the picked thing's facts, best grade first, and its links in and out."""
        from warp2.tags.dehydrate import of_item
        from warp2.tags.grounding import NAMES
        subject = sub.get("subject", self.view.get("subject", ""))
        best = max((g for _f, g in facts), default=0)
        self.thing_name.setText(f"{subject}\nits best grade: {NAMES.get(best, 'not known')}")
        facts = sorted(facts, key=lambda fg: -fg[1])
        self.facts.fill([(of_item(f), NAMES.get(g, "not known")) for f, g in facts],
                        keys=[f.get("key") for f, _g in facts],
                        colours={(i, 1): theme.GRADE.get(g, theme.QUIET) for i, (_f, g) in enumerate(facts)})
        rows = [("out", o.get("relation"), o.get("target")) for o in sub.get("outbound") or []]
        rows += [("in", i.get("relation"), i.get("source")) for i in sub.get("inbound") or []]
        self.links.fill(rows, keys=[f"{r[0]}{r[1]}{r[2]}" for r in rows])
