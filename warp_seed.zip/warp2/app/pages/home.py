# WARP2/warp2/app/pages/home.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/home.py
#  Used by   : warp2/app/window.py (the first page).
#  Uses      : warp2/app/parts/{page,cards,chart,table,tiles,worker}.py, warp2/app/theme.py,
#              warp2/app/capabilities.py, warp2/app/pages/{capabilities,capability}.py
#              (holdings, ago, ENDED — the outline),
#              warp2/record/stop.py (Halt — the resume),
#              warp2/record/all_stop.py (the Stop: flag, then kill),
#              warp2/ui/runner.py (start — the runner asked for on Resume),
#              warp2/app/parts/standing_words.py (the pill, the doing line, local time).
#  Description:
#    The machine at a glance: running or stopped (with the Stop / Resume
#    button — the one control that must never be on another window), what it
#    is doing now, then the numbers in one row (work done / open / set down,
#    the KG's size and how fast it grew today, the gate, the models), then
#    the outline as tiles — every capability coloured by how it last went
#    (click one to open its tab) and every thing it holds as a number — a
#    live chart of the work, and the last few things it did. Pictures first;
#    words only where a picture cannot say it.
#  User intention (Andrew): "One launcher, one stop, one monitor." Runs show
#    visual cues.
#    2026-11-08 (BUILD_LOG 1455; "The gui still doesn't say everything is
#    going fix it"): the pill says paused for memory, a step taking long, or
#    can't tell, and offers Start only when the runner is surely down; the
#    doing line names the main runner's step in flight; times are in this
#    machine's clock; a number not read shows "—", never 0.
# ============================================================================
from __future__ import annotations

from qfluentwidgets import BodyLabel, CaptionLabel, FluentIcon, PrimaryPushButton

from warp2.app import theme
from warp2.app.parts.cards import Panel, Pill, ShareBar, StatCard
from warp2.app.parts.chart import LiveChart
from warp2.app.parts.page import Page, row
from warp2.app.parts.table import Table
from warp2.app.parts.tiles import HeldTile, Tile, TileGrid
from warp2.app.parts.worker import later

# Intention: how many of the latest actions are shown — a screen of them.
RECENT = 10


def _count(value) -> str:
    """Intention: a counted number with thousands marks, or — when it was not read (never 0 for unknown)."""
    return f"{value:,}" if type(value) is int else "—"


class HomePage(Page):
    """The machine at a glance."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the state line, the numbers, the chart and the latest actions."""
        super().__init__("home", "WARP2", "What the machine is doing, and how it is going.", parent)
        self.feed = feed
        self.state_pill = Pill("● reading…", theme.QUIET)
        self.stop_button = PrimaryPushButton(FluentIcon.PAUSE, "Stop")
        self.stop_button.clicked.connect(self._stop_or_resume)
        self.tools.addWidget(self.state_pill)
        self.tools.addWidget(self.stop_button)
        self.doing = BodyLabel("")
        self.doing.setWordWrap(True)
        self.body.addWidget(self.doing)
        # Intention: where the numbers came from, one quiet line — not a panel.
        self.sources = CaptionLabel("")
        self.sources.setTextColor("#64748B", "#94A3B8")
        self.body.addWidget(self.sources)

        # Intention: THE NUMBERS FIRST, in one row, and the share of the work
        # under them — the machine at a glance before anything else.
        self.done = StatCard("Work done", colour=theme.GOOD)
        self.open = StatCard("Work open", colour=theme.ACCENT)
        self.sunk = StatCard("Set down", colour=theme.WARN)
        self.facts = StatCard("KG facts", colour="#A78BFA")
        self.gate = StatCard("Gate", colour=theme.GOOD)
        self.models = StatCard("Models", colour="#F472B6")
        self.body.addLayout(row(self.done, self.open, self.sunk, self.facts, self.gate, self.models))
        self.share = ShareBar()
        self.body.addWidget(self.share)

        # Intention: THE OUTLINE (Andrew, 2026-09-25: "Then a home outline"),
        # as tiles — what it does, each capability a tile coloured by how it
        # last went (click to open its tab), and what it has, each a number.
        self.outline_panel = Panel("What it does — click one to open it")
        self.tiles = TileGrid()
        self.outline_panel.add(self.tiles)
        self.body.addWidget(self.outline_panel)
        self.held_panel = Panel("What it has")
        self.held = TileGrid()
        self.held_panel.add(self.held)
        self.body.addWidget(self.held_panel)
        self.open_cap = None
        self.open_page = None
        self._outlining = False
        self._outline_was = None

        self.chart_panel = Panel("How it has moved since this window opened")
        self.chart = LiveChart(height=200)
        self.chart_panel.add(self.chart)
        self.body.addWidget(self.chart_panel)

        self.recent_panel = Panel("Latest actions")
        self.recent = Table(["When", "Step", "On", "Outcome", "Seconds"], stretch=2)
        self.recent.setMinimumHeight(300)
        self.recent_panel.add(self.recent)
        self.body.addWidget(self.recent_panel)
        feed.standing.connect(self.stand)

    def stand(self, stand: dict) -> None:
        """Intention: running, paused for memory, a long step, stopped or can't tell - and what it is on - shown within a second."""
        from warp2.app.parts.standing_words import doing_line, pill
        words, colour, button = pill(stand)
        self.state_pill.set(words, colour)
        self.button_says = button
        self.stop_button.setEnabled(bool(button))
        self.stop_button.setText(button or "Stop")
        self.stop_button.setIcon(FluentIcon.PAUSE if button in ("Stop", "") else FluentIcon.PLAY)
        self.running = stand.get("running") if not stand.get("stopped") else False
        self.doing.setText(doing_line(stand))

    def _stop_or_resume(self) -> None:
        """The stop raised while it runs; otherwise lifted and the runner asked for — the one thing this page writes.

        Intention: the same authority the old cockpit's ALL STOP had, and the
        same Resume: every mirror of the stop lifted, then the runner started.
        """
        from warp2.record.stop import Halt
        halt = Halt(self.feed.state)
        # Intention (BUILD_LOG 1455): Start only when the reading said the runner is surely down (button "Start" or
        # "Resume"); when it could not tell, the button is off and nothing is started beside a live runner.
        if getattr(self, "button_says", "") not in ("Start", "Resume", "Stop"):
            self.feed.reader.ask_now()
            return
        if halt.raised() or self.button_says in ("Start", "Resume"):
            halt.clear()
            from warp2.ui.runner import start
            try:
                start(self.feed.root, self.feed.state)
                self.doing.setText("runner requested")
            except OSError as exc:
                self.doing.setText(f"could not start the runner: {exc}")
        else:
            # Intention (2026-10-09, check F3): a kill, like ALL_STOP.bat — the
            # flag, then every process this system owns (warp2/record/all_stop.py).
            from warp2.record.all_stop import halt as all_stop
            all_stop(self.feed.state, "stopped from the window")
        self.feed.reader.ask_now()

    def outline_read(self, snap: dict) -> None:
        """Intention: the outline read off the window's thread — what it holds and every capability's standing."""
        if self._outlining:
            return
        self._outlining = True
        from warp2.app.capabilities import Capabilities
        from warp2.app.pages.capabilities import holdings
        caps, state = Capabilities(self.feed.root, self.feed.state), self.feed.state

        def gather():
            """Intention: the off-thread part — what is held, and each capability with its standing from its runs."""
            entries = caps.entries()
            known = caps.all(entries)
            return {"held": holdings(state, snap),
                    "rows": [(c, caps.standing(c, caps.runs(c, entries, known))) for c in known]}
        later(gather, self._outline_fill, lambda _w: setattr(self, "_outlining", False))

    def _outline_fill(self, got: dict) -> None:
        """Intention: a tile for every capability, grouped by area — phases, work, steps, then its own running — and one for everything it holds."""
        from warp2.app.pages.capability import ENDED, ago
        self._outlining = False
        order = {"phase": 0, "work": 1, "step": 2, "running": 3}
        rows = sorted(got["rows"], key=lambda cs: (order.get(cs[0]["kind"], 9), cs[0]["name"]))
        # Intention: the tiles made again only when something on them changed.
        seen = ([(c["key"], s["runs"], None if s["ago"] is None else int(s["ago"] // 60),
                  str((s["last"] or {}).get("outcome"))) for c, s in rows],
                got["held"])
        if seen == self._outline_was:
            return
        self._outline_was = seen
        tiles = []
        for cap, standing in rows:
            last = str((standing["last"] or {}).get("outcome") or "")
            # Intention (2026-10-02): runs counted over the whole record
            # (warp2/app/record_index.py), not the recent window alone.
            runs = (standing.get("record") or {}).get("runs", standing["runs"])
            line = f"{ago(standing['ago'])} · {runs:,} run{'s' if runs != 1 else ''}"
            ended = [(n, ENDED.get(k, theme.QUIET)) for k, n in (standing.get("outcomes") or {}).items()]
            tile = Tile(cap["key"], cap["name"], line, ENDED.get(last, theme.QUIET) if last else theme.QUIET, ended)
            tile.opened.connect(self._open)
            tiles.append(tile)
        self.tiles.fill(tiles)
        tiles = [HeldTile(name, said) for name, said in got["held"]]
        for tile in tiles:
            tile.opened.connect(lambda key: self.open_page(key) if self.open_page else None)
        self.held.fill(tiles)

    def _open(self, key: str) -> None:
        """Intention: a capability's tab opened from its tile."""
        if self.open_cap is not None:
            self.open_cap(key)

    def draw(self, snap: dict) -> None:
        """Intention: every number, the chart and the latest actions from one reading."""
        self.outline_read(snap)
        ledger = snap.get("ledger") or {}
        kg = snap.get("kg") or {}
        gate = snap.get("gate") or {}
        models = snap.get("models") or []
        from warp2.app.parts.standing_words import local_time
        from warp2.app.parts.tone import pct
        total = ledger.get("total")
        self.done.set(_count(ledger.get("done")), f"{pct(ledger.get('share_done'))} of {_count(total)} units")
        self.open.set(_count(ledger.get("open")), "waiting or being worked on")
        self.sunk.set(_count(ledger.get("sunk")), "set down after trying")
        self.share.set([(ledger.get("done") or 0, theme.GOOD), (ledger.get("open") or 0, theme.ACCENT),
                        (ledger.get("sunk") or 0, theme.WARN)])
        grew = kg.get("growth_rate")
        self.facts.set(_count(kg.get("total_facts")),
                       f"{_count(kg.get('velocity_today'))} new today" + (f" (+{grew}%)" if grew is not None else ""))
        status = str(gate.get("status") or "—")
        self.gate.set(status, f"{_count(gate.get('safeguards_monitored'))} checks watched",
                      theme.GOOD if status == "CHECKED" else theme.QUIET if status == "—" else theme.WARN)
        on = [m for m in models if m.get("enabled", True)]
        self.models.set(f"{len(on)}" if models else "—",
                        f"of {len(models)} enabled; {len(snap.get('workers') or [])} worker(s)" if models else "not read")
        for name, colour in (("done", theme.GOOD), ("open", theme.ACCENT), ("sunk", theme.WARN)):
            self.chart.show(name, *self.feed.history.of(name), colour=colour)
        # Intention: the latest actions only — a screen of them, the newest first.
        rows = [(local_time(r.get("timestamp"), clock_only=True), r.get("verb", ""), r.get("target", ""),
                 r.get("outcome", ""), "" if r.get("seconds") is None else f"{float(r['seconds']):.1f}")
                for r in (snap.get("recent") or [])[:RECENT]]
        from warp2.app.pages.capability import ENDED
        colours = {(i, 3): ENDED.get(str(r[3]), theme.QUIET) for i, r in enumerate(rows)}
        self.recent.fill(rows, keys=[f"{r[0]}{r[1]}{r[2]}" for r in rows], colours=colours)
        missed = snap.get("could_not_read") or []
        self.sources.setText(f"read {local_time(snap.get('at'))}" + (" (from the last session)" if snap.get("cached") else "")
                             + " · "
                             + ("everything from the store" if not missed else
                                f"all but {len(missed)} reading(s) from the store: " + "; ".join(m[:60] for m in missed)))
