# WARP2/warp2/app/pages/pictures.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/pictures.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/app/chat_centre.py (shared — the Action Centre's picture
#              rules), warp2/ask/{media,visual,image_triage}.py (read),
#              warp2/app/parts/{page,cards,table,thumbs,worker}.py.
#              warp2/tags/media/pictures.py (is_there, bytes_of, where_file_is - asked of the small form; BUILD_LOG 1597c);
#  Description:
#    Everything about pictures in one page: what needs his eye (pictures and
#    references to confirm, turn down, or say he does not know — each answer
#    adds feedback to the work, nothing is made here); the pictures asked
#    for and where each stands, with a box to ask for another; the uncertain
#    ones to sort; and the gallery of what has been made.
#  User intention (Andrew, 2026-09-18): "detach the immediate change that
#    image user stuff works and place that into something that adds to the
#    work instead of acting like a trigger."
# ============================================================================
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QHBoxLayout, QWidget
from qfluentwidgets import BodyLabel, FlowLayout, FluentIcon, LineEdit, PrimaryPushButton, PushButton

from warp2.app import theme
from warp2.app.parts.cards import Panel
from warp2.app.parts.page import Page
from warp2.app.parts.table import Table
from warp2.app.parts.thumbs import PictureCard
from warp2.app.parts.worker import later
from warp2.record.swallowed import noted
from warp2.tags.media import pictures


def _flow() -> tuple:
    """Intention: a holder whose cards wrap to the width of the page."""
    holder = QWidget()
    flow = FlowLayout(holder, needAni=False)
    flow.setContentsMargins(0, 0, 0, 0)
    flow.setHorizontalSpacing(12)
    flow.setVerticalSpacing(12)
    return holder, flow


def _clear(flow) -> None:
    """Intention: every card taken out of a flow."""
    while flow.count():
        widget = flow.takeAt(0)
        if widget is not None:
            widget.deleteLater()


class PicturesPage(Page):
    """Pictures: to confirm, asked for, uncertain, and made."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the four parts, top to bottom in the order he needs them."""
        super().__init__("pictures", "Pictures", "What needs your eye, what was asked for, and what was made.", parent)
        from warp2.app.chat_centre import shared
        self.feed = feed
        self.centre = shared(feed)

        # Debounced redraw timer preventing event-loop freezes on rapid signal bursts
        self._draw_timer = QTimer(self)
        self._draw_timer.setSingleShot(True)
        self._draw_timer.setInterval(250)
        self._draw_timer.timeout.connect(self._do_draw_all)
        self._in_draw = False

        # Card trackers for incremental non-freezing updates
        self._eye_cards: dict[str, PictureCard] = {}
        self._unsure_cards: dict[str, PictureCard] = {}
        self._made_cards: dict[str, PictureCard] = {}

        self.centre.bridge.lists.connect(self.draw_all)
        self.eye_panel = Panel("Needs your eye")

        eye_top = QHBoxLayout()
        self.eye_empty = BodyLabel("Nothing is waiting for you.")
        eye_top.addWidget(self.eye_empty, 1)

        self.self_confirm_btn = PushButton(FluentIcon.ACCEPT, "Self-confirm high confidence")
        self.self_confirm_btn.setToolTip("Autonomously self-confirm pending images and references with high reader scores (≥ 70%)")
        self.self_confirm_btn.clicked.connect(self._self_confirm_all)
        self.self_confirm_btn.hide()
        eye_top.addWidget(self.self_confirm_btn)
        self.eye_panel.body.addLayout(eye_top)

        holder, self.eye = _flow()
        self.eye_panel.add(holder)
        self.body.addWidget(self.eye_panel)

        asked = Panel("Pictures asked for")
        line = QHBoxLayout()
        self.subject = LineEdit()
        self.subject.setPlaceholderText("What should the picture be of?")
        self.subject.returnPressed.connect(self._ask)
        ask = PrimaryPushButton(FluentIcon.ADD, "Ask for it")
        ask.clicked.connect(self._ask)
        take_back = PushButton(FluentIcon.CANCEL, "Take back the picked one")
        take_back.clicked.connect(self._take_back)
        clear = PushButton(FluentIcon.BROOM, "Clear the made ones")
        clear.clicked.connect(self._clear_made)
        line.addWidget(self.subject, 1)
        line.addWidget(ask)
        line.addWidget(take_back)
        line.addWidget(clear)
        asked.body.addLayout(line)
        self.queue = Table(["Picture of", "Stands", "Picture", "Why not"], stretch=0)
        self.queue.setMinimumHeight(220)
        self.queue.cellDoubleClicked.connect(self._open_queue_image)
        asked.add(self.queue)
        self.body.addWidget(asked)

        self.unsure_panel = Panel("Not sure what they are")
        holder, self.unsure = _flow()
        self.unsure_panel.add(holder)
        self.body.addWidget(self.unsure_panel)

        made = Panel("Made")
        holder, self.made = _flow()
        made.add(holder)
        self.body.addWidget(made)
        self.feed.snapshot.connect(lambda _s: self.isVisible() and self.draw_all())

    def showEvent(self, event) -> None:
        """Intention: the page read fresh whenever it is shown."""
        super().showEvent(event)
        self.draw_all()

    def draw(self, snapshot: dict) -> None:
        """Intention: update pictures, queue, and triage whenever a snapshot reading arrives."""
        self.draw_all()

    def draw_all(self) -> None:
        """Debounced redraw of all picture parts."""
        if not self.isVisible():
            return
        self._draw_timer.start(250)

    def _do_draw_all(self) -> None:
        """Intention: the machine's new picture reports taken in, then every part read off the window's thread."""
        if not self.isVisible() or self._in_draw:
            return
        self._in_draw = True
        root, state = self.feed.root, self.feed.state

        def read():
            """Intention: the off-thread part — made, approved, unsure and waiting pictures, and the picture queue."""
            from warp2.ask.image_triage import ImageTriageHandler
            from warp2.ask.media import list_created_images
            from warp2.ask.visual import VisualLearning
            learning = VisualLearning(root, state)
            made = list_created_images(state, limit=24)
            approved = learning.approved_paths()
            unsure = [it for it in ImageTriageHandler(state).list_uncertain()
                      if it.status in ("pending_triage", "analyzed")]
            waiting = [(k, v) for k, v in list(self.centre.pending_image_confirmations.items())
                       if pictures.is_there(v.get("path", ""))][:24]
            return {"made": made, "approved": approved, "unsure": unsure,
                    "waiting": waiting,
                    "queue": self.centre._load_image_queue()}
        later(read, self._fill, lambda _: setattr(self, "_in_draw", False))

    def _fill(self, read: dict) -> None:
        """Intention: the four parts drawn from one reading without tearing down intact cards."""
        self._in_draw = False

        # 1. Waiting (Needs your eye)
        waiting = read.get("waiting", [])
        self.eye_empty.setVisible(not waiting)
        self.self_confirm_btn.setVisible(bool(waiting))

        current_waiting_keys = {k for k, _ in waiting}
        for k in list(self._eye_cards.keys()):
            if k not in current_waiting_keys:
                c = self._eye_cards.pop(k, None)
                if c is not None:
                    c.hide()
                    c.deleteLater()

        for key, item in waiting:
            if key in self._eye_cards:
                continue
            path = Path(item["path"])
            review = item.get("review") or {}
            subject = review.get("subject") or path.stem
            if subject == "user_confirmed":
                subject = path.stem
            score = review.get("reader_score")
            line = f"{'reference' if item.get('is_reference') else 'made'} · " + (
                f"reader {int(score * 100)}%" if score is not None else "needs review")
            if item.get("is_reference") and review:
                actions = (
                    ("Yes", lambda r=review, k=key: (self.centre.pending_image_confirmations.pop(k, None), self.centre._confirm_reference_from_panel(r, True))),
                    ("Auto-verify", lambda r=review, k=key: (self.centre.pending_image_confirmations.pop(k, None), self.centre.self_confirm_reference_from_panel(r))),
                    ("No", lambda r=review, k=key: (self.centre.pending_image_confirmations.pop(k, None), self.centre._confirm_reference_from_panel(r, False))),
                    ("Not sure", lambda r=review, k=key: (self.centre.pending_image_confirmations.pop(k, None), self.centre._mark_reference_unknown_from_panel(r))),
                )
            else:
                # Intention (2026-10-02): "Auto-verify" confirms a picture at
                # the reader's score; a picture the reader never scored was
                # confirmed as if it scored 100% (score or 1.0). It is offered
                # only when there is a score to confirm it at.
                verify = (("Auto-verify", lambda p=path, k=key, sc=score: (self.centre.pending_image_confirmations.pop(k, None), self.centre.self_confirm_image_from_panel(p, score=sc))),
                          ) if score is not None else ()
                actions = (
                    ("Keep", lambda p=path, k=key: (self.centre.pending_image_confirmations.pop(k, None), self.centre._confirm_image_from_panel(p))),
                    *verify,
                    ("Not right", lambda p=path, k=key: (self.centre.pending_image_confirmations.pop(k, None), self.centre._downvote_image_from_panel(p))),
                    ("Not sure", lambda p=path, k=key: (self.centre.pending_image_confirmations.pop(k, None), self.centre._mark_image_unknown_from_panel(p))),
                )
            card = PictureCard(path, subject, line, self.closing(actions, card_key=key))
            self._eye_cards[key] = card
            self.eye.addWidget(card)

        # 2. Table queue
        queue = read["queue"]
        colours = {(i, 1): {"done": theme.GOOD, "failed": theme.BAD}.get(r.get("status"), theme.ACCENT)
                   for i, r in enumerate(queue)}
        self.queue.fill([(r.get("subject"), r.get("status"), Path(r.get("image_path") or "").name,
                          r.get("error") or "") for r in queue], keys=[r.get("id") for r in queue], colours=colours)

        # 3. Unsure triage
        self.unsure_panel.setVisible(bool(read["unsure"]))
        current_unsure_ids = {str(it.id) for it in read["unsure"] if pictures.is_there(it.path)}
        for uid in list(self._unsure_cards.keys()):
            if uid not in current_unsure_ids:
                c = self._unsure_cards.pop(uid, None)
                if c is not None:
                    c.hide()
                    c.deleteLater()

        for it in read["unsure"]:
            uid = str(it.id)
            if uid in self._unsure_cards or not pictures.is_there(it.path):
                continue
            top = it.hypotheses[0]["concept"] if it.hypotheses else ""
            actions = ([(f"It is {top}", lambda i=it.id, c=top: self.centre._resolve_triage_action(i, c))] if top else
                       [("Look at it", lambda i=it.id: self.centre._analyze_triage_action(i))])
            actions.append(("Drop it", lambda i=it.id: self.centre._discard_triage_action(i)))
            card = PictureCard(it.path, it.initial_subject or Path(it.path).stem,
                               f"{it.status}" + (f" · best guess {top}" if top else ""),
                               self.closing(actions))
            self._unsure_cards[uid] = card
            self.unsure.addWidget(card)

        # 4. Made pictures (incremental additions with truthful attribution)
        current_made_paths = {str(Path(row["image_path"]).resolve()) for row in read["made"]
                              if row.get("image_path") and pictures.is_there(row["image_path"])}
        for p in list(self._made_cards.keys()):
            if p not in current_made_paths:
                c = self._made_cards.pop(p, None)
                if c is not None:
                    c.hide()
                    c.deleteLater()

        approved_paths = read.get("approved", set())
        for row in read["made"]:
            p_str = row.get("image_path")
            if not p_str or not pictures.is_there(p_str):
                continue
            p_res = str(Path(p_str).resolve())
            if p_res in self._made_cards:
                continue
            subj = str(row.get("subject") or "")
            if not subj or subj == "user_confirmed":
                subj = Path(p_str).stem
            by = row.get("confirmed_by")
            if by == "user":
                tag = "kept (you confirmed)"
            elif by == "system":
                tag = "kept (system verified)"
            elif p_str in approved_paths or p_res in approved_paths:
                tag = "kept"
            elif row.get("kind") == "training_preview":
                checked = "reader pending" if row.get("reader_status") == "pending" else "not reader checked"
                tag = f"training preview · round {row.get('round')} · seed {row.get('seed')} · {checked}"
            elif row.get("kind") == "training_candidate":
                tag = f"reader candidate · round {row.get('round')} · reader pending"
            else:
                tag = ""
            card = PictureCard(p_str, subj, tag, size=132)
            self._made_cards[p_res] = card
            self.made.addWidget(card)

    def closing(self, actions, card_key: str | None = None) -> list:
        """Each button made to close its picture out at once: card removed instantly from UI, work run off-thread.

        Intention: Andrew, 2026-09-25/27: confirmed pictures close out immediately
        without UI lockups or freezes.
        """
        def make_handler(act):
            """Intention: wrap one action in a click handler, so each button keeps its own action."""
            def handler(*_args):
                # Instantly remove the card from the UI flow without waiting
                """Intention: on click, take the card off the page at once, run the action off-thread, then redraw."""
                if card_key and card_key in self._eye_cards:
                    c = self._eye_cards.pop(card_key, None)
                    if c is not None:
                        try:
                            c.hide()
                            c.deleteLater()
                        except Exception:  # Intention: the card may already be gone from the page; hiding it is only a tidy-up and the redraw follows.
                            pass
                def run_action():
                    """Intention: run the button's action; a failure is printed, not raised, so the redraw still happens."""
                    try:
                        act()
                    except Exception as exc:
                        print("Error executing image action:", exc)
                later(run_action, lambda _: self.draw_all())
            return handler
        return [(words, make_handler(act)) for words, act in actions]

    def _self_confirm_all(self) -> None:
        """Autonomously self-confirm all pending images and references with reader scores >= 70%."""
        def run_sc():
            """Intention: the off-thread part — confirm every waiting picture the reader scores 0.70 or higher."""
            return self.centre.self_confirm_pending(threshold=0.70)
        later(run_sc, lambda _: self.draw_all())

    def _ask(self) -> None:
        """Intention: a picture asked for — the loop makes it on its next pass."""
        subject = self.subject.text().strip()
        if subject:
            self.centre.enqueue_image_action(subject)
            self.subject.clear()
            self.draw_all()

    def _take_back(self) -> None:
        """Intention: the picked ask taken back, if the loop has not reached it."""
        picked = self.queue.picked()
        if picked:
            self.centre._remove_from_queue_action(picked)
            self.draw_all()

    def _clear_made(self) -> None:
        """Intention: the finished asks cleared from view (the pictures stay)."""
        self.centre._clear_completed_queue_action()
        self.draw_all()

    def _open_queue_image(self, row: int, col: int) -> None:
        """Intention: double-clicking a row opens its picture in the full viewer."""
        try:
            from PySide6.QtCore import QUrl
            from PySide6.QtGui import QDesktopServices
            keys = getattr(self.queue, "keys", [])
            key = keys[row] if row < len(keys) else None
            item = self.queue.item(row, 2)
            fname = item.text() if item else ""
            from warp2.ask.image_asks import ImageAsks
            for r in ImageAsks(self.feed.state).rows():
                if r.get("id") == key or (fname and Path(r.get("image_path") or "").name == fname):
                    p = r.get("image_path")
                    at = pictures.where_file_is(p) if p else None
                    if at is not None:
                        QDesktopServices.openUrl(QUrl.fromLocalFile(str(at)))
                        return
        except Exception as exc:
            noted("warp2/app/pages/pictures.py:PicturesPage._open_queue_image", exc)

