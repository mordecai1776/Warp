# WARP2/warp2/app/pages/make.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/make.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/make/{book,stage,home}.py (read only),
#              warp2/app/parts/{page,cards,table,worker}.py, warp2/app/theme.py.
#  Description:
#    The make cycle: every job with its state and how many of its nodes are
#    done; the picked job's nodes in order — each level's step, try and rung,
#    and the three makers' scores (the models, the Eye's parts, the Eye's
#    master) — and what it knows: what it understood, the checks it carries,
#    the agents' work as the other models judged it, what needs training most,
#    and its final evaluation. Read again only when a job file changed.
#  User intention (Andrew): the old Make Cycle tab, in the one window.
# ============================================================================
from __future__ import annotations

import json

from PySide6.QtWidgets import QHBoxLayout
from qfluentwidgets import PlainTextEdit

from warp2.app import theme
from warp2.app.parts.cards import Panel
from warp2.app.parts.page import Page
from warp2.app.parts.table import Table
from warp2.app.parts.worker import later


def _read(state) -> dict:
    """Intention: every job, keyed by its item, and the newest training needs."""
    from warp2.make.book import JobBook
    from warp2.make.home import home
    jobs = {job.row["item"]: job for job in JobBook(state).all()}
    try:
        needs = json.loads((home(state) / "training_needs.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        needs = None
    return {"jobs": jobs, "needs": needs}


def _stamp(state):
    """Intention: what the job files look like now — only a change reads them again."""
    from warp2.make.home import jobs
    return tuple(sorted((p.name, p.stat().st_mtime) for p in jobs(state).glob("*.json")))


class MakePage(Page):
    """The make cycle."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the jobs, the picked job's nodes, and what it knows."""
        super().__init__("make", "Make cycle", "Every job, every level, every step — and how each maker did.", parent)
        self.feed = feed
        split = QHBoxLayout()
        split.setSpacing(16)
        jobs = Panel("Jobs")
        self.jobs = Table(["Job", "State", "Nodes done"], stretch=0)
        self.jobs.setMinimumHeight(520)
        self.jobs.itemSelectionChanged.connect(self._show_picked)
        jobs.add(self.jobs)
        split.addWidget(jobs, 2)
        nodes = Panel("Its nodes")
        self.nodes = Table(["Level — what", "Status", "Step", "Try", "Models", "Eye parts", "Eye master", "Why"],
                           stretch=0)
        self.nodes.setMinimumHeight(520)
        nodes.add(self.nodes)
        split.addWidget(nodes, 5)
        self.body.addLayout(split)
        known = Panel("What it knows")
        self.known = PlainTextEdit()
        self.known.setReadOnly(True)
        self.known.setMinimumHeight(320)
        known.add(self.known)
        self.body.addWidget(known)
        self.read: dict = {"jobs": {}, "needs": None}
        self.seen = None

    def draw(self, snap: dict) -> None:
        """Intention: the job files read again, off the window's thread, only when one changed."""
        state = self.feed.state
        try:
            stamp = _stamp(state)
        except OSError:
            return
        if stamp == self.seen:
            return
        self.seen = stamp
        later(lambda: _read(state), self._fill)

    def _fill(self, read: dict) -> None:
        """Intention: the jobs listed, the picked one kept."""
        self.read = read
        rows, colours = [], {}
        for i, (key, job) in enumerate(read["jobs"].items()):
            nodes = list(job.nodes.values())
            done = sum(1 for n in nodes if n["status"] == "done")
            rows.append((job.row.get("target") or key, job.row.get("state"), f"{done} of {len(nodes)}"))
            colours[(i, 1)] = theme.GOOD if job.row.get("state") == "done" else theme.ACCENT
        self.jobs.fill(rows, keys=list(read["jobs"]), colours=colours)
        self._show_picked()

    def _show_picked(self) -> None:
        """Intention: the picked job's nodes in order, and what it knows."""
        from warp2.make.stage import STEPS
        job = self.read["jobs"].get(self.jobs.picked())
        if job is None:
            self.nodes.fill([])
            self.known.setPlainText("Pick a job.")
            return
        rows, colours = [], {}
        for i, key in enumerate(job.row["order"]):
            n = job.nodes[key]
            scores = {m: v.get("score") for m, v in n.get("verdicts", {}).items()}
            shown = [f"{scores[m]:.2f}" if isinstance(scores.get(m), (int, float)) else "—"
                     for m in ("models", "eye:parts", "eye:master")]
            rows.append((f"{n['level']} — {n['what']}", n["status"], STEPS[n["step"]] if n["step"] < len(STEPS) else n["step"],
                         f"{n['attempt'] + 1} / rung {n['rung']}", *shown,
                         n.get("why") or "; ".join(n.get("whys", [])[-1:])))
            colours[(i, 1)] = {"done": theme.GOOD, "failed": theme.BAD, "waiting": theme.WARN}.get(n["status"], theme.ACCENT)
        self.nodes.fill(rows, keys=list(job.row["order"]), colours=colours)
        lines = ["WHAT IT UNDERSTOOD:", job.row.get("understood") or "(not yet)", "", "CHECKS IT CARRIES:"]
        for n in job.nodes.values():
            lines += [f"- {c}" for c in n.get("checks", [])]
        lines += ["", "THE AGENTS' WORK, AS THE OTHER MODELS JUDGED AND TAGGED IT:"]
        for n in job.nodes.values():
            for role, v in n.get("data", {}).get("agent_verdicts", {}).items():
                tags = sorted({t["name"] for ts in v.get("tags", {}).values() for t in ts})[:6]
                lines.append(f"- {n['level']} {role} by {v.get('model')}: {v.get('score')} "
                             f"({'used' if v.get('passed') or not v.get('by') else 'turned down'}) "
                             f"tags: {', '.join(tags) or 'none'}")
        lines += ["", "WHAT NEEDS TRAINING MOST (newest reading):"]
        needs = self.read.get("needs")
        if needs:
            lines += [f"- {row['need']:.2f}  {row['area']} — {row['why']}" for row in needs[:8]]
        else:
            lines.append("- (not measured yet)")
        final = job.row.get("final") or {}
        if final:
            lines += ["", f"FINAL EVALUATION: {final.get('score')} — passed {final.get('passed')}"]
            lines += [f"  gate: {g}" for g in final.get("gate", [])]
        self.known.setPlainText("\n".join(lines))
