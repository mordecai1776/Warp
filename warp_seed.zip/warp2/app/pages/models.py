# WARP2/warp2/app/pages/models.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/models.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/app/parts/{page,cards,table}.py, warp2/app/theme.py.
#  Description:
#    The model fleet: every model, whether it is on, what it does, how it
#    has done in its trials (pass, syntax and gate rates), its usual flaws,
#    and which context reading each is best with.
#  User intention (Andrew): the old Model Fleet tab, in the one window.
# ============================================================================
from __future__ import annotations

from warp2.app import theme
from warp2.app.parts.cards import Panel, StatCard
from warp2.app.parts.page import Page, row
from warp2.app.parts.table import Table


def _pct(value) -> str:
    """Intention: a rate as a percent, or — when there is no record."""
    return "—" if value is None else f"{float(value):.0%}"


class ModelsPage(Page):
    """The model fleet."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: counts, the fleet and the readings each is best with."""
        super().__init__("models", "Models", "Every model, what it does, and how it has done.", parent)
        self.enabled = StatCard("Enabled", colour=theme.GOOD)
        self.trials = StatCard("Trials recorded", colour=theme.ACCENT)
        self.best = StatCard("Best pass rate", colour="#F472B6")
        self.body.addLayout(row(self.enabled, self.trials, self.best))
        fleet = Panel("Fleet")
        self.table = Table(["Model", "On", "Role", "Kinds", "Trials", "Pass", "Syntax", "Gate", "Flaws"], stretch=8)
        self.table.setMinimumHeight(360)
        fleet.add(self.table)
        self.body.addWidget(fleet)
        lens = Panel("Context readings each model does best with")
        self.lens = Table(["Model", "Kind of work", "Favoured", "Trials", "Readings"], stretch=4)
        self.lens.setMinimumHeight(240)
        lens.add(self.lens)
        self.body.addWidget(lens)

    def draw(self, snap: dict) -> None:
        """Intention: the fleet joined with its trial record."""
        models = snap.get("models") or []
        analysis = {a.get("model"): a for a in snap.get("model_analysis") or []}
        on = [m for m in models if m.get("enabled", True)]
        self.enabled.set(f"{len(on)} of {len(models)}")
        trials = sum(int(a.get("total_trials") or 0) for a in analysis.values())
        self.trials.set(f"{trials:,}")
        rated = [a for a in analysis.values() if a.get("success_rate") is not None]
        top = max(rated, key=lambda a: a["success_rate"], default=None)
        self.best.set(_pct(top["success_rate"]) if top else "—", str(top.get("model")) if top else "no trials yet")
        rows, colours = [], {}
        for i, m in enumerate(models):
            a = analysis.get(m.get("name"), {})
            rows.append((m.get("name"), "yes" if m.get("enabled", True) else "no", m.get("role", ""),
                         ", ".join(m.get("kinds") or []), a.get("total_trials", 0), _pct(a.get("success_rate")),
                         _pct(a.get("syntax_rate")), _pct(a.get("gate_pass_rate")),
                         ", ".join(str(f) for f in (a.get("signature_flaws") or [])[:3])))
            colours[(i, 1)] = theme.GOOD if m.get("enabled", True) else theme.QUIET
        self.table.fill(rows, colours=colours)
        self.lens.fill([(p.get("model"), p.get("task_kind"), p.get("favoured"), p.get("trials"),
                         ", ".join(f"{k} {v}" for k, v in (p.get("readings") or {}).items()))
                        for p in snap.get("lens_profiles") or []],
                       keys=[f"{p.get('model')}|{p.get('task_kind')}" for p in snap.get("lens_profiles") or []])
