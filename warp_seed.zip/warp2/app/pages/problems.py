# WARP2/warp2/app/pages/problems.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/problems.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/store/problem_web.py (diagnose_code, classify — read only),
#              warp2/app/parts/{page,cards,table}.py, warp2/app/theme.py.
#  Description:
#    The common problems: how many incidents are recorded, the hotspots (the
#    defects seen most, coloured by how serious), the whole taxonomy as a
#    tree with how often each was seen, and a box to paste an error or some
#    code into and see what kind of problem it is and its fix.
#  User intention (Andrew): the old Problem Web tab, in the one window.
# ============================================================================
from __future__ import annotations

from PySide6.QtWidgets import QHBoxLayout, QTreeWidgetItem
from qfluentwidgets import BodyLabel, FluentIcon, PlainTextEdit, PrimaryPushButton, TreeWidget

from warp2.app import theme
from warp2.app.parts.cards import Panel, StatCard
from warp2.app.parts.page import Page, row
from warp2.app.parts.table import Table


def severity(tier: str, hits: int) -> str:
    """Intention: how serious a hotspot looks — the same rule the old tab used."""
    if hits >= 5 or tier in ("root", "pillar"):
        return theme.BAD
    if hits >= 2 or tier == "base":
        return theme.WARN
    return theme.QUIET


class ProblemsPage(Page):
    """The common problems."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the counts, the hotspots, the taxonomy and the checker."""
        super().__init__("problems", "Problems", "The problems seen, how often, and how they are fixed.", parent)
        self.total = StatCard("Incidents recorded", colour=theme.BAD)
        self.hot = StatCard("Hotspots", colour=theme.WARN)
        self.body.addLayout(row(self.total, self.hot))
        split = QHBoxLayout()
        split.setSpacing(16)
        hot = Panel("Hotspots")
        self.hotspots = Table(["Problem", "Tier", "Hits", "Fix"], stretch=0)
        self.hotspots.setMinimumHeight(380)
        hot.add(self.hotspots)
        split.addWidget(hot, 3)
        tree = Panel("Taxonomy")
        self.tree = TreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setMinimumHeight(380)
        tree.add(self.tree)
        split.addWidget(tree, 2)
        self.body.addLayout(split)
        check = Panel("What kind of problem is this?")
        self.input = PlainTextEdit()
        self.input.setPlaceholderText("Paste an error message or some code…")
        self.input.setFixedHeight(110)
        button = PrimaryPushButton(FluentIcon.SEARCH, "Check")
        button.clicked.connect(self._check)
        self.result = BodyLabel("")
        self.result.setWordWrap(True)
        check.add(self.input)
        check.add(button)
        check.add(self.result)
        self.body.addWidget(check)
        self.tree_seen = None

    def draw(self, snap: dict) -> None:
        """Intention: counts and hotspots every reading; the tree only when it changed."""
        web = snap.get("problem_web") or {}
        hotspots = web.get("hotspots") or []
        self.total.set(f"{int(web.get('total_incidents') or 0):,}")
        self.hot.set(len(hotspots))
        rows = [(h.get("name"), h.get("tier"), int(h.get("occurrences") or 0), h.get("remediation_batch", ""))
                for h in hotspots]
        self.hotspots.fill(rows, colours={(i, 0): severity(str(r[1]).lower(), r[2]) for i, r in enumerate(rows)})
        tree = web.get("root") or web.get("pillars")
        if tree != self.tree_seen:
            self.tree_seen = tree
            self.tree.clear()
            for top in ([tree] if isinstance(tree, dict) else tree or []):
                self.tree.addTopLevelItem(self._item(top))

    def _item(self, node: dict) -> QTreeWidgetItem:
        """Intention: one taxonomy node and its children, with how often it was seen."""
        hits = int(node.get("occurrences") or 0)
        item = QTreeWidgetItem([f"{node.get('name', '')}  ·  {node.get('tier', '')}" + (f"  [{hits}]" if hits else "")])
        for child in node.get("children") or []:
            item.addChild(self._item(child))
        item.setExpanded(node.get("tier") in ("root", "pillar"))
        return item

    def _check(self) -> None:
        """Intention: the pasted text classified, with its fix — the same check the old tab ran."""
        text = self.input.toPlainText().strip()
        if not text:
            self.result.setText("Paste an error message or some code first.")
            return
        try:
            from warp2.store.problem_web import ProblemWeb
            web = ProblemWeb()
            found = web.diagnose_code(text)
            direct = web.classify(text)
            if direct["node_id"] != "problem:syntax:grammar:invalid_syntax_generic" and (
                    len(found) == 1 and found[0]["node_id"] == "problem:syntax:grammar:invalid_syntax_generic"):
                found = [direct]
            lines = []
            for f in found[:2]:
                lines.append(f"{f['path']} — {f['name']} ({f['tier']}), severity {str(f.get('severity', 'none')).upper()}")
                if f.get("remediation_batch") and f["remediation_batch"] != "none":
                    lines.append(f"Fix: {f['remediation_batch']} — {f.get('description', '')}")
            self.result.setText("\n".join(lines) or "Nothing found.")
        except Exception as exc:
            self.result.setText(f"The check fell over: {exc}")
