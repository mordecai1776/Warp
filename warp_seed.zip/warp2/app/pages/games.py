# WARP2/warp2/app/pages/games.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/games.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/app/chat_centre.py (shared — the Action Centre's game
#              actions), warp2/app/parts/{page,cards}.py, warp2/app/theme.py.
#  Description:
#    The games the warp has coded: pick one and have the learning player take
#    a turn at it (in its own process), or play it by hand — arrows or WASD
#    to move, Space to wait, R to start again, P for the Eye to take a step,
#    Q to stop. The board, the score and how it went are shown as it plays.
#  User intention (Andrew): the old Game Arena, in the one window.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from qfluentwidgets import BodyLabel, ComboBox, FluentIcon, PlainTextEdit, PrimaryPushButton, PushButton

from warp2.app import theme
from warp2.app.parts.cards import KeyValue, Panel, StatCard
from warp2.app.parts.page import Page, row

# Intention: the keys that play, as the old window read them.
KEYS = {Qt.Key.Key_Up: "UP", Qt.Key.Key_Down: "DOWN", Qt.Key.Key_Left: "LEFT", Qt.Key.Key_Right: "RIGHT",
        Qt.Key.Key_W: "UP", Qt.Key.Key_S: "DOWN", Qt.Key.Key_A: "LEFT", Qt.Key.Key_D: "RIGHT",
        Qt.Key.Key_Space: "WAIT"}


class GamesPage(Page):
    """The coded games."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the chooser and buttons, the result, and the board."""
        super().__init__("games", "Games", "The games the warp coded, played by its player or by you.", parent)
        from warp2.app.chat_centre import shared
        self.centre = shared(feed)
        self.centre.bridge.game.connect(self.show_result)
        self.centre.bridge.board.connect(self.show_board)
        self.chooser = ComboBox()
        self.chooser.setMinimumWidth(240)
        self.tools.addWidget(self.chooser)
        buttons = [(FluentIcon.ROBOT, "Player takes a turn", lambda: self.centre.test_game_action(self.chooser.currentText())),
                   (FluentIcon.SYNC, "A random one", self.centre.test_random_game_action),
                   (FluentIcon.GAME, "Play it yourself", self._play),
                   (FluentIcon.VIEW, "Eye takes a step", self.centre.eye_step_game_action),
                   (FluentIcon.RETURN, "Start again", self.centre.reset_current_game),
                   (FluentIcon.CLOSE, "Stop playing", self.centre.stop_interactive_game_action)]
        line = []
        for i, (icon, words, call) in enumerate(buttons):
            button = (PrimaryPushButton if i == 0 else PushButton)(icon, words)
            button.clicked.connect(call)
            line.append(button)
        self.body.addLayout(row(*line))
        self.score = StatCard("Score", colour=theme.GOOD)
        self.steps = StatCard("Steps", colour=theme.ACCENT)
        self.outcome = StatCard("How it went", colour="#A78BFA")
        self.body.addLayout(row(self.score, self.steps, self.outcome))
        board = Panel("Board")
        self.board = PlainTextEdit()
        self.board.setReadOnly(True)
        font = QFont("Consolas")
        font.setStyleHint(QFont.StyleHint.Monospace)
        font.setPointSize(13)
        self.board.setFont(font)
        self.board.setMinimumHeight(360)
        board.add(self.board)
        self.legend = BodyLabel("Arrows or WASD move · Space waits · R starts again · P lets the Eye step · Q stops")
        self.legend.setTextColor("#64748B", "#94A3B8")
        board.add(self.legend)
        self.body.addWidget(board)
        details = Panel("Details")
        self.details = KeyValue()
        details.add(self.details)
        self.body.addWidget(details)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def showEvent(self, event) -> None:
        """Intention: the coded games listed afresh when the page is shown."""
        super().showEvent(event)
        names = self.centre._coded_game_names()
        if names != [self.chooser.itemText(i) for i in range(self.chooser.count())]:
            self.chooser.clear()
            self.chooser.addItems(names)

    def draw(self, snapshot: dict) -> None:
        """Intention: refresh coded games list from the latest system state."""
        names = self.centre._coded_game_names()
        if names != [self.chooser.itemText(i) for i in range(self.chooser.count())]:
            self.chooser.clear()
            self.chooser.addItems(names)

    def _play(self) -> None:
        """Intention: the chosen game opened to be played by hand, and the keys given to it."""
        self.centre.start_interactive_game_action(self.chooser.currentText(), mode="made")
        self.setFocus()

    def keyPressEvent(self, event) -> None:
        """Intention: while a game is being played, the keys play it."""
        if not getattr(self.centre, "_game_play_active", False):
            return super().keyPressEvent(event)
        key = event.key()
        if key in KEYS:
            self.centre.send_game_input(KEYS[key])
        elif key == Qt.Key.Key_R:
            self.centre.reset_current_game()
        elif key == Qt.Key.Key_P:
            self.centre.eye_step_game_action()
        elif key == Qt.Key.Key_Q:
            self.centre.stop_interactive_game_action()
        else:
            super().keyPressEvent(event)

    def show_board(self) -> None:
        """Intention: the board, score and state of the game being played."""
        session = getattr(self.centre, "_active_session", None)
        if session is None:
            self.outcome.set("—", "not playing")
            return
        state = "won" if session.won else ("over" if session.terminated else "playing")
        self.score.set(f"{session.score:.1f}", session.game_name)
        self.steps.set(session.steps, session.mode)
        self.outcome.set(state, session.last_message,
                         theme.GOOD if session.won else theme.WARN if session.terminated else theme.ACCENT)
        try:
            self.board.setPlainText(session.state.render_ascii())
        except Exception as exc:
            self.board.setPlainText(f"(the board could not be drawn: {exc})")

    def show_result(self, result: dict) -> None:
        """Intention: a turn the player took, as it ended."""
        score = float(result.get("score") or 0.0)
        passed = bool(result.get("is_correct", score >= 0.8))
        self.score.set(f"{int(score * 100 if score <= 1 else score)}%", result.get("game_name", ""),
                       theme.GOOD if passed else theme.WARN)
        self.steps.set(result.get("steps", "—"), "games this turn")
        self.outcome.set("won" if result.get("won") else "lost", result.get("verification_details", ""))
        self.board.setPlainText(str(result.get("final_render") or ""))
        self.details.set([("game", result.get("game_name", "")), ("details", result.get("details", "")),
                          ("code", result.get("created_copy_path", ""))])
