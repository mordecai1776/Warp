# WARP2/warp2/app/pages/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/__init__.py
#  Used by   : warp2/app/window.py.
#  Uses      : nothing itself.
#  Description:
#    The pages of the one window, one file each.
#  User intention (Andrew): the old windows' parts, in one window.
# ============================================================================
