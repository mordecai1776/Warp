# WARP2/warp2/app/pages/capabilities.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/capabilities.py
#  Used by   : warp2/app/window.py (the Capabilities tab — every capability's
#              own tab sits under it).
#  Uses      : warp2/app/capabilities.py, warp2/app/pages/capability.py (ago,
#              ENDED), warp2/app/parts/{page,cards,table,tiles,worker}.py,
#              PySide6, qfluentwidgets.
#  Description:
#    All it has and what it does: every capability in one table — what it
#    is, how many runs, how the last one ended, when — and what the warp
#    holds: its models, its projects, the knowledge graph, the Eye's parts,
#    the datasets it has refined, the training web, the record of every
#    answer. Double-click a capability to open its own tab.
#  User intention (Andrew, 2026-09-25): "So a tab for all it has and what it
#    does." "and the kg of course" "and projects and all of that kind of
#    stuff".
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.app import theme
from warp2.app.pages.capability import ENDED, ago
from warp2.app.parts.cards import Panel
from warp2.app.parts.page import Page
from warp2.app.parts.table import Table
from warp2.app.parts.tiles import HeldTile, TileGrid
from warp2.app.parts.worker import later


def holdings(state, snapshot: dict) -> list:
    """What the warp holds, as (name, how much) — each read from where it is kept.

    Intention: NOTHING GUESSED — a count that cannot be read says so.
    """
    state = Path(state)
    out = []
    models = snapshot.get("models") or []
    out.append(("Models", f"{len(models)} ({', '.join(str(m.get('name')) for m in models[:8])}"
                          f"{'…' if len(models) > 8 else ''})" if models else "none read yet"))
    projects = snapshot.get("projects") or []
    out.append(("Projects", f"{len(projects)}" if projects else "none read yet"))
    kg = snapshot.get("kg") or {}
    if kg:
        parts_list = []
        for k in ("nodes", "edges", "concepts", "findings", "skills", "webs", "problems", "proofs"):
            val = kg.get(k)
            cnt = len(val) if isinstance(val, (list, dict)) else val if isinstance(val, int) else None
            if cnt is not None:
                parts_list.append(f"{cnt:,} {k}")
        kinds = ", ".join(parts_list)
        out.append(("Knowledge graph", f"{int(kg.get('total_facts') or 0):,} facts" + (f" — {kinds}" if kinds else "")))
    else:
        out.append(("Knowledge graph", "not read yet"))
    try:
        parts = json.loads((state / "models" / "eye" / "parts.json").read_text(encoding="utf-8"))
        out.append(("The Eye", f"{len(parts)} parts and the master: {', '.join(sorted(parts)[:10])}"
                               f"{'…' if len(parts) > 10 else ''}"))
    except (OSError, ValueError):
        out.append(("The Eye", "no parts saved yet"))
    refine = state / "refine"
    sets = [p.name for p in refine.iterdir() if (p / "manifest.json").is_file()] if refine.is_dir() else []
    out.append(("Refined datasets", f"{len(sets)}"))
    blocks = state / "training" / "blocks" / "blocks.jsonl"
    out.append(("Training web", f"{_lines(blocks):,} blocks"))
    outputs = state / "training" / "outputs.jsonl"
    try:
        data = outputs.read_bytes()
        kept, graded = data.count(b'"e": "kept"'), data.count(b'"e": "graded"')
        out.append(("Every answer kept", f"{kept:,} answers, {graded:,} grades"))
    except OSError:
        out.append(("Every answer kept", "none yet"))
    try:
        bloom_data = json.loads((state / "seed" / "bloom.json").read_text(encoding="utf-8"))
        plan = bloom_data.get("plan") or {}
        rec = bloom_data.get("recommendation") or {}
        out.append((
            "Seed & hardware fit",
            f"tier {plan.get('tier', '-')} · role {rec.get('recommended_role', plan.get('eye_mode', '-'))} "
            f"· model {rec.get('recommended_model_tier', '-')}",
        ))
    except (OSError, ValueError):
        out.append(("Seed & hardware fit", "not bloomed yet"))
    try:
        golem_caps = json.loads((state / "golem" / "capabilities.json").read_text(encoding="utf-8")).get("capabilities") or {}
        proj_cnt = sum(1 for v in golem_caps.values() if isinstance(v, dict) and v.get("kind") == "project")
        out.append(("Surface Golem", f"{len(golem_caps)} capabilities ({proj_cnt} accepted from projects)"))
    except (OSError, ValueError):
        out.append(("Surface Golem", "0 capabilities yet"))
    return out


def _lines(path: Path) -> int:
    """Intention: how many lines a file has, counted in its bytes; 0 when it is not there."""
    try:
        return path.read_bytes().count(b"\n")
    except OSError:
        return 0


class CapabilitiesPage(Page):
    """All it has and what it does."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: what it holds, then every capability."""
        super().__init__("capabilities", "Capabilities", "All it has and what it does. Double-click one to open it.",
                         parent)
        from warp2.app.capabilities import Capabilities
        self.feed = feed
        self.caps = Capabilities(feed.root, feed.state)
        self.open_cap = None
        self.open_page = None
        held = Panel("What it has")
        self.held = TileGrid()
        held.add(self.held)
        self._held_was = None
        self.body.addWidget(held)
        doing = Panel("What it does")
        self.table = Table(["Capability", "Kind", "Runs", "Last ended", "Last ran", "What it is"], stretch=5)
        self.table.setMinimumHeight(520)
        self.table.cellDoubleClicked.connect(self._open)
        doing.add(self.table)
        self.body.addWidget(doing)
        self._asked = False
        self.snapshot: dict = {}

    def draw(self, snapshot: dict) -> None:
        """Intention: a new reading while showing — the holdings and every capability read again."""
        self.snapshot = snapshot
        if self._asked:
            return
        self._asked = True
        caps, state = self.caps, self.feed.state

        def gather():
            """Intention: the off-thread part — every capability with its standing, and what is held."""
            entries = caps.entries()
            known = caps.all(entries)
            rows = []
            for cap in known:
                runs = caps.runs(cap, entries, known)
                rows.append((cap, caps.standing(cap, runs)))
            return {"rows": rows, "held": holdings(state, snapshot)}
        later(gather, self._fill, lambda _w: setattr(self, "_asked", False))

    def _fill(self, got: dict) -> None:
        """Intention: both parts drawn from one reading."""
        self._asked = False
        # Intention: the tiles made again only when what it holds has changed.
        if got["held"] != self._held_was:
            self._held_was = got["held"]
            tiles = [HeldTile(name, said) for name, said in got["held"]]
            for tile in tiles:
                tile.opened.connect(lambda key: self.open_page(key) if self.open_page else None)
            self.held.fill(tiles)
        rows = got["rows"]
        colours = {(i, 3): ENDED.get(str((s["last"] or {}).get("outcome")), theme.QUIET) for i, (_c, s) in enumerate(rows)}
        self.table.fill([(c["name"], c["kind"], (s.get("record") or {}).get("runs", s["runs"]),
                          (s["last"] or {}).get("outcome", ""), ago(s["ago"]),
                          c.get("says", "")[:160]) for c, s in rows],
                        keys=[c["key"] for c, _s in rows], colours=colours)

    def _open(self, row: int, _column: int) -> None:
        """Intention: the capability's own tab opened."""
        if self.open_cap is not None and row < len(self.table.keys):
            self.open_cap(self.table.keys[row])
