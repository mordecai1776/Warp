# WARP2/warp2/app/pages/improving.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/improving.py
#  Used by   : warp2/app/window.py (second in the side menu).
#  Uses      : warp2/app/parts/{page,cards,table,tone,verdict_banner,
#              progress_charts,judge_rows}.py; draws snapshot["progress"]
#              (warp2/progress/gather.py, read by warp2/ui/snapshot.py).
#  Description:
#    "Is it improving?" — the plain answer first, then the record behind it:
#    training rounds against what each had to beat, graded answers by day,
#    each side step's measured progress, every decision point's action model
#    against its rule, how often the judges vote apart, what this run has done and where it broke, and the
#    newest changes made to the warp. Everything is read from files the warp
#    writes; a number nobody measured is shown as "—".
#  User intention (Andrew, 2026-10-16): "I want to know if the entire system's
#    improving as a whole"; "lets do that now so I can give feedback go wild
#    on the redesign but put as much care to it as has been put to the rest
#    of the warp."
# ============================================================================
from __future__ import annotations

from qfluentwidgets import CaptionLabel

from warp2.app import theme
from warp2.app.parts import tone
from warp2.app.parts.cards import KeyValue, Panel, StatCard
from warp2.app.parts.judge_rows import judge_rows, pair_rows, summary_lines
from warp2.app.parts.page import Page, row
from warp2.app.parts.progress_charts import DaysChart, RoundsChart
from warp2.app.parts.table import Table
from warp2.app.parts.verdict_banner import VerdictBanner


def explain(panel: Panel, words: str) -> CaptionLabel:
    """Intention: one quiet line under a panel's title saying how to read it."""
    line = CaptionLabel(words)
    line.setWordWrap(True)
    line.setStyleSheet("color: #94A3B8;")
    return panel.add(line)


def training_card(training: dict) -> tuple:
    """Intention: (value, caption, colour) for the training card — improved rounds, temperature delta, and slope."""
    total = int(training.get("total") or 0)
    improved = int(training.get("improved") or training.get("promoted") or 0)
    heat_val = training.get("slope") if training.get("slope") is not None else training.get("margin_heat")
    mark, words, sign = tone.arrow(heat_val)
    score, prev, delta = training.get("score"), training.get("previous_score"), training.get("delta")
    temp_part = ""
    if type(score) in (int, float) and type(delta) in (int, float):
        prev_txt = f" vs {prev:.0%}" if type(prev) in (int, float) else ""
        temp_part = f"temp {score:.0%}{prev_txt} ({delta:+.0%}) · "
    last = str(training.get("last_at") or "")[:10]
    caption = f"{temp_part}slope {mark} {words}" + (f" · last {last}" if last else "")
    return (f"{improved} of {total}", caption, theme.GOOD if improved else theme.BAD if total else theme.QUIET)


def graded_card(graded: dict) -> tuple:
    """Intention: (value, caption, colour) for the graded card — the last day's passed share and the direction."""
    days = graded.get("days") or []
    if not days:
        return ("—", "no graded answers yet", theme.QUIET)
    last = days[-1]
    mark, words, sign = tone.arrow(graded.get("pass_heat"))
    return (tone.pct(last.get("passed_share")), f"{last.get('n')} answers on {last.get('day')} · {mark} {words}",
            tone.colour(sign))


def models_card(decisions: dict) -> tuple:
    """Intention: (value, caption, colour) for the action-model card — the most-asked point, model against rule."""
    points = [p for p in decisions.get("points") or [] if p.get("scored")]
    if not points:
        return ("—", "no decision settled yet", theme.QUIET)
    top = points[0]
    model, rule = top.get("model_right"), top.get("rule_right")
    ahead = type(model) in (int, float) and type(rule) in (int, float) and model > rule
    return (f"{tone.pct(model)} vs {tone.pct(rule)}", f"{top['point']}: model vs rule, newest {top['scored']}",
            theme.GOOD if ahead else theme.WARN)


def session_card(session: dict) -> tuple:
    """Intention: (value, caption, colour) for this run — errors are what colour it."""
    if not session:
        return ("—", "no run read yet", theme.QUIET)
    errors = int(session.get("error_count") or 0)
    return (f"{session.get('ok', 0)} / {session.get('steps', 0)} ok",
            f"{errors} errors · last entry {tone.age(session.get('silent_seconds'))} ago",
            theme.BAD if errors else theme.GOOD)


def step_rows(steps: dict) -> list:
    """Intention: one row per side step — measured count, mean and spread of progress, smoothed progress, time."""
    return [[s["step"], s["measured"], tone.number(s.get("mean"), 3), tone.number(s.get("spread"), 3),
             tone.number(s.get("progress"), 3), tone.age(s.get("seconds"))] for s in steps.get("steps") or []]


def point_rows(decisions: dict) -> tuple:
    """Intention: (rows, colours) — each decision point, the rule's and the model's right share, the lead coloured."""
    rows, colours = [], {}
    for i, p in enumerate(decisions.get("points") or []):
        model, rule = p.get("model_right"), p.get("rule_right")
        lead = (model - rule) if type(model) in (int, float) and type(rule) in (int, float) else None
        rows.append([p["point"], p["asked"], p["settled"], tone.pct(rule), tone.pct(model),
                     "—" if lead is None else f"{lead:+.0%}", str(p.get("last_at") or "")[:16].replace("T", " ")])
        if lead is not None:
            colours[(i, 5)] = theme.GOOD if lead > 0 else theme.BAD if lead < 0 else theme.QUIET
    return rows, colours


def session_lines(session: dict) -> list:
    """Intention: what this run has done, as (name, words)."""
    return [("Opened", str(session.get("opened") or "—")[:19].replace("T", " ")),
            ("Steps", f"{session.get('steps', 0)} ({session.get('ok', 0)} ok, {session.get('error_count', 0)} errors)"),
            ("Last entry", f"{tone.age(session.get('silent_seconds'))} ago — {session.get('last_step') or '—'}")]


class ImprovingPage(Page):
    """Is the whole warp improving — the answer, and the record behind it."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the answer, four cards, two charts, and the tables under them."""
        super().__init__("improving", "Is it improving?",
                         "The plain answer, and the record it comes from. Nothing here is guessed.", parent)
        self.failed = CaptionLabel("")
        self.failed.setWordWrap(True)
        self.failed.setStyleSheet(f"color: {theme.WARN};")
        self.body.addWidget(self.failed)
        self.banner = VerdictBanner()
        self.body.addWidget(self.banner)
        self.training = StatCard("Training promoted")
        self.graded = StatCard("Graded answers passed")
        self.models = StatCard("Action model vs rule")
        self.session = StatCard("This run")
        self.body.addLayout(row(self.training, self.graded, self.models, self.session))
        rounds = Panel("Training rounds — pass rate against what each had to beat")
        explain(rounds, "Each dot is one finished round's held-out pass rate; the dashed line is what it had to "
                        "beat to be promoted. A star marks a promoted round. Gaps are rounds nobody measured.")
        self.rounds = rounds.add(RoundsChart())
        days = Panel("Graded answers by day")
        explain(days, "Bars: the share of answers that passed. Line: their mean score. Under each day, how "
                      "many answers it rests on — a day with few says little.")
        self.days = days.add(DaysChart())
        self.body.addLayout(row(rounds, days))
        steps = Panel("Side steps — measured progress")
        explain(steps, "Only measured progress (side_progress.json). The old made-up gains are not shown.")
        self.steps = steps.add(Table(["Step", "Measured", "Mean", "Spread", "Progress", "Time"], stretch=0))
        self.steps.setMinimumHeight(220)
        points = Panel("Action models — right more often than their rule?")
        explain(points, "Over the newest settled cases: how often the fixed rule's pick and the action "
                        "model's pick matched what really happened. A model that leads is on its way to deciding.")
        self.points = points.add(Table(["Point", "Asked", "Settled", "Rule right", "Model right", "Lead", "Last"],
                                       stretch=0))
        self.points.setMinimumHeight(220)
        self.body.addLayout(row(steps, points))
        judges = Panel("Judges — how often they vote apart")
        explain(judges, "Measurement only; nothing steers on it. A vote is read against the panel's own "
                        "verdict, not the truth, so the C-bound says how the panel hangs together.")
        self.judge_summary = judges.add(KeyValue())
        self.judges = judges.add(Table(["Judge", "Votes", "Against the verdict"], stretch=0))
        self.judges.setMinimumHeight(170)
        pairs = Panel("Pairs of judges")
        explain(pairs, "How often two judges voted apart on the same answer, busiest pairs first.")
        self.pairs = pairs.add(Table(["Judge", "Judge", "Both voted", "Apart"], stretch=0))
        self.pairs.setMinimumHeight(220)
        self.body.addLayout(row(judges, pairs))
        run = Panel("This run")
        self.run = run.add(KeyValue())
        self.errors = run.add(Table(["When", "Step", "Error", "Where it broke"], stretch=2))
        self.errors.setMinimumHeight(170)
        self.stepped = run.add(Table(["Stepped past (caught and went on)", "Times"], stretch=0))
        self.stepped.setMinimumHeight(140)
        changes = Panel("Newest changes to the warp")
        explain(changes, "From the build log — the chat and the hourly runs both write here.")
        self.changes = changes.add(Table(["#", "Change", "Day"], stretch=1))
        self.changes.setMinimumHeight(330)
        self.body.addLayout(row(run, changes))
        self.body.addStretch(1)

    def draw(self, snap: dict) -> None:
        """Intention: every part drawn from the newest reading's progress; a failed reading named at the top."""
        progress = (snap or {}).get("progress") or {}
        failed = progress.get("failed") or {}
        self.failed.setText("" if not failed else "Could not read: " + "; ".join(f"{k} ({v})" for k, v in failed.items()))
        if not progress:
            self.failed.setText("No progress reading yet — the window is still taking its first full reading.")
            return
        self.banner.set(progress.get("verdict") or {})
        training, graded = progress.get("training") or {}, progress.get("graded") or {}
        decisions, session = progress.get("decisions") or {}, progress.get("session") or {}
        for card, said in ((self.training, training_card(training)), (self.graded, graded_card(graded)),
                           (self.models, models_card(decisions)), (self.session, session_card(session))):
            card.set(said[0], said[1], said[2])
        self.rounds.set(training.get("rounds") or [])
        self.days.set(graded.get("days") or [])
        self.steps.fill(step_rows(progress.get("steps") or {}))
        rows, colours = point_rows(decisions)
        self.points.fill(rows, colours=colours)
        disagreement = progress.get("disagreement") or {}
        self.judge_summary.set(summary_lines(disagreement))
        self.judges.fill(judge_rows(disagreement))
        self.pairs.fill(pair_rows(disagreement))
        self.run.set(session_lines(session))
        self.errors.fill([[e["at"][11:19], e["step"], e["error"], e["dump"].replace("\\", "/").split("/")[-1]]
                          for e in reversed(session.get("errors") or [])],
                         colours={(i, 2): theme.BAD for i in range(len(session.get("errors") or []))})
        self.stepped.fill([[where, times] for where, times in (session.get("stepped_past") or {}).items()])
        self.changes.fill([[c["number"], c["title"], c["day"]] for c in (progress.get("changes") or {}).get("entries") or []])
