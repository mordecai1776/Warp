# WARP2/warp2/app/pages/system.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/system.py
#  Used by   : warp2/app/window.py.
#  Uses      : projects/warp_overview_maps/canonical_architecture_graph.py (the
#              same flowcharts the old System Map drew, and their live state),
#              warp2/app/parts/{page,cards,flow,worker}.py.
#  Description:
#    The system map: the warp's main loop as a flowchart, and each of its
#    parts (subsystems, pictures, games, projects, models, problems, the
#    write gateway, the Eye's co-training) on its own tab, every step lit by
#    its live state; the picked step's details beside it.
#  User intention (Andrew): the old System Map (RAPTOR), in the one window.
# ============================================================================
from __future__ import annotations

from PySide6.QtWidgets import QHBoxLayout
from qfluentwidgets import Pivot

from warp2.app.parts.cards import KeyValue, Panel
from warp2.app.parts.flow import FlowView
from warp2.app.parts.page import Page
from warp2.app.parts.worker import later

# Intention: each chart the old map had, by the builder that makes it.
CHARTS = (("main", "Main loop", "build_warp_pipeline_flowchart"),
          ("subsystems", "Subsystems", "build_subsystems_flowchart"),
          ("visual", "Pictures", "build_sub_visual_flowchart"),
          ("games", "Games", "build_sub_games_flowchart"),
          ("projects", "Projects", "build_sub_projects_flowchart"),
          ("models", "Models", "build_sub_models_flowchart"),
          ("problems", "Problems", "build_sub_problem_web_flowchart"),
          ("writes", "Write gateway", "build_sub_write_gateway_flowchart"),
          ("cotrain", "Eye co-training", "build_sub_cotrain_flowchart"))


def _chart(root, state, builder: str, snap: dict):
    """Intention: one flowchart built and lit with the live reading."""
    from projects.warp_overview_maps import canonical_architecture_graph as maps
    graph = getattr(maps, builder)(root, state)
    maps.inject_live_telemetry_into_graph(graph, snap, state)
    return graph


class SystemPage(Page):
    """The system map."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the chart tabs, the chart and the picked step."""
        super().__init__("system", "System map", "How the warp works, step by step, lit by what it is doing now.", parent)
        self.feed = feed
        self.tabs = Pivot()
        for key, words, _builder in CHARTS:
            self.tabs.addItem(routeKey=key, text=words, onClick=lambda k=key: self._switch(k))
        self.tabs.setCurrentItem("main")
        self.body.addWidget(self.tabs)
        split = QHBoxLayout()
        split.setSpacing(16)
        self.chart_panel = Panel("")
        self.flow = FlowView()
        self.flow.setMinimumHeight(640)
        self.flow.picked_step.connect(self._pick)
        self.chart_panel.add(self.flow)
        split.addWidget(self.chart_panel, 3)
        self.step_panel = Panel("Picked step")
        self.step = KeyValue()
        self.step_panel.add(self.step)
        split.addWidget(self.step_panel, 1)
        self.body.addLayout(split)
        self.current = "main"
        self.graph = None
        self.snap: dict = {}

    def _switch(self, key: str) -> None:
        """Intention: another chart shown."""
        self.current = key
        self.graph = None
        self.draw(self.snap, moved=True)

    def draw(self, snap: dict, moved: bool = False) -> None:
        """Intention: the chart built and lit off the window's thread, then drawn."""
        self.snap = snap
        builder = dict((k, b) for k, _w, b in CHARTS)[self.current]
        root, state, key = self.feed.root, self.feed.state, self.current
        later(lambda: (key, _chart(root, state, builder, snap)), lambda answer: self._show(answer, not moved))

    def _show(self, answer, keep: bool) -> None:
        """Intention: the chart drawn; only its states changed when it is the same chart."""
        key, graph = answer
        if key != self.current:
            return
        self.graph = graph
        self.chart_panel.heading.setText(f"{graph.title} — {graph.description}")
        steps = [{"key": n.id, "title": f"{n.icon} {n.title}".strip(), "line": n.subtitle or n.status_label,
                  "state": str(getattr(n.status, "value", n.status)), "badge": n.status_label}
                 for n in graph.nodes.values()]
        links = [(e.source, e.target, e.is_loopback) for e in graph.edges]
        self.flow.show_flow(steps, links, keep_view=keep)

    def _pick(self, key: str) -> None:
        """Intention: the picked step's title, state, where its code is, and its details."""
        node = self.graph.nodes.get(key) if self.graph else None
        if node is None:
            return
        pairs = [("step", node.title), ("state", node.status_label or str(getattr(node.status, "value", node.status))),
                 ("what", node.subtitle), ("code", node.source_file or "—"), ("kind", node.category)]
        pairs += [(k, str(v)[:160]) for k, v in (node.details or {}).items()]
        self.step.set(pairs)
