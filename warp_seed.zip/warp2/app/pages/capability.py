# WARP2/warp2/app/pages/capability.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/capability.py
#  Used by   : warp2/app/window.py (one of these for every capability the warp
#              has, made as each is found).
#  Uses      : warp2/app/capabilities.py (what the capability is and every run
#              of it), warp2/app/parts/{page,cards,table,worker}.py,
#              PySide6, qfluentwidgets.
#  Description:
#    One capability, all of it: what it is and what its code says it is for,
#    how it stands (runs, how they ended, how long they take, when it last
#    ran, what that costs as measured), every run the journals hold — pick
#    one and everything the warp wrote down about it is shown whole — and,
#    for a kind of work, how its graded answers went and the faults said
#    most often. Read off the window's thread, each time it is shown and on
#    each new reading while it is showing.
#  User intention (Andrew, 2026-09-25): "we need have ones to watch what it
#    dose whit as much info about that thing that we can have it give."
# ============================================================================
from __future__ import annotations

import json

from PySide6.QtWidgets import QHBoxLayout
from qfluentwidgets import PlainTextEdit

from warp2.app import theme
from warp2.app.parts.cards import KeyValue, Panel, StatCard
from warp2.app.parts.page import Page, row
from warp2.app.parts.table import Table
from warp2.app.parts.worker import later

# Intention: the colour of each way a run can end.
ENDED = {"ok": theme.GOOD, "noted": theme.QUIET, "opened": theme.QUIET, "sealed": theme.QUIET,
         "failed": theme.BAD, "error": theme.BAD, "refused": theme.WARN, "cancelled": theme.WARN,
         "halted": theme.WARN, "already_done": theme.QUIET,
         # Intention (2026-11-08, BUILD_LOG 1455): outcomes the journals really write, which drew grey here while
         # the home page drew "passed" green.
         "passed": theme.GOOD, "done": theme.GOOD, "written": theme.GOOD, "unchanged": theme.QUIET,
         "broken_test": theme.BAD, "invalid_test": theme.BAD}


def ago(seconds) -> str:
    """Intention: how long ago, in the words a person would use."""
    if seconds is None:
        return "never"
    seconds = max(0.0, float(seconds))
    if seconds < 90:
        return f"{int(seconds)}s ago"
    if seconds < 5400:
        return f"{int(seconds // 60)}m ago"
    if seconds < 172800:
        return f"{seconds / 3600:.1f}h ago"
    return f"{seconds / 86400:.1f} days ago"


def said_of(entry: dict) -> str:
    """Intention: one line of what a run said — its error, else what it returned."""
    if entry.get("error"):
        return str(entry["error"]).splitlines()[0][:200]
    value = entry.get("value")
    if isinstance(value, dict):
        for key in ("said", "why", "did", "status"):
            if value.get(key):
                return str(value[key])[:200]
        return json.dumps(value, default=str)[:200]
    return "" if value is None else str(value)[:200]


class CapabilityPage(Page):
    """Everything about one capability."""

    def __init__(self, feed, cap: dict, parent=None) -> None:
        """Intention: what it is, how it stands, every run, and its graded answers."""
        super().__init__(f"cap-{cap['key'].replace(':', '-')}", cap["name"], cap.get("says") or "", parent)
        from warp2.app.capabilities import Capabilities
        self.feed, self.cap = feed, cap
        self.caps = Capabilities(feed.root, feed.state)
        self.says.setWordWrap(True)
        self.what = Panel("What it is")
        self.facts = KeyValue()
        self.what.add(self.facts)
        self.body.addWidget(self.what)
        self.cards = {name: StatCard(name) for name in ("Runs", "Ended well", "Ended badly", "Takes", "Last ran")}
        self.body.addLayout(row(*self.cards.values()))
        runs = Panel("Every run the record holds (pick one to see all of it)")
        split = QHBoxLayout()
        self.runs = Table(["When", "Lane", "Step", "Ended", "Seconds", "On", "Said"], stretch=6)
        self.runs.setMinimumHeight(360)
        self.runs.itemSelectionChanged.connect(self._pick)
        split.addWidget(self.runs, 3)
        self.detail = PlainTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setMinimumWidth(360)
        split.addWidget(self.detail, 2)
        runs.body.addLayout(split)
        self.body.addWidget(runs)
        self.graded_panel = Panel("How its answers were graded")
        self.graded = KeyValue()
        self.faults = Table(["Fault", "Times"], stretch=0)
        self.faults.setMinimumHeight(200)
        self.graded_panel.add(self.graded)
        self.graded_panel.add(self.faults)
        self.body.addWidget(self.graded_panel)
        self.graded_panel.setVisible(cap["kind"] == "work")
        self.shown_runs: dict = {}
        self._asked = False

    def draw(self, snapshot: dict) -> None:
        """Intention: a new reading while it is showing — the record read again, off the window's thread."""
        self.read()

    def read(self) -> None:
        """Intention: the capability's record read in the background, then drawn; one reading at a time."""
        if self._asked:
            return
        self._asked = True
        caps, cap = self.caps, self.cap

        def gather():
            """Intention: the off-thread part — this capability's runs and its standing from them."""
            entries = caps.entries()
            known = caps.all(entries)
            runs = caps.runs(cap, entries, known)
            return {"runs": runs, "standing": caps.standing(cap, runs)}
        later(gather, self._fill, lambda _w: setattr(self, "_asked", False))

    def _fill(self, got: dict) -> None:
        """Intention: every part drawn from one reading."""
        self._asked = False
        cap, standing, runs = self.cap, got["standing"], got["runs"]
        self.facts.set([("Kind", cap["kind"]), ("Its code", cap.get("code", "")),
                        ("What its code says it is", cap.get("about") or cap.get("says") or "—"),
                        ("What it is for", cap.get("for") or "—"),
                        ("Measured cost", "; ".join(f"{v}: {c.get('mean', 0):.1f}s over {c.get('n', 0)}"
                                                    for v, c in standing["cost"].items()) or "not measured yet")])
        outcomes = standing["outcomes"]
        good = sum(n for o, n in outcomes.items() if ENDED.get(o) in (theme.GOOD, theme.QUIET))
        bad = sum(n for o, n in outcomes.items() if ENDED.get(o) in (theme.BAD, theme.WARN))
        # Intention (2026-10-02): the numbers are the whole record
        # (warp2/app/record_index.py); the recent window only says how many of
        # them are recent — it used to be all that was counted.
        record = standing.get("record") or {}
        self.cards["Runs"].set(f"{record.get('runs', standing['runs']):,}",
                               f"in all · {standing['runs']:,} in the recent record")
        self.cards["Ended well"].set(f"{record.get('ok', good):,}",
                                     f"last {str(record.get('last_ok') or '')[:10] or 'never'} · recent: "
                                     + (", ".join(f"{o} {n}" for o, n in outcomes.items()
                                                  if ENDED.get(o) in (theme.GOOD, theme.QUIET)) or "—"),
                                     theme.GOOD)
        errors = record.get("errors", bad)
        self.cards["Ended badly"].set(f"{errors:,}", "errors in all · recent: " + (
            ", ".join(f"{o} {n}" for o, n in outcomes.items() if ENDED.get(o) in (theme.BAD, theme.WARN)) or "—"),
                                      theme.BAD if errors else theme.QUIET)
        mean = standing["mean_seconds"]
        self.cards["Takes"].set(f"{mean:.1f}s" if mean is not None else "—", "on average, per run")
        self.cards["Last ran"].set(ago(standing["ago"]), str((standing["last"] or {}).get("outcome") or ""))
        shown = runs[:400]
        self.shown_runs = {str(e.get("hash") or i): e for i, e in enumerate(shown)}
        colours = {(i, 3): ENDED.get(str(e.get("outcome")), theme.QUIET) for i, e in enumerate(shown)}
        self.runs.fill([(str(e.get("ts") or "")[:19].replace("T", " "), e.get("lane"), e.get("verb"),
                         e.get("outcome"), e.get("seconds"), str(e.get("target") or "")[-60:], said_of(e))
                        for e in shown], keys=list(self.shown_runs), colours=colours)
        graded = standing.get("graded") or {}
        if graded:
            self.graded.set([("Passed", graded.get("passed", 0)), ("Failed", graded.get("failed", 0))])
            self.faults.fill([(f, n) for f, n in graded.get("faults", [])])
        if not self.runs.picked() and shown:
            self.runs.selectRow(0)

    def _pick(self) -> None:
        """Intention: the picked run shown whole — everything the warp wrote down about it."""
        entry = self.shown_runs.get(self.runs.picked())
        if entry is None:
            return
        whole = {k: v for k, v in entry.items() if k not in ("prev", "hash")}
        self.detail.setPlainText(json.dumps(whole, indent=2, default=str, ensure_ascii=False))

    def showEvent(self, event) -> None:
        """Intention: read fresh whenever it is shown."""
        super().showEvent(event)
        self.read()

