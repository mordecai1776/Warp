# WARP2/warp2/app/pages/eye_tree.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/eye_tree.py
#  Used by   : warp2/app/window.py (the Eye tree tab).
#  Uses      : state/models/eye/hierarchy.json (written by the Eye on every
#              save — projects/behemoth_eye/eye/hierarchy/summary.py), read
#              small through warp2/app/parts/eye_digest.py (BUILD_LOG 1477),
#              warp2/app/parts/{page,cards,tree_view,relation_bars,
#              tiles,worker,eye_digest}.py,
#              PySide6, qfluentwidgets; (stdlib) json, pathlib.
#  Description:
#    THE EYE'S HIERARCHY, SEEN. For the concept side or the action side:
#      * a row of numbers — groups, proven cuts, cuts whose sides are
#        opposites, relations that stand, how new the last looks were
#        (the mean gap), group pairs;
#      * the tree itself, drawn (parts/tree_view.py) — click a group;
#      * the picked group: how it was cut and what the cut gained on
#        held-back looks, its two sides compared whole, its tokens, and the
#        strongest ties among its names, as bars;
#      * the strongest synonyms and opposites the Eye has, as bars;
#      * one name, picked from the list: what it goes with and against (and
#        how alike the activation layer's answer is to its own — the link),
#        and the proven mix of other names it is (plus and minus weights);
#      * the scale the real concepts set (the closest two) and how many
#        models are too close and will merge;
#      * one task (a smaller one): its concept, how its concept thing and
#        its action thing have done, which one answers, what it uses — and
#        the tree dimmed to what it uses.
#    (What the Eye used at each moment was shown down the right until
#    2026-11-09 - Andrew: "lets get rid of the eye in use now"; BUILD_LOG 1480. It is in archive/2026-11-09_lean_window_and_room/.)
#    Only what is needed to understand it; everything as a picture first.
#    The file is read again only when the Eye has written it again.
#  User intention (Andrew, 2026-09-25): "Add an Eye tree tab" — "The shown
#    data needs to be pruned out to what is needed to understand with more of
#    a visuals centered concept". (2026-09-26) "the eye tab should have and
#    active thing constant on the right like the warp" — "it should show the
#    one in use that can be navigated through."
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtWidgets import QBoxLayout, QHBoxLayout, QVBoxLayout, QWidget
from qfluentwidgets import BodyLabel, ComboBox, SegmentedWidget

from warp2.app import theme
from warp2.app.parts.cards import KeyValue, Panel, StatCard
from warp2.app.parts.page import Page
from warp2.app.parts.relation_bars import RelationBars
from warp2.app.parts.tiles import TileGrid
from warp2.app.parts.tree_view import TreeView, label_of, opposite
from warp2.app.parts.worker import later

# Intention: how many bars a list shows — as many as can be read at a glance.
BARS = 12

# Intention: the sides, as a person names them.
SIDES = (("concepts", "Concepts"), ("actions", "Actions"))


def read(path: Path) -> dict:
    """Intention: the hierarchy the Eye last wrote, its relations as one small table (parts/eye_digest.py); {} when
    there is none yet. BUILD_LOG 1477: the 96 MB file is read in a process of its own, never in the window."""
    from warp2.app.parts.eye_digest import read_digest
    return read_digest(Path(path).parents[2])


def nodes(tree: dict | None) -> dict:
    """Intention: every group of a tree by its uid."""
    out, stack = {}, [tree] if tree else []
    while stack:
        node = stack.pop()
        out[int(node["uid"])] = node
        stack.extend(node.get("sides") or [])
    return out


def strongest(relations, among: set | None = None) -> list:
    """Intention: [(a, b, weight)] with the most weight, either way — among some names only, when given; as many as
    a list shows at a glance (BARS)."""
    from warp2.app.parts.eye_digest import Relations, relations_of
    table = relations if isinstance(relations, Relations) else relations_of({"relations": relations})
    return table.strongest(among, BARS)


def short(name: str) -> str:
    """Intention: a name short enough for a bar."""
    name = str(name)
    return name if len(name) <= 34 else name[:32] + "…"


class EyeTreePage(QWidget):
    """The Eye tab: the tree and the relations."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the page that scrolls, drawn again when the Eye writes."""
        super().__init__(parent)
        self.setObjectName("eye_tree")
        line = QHBoxLayout(self)
        line.setContentsMargins(0, 0, 0, 0)
        line.setSpacing(0)
        self.view = EyeTreeView(feed)
        line.addWidget(self.view, 1)
        feed.standing.connect(self.view.draw)

    def take(self, snapshot: dict) -> None:
        """Intention: a reading handed to the page that draws it."""
        self.view.take(snapshot)


class EyeTreeView(Page):
    """The Eye's hierarchy and relations, drawn."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the side switch, the numbers, the tree with the picked group, then the relations."""
        super().__init__("eye_tree_view", "Eye tree",
                         "How the Eye's parts group, split and oppose each other, as it learns them.", parent)
        self.path = Path(feed.state) / "models" / "eye" / "hierarchy.json"
        self.stamp = None
        self.data: dict = {}
        self._asked = False
        self.side = "concepts"
        self.switch = SegmentedWidget()
        for key, words in SIDES:
            self.switch.addItem(key, words, onClick=lambda _c=False, k=key: self._side(k))
        self.switch.setCurrentItem("concepts")
        self.tools.addWidget(self.switch)
        self.cards = {key: StatCard(title, "—", caption, colour) for key, title, caption, colour in (
            ("groups", "Groups", "found in the relations", theme.ACCENT),
            ("cuts", "Proven cuts", "held-back looks agree", "#A78BFA"),
            ("opposite", "Opposite cuts", "two sides that are opposites", theme.BAD),
            ("relations", "Relations", "that stand", theme.GOOD),
            ("gap", "How new", "last looks vs what it has", theme.WARN),
            ("pairs", "Group pairs", "hidden pairs of their own", theme.GOOD),
            ("spacing", "Real spacing", "closest two real concepts", "#F472B6"),
            ("close", "Too close", "models to merge", theme.WARN))}
        # Intention: THE PAGE FITS THE WIDTH IT HAS — the numbers wrap onto
        # more rows, and each pair of panels stands side by side only while
        # both fit (the Eye tab has two views down its right).
        self.card_grid = TileGrid(tile_width=170)
        self.card_grid.fill(list(self.cards.values()))
        self.body.addWidget(self.card_grid)
        middle = QBoxLayout(QBoxLayout.Direction.LeftToRight)
        middle.setSpacing(16)
        tree_panel = Panel("The tree — click a group")
        self.tree = TreeView()
        self.tree.setMinimumHeight(520)
        self.tree.picked.connect(self._pick)
        tree_panel.add(self.tree)
        self.key_note = BodyLabel("blue: cut by kind   violet: cut by side   grey: not cut   "
                                  "green ring: has its own pair   red dash: sides are opposites")
        self.key_note.setTextColor("#64748B", "#94A3B8")
        tree_panel.add(self.key_note)
        middle.addWidget(tree_panel, 3)
        group = QVBoxLayout()
        self.group_panel = Panel("Pick a group")
        self.group_facts = KeyValue()
        self.group_panel.add(self.group_facts)
        self.group_bars = RelationBars("its names have no ties that stand yet")
        self.group_panel.add(self.group_bars)
        group.addWidget(self.group_panel)
        group.addStretch(1)
        middle.addLayout(group, 2)
        self.body.addLayout(middle)
        bottom = QBoxLayout(QBoxLayout.Direction.LeftToRight)
        bottom.setSpacing(16)
        ties = Panel("Strongest synonyms (green) and opposites (red)")
        self.ties = RelationBars("no relation stands yet")
        ties.add(self.ties)
        bottom.addWidget(ties, 1)
        one = Panel("One name")
        self.name_pick = ComboBox()
        self.name_pick.currentTextChanged.connect(self._name)
        one.corner.addWidget(self.name_pick)
        self.name_ties = RelationBars("pick a name")
        one.add(self.name_ties)
        self.mix_note = BodyLabel("")
        self.mix_note.setTextColor("#64748B", "#94A3B8")
        one.add(self.mix_note)
        self.mix_bars = RelationBars("no proven mix yet")
        one.add(self.mix_bars)
        bottom.addWidget(one, 1)
        self.body.addLayout(bottom)
        # Intention: ONE TASK — a smaller one: its concept, how its concept
        # thing and its action thing have done, whether its action thing
        # answers yet, and everything it uses; picking it dims the groups
        # of the tree it does not use.
        self.task_panel = Panel("One task")
        self.task_pick = ComboBox()
        self.task_pick.currentTextChanged.connect(self._task)
        self.task_panel.corner.addWidget(self.task_pick)
        self.task_facts = KeyValue()
        self.task_panel.add(self.task_facts)
        self.task_bars = RelationBars("pick a task")
        self.task_panel.add(self.task_bars)
        self.body.addWidget(self.task_panel)
        self.body.addStretch(1)
        self.rows = ((middle, (tree_panel, self.group_panel)), (bottom, (ties, one)))

    def resizeEvent(self, event) -> None:
        """Intention: each pair of panels side by side while both fit their least width, else one above the other."""
        super().resizeEvent(event)
        room = self.viewport().width() - 72
        for line, panels in self.rows:
            wanted = sum(max(p.minimumSizeHint().width(), p.minimumWidth()) for p in panels) + line.spacing()
            direction = QBoxLayout.Direction.LeftToRight if room >= wanted else QBoxLayout.Direction.TopToBottom
            if line.direction() != direction:
                line.setDirection(direction)

    def draw(self, _snapshot: dict) -> None:
        """Intention: the file read again, off the window's thread, only when the Eye has written it again."""
        try:
            stamp = self.path.stat().st_mtime_ns
        except OSError:
            stamp = None
        if self._asked or (stamp == self.stamp and self.data):
            return
        self._asked = True

        def received(data):
            """Intention: the Eye tree came back — allow the next read, and fill only when there is data."""
            self._asked = False
            if data:
                self.stamp = stamp
                self._fill(data)
        later(lambda: read(self.path), received, lambda _w: setattr(self, "_asked", False))

    def _side(self, key: str) -> None:
        """Intention: the other side shown."""
        self.side = key
        self._fill(self.data)

    def _fill(self, data: dict) -> None:
        """Intention: the numbers, the tree, the strongest ties and the name list, for the side shown."""
        self.data = data or {}
        side = self.data.get(self.side) or {}
        tree = side.get("tree")
        groups = nodes(tree)
        cut = [n for n in groups.values() if n.get("sides")]
        from warp2.app.parts.eye_digest import relations_of
        relations = relations_of(side)
        self.cards["groups"].set(len(groups))
        self.cards["cuts"].set(len(cut), f"{sum(1 for n in cut if n.get('cut') == 'kinds')} by kind, "
                                         f"{sum(1 for n in cut if n.get('cut') == 'sides')} by side")
        self.cards["opposite"].set(sum(1 for n in cut if opposite(n)))
        self.cards["relations"].set(f"{len(relations):,}", f"from {int(side.get('sets') or 0):,} sets of looks")
        self.cards["gap"].set(f"{float(side.get('gap') or 0.0):.2f}", "0 = nothing new, 1 = all new")
        self.cards["pairs"].set(int(side.get("pairs_made") or 0))
        known = side.get("space") or {}
        closest = known.get("closest_real")
        self.cards["spacing"].set("—" if closest is None else f"{float(closest):.2f}",
                                  "no two real concepts measured yet" if closest is None else
                                  f"usual {float(known.get('usual_real') or 0):.2f} · 0 alike, 2 opposite")
        self.cards["close"].set(len(known.get("too_close") or []), "models to merge")
        if known.get("current") is False:
            note = ("prior scale" if closest is not None else "scale unmeasured")
            note += f" · {known.get('deferred_pairs', 0)} pairs deferred"
            self.cards["spacing"].set("—" if closest is None else f"{float(closest):.2f}", note)
            self.cards["close"].set(len(known.get("too_close") or []) if closest is not None else "—", note)
        self.tree.show_tree(tree)
        self.ties.set([(f"{short(a)}  ·  {short(b)}", v) for a, b, v in strongest(relations)])
        names = sorted(set(relations.named()) | set((tree or {}).get("members") or []))
        current = self.name_pick.currentText()
        self.name_pick.blockSignals(True)
        self.name_pick.clear()
        self.name_pick.addItems(names)
        if current in names:
            self.name_pick.setCurrentText(current)
        self.name_pick.blockSignals(False)
        self._name(self.name_pick.currentText())
        tasks = sorted((self.data.get("tasks") or {}))
        current = self.task_pick.currentText()
        self.task_pick.blockSignals(True)
        self.task_pick.clear()
        self.task_pick.addItems(["all of the Eye"] + tasks)
        if current in tasks:
            self.task_pick.setCurrentText(current)
        self.task_pick.blockSignals(False)
        self._task(self.task_pick.currentText())
        if self.tree.chosen in groups:
            self._pick(self.tree.chosen)
        elif tree:
            self.tree.pick(int(tree["uid"]))

    def _pick(self, uid: int) -> None:
        """Intention: one group shown — how it was cut, its sides whole, its tokens, its strongest ties."""
        side = self.data.get(self.side) or {}
        node = nodes(side.get("tree")).get(int(uid))
        if node is None:
            return
        members = node.get("members") or []
        self.group_panel.heading.setText(f"Group {node['uid']} — {label_of(node)} ({len(members)} names)")
        tokens = sorted(node.get("tokens") or {}, key=lambda t: -(node["tokens"][t][0] * (1 - node["tokens"][t][1])))
        if node.get("sides"):
            how = f"by {'kind' if node.get('cut') == 'kinds' else 'side'} · proven {float(node.get('held', 0)):.2f}"
            whole = float(node.get("combined", 0.0))
            word = "opposites" if opposite(node) else "unrelated kinds" if node.get("cut") == "kinds" else "related"
            sides = f"{word} {whole:+.2f} · {len(node['sides'][0]['members'])} | {len(node['sides'][1]['members'])}"
        else:
            how, sides = "not cut", "—"
        self.group_facts.set([("Cut", how), ("Its two sides, whole", sides),
                              ("Its own pair", node.get("pair") or "none yet"),
                              ("Tokens here", ", ".join(tokens[:6]) + (" …" if len(tokens) > 6 else "") or "none"),
                              ("Names", ", ".join(short(m) for m in members[:6]) + (" …" if len(members) > 6 else ""))])
        self.group_bars.set([(f"{short(a)}  ·  {short(b)}", v)
                             for a, b, v in strongest(side.get("relations") or [], set(members))])

    def _task(self, part: str) -> None:
        """Intention: one task shown — its two things' record, what it uses as bars — and the tree's other groups dimmed."""
        task = (self.data.get("tasks") or {}).get(part)
        if not task:
            self.task_facts.set([("Task", "all of the Eye — pick one to see a smaller one")])
            self.task_bars.set([])
            for dot in self.tree.dots.values():
                dot.setOpacity(1.0)
            return
        record = task.get("record") or {}
        times = int(record.get("times", 0))
        self.task_facts.set([
            ("Its concept", task.get("concept", "")),
            ("Concept thing right", f"{record.get('concepts', 0)} of {times}"),
            ("Action thing right", f"{record.get('action', 0)} of {times}"),
            ("Answers with", "its action thing (proven)" if task.get("proven") else "its concepts (action thing not proven yet)")])
        used = task.get("used") or {}
        most = max(used.values(), default=1) or 1
        self.task_bars.set([(short(n), c / most) for n, c in sorted(used.items(), key=lambda kv: -kv[1])[:BARS]])
        mine = set(used)
        for uid, node in nodes((self.data.get("concepts") or {}).get("tree")).items():
            if uid in self.tree.dots:
                self.tree.dots[uid].setOpacity(1.0 if mine & set(node.get("members") or []) else 0.25)

    def _name(self, name: str) -> None:
        """Intention: one name — what it goes with and against, and the mix of others it is."""
        side = self.data.get(self.side) or {}
        if not name:
            self.name_ties.set([])
            self.mix_bars.set([])
            self.mix_note.setText("")
            return
        from warp2.app.parts.eye_digest import relations_of
        mine = relations_of(side).ties(name, BARS)
        link = (side.get("link") or {}).get(name)
        if link:
            mine = [("the activation layer (link)", float(link["link"]))] + mine
        self.name_ties.set([(short(o), v) for o, v in sorted(mine, key=lambda r: -abs(r[1]))[:BARS]])
        found = (side.get("mixes") or {}).get(name)
        if found:
            self.mix_note.setText(f"As a mix of others — explains {float(found['held']):.0%} of looks it never learned from:")
            parts = sorted(found["parts"].items(), key=lambda kv: -abs(kv[1]))[:BARS]
            self.mix_bars.set([(short(p), w) for p, w in parts])
        else:
            self.mix_note.setText("No proven mix of other names yet.")
            self.mix_bars.set([])
