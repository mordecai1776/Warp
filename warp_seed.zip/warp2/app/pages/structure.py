# WARP2/warp2/app/pages/structure.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/structure.py
#  Used by   : warp2/app/window.py (the Code structure tab).
#  Uses      : warp2/app/code_map.py (CodeMap — the tree, each file's header,
#              parts and links), warp2/app/parts/{page,cards,table,worker}.py,
#              PySide6, qfluentwidgets.
#  Description:
#    The warp's code, folder by folder. Pick a file and see its header — its
#    pathway, what it is, what it is for — every class and function in it
#    with the first line of what each says it is for, what it uses and what
#    uses it (from its header and from the imports in the code). Double-click
#    a file it uses, or one that uses it, to go there; the search box finds a
#    file by any part of its path.
#  User intention (Andrew, 2026-09-25): "also we need to add in the code
#    structure like was in there before it should be a tab" — "we need the
#    structure and all that in there".
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QTreeWidgetItem, QVBoxLayout
from qfluentwidgets import SearchLineEdit, TreeWidget

from warp2.app.parts.cards import KeyValue, Panel
from warp2.app.parts.page import Page
from warp2.app.parts.table import Table
from warp2.app.parts.worker import later

# Intention: where the file a tree item stands for is kept on it.
PATH_ROLE = Qt.ItemDataRole.UserRole


class StructurePage(Page):
    """The code, folder by folder, and everything about one file."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the tree and search on the left, the picked file on the right."""
        super().__init__("structure", "Code structure",
                         "Every file of the warp: what it is, what is in it, what it uses and what uses it.", parent)
        from warp2.app.code_map import CodeMap
        self.map = CodeMap(feed.root)
        split = QHBoxLayout()
        split.setSpacing(16)
        left = QVBoxLayout()
        self.search = SearchLineEdit()
        self.search.setPlaceholderText("Find a file by any part of its path")
        self.search.textChanged.connect(self._filter)
        left.addWidget(self.search)
        self.tree = TreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setMinimumHeight(720)
        self.tree.itemClicked.connect(self._clicked)
        left.addWidget(self.tree)
        split.addLayout(left, 2)
        right = QVBoxLayout()
        self.header_panel = Panel("Pick a file")
        self.header = KeyValue()
        self.header_panel.add(self.header)
        right.addWidget(self.header_panel)
        parts = Panel("What is in it")
        self.parts = Table(["Kind", "Name", "Line", "What it says it is for"], stretch=3)
        self.parts.setMinimumHeight(300)
        parts.add(self.parts)
        right.addWidget(parts)
        links = QHBoxLayout()
        uses = Panel("What it uses (double-click to go there)")
        self.uses = Table(["File"], stretch=0)
        self.uses.setMinimumHeight(220)
        self.uses.cellDoubleClicked.connect(lambda r, _c: self.show_file(self.uses.keys[r]))
        uses.add(self.uses)
        used = Panel("What uses it")
        self.used = Table(["File", "Said by"], stretch=0)
        self.used.setMinimumHeight(220)
        self.used.cellDoubleClicked.connect(lambda r, _c: self.show_file(self.used.keys[r]))
        used.add(self.used)
        links.addWidget(uses)
        links.addWidget(used)
        right.addLayout(links)
        split.addLayout(right, 3)
        self.body.addLayout(split)
        self.items: dict = {}
        self.built = False

    def showEvent(self, event) -> None:
        """Intention: the tree built the first time the page is shown, off the window's thread."""
        super().showEvent(event)
        if not self.built:
            self.built = True
            later(self.map.tree, self._build)

    def _build(self, tree: dict) -> None:
        """Intention: the folders and files as a tree, folders first."""
        self.tree.clear()
        self.items = {}

        def add(parent, level: dict) -> None:
            """Intention: add one folder level to the tree (folders first), keeping each file's item by its path."""
            for name in sorted(level, key=lambda n: (not n.endswith("/"), n)):
                item = QTreeWidgetItem([name])
                if isinstance(level[name], dict):
                    add(item, level[name])
                else:
                    item.setData(0, PATH_ROLE, level[name])
                    self.items[level[name]] = item
                if parent is None:
                    self.tree.addTopLevelItem(item)
                else:
                    parent.addChild(item)
        add(None, tree)

    def _filter(self, words: str) -> None:
        """Intention: only the files whose path holds the words, with the folders they are in."""
        words = str(words or "").strip().lower()
        for path, item in self.items.items():
            match = not words or words in path.lower()
            item.setHidden(not match)
            parent = item.parent()
            while parent is not None:
                if match:
                    parent.setHidden(False)
                    parent.setExpanded(bool(words))
                parent = parent.parent()
        if words:
            for item in self._folders():
                item.setHidden(not self._any_shown(item))

    def _folders(self) -> list:
        """Intention: every folder item in the tree."""
        out, stack = [], [self.tree.topLevelItem(i) for i in range(self.tree.topLevelItemCount())]
        while stack:
            item = stack.pop()
            if item.childCount():
                out.append(item)
                stack.extend(item.child(i) for i in range(item.childCount()))
        return out

    def _any_shown(self, item) -> bool:
        """Intention: whether a folder holds any file still shown."""
        for i in range(item.childCount()):
            child = item.child(i)
            if child.childCount() and self._any_shown(child):
                return True
            if not child.childCount() and not child.isHidden():
                return True
        return False

    def _clicked(self, item, _column: int) -> None:
        """Intention: a file clicked is shown."""
        path = item.data(0, PATH_ROLE)
        if path:
            self.show_file(path)

    def show_file(self, path: str) -> None:
        """Intention: one file read off the window's thread — its header, parts and both kinds of link."""
        item = self.items.get(path)
        if item is not None:
            self.tree.setCurrentItem(item)
            self.tree.scrollToItem(item)
        mapped = self.map

        def read():
            """Intention: the off-thread part — the file's header and parts, plus the files that import it."""
            got = mapped.read(path)
            got["importers"] = mapped.importers(path)
            return got
        later(read, self._show)

    def _show(self, got: dict) -> None:
        """Intention: the file drawn."""
        header = got.get("header") or {}
        self.header_panel.heading.setText(got["path"])
        self.header.set([("Pathway", header.get("Pathway") or got["path"]),
                         ("What it is", header.get("Description") or "no header says"),
                         ("What it is for", header.get("User intention") or "—"),
                         ("Lines", got.get("lines", 0))])
        self.parts.fill([(p["kind"], p["name"], p["line"], p["says"]) for p in got.get("parts") or []],
                        keys=[f"{p['name']}:{p['line']}" for p in got.get("parts") or []])
        uses = got.get("uses") or []
        self.uses.fill([(u,) for u in uses], keys=uses)
        said = set(got.get("used_by") or [])
        imported = set(got.get("importers") or [])
        both = sorted(said | imported)
        self.used.fill([(u, "header and imports" if u in said and u in imported else
                         ("header" if u in said else "imports")) for u in both], keys=both)

    def draw(self, snapshot: dict) -> None:
        """Intention: code structure updates when files in tree are added or modified."""
        pass
