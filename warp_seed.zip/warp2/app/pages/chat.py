# WARP2/warp2/app/pages/chat.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/pages/chat.py
#  Used by   : warp2/app/window.py.
#  Uses      : warp2/app/chat_centre.py (QtCentre — the Action Centre's
#              rules), warp2/ask/window.py (turn_is_shown), warp2/ask/thread.py
#              (ANDREW), qfluentwidgets, warp2/app/theme.py.
#  Description:
#    Talking to the warp, laid out like a chat app of today: on the left a new
#    chat button, the projects and the past chats (each can be opened or
#    deleted); in the middle the conversation as bubbles, his on the right and
#    the warp's on the left, with its pictures, and copy on each; under it,
#    when something is offered to store, a bar asking yes or no; at the
#    bottom the box he types in (Enter sends, Shift+Enter is a new line) with
#    buttons to add a file, ask for a picture or a video, and stop.
#  User intention (Andrew, 2026-09-07): "It should look like a normal chat bot
#    interface does these days", past conversations, folders for projects,
#    image and video, and "The conversation should be able to be reset".
# ============================================================================
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QFileDialog, QFrame, QHBoxLayout, QLabel, QVBoxLayout, QWidget
from qfluentwidgets import (BodyLabel, CaptionLabel, FluentIcon, HyperlinkButton, ListWidget, PlainTextEdit, PrimaryPushButton,
                            PushButton, SimpleCardWidget, SmoothScrollArea, StrongBodyLabel, SubtitleLabel,
                            ToolButton, TransparentToolButton)

from warp2.app import theme
from warp2.app.parts.cards import Pill
from warp2.record.swallowed import noted


class Bubble(QFrame):
    """One turn of the conversation."""

    def __init__(self, turn: dict, mine: bool, copy) -> None:
        """Intention: who said it, what was said, any pictures, and a copy button with the time."""
        super().__init__()
        self.setObjectName("bubble")
        tint = "rgba(56,189,248,0.16)" if mine else "rgba(148,163,184,0.10)"
        edge = "rgba(56,189,248,0.35)" if mine else "rgba(148,163,184,0.18)"
        self.setStyleSheet(f"#bubble {{background: {tint}; border: 1px solid {edge}; border-radius: 14px}}")
        box = QVBoxLayout(self)
        box.setContentsMargins(16, 12, 16, 10)
        box.setSpacing(6)
        who = CaptionLabel("You" if mine else "Warp")
        who.setTextColor(theme.ACCENT, theme.ACCENT)
        box.addWidget(who)
        words = BodyLabel(str(turn.get("said") or ""))
        words.setWordWrap(True)
        words.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        box.addWidget(words)
        for path in _pictures(turn):
            picture = QLabel()
            image = QPixmap(str(path))
            if not image.isNull():
                picture.setPixmap(image.scaledToWidth(min(360, image.width()),
                                                      Qt.TransformationMode.SmoothTransformation))
                picture.setToolTip(str(path))
                box.addWidget(picture)
        foot = QHBoxLayout()
        when = CaptionLabel(str(turn.get("at") or "")[:19].replace("T", " "))
        when.setTextColor("#64748B", "#64748B")
        copy_button = TransparentToolButton(FluentIcon.COPY)
        copy_button.setToolTip("Copy")
        copy_button.clicked.connect(lambda: copy(str(turn.get("said") or "")))
        foot.addWidget(when)
        foot.addStretch(1)
        foot.addWidget(copy_button)
        box.addLayout(foot)


def _pictures(turn: dict) -> list:
    """Intention: the pictures a turn carries that are still on disk — what it made, and what it found to check."""
    found = []
    if turn.get("image"):
        found.append(turn["image"])
    found += list(turn.get("references") or ([turn["reference"]] if turn.get("reference") else []))
    return [Path(p) for p in found if p and Path(p).is_file()]


class Composer(PlainTextEdit):
    """The box he types in: Enter sends, Shift+Enter makes a new line."""

    def __init__(self, send) -> None:
        """Intention: a few lines tall, growing no taller than a third of the page."""
        super().__init__()
        self.send = send
        self.setPlaceholderText("Ask about a project, say what you want, or ask for a picture…  (Enter to send)")
        self.setFixedHeight(92)

    def keyPressEvent(self, event) -> None:
        """Intention: Enter sends; Shift+Enter is a new line."""
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            self.send()
            return
        super().keyPressEvent(event)


class ChatPage(QWidget):
    """Talking to the warp."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: the three columns — lists, conversation, and nothing hidden."""
        super().__init__(parent)
        self.setObjectName("chat")
        self.feed = feed
        from warp2.app.chat_centre import shared
        self.centre = shared(feed)
        page = QHBoxLayout(self)
        page.setContentsMargins(24, 20, 24, 20)
        page.setSpacing(16)
        page.addWidget(self._side(), 0)
        page.addLayout(self._middle(), 1)
        bridge = self.centre.bridge
        bridge.turns.connect(self.show_turns)
        bridge.archive.connect(self.show_archive)
        bridge.note.connect(self.note.setText)
        bridge.offer.connect(self.show_offer)
        bridge.lists.connect(self.fill_lists)
        bridge.typed.connect(self._typed)
        self.fill_lists()
        self.centre.refresh(force=True)
        self._clock = QTimer(self)
        self._clock.timeout.connect(self._tick)
        self._clock.start(2000)

    def _side(self) -> QWidget:
        """Intention: a new chat, the projects, the past chats."""
        side = SimpleCardWidget()
        side.setFixedWidth(260)
        box = QVBoxLayout(side)
        box.setContentsMargins(14, 14, 14, 14)
        box.setSpacing(10)
        new = PrimaryPushButton(FluentIcon.ADD, "New chat")
        new.clicked.connect(self._new_chat)
        box.addWidget(new)
        box.addWidget(StrongBodyLabel("Projects"))
        self.projects = ListWidget()
        self.projects.itemClicked.connect(lambda item: self.centre.select_project(item.text()))
        box.addWidget(self.projects, 1)
        head = QHBoxLayout()
        head.addWidget(StrongBodyLabel("Past chats"))
        head.addStretch(1)
        self.delete_button = TransparentToolButton(FluentIcon.DELETE)
        self.delete_button.setToolTip("Delete the picked past chat")
        self.delete_button.clicked.connect(self._delete_chat)
        head.addWidget(self.delete_button)
        box.addLayout(head)
        self.chats = ListWidget()
        self.chats.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.chats.customContextMenuRequested.connect(self._chat_context_menu)
        orig_key_press = self.chats.keyPressEvent
        def _chat_key(event):
            """Intention: let the Delete key delete the chosen chat; every other key goes to the list as normal."""
            if event.key() == Qt.Key.Key_Delete:
                self._delete_chat()
                return
            orig_key_press(event)
        self.chats.keyPressEvent = _chat_key
        self.chats.itemClicked.connect(self._open_chat)
        box.addWidget(self.chats, 2)
        return side

    def _middle(self) -> QVBoxLayout:
        """Intention: the heading, the conversation, the offer, the composer."""
        middle = QVBoxLayout()
        middle.setSpacing(10)
        head = QHBoxLayout()
        words = QVBoxLayout()
        self.heading = SubtitleLabel("Talk to the warp")
        self.sub = CaptionLabel("Ask about a project, say what you want, or generate media.")
        self.sub.setTextColor("#64748B", "#94A3B8")
        words.addWidget(self.heading)
        words.addWidget(self.sub)
        head.addLayout(words, 1)
        self.state_pill = Pill("● Ready (wakes when you type)", theme.GOOD)
        head.addWidget(self.state_pill)
        middle.addLayout(head)

        self.scroll = SmoothScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("QScrollArea {border: none; background: transparent}")
        self.paper = QWidget()
        self.paper.setObjectName("paper")
        self.paper.setStyleSheet("#paper {background: transparent}")
        self.turns_box = QVBoxLayout(self.paper)
        self.turns_box.setSpacing(12)
        self.turns_box.addStretch(1)
        self.scroll.setWidget(self.paper)
        middle.addWidget(self.scroll, 1)



        composer_card = SimpleCardWidget()
        c = QVBoxLayout(composer_card)
        c.setContentsMargins(12, 10, 12, 10)
        self.composer = Composer(self.send)
        c.addWidget(self.composer)
        tools = QHBoxLayout()
        for icon, tip, call in ((FluentIcon.FOLDER_ADD, "Add a file or picture", self._add_file),
                                (FluentIcon.PHOTO, "Ask for a picture of what is typed", self._picture),
                                (FluentIcon.VIDEO, "Ask for a video of what is typed", self._video),
                                (FluentIcon.SAVE, "Save this conversation", self._save),
                                (FluentIcon.SHARE, "Export this conversation", self.centre.export_chat_action)):
            button = ToolButton(icon)
            button.setToolTip(tip)
            button.clicked.connect(call)
            tools.addWidget(button)
        self.open_page = None
        self.queue_link = HyperlinkButton("", "")
        self.queue_link.setStyleSheet(f"HyperlinkButton {{font-size: 11px; color: {theme.ACCENT}; text-align: left; padding: 0 4px;}}")
        self.queue_link.clicked.connect(lambda: self.open_page and self.open_page("pictures"))
        self.queue_link.hide()
        tools.addWidget(self.queue_link)
        self.note = CaptionLabel("")
        self.note.setTextColor("#64748B", "#94A3B8")
        tools.addWidget(self.note, 1)
        self.stop_button = PushButton(FluentIcon.PAUSE, "Stop")
        self.stop_button.clicked.connect(self._stop)
        send = PrimaryPushButton(FluentIcon.SEND, "Send")
        send.clicked.connect(self.send)
        tools.addWidget(self.stop_button)
        tools.addWidget(send)
        c.addLayout(tools)
        middle.addWidget(composer_card)
        return middle

    # -- what the buttons do -------------------------------------------------

    def showEvent(self, event) -> None:
        """Intention: focus composer whenever this page is navigated to."""
        super().showEvent(event)
        QTimer.singleShot(50, self.composer.setFocus)

    def send(self) -> None:
        """Intention: his words handed to the centre, which answers off the window's thread."""
        words = self.composer.toPlainText()
        if not words.strip():
            return
        self.composer.clear()
        self.centre.said.text = words
        self.centre.send()
        self.composer.setFocus()

    def _typed(self, words: str) -> None:
        """Intention: the composer shows what the centre left in it (cleared after sending, or a project prefix)."""
        if self.composer.toPlainText() != words:
            self.composer.setPlainText(words)

    def _new_chat(self) -> None:
        """Intention: the conversation saved and a fresh one begun."""
        self.centre.reset()
        self.heading.setText("Talk to the warp")
        self.sub.setText("New conversation started. Ask about a project or generate media.")
        self.centre.refresh(force=True)
        self.composer.setFocus()

    def _open_chat(self, item) -> None:
        """Intention: a past chat shown, or back to the current one."""
        path = item.data(Qt.ItemDataRole.UserRole)
        if path:
            self.centre.show_archive(path)
        else:
            self.centre.show_active_chat()
            self.heading.setText("Talk to the warp")
            self.sub.setText("Ask about a project, say what you want, or generate media.")

    def _chat_context_menu(self, pos) -> None:
        """Intention: 1-click context menu on a past chat to delete it."""
        item = self.chats.itemAt(pos)
        if not item:
            return
        path = item.data(Qt.ItemDataRole.UserRole)
        if not path:
            return
        from qfluentwidgets import Action, RoundMenu
        menu = RoundMenu(parent=self)
        menu.addAction(Action(FluentIcon.DELETE, "Delete this chat", triggered=lambda: self._delete_path(path)))
        menu.exec(self.chats.mapToGlobal(pos))

    def _delete_path(self, path: str) -> None:
        """Intention: delete a specific past conversation archive immediately."""
        if path:
            self.centre.delete_archive_action(path)
            self.fill_lists()

    def _delete_chat(self) -> None:
        """Intention: the picked past chat deleted, as the old window let him."""
        item = self.chats.currentItem()
        path = item.data(Qt.ItemDataRole.UserRole) if item else ""
        if path:
            self._delete_path(path)

    def _add_file(self) -> None:
        """Intention: files picked and kept with what he was saying."""
        paths, _ = QFileDialog.getOpenFileNames(self, "Add files or pictures")
        self.centre.said.text = self.composer.toPlainText()
        self.centre.add_files(paths)

    def _picture(self) -> None:
        """Intention: a picture of what is typed asked for — made by the loop, as before."""
        subject = self.composer.toPlainText().strip()
        if subject:
            self.centre.enqueue_image_action(subject)
            self.composer.clear()

    def _video(self) -> None:
        """Intention: a video of what is typed asked for."""
        subject = self.composer.toPlainText().strip()
        if subject:
            self.centre.said.text = f"make a video of {subject}"
            self.centre.send()

    def _save(self) -> None:
        """Intention: a snapshot of this conversation kept."""
        self.centre.said.text = "/save"
        self.centre.send()

    def _stop(self) -> None:
        """Intention: the same Stop and Resume the old window had."""
        self.centre.stop_action()
        self._tick()

    # -- showing it ----------------------------------------------------------

    def _clear(self) -> None:
        """Intention: every bubble taken away."""
        while self.turns_box.count() > 1:
            item = self.turns_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _place(self, turn: dict) -> None:
        """Intention: one bubble, his on the right and the warp's on the left, never wider than two thirds."""
        from warp2.ask.thread import ANDREW
        mine = turn.get("who") == ANDREW
        line = QHBoxLayout()
        bubble = Bubble(turn, mine, self._copy)
        # Intention: a bubble as wide as its words need, never wider than two
        # thirds of the conversation, so short turns stay small and long ones read well.
        from PySide6.QtGui import QFontMetrics
        widest = max(420, int(self.scroll.width() * 0.68))
        longest = max((QFontMetrics(self.font()).horizontalAdvance(line)
                       for line in str(turn.get("said") or "").splitlines() or [""]), default=0)
        bubble.setFixedWidth(max(240, min(widest, longest + 64)) if not _pictures(turn) else widest)
        if mine:
            line.addStretch(1)
        line.addWidget(bubble)
        if not mine:
            line.addStretch(1)
        holder = QWidget()
        holder.setLayout(line)
        line.setContentsMargins(0, 0, 0, 0)
        self.turns_box.insertWidget(self.turns_box.count() - 1, holder)

    def show_turns(self, turns: list) -> None:
        """Intention: the conversation drawn again only when it changed, then scrolled to the newest."""
        from warp2.ask.window import turn_is_shown
        shown = [t for t in turns if turn_is_shown(t)]
        key = (len(shown), str(shown[-1].get("at") if shown else ""))
        if getattr(self, "_drawn", None) == key:
            return
        self._drawn = key
        self._clear()
        if not shown:
            empty = BodyLabel("Nothing said yet. Ask about a project, or say what you want made.")
            empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
            empty.setTextColor("#64748B", "#94A3B8")
            self.turns_box.insertWidget(0, empty)
        for turn in shown:
            self._place(turn)
        QTimer.singleShot(60, lambda: self.scroll.verticalScrollBar().setValue(
            self.scroll.verticalScrollBar().maximum()))

    def show_archive(self, path: str, turns: list) -> None:
        """Intention: a past conversation drawn, with a heading saying so."""
        self._drawn = None
        self.show_turns(turns)
        self._drawn = ("archive", path)
        self.heading.setText("Past conversation")
        self.sub.setText(f"Viewing {Path(path).name} — pick Current chat to go back")

    def show_offer(self, offered) -> None:
        """Intention: no popups in chat — chat is pure chat."""
        pass

    def fill_lists(self) -> None:
        """Intention: the projects and past chats, as they stand."""
        from PySide6.QtWidgets import QListWidgetItem
        self.projects.clear()
        for name in self.centre._get_project_names():
            self.projects.addItem(name)
        self.chats.clear()
        current = QListWidgetItem("●  Current chat")
        current.setData(Qt.ItemDataRole.UserRole, "")
        self.chats.addItem(current)
        for arch in self.centre.thread.list_archives():
            item = QListWidgetItem(str(arch.get("title") or arch.get("filename") or "chat"))
            item.setData(Qt.ItemDataRole.UserRole, arch.get("path"))
            item.setToolTip(str(arch.get("path")))
            self.chats.addItem(item)

    def _copy(self, text: str) -> None:
        """Intention: a turn's words on the clipboard."""
        self.centre._copy_to_clipboard(text)

    def _tick(self) -> None:
        """Intention: ready, working (and for how long) or stopped, and the conversation read again from disk."""
        centre = self.centre
        if centre.halt.raised():
            self.state_pill.set("■ Stopped", theme.WARN)
            self.stop_button.setText("Resume")
        elif centre._busy:
            if centre._since is None:
                import time
                centre._since = time.monotonic()
            self.state_pill.set(f"● Working{centre._doing()} — {centre._how_long()}", theme.ACCENT)
            self.stop_button.setText("Stop")
        else:
            centre._since = None
            self.state_pill.set("● Ready" if centre.talk is not None else "● Ready (wakes when you type)", theme.GOOD)
            self.stop_button.setText("Stop")
        try:
            from warp2.ask.image_asks import ImageAsks
            active_asks = [r for r in ImageAsks(centre.state).rows(limit=5) if r.get("status") in ("pending", "rendering")]
            if active_asks:
                first = active_asks[0]
                status_label = "in progress" if first["status"] == "rendering" else "queued"
                self.queue_link.setText(f"🎨 Picture of '{first['subject']}' ({status_label}) → View in Pictures")
                self.queue_link.show()
            else:
                self.queue_link.hide()
        except Exception as exc:
            noted("warp2/app/pages/chat.py:ChatPage._tick", exc)
        if not centre.viewing_archive:
            centre.refresh()

    def draw(self, snapshot: dict) -> None:
        """Intention: update state pill, active asks banner, and turns on snapshot arrival."""
        self._tick()

    def take(self, snapshot: dict) -> None:
        """Intention: keep newest snapshot reading and update chat state when visible."""
        self._tick()

    def close_page(self) -> None:
        """Intention: the clock stopped before the window closes."""
        self._clock.stop()
