# WARP2/warp2/app/code_map.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/code_map.py
#  Used by   : warp2/app/pages/structure.py (the code structure tab),
#              warp2/app/tests/test_structure.py.
#  Uses      : stdlib ast, pathlib, re.
#  Description:
#    The warp's code as it is on disk: every Python file under the tree,
#    folder by folder; for one file, the header every file carries (its
#    pathway, what uses it, what it uses, what it is, what it is for) and its
#    parts — each class and function, where it starts, and the first line of
#    what it says it is for. What a file uses and what uses it are read from
#    the headers and from its imports, and turned into the files they name,
#    so a person can walk from one file to the next.
#  User intention (Andrew, 2026-09-25): "also we need to add in the code
#    structure like was in there before it should be a tab" — and "we need
#    the structure and all that in there".
# ============================================================================
from __future__ import annotations

import ast
import re
from pathlib import Path

# Intention: the header's fields, in the order every file writes them.
FIELDS = ("Pathway", "Used by", "Uses", "Description", "User intention")

# Intention: folders that are not the warp's code — kept old code, state,
# caches — so the map shows what runs.
SKIPPED = ("archive", "state", "__pycache__", "_retired", "_slop", ".git", "tmp_test_store")

# Intention: a path a header names — words and slashes ending in .py, or a
# folder of files named with {a,b}.py.
_PATH = re.compile(r"([\w./-]+/)\{([\w,]+)\}\.py|([\w./-]+\.py)")


def header_of(text: str) -> dict:
    """The header a file starts with, field by field; {} when it has none.

    Intention: READ THE WAY IT IS WRITTEN — "#  Name : words", then more
    lines of words until the next name, inside the first ====== block.
    """
    out: dict = {}
    field = None
    started = False
    for line in text.splitlines()[:120]:
        if not line.startswith("#"):
            if started:
                break
            continue
        body = line[1:].strip()
        if body.startswith("===="):
            if started:
                break
            started = True
            continue
        if not started:
            continue
        name = body.split(":", 1)[0].strip()
        named = next((f for f in FIELDS if name.startswith(f)), None)
        if named and ":" in body:
            field = named
            out[field] = body.split(":", 1)[1].strip()
        elif field and body:
            out[field] = (out[field] + " " + body).strip()
    return out


def parts_of(text: str) -> list:
    """Every class and function in a file: [{kind, name, line, says}], methods under their class.

    Intention: THE FIRST LINE OF WHAT IT SAYS — its docstring's first line,
    which in this tree is its intention note. A file that does not parse
    says so rather than showing nothing.
    """
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return [{"kind": "error", "name": f"does not parse: {exc.msg}", "line": exc.lineno or 0, "says": ""}]
    out = []

    def said(node) -> str:
        """Intention: the first line of a part's docstring (its intention note), or empty if it has none."""
        doc = ast.get_docstring(node) or ""
        return doc.strip().splitlines()[0] if doc.strip() else ""

    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            out.append({"kind": "class", "name": node.name, "line": node.lineno, "says": said(node)})
            for inner in node.body:
                if isinstance(inner, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    out.append({"kind": "method", "name": f"{node.name}.{inner.name}",
                                "line": inner.lineno, "says": said(inner)})
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            out.append({"kind": "function", "name": node.name, "line": node.lineno, "says": said(node)})
    return out


def imports_of(text: str) -> list:
    """Intention: the modules a file imports, by dotted name, as the code says them."""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and not node.level:
            found.add(node.module)
        elif isinstance(node, ast.Import):
            found.update(alias.name for alias in node.names)
    return sorted(found)


def paths_named(words: str) -> list:
    """Intention: every file path a header's words name, the {a,b}.py shorthand opened out."""
    out = []
    for folder, names, whole in _PATH.findall(str(words or "")):
        if whole:
            out.append(whole.strip("./"))
        else:
            out.extend(f"{folder}{name}.py".strip("./") for name in names.split(","))
    return out


class CodeMap:
    """The code under one root, read when asked, each file read again only when it changes."""

    def __init__(self, root) -> None:
        """Intention: the root, what each file said the last time it was read, and the list of files once walked."""
        self.root = Path(root)
        self._read: dict = {}
        self._files: list | None = None
        self._modules: dict = {}

    def files(self) -> list:
        """Intention: every Python file of the warp's code, as paths from the root, sorted — walked once, again only when the tree is asked for."""
        if self._files is None:
            out = []
            for path in self.root.rglob("*.py"):
                rel = path.relative_to(self.root)
                if any(part in SKIPPED for part in rel.parts):
                    continue
                out.append(rel.as_posix())
            self._files = sorted(out)
            self._modules = {self.module_of(f): f for f in self._files}
        return self._files

    def tree(self) -> dict:
        """Intention: the files as nested folders — {name: sub-tree} for a folder, {name: path} for a file; the tree walked afresh."""
        self._files = None
        out: dict = {}
        for rel in self.files():
            here = out
            parts = rel.split("/")
            for folder in parts[:-1]:
                here = here.setdefault(folder + "/", {})
            here[parts[-1]] = rel
        return out

    def module_of(self, rel: str) -> str:
        """Intention: the dotted name a file is imported by."""
        name = rel[:-3].replace("/", ".")
        return name[: -len(".__init__")] if name.endswith(".__init__") else name

    def read(self, rel: str) -> dict:
        """One file: its header, its parts, what it imports, and the files it uses — read again only when it changed."""
        path = self.root / rel
        try:
            stamp = path.stat().st_mtime
        except OSError:
            return {"path": rel, "missing": True}
        known = self._read.get(rel)
        if known and known["stamp"] == stamp:
            return known
        text = path.read_text(encoding="utf-8", errors="replace")
        header = header_of(text)
        imports = imports_of(text)
        files = set(self.files())
        modules = self._modules
        uses = sorted({p for p in paths_named(header.get("Uses", "")) if p in files} |
                      {modules[m] for m in imports if m in modules})
        used_by = sorted(p for p in paths_named(header.get("Used by", "")) if p in files)
        known = {"path": rel, "stamp": stamp, "header": header, "parts": parts_of(text),
                 "imports": imports, "uses": uses, "used_by": used_by,
                 "lines": text.count("\n") + 1}
        self._read[rel] = known
        return known

    def importers(self, rel: str) -> list:
        """Intention: every file whose imports name this one — what uses it, read from the code, not only from headers."""
        module = self.module_of(rel)
        out = []
        for other in self.files():
            if other != rel and module in self._imports(other):
                out.append(other)
        return out

    def _imports(self, rel: str) -> list:
        """Intention: one file's imports only — cheap enough to ask of every file, kept until the file changes."""
        path = self.root / rel
        try:
            stamp = path.stat().st_mtime
        except OSError:
            return []
        known = self._read.get(rel)
        if known and known["stamp"] == stamp:
            return known["imports"]
        cached = self._read.setdefault(f"imports:{rel}", {"stamp": None, "imports": []})
        if cached["stamp"] != stamp:
            cached.update(stamp=stamp, imports=imports_of(path.read_text(encoding="utf-8", errors="replace")))
        return cached["imports"]
