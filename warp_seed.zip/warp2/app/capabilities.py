# WARP2/warp2/app/capabilities.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/capabilities.py
#  Used by   : warp2/app/window.py (a tab for each capability, and new tabs
#              as new ones appear), warp2/app/pages/capability.py (what one
#              capability shows), warp2/app/pages/capabilities.py (all of
#              them), warp2/app/parts/now_view.py (which one is running now),
#              warp2/app/pages/home.py (the outline), warp2/app/tests/.
#  Uses      : warp2/work/side/turns.py (ORDER — every side step the warp
#              has), warp2/work/phases.py (ORDER — the phases of the action
#              cycle), warp2/record/journal.py (last_lines), warp2/train/
#              outputs.py (the graded answers of a kind), warp2/app/record_index.py
#              (each verb's whole record), state/deadlines.json
#              (what each step costs, measured); stdlib json, time, pathlib.
#  Description:
#    What the warp can do, and everything it has done with each. A
#    capability is found, never listed by hand: every side step the warp has
#    (its verb and what its code says it is for), every phase of its action
#    cycle, and every kind of work its queue has ever held (build, test,
#    research...). A new side step, phase or kind of work is a new
#    capability, so the window grows a tab for it by itself. For one
#    capability: its runs from the journals (when, how it ended, how long,
#    what it said), its measured cost, its graded answers, and whether it is
#    running now. Everything the warp does that is none of these is its own
#    running — kept as one capability of its own, so nothing is left out.
#  User intention (Andrew, 2026-09-25): "we need it to have a tabs on the
#    capabilities and we need have ones to watch what it dose whit as much
#    info about that thing that we can have it give" — "make new tabs when it
#    grows a capability" — "So a tab for all it has and what it does."
# ============================================================================
from __future__ import annotations

import functools
import json
import time
from datetime import datetime
from pathlib import Path

from warp2.app.record_index import over, record_of
from warp2.record.swallowed import noted

# Intention: the verbs each phase of the action cycle runs under
# (warp2/work/loop.py take_a_phase / _training_turn) — the loop's own names.
PHASE_VERBS = {"research": ("review_research",), "wiring": ("wire_the_kg",),
               "training": ("train", "training_readiness"), "improve": ("improve_itself", "prove_improvement")}

# Intention: the verbs a kind of work goes through, beside the kind's name.
WORK_VERBS = ("do_work", "settle_work", "build_context", "write_file", "prove", "prove_in_shadow")

# Intention: the one capability everything else belongs to.
RUNNING = "running"

# Intention: the journals the warp writes its actions to — its card lane and its web lane.
JOURNALS = ("continuous.jsonl", "web.jsonl")


def words(verb: str) -> str:
    """Intention: a verb as a person would say it."""
    text = str(verb).replace("_", " ").strip()
    return text[:1].upper() + text[1:] if text else text


def first_paragraph(doc: str) -> str:
    """Intention: what a piece of code says it is, its first paragraph."""
    return " ".join(str(doc or "").strip().split("\n\n")[0].split())


def _seconds(ts: str) -> float:
    """Intention: a journal time as seconds since 1970, or 0."""
    try:
        return datetime.fromisoformat(str(ts)).timestamp()
    except (TypeError, ValueError):
        return 0.0


@functools.lru_cache(maxsize=1)
def _side_steps() -> tuple:
    """Intention: read once a sitting — the registry and the headers do not change while the window is open."""
    return tuple(_read_side_steps())


def side_steps() -> list:
    """Intention: every side step the warp has, as a capability, read from its own registry."""
    return [dict(c) for c in _side_steps()]


def _read_side_steps() -> list:
    """Intention: each side step class in the order the warp takes them, with what its code says."""
    import sys
    from warp2.app.code_map import header_of
    from warp2.work.side.turns import ORDER
    out = []
    for cls in ORDER:
        module = sys.modules.get(cls.__module__)
        header = {}
        if module is not None and getattr(module, "__file__", None):
            try:
                header = header_of(Path(module.__file__).read_text(encoding="utf-8", errors="replace"))
            except OSError:
                header = {}
        out.append({"key": cls.verb, "name": words(cls.verb), "kind": "step", "verbs": [cls.verb],
                    "says": first_paragraph(cls.__doc__) or header.get("Description", ""),
                    "about": header.get("Description", ""), "for": header.get("User intention", ""),
                    "code": cls.__module__.replace(".", "/") + ".py"})
    return out


def phases() -> list:
    """Intention: every phase of the action cycle but the work (whose kinds are their own), as a capability."""
    from warp2.work.phases import ORDER, WORK
    return [{"key": f"phase:{p}", "name": f"{words(p)} phase", "kind": "phase",
             "verbs": list(PHASE_VERBS.get(p, ())), "says": f"The {p} phase of the action cycle.",
             "about": "", "for": "", "code": "warp2/work/phases.py"}
            for p in ORDER if p != WORK]


def work_kind(entry: dict) -> str:
    """Intention: the kind of work a journal entry was about, or "" when it was not about a work item."""
    if entry.get("work_kind"):
        return str(entry["work_kind"])
    target = str(entry.get("target") or "")
    if target.startswith("work:") and target.count(":") >= 2:
        return target.split(":")[1]
    return ""


class Capabilities:
    """What the warp can do and what it has done, read from its code and its record."""

    def __init__(self, root, state) -> None:
        """Intention: where the code and the record are."""
        self.root, self.state = Path(root), Path(state)

    # -- what there is ------------------------------------------------------

    def entries(self, most: int = 0) -> list:
        """The journals' entries, newest last, read from their ends.

        Intention: AS MUCH AS IS ASKED FOR. `most` bounds how many lines each
        journal gives; 0 means the lines the journal tail reader gives by
        itself, which grows its window only as far as it needs.
        """
        from warp2.record.journal import last_lines
        rows = []
        for name in JOURNALS:
            path = self.state / "journals" / name
            if not path.is_file():
                continue
            for line in last_lines(path, most or 2000):
                try:
                    entry = json.loads(line)
                except ValueError:
                    continue
                if isinstance(entry, dict) and entry.get("verb"):
                    entry["lane"] = name.split(".")[0]
                    rows.append(entry)
        return sorted(rows, key=lambda e: str(e.get("ts") or ""))

    def kinds(self, entries: list) -> list:
        """Intention: every kind of work the record shows, as a capability each."""
        seen = sorted({work_kind(e) for e in entries} - {""})
        return [{"key": f"work:{k}", "name": f"{words(k)} work", "kind": "work", "verbs": list(WORK_VERBS),
                 "work_kind": k, "says": f"Work items of kind {k}: taken, done by a model, judged, settled.",
                 "about": "", "for": "", "code": "warp2/work/loop.py"} for k in seen]

    def golem_and_projects(self) -> list:
        """Intention: every capability acquired by the Surface Golem or accepted from a completed project."""
        path = self.state / "golem" / "capabilities.json"
        if not path.is_file():
            return []
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        caps_map = raw.get("capabilities") if isinstance(raw, dict) else {}
        if not isinstance(caps_map, dict):
            return []
        out = []
        for cname, rec in sorted(caps_map.items()):
            if not isinstance(rec, dict):
                continue
            kind = str(rec.get("kind") or "golem")
            temps = [float(x) for x in (rec.get("temperatures") or []) if isinstance(x, (int, float))]
            temp_note = f" [temp {temps[-1]:.2f}]" if temps else ""
            code_path = (rec.get("modules") or ["warp2/golem/surface.py"])[0]
            label = words(str(cname).replace("project:", ""))
            if kind == "project":
                label = f"{label} (project)"
            says = str(rec.get("says") or (rec.get("trace_example") or {}).get("output") or "Acquired capability") + temp_note
            out.append({
                "key": f"cap:{cname}",
                "name": label,
                "kind": kind,
                "verbs": [str(cname)],
                "says": says,
                "about": ", ".join(rec.get("tags") or ()),
                "for": str(rec.get("engine") or ""),
                "code": str(code_path),
            })
        return out

    def all(self, entries: list | None = None) -> list:
        """Every capability: side steps, phases, kinds of work, golem/accepted projects, and the warp's own running.

        Intention: FOUND, NOT LISTED — each comes from a registry in the code
        or from the record, so a new one is here the moment it exists.
        """
        entries = self.entries() if entries is None else entries
        out = side_steps() + phases() + self.kinds(entries) + self.golem_and_projects()
        out.append({"key": RUNNING, "name": "The warp's own running", "kind": "running", "verbs": [],
                    "says": "Everything the warp does to keep itself going: reading its tree, deriving and "
                            "settling work, opening and sealing sessions.",
                    "about": "", "for": "", "code": "warp2/work/loop.py"})
        # Intention (Andrew, 2026-10-02: "make sure the gui does not show
        # things it does not do"): each capability carries its whole record
        # (warp2/app/record_index.py), and a step or phase that has never once
        # ended well is not shown — its code being in the registry is not the
        # warp doing it.
        record = self.record()
        for cap in out:
            cap["record"] = over(record, cap["verbs"])
        return [cap for cap in out if cap["kind"] not in ("step", "phase") or cap["record"]["ok"] > 0]

    def record(self) -> dict:
        """Intention: every verb's whole record over every journal the warp has written."""
        folder = self.state / "journals"
        names = sorted(p.name for p in folder.glob("*.jsonl")) if folder.is_dir() else []
        return record_of(self.state, names)

    # -- what one did -------------------------------------------------------

    def owner(self, entry: dict, caps: list) -> str:
        """Intention: which capability one journal entry belongs to — its kind of work first, then its verb, else the warp's own running."""
        kind = work_kind(entry)
        if kind and str(entry.get("verb")) in WORK_VERBS:
            return f"work:{kind}"
        verb = str(entry.get("verb") or "")
        for cap in caps:
            if cap["kind"] != "work" and verb in cap["verbs"]:
                return cap["key"]
        return RUNNING

    def runs(self, cap: dict, entries: list, caps: list) -> list:
        """Every entry this capability owns, newest first, as the journal wrote it."""
        mine = [e for e in entries if self.owner(e, caps) == cap["key"]]
        return list(reversed(mine))

    def cost(self, verbs: list) -> dict:
        """Intention: what its verbs cost, as the timing record measured them — {verb: {mean, max, n}}."""
        try:
            record = json.loads((self.state / "deadlines.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return {v: record[v] for v in verbs if isinstance(record.get(v), dict)}

    def graded(self, cap: dict) -> dict:
        """Intention: for a kind of work, how its graded answers went — how many passed, failed, and the faults said most."""
        kind = cap.get("work_kind") or ""
        if not kind:
            return {}
        from warp2.train.outputs import GRADED, Outputs
        passed = failed = 0
        faults: dict = {}
        for row in Outputs.for_state(self.state).rows(GRADED):
            if str(row.get("kind") or "") != kind or "passed" not in row:
                continue
            passed += int(bool(row["passed"]))
            failed += int(not row["passed"])
            for fault in row.get("faults") or []:
                faults[fault] = faults.get(fault, 0) + 1
        return {"passed": passed, "failed": failed,
                "faults": sorted(faults.items(), key=lambda kv: -kv[1])[:12]}

    def standing(self, cap: dict, runs: list) -> dict:
        """What one capability's record says: runs, how they ended, when last, how long, and whether it is running now.

        Intention: "AS MUCH INFO ABOUT THAT THING AS WE CAN HAVE IT GIVE" —
        every number here is read from the record, none is made up.
        """
        outcomes: dict = {}
        seconds = []
        for run in runs:
            outcomes[str(run.get("outcome") or "")] = outcomes.get(str(run.get("outcome") or ""), 0) + 1
            if isinstance(run.get("seconds"), (int, float)):
                seconds.append(float(run["seconds"]))
        last = runs[0] if runs else {}
        ago = time.time() - _seconds(last.get("ts")) if last else None
        record = cap.get("record") or {}
        # Intention (2026-10-02): when the recent window holds no run, when it
        # last ran is read from the whole record, not said as "never".
        if not last and record.get("last"):
            ago = time.time() - _seconds(record["last"])
        return {"runs": len(runs), "outcomes": outcomes,
                "mean_seconds": round(sum(seconds) / len(seconds), 2) if seconds else None,
                "last": last, "ago": ago, "cost": self.cost(cap["verbs"]), "graded": self.graded(cap),
                "record": record}

    def now(self, entries: list, caps: list) -> dict:
        """Intention: what the warp is doing right now — the newest entry of each lane, and whose it is."""
        lanes: dict = {}
        for entry in entries:
            lanes[entry.get("lane")] = entry
        result = {lane: {"entry": e, "owner": self.owner(e, caps), "ago": time.time() - _seconds(e.get("ts"))}
                  for lane, e in lanes.items()}
        from warp2.work.lane_progress import read
        for lane, beat in (("continuous", "card"), ("web", "web")):
            live = read(self.state, beat)
            if not live:
                continue
            now = result.setdefault(lane, {"entry": {}, "owner": RUNNING, "ago": None})
            now.update(live)
            progress = live.get("progress")
            if progress:
                message = (f"{progress['done']}/{progress['total']} images checked; "
                           f"{progress['checks']}/{progress['total_checks']} concept checks")
                entry = {"verb": progress["verb"], "target": progress["target"],
                         "outcome": "in_progress", "value": {"said": message}}
                now.update(entry=entry, owner=self.owner(entry, caps), ago=live["progress_age"],
                           progress_text=message)
            elif lane == "continuous" and live.get("heartbeat_age", 999) <= 60:
                try:
                    from warp2.ask.waiting import Waiting
                    mark = Waiting(self.state).someone()
                    if mark and mark.get("what"):
                        what = str(mark["what"])
                        inbox_dir = Path(self.state) / "centering_image" / "inbox"
                        round_num, part = None, None
                        if inbox_dir.is_dir():
                            unacked = [p for p in inbox_dir.glob("*.json") if not p.with_suffix(".ack").exists()]
                            if unacked:
                                try:
                                    req_data = json.loads(unacked[-1].read_text(encoding="utf-8"))
                                    resume = req_data.get("resume") or {}
                                    part_state = resume.get("part_state") or {}
                                    round_num = part_state.get("round") or resume.get("round")
                                    part = part_state.get("part") or resume.get("part")
                                except Exception:  # Intention: the inbox file may be mid-write; with no round number the line just says what is in progress.
                                    pass
                        if round_num:
                            message = f"Round {round_num}" + (f" ({part})" if part else "") + " · progress unmeasured"
                        else:
                            message = f"Active request: {what} · progress unmeasured"
                        since_val = mark.get("since")
                        active_ago = max(0.0, time.time() - _seconds(since_val)) if since_val else None
                        entry = {"verb": "make_asked_image", "target": what,
                                 "outcome": "in_progress", "value": {"said": message},
                                 "ts": since_val}
                        # A waiting request describes activity, not measured work.
                        # Leave progress absent so a fresh beat cannot imply advancement.
                        now.update(entry=entry, owner=self.owner(entry, caps), ago=active_ago,
                                   progress_text=message)
                except Exception as exc:
                    noted("warp2/app/capabilities.py:Capabilities.now", exc)
        return result
