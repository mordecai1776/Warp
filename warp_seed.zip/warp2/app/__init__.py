# WARP2/warp2/app/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/__init__.py
#  Used by   : WARP2.bat (python -m warp2.app), warp2/run.py (`cockpit`, `ask`).
#  Uses      : nothing itself — each file here is one small part.
#  Description:
#    The one window: everything a person sees of WARP2 — the chat, the work,
#    the models, the KG and its webs and tags, the make cycle, the problems,
#    the pictures, the games, the projects and the system map — as pages of
#    one Fluent-style window (PySide6 + PySide6-Fluent-Widgets, live charts
#    with pyqtgraph). It reads the machine from the side, never blocks it,
#    and writes nothing but what a person asks for (a stop, a chat turn, an
#    approval), through the same doors the old windows used.
#  User intention (Andrew, 2026-09-25): "we will remake the gui parts into one
#    window and upgrade to the best looking set up we can get after some
#    research on the topic" — chosen: PySide6 + Fluent.
# ============================================================================
