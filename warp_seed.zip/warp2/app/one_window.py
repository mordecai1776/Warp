# WARP2/warp2/app/one_window.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/one_window.py
#  Used by   : warp2/app/window.py (WarpWindow claims the window when it is
#              made, and closes itself when a newer window has claimed it).
#  Uses      : warp2/util.py (atomic_write_bytes); stdlib json, os, time.
#  Description:
#    Which window process is THE window. Each window writes its process id
#    to state/control/window.owner.json when it is made (and again when it
#    reloads in place, with the same id). A window whose id is no longer the
#    one written there has been replaced by a newer one, and closes itself.
#    So opening the window again (WARP2.bat, OPEN_WINDOW.bat) gives one
#    window, the new one, never a pile of them.
#    Seen 2026-10-24: three window processes open at once (about 1.1 GB
#    private each) while the picture child was short of memory and the web
#    lane kept pausing on low RAM.
#  User intention (Andrew): "one launcher, one window".
# ============================================================================
"""The newest window is the one window; older ones step aside."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from warp2.util import atomic_write_bytes


class OneWindow:
    """Intention: the claim of one window process on being THE window, read from one small file."""

    def __init__(self, state, pid: int | None = None) -> None:
        """Intention: the claim file under the state's control folder, and this process's id."""
        self.path = Path(state) / "control" / "window.owner.json"
        self.pid = int(pid if pid is not None else os.getpid())

    def claim(self) -> bool:
        """Intention: say this process is the window now; a failed write is False, never a raise."""
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            atomic_write_bytes(self.path, json.dumps(
                {"pid": self.pid, "when": time.strftime("%Y-%m-%d %H:%M:%S")}).encode("utf-8"))
            return True
        except OSError:
            return False

    def owner(self) -> int | None:
        """Intention: the process id written as the window, or None when nothing readable is there."""
        try:
            return int(json.loads(self.path.read_text(encoding="utf-8")).get("pid"))
        except (OSError, ValueError, TypeError, AttributeError):
            return None

    def replaced(self) -> bool:
        """Intention: True only when another process has claimed the window since; unreadable is not replaced."""
        owner = self.owner()
        return owner is not None and owner != self.pid
