# WARP2/warp2/app/theme.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/theme.py
#  Used by   : every file in warp2/app/.
#  Uses      : qfluentwidgets (setTheme, setThemeColor), warp2/app/parts/kg_filter.py
#              (kind_of — one rule for what kind a thing is).
#  Description:
#    The look, in one place: the Fluent dark theme, the accent, and the few
#    colours the pages use for meaning — good, warning, bad, and one colour
#    for each proof grade and each kind of thing in the KG. Pages ask here;
#    no page picks its own colours.
#  User intention (Andrew, 2026-09-25): "the best looking set up we can get".
# ============================================================================
from __future__ import annotations

from PySide6.QtGui import QColor, QPalette

# Intention: the accent the whole window leans on — the same sky blue the old cockpit used.
ACCENT = "#38BDF8"

# Intention: meaning, not decoration — each used for one thing only.
GOOD, WARN, BAD, QUIET = "#4ADE80", "#FACC15", "#F87171", "#94A3B8"

# Intention: the proof grades (warp2/tags/grounding.py), ground truth bright, the rest cooler.
GRADE = {5: "#F472B6", 4: "#4ADE80", 3: "#38BDF8", 2: "#A78BFA", 1: "#FACC15", 0: "#64748B"}

# Intention: each kind of thing in the KG, by the prefix of its name.
KIND = {"concept": "#38BDF8", "area": "#C084FC", "finding": "#2DD4BF", "recipe": "#FB923C",
        "point": "#F472B6", "phrase": "#F472B6", "tag": "#F472B6", "skill": "#A855F7",
        "proof": "#818CF8", "problem": "#EF4444", "game": "#10B981", "web": "#8B5CF6",
        "webtag": "#8B5CF6", "eval": "#F59E0B", "need": "#FBBF24", "work": "#94A3B8",
        "file": "#FBBF24"}


def kind_of(subject: str) -> str:
    """Intention: the kind of a KG thing — one rule, kept in warp2/app/parts/kg_filter.py."""
    from warp2.app.parts.kg_filter import kind_of as rule
    return rule(subject)


def kind_colour(subject: str) -> QColor:
    """Intention: the colour for one KG thing."""
    return QColor(KIND.get(kind_of(subject), "#CBD5E1"))


def apply() -> None:
    """Intention: the dark Fluent theme with the accent, set once before any window is made."""
    from qfluentwidgets import Theme, setTheme, setThemeColor
    setTheme(Theme.DARK)
    setThemeColor(ACCENT)
    # Intention: native Qt viewports and editors share Fluent's dark theme,
    # so light text remains readable in every tab and in the active Eye.
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance()
    if app is not None:
        palette = app.palette()
        for role, colour in ((QPalette.ColorRole.Window, "#181C24"),
                             (QPalette.ColorRole.Base, "#11151D"),
                             (QPalette.ColorRole.AlternateBase, "#202632"),
                             (QPalette.ColorRole.WindowText, "#F1F5F9"),
                             (QPalette.ColorRole.Text, "#F1F5F9"),
                             (QPalette.ColorRole.Button, "#202632"),
                             (QPalette.ColorRole.ButtonText, "#F1F5F9"),
                             (QPalette.ColorRole.ToolTipBase, "#1E293B"),
                             (QPalette.ColorRole.ToolTipText, "#F8FAFC"),
                             (QPalette.ColorRole.PlaceholderText, "#94A3B8"),
                             (QPalette.ColorRole.BrightText, "#FFFFFF")):
            palette.setColor(role, QColor(colour))
        app.setPalette(palette)
        app.setStyleSheet(
            "QLabel { color: #E2E8F0; }"
            "QTableView, QTableWidget { color: #F1F5F9; }"
            "QToolTip { color: #F8FAFC; background-color: #1E293B; border: 1px solid #334155; }"
        )
