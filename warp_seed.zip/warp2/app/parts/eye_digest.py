# WARP2/warp2/app/parts/eye_digest.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/eye_digest.py
#  Used by   : warp2/app/pages/eye_tree.py (the Eye tab reads the hierarchy
#              through it), warp2/app/tests/test_eye_tree.py.
#  Uses      : state/models/eye/hierarchy.json (written by the Eye),
#              warp2/record/kept_file.py; numpy; stdlib json, os, subprocess,
#              sys.
#  Description:
#    THE EYE'S HIERARCHY, SMALL ENOUGH FOR THE WINDOW. The Eye writes every
#    relation it has as a list of [name, name, weight, sets] - measured
#    2026-11-09: 1,474,104 relations among 1,924 names, a 96 MB file that
#    took 474 MB to read, read again each time the Eye saved, held by two
#    parts of the window and drawn as 762,094 lines (the window sat at
#    3.9 GB). Here it is read ONCE per save, in a process of its own (so the
#    reading's memory goes back to the machine when it ends), and kept as:
#      - every name, once, in order (plain text - nothing is unpickled);
#      - one square table of weights, a float32 per pair of names (1,924
#        names: 15 MB), empty where no relation stands;
#      - the rest of the hierarchy (the tree, mixes, space, tasks) as it was.
#    `Relations` answers what the pages ask - how many stand, the strongest
#    (among some names, or for one name) - from the table, without lists.
#  User intention (Andrew, 2026-11-09 09:49): "Yes and let's change the window
#    to work with more plain visuals if needed." (BUILD_LOG 1477.)
# ============================================================================
"""The Eye's hierarchy read once in its own process, its relations kept as one small table of weights."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np

from warp2.record.kept_file import read_kept, write_kept

# Intention: the sides the Eye writes, and where the small copy is kept.
SIDES = ("concepts", "actions")


def digest_home(state) -> Path:
    """Intention: the small copy lives with the window's own state, beside nothing the Eye writes."""
    return Path(state) / "ui" / "eye_digest"


class Relations:
    """The relations that stand, as one square table of weights over the names (NaN where none stands)."""

    def __init__(self, names=(), table=None) -> None:
        """Intention: the names in order, and their table; an empty set of relations when nothing is given."""
        self.names = [str(n) for n in names]
        self.index = {n: i for i, n in enumerate(self.names)}
        size = len(self.names)
        self.table = (np.asarray(table, dtype=np.float32) if table is not None
                      else np.full((size, size), np.nan, dtype=np.float32))

    @classmethod
    def from_rows(cls, rows: list) -> "Relations":
        """Intention: the Eye's rows [a, b, weight, ...] as the table; a pair said twice keeps the last weight."""
        names = sorted({str(r[0]) for r in rows} | {str(r[1]) for r in rows})
        made = cls(names)
        for row in rows:
            i, j = made.index[str(row[0])], made.index[str(row[1])]
            made.table[i, j] = made.table[j, i] = float(row[2])
        return made

    def __len__(self) -> int:
        """Intention: how many relations stand - each pair once."""
        upper = np.triu(np.ones(self.table.shape, dtype=bool))
        return int(np.count_nonzero(upper & ~np.isnan(self.table)))

    def strongest(self, among=None, most: int = 0) -> list:
        """Intention: [(a, b, weight)] with the most weight either way - among some names only, when given; `most` rows."""
        if among is None:
            picked = np.arange(len(self.names))
        else:
            picked = np.array(sorted(self.index[n] for n in among if n in self.index), dtype=np.int64)
        if picked.size == 0:
            return []
        part = self.table[np.ix_(picked, picked)]
        upper = np.triu(np.ones(part.shape, dtype=bool), k=1)
        found = np.argwhere(upper & ~np.isnan(part))
        if found.size == 0:
            return []
        weights = part[found[:, 0], found[:, 1]]
        order = np.argsort(-np.abs(weights), kind="stable")[:most or len(weights)]
        return [(self.names[picked[found[k, 0]]], self.names[picked[found[k, 1]]], float(weights[k])) for k in order]

    def ties(self, name: str, most: int = 0) -> list:
        """Intention: [(other, weight)] for one name, the most weight first; `most` rows."""
        i = self.index.get(str(name))
        if i is None:
            return []
        row = self.table[i]
        found = [j for j in np.flatnonzero(~np.isnan(row)) if j != i]
        found.sort(key=lambda j: -abs(float(row[j])))
        return [(self.names[j], float(row[j])) for j in found[:most or len(found)]]

    def named(self) -> list:
        """Intention: every name that has a relation, in order."""
        has = ~np.all(np.isnan(self.table), axis=1)
        return [n for n, keep in zip(self.names, has) if keep]


def relations_of(side: dict) -> Relations:
    """Intention: a side's relations as the table, whatever form they came in; an empty table when there are none."""
    found = (side or {}).get("relations")
    if isinstance(found, Relations):
        return found
    return Relations.from_rows(list(found or []))


def make_digest(source, home) -> dict:
    """The small copy written from the Eye's file: rest.json, and per side names + table. What was written.

    Intention: run in its own process (`main`), so the big reading never lives in the window.
    """
    source, home = Path(source), Path(home)
    stamp = source.stat().st_mtime_ns
    data = json.loads(source.read_text(encoding="utf-8"))  # fault: ok - a broken file must fail this child, so the window keeps its last copy and says why
    home.mkdir(parents=True, exist_ok=True)
    counts = {}
    for side in SIDES:
        part = data.get(side) or {}
        made = Relations.from_rows(list(part.pop("relations", None) or []))
        part["relations_count"] = counts[side] = len(made)
        tmp = home / f"{side}.tmp.npz"
        np.savez(tmp, table=made.table, names=np.array(made.names, dtype=str))
        os.replace(tmp, home / f"{side}.npz")
    write_kept(home / "rest.json", dict(data, digest_of=stamp))
    return {"of": stamp, "relations": counts}


def read_digest(state, seconds: float = 0.0) -> dict:
    """The Eye's hierarchy as the window keeps it: the rest as written, each side's relations as a `Relations`; {}.

    Intention: the small copy is made again (in its own process) only when the Eye has written its file since;
    a copy that cannot be made says so in "digest_why", and the window shows what it last had.
    """
    source = Path(state) / "models" / "eye" / "hierarchy.json"
    home = digest_home(state)
    if not source.is_file():
        return {}
    why = ""
    rest = read_kept(home / "rest.json", {})
    if rest.get("digest_of") != source.stat().st_mtime_ns:
        from warp2.record.quiet import quiet
        done = subprocess.run([sys.executable, "-m", "warp2.app.parts.eye_digest", str(source), str(home)],
                              capture_output=True, text=True, timeout=seconds or None,
                              cwd=str(Path(__file__).resolve().parents[3]), **quiet())
        if done.returncode != 0:
            why = (done.stderr or done.stdout or "the digest gave no reason").strip().splitlines()[-1]
        rest = read_kept(home / "rest.json", {})
    if not rest:
        return {"digest_why": why} if why else {}
    for side in SIDES:
        path = home / f"{side}.npz"
        part = rest.get(side)
        if isinstance(part, dict) and path.is_file():
            with np.load(path, allow_pickle=False) as kept:
                part["relations"] = Relations([str(n) for n in kept["names"]], kept["table"])
    return dict(rest, digest_why=why)


def main(argv=None) -> int:
    """Intention: the child process's door - the Eye's file in, the small copy out."""
    argv = list(sys.argv[1:] if argv is None else argv)
    said = make_digest(argv[0], argv[1])
    print(json.dumps(said))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
