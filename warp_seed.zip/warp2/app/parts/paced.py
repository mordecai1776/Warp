# WARP2/warp2/app/parts/paced.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/paced.py
#  Used by   : warp2/app/parts/warp_tasks_view.py, warp2/app/parts/user_tasks_view.py.
#  Uses      : warp2/app/feed.py (LEAST_PAUSE, COST_TIMES — the full reading's own pause).
#  Description:
#    How often a part may redo a store read on the quick (once a second)
#    reading: after a pause of its own last cost times COST_TIMES, never less
#    than LEAST_PAUSE — the same measure the full reading paces itself by.
#  User intention (Andrew, 2026-10-31: "I want you to fix everything that is
#    wrong"). Measured that night: the window used a whole core (21 CPU-seconds
#    in 20 s); its threads were in the store's query, the task lists re-reading
#    every work state each second, a read that takes longer than a second.
# ============================================================================
"""A read paced by its own cost."""
from __future__ import annotations

import time
from contextlib import contextmanager


class Paced:
    """When a read was last done and what it cost."""

    def __init__(self) -> None:
        """Intention: never read yet, so the first is due at once."""
        self.cost = 0.0
        self.ended = None

    def due(self) -> bool:
        """Intention: whether the pause since the last read has reached its own cost times COST_TIMES."""
        if self.ended is None:
            return True
        from warp2.app.feed import COST_TIMES, LEAST_PAUSE
        return time.monotonic() - self.ended >= max(LEAST_PAUSE, COST_TIMES * self.cost)

    @contextmanager
    def reading(self):
        """Intention: the read's cost measured, whether it ends well or not."""
        began = time.monotonic()
        try:
            yield
        finally:
            self.ended = time.monotonic()
            self.cost = self.ended - began
