# WARP2/warp2/app/parts/tone.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/tone.py
#  Used by   : warp2/app/parts/{verdict_banner,health_card}.py,
#              warp2/app/pages/improving.py.
#  Uses      : warp2/app/theme.py (GOOD, WARN, BAD, QUIET).
#  Description:
#    The few ways a reading is said on screen, kept in one place: a tone's
#    colour, a share as a percent, an age in plain words, a heat as an arrow.
#    Anything nobody measured is shown as "—", never as 0.
#  User intention (Andrew, 2026-10-02): "the GUI must not show things the
#    system does not actually do."
# ============================================================================
from __future__ import annotations

from warp2.app import theme

# Intention: the colour each tone of warp2/progress/verdict.py is drawn in.
COLOURS = {"good": theme.GOOD, "warn": theme.WARN, "bad": theme.BAD, "quiet": theme.QUIET}


def colour(tone: str) -> str:
    """Intention: the colour for a tone; an unknown tone is quiet."""
    return COLOURS.get(str(tone), theme.QUIET)


def pct(value) -> str:
    """Intention: a share as a whole percent, or — when nothing was measured."""
    return "—" if type(value) not in (int, float) else f"{float(value):.0%}"


def number(value, places: int = 2) -> str:
    """Intention: a measured number, or — when there is none."""
    return "—" if type(value) not in (int, float) else f"{float(value):.{places}f}"


def age(seconds) -> str:
    """Intention: how long ago, in plain words (s, min, h, days), or — when unknown."""
    if type(seconds) not in (int, float):
        return "—"
    s = float(seconds)
    if s < 90:
        return f"{s:.0f} s"
    if s < 5400:
        return f"{s / 60:.0f} min"
    if s < 172800:
        return f"{s / 3600:.1f} h"
    return f"{s / 86400:.1f} days"


def arrow(heat) -> tuple:
    """Intention: (arrow, words, tone) for a heat from warp2/progress/trend.py; too little to say is quiet."""
    if type(heat) not in (int, float):
        return ("·", "too little to say", "quiet")
    if heat > 0.3:
        return ("↑", "rising", "good")
    if heat < -0.3:
        return ("↓", "falling", "bad")
    return ("→", "flat", "quiet")
