# WARP2/warp2/app/parts/kg_filter.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/kg_filter.py
#  Used by   : warp2/app/pages/knowledge.py (what the KG view draws),
#              warp2/app/theme.py (kind_of).
#  Uses      : warp2/tags/grounding.py (a link's grade),
#              warp2/store/context.py (is_machinery — the warp's own bookkeeping).
#  Description:
#    The KG view's choices, as plain data work with no windows: what kinds and
#    relations are present, which things and links pass the filters (kind,
#    relation, least grade, machinery hidden), the most joined things, the
#    neighbourhood of a thing to a depth, and the shortest path between two
#    things. Kept apart from the drawing so it can be tested anywhere.
#  User intention (Andrew, 2026-09-25): "we need better controle in the kg
#    view" — he chose filters, focus and expand, size and layout, search and
#    paths.
# ============================================================================
from __future__ import annotations

from collections import deque


def kind_of(subject: str) -> str:
    """Intention: the kind of a KG thing, read from its name — a path is a file."""
    text = str(subject)
    if ":" in text and not text.startswith(("http://", "https://")):
        return text.split(":", 1)[0]
    return "file" if ("/" in text or text.endswith(".py")) else "thing"


def node_kind(node: dict) -> str:
    """Intention: a node's kind — the snapshot's word for it, else read from its name."""
    return str(node.get("kind") or kind_of(node.get("id")))


def kinds_of(nodes: list) -> list:
    """Intention: every kind present, most common first, so the filter lists what is there."""
    count: dict = {}
    for node in nodes:
        kind = node_kind(node)
        count[kind] = count.get(kind, 0) + 1
    return sorted(count, key=lambda k: (-count[k], k))


def relations_of(edges: list) -> list:
    """Intention: every relation present, most common first."""
    count: dict = {}
    for edge in edges:
        rel = str(edge.get("relation") or "")
        count[rel] = count.get(rel, 0) + 1
    return sorted(count, key=lambda r: (-count[r], r))


def grade_of(edge: dict) -> int:
    """Intention: how a link is known — its kept grade, or its shape's (warp2/tags/grounding.py)."""
    from warp2.tags import grounding
    return grounding.of({"subject": edge.get("from"), "relation": edge.get("relation"),
                         "object": edge.get("to"), "proof": edge.get("proof")})


def is_machinery(edge: dict) -> bool:
    """Intention: a link that is the warp's own bookkeeping, not knowledge (the context's own rule)."""
    from warp2.store.context import is_machinery as machinery
    return machinery({"subject": edge.get("from"), "object": edge.get("to"), "attr": edge.get("attr")})


def filtered(nodes: list, edges: list, kinds=None, relations=None, least_grade: int = 0,
             hide_machinery: bool = False) -> tuple:
    """(nodes, edges) that pass every filter.

    Intention: `kinds` and `relations` are the ones SHOWN (None shows all); a
    link is kept only when both its ends are kept, it passes the relation and
    grade filters, and — when asked — it is not machinery. A thing is kept
    when its kind is shown.
    """
    keep = [n for n in nodes if kinds is None or node_kind(n) in kinds]
    ids = {n.get("id") for n in keep}
    links = [e for e in edges
             if e.get("from") in ids and e.get("to") in ids
             and (relations is None or str(e.get("relation") or "") in relations)
             and (least_grade <= 0 or grade_of(e) >= least_grade)
             and not (hide_machinery and is_machinery(e))]
    return keep, links


def degree(edges: list) -> dict:
    """Intention: how many links each thing has."""
    count: dict = {}
    for e in edges:
        for end in (e.get("from"), e.get("to")):
            count[end] = count.get(end, 0) + 1
    return count


def most_joined(nodes: list, edges: list, most: int) -> tuple:
    """Intention: the `most` most joined things and the links among them — the KG's shape at a glance."""
    joined = degree(edges)
    keep = sorted(nodes, key=lambda n: (-joined.get(n.get("id"), 0), str(n.get("id"))))[:max(1, int(most))]
    ids = {n.get("id") for n in keep}
    return keep, [e for e in edges if e.get("from") in ids and e.get("to") in ids]


def _neighbours(edges: list) -> dict:
    """Intention: who is next to whom, either way along a link."""
    near: dict = {}
    for e in edges:
        a, b = e.get("from"), e.get("to")
        near.setdefault(a, set()).add(b)
        near.setdefault(b, set()).add(a)
    return near


def around(nodes: list, edges: list, focus: str, depth: int) -> tuple:
    """(nodes, edges) within `depth` links of the focus, either way. Each node carries its `ring` (distance)."""
    near = _neighbours(edges)
    ring = {focus: 0}
    frontier = deque([focus])
    while frontier:
        here = frontier.popleft()
        if ring[here] >= depth:
            continue
        for other in sorted(near.get(here, ())):
            if other not in ring:
                ring[other] = ring[here] + 1
                frontier.append(other)
    known = {n.get("id"): n for n in nodes}
    keep = [{**known.get(name, {"id": name}), "ring": d} for name, d in sorted(ring.items(), key=lambda kv: (kv[1], str(kv[0])))]
    return keep, [e for e in edges if e.get("from") in ring and e.get("to") in ring]


def path_between(edges: list, start: str, end: str) -> list:
    """The shortest chain of things from start to end, either way along links, or [] when none.

    Intention: breadth first, so the first chain found is a shortest one.
    """
    if start == end:
        return [start]
    near = _neighbours(edges)
    before = {start: None}
    frontier = deque([start])
    while frontier:
        here = frontier.popleft()
        for other in sorted(near.get(here, ())):
            if other in before:
                continue
            before[other] = here
            if other == end:
                chain = [end]
                while before[chain[-1]] is not None:
                    chain.append(before[chain[-1]])
                return chain[::-1]
            frontier.append(other)
    return []


def matching(nodes: list, words: str, most: int) -> list:
    """Intention: things whose name holds the words, exact names first, then shortest — the search's suggestions."""
    words = str(words or "").strip().lower()
    if not words:
        return []
    hits = [n.get("id") for n in nodes if words in str(n.get("label") or n.get("id")).lower()
            or words in str(n.get("id")).lower()]
    return sorted(hits, key=lambda i: (str(i).lower() != words, len(str(i)), str(i)))[:max(1, int(most))]
