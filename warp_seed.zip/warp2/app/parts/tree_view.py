# WARP2/warp2/app/parts/tree_view.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/tree_view.py
#  Used by   : warp2/app/pages/eye_tree.py (the Eye's hierarchy, drawn).
#  Uses      : PySide6 (QGraphicsView — drawn through Qt), warp2/app/theme.py;
#              (stdlib) math.
#  Description:
#    A hierarchy drawn as a tree, top down: every group a dot, as big as the
#    names it holds (on a log scale, so a big group does not swamp the
#    rest). The colour says how a group was cut — by kind (blue), by side
#    (violet), or not cut (grey) — and a green ring says it has a pair of
#    its own. Where a group cut by side has two sides that are opposites, a
#    red dashed arc joins them, with how opposite they are. The wheel zooms
#    toward the pointer, dragging pans, clicking a group picks it.
#  User intention (Andrew, 2026-09-25): "Add an Eye tree tab" — "with more of
#    a visuals centered concept".
#    2026-11-09 (BUILD_LOG 1480): the in-use ring is gone with the in-use panel.
# ============================================================================
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QGraphicsEllipseItem, QGraphicsPathItem, QGraphicsScene,
                               QGraphicsSimpleTextItem, QGraphicsView)

from warp2.app import theme

# Intention: the colour of each way a group can be cut.
CUT = {"kinds": theme.ACCENT, "sides": "#A78BFA", "": theme.QUIET}

# Intention: room between rows and between leaves, in scene units.
ROW, LEAF = 110.0, 46.0


def layout(tree: dict) -> dict:
    """{uid: (x, y)} — leaves side by side in order, each group over the middle of its sides.

    Intention: the classic tidy tree: the same tree is always drawn the same
    way, and no two groups sit on each other.
    """
    where: dict = {}
    count = [0]

    def place(node: dict, depth: int) -> float:
        """Intention: one group placed after its sides; its x the middle of theirs."""
        sides = node.get("sides") or []
        if not sides:
            x = count[0] * LEAF
            count[0] += 1
        else:
            xs = [place(s, depth + 1) for s in sides]
            x = sum(xs) / len(xs)
        where[node["uid"]] = (x, depth * ROW)
        return x
    place(tree, 0)
    return where


def label_of(node: dict) -> str:
    """Intention: what a group is best called — its best-fitting token, else its first member — short."""
    tokens = node.get("tokens") or {}
    # Intention: a token that fires with everything names nothing — only a
    # token with some of its own (share less spread above 0) can name a group.
    telling = {t: v[0] * (1.0 - v[1]) for t, v in tokens.items() if v[0] * (1.0 - v[1]) > 1e-9}
    name = max(telling, key=telling.get) if telling else (node.get("members") or ["—"])[0]
    name = str(name)
    return name if len(name) <= 18 else name[:16] + "…"


def opposite(node: dict) -> bool:
    """Intention: a group cut by side whose two sides, taken whole, go against each other — a cut by kind parts unrelated kinds, not opposites."""
    return node.get("cut") == "sides" and len(node.get("sides") or []) == 2 and float(node.get("combined", 0.0)) < 0.0


class GroupDot(QGraphicsEllipseItem):
    """One group, drawn."""

    def __init__(self, node: dict, radius: float) -> None:
        """Intention: a dot coloured by its cut, ringed when it has a pair, lit when hovered."""
        super().__init__(-radius, -radius, 2 * radius, 2 * radius)
        self.uid = int(node["uid"])
        colour = QColor(CUT.get(node.get("cut") or "", theme.QUIET))
        fill = QColor(colour)
        fill.setAlpha(200)
        self.setBrush(QBrush(fill))
        self.own_pen = QPen(QColor(theme.GOOD), 3) if node.get("pair") else QPen(colour.darker(140), 1)
        self.setPen(self.own_pen)
        self.setAcceptHoverEvents(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(f"{len(node.get('members') or [])} names — {label_of(node)}")
        self.setZValue(2)

    def hoverEnterEvent(self, event) -> None:
        """Intention: a hovered group grows a little, so it is clear what a click picks."""
        self.setScale(1.25)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:
        """Intention: back to its size."""
        self.setScale(1.0)
        super().hoverLeaveEvent(event)


class TreeView(QGraphicsView):
    """The hierarchy, as a tree a person can move around in."""

    picked = Signal(int)

    def __init__(self, parent=None) -> None:
        """Intention: an empty scene, smooth drawing, dragging to pan."""
        super().__init__(parent)
        self.setScene(QGraphicsScene(self))
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setStyleSheet("QGraphicsView {border: none; background: transparent}")
        self.dots: dict = {}
        self.chosen = -1

    def show_tree(self, tree: dict | None) -> None:
        """Intention: the whole tree drawn again; the picked group stays picked when it is still there."""
        scene = self.scene()
        scene.clear()
        self.dots = {}
        if not tree:
            note = scene.addSimpleText("No hierarchy yet — it grows from the Eye's cascades.")
            note.setBrush(QColor(theme.QUIET))
            return
        where = layout(tree)
        stack = [tree]
        font = QFont()
        font.setPointSizeF(8.5)
        while stack:
            node = stack.pop()
            x, y = where[node["uid"]]
            for side in node.get("sides") or []:
                sx, sy = where[side["uid"]]
                path = QPainterPath(QPointF(x, y))
                path.cubicTo(QPointF(x, (y + sy) / 2), QPointF(sx, (y + sy) / 2), QPointF(sx, sy))
                line = QGraphicsPathItem(path)
                line.setPen(QPen(QColor(148, 163, 184, 90), 1.4))
                scene.addItem(line)
                stack.append(side)
            if opposite(node):
                self._opposite(node, where)
            radius = 7.0 + 4.0 * math.log2(1 + len(node.get("members") or []))
            dot = GroupDot(node, radius)
            dot.setPos(x, y)
            scene.addItem(dot)
            self.dots[dot.uid] = dot
            text = QGraphicsSimpleTextItem(label_of(node))
            text.setFont(font)
            text.setBrush(QColor("#CBD5E1"))
            text.setPos(x - text.boundingRect().width() / 2, y + radius + 3)
            text.setZValue(3)
            scene.addItem(text)
        scene.setSceneRect(scene.itemsBoundingRect().adjusted(-40, -40, 40, 40))
        self.fit()
        if self.chosen in self.dots:
            self.pick(self.chosen, tell=False)

    def _opposite(self, node: dict, where: dict) -> None:
        """Intention: a red dashed arc between a group's two sides when, taken whole, they are opposites."""
        (ax, ay), (bx, by) = (where[s["uid"]] for s in node["sides"])
        path = QPainterPath(QPointF(ax, ay))
        dip = ROW * 0.45
        path.cubicTo(QPointF(ax, ay + dip), QPointF(bx, by + dip), QPointF(bx, by))
        arc = QGraphicsPathItem(path)
        pen = QPen(QColor(theme.BAD), 1.6, Qt.PenStyle.DashLine)
        arc.setPen(pen)
        arc.setZValue(1)
        arc.setToolTip(f"the two sides are opposites, taken whole: {float(node['combined']):+.2f}")
        self.scene().addItem(arc)

    def pick(self, uid: int, tell: bool = True) -> None:
        """Intention: one group marked as picked, and said when a person picked it."""
        for key, dot in self.dots.items():
            dot.setOpacity(1.0 if key == uid or uid < 0 else 0.55)
        self.chosen = int(uid)
        if tell:
            self.picked.emit(int(uid))

    def fit(self) -> None:
        """Intention: the whole tree in view."""
        rect = self.scene().sceneRect()
        if rect.width() > 0:
            self.fitInView(rect, Qt.AspectRatioMode.KeepAspectRatio)

    def mousePressEvent(self, event) -> None:
        """Intention: a click on a group picks it; anywhere else starts a pan."""
        item = self.itemAt(event.position().toPoint())
        if isinstance(item, GroupDot):
            self.pick(item.uid)
            return
        super().mousePressEvent(event)

    def wheelEvent(self, event) -> None:
        """Intention: zoom toward the pointer, smoothly, by how far the wheel turned."""
        step = 1.0015 ** event.angleDelta().y()
        self.scale(step, step)

    def resizeEvent(self, event) -> None:
        """Intention: a resized view shows the whole tree again."""
        super().resizeEvent(event)
        self.fit()
