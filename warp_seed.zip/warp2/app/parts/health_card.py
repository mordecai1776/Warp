# WARP2/warp2/app/parts/health_card.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/health_card.py
#  Used by   : warp2/app/parts/now_view.py (down the right, on every tab).
#  Uses      : PySide6, qfluentwidgets, warp2/app/parts/{cards,tone,standing_words}.py
#              (the memory floor the runner measures comes in the quick reading,
#              warp2/app/feed.py).
#  Description:
#    How the machine is, always in view: whether the runner and the watcher
#    are beating, how much memory is free (the runner's last word and the
#    watcher's last measure, each with its age), how often it had to wait for
#    memory, when and why it last restarted, and this run so far — steps,
#    errors, and how long since its last entry. A long silence while the
#    runner beats is a long step; while it does not, a stall.
#  User intention (Andrew, 2026-10-16): the 381 MB and the restart that left
#    no window were invisible — "is the gui fit for the program".
#    2026-11-08 (BUILD_LOG 1455): memory is drawn against the floor the
#    runner really waits on (measured, not the 1536 MB setting), warmer as it
#    nears it; an old measure says how old it is; a long step is the step in
#    flight past its own usual time, named, not a set half hour of silence;
#    with no health reading the pills say so instead of keeping old words.
# ============================================================================
from __future__ import annotations

from qfluentwidgets import CaptionLabel, CardWidget, StrongBodyLabel
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout

from warp2.app import theme
from warp2.app.parts import tone
from warp2.app.parts.cards import KeyValue, Pill
from warp2.app.parts.standing_words import memory_heat, measured_age, step_words


def health_lines(health: dict, session: dict, floor_mb=None, now: float | None = None) -> list:
    """Intention: the card's lines as (name, words) — every figure with its age, nothing filled in."""
    said = (health.get("memory_said") or {}).get("last") or {}
    measured = health.get("memory_measured") or {}
    restart = health.get("restart") or {}
    waits = (health.get("memory_said") or {}).get("waits")
    current = health.get("memory_current") or {}
    image = health.get("image_memory") or {}
    import time
    measured_ago = measured_age(measured.get("when"), time.time() if now is None else now)
    lines = [
        ("Free RAM now", f"{current['free_mb']:,} MB"
         if type(current.get("free_mb")) in (int, float) else "—"),
        ("Commit headroom now", f"{current['commit_free_mb']:,} MB"
         if type(current.get("commit_free_mb")) in (int, float) else "—"),
        ("Image private (sample)", f"{image['private_mb']:,} MB · {tone.age(image.get('age_seconds'))} ago"
         if type(image.get("private_mb")) in (int, float) else "—"),
        ("Free memory (runner)", f"{said['free_mb']:,} MB" + (" — waiting" if said.get("waiting") else "")
         if said else "—"),
        ("Free memory (measured)", f"{measured['free_mb']:,} MB · {tone.age(measured_ago)} ago"
         if type(measured.get("free_mb")) in (int, float) else "—"),
        ("Runner waits under", f"{floor_mb:,} MB (measured)" if type(floor_mb) is int else "—"),
        ("Waited for memory", f"{waits} times" if waits is not None else "—"),
        ("Last restart", f"{restart.get('when') or '—'} ({restart.get('outcome') or '—'})"),
        ("Why", restart.get("why") or "—"),
        ("This run", f"{session.get('steps', 0)} steps, {session.get('ok', 0)} ok, "
                     f"{session.get('error_count', 0)} errors" if session else "—"),
        ("Last entry", f"{tone.age(session.get('silent_seconds'))} ago"
                       + (f" ({session.get('last_step')})" if session.get("last_step") else "") if session else "—"),
    ]
    return lines


class HealthCard(CardWidget):
    """The machine's health, down the right side of the window."""

    def __init__(self, parent=None) -> None:
        """Intention: a title with two state pills, and the lines under them."""
        super().__init__(parent)
        box = QVBoxLayout(self)
        box.setContentsMargins(14, 12, 14, 12)
        box.setSpacing(6)
        head = QHBoxLayout()
        head.addWidget(StrongBodyLabel("Health"))
        head.addStretch(1)
        self.runner = Pill("runner —", theme.QUIET)
        self.watcher = Pill("watcher —", theme.QUIET)
        head.addWidget(self.runner)
        head.addWidget(self.watcher)
        box.addLayout(head)
        self.lines = KeyValue()
        box.addWidget(self.lines)
        self.note = CaptionLabel("")
        self.note.setWordWrap(True)
        box.addWidget(self.note)
        self.session = {}
        self.floor_mb = None
        self.step = {}

    def take_standing(self, stand: dict) -> None:
        """Intention: current health refreshes independently of the expensive full store reading; the floor and
        the step in flight come with it."""
        self.floor_mb = stand.get("floor_mb")
        self.step = stand.get("step") or {}
        if stand.get("health"):
            self.take({"progress": {"health": stand["health"], "session": self.session}})

    def take(self, snapshot: dict) -> None:
        """Intention: drawn from the newest reading's progress part; nothing shown that was not read."""
        progress = (snapshot or {}).get("progress") or {}
        health, session = progress.get("health") or {}, progress.get("session") or {}
        self.session = session
        if not health:
            self.runner.set("runner — (no reading)", theme.QUIET)
            self.watcher.set("watcher — (no reading)", theme.QUIET)
            self.note.setText("No health reading yet.")
            return
        beating = bool(health.get("runner_alive"))
        self.runner.set("runner beating" if beating else "runner silent", theme.GOOD if beating else theme.BAD)
        watcher = health.get("watcher") or {}
        self.watcher.set(f"watcher {watcher.get('state') or '—'}",
                         theme.GOOD if watcher.get("alive") else theme.BAD)
        self.lines.set(health_lines(health, session, self.floor_mb))
        memory_wait = (health.get("memory_said") or {}).get("last") or {}
        notes = []
        if memory_wait.get("waiting"):
            notes.append("Memory is low — the runner waits for more before starting work.")
        current = health.get("memory_current") or {}
        if (memory_heat(current.get("commit_free_mb"), self.floor_mb) or 0.0) >= 1.0:
            notes.append("Commit headroom is low — RAM alone does not show allocation room.")
        if self.step.get("overdue"):
            notes.append(f"A long step is running: {step_words(self.step)}." if beating else
                         f"The runner is silent in a long step: {step_words(self.step)} — stalled?")
        self.note.setText(" ".join(notes))
        self.note.setStyleSheet(f"color: {theme.WARN if notes else theme.QUIET};")
