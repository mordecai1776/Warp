# WARP2/warp2/app/parts/chart.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/chart.py
#  Used by   : warp2/app/pages/{home,activity,models}.py.
#  Uses      : pyqtgraph (fast live plots, drawn on the GPU when OpenGL is
#              there), warp2/app/theme.py.
#  Description:
#    A live line chart styled to the window: transparent, thin grid, time
#    along the bottom, each series a soft line with a faint fill under it,
#    redrawn cheaply as new readings arrive.
#  User intention (Andrew): GPU first; runs show visual cues.
# ============================================================================
from __future__ import annotations

import pyqtgraph as pg
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor

from warp2.app import theme

pg.setConfigOptions(antialias=True, background=None, foreground="#94A3B8")


def see_through(plot: pg.PlotWidget) -> pg.PlotWidget:
    """Intention: a chart with no background of its own, so the card behind it shows — in dark and light."""
    plot.setBackground(None)
    plot.setStyleSheet("background: transparent; border: none")
    plot.viewport().setAutoFillBackground(False)
    plot.viewport().setStyleSheet("background: transparent")
    plot.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    return plot


class LiveChart(pg.PlotWidget):
    """Lines over time."""

    def __init__(self, parent=None, height: int = 180) -> None:
        """Intention: an empty chart with a time axis and room for a legend."""
        super().__init__(parent=parent, axisItems={"bottom": pg.DateAxisItem(orientation="bottom")})
        see_through(self)
        self.setMinimumHeight(height)
        self.showGrid(x=False, y=True, alpha=0.12)
        self.getPlotItem().getAxis("left").setWidth(44)
        for side in ("left", "bottom"):
            axis = self.getPlotItem().getAxis(side)
            axis.setPen(pg.mkPen(QColor(148, 163, 184, 60)))
            axis.setTextPen(pg.mkPen("#94A3B8"))
        self.getPlotItem().setMenuEnabled(False)
        self.getPlotItem().hideButtons()
        self.legend = self.addLegend(offset=(8, 4), labelTextColor="#94A3B8")
        self.lines: dict = {}

    def show(self, name: str, times, values, colour: str = theme.ACCENT) -> None:
        """Intention: one series drawn or redrawn, a soft fill under the line."""
        if name not in self.lines:
            c = QColor(colour)
            fill = QColor(c.red(), c.green(), c.blue(), 36)
            self.lines[name] = self.plot([], [], name=name, pen=pg.mkPen(colour, width=2),
                                         fillLevel=None, brush=fill)
        line = self.lines[name]
        line.setData(list(times), list(values))
        if values:
            line.setFillLevel(min(values))
