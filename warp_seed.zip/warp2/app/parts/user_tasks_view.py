# WARP2/warp2/app/parts/user_tasks_view.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/user_tasks_view.py
#  Used by   : warp2/app/parts/now_view.py (down the right side of the window).
#  Uses      : warp2/work/user_tasks.py, warp2/app/theme.py,
#              warp2/app/parts/worker.py (later), PySide6, qfluentwidgets.
#  Description:
#    The User Tasked Work & Workflow panel on the right of the window.
#    Shows active tasks until they are done, prevents stopping until passed,
#    and allows the user to rate the completed job or provide a statement
#    and redo it.
#  User intention (Andrew, 2026-09-27):
#    "lets work on the workflow and user tasked work system it should show up
#    on the right until it is done and should not be able to stop until it passes
#    what it has done and allow the user to rate the job if the user thinks it
#    is not done with a statement and redo it."
# ============================================================================
from __future__ import annotations

from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QWidget
from qfluentwidgets import (BodyLabel, CaptionLabel, CardWidget, FluentIcon, LineEdit,
                            PrimaryPushButton, PushButton, StrongBodyLabel, TransparentToolButton)

from warp2.app import theme
from warp2.app.parts.cards import Pill
from warp2.app.parts.worker import later
from warp2.work.user_tasks import get_user_tasks, rate_user_task, redo_user_task


class ActiveTaskCard(CardWidget):
    """An active user-tasked work item or workflow in progress.

    User intention (Andrew, 2026-09-27):
      "ok the right side should highlight exactly what it is working on in the moment"
    """

    def __init__(self, task: dict[str, Any], is_current_focus: bool = False, parent=None) -> None:
        """Intention: build the card for one open task Andrew gave; the one being worked on now is drawn stronger."""
        super().__init__(parent)
        self.task_id = str(task.get("id") or "")
        self.is_current_focus = is_current_focus

        if is_current_focus:
            self.setObjectName("activeFocusCard")
            self.setStyleSheet(
                "#activeFocusCard {"
                "  border: 2px solid #0284c7;"
                "  background: rgba(14, 165, 233, 0.12);"
                "  border-radius: 8px;"
                "}"
            )
        else:
            self.setObjectName("activeQueuedCard")
            self.setStyleSheet(
                "#activeQueuedCard {"
                "  border: 1px solid rgba(148, 163, 184, 0.2);"
                "  background: rgba(30, 41, 59, 0.35);"
                "  border-radius: 8px;"
                "}"
            )

        box = QVBoxLayout(self)
        box.setContentsMargins(12, 10, 12, 10)
        box.setSpacing(6)

        head = QHBoxLayout()
        kind = str(task.get("kind") or "task").upper()

        is_retry = bool(task.get("retry_reason"))
        if is_current_focus:
            focus_badge = CaptionLabel("🔥 IN THE MOMENT")
            focus_badge.setStyleSheet("color: #38bdf8; font-weight: 700; font-size: 11px;")
            head.addWidget(focus_badge)
            head.addStretch(1)

            pill_text = "⚡ Retrying until passes" if is_retry else "⚡ WORKING ON NOW"
            pill_color = theme.WARN if is_retry else "#0284c7"
            pill = Pill(pill_text, pill_color)
            head.addWidget(pill)
        else:
            queue_badge = CaptionLabel(f"⏳ QUEUED · {kind}")
            queue_badge.setTextColor("#64748B", "#94A3B8")
            head.addWidget(queue_badge)
            head.addStretch(1)

            pill = Pill("Waiting turn", "#64748B")
            head.addWidget(pill)
        box.addLayout(head)

        title = StrongBodyLabel(str(task.get("title") or task.get("target") or "Task"))
        title.setWordWrap(True)
        if is_current_focus:
            title.setStyleSheet("font-size: 15px; font-weight: 700; color: #f8fafc;")
        box.addWidget(title)

        target = str(task.get("target") or "")
        if target and target != title.text():
            tgt_lbl = CaptionLabel(f"Target: {target}")
            if is_current_focus:
                tgt_lbl.setTextColor("#38bdf8", "#38bdf8")
            else:
                tgt_lbl.setTextColor("#64748B", "#94A3B8")
            tgt_lbl.setWordWrap(True)
            box.addWidget(tgt_lbl)

        if is_retry:
            why = BodyLabel(f"User critique: \"{task['retry_reason']}\"")
            why.setWordWrap(True)
            why.setStyleSheet(f"color: {theme.WARN}; font-size: 11px; font-style: italic;")
            box.addWidget(why)

        # Workflow progress if available
        workflow_steps = task.get("workflow_steps") or []
        if workflow_steps:
            wf_lbl = CaptionLabel(f"Workflow: {len(workflow_steps)} linked steps in progress")
            wf_lbl.setTextColor(theme.ACCENT, theme.ACCENT)
            box.addWidget(wf_lbl)

        if is_current_focus:
            status_line = CaptionLabel("● Active Focus · Reader 100% gate enforced · Will not stop until passes")
            status_line.setStyleSheet("color: #38bdf8; font-weight: 600; font-size: 10px;")
            status_line.setWordWrap(True)
            box.addWidget(status_line)
        else:
            rule = CaptionLabel("Rule: will not stop until verified passed")
            rule.setTextColor("#64748B", "#64748B")
            box.addWidget(rule)


class CompletedTaskCard(CardWidget):
    """A finished user-tasked job allowing rating and redo with statement."""

    def __init__(self, task: dict[str, Any], on_redo, on_rate, parent=None) -> None:
        """Intention: build the card for one passed task, with star rating and a redo panel to send it back."""
        super().__init__(parent)
        self.task_id = str(task.get("id") or "")
        self.on_redo = on_redo
        self.on_rate = on_rate
        self.current_rating = task.get("rating")

        box = QVBoxLayout(self)
        box.setContentsMargins(12, 10, 12, 10)
        box.setSpacing(6)

        head = QHBoxLayout()
        ok_badge = CaptionLabel("✓ DONE & PASSED")
        ok_badge.setTextColor(theme.GOOD, theme.GOOD)
        head.addWidget(ok_badge)
        head.addStretch(1)
        head.addWidget(Pill("Passed", theme.GOOD))
        box.addLayout(head)

        title = StrongBodyLabel(str(task.get("title") or task.get("target") or "Task"))
        title.setWordWrap(True)
        box.addWidget(title)

        # Star Rating Row
        rate_box = QHBoxLayout()
        rate_lbl = CaptionLabel("Rate job:")
        rate_lbl.setTextColor("#64748B", "#94A3B8")
        rate_box.addWidget(rate_lbl)

        self.star_buttons = []
        for star_val in range(1, 6):
            btn = TransparentToolButton(FluentIcon.FLAG if self.current_rating and star_val <= self.current_rating else FluentIcon.HEART)
            btn.setFixedSize(24, 24)
            btn.setToolTip(f"Rate {star_val} of 5 stars")
            btn.clicked.connect(lambda _c=False, s=star_val: self._click_rate(s))
            self.star_buttons.append(btn)
            rate_box.addWidget(btn)

        self.rating_text = CaptionLabel(f"({self.current_rating}/5)" if self.current_rating else "(unrated)")
        self.rating_text.setTextColor(theme.GOOD if self.current_rating and self.current_rating >= 4 else "#94A3B8", "#94A3B8")
        rate_box.addWidget(self.rating_text)
        rate_box.addStretch(1)
        box.addLayout(rate_box)

        # Redo button & expandable critique input
        self.redo_toggle = PushButton(FluentIcon.SYNC, "Not done? Redo")
        self.redo_toggle.clicked.connect(self._toggle_redo_panel)
        box.addWidget(self.redo_toggle)

        self.redo_panel = QFrame()
        r_box = QVBoxLayout(self.redo_panel)
        r_box.setContentsMargins(0, 4, 0, 0)
        r_box.setSpacing(6)

        self.statement_input = LineEdit()
        self.statement_input.setPlaceholderText("State what is not done / what to fix...")
        self.statement_input.returnPressed.connect(self._submit_redo)
        r_box.addWidget(self.statement_input)

        submit_btn = PrimaryPushButton(FluentIcon.SEND, "Submit Statement & Redo")
        submit_btn.clicked.connect(self._submit_redo)
        r_box.addWidget(submit_btn)

        self.redo_panel.hide()
        box.addWidget(self.redo_panel)

    def _click_rate(self, stars: int) -> None:
        """Intention: record a star rating and pass it on; a 1 or 2 star rating opens the redo panel."""
        self.current_rating = stars
        self.rating_text.setText(f"({stars}/5)")
        self.rating_text.setTextColor(theme.GOOD if stars >= 4 else theme.WARN, theme.GOOD if stars >= 4 else theme.WARN)
        self.on_rate(self.task_id, stars)
        # If rated low (1 or 2 stars), automatically offer the redo panel
        if stars <= 2 and self.redo_panel.isHidden():
            self._toggle_redo_panel()

    def _toggle_redo_panel(self) -> None:
        """Intention: show or hide the redo panel and change the button text to match."""
        if self.redo_panel.isHidden():
            self.redo_panel.show()
            self.redo_toggle.setText("Cancel Redo")
            self.statement_input.setFocus()
        else:
            self.redo_panel.hide()
            self.redo_toggle.setText("Not done? Redo")

    def _submit_redo(self) -> None:
        """Intention: send the task back to be redone with the typed reason, or a default reason if none was typed."""
        stmt = self.statement_input.text().strip()
        if not stmt:
            stmt = "User reviewed job and determined it is not done yet."
        self.on_redo(self.task_id, stmt)


def _working_on(active: list, what: str) -> int:
    """Intention: which active task the runner is on — the one whose words appear in its waiting mark — or -1 for none."""
    what = str(what or "").lower()
    if not what:
        return -1
    for idx, task in enumerate(active):
        words = str(task.get("title") or task.get("target") or "").lower().strip()
        if words and words in what:
            return idx
    return -1


class UserTasksView(QFrame):
    """The User Tasked Work & Workflow section pinned down the right side."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: build the TASKED WORK box (header, pill, card list) and refresh it from the feed."""
        super().__init__(parent)
        self.feed = feed
        self.setObjectName("userTasksView")
        self.setStyleSheet("#userTasksView {border: none; background: transparent;}")

        self.box = QVBoxLayout(self)
        self.box.setContentsMargins(0, 0, 0, 8)
        self.box.setSpacing(6)

        head = QHBoxLayout()
        title = CaptionLabel("TASKED WORK & WORKFLOW")
        title.setTextColor("#64748B", "#94A3B8")
        head.addWidget(title)
        head.addStretch(1)
        self.status_pill = Pill("Ready", theme.GOOD)
        head.addWidget(self.status_pill)
        self.box.addLayout(head)

        self.cards_box = QVBoxLayout()
        self.cards_box.setSpacing(6)
        self.box.addLayout(self.cards_box)

        self._updating = False
        # Intention (2026-10-31, Remy for Andrew): the quick reading comes each second and this read can take
        # longer than that; it is redone after a pause of its own cost (warp2/app/parts/paced.py).
        from warp2.app.parts.paced import Paced
        self._paced = Paced()
        feed.standing.connect(self._tick)
        feed.snapshot.connect(self._on_snapshot)

    def _tick(self, _stand: dict) -> None:
        """Intention: on each quick reading, refresh the cards if shown and not already refreshing."""
        if not self.isVisible() or self._updating or not self._paced.due():
            return
        self.refresh()

    def _on_snapshot(self, _snap: dict) -> None:
        """Intention: on each full snapshot, refresh the cards if shown and not already refreshing."""
        if not self.isVisible() or self._updating:
            return
        self.refresh()

    def refresh(self) -> None:
        """Read tasks off the window's thread and redraw."""
        if self._updating:
            return
        self._updating = True
        state = self.feed.state

        def paced_read():
            """Intention: the read below, its cost measured for the pace."""
            with self._paced.reading():
                return read()

        def read():
            """Intention: the off-thread part — Andrew's tasks from the store, plus what the runner says it is on now."""
            store = getattr(self.feed, "_store", None)
            got = get_user_tasks(state, store=store, limit=10)
            # Intention (2026-10-02): what the runner is on now, from its
            # waiting mark (warp2/ask/waiting.py) — the only task shown as
            # being worked on is the one the runner says it is on.
            try:
                from warp2.ask.waiting import Waiting
                got["working_on"] = str(Waiting(state).someone().get("what") or "")
            except Exception:
                got["working_on"] = ""
            return got

        later(paced_read, self._fill, lambda _w: setattr(self, "_updating", False))

    def _fill(self, data: dict[str, list[dict]]) -> None:
        """Intention: replace the cards with the tasks just read — open ones first, then passed ones — and set the pill."""
        self._updating = False
        active = data.get("active", [])
        completed = data.get("completed", [])

        # Clear existing task cards
        while self.cards_box.count():
            item = self.cards_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        total_active = len(active)
        if total_active > 0:
            self.status_pill.setText(f"● {total_active} Active · Until passes")
            self.status_pill.setStyleSheet(f"background: rgba(56,189,248,0.2); color: {theme.ACCENT}; border: 1px solid {theme.ACCENT}; border-radius: 10px; padding: 2px 8px; font-size: 11px;")
            self.show()
        else:
            self.status_pill.setText("● Nothing waiting")
            self.status_pill.setStyleSheet(f"background: rgba(52,211,153,0.15); color: {theme.GOOD}; border: 1px solid {theme.GOOD}; border-radius: 10px; padding: 2px 8px; font-size: 11px;")

        # 1. Render active tasks (MUST SHOW ON THE RIGHT UNTIL DONE)
        # Intention (2026-10-02): "working on now" goes to the task the runner
        # says it is on (its waiting mark), not to whichever is first in the
        # list; when it is on none of them, none is said to be worked on.
        on = _working_on(active, data.get("working_on", ""))
        if total_active > 0:
            for idx, task in enumerate(active):
                card = ActiveTaskCard(task, is_current_focus=(idx == on))
                self.cards_box.addWidget(card)
        else:
            placeholder = CardWidget()
            p_box = QVBoxLayout(placeholder)
            p_box.setContentsMargins(12, 12, 12, 12)
            lbl = CaptionLabel("No tasks in progress.\nTasks, projects, or revisions you request will stay here until completed and verified.")
            lbl.setTextColor("#64748B", "#94A3B8")
            lbl.setWordWrap(True)
            p_box.addWidget(lbl)
            self.cards_box.addWidget(placeholder)

        # 2. Render up to 3 recently completed tasks for rating and redo
        for task in completed[:3]:
            card = CompletedTaskCard(task, on_redo=self._do_redo, on_rate=self._do_rate)
            self.cards_box.addWidget(card)

    def _do_rate(self, task_id: str, rating: int) -> None:
        """Intention: save a task's rating off the window's thread, then refresh the cards."""
        state = self.feed.state
        store = getattr(self.feed, "_store", None)

        def work():
            """Intention: the off-thread part — write the rating for this task."""
            return rate_user_task(state, task_id, rating=rating, store=store)

        later(work, lambda _: self.refresh())

    def _do_redo(self, task_id: str, statement: str) -> None:
        """Intention: send a passed task back to be redone off the window's thread, then refresh the cards."""
        state = self.feed.state
        store = getattr(self.feed, "_store", None)
        queue = getattr(self.feed, "queue", None)

        def work():
            """Intention: the off-thread part — reopen the task with Andrew's reason and put it back in the queue."""
            return redo_user_task(state, task_id, statement=statement, store=store, queue=queue)

        later(work, lambda _: self.refresh())
