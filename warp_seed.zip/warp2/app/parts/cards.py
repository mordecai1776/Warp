# WARP2/warp2/app/parts/cards.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/cards.py
#  Used by   : warp2/app/pages/*.py.
#  Uses      : PySide6, qfluentwidgets (card widgets and labels), warp2/app/theme.py.
#  Description:
#    Cards: a number with what it means (StatCard), a titled card that holds
#    anything (Panel), a thin bar of shares (ShareBar), and a coloured pill
#    for a state (Pill).
#  User intention (Andrew): runs show visual cues — the state of the machine
#    is seen at a glance.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath
from PySide6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget
from qfluentwidgets import BodyLabel, CaptionLabel, ElevatedCardWidget, SimpleCardWidget, StrongBodyLabel

from warp2.app import theme


class StatCard(ElevatedCardWidget):
    """A number, what it is, and a line under it."""

    def __init__(self, title: str, value: str = "—", caption: str = "", colour: str = theme.ACCENT,
                 parent=None) -> None:
        """Intention: the three lines and a coloured edge that says what kind of number it is."""
        super().__init__(parent)
        self.colour = QColor(colour)
        box = QVBoxLayout(self)
        box.setContentsMargins(20, 16, 20, 16)
        box.setSpacing(4)
        self.name = CaptionLabel(title.upper())
        self.name.setTextColor("#64748B", "#CBD5E1")
        self.name.setStyleSheet("font-weight: 600; letter-spacing: 0.5px; color: #CBD5E1;")
        self.value = QLabel(value)
        self.value.setStyleSheet(f"font-size: 30px; font-weight: 600; color: {colour}; background: transparent")
        self.caption = CaptionLabel(caption)
        self.caption.setTextColor("#64748B", "#CBD5E1")
        self.caption.setStyleSheet("color: #94A3B8;")
        self.caption.setWordWrap(True)
        box.addWidget(self.name)
        box.addWidget(self.value)
        box.addWidget(self.caption)
        self.setMinimumHeight(118)

    def set(self, value, caption: str | None = None, colour: str | None = None) -> None:
        """Intention: a new number (and line, and colour) shown."""
        self.value.setText(str(value))
        if caption is not None:
            self.caption.setText(caption)
        if colour is not None:
            self.colour = QColor(colour)
            self.value.setStyleSheet(f"font-size: 30px; font-weight: 600; color: {colour}; background: transparent")
        self.update()

    def paintEvent(self, event) -> None:
        """Intention: the card, and a thin coloured edge down its left side."""
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(QRectF(0, 10, 4, self.height() - 20), 2, 2)
        painter.fillPath(path, self.colour)


class Panel(SimpleCardWidget):
    """A card with a title, holding whatever is put in it."""

    def __init__(self, title: str, parent=None) -> None:
        """Intention: the title and an empty body."""
        super().__init__(parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 16, 20, 18)
        outer.setSpacing(10)
        head = QHBoxLayout()
        self.heading = StrongBodyLabel(title)
        self.heading.setStyleSheet("font-size: 14px; font-weight: 600; color: #F8FAFC;")
        head.addWidget(self.heading)
        head.addStretch(1)
        self.corner = QHBoxLayout()
        head.addLayout(self.corner)
        outer.addLayout(head)
        self.body = QVBoxLayout()
        self.body.setSpacing(8)
        outer.addLayout(self.body)

    def add(self, widget) -> QWidget:
        """Intention: one more thing in the card."""
        self.body.addWidget(widget)
        return widget


class ShareBar(QWidget):
    """A thin rounded bar split into coloured shares."""

    def __init__(self, parent=None) -> None:
        """Intention: empty until shares are set."""
        super().__init__(parent)
        self.shares: list = []
        self.setFixedHeight(10)

    def set(self, shares: list) -> None:
        """Intention: [(amount, colour)] drawn in order."""
        self.shares = [(max(0.0, float(a)), c) for a, c in shares]
        self.update()

    def paintEvent(self, event) -> None:
        """Intention: each share its width of the bar; an empty bar is one quiet track."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect())
        clip = QPainterPath()
        clip.addRoundedRect(rect, 5, 5)
        painter.setClipPath(clip)
        painter.fillRect(rect, QColor(148, 163, 184, 40))
        total = sum(a for a, _ in self.shares)
        x = 0.0
        for amount, colour in self.shares:
            if total <= 0:
                break
            width = rect.width() * amount / total
            painter.fillRect(QRectF(x, 0, width, rect.height()), QColor(colour))
            x += width


class Pill(QLabel):
    """A coloured pill with a word in it."""

    def __init__(self, text: str = "", colour: str = theme.QUIET, parent=None) -> None:
        """Intention: a state, readable at a glance."""
        super().__init__(parent)
        self.set(text, colour)

    def set(self, text: str, colour: str) -> None:
        """Intention: the word and its colour."""
        c = QColor(colour)
        self.setText(text)
        self.setStyleSheet(
            f"QLabel {{color: {colour}; background: rgba({c.red()},{c.green()},{c.blue()},38);"
            f"border: 1px solid rgba({c.red()},{c.green()},{c.blue()},90); border-radius: 11px;"
            f"padding: 3px 12px; font-weight: 600}}")


class KeyValue(QWidget):
    """A few lines of name: value."""

    def __init__(self, parent=None) -> None:
        """Intention: an empty list of lines."""
        super().__init__(parent)
        self.box = QVBoxLayout(self)
        self.box.setContentsMargins(0, 0, 0, 0)
        self.box.setSpacing(4)
        self.lines: list = []

    def set(self, pairs: list) -> None:
        """Intention: [(name, value)] shown one a line, the name quiet, the value plain."""
        for widget in self.lines:
            widget.deleteLater()
        self.lines = []
        for name, value in pairs:
            line = QWidget()
            h = QHBoxLayout(line)
            h.setContentsMargins(0, 0, 0, 0)
            left = CaptionLabel(str(name))
            left.setTextColor("#64748B", "#94A3B8")
            right = BodyLabel(str(value))
            right.setWordWrap(True)
            right.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            h.addWidget(left)
            h.addStretch(1)
            h.addWidget(right, 2)
            self.box.addWidget(line)
            self.lines.append(line)
