# WARP2/warp2/app/parts/kg_controls.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/kg_controls.py
#  Used by   : warp2/app/pages/knowledge.py.
#  Uses      : qfluentwidgets, PySide6, warp2/tags/grounding.py (NAMES).
#  Description:
#    The KG view's controls, in one bar that wraps to the window: which kinds
#    and relations are shown, the least grade, machinery hidden or not, a
#    web or relation to highlight; how many things, how deep around a picked
#    thing, which layout, fit and let go of pins; and a path between two
#    things. The bar only says what was chosen; the page draws it.
#  User intention (Andrew, 2026-09-25): "we need better controle in the kg
#    view" — filters, focus and expand, size and layout, search and paths.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QStringListModel, Qt, Signal
from PySide6.QtWidgets import QCompleter, QWidget
from qfluentwidgets import (Action, BodyLabel, CheckableMenu, ComboBox, CompactSpinBox, DropDownPushButton,
                            FlowLayout, FluentIcon, LineEdit, PushButton, Slider, SwitchButton)

# Intention: how many things the whole-graph view starts with — about as many
# dots as a person can still read as a picture. The slider goes as far as the
# graph does.
START_WITH = 250

LAYOUTS = ("Spring", "Radial", "Layers")


class CheckDrop(DropDownPushButton):
    """A drop-down of tick boxes — every item shown until it is unticked."""

    changed = Signal()

    def __init__(self, title: str = "", parent=None) -> None:
        """Intention: the button, its menu, and what is ticked.

        The Fluent button calls __init__ again with only the parent, so the
        title has a default and is kept only the first time.
        """
        super().__init__(parent)
        self.title = title or getattr(self, "title", "")
        self.setText(self.title)
        self.menu = CheckableMenu(parent=self)
        self.setMenu(self.menu)
        self.items: list = []
        self.off: set = set()

    def set_items(self, items: list) -> None:
        """Intention: the items there are now; what was unticked stays unticked, anything new is ticked."""
        if list(items) == self.items:
            return
        self.items = list(items)
        self.menu.clear()
        every = Action(FluentIcon.ACCEPT, "Show all")
        every.triggered.connect(lambda: self._all(True))
        none = Action(FluentIcon.CLOSE, "Hide all")
        none.triggered.connect(lambda: self._all(False))
        self.menu.addActions([every, none])
        self.menu.addSeparator()
        for item in self.items:
            action = Action(str(item or "(none)"), checkable=True)
            action.setChecked(item not in self.off)
            action.toggled.connect(lambda on, it=item: self._tick(it, on))
            self.menu.addAction(action)
        self._label()

    def _tick(self, item, on: bool) -> None:
        """Intention: one item ticked or unticked."""
        (self.off.discard if on else self.off.add)(item)
        self._label()
        self.changed.emit()

    def _all(self, on: bool) -> None:
        """Intention: every item at once, then drawn once."""
        self.off = set() if on else set(self.items)
        for action in self.menu.actions():
            if action.isCheckable():
                action.blockSignals(True)
                action.setChecked(on)
                action.blockSignals(False)
        self._label()
        self.changed.emit()

    def _label(self) -> None:
        """Intention: the button says how many are shown."""
        shown = len([i for i in self.items if i not in self.off])
        self.setText(f"{self.title}: {'all' if shown == len(self.items) else f'{shown} of {len(self.items)}'}")

    def shown(self):
        """Intention: the shown items, or None when all are (no filter)."""
        return None if not self.off else {i for i in self.items if i not in self.off}


class Completing(LineEdit):
    """A line to type a thing's name in, suggesting names as it goes."""

    def __init__(self, hint: str, parent=None) -> None:
        """Intention: the suggestions match anywhere in the name, case ignored."""
        super().__init__(parent)
        self.setPlaceholderText(hint)
        self.setClearButtonEnabled(True)
        self.names = QStringListModel(self)
        finder = QCompleter(self.names, self)
        finder.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        finder.setFilterMode(Qt.MatchFlag.MatchContains)
        finder.setMaxVisibleItems(12)
        self.setCompleter(finder)

    def know(self, names: list) -> None:
        """Intention: the names it can suggest."""
        if self.names.stringList() != names:
            self.names.setStringList(names)


class KgControls(QWidget):
    """The controls bar."""

    changed = Signal()
    path_asked = Signal(str, str)
    fit_asked = Signal()
    unpin_asked = Signal()

    def __init__(self, parent=None) -> None:
        """Intention: every control, laid out to wrap; each change says so once."""
        super().__init__(parent)
        from warp2.tags.grounding import NAMES
        flow = FlowLayout(self, needAni=False)
        flow.setHorizontalSpacing(10)
        flow.setVerticalSpacing(10)
        flow.setContentsMargins(0, 0, 0, 0)
        self.kinds = CheckDrop("Kinds")
        self.relations = CheckDrop("Relations")
        self.grade = ComboBox()
        self.grades = [0] + sorted(g for g in NAMES if g > 0)
        self.grade.addItems(["any grade"] + [f"{NAMES[g]} or better" if g < max(NAMES) else NAMES[g]
                                             for g in self.grades[1:]])
        self.machinery = SwitchButton()
        self.machinery.setOnText("machinery hidden")
        self.machinery.setOffText("machinery shown")
        self.machinery.setChecked(True)
        self.highlight = ComboBox()
        self.highlight.addItem("highlight nothing")
        self.marks: list = [("", "")]
        self.most_label = BodyLabel(f"{START_WITH} things")
        self.most = Slider(Qt.Orientation.Horizontal)
        self.most.setFixedWidth(180)
        self.most.setRange(10, START_WITH)
        self.most.setValue(START_WITH)
        # Intention: what was ASKED for, kept apart from what the graph can
        # give now — a small first reading must not shrink it for good.
        self.wanted = START_WITH
        self.depth = CompactSpinBox()
        self.depth.setRange(1, 99)
        self.depth.setValue(1)
        self.depth.setPrefix("depth ")
        self.layout_pick = ComboBox()
        self.layout_pick.addItems(list(LAYOUTS))
        fit = PushButton(FluentIcon.FIT_PAGE, "Fit")
        unpin = PushButton(FluentIcon.PIN, "Let go of pins")
        self.start = Completing("Path from…")
        self.end = Completing("…to")
        for line in (self.start, self.end):
            line.setFixedWidth(200)
        go = PushButton(FluentIcon.SHARE, "Find path")
        for widget in (self.kinds, self.relations, self.grade, self.machinery, self.highlight,
                       self.most_label, self.most, self.depth, self.layout_pick, fit, unpin,
                       self.start, self.end, go):
            flow.addWidget(widget)
        self.kinds.changed.connect(self.changed)
        self.relations.changed.connect(self.changed)
        self.grade.currentIndexChanged.connect(lambda _i: self.changed.emit())
        self.machinery.checkedChanged.connect(lambda _on: self.changed.emit())
        self.highlight.currentIndexChanged.connect(lambda _i: self.changed.emit())
        self.most.valueChanged.connect(self._moved)
        self.most.sliderReleased.connect(self.changed)
        self.depth.valueChanged.connect(lambda _v: self.changed.emit())
        self.layout_pick.currentIndexChanged.connect(lambda _i: self.changed.emit())
        fit.clicked.connect(self.fit_asked)
        unpin.clicked.connect(self.unpin_asked)
        go.clicked.connect(lambda: self.path_asked.emit(self.start.text().strip(), self.end.text().strip()))

    def know(self, kinds: list, relations: list, names: list, most: int) -> None:
        """Intention: what there is to choose from, as it changes; the slider as long as the graph."""
        self.kinds.set_items(kinds)
        self.relations.set_items(relations)
        self.start.know(names)
        self.end.know(names)
        top = max(10, int(most))
        if self.most.maximum() != top:
            self.most.blockSignals(True)
            self.most.setRange(10, top)
            self.most.setValue(min(self.wanted, top))
            self.most.blockSignals(False)
            self.most_label.setText(f"{self.most.value():,} things")

    def _moved(self, value: int) -> None:
        """Intention: a move by hand is what is wanted from now on."""
        self.wanted = int(value)
        self.most_label.setText(f"{value:,} things")

    def know_marks(self, marks: list) -> None:
        """Intention: what can be highlighted — [(kind, value)] as ("web", id) or ("relation", name)."""
        wanted = [("", "")] + list(marks)
        if wanted == self.marks:
            return
        was = self.marks[self.highlight.currentIndex()] if 0 <= self.highlight.currentIndex() < len(self.marks) else ("", "")
        self.highlight.blockSignals(True)
        self.highlight.clear()
        self.highlight.addItem("highlight nothing")
        for kind, value in marks:
            self.highlight.addItem(f"{kind}: {value[1] if isinstance(value, tuple) else value}")
        self.marks = wanted
        self.highlight.setCurrentIndex(wanted.index(was) if was in wanted else 0)
        self.highlight.blockSignals(False)

    def chosen(self) -> dict:
        """Intention: everything chosen, in one reading."""
        at = self.highlight.currentIndex()
        mark = self.marks[at] if 0 <= at < len(self.marks) else ("", "")
        return {"kinds": self.kinds.shown(), "relations": self.relations.shown(),
                "least_grade": self.grades[max(0, self.grade.currentIndex())],
                "hide_machinery": self.machinery.isChecked(), "mark": mark,
                "most": self.most.value(), "depth": self.depth.value(),
                "layout": LAYOUTS[max(0, self.layout_pick.currentIndex())].lower()}
