# WARP2/warp2/app/parts/standing_words.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/standing_words.py
#  Used by   : warp2/app/pages/home.py (HomePage.stand, HomePage.draw),
#              warp2/app/parts/now_view.py (RunningEngineCard),
#              warp2/app/parts/health_card.py (memory and the long step).
#  Uses      : warp2/app/theme.py (the colours), warp2/app/parts/tone.py (age).
#  Description:
#    The plain words and colours for how the machine stands, kept apart from
#    the widgets so they can be tested without a window: the state pill
#    (stopped, paused for memory, a step running long, running, not running,
#    or cannot tell), the main runner's step in flight with how long it has
#    run against its usual time, a colour that warms as a step runs past its
#    usual time or as free memory nears the runner's measured floor (a
#    temperature, not a switch), and a stored UTC time shown in this
#    machine's own clock.
#  User intention (Andrew, 2026-11-08): "The gui still doesn't say everything
#    is going fix it", then "look for other silly mistakes that could be in
#    the gui and try to get in lign with what a person would want to see."
#    Measured that night: the window said "read the frontier · 1m ago" (the
#    research lane's last finished step) while the main runner had been in
#    teach_eye_what_was_made for two hours, 5.5 times its usual.
# ============================================================================
"""How the machine stands, in words and colours a person reads at a glance."""
from __future__ import annotations

import re
from datetime import datetime

from warp2.app import theme
from warp2.app.parts import tone


def blend(cold: str, hot: str, heat) -> str:
    """Intention: a colour between two, by a heat from 0 (cold) to 1 (hot) - a temperature, never a switch."""
    try:
        t = max(0.0, min(1.0, float(heat)))
    except (TypeError, ValueError):
        return theme.QUIET
    a = [int(cold[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(hot[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x + (y - x) * t):02X}" for x, y in zip(a, b))


def step_heat(step: dict):
    """The share of the step's running time that is past its usual time: 0 within it, nearer 1 the longer past.

    Intention: measured from the step's own usual time (warp2/control/overdue.py), no set number; None when the
    step or its usual time is not known.
    """
    step = step or {}
    running, usual = step.get("running_seconds"), step.get("usual_seconds")
    if type(running) not in (int, float) or type(usual) not in (int, float) or running <= 0:
        return None
    return max(0.0, (running - usual) / running)


def step_words(step: dict) -> str:
    """Intention: "teach eye what was made - 1.9 h (usually 20 min)"; "" when no step is known to be in flight."""
    step = step or {}
    verb = step.get("verb")
    if not verb:
        return ""
    words = f"{str(verb).replace('_', ' ')} - {tone.age(step.get('running_seconds'))}"
    if type(step.get("usual_seconds")) in (int, float):
        words += f" (usually {tone.age(step['usual_seconds'])})"
    return words


def memory_heat(free_mb, floor_mb):
    """How near free memory is to the runner's measured floor: 1 at or under it, 0 at twice it or more.

    Intention: the floor the runner really waits on (warp2/work/memory_gate.py floor_bytes, measured) is the
    scale, not a set number; None when either is unknown.
    """
    if type(free_mb) not in (int, float) or type(floor_mb) not in (int, float) or floor_mb <= 0:
        return None
    return max(0.0, min(1.0, (2.0 * floor_mb - free_mb) / floor_mb))


def waiting_for_memory(stand: dict) -> dict:
    """Intention: the runner's last word about memory when it says it is waiting; {} otherwise."""
    said = (((stand or {}).get("health") or {}).get("memory_said") or {}).get("last") or {}
    return said if said.get("waiting") else {}


def pill(stand: dict) -> tuple:
    """The state pill: (words, colour, button) - button is "Resume", "Stop", "Start" or "" (none offered).

    Intention: what is true, said once. Stopped when the stop is raised. Can't tell when the process list could
    not be read - never "Not running", whose Start could start a second runner beside a live one. Not running
    only when the process list and the runner's beat both say so. A runner waiting for memory says so; one whose
    step runs past its usual time says that, coloured by how far past.
    """
    stand = stand or {}
    alive = ((stand.get("health") or {}).get("runner_alive"))
    if stand.get("stopped"):
        return "■ Stopped", theme.WARN, "Resume"
    running = stand.get("running")
    if running is None:
        return "? Can't tell if it is running", theme.QUIET, ""
    if not running:
        if alive:
            return "? Runner beating, process not seen", theme.WARN, ""
        return "○ Not running", theme.QUIET, "Start"
    wait = waiting_for_memory(stand)
    if wait:
        need = stand.get("floor_mb")
        words = f"⏸ Paused for memory ({tone.number(wait.get('free_mb'), 0)} MB free"
        words += f", needs {tone.number(need, 0)} MB)" if type(need) in (int, float) else ")"
        return words, theme.WARN, "Stop"
    step = stand.get("step") or {}
    if step.get("overdue"):
        return "● Running - a step is taking long", blend(theme.GOOD, theme.BAD, step_heat(step)), "Stop"
    return "● Running", theme.GOOD, "Stop"


def doing_line(stand: dict) -> str:
    """Intention: what each lane is on now - the main runner's step in flight first, then the latest finished step."""
    stand = stand or {}
    parts = []
    words = step_words(stand.get("step"))
    if words:
        parts.append(f"Main runner: {words}")
    if stand.get("doing"):
        parts.append(f"Latest finished: {stand['doing']}")
    if stand.get("why"):
        parts.append(f"stopped because: {stand['why']}")
    return " · ".join(parts)


def local_time(stamp, clock_only: bool = False) -> str:
    """Intention: a stored UTC time ("2026-11-09T01:47:37+00:00") in this machine's own clock, as the person
    reads it - the time of day alone when asked; the text as it was when it is not a time."""
    text = str(stamp or "")
    try:
        when = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return text
    if when.tzinfo is not None:
        when = when.astimezone()
    return when.strftime("%H:%M:%S" if clock_only else "%Y-%m-%d %H:%M:%S")


# Intention: a local reading time as the watcher writes it ("2026-11-08 16:55:30").
LOCAL_STAMP = re.compile(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d")


def measured_age(when: str, now: float):
    """Intention: seconds since a local "YYYY-MM-DD HH:MM:SS" reading was taken; None when it is not such a time
    (looked at first, so nothing is caught and filled in)."""
    found = LOCAL_STAMP.match(str(when or ""))
    if found is None:
        return None
    return max(0.0, now - datetime.fromisoformat(found.group(0)).timestamp())
