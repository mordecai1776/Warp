# WARP2/warp2/app/parts/warp_tasks_view.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/warp_tasks_view.py
#  Used by   : warp2/app/parts/now_view.py (below user tasks on the right side).
#  Uses      : warp2/work/warp_tasks.py, warp2/app/theme.py,
#              warp2/app/parts/worker.py (later), PySide6, qfluentwidgets.
#  Description:
#    Compact view for autonomous internal warp engine tasks (skills, splits,
#    derivations, improvements).
#    Stringently enforced until_it_passes=True: tasks cannot stop until
#    mechanically verified passed.
#    Autonomous: dealt with by the warp without user rating or redo buttons.
#  User intention (Andrew, 2026-09-27):
#    "make something smaller that just shows a min of them below it for warp task
#    like that and have them follow the same striengent path as user task. They
#    should be seprate though to define user task as the thing to interact with
#    and the others to be dealt with by the warp."
# ============================================================================
from __future__ import annotations

from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout
from qfluentwidgets import CaptionLabel, CardWidget, StrongBodyLabel

from warp2.app import theme
from warp2.app.parts.cards import Pill
from warp2.app.parts.worker import later
from warp2.work.warp_tasks import get_warp_tasks


class CompactWarpTaskRow(CardWidget):
    """A minimal, compact row showing an autonomous internal warp engine task."""

    def __init__(self, task: dict[str, Any], parent=None) -> None:
        """Intention: build one row for a task the warp handles itself — kind, retry/autonomous pill, title, target."""
        super().__init__(parent)
        box = QVBoxLayout(self)
        box.setContentsMargins(10, 8, 10, 8)
        box.setSpacing(4)

        top = QHBoxLayout()
        top.setSpacing(6)

        kind = str(task.get("kind") or "task").upper()
        kind_badge = CaptionLabel(f"⚙ {kind}")
        kind_badge.setTextColor(theme.ACCENT, theme.ACCENT)
        top.addWidget(kind_badge)
        top.addStretch(1)

        is_retry = task.get("status") == "retrying_until_passes"
        pill_text = "⚡ Retrying until passes" if is_retry else "⚡ Autonomous"
        pill_color = theme.WARN if is_retry else "#64748B"
        top.addWidget(Pill(pill_text, pill_color))
        box.addLayout(top)

        title = StrongBodyLabel(str(task.get("title") or task.get("compact_target") or "Task"))
        title.setWordWrap(True)
        box.addWidget(title)

        verif = str(task.get("verification") or "Verified by contract")
        rule_lbl = CaptionLabel(f"Target: {task.get('compact_target') or task.get('target')}")
        rule_lbl.setTextColor("#64748B", "#94A3B8")
        rule_lbl.setToolTip(f"Verification contract: {verif}")
        rule_lbl.setWordWrap(True)
        box.addWidget(rule_lbl)

        contract_lbl = CaptionLabel("Rule: stringent · will not stop until verified passed")
        contract_lbl.setTextColor("#475569", "#64748B")
        contract_lbl.setStyleSheet("font-size: 10px; font-style: italic;")
        box.addWidget(contract_lbl)


class WarpTasksView(QFrame):
    """Minimal autonomous warp engine tasks panel placed below user tasks."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: build the WARP ENGINE TASKS box (header, pill, row list) and refresh it from the feed."""
        super().__init__(parent)
        self.feed = feed
        self.setObjectName("warpTasksView")
        self.setStyleSheet("#warpTasksView {border: none; background: transparent;}")

        self.box = QVBoxLayout(self)
        self.box.setContentsMargins(0, 10, 0, 8)
        self.box.setSpacing(6)

        head = QHBoxLayout()
        title = CaptionLabel("WARP ENGINE TASKS")
        title.setTextColor("#64748B", "#94A3B8")
        head.addWidget(title)
        head.addStretch(1)
        self.status_pill = Pill("Autonomous", "#64748B")
        head.addWidget(self.status_pill)
        self.box.addLayout(head)

        sub_desc = CaptionLabel("Handled by warp · Stringent verification · Stays until passes")
        sub_desc.setTextColor("#475569", "#64748B")
        sub_desc.setStyleSheet("font-size: 10px;")
        sub_desc.setWordWrap(True)
        self.box.addWidget(sub_desc)

        self.cards_box = QVBoxLayout()
        self.cards_box.setSpacing(6)
        self.box.addLayout(self.cards_box)

        self._updating = False
        # Intention (2026-10-31, Remy for Andrew): the quick reading comes each second and this read can take
        # longer than that; it is redone after a pause of its own cost (warp2/app/parts/paced.py).
        from warp2.app.parts.paced import Paced
        self._paced = Paced()
        feed.standing.connect(self._tick)
        feed.snapshot.connect(self._on_snapshot)

    def _tick(self, _stand: dict) -> None:
        """Intention: on each quick reading, refresh the list if it is shown and not already refreshing."""
        if not self.isVisible() or self._updating or not self._paced.due():
            return
        self.refresh()

    def _on_snapshot(self, _snap: dict) -> None:
        """Intention: on each full snapshot, refresh the list if it is shown and not already refreshing."""
        if not self.isVisible() or self._updating:
            return
        self.refresh()

    def refresh(self) -> None:
        """Intention: read the warp's own open tasks off the window's thread, then fill the rows; one read at a time."""
        if self._updating:
            return
        self._updating = True
        state = self.feed.state

        def paced_read():
            """Intention: the read below, its cost measured for the pace."""
            with self._paced.reading():
                return read()

        def read():
            """Intention: the off-thread part — up to 4 of the warp's tasks from the store."""
            store = getattr(self.feed, "_store", None)
            return get_warp_tasks(state, store=store, limit=4)

        later(paced_read, self._fill, lambda _w: setattr(self, "_updating", False))

    def _fill(self, tasks: list[dict[str, Any]]) -> None:
        """Intention: replace the rows with the tasks just read and set the pill; say "nothing open" when empty."""
        self._updating = False

        # Clear existing rows
        while self.cards_box.count():
            item = self.cards_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        count = len(tasks)
        if count > 0:
            self.status_pill.setText(f"⚡ {count} Active · Stringent")
            self.status_pill.setStyleSheet(
                f"background: rgba(148,163,184,0.15); color: #94A3B8; "
                f"border: 1px solid rgba(148,163,184,0.3); border-radius: 10px; padding: 2px 8px; font-size: 11px;"
            )
            for task in tasks:
                row = CompactWarpTaskRow(task)
                self.cards_box.addWidget(row)
        else:
            # Intention (2026-10-02): an empty list says nothing open, not
            # "all passed" — it is also what a failed read looks like.
            self.status_pill.setText("● Nothing open")
            self.status_pill.setStyleSheet(
                f"background: rgba(52,211,153,0.15); color: {theme.GOOD}; "
                f"border: 1px solid {theme.GOOD}; border-radius: 10px; padding: 2px 8px; font-size: 11px;"
            )
            placeholder = CardWidget()
            p_box = QVBoxLayout(placeholder)
            p_box.setContentsMargins(10, 10, 10, 10)
            lbl = CaptionLabel("No open warp engine tasks.\nSkills, splits, and improvements will show here as they run.")
            lbl.setTextColor("#64748B", "#94A3B8")
            lbl.setWordWrap(True)
            p_box.addWidget(lbl)
            self.cards_box.addWidget(placeholder)
