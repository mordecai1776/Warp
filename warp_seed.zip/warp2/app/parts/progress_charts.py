# WARP2/warp2/app/parts/progress_charts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/progress_charts.py
#  Used by   : warp2/app/pages/improving.py.
#  Uses      : pyqtgraph, PySide6, warp2/app/parts/chart.py (see_through),
#              warp2/app/theme.py.
#  Description:
#    The two charts that answer "is it improving": every training round's
#    held-out pass rate against what it had to beat (a promoted round marked
#    with a star, so none being there is plain to see), and graded answers
#    by day (bars for the share that passed, a line for the mean score, the
#    count of answers under each day). Drawn only from measured numbers — a
#    round nobody measured leaves a gap, not a zero.
#  User intention (Andrew, 2026-10-16): "is there any indication that we're on
#    that route?"; runs "show visual cues".
# ============================================================================
from __future__ import annotations

import pyqtgraph as pg
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor

from warp2.app import theme
from warp2.app.parts.chart import see_through


def styled(plot: pg.PlotWidget, height: int) -> pg.PlotWidget:
    """Intention: a chart dressed like the rest of the window — clear, thin grid, quiet axes, 0..1 up the side."""
    see_through(plot)
    plot.setMinimumHeight(height)
    plot.showGrid(x=False, y=True, alpha=0.12)
    item = plot.getPlotItem()
    item.setMenuEnabled(False)
    item.hideButtons()
    item.getAxis("left").setWidth(44)
    for side in ("left", "bottom"):
        axis = item.getAxis(side)
        axis.setPen(pg.mkPen(QColor(148, 163, 184, 60)))
        axis.setTextPen(pg.mkPen("#94A3B8"))
    plot.setYRange(0.0, 1.0, padding=0.04)
    plot.getAxis("left").setTicks([[(v, f"{v:.0%}") for v in (0.0, 0.25, 0.5, 0.75, 1.0)]])
    return plot


class RoundsChart(pg.PlotWidget):
    """Each training round: what it passed, what it had to beat, and whether it was promoted."""

    def __init__(self, parent=None) -> None:
        """Intention: three layers — the bar it had to beat, its own pass rate, stars for promotions."""
        super().__init__(parent=parent)
        styled(self, 230)
        self.legend = self.addLegend(offset=(8, 4), labelTextColor="#94A3B8")
        self.against = self.plot([], [], name="had to beat", connect="finite",
                                 pen=pg.mkPen(theme.QUIET, width=1.5, style=Qt.PenStyle.DashLine))
        self.passed = self.plot([], [], name="its pass rate", connect="finite",
                                pen=pg.mkPen(theme.ACCENT, width=2), symbol="o", symbolSize=6,
                                symbolBrush=theme.ACCENT, symbolPen=None)
        self.stars = pg.ScatterPlotItem(symbol="star", size=16, brush=pg.mkBrush(theme.GOOD), pen=None)
        self.addItem(self.stars)
        self.legend.addItem(self.stars, "promoted")
        self.getAxis("bottom").setLabel("round, oldest to newest", color="#94A3B8")

    def set(self, rounds: list) -> None:
        """Intention: one point per finished round; an unmeasured round is a gap (NaN), never zero."""
        nan = float("nan")
        xs = list(range(1, len(rounds) + 1))
        passed = [r["pass_rate"] if r.get("pass_rate") is not None else nan for r in rounds]
        against = [r["against"] if r.get("against") is not None else nan for r in rounds]
        self.passed.setData(xs, passed)
        self.against.setData(xs, against)
        promoted = [(x, r["pass_rate"]) for x, r in zip(xs, rounds)
                    if r.get("promoted") and r.get("pass_rate") is not None]
        self.stars.setData([p[0] for p in promoted], [p[1] for p in promoted])
        if xs:
            self.setXRange(0.5, len(xs) + 0.5, padding=0)


class DaysChart(pg.PlotWidget):
    """Graded answers, day by day: the share that passed, and the mean score."""

    def __init__(self, parent=None) -> None:
        """Intention: bars for the passed share, a line over them for the mean score."""
        super().__init__(parent=parent)
        styled(self, 210)
        self.legend = self.addLegend(offset=(8, 4), labelTextColor="#94A3B8")
        self.bars = pg.BarGraphItem(x=[], height=[], width=0.62, brush=QColor(74, 222, 128, 150), pen=None)
        self.addItem(self.bars)
        self.legend.addItem(self.bars, "share passed")
        self.mean = self.plot([], [], name="mean score", connect="finite", pen=pg.mkPen("#F472B6", width=2),
                              symbol="o", symbolSize=5, symbolBrush="#F472B6", symbolPen=None)

    def set(self, days: list) -> None:
        """Intention: one bar per day with answers; under it the day and how many answers it rests on."""
        nan = float("nan")
        xs = list(range(len(days)))
        self.bars.setOpts(x=xs, height=[d.get("passed_share") or 0.0 for d in days])
        self.mean.setData(xs, [d["mean_score"] if d.get("mean_score") is not None else nan for d in days])
        self.getAxis("bottom").setTicks([[(i, f"{str(d['day'])[5:]}\n{d['n']}") for i, d in enumerate(days)]])
        if xs:
            self.setXRange(-0.6, len(xs) - 0.4, padding=0)
