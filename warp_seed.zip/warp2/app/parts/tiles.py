# WARP2/warp2/app/parts/tiles.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/tiles.py
#  Used by   : warp2/app/pages/home.py (what it has, what it does).
#  Uses      : PySide6, qfluentwidgets (CardWidget), warp2/app/theme.py;
#              (stdlib) re.
#  Description:
#    Small cards laid out in a grid that fits the width it has — as many
#    across as there is room for, so nothing is squeezed or left in a long
#    table. Two kinds:
#      * Tile — one capability: a dot in the colour of how it last ended,
#        its name, how long ago and how many runs, and a thin bar of how its
#        runs have ended; clicking opens its tab;
#      * HeldTile — one thing the warp holds: its number large, what it is
#        under it.
#  User intention (Andrew, 2026-09-25): "Tidy layout/spacing" — "The shown
#    data needs to be pruned out to what is needed to understand with more of
#    a visuals centered concept".
# ============================================================================
from __future__ import annotations

import re

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QGridLayout, QLabel, QVBoxLayout, QWidget
from qfluentwidgets import CaptionLabel, CardWidget, StrongBodyLabel

from warp2.app import theme
from warp2.app.parts.cards import ShareBar

# Intention: the width one tile wants; the grid fits as many across as it can.
TILE_WIDTH = 250


class Tile(CardWidget):
    """One capability, at a glance."""

    opened = Signal(str)

    def __init__(self, key: str, name: str, line: str, colour: str, ended: list, parent=None) -> None:
        """Intention: the dot and name, the line under it, and the bar of how its runs ended."""
        super().__init__(parent)
        self.key = str(key)
        box = QVBoxLayout(self)
        box.setContentsMargins(14, 10, 14, 10)
        box.setSpacing(4)
        head = StrongBodyLabel(f"<span style='color:{colour}'>●</span>&nbsp; {name}")
        head.setTextFormat(Qt.TextFormat.RichText)
        box.addWidget(head)
        words = CaptionLabel(line)
        words.setTextColor("#64748B", "#94A3B8")
        box.addWidget(words)
        bar = ShareBar()
        bar.setFixedHeight(5)
        bar.set(ended)
        box.addWidget(bar)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.clicked.connect(lambda: self.opened.emit(self.key))


class HeldTile(CardWidget):
    """One thing the warp holds: its number large, what it is under it."""

    opened = Signal(str)

    # Intention: the same holdings on Home and Capabilities lead to their tabs.
    DESTINATIONS = {"Models": "models", "Projects": "structure", "Knowledge graph": "knowledge",
                    "The Eye": "eye_tree", "Seed & hardware fit": "connections", "Surface Golem": "connections"}

    def __init__(self, name: str, said: str, parent=None) -> None:
        """Intention: the leading number of what was read, big; the rest as a caption."""
        super().__init__(parent)
        self.key = self.DESTINATIONS.get(name, "")
        if self.key:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
            self.clicked.connect(lambda: self.opened.emit(self.key))
        box = QVBoxLayout(self)
        box.setContentsMargins(14, 10, 14, 10)
        box.setSpacing(2)
        top = CaptionLabel(str(name).upper())
        top.setTextColor("#64748B", "#94A3B8")
        box.addWidget(top)
        found = re.match(r"\s*([\d,.]+)\s*(.*)", str(said))
        value, rest = (found.group(1), found.group(2)) if found else (str(said), "")
        big = QLabel(value)
        big.setStyleSheet(f"font-size: 22px; font-weight: 600; color: {theme.ACCENT}; background: transparent")
        box.addWidget(big)
        rest = rest.strip(" ()—-")
        if rest:
            under = CaptionLabel(rest if len(rest) <= 70 else rest[:68] + "…")
            under.setTextColor("#64748B", "#94A3B8")
            under.setWordWrap(True)
            box.addWidget(under)


class TileGrid(QWidget):
    """Tiles, as many across as the width holds."""

    def __init__(self, parent=None, tile_width: int = TILE_WIDTH) -> None:
        """Intention: an empty grid; `tile_width` is the least width one of its tiles wants."""
        super().__init__(parent)
        self.tile_width = int(tile_width)
        self.grid = QGridLayout(self)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(10)
        self.tiles: list = []
        self.across = 0

    def fill(self, tiles: list) -> None:
        """Intention: the old tiles let go and the new ones laid out."""
        for tile in self.tiles:
            self.grid.removeWidget(tile)
            tile.deleteLater()
        self.tiles = list(tiles)
        self._lay()

    def _fits(self) -> int:
        """Intention: how many tiles fit across the width there is."""
        return max(1, self.width() // self.tile_width)

    def _lay(self) -> None:
        """Intention: the tiles placed row by row, as many across as fit, each column an equal share."""
        for tile in self.tiles:
            self.grid.removeWidget(tile)
        for c in range(self.grid.columnCount()):
            self.grid.setColumnStretch(c, 0)
        self.across = self._fits()
        for i, tile in enumerate(self.tiles):
            self.grid.addWidget(tile, i // self.across, i % self.across)
        for c in range(self.across):
            self.grid.setColumnStretch(c, 1)

    def resizeEvent(self, event) -> None:
        """Intention: laid out again only when a different number of tiles now fit across."""
        super().resizeEvent(event)
        if self._fits() != self.across:
            self._lay()
