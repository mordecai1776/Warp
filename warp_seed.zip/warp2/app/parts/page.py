# WARP2/warp2/app/parts/page.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/page.py
#  Used by   : every page in warp2/app/pages/.
#  Uses      : PySide6, qfluentwidgets (ScrollArea, TitleLabel, BodyLabel).
#  Description:
#    The frame every page shares: a title, a line saying what the page is for,
#    and a body that scrolls smoothly. A page is handed each new reading of
#    the machine, but only draws it while it is the page being looked at — a
#    hidden page keeps the reading and draws it when it is shown.
#  User intention (Andrew): the window never freezes the thing it watches.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QWidget
from qfluentwidgets import BodyLabel, ScrollArea, TitleLabel


class Page(ScrollArea):
    """One page of the window."""

    def __init__(self, name: str, title: str, says: str, parent=None) -> None:
        """Intention: the title, what it is for, and a body the page fills."""
        super().__init__(parent)
        self.setObjectName(name)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setStyleSheet("QScrollArea {border: none; background: transparent}")
        self.inner = QWidget()
        self.inner.setObjectName("inner")
        self.inner.setStyleSheet("#inner {background: transparent}")
        self.body = QVBoxLayout(self.inner)
        self.body.setContentsMargins(36, 28, 36, 28)
        self.body.setSpacing(16)
        head = QHBoxLayout()
        words = QVBoxLayout()
        words.setSpacing(2)
        self.title = TitleLabel(title)
        self.says = BodyLabel(says)
        self.says.setTextColor("#64748B", "#94A3B8")
        words.addWidget(self.title)
        words.addWidget(self.says)
        head.addLayout(words, 1)
        self.tools = QHBoxLayout()
        self.tools.setSpacing(8)
        head.addLayout(self.tools)
        self.body.addLayout(head)
        self.setWidget(self.inner)
        self.pending: dict | None = None

    def take(self, snapshot: dict) -> None:
        """Intention: a new reading kept; drawn now only if this page is showing."""
        self.pending = snapshot
        if self.isVisible():
            self._draw()

    def showEvent(self, event) -> None:
        """Intention: a page shown draws the newest reading it was handed."""
        super().showEvent(event)
        self._draw()

    def _draw(self) -> None:
        """Intention: the newest reading drawn once."""
        if self.pending is not None:
            snapshot, self.pending = self.pending, None
            self.draw(snapshot)

    def draw(self, snapshot: dict) -> None:
        """Intention: each page draws what it shows from a reading."""


def row(*widgets, stretch_last: bool = False) -> QHBoxLayout:
    """Intention: widgets side by side, evenly spaced."""
    line = QHBoxLayout()
    line.setSpacing(16)
    for i, widget in enumerate(widgets):
        line.addWidget(widget, 1 if (not stretch_last or i == len(widgets) - 1) else 0)
    return line
