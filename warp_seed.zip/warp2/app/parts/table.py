# WARP2/warp2/app/parts/table.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/table.py
#  Used by   : warp2/app/pages/*.py.
#  Uses      : PySide6, qfluentwidgets (TableWidget).
#  Description:
#    A Fluent table filled from rows, keeping the row a person picked when it
#    is filled again, with an optional colour per cell.
#  User intention (Andrew): the old tabs' lists, kept, looking right.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QAbstractItemView, QHeaderView, QTableWidgetItem
from qfluentwidgets import TableWidget


class Table(TableWidget):
    """Rows of cells, filled again as readings arrive."""

    def __init__(self, headers: list, parent=None, stretch: int = -1) -> None:
        """Intention: the columns; the `stretch` column takes the spare width."""
        super().__init__(parent)
        self.setColumnCount(len(headers))
        self.setHorizontalHeaderLabels(headers)
        self.verticalHeader().hide()
        self.setBorderVisible(True)
        self.setBorderRadius(8)
        self.setWordWrap(False)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        header = self.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(stretch if stretch >= 0 else len(headers) - 1, QHeaderView.ResizeMode.Stretch)
        self.setStyleSheet(
            "QTableView { background: transparent; color: #F1F5F9; border: 1px solid rgba(255, 255, 255, 25); }"
            "QTableView::item { color: #F1F5F9; font-size: 13px; padding-left: 12px; padding-right: 12px; }"
            "QTableView::item:selected { background: rgba(56, 189, 248, 0.25); color: #FFFFFF; }"
            "QHeaderView::section { background: rgba(30, 41, 59, 0.7); color: #CBD5E1; font-weight: 600; font-size: 12px; }"
        )
        self.keys: list = []

    def fill(self, rows: list, keys: list | None = None, colours: dict | None = None) -> None:
        """Rows of values; `keys` name each row so the picked one stays picked; `colours` {(row, col): colour}.

        Intention: a table filled again does not jump — the same row stays
        picked and the view stays where it was.
        """
        picked = self.picked()
        self.setUpdatesEnabled(False)
        self.setRowCount(len(rows))
        for r, values in enumerate(rows):
            for c, value in enumerate(values):
                item = QTableWidgetItem("" if value is None else str(value))
                item.setData(Qt.ItemDataRole.UserRole, value)
                if colours and (r, c) in colours:
                    item.setForeground(QColor(colours[(r, c)]))
                else:
                    item.setForeground(QColor("#F1F5F9"))
                self.setItem(r, c, item)
        self.keys = list(keys) if keys is not None else [str(v[0]) if v else "" for v in rows]
        if picked in self.keys:
            self.selectRow(self.keys.index(picked))
        self.setUpdatesEnabled(True)

    def picked(self) -> str:
        """Intention: the key of the picked row, or ""."""
        rows = self.selectionModel().selectedRows() if self.selectionModel() else []
        if rows and rows[0].row() < len(self.keys):
            return self.keys[rows[0].row()]
        return ""
