# WARP2/warp2/app/parts/kg_reads.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/kg_reads.py
#  Used by   : warp2/app/pages/knowledge.py (highlight a web; a thing's
#              neighbourhood and facts), warp2/app/pages/webs.py (a web's members).
#  Uses      : warp2/webs/home.py (the webs file), warp2/store/store.py (read
#              only), warp2/ui/snapshot.py (get_entity_subgraph),
#              warp2/tags/grounding.py.
#  Description:
#    The reads the KG view makes off the window's thread: the webs there are,
#    one web's members, and a thing's neighbourhood to a depth with its facts
#    and their grades. Nothing here writes.
#  User intention (Andrew, 2026-09-25): "better controle in the kg view".
# ============================================================================
from __future__ import annotations


def web_list(state) -> list:
    """Intention: every web, (id, kind, name, size), biggest first within a kind."""
    from warp2.webs.home import db
    con = db(state)
    try:
        return list(con.execute("SELECT id, kind, name, size FROM web ORDER BY kind, size DESC"))
    finally:
        con.close()


def web_members(state, web: str) -> list:
    """Intention: a web's members, strongest first, with their grade and where the grade came from."""
    from warp2.webs.home import db
    con = db(state)
    try:
        return list(con.execute("SELECT m.subject, m.strength, p.level, p.origin FROM member m LEFT JOIN proof p "
                                "ON p.subject = m.subject WHERE m.web = ? ORDER BY m.strength DESC", (web,)))
    finally:
        con.close()


def neighbourhood(root, state, subject: str, depth: int) -> tuple:
    """(subgraph, facts with grades) for one thing, read from the store.

    Intention: the depth is the person's choice; the store answers it. The
    snapshot reader and the store are both closed before this returns.
    """
    from warp2.store.store import Store, store_home
    from warp2.tags import grounding
    from warp2.ui.snapshot import ObserverSnapshot
    reader = ObserverSnapshot(root, state)
    try:
        sub = reader.get_entity_subgraph(subject, depth=max(1, int(depth)))
    finally:
        if getattr(reader, "_store", None) is not None:
            reader._store.close()
    store = Store(store_home(state))
    try:
        facts = [(f, grounding.of(f)) for f in store.current(subject=subject)]
    finally:
        store.close()
    return sub, facts
