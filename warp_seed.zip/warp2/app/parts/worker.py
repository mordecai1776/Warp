# WARP2/warp2/app/parts/worker.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/worker.py
#  Used by   : warp2/app/pages/{knowledge,webs,make,problems,pictures,games,system}.py.
#  Uses      : PySide6.QtCore (QObject, QRunnable, QThreadPool, Signal).
#  Description:
#    One slow job run off the window's thread, its answer handed back on it:
#    `later(work, then)` runs work() in the pool and calls then(answer) on the
#    window's thread, or shows the error. So a page never freezes while it
#    reads the store.
#  User intention (Andrew): the window never freezes the thing it watches,
#    nor itself.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal


class _Said(QObject):
    """The answer, carried back to the window's thread."""

    done = Signal(object)
    failed = Signal(str)


class _Job(QRunnable):
    """One job in the pool."""

    def __init__(self, work) -> None:
        """Intention: the work, and where its answer goes."""
        super().__init__()
        self.work = work
        self.said = _Said()

    def run(self) -> None:
        """Intention: the work done; its answer or its error sent back."""
        try:
            answer = self.work()
        except Exception as exc:
            self._say(self.said.failed, f"{type(exc).__name__}: {exc}")
            return
        self._say(self.said.done, answer)

    @staticmethod
    def _say(signal, what) -> None:
        """Intention: the answer sent back — unless the window has already gone (closing), when there is no one to tell."""
        try:
            signal.emit(what)
        except RuntimeError:
            return


_KEEP: set = set()


def later(work, then, failed=None) -> None:
    """Intention: work() off the window's thread; then(answer) on it; failed(words) if it fell over."""
    job = _Job(work)
    _KEEP.add(job.said)
    job.said.done.connect(then)
    job.said.done.connect(lambda _a, s=job.said: _KEEP.discard(s))
    job.said.failed.connect(lambda w, s=job.said: _KEEP.discard(s))
    if failed is not None:
        job.said.failed.connect(failed)
    QThreadPool.globalInstance().start(job)
