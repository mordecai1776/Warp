# WARP2/warp2/app/parts/relation_bars.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/relation_bars.py
#  Used by   : warp2/app/pages/eye_tree.py (relations, mixes, a group's
#              strongest ties).
#  Uses      : PySide6, warp2/app/theme.py.
#  Description:
#    Weights from -1 to 1 as bars out from a middle line: to the right in
#    green when two things go together (synonym, a plus weight in a mix), to
#    the left in red when they are opposites (a minus weight). One row per
#    weight, its words on the left and its number on the right, so a glance
#    shows what goes with what and how strongly.
#  User intention (Andrew, 2026-09-25): "The shown data needs to be pruned
#    out to what is needed to understand with more of a visuals centered
#    concept".
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import QWidget

from warp2.app import theme

# Intention: the height of one row, and the share of the width the words take.
ROW = 24
WORDS = 0.46


class RelationBars(QWidget):
    """Rows of weights, drawn as bars either side of 0."""

    def __init__(self, empty: str = "nothing yet", parent=None) -> None:
        """Intention: empty until rows are set; `empty` says what shows when there are none."""
        super().__init__(parent)
        self.rows: list = []
        self.empty = str(empty)
        self.setMinimumHeight(ROW * 2)

    def set(self, rows: list) -> None:
        """Intention: [(words, weight)] drawn in the order given; the widget as tall as its rows."""
        self.rows = [(str(w), max(-1.0, min(1.0, float(v)))) for w, v in rows]
        self.setMinimumHeight(max(ROW * 2, ROW * len(self.rows) + 8))
        self.update()

    def paintEvent(self, event) -> None:
        """Intention: each row's words, its bar from the middle line, and its number."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        font = QFont(self.font())
        font.setPointSizeF(9.0)
        painter.setFont(font)
        width = float(self.width())
        if not self.rows:
            painter.setPen(QColor(theme.QUIET))
            painter.drawText(QRectF(0, 0, width, ROW * 2), Qt.AlignmentFlag.AlignCenter, self.empty)
            return
        left = width * WORDS
        number = 46.0
        track = max(width - left - number - 12, 20.0)
        middle = left + track / 2
        painter.setPen(QColor(148, 163, 184, 70))
        painter.drawLine(int(middle), 2, int(middle), int(ROW * len(self.rows) + 4))
        for i, (words, value) in enumerate(self.rows):
            y = 4 + i * ROW
            painter.setPen(QColor("#E2E8F0"))
            shown = painter.fontMetrics().elidedText(words, Qt.TextElideMode.ElideMiddle, int(left - 10))
            painter.drawText(QRectF(0, y, left - 10, ROW - 4), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, shown)
            colour = QColor(theme.GOOD if value >= 0 else theme.BAD)
            colour.setAlpha(210)
            span = abs(value) * track / 2
            bar = QRectF(middle if value >= 0 else middle - span, y + 5, span, ROW - 14)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(colour)
            painter.drawRoundedRect(bar, 3, 3)
            painter.setPen(QColor(theme.QUIET))
            painter.drawText(QRectF(left + track + 8, y, number, ROW - 4), Qt.AlignmentFlag.AlignVCenter, f"{value:+.2f}")
