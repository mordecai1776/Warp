# WARP2/warp2/app/parts/now_view.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/now_view.py
#  Used by   : warp2/app/window.py (always on, down the right of the window).
#  Uses      : warp2/app/capabilities.py (what each lane is doing and whose
#              capability it is), warp2/app/pages/capability.py (ago,
#              said_of, ENDED), warp2/app/parts/worker.py,
#              warp2/app/parts/health_card.py (the machine's health),
#              warp2/app/parts/standing_words.py (the step in flight),
#              warp2/app/parts/paced.py (the lanes read paced by their cost),
#              PySide6, qfluentwidgets.
#  Description:
#    What the warp is doing right now, always in view beside whatever page is
#    open: for each lane (the card lane and the web lane), the capability
#    that is running, the step, what it is on, how long ago, how it ended,
#    what it said, and that capability's last few runs. Click the
#    capability's name to open its tab. Read again on every quick reading
#    (about a second), from the ends of the journals only.
#  User intention (Andrew, 2026-09-25): "lets have a dual thing where insted
#    of idol we have the current active thing pop up to the right of the
#    window" — "like added on as a new constant view".
#    2026-11-08 (BUILD_LOG 1455): the card lane shows the main runner's step
#    in flight with how long it has run against its usual time, coloured
#    warmer the further past (the journals only get a line when a step ends,
#    so a two-hour step showed as the last finished one); the runner pill
#    says "can't tell" when the process list could not be read.
#    2026-11-09 (BUILD_LOG 1480): the Eye's in-use panel is no longer carried
#    here ("lets get rid of the eye in use now").
#    2026-11-09 (BUILD_LOG 1479): the lanes are read again only after their
#    own cost times COST_TIMES (parts/paced.py), not every second.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QWidget
from qfluentwidgets import (BodyLabel, CaptionLabel, CardWidget, HyperlinkButton,
                            ScrollArea, StrongBodyLabel, SubtitleLabel)

from warp2.app import theme
from warp2.app.pages.capability import ENDED, ago, said_of
from warp2.app.parts.cards import Pill
from warp2.app.parts.worker import later

# Intention: the lanes, as a person names them.
LANES = (("continuous", "Card lane — building, training, the Eye"), ("web", "Web lane — research, datasets"))

# Intention: how many of a capability's runs are shown under it here.
RECENT = 6


def _badge(label, seconds_ago, live=None) -> None:
    """Liveness and measured progress are different; a heartbeat proves only liveness."""
    from warp2.record.heartbeat import SILENT_SECONDS
    live = live or {}
    if "heartbeat_age" in live:
        if live["heartbeat_age"] > SILENT_SECONDS:
            text, colour = "heartbeat overdue", theme.WARN
        elif live.get("progress"):
            active = live.get("progress_age", float("inf")) <= SILENT_SECONDS
            text, colour = ("working", theme.GOOD) if active else ("alive · progress overdue", theme.WARN)
        else:
            text, colour = "alive · no recent report", theme.QUIET
        label.setText(text)
        label.setStyleSheet(f"color: {colour}; font-size: 10px;")
        return
    if seconds_ago is None:
        label.setText("no steps")
        label.setStyleSheet(f"color: {theme.QUIET}; font-size: 10px;")
    elif float(seconds_ago) <= float(SILENT_SECONDS):
        label.setText("running")
        label.setStyleSheet(f"color: {theme.GOOD}; font-size: 10px;")
    else:
        label.setText(f"quiet · {ago(seconds_ago)}")
        label.setStyleSheet(f"color: {theme.WARN}; font-size: 10px;")


class RunningEngineCard(CardWidget):
    """At the top of the right panel: shows what the background engine is running.

    User intention (Andrew, 2026-09-27):
      "ok the right side should highlight exactly what it is working on in the moment
       and have a thing at the top that says the other stuff when it is running that it is doing."
    """

    def __init__(self, parent=None) -> None:
        """Intention: build the WHAT IS RUNNING card — the runner's real state pill and a line per lane."""
        super().__init__(parent)
        self.setObjectName("runningEngineCard")
        self.setStyleSheet(
            "#runningEngineCard {"
            "  border: 1px solid rgba(148, 163, 184, 0.22);"
            "  background: rgba(15, 23, 42, 0.65);"
            "  border-radius: 8px;"
            "}"
        )
        box = QVBoxLayout(self)
        box.setContentsMargins(12, 10, 12, 10)
        box.setSpacing(6)

        # Top Header
        head = QHBoxLayout()
        # Intention (2026-10-02, Andrew: "make sure the gui does not show
        # things it does not do"): this card said "BACKGROUND ENGINE RUNNING"
        # and "Engine Active" whatever was true, and a lane "running" whenever
        # it had ever written a step. Now the pill is the runner's real state
        # (show_state) and a lane is "running" only while its newest step is
        # fresher than the silence bound.
        title = CaptionLabel("WHAT IS RUNNING")
        title.setTextColor("#64748B", "#94A3B8")
        title.setStyleSheet("font-weight: 700; letter-spacing: 0.5px;")
        head.addWidget(title)
        head.addStretch(1)
        self.status_pill = Pill("—", theme.QUIET)
        head.addWidget(self.status_pill)
        box.addLayout(head)

        sub = CaptionLabel("The newest step in each lane:")
        sub.setTextColor("#475569", "#64748B")
        sub.setStyleSheet("font-size: 10px; font-style: italic;")
        box.addWidget(sub)

        # 1. Card Lane (Building, Training, Eye)
        card_lane_box = QVBoxLayout()
        card_lane_box.setSpacing(2)
        c_head = QHBoxLayout()
        c_title = CaptionLabel("🎴 Card Lane")
        c_title.setStyleSheet(f"color: {theme.ACCENT}; font-weight: 600; font-size: 11px;")
        c_head.addWidget(c_title)
        c_head.addStretch(1)
        self.card_badge = CaptionLabel("running")
        self.card_badge.setStyleSheet(f"color: {theme.GOOD}; font-size: 10px;")
        c_head.addWidget(self.card_badge)
        card_lane_box.addLayout(c_head)

        self.card_verb = StrongBodyLabel("—")
        self.card_verb.setWordWrap(True)
        self.card_verb.setStyleSheet("font-size: 12px; font-weight: 600;")
        card_lane_box.addWidget(self.card_verb)

        self.card_detail = CaptionLabel("")
        self.card_detail.setTextColor("#64748B", "#94A3B8")
        self.card_detail.setWordWrap(True)
        card_lane_box.addWidget(self.card_detail)
        box.addLayout(card_lane_box)

        # Separator line
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("color: rgba(148, 163, 184, 0.15); margin: 2px 0;")
        box.addWidget(sep)

        # 2. Web Lane (Research, Datasets)
        web_lane_box = QVBoxLayout()
        web_lane_box.setSpacing(2)
        w_head = QHBoxLayout()
        w_title = CaptionLabel("🌐 Web Lane")
        w_title.setStyleSheet("color: #38bdf8; font-weight: 600; font-size: 11px;")
        w_head.addWidget(w_title)
        w_head.addStretch(1)
        self.web_badge = CaptionLabel("running")
        self.web_badge.setStyleSheet(f"color: {theme.GOOD}; font-size: 10px;")
        w_head.addWidget(self.web_badge)
        web_lane_box.addLayout(w_head)

        self.web_verb = StrongBodyLabel("—")
        self.web_verb.setWordWrap(True)
        self.web_verb.setStyleSheet("font-size: 12px; font-weight: 600;")
        web_lane_box.addWidget(self.web_verb)

        self.web_detail = CaptionLabel("")
        self.web_detail.setTextColor("#64748B", "#94A3B8")
        self.web_detail.setWordWrap(True)
        web_lane_box.addWidget(self.web_detail)
        box.addLayout(web_lane_box)

    def update_lanes(self, now_map: dict, caps_map: dict) -> None:
        """Update the lane summaries from latest now and capability readings."""
        # Continuous / Card Lane
        c_now = now_map.get("continuous")
        if c_now and c_now.get("entry"):
            c_entry = c_now["entry"]
            c_verb = str(c_entry.get("verb") or "").replace("_", " ").strip()
            c_cap = (caps_map.get(c_now.get("owner")) or {}).get("name") or c_now.get("owner") or ""

            c_target = str(c_entry.get("target") or "")
            val = c_entry.get("value")
            if isinstance(val, dict):
                if not c_target and val.get("skill_name"):
                    c_target = str(val.get("skill_name"))
                    if val.get("base_model"):
                        c_target += f" ({val.get('base_model')})"
                elif not c_target and val.get("subject"):
                    c_target = str(val.get("subject"))

            verb_text = c_verb.capitalize() if c_verb else (c_cap or "Active")
            self.card_verb.setText(verb_text)
            ago_s = ago(c_now.get("ago"))
            outcome = str(c_entry.get("outcome") or "")
            target_desc = f"on {c_target}" if c_target else f"in {c_cap}"
            self.card_detail.setText(c_now.get("progress_text") or f"{target_desc} · {outcome} ({ago_s})")
            _badge(self.card_badge, c_now.get("ago"), c_now)
        else:
            self.card_verb.setText("—")
            self.card_detail.setText("alive, between steps" if (c_now or {}).get("heartbeat_age") is not None
                                     else "nothing written yet")
            _badge(self.card_badge, None, c_now)
        self._step_in_flight()

        # Web Lane
        w_now = now_map.get("web")
        if w_now and w_now.get("entry"):
            w_entry = w_now["entry"]
            w_verb = str(w_entry.get("verb") or "").replace("_", " ").strip()
            w_cap = (caps_map.get(w_now.get("owner")) or {}).get("name") or w_now.get("owner") or ""
            w_target = str(w_entry.get("target") or "")
            val = w_entry.get("value")
            if isinstance(val, dict) and not w_target:
                if val.get("subject"):
                    w_target = str(val.get("subject"))
                elif val.get("topic"):
                    w_target = str(val.get("topic"))

            verb_text = w_verb.capitalize() if w_verb else (w_cap or "Active")
            self.web_verb.setText(verb_text)
            ago_s = ago(w_now.get("ago"))
            outcome = str(w_entry.get("outcome") or "")
            target_desc = f"on {w_target}" if w_target else f"in {w_cap}"
            self.web_detail.setText(w_now.get("progress_text") or f"{target_desc} · {outcome} ({ago_s})")
            _badge(self.web_badge, w_now.get("ago"), w_now)
        else:
            self.web_verb.setText("—")
            self.web_detail.setText("alive, between steps" if (w_now or {}).get("heartbeat_age") is not None
                                    else "nothing written yet")
            _badge(self.web_badge, None, w_now)

    def _step_in_flight(self) -> None:
        """Intention: the main runner's step now, over the last finished one - how long it has run against its
        usual time, warmer the further past (BUILD_LOG 1455)."""
        from warp2.app.parts.standing_words import blend, step_heat, step_words
        step = getattr(self, "in_flight", None) or {}
        if not step.get("verb"):
            return
        self.card_verb.setText(str(step["verb"]).replace("_", " ").capitalize())
        self.card_detail.setText(f"running now: {step_words(step)}")
        heat = step_heat(step)
        self.card_badge.setText("running long" if step.get("overdue") else "running")
        self.card_badge.setStyleSheet(f"color: {blend(theme.GOOD, theme.BAD, heat) if heat is not None else theme.GOOD}; font-size: 10px;")

    def show_state(self, stand: dict) -> None:
        """Intention: the pill says what is true of the runner — ALL_STOP raised, running, or not running."""
        if not isinstance(stand, dict) or not ("running" in stand or "stopped" in stand):
            return
        self.in_flight = stand.get("step") or {}
        if stand.get("stopped"):
            self.status_pill.set("ALL_STOP raised", theme.BAD)
        elif stand.get("running") is None:
            self.status_pill.set("Runner: can't tell", theme.QUIET)
        elif stand.get("running"):
            self.status_pill.set("Runner up", theme.GOOD)
        else:
            self.status_pill.set("Runner not running", theme.WARN)
        self._step_in_flight()


class LaneView(QFrame):
    """One lane: what is running in it now."""

    def __init__(self, title: str, parent=None) -> None:
        """Intention: the lane's name, the capability, the step and what it said, and its last runs."""
        super().__init__(parent)
        box = QVBoxLayout(self)
        box.setContentsMargins(0, 8, 0, 8)
        box.setSpacing(4)
        head = CaptionLabel(title)
        head.setTextColor("#64748B", "#94A3B8")
        box.addWidget(head)
        self.cap = HyperlinkButton("", "—")
        # Intention: a link, not a button — no box around it on the dark window.
        self.cap.setStyleSheet(f"HyperlinkButton {{text-align: left; padding: 0; border: none; "
                               f"background: transparent; color: {theme.ACCENT}; font-weight: 600}}")
        box.addWidget(self.cap)
        self.step = StrongBodyLabel("—")
        self.step.setWordWrap(True)
        box.addWidget(self.step)
        self.on = BodyLabel("")
        self.on.setWordWrap(True)
        box.addWidget(self.on)
        self.said = BodyLabel("")
        self.said.setWordWrap(True)
        box.addWidget(self.said)
        self.recent = BodyLabel("")
        self.recent.setWordWrap(True)
        self.recent.setTextFormat(Qt.TextFormat.RichText)
        box.addWidget(self.recent)
        self.key = ""

    def show_now(self, now: dict | None, cap: dict | None, runs: list) -> None:
        """Intention: the lane's newest entry and its capability's last runs drawn."""
        if not now:
            self.cap.setText("nothing written yet")
            self.step.setText("")
            self.on.setText("")
            self.said.setText("")
            self.recent.setText("")
            self.key = ""
            return
        entry = now["entry"]
        self.key = now["owner"]
        self.cap.setText((cap or {}).get("name") or now["owner"])
        colour = ENDED.get(str(entry.get("outcome")), theme.QUIET)
        self.step.setText(f"{str(entry.get('verb') or '').replace('_', ' ')} · "
                          f"<span style='color:{colour}'>{entry.get('outcome')}</span> · {ago(now['ago'])}")
        self.step.setTextFormat(Qt.TextFormat.RichText)
        seconds = entry.get("seconds")
        self.on.setText(f"on {str(entry.get('target') or '—')[-90:]}"
                        + (f" · took {float(seconds):.1f}s" if isinstance(seconds, (int, float)) else ""))
        self.said.setText(said_of(entry))
        lines = []
        for run in runs[:RECENT]:
            c = ENDED.get(str(run.get("outcome")), theme.QUIET)
            lines.append(f"<span style='color:{c}'>●</span> {str(run.get('ts') or '')[11:19]} "
                         f"{str(run.get('verb') or '').replace('_', ' ')} — {said_of(run)[:70]}")
        self.recent.setText("<br>".join(lines))


class NowView(QFrame):
    """What the warp is doing now, always in view down the right."""

    def __init__(self, feed, parent=None) -> None:
        """Intention: a lane view for each lane, read on every quick reading."""
        super().__init__(parent)
        from warp2.app.capabilities import Capabilities
        self.feed = feed
        self.caps = Capabilities(feed.root, feed.state)
        self.setObjectName("now")
        self.setStyleSheet("#now {border-left: 1px solid rgba(148,163,184,60); background: transparent}")
        self.setFixedWidth(340)
        # Intention: the view scrolls within itself when what it carries is
        # taller than the window, so nothing is cut off.
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = ScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea {border: none; background: transparent}")
        inner = QWidget()
        inner.setObjectName("nowinner")
        inner.setStyleSheet("#nowinner {background: transparent}")
        scroll.setWidget(inner)
        outer.addWidget(scroll)
        box = QVBoxLayout(inner)
        box.setContentsMargins(16, 56, 16, 16)
        box.setSpacing(8)

        # User intention (Andrew, 2026-09-27):
        # "ok the right side should highlight exactly what it is working on in the moment
        # and have a thing at the top that says the other stuff when it is running that it is doing."
        # At the top of the right panel: shows what the background engine is running.
        self.running_card = RunningEngineCard(self)
        box.addWidget(self.running_card)
        # Intention (2026-10-16): THE MACHINE'S HEALTH, ALWAYS IN VIEW — the
        # 381 MB and the restart that left no window were invisible.
        from warp2.app.parts.health_card import HealthCard
        self.health = HealthCard(self)
        box.addWidget(self.health)
        self.health.take(feed.last)
        feed.snapshot.connect(self.health.take)
        feed.standing.connect(self.health.take_standing)

        box.addWidget(SubtitleLabel("User Tasked Work"))
        subtitle = CaptionLabel("What you tasked · stays on the right until verified passed")
        subtitle.setTextColor("#64748B", "#94A3B8")
        subtitle.setWordWrap(True)
        box.addWidget(subtitle)

        # Compatibility attributes preserved so external callers do not break
        self.doing = BodyLabel("")
        self.lanes = {}
        for key, title in LANES:
            lv = LaneView(title, self)
            lv.setVisible(False)
            self.lanes[key] = lv
            lv.cap.clicked.connect(lambda k=key: self._open(self.lanes[k].key))
        self.extra = QVBoxLayout()
        self.open_cap = None
        self._asked = False
        from warp2.app.parts.paced import Paced
        self._pace = Paced()

        from warp2.app.parts.user_tasks_view import UserTasksView
        self.user_tasks = UserTasksView(feed)
        box.addWidget(self.user_tasks)

        # User intention (Andrew, 2026-09-27):
        # "make something smaller that just shows a min of them below it for warp task like that
        # and have them follow the same striengent path as user task. They should be seprate
        # though to define user task as the thing to interact with and the others to be dealt
        # with by the warp."
        from warp2.app.parts.warp_tasks_view import WarpTasksView
        self.warp_tasks = WarpTasksView(feed)
        box.addWidget(self.warp_tasks)

        box.addLayout(self.extra)
        box.addStretch(1)
        feed.standing.connect(self._tick)
        feed.snapshot.connect(lambda _s: self._tick({}))

    def _tick(self, stand: dict = None) -> None:
        """Intention: read what the lanes are doing right now."""
        if isinstance(stand, dict) and "doing" in stand:
            self.doing.setText(str(stand["doing"]))
        if isinstance(stand, dict):
            self.running_card.show_state(stand)
        if self._asked or not self._pace.due():
            return
        self._asked = True
        later(self._read_now, self._fill, lambda _w: setattr(self, "_asked", False))

    def _read_now(self) -> dict:
        """Intention: off-thread read of what each lane is on now, its capability, and that capability's runs - paced
        by its own cost (BUILD_LOG 1479, measured 2026-11-09: it read and decoded the journals every second, nearly a
        third of the window's busy time)."""
        with self._pace.reading():
            return self._read_now_once()

    def _read_now_once(self) -> dict:
        """Intention: what each lane is on now, its capability, and that capability's runs."""
        entries = self.caps.entries()
        caps = self.caps.all(entries)
        now = self.caps.now(entries, caps)
        caps_by_key = {c["key"]: c for c in caps}
        runs = {now[l]["owner"]: self.caps.runs(caps_by_key.get(now[l]["owner"], {}), entries, caps)
                for l in now if now[l].get("owner")}
        return {"now": now, "caps": caps_by_key, "runs": runs}

    def _fill(self, got: dict) -> None:
        """Intention: show the reading on the running card and each lane view; a lane with nothing on is cleared."""
        self._asked = False
        if not got:
            return
        now_map = got.get("now", {})
        caps_map = got.get("caps", {})
        runs_map = got.get("runs", {})
        if hasattr(self, "running_card"):
            self.running_card.update_lanes(now_map, caps_map)
        for key, lv in self.lanes.items():
            if key in now_map:
                lv.show_now(now_map[key], caps_map.get(now_map[key]["owner"]), runs_map.get(now_map[key]["owner"], []))
            else:
                lv.show_now(None, None, [])

    def _open(self, key: str) -> None:
        """Intention: open a capability's page when its lane is clicked, if the window gave a way to open one."""
        if key and self.open_cap is not None:
            self.open_cap(key)
