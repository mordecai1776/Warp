# WARP2/warp2/app/parts/graph.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/graph.py
#  Used by   : warp2/app/pages/{knowledge,system}.py.
#  Uses      : PySide6 (QGraphicsView — drawn on the GPU through Qt), numpy
#              (the layout), warp2/app/theme.py.
#  Description:
#    A graph a person can move around in: things as glowing dots coloured by
#    kind, links as soft lines, laid out so what is joined sits together
#    (a spring layout, worked out once per graph and settled smoothly). The
#    wheel zooms toward the pointer, dragging pans, hovering lights a thing
#    and its links, clicking picks it, dragging a dot moves and pins it,
#    a double click adds its neighbours and a right click takes them away.
#    Layouts: spring, layered rows (for the system map), or radial — rings
#    round a picked thing, a sunflower spiral for the whole graph.
#  User intention (Andrew): the KG seen as it is; "the best looking set up".
# ============================================================================
from __future__ import annotations

import math

import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen, QRadialGradient
from PySide6.QtWidgets import QGraphicsEllipseItem, QGraphicsLineItem, QGraphicsScene, QGraphicsSimpleTextItem, QGraphicsView

from warp2.app import theme


def spring_layout(names: list, edges: list, rounds: int = 0) -> dict:
    """{name: (x, y)} by springs and repulsion (Fruchterman–Reingold).

    Intention: the number of rounds follows the size of the graph — a bigger
    graph settles over more rounds — and the start is the same every time,
    so the same graph is drawn the same way.
    """
    n = len(names)
    if n == 0:
        return {}
    index = {name: i for i, name in enumerate(names)}
    angle = np.linspace(0, 2 * math.pi, n, endpoint=False)
    pos = np.stack([np.cos(angle), np.sin(angle)], axis=1) * math.sqrt(n) * 30
    pairs = np.array([(index[a], index[b]) for a, b in edges if a in index and b in index and a != b] or
                     [(0, 0)], dtype=int)
    k = 60.0
    rounds = rounds or int(60 + 12 * math.sqrt(n))
    heat = math.sqrt(n) * 20
    for step in range(rounds):
        delta = pos[:, None, :] - pos[None, :, :]
        dist = np.maximum(np.linalg.norm(delta, axis=2), 0.01)
        push = (k * k / dist)[:, :, None] * delta / dist[:, :, None]
        move = push.sum(axis=1)
        if len(pairs) and pairs[0][0] != pairs[0][1]:
            d = pos[pairs[:, 0]] - pos[pairs[:, 1]]
            length = np.maximum(np.linalg.norm(d, axis=1), 0.01)
            pull = (length * length / k)[:, None] * d / length[:, None]
            np.add.at(move, pairs[:, 0], -pull)
            np.add.at(move, pairs[:, 1], pull)
        # Intention: a gentle pull to the middle, so pieces that are not
        # joined to each other still sit together in one picture.
        move -= pos * (np.linalg.norm(pos, axis=1, keepdims=True) / (k * math.sqrt(n))) * k / 4
        size = np.maximum(np.linalg.norm(move, axis=1), 0.01)
        cool = heat * (1 - step / rounds)
        pos += move / size[:, None] * np.minimum(size, cool)[:, None]
    return {name: (float(pos[i, 0]), float(pos[i, 1])) for name, i in index.items()}


def layered_layout(names: list, edges: list, loops=()) -> dict:
    """{name: (x, y)} in rows by longest path from the start, for a flowchart.

    Intention: the loop-back links are left out of the ordering, so a cycle
    still reads top to bottom.
    """
    skip = set(loops)
    level = {name: 0 for name in names}
    for _ in range(len(names)):
        moved = False
        for a, b in edges:
            if (a, b) in skip or a not in level or b not in level:
                continue
            if level[b] < level[a] + 1 and level[a] + 1 < len(names):
                level[b] = level[a] + 1
                moved = True
        if not moved:
            break
    rows: dict = {}
    for name in names:
        rows.setdefault(level[name], []).append(name)
    out = {}
    for depth, members in rows.items():
        for i, name in enumerate(members):
            out[name] = ((i - (len(members) - 1) / 2) * 300.0, depth * 130.0)
    return out


def radial_layout(names: list, rings: dict) -> dict:
    """{name: (x, y)} on circles by ring — ring 0 in the middle, each ring further out.

    Intention: for a neighbourhood, the ring is the distance from the focus;
    for the whole graph, it grows with how far down the most-joined order a
    thing is. Each circle is spaced to how many it holds, so no ring crowds.
    """
    by_ring: dict = {}
    for name in names:
        by_ring.setdefault(int(rings.get(name, 0)), []).append(name)
    out, radius = {}, 0.0
    for ring in sorted(by_ring):
        members = by_ring[ring]
        # Intention: each circle as big as it needs for its members, never
        # smaller than one step out from the last.
        radius = 0.0 if ring == 0 and len(members) == 1 else max(radius + 110.0, len(members) * 46.0 / (2 * math.pi))
        # Intention: each ring turned by the golden angle, so rings never line up in spokes.
        turn = ring * math.pi * (3 - math.sqrt(5))
        for i, name in enumerate(members):
            angle = turn + 2 * math.pi * i / len(members)
            out[name] = (radius * math.cos(angle), radius * math.sin(angle))
    return out


def sunflower_layout(names: list, joined: dict) -> dict:
    """{name: (x, y)} on a sunflower spiral — the most joined in the middle, evenly packed outwards.

    Intention: for the whole graph, where there is no one centre. Each
    thing's distance grows with the square root of its rank and its angle by
    the golden angle, so every ring is as full as the one inside it and none
    line up in spokes (Vogel's model of a sunflower head).
    """
    order = sorted(names, key=lambda n: (-joined.get(n, 0), str(n)))
    golden = math.pi * (3 - math.sqrt(5))
    return {name: (42.0 * math.sqrt(rank) * math.cos(rank * golden),
                   42.0 * math.sqrt(rank) * math.sin(rank * golden)) for rank, name in enumerate(order)}


class Dot(QGraphicsEllipseItem):
    """One thing: a glowing dot with its name under it."""

    def __init__(self, name: str, label: str, colour: QColor, radius: float) -> None:
        """Intention: the dot, its glow and its label, all one item."""
        super().__init__(-radius, -radius, 2 * radius, 2 * radius)
        self.name, self.colour, self.radius = name, colour, radius
        glow = QRadialGradient(QPointF(0, 0), radius)
        glow.setColorAt(0.0, colour.lighter(140))
        glow.setColorAt(1.0, colour)
        self.setBrush(QBrush(glow))
        self.setPen(QPen(QColor(255, 255, 255, 40), 1.2))
        self.setAcceptHoverEvents(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        # Intention: A THING CAN BE MOVED BY HAND AND STAYS WHERE IT IS PUT
        # (pinned) — its links follow it as it goes.
        self.setFlag(QGraphicsEllipseItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setFlag(QGraphicsEllipseItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.setZValue(2)
        self.text = QGraphicsSimpleTextItem(label[:38], self)
        self.text.setBrush(QColor("#CBD5E1"))
        font = QFont()
        font.setPointSizeF(8.0)
        self.text.setFont(font)
        width = self.text.boundingRect().width()
        self.text.setPos(-width / 2, radius + 3)
        self.links: list = []

    def itemChange(self, change, value):
        """Intention: while it is dragged its links follow, and once moved it is pinned where it was put."""
        if change == QGraphicsEllipseItem.GraphicsItemChange.ItemPositionHasChanged:
            for link in self.links:
                link.follow()
            view = self.scene().views()[0] if self.scene() and self.scene().views() else None
            if view is not None and getattr(view, "placing", False) is False:
                view.pinned[self.name] = (self.x(), self.y())
        return super().itemChange(change, value)

    def light(self, on: bool) -> None:
        """Intention: a thing and its links brighter while hovered or picked, its name shown while lit."""
        self.setPen(QPen(QColor("#F8FAFC") if on else QColor(255, 255, 255, 40), 2.4 if on else 1.2))
        if on:
            self.text.setVisible(True)
            self.setZValue(3)
        else:
            self.setZValue(2)
            view = self.scene().views()[0] if self.scene() and self.scene().views() else None
            if view is not None:
                self.text.setVisible(self.radius * view.transform().m11() >= 7.0)
        for link in self.links:
            link.light(on)

    def hoverEnterEvent(self, event) -> None:
        """Intention: lit while the pointer is on it."""
        self.light(True)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:
        """Intention: back to calm, unless it is the picked one."""
        view = self.scene().views()[0] if self.scene() and self.scene().views() else None
        if view is None or view.picked != self.name:
            self.light(False)
        super().hoverLeaveEvent(event)


class Link(QGraphicsLineItem):
    """A link between two things."""

    def __init__(self, a: Dot, b: Dot, label: str) -> None:
        """Intention: a soft line under the dots, named for its relation."""
        super().__init__(a.x(), a.y(), b.x(), b.y())
        self.a, self.b = a, b
        self.label = label
        self.setToolTip(label)
        self.light(False)
        self.setZValue(1)

    def light(self, on: bool) -> None:
        """Intention: brighter when one of its ends is lit."""
        self.setPen(QPen(QColor(theme.ACCENT) if on else QColor(148, 163, 184, 70), 2.0 if on else 1.0))

    def follow(self) -> None:
        """Intention: the line kept between its two ends when one is moved."""
        self.setLine(self.a.x(), self.a.y(), self.b.x(), self.b.y())


class GraphView(QGraphicsView):
    """A graph to look around in."""

    picked_thing = Signal(str)
    # Intention: a double click asks for a thing's neighbours to be added; a
    # right click asks for what it added to be taken away again.
    expand_asked = Signal(str)
    collapse_asked = Signal(str)

    def __init__(self, parent=None) -> None:
        """Intention: an empty scene, smooth drawing, zoom toward the pointer, drag to pan."""
        super().__init__(parent)
        self.setScene(QGraphicsScene(self))
        self.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.TextAntialiasing)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.SmartViewportUpdate)
        self.setStyleSheet("QGraphicsView {background: transparent; border: none}")
        self.setMinimumHeight(420)
        self.dots: dict = {}
        self.picked = ""
        # Intention: where a person put things by hand (kept across redraws),
        # what each expansion added (so it can be taken away), and whether
        # the view itself is placing dots (so that is not mistaken for a pin).
        self.pinned: dict = {}
        self.expanded: dict = {}
        self.placing = False
        self.lit: set = set()

    def show_graph(self, nodes: list, edges: list, focus: str = "", layered: bool = False, loops=(),
                   layout: str = "", rings: dict | None = None) -> None:
        """nodes: [{id, label, colour?, size?}]; edges: [(a, b, label)].

        Intention: the graph drawn fresh and fitted to the view; the focus,
        if given, picked and lit. `layout` is "spring", "layers" or "radial"
        (with `rings`); a thing pinned by hand keeps its place.
        """
        scene = self.scene()
        scene.clear()
        self.dots, self.expanded, self.lit = {}, {}, set()
        names = [n["id"] for n in nodes]
        pairs = [(a, b) for a, b, _l in edges]
        layout = layout or ("layers" if layered else "spring")
        if layout == "layers":
            where = layered_layout(names, pairs, loops)
        elif layout == "radial":
            where = radial_layout(names, rings) if rings else sunflower_layout(names, _degree(pairs))
        else:
            where = spring_layout(names, pairs)
        where.update({name: xy for name, xy in self.pinned.items() if name in where})
        self.placing = True
        joined = _degree(pairs)
        for node in nodes:
            self._add_dot(node, where.get(node["id"], (0.0, 0.0)), joined)
        for a, b, label in edges:
            self._add_link(a, b, label)
        self.placing = False
        self.fit()
        self.moved_by_hand = False
        self.picked = ""
        if focus in self.dots:
            self.pick(focus, tell=False)
        self._labels()

    def _add_dot(self, node: dict, xy: tuple, joined: dict) -> None:
        """Intention: one thing put in the scene, sized by how joined it is, coloured by its kind."""
        colour = QColor(node.get("colour") or theme.kind_colour(node["id"]).name())
        radius = float(node.get("size") or (7 + 3 * math.sqrt(joined.get(node["id"], 0))))
        dot = Dot(node["id"], str(node.get("label") or node["id"]), colour, radius)
        dot.setPos(*xy)
        dot.setToolTip(str(node.get("tip") or node["id"]))
        self.scene().addItem(dot)
        self.dots[node["id"]] = dot

    def _add_link(self, a: str, b: str, label: str) -> None:
        """Intention: one link between two things already in the scene, once."""
        if a not in self.dots or b not in self.dots:
            return
        if any((link.a.name, link.b.name) in ((a, b), (b, a)) and link.label == label
               for link in self.dots[a].links):
            return
        link = Link(self.dots[a], self.dots[b], label)
        self.scene().addItem(link)
        self.dots[a].links.append(link)
        self.dots[b].links.append(link)

    def expand(self, name: str, nodes: list, edges: list) -> int:
        """Add a thing's neighbours around it, leaving everything else where it is. How many were new.

        Intention: growing the picture one thing at a time, without redrawing
        it — the new ones are set on a small circle round the thing and
        remembered, so a right click can take exactly them away again.
        """
        if name not in self.dots:
            return 0
        centre = self.dots[name]
        fresh = [n for n in nodes if n["id"] not in self.dots]
        self.placing = True
        step = max(90.0, 22.0 * len(fresh) / math.pi)
        for i, node in enumerate(fresh):
            angle = 2 * math.pi * i / max(1, len(fresh))
            xy = self.pinned.get(node["id"], (centre.x() + step * math.cos(angle), centre.y() + step * math.sin(angle)))
            self._add_dot(node, xy, {})
        for a, b, label in edges:
            self._add_link(a, b, label)
        self.placing = False
        self.expanded.setdefault(name, []).extend(n["id"] for n in fresh)
        self.scene().setSceneRect(self.scene().itemsBoundingRect().adjusted(-80, -80, 80, 80))
        self._labels()
        return len(fresh)

    def collapse(self, name: str) -> int:
        """Take away what expanding this thing added. How many went.

        Intention: only what it added, and not a thing another expansion
        added, the picked one, or one pinned by hand.
        """
        keep = {n for other, added in self.expanded.items() if other != name for n in added}
        gone = [n for n in self.expanded.pop(name, [])
                if n in self.dots and n not in keep and n != self.picked and n not in self.pinned]
        for n in gone:
            dot = self.dots.pop(n)
            for link in list(dot.links):
                other = link.b if link.a is dot else link.a
                if link in other.links:
                    other.links.remove(link)
                self.scene().removeItem(link)
            self.scene().removeItem(dot)
        return len(gone)

    def highlight(self, names) -> None:
        """Intention: the named things lit and the rest dimmed; None or empty brings everything back."""
        self.lit = set(names or ())
        for name, dot in self.dots.items():
            on = not self.lit or name in self.lit
            dot.setOpacity(1.0 if on else 0.18)
            for link in dot.links:
                both = not self.lit or (link.a.name in self.lit and link.b.name in self.lit)
                link.setOpacity(1.0 if both else 0.12)
                if self.lit and both:
                    link.light(True)

    def fit(self) -> None:
        """Intention: everything in view."""
        rect = self.scene().itemsBoundingRect().adjusted(-80, -80, 80, 80)
        self.scene().setSceneRect(rect)
        self.fitInView(rect, Qt.AspectRatioMode.KeepAspectRatio)
        self._labels()

    def unpin(self) -> None:
        """Intention: every hand-placed thing let go, for the next drawing."""
        self.pinned = {}

    def pick(self, name: str, tell: bool = True) -> None:
        """Intention: one thing picked and lit; the one before it calmed."""
        if self.picked in self.dots:
            self.dots[self.picked].light(False)
        self.picked = name
        if name in self.dots:
            self.dots[name].light(True)
        if tell:
            self.picked_thing.emit(name)

    def mousePressEvent(self, event) -> None:
        """Intention: a click on a dot picks it; anywhere else starts a pan."""
        item = self.itemAt(event.position().toPoint())
        while item is not None and not isinstance(item, Dot):
            item = item.parentItem()
        if isinstance(item, Dot):
            if event.button() == Qt.MouseButton.RightButton:
                self.collapse_asked.emit(item.name)
                return
            self.pick(item.name)
            # Intention: the press goes on to the dot, so it can be dragged.
            self.setDragMode(QGraphicsView.DragMode.NoDrag)
            super().mousePressEvent(event)
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        """Intention: after a dot is let go, dragging the background pans again."""
        super().mouseReleaseEvent(event)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)

    def mouseDoubleClickEvent(self, event) -> None:
        """Intention: a double click on a thing asks for its neighbours."""
        item = self.itemAt(event.position().toPoint())
        while item is not None and not isinstance(item, Dot):
            item = item.parentItem()
        if isinstance(item, Dot):
            self.expand_asked.emit(item.name)
            return
        super().mouseDoubleClickEvent(event)

    def wheelEvent(self, event) -> None:
        """Intention: zoom toward the pointer, smoothly, by how far the wheel turned."""
        factor = 1.0015 ** event.angleDelta().y()
        self.scale(factor, factor)
        self.moved_by_hand = True
        self._labels()

    def _labels(self) -> None:
        """Names shown only where they can be read.

        Intention: a name is drawn when its dot is big enough on screen to
        carry one, or when it is lit — so zooming in brings the names out and
        the whole graph is never a smear of words.
        """
        scale = self.transform().m11()
        for dot in self.dots.values():
            dot.text.setVisible(dot.radius * scale >= 7.0 or dot.name == self.picked)

    def resizeEvent(self, event) -> None:
        """Intention: the graph kept fitted to the view until a person zooms it themselves."""
        super().resizeEvent(event)
        if not getattr(self, "moved_by_hand", False) and self.scene().items():
            self.fitInView(self.scene().sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)
            self._labels()

    def drawBackground(self, painter, rect: QRectF) -> None:
        """Intention: a faint dot grid, so moving around can be felt."""
        super().drawBackground(painter, rect)
        step = 40.0
        painter.setPen(QPen(QColor(148, 163, 184, 26), 1.6))
        left = math.floor(rect.left() / step) * step
        top = math.floor(rect.top() / step) * step
        y = top
        points = []
        while y < rect.bottom():
            x = left
            while x < rect.right():
                points.append(QPointF(x, y))
                x += step
            y += step
        if len(points) < 20000:
            painter.drawPoints(points)


def _degree(pairs: list) -> dict:
    """Intention: how many links each thing has, from (a, b) pairs."""
    count: dict = {}
    for a, b in pairs:
        count[a] = count.get(a, 0) + 1
        count[b] = count.get(b, 0) + 1
    return count

