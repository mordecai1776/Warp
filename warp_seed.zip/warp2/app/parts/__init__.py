# WARP2/warp2/app/parts/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/__init__.py
#  Used by   : warp2/app/pages/*.py.
#  Uses      : nothing itself.
#  Description:
#    The small pieces every page is made of: the page frame, cards, tables,
#    live charts and the graph view.
#  User intention (Andrew): smallest parts, one job each.
# ============================================================================
