# WARP2/warp2/app/parts/judge_rows.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/judge_rows.py
#  Used by   : warp2/app/pages/improving.py (the "Judges" panel).
#  Uses      : nothing but the plain reading from
#              warp2/progress/disagreement.py (snapshot["progress"]["disagreement"]).
#  Description:
#    Turns the judges' disagreement reading into what the page shows: a few
#    lines for the panel as a whole, one row per judge (how often it went
#    against the panel's verdict) and one row per pair of judges (how often
#    they voted apart). No Qt here, so it is tested without a screen.
#    Anything nobody measured is "—", never 0. Measurement only — nothing
#    steers on it.
#  User intention (Andrew, 2026-10-18): approved muse-40 #4, pairwise
#    disagreement next to the temperatures, as measurement only; and
#    (2026-10-16) "I want to know if the entire system's improving as a whole".
# ============================================================================
from __future__ import annotations

# Intention: how many judges and pairs the page lists; the busiest come first already.
SHOWN = 8


def share(value) -> str:
    """Intention: a share as a whole percent, or — when nothing was measured."""
    return "—" if type(value) not in (int, float) else f"{float(value):.0%}"


def heat_words(heat) -> str:
    """Intention: the daily disagreement's heat in plain words; more disagreement is not called good or bad."""
    if type(heat) not in (int, float):
        return "too little to say"
    if heat > 0.3:
        return "more disagreement lately"
    if heat < -0.3:
        return "less disagreement lately"
    return "about the same"


def summary_lines(reading: dict) -> list:
    """Intention: [(name, words)] for the whole panel — answers read, mean disagreement, error, C-bound, heat,
    and Book-2 reality pairing (relay claude-31..33 / muse-53..55).
    """
    reading = reading or {}
    return [("Judged answers read", str(int(reading.get("answers") or 0))),
            ("Two judges vote apart", share(reading.get("mean_disagreement"))),
            ("A judge goes against the verdict", share(reading.get("mean_off_verdict"))),
            ("C-bound (how the panel hangs together)", share(reading.get("c_bound"))),
            ("Paired with gate/test reality", str(int(reading.get("paired") or 0))),
            ("Unpaired votes (never met gate/test)", share(reading.get("unpaired_share"))),
            ("Verdict against reality", share(reading.get("verdict_off_reality"))),
            ("A judge goes against reality", share(reading.get("mean_off_reality"))),
            ("C-bound against reality", share(reading.get("c_bound_reality"))),
            ("Lately", heat_words(reading.get("disagreement_heat")))]


def judge_rows(reading: dict) -> list:
    """Intention: one row per judge — its name, how many votes it cast, how often it went against the verdict."""
    return [[str(j.get("model") or "—"), int(j.get("n") or 0), share(j.get("off_verdict"))]
            for j in ((reading or {}).get("judges") or [])[:SHOWN]]


def reality_judge_rows(reading: dict) -> list:
    """Intention: one row per judge in Book 2 — its name, paired votes, unpaired votes, and how often against reality."""
    return [[str(j.get("model") or "—"), int(j.get("paired") or 0), int(j.get("unpaired") or 0),
             share(j.get("off_reality"))]
            for j in ((reading or {}).get("reality_judges") or [])[:SHOWN]]


def pair_rows(reading: dict) -> list:
    """Intention: one row per pair of judges — both names, how many answers both voted on, how often apart."""
    return [[str(p.get("a") or "—"), str(p.get("b") or "—"), int(p.get("n") or 0), share(p.get("disagree"))]
            for p in ((reading or {}).get("pairs") or [])[:SHOWN]]
