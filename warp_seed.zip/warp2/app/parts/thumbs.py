# WARP2/warp2/app/parts/thumbs.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/thumbs.py
#  Used by   : warp2/app/pages/pictures.py.
#  Uses      : PySide6 (QPixmap, QDesktopServices), qfluentwidgets.
#  Description:
#    A picture card: the picture (click to open it full size), a line or two
#    about it, and a row of buttons for what can be done with it.
#  User intention (Andrew): pictures seen and confirmed in one place.
# ============================================================================
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout
from qfluentwidgets import CaptionLabel, CardWidget, PushButton, StrongBodyLabel


_THUMB_CACHE: dict[tuple[str, int], QPixmap] = {}


def get_thumbnail(path: Path | str, size: int) -> QPixmap:
    """Cached thumbnail generator preventing repeated synchronous disk I/O and rescale on UI thread."""
    key = (str(path), size)
    cached = _THUMB_CACHE.get(key)
    if cached is not None and not cached.isNull():
        return cached
    p = Path(path)
    if not p.is_file():
        return QPixmap()
    image = QPixmap(str(p))
    if not image.isNull():
        scaled = image.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio,
                              Qt.TransformationMode.SmoothTransformation)
        if len(_THUMB_CACHE) > 300:
            _THUMB_CACHE.pop(next(iter(_THUMB_CACHE)))
        _THUMB_CACHE[key] = scaled
        return scaled
    return QPixmap()


class PictureCard(CardWidget):
    """One picture and what can be done with it."""

    def __init__(self, path, title: str, line: str = "", actions=(), size: int = 168) -> None:
        """Intention: the picture scaled to `size`, its title, a line, and one button per (words, call)."""
        super().__init__()
        self.path = Path(path)
        self.setFixedWidth(size + 28)
        box = QVBoxLayout(self)
        box.setContentsMargins(14, 14, 14, 12)
        box.setSpacing(6)
        picture = QLabel()
        picture.setAlignment(Qt.AlignmentFlag.AlignCenter)
        picture.setFixedHeight(size)
        picture.setCursor(Qt.CursorShape.PointingHandCursor)
        picture.mousePressEvent = lambda _e: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.path)))

        # Non-blocking thumbnail load: return cached immediately or load in worker thread
        cached_pix = _THUMB_CACHE.get((str(self.path), size))
        if cached_pix is not None and not cached_pix.isNull():
            picture.setPixmap(cached_pix)
        else:
            picture.setStyleSheet("background: rgba(148,163,184,0.1); border-radius: 8px;")
            p_str = str(self.path)

            def load_off_thread():
                """Intention: load and shrink the picture off the window's thread; None if missing or unreadable."""
                from PySide6.QtGui import QImage
                p = Path(p_str)
                if not p.is_file():
                    return None
                try:
                    img = QImage(str(p))
                    if img.isNull():
                        return None
                    return img.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio,
                                      Qt.TransformationMode.SmoothTransformation)
                except Exception:
                    return None

            def on_thumbnail_ready(img):
                """Intention: back on the window's thread — cache the thumbnail (about 300 kept) and show it on the card."""
                if img is not None and not img.isNull():
                    pix = QPixmap.fromImage(img)
                    if len(_THUMB_CACHE) > 300:
                        _THUMB_CACHE.pop(next(iter(_THUMB_CACHE)))
                    _THUMB_CACHE[(p_str, size)] = pix
                    try:
                        picture.setStyleSheet("")
                        picture.setPixmap(pix)
                    except Exception:  # Intention: the card can be closed before its thumbnail arrives; nothing is left to show it on, and the thumbnail is already cached.
                        pass

            from warp2.app.parts.worker import later
            later(load_off_thread, on_thumbnail_ready)

        box.addWidget(picture)
        name = StrongBodyLabel(title[:40])
        name.setWordWrap(True)
        name.setStyleSheet("color: #F8FAFC; font-weight: 600; font-size: 13px;")
        box.addWidget(name)
        if line:
            words = CaptionLabel(line)
            words.setWordWrap(True)
            words.setTextColor("#334155", "#CBD5E1")
            words.setStyleSheet("color: #CBD5E1; font-size: 11px;")
            box.addWidget(words)
        row = QHBoxLayout()
        row.setSpacing(6)
        for words, call in actions:
            button = PushButton(words)
            button.setStyleSheet(
                "QPushButton { background: rgba(51, 65, 85, 0.8); color: #F8FAFC; border: 1px solid rgba(148, 163, 184, 0.35); border-radius: 4px; padding: 4px 8px; font-size: 11px; }"
                "QPushButton:hover { background: rgba(56, 189, 248, 0.3); border-color: #38BDF8; color: #FFFFFF; }"
            )
            def _make_trigger(c=call):
                """Intention: make a click handler bound to this button's own action (avoids the loop-variable trap)."""
                def _trigger():
                    """Intention: on click, remove this card at once, then run the button's action."""
                    try:
                        self.hide()
                        self.deleteLater()
                    except Exception:  # Intention: the card may already be gone when clicked twice or closed; the button's action still runs below.
                        pass
                    if c:
                        c()
                return _trigger
            button.clicked.connect(_make_trigger())
            row.addWidget(button)
        box.addLayout(row)
