# WARP2/warp2/app/parts/flow.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/flow.py
#  Used by   : warp2/app/pages/system.py.
#  Uses      : PySide6 (QGraphicsView), warp2/app/parts/graph.py
#              (layered_layout), warp2/app/theme.py.
#  Description:
#    A flowchart: each step a rounded card with its title, a line under it
#    and its state (running, passed, failed, refused, idle) as a coloured
#    edge and dot; arrows between them in rows, loop-backs as curves round
#    the side. The wheel zooms, dragging pans, clicking a card picks it.
#  User intention (Andrew): the system map seen whole, and live.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPen, QPolygonF
from PySide6.QtWidgets import QGraphicsItem, QGraphicsPathItem, QGraphicsScene, QGraphicsView

from warp2.app import theme
from warp2.app.parts.graph import layered_layout

# Intention: one colour per state of a step.
STATE = {"running": theme.ACCENT, "passed": theme.GOOD, "failed": theme.BAD, "refused": theme.WARN, "idle": theme.QUIET}

WIDTH, HEIGHT = 250.0, 70.0


class Step(QGraphicsItem):
    """One step of the flowchart."""

    def __init__(self, key: str, title: str, line: str, state: str, badge: str) -> None:
        """Intention: a card that knows its words and its state."""
        super().__init__()
        self.key, self.title, self.line, self.state, self.badge = key, title, line, state, badge
        self.picked = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAcceptHoverEvents(True)
        self.hover = False

    def boundingRect(self) -> QRectF:
        """Intention: the card's size, centred on its place."""
        return QRectF(-WIDTH / 2 - 4, -HEIGHT / 2 - 4, WIDTH + 8, HEIGHT + 8)

    def paint(self, painter: QPainter, option, widget=None) -> None:
        """Intention: the card, its state edge, its title, its line and its badge."""
        colour = QColor(STATE.get(self.state, theme.QUIET))
        rect = QRectF(-WIDTH / 2, -HEIGHT / 2, WIDTH, HEIGHT)
        path = QPainterPath()
        path.addRoundedRect(rect, 12, 12)
        fill = QColor(30, 41, 59, 235) if not self.hover else QColor(41, 55, 78, 245)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillPath(path, fill)
        painter.setPen(QPen(colour if self.picked else QColor(148, 163, 184, 70), 2.0 if self.picked else 1.0))
        painter.drawPath(path)
        edge = QPainterPath()
        edge.addRoundedRect(QRectF(rect.left(), rect.top() + 10, 4, rect.height() - 20), 2, 2)
        painter.fillPath(edge, colour)
        painter.setPen(QColor("#F1F5F9"))
        font = QFont()
        font.setPointSizeF(9.5)
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(QRectF(rect.left() + 16, rect.top() + 8, rect.width() - 60, 20),
                         Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                         painter.fontMetrics().elidedText(self.title, Qt.TextElideMode.ElideRight, int(rect.width() - 60)))
        font.setBold(False)
        font.setPointSizeF(8.0)
        painter.setFont(font)
        painter.setPen(QColor("#94A3B8"))
        painter.drawText(QRectF(rect.left() + 16, rect.top() + 30, rect.width() - 28, 34),
                         Qt.AlignmentFlag.AlignLeft | Qt.TextFlag.TextWordWrap, self.line[:120])
        painter.setBrush(QBrush(colour))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(rect.right() - 16, rect.top() + 18), 5, 5)

    def hoverEnterEvent(self, event) -> None:
        """Intention: a little lighter under the pointer."""
        self.hover = True
        self.update()

    def hoverLeaveEvent(self, event) -> None:
        """Intention: back to calm."""
        self.hover = False
        self.update()


def _arrow(a: QPointF, b: QPointF, loop: bool) -> QGraphicsPathItem:
    """Intention: a link from one step's foot to the next step's head; a loop-back curves round the right."""
    path = QPainterPath(a)
    if loop:
        side = max(a.x(), b.x()) + WIDTH * 0.75
        path.cubicTo(QPointF(side, a.y()), QPointF(side, b.y()), b)
    else:
        mid = (a.y() + b.y()) / 2
        path.cubicTo(QPointF(a.x(), mid), QPointF(b.x(), mid), b)
    item = QGraphicsPathItem(path)
    item.setPen(QPen(QColor(56, 189, 248, 150) if loop else QColor(148, 163, 184, 110), 1.6,
                     Qt.PenStyle.DashLine if loop else Qt.PenStyle.SolidLine))
    item.setZValue(-1)
    head = QPainterPath()
    tip = b
    head.addPolygon(QPolygonF([tip, QPointF(tip.x() - 5, tip.y() - 9), QPointF(tip.x() + 5, tip.y() - 9), tip]))
    arrowhead = QGraphicsPathItem(head, item)
    arrowhead.setBrush(QColor(148, 163, 184, 160))
    arrowhead.setPen(Qt.PenStyle.NoPen)
    return item


class FlowView(QGraphicsView):
    """A flowchart to look around in."""

    picked_step = Signal(str)

    def __init__(self, parent=None) -> None:
        """Intention: an empty scene, smooth drawing, zoom and pan."""
        super().__init__(parent)
        self.setScene(QGraphicsScene(self))
        self.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.TextAntialiasing)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setStyleSheet("QGraphicsView {background: transparent; border: none}")
        self.setMinimumHeight(560)
        self.steps: dict = {}

    def show_flow(self, steps: list, links: list, keep_view: bool = False) -> None:
        """steps: [{key, title, line, state, badge}]; links: [(a, b, is_loop)].

        Intention: drawn fresh; when only the states changed, the view is not
        moved, so a live chart does not jump.
        """
        if keep_view and set(self.steps) == {s["key"] for s in steps}:
            for s in steps:
                step = self.steps[s["key"]]
                step.title, step.line, step.state, step.badge = s["title"], s["line"], s["state"], s["badge"]
                step.update()
            return
        scene = self.scene()
        scene.clear()
        self.steps = {}
        where = self._folded(layered_layout([s["key"] for s in steps], [(a, b) for a, b, _l in links],
                                            loops=[(a, b) for a, b, loop in links if loop]))
        for s in steps:
            step = Step(s["key"], s["title"], s["line"], s["state"], s["badge"])
            x, y = where.get(s["key"], (0.0, 0.0))
            step.setPos(x, y)
            scene.addItem(step)
            self.steps[s["key"]] = step
        for a, b, loop in links:
            if a in self.steps and b in self.steps:
                pa, pb = self.steps[a].pos(), self.steps[b].pos()
                scene.addItem(_arrow(QPointF(pa.x(), pa.y() + HEIGHT / 2), QPointF(pb.x(), pb.y() - HEIGHT / 2), loop))
        rect = scene.itemsBoundingRect().adjusted(-60, -60, 60, 60)
        scene.setSceneRect(rect)
        self.fitInView(rect, Qt.AspectRatioMode.KeepAspectRatio)

    def _folded(self, where: dict) -> dict:
        """A tall chart folded into columns, so it fills the view instead of being a thin line.

        Intention: the number of rows in a column is worked out from the
        shape of the view — as many columns as make the chart about as wide
        as it is tall on screen — so the steps are as big as they can be.
        """
        if not where:
            return where
        rows = sorted({y for _x, y in where.values()})
        spread = (max(x for x, _y in where.values()) - min(x for x, _y in where.values())) + WIDTH * 1.4
        view = max(1.0, self.viewport().width()) / max(1.0, self.viewport().height())
        columns = max(1, round(((len(rows) * 130.0) * view / spread) ** 0.5))
        per = -(-len(rows) // columns)
        place = {y: (i // per, i % per) for i, y in enumerate(rows)}
        return {k: (x + place[y][0] * spread, place[y][1] * 130.0) for k, (x, y) in where.items()}

    def mousePressEvent(self, event) -> None:
        """Intention: a click on a step picks it."""
        item = self.itemAt(event.position().toPoint())
        if isinstance(item, Step):
            for step in self.steps.values():
                step.picked = step is item
                step.update()
            self.picked_step.emit(item.key)
            return
        super().mousePressEvent(event)

    def wheelEvent(self, event) -> None:
        """Intention: zoom toward the pointer."""
        factor = 1.0015 ** event.angleDelta().y()
        self.scale(factor, factor)
