# WARP2/warp2/app/parts/verdict_banner.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/parts/verdict_banner.py
#  Used by   : warp2/app/pages/improving.py.
#  Uses      : PySide6, qfluentwidgets, warp2/app/parts/tone.py.
#  Description:
#    The answer at the top of the page, big enough to read from across the
#    room: "Not yet", "Starting to" or "Yes", in its tone's colour, with a
#    glowing edge, and under it each sign it came from — a coloured dot, what
#    the sign is about, and what it says.
#  User intention (Andrew, 2026-10-16): "I want to know if the entire system's
#    improving as a whole ... is there any indication that we're on that
#    route?"
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPainterPath
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QVBoxLayout
from qfluentwidgets import BodyLabel, CaptionLabel, SimpleCardWidget

from warp2.app.parts import tone


class SignRow:
    """One sign's three cells in the banner's grid: a dot, a name, what it says."""

    def __init__(self, grid: QGridLayout, at: int) -> None:
        """Intention: the three labels placed on their line of the grid."""
        self.dot = QLabel("●")
        self.name = BodyLabel("")
        self.name.setStyleSheet("font-weight: 600; color: #E2E8F0;")
        self.says = BodyLabel("")
        self.says.setWordWrap(True)
        self.says.setStyleSheet("color: #CBD5E1;")
        grid.addWidget(self.dot, at, 0, Qt.AlignmentFlag.AlignTop)
        grid.addWidget(self.name, at, 1, Qt.AlignmentFlag.AlignTop)
        grid.addWidget(self.says, at, 2)

    def set(self, sign: dict) -> None:
        """Intention: the sign's tone as the dot's colour, its name and its words."""
        self.dot.setStyleSheet(f"color: {tone.colour(sign.get('tone'))}; font-size: 14px;")
        self.name.setText(str(sign.get("name") or ""))
        self.says.setText(str(sign.get("says") or ""))


class VerdictBanner(SimpleCardWidget):
    """The plain answer and the signs it came from."""

    def __init__(self, parent=None) -> None:
        """Intention: the question, the answer, and room for four signs."""
        super().__init__(parent)
        self.glow = QColor(tone.colour("quiet"))
        outer = QHBoxLayout(self)
        outer.setContentsMargins(28, 22, 28, 22)
        outer.setSpacing(32)
        left = QVBoxLayout()
        left.setSpacing(2)
        question = CaptionLabel("IS THE WHOLE WARP IMPROVING?")
        question.setStyleSheet("font-weight: 600; letter-spacing: 1px; color: #94A3B8;")
        self.answer = QLabel("—")
        self.answer.setStyleSheet("font-size: 40px; font-weight: 700; background: transparent;")
        self.basis = CaptionLabel("From the record: training, graded answers, side steps, action models.")
        self.basis.setStyleSheet("color: #64748B;")
        self.basis.setWordWrap(True)
        left.addWidget(question)
        left.addWidget(self.answer)
        left.addWidget(self.basis)
        left.addStretch(1)
        outer.addLayout(left, 2)
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(8)
        grid.setColumnStretch(2, 1)
        self.rows = [SignRow(grid, i) for i in range(4)]
        outer.addLayout(grid, 5)
        self.setMinimumHeight(150)

    def set(self, said: dict) -> None:
        """Intention: the answer in its tone's colour, and each sign on its line."""
        colour = tone.colour(said.get("tone"))
        self.glow = QColor(colour)
        self.answer.setText(str(said.get("answer") or "—"))
        self.answer.setStyleSheet(f"font-size: 40px; font-weight: 700; color: {colour}; background: transparent;")
        signs = list(said.get("signs") or [])
        for row, sign in zip(self.rows, signs + [{}] * (len(self.rows) - len(signs))):
            row.set(sign)
        self.update()

    def paintEvent(self, event) -> None:
        """Intention: the card, with a soft glow of the answer's colour down its left edge."""
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        fade = QLinearGradient(0, 0, 220, 0)
        start = QColor(self.glow)
        start.setAlpha(70)
        end = QColor(self.glow)
        end.setAlpha(0)
        fade.setColorAt(0.0, start)
        fade.setColorAt(1.0, end)
        shape = QPainterPath()
        shape.addRoundedRect(QRectF(self.rect()), 10, 10)
        painter.setClipPath(shape)
        painter.fillRect(QRectF(0, 0, 220, self.height()), fade)
        edge = QPainterPath()
        edge.addRoundedRect(QRectF(0, 12, 5, self.height() - 24), 2.5, 2.5)
        painter.fillPath(edge, self.glow)
