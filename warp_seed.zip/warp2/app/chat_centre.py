# WARP2/warp2/app/chat_centre.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/chat_centre.py
#  Used by   : warp2/app/pages/{chat,pictures,games}.py.
#  Uses      : warp2/ask/window.py (ActionCentre — every rule of the
#              conversation, the approvals, the pictures and games, kept as
#              they are), PySide6 (QObject, Signal, QTimer, QFileDialog).
#  Description:
#    The Action Centre's logic, run behind the one window. Nothing about how
#    the conversation works changes — he talks, it answers out of what is
#    true, nothing is stored until he says yes. Only the showing changes:
#    where the old window drew into Tk, this says so through signals the
#    pages listen to, always on the window's own thread; slow work runs on
#    the same one background thread the old window used.
#  User intention (Andrew, 2026-09-25): the old windows' parts in one window.
# ============================================================================
from __future__ import annotations

from PySide6.QtCore import QObject, QTimer, Signal

from warp2.ask.window import ActionCentre, _on_ui


class Said:
    """What he is typing, where the Action Centre reads and clears it."""

    def __init__(self) -> None:
        """Intention: empty until the page hands it the composer's text."""
        self.text = ""
        self.changed = None

    def get(self, *_where) -> str:
        """Intention: the text, as Tk's get("1.0", "end") gave it."""
        return self.text

    def delete(self, *_where) -> None:
        """Intention: cleared, and the composer told."""
        self.text = ""
        if self.changed:
            self.changed("")

    def insert(self, _where, words: str) -> None:
        """Intention: words put in, and the composer told."""
        self.text = str(words) + self.text
        if self.changed:
            self.changed(self.text)


class Root:
    """What the Action Centre calls its window, on Qt."""

    def after(self, ms: int, call) -> None:
        """Intention: a call made later on the window's own thread."""
        QTimer.singleShot(int(ms), call)

    def clipboard_clear(self) -> None:
        """Intention: the clipboard emptied."""
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().clear()

    def clipboard_append(self, text: str) -> None:
        """Intention: text put on the clipboard."""
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(str(text))


class Bridge(QObject):
    """The signals the pages listen to."""

    turns = Signal(list)
    note = Signal(str)
    offer = Signal(object)
    lists = Signal()
    archive = Signal(str, list)
    typed = Signal(str)
    game = Signal(dict)
    board = Signal()


class QtCentre(ActionCentre):
    """The Action Centre, shown through signals."""

    def __init__(self, state, root_dir) -> None:
        """Intention: the same centre, with a Qt root, a composer to read, and its queue drained on the window's thread."""
        super().__init__(state, root_dir=root_dir)
        self.bridge = Bridge()
        self.root = Root()
        self.said = Said()
        self.said.changed = self.bridge.typed.emit
        self._drain_ui()

    @_on_ui
    def refresh(self, force: bool = False) -> list:
        """Intention: the conversation as it stands, handed to the page."""
        if self.viewing_archive:
            return []
        turns = self.thread.recent()
        self.bridge.turns.emit(turns)
        return turns

    @_on_ui
    def _say(self, words: str) -> None:
        """Intention: the status line, handed to the page."""
        self.bridge.note.emit(str(words))

    @_on_ui
    def _show_proposal(self, offered) -> None:
        """Intention: no popups or decision bloat in chat — actions are auto-handled."""
        self.proposal = None

    @_on_ui
    def _refresh_projects_list(self, tk=None, colour=None) -> None:
        """Intention: the page redraws its lists."""
        self.bridge.lists.emit()

    @_on_ui
    def _refresh_chats_list(self, tk=None, colour=None) -> None:
        """Intention: the page redraws its lists."""
        self.bridge.lists.emit()

    @_on_ui
    def _refresh_image_queue_ui(self, tk=None, colour=None) -> None:
        """Intention: the page redraws its lists."""
        self.bridge.lists.emit()

    @_on_ui
    def _refresh_confirmations_space(self) -> None:
        """Intention: the page redraws its lists."""
        self.bridge.lists.emit()

    @_on_ui
    def _refresh_images_list(self, tk=None, colour=None) -> None:
        """Intention: the page redraws its lists."""
        self.bridge.lists.emit()

    @_on_ui
    def _display_game_verification_result(self, result_or_report: dict) -> None:
        """Intention: a game's result handed to the Games page."""
        self.bridge.game.emit(dict(result_or_report))

    @_on_ui
    def _render_active_game_board(self) -> None:
        """Intention: the Games page told the board moved."""
        self.bridge.board.emit()

    @_on_ui
    def _show_game_play_ui(self, session) -> None:
        """Intention: the Games page told a game began."""
        self.bridge.board.emit()

    @_on_ui
    def stop_interactive_game_action(self) -> None:
        """Intention: play ended, and the Games page told."""
        self._game_play_active = False
        self._active_session = None
        self.bridge.board.emit()

    def show_archive(self, path: str) -> list:
        """Intention: a past conversation handed to the page to show."""
        self.viewing_archive = path
        turns = self.thread.load_archive(path)
        self.bridge.archive.emit(str(path), turns)
        self._refresh_chats_list()
        return turns

    def show_active_chat(self) -> None:
        """Intention: back to the conversation going on now."""
        self.viewing_archive = ""
        self._refresh_chats_list()
        self.refresh(force=True)

    def add_files(self, paths: list) -> list:
        """Intention: files he picked kept in the inbox with what he was saying, as the old window did."""
        from pathlib import Path

        from warp2.ask.thread import ANDREW
        words = self.said.get().strip()
        made = []
        for path in paths or ():
            made.append(self.inbox.put_file(path, said=words))
            self.thread.add(ANDREW, f"[added {Path(path).name}]" + (f" — {words}" if words else ""))
        if made:
            self.refresh()
            self._say(f"kept {len(made)} file(s)")
        return made


def shared(feed) -> QtCentre:
    """Intention: one centre for the whole window — the chat, the pictures and the games see the same state."""
    if getattr(feed, "centre", None) is None:
        feed.centre = QtCentre(feed.state, feed.root)
    return feed.centre
