# WARP2/warp2/app/tests/test_eye_tree.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_eye_tree.py
#  Used by   : pytest.
#  Uses      : warp2/app/pages/eye_tree.py, warp2/app/parts/{tree_view,
#              relation_bars,tiles}.py, projects/behemoth_eye/eye/hierarchy
#              (summary), eye/relations/ (RelationBook), PySide6,
#              qfluentwidgets (skipped where they are not installed).
#  Description:
#    The Eye tree tab reads the hierarchy the Eye writes and draws it: every
#    group a dot, the opposite cut marked, a picked group's facts and ties,
#    the strongest relations, one name with its mix; and down the right,
#    what the Eye uses now — its group ringed in the tree, and a click on a
#    name going there; the strongest ties in use as plain bars, the names
#    found by name; and the 96 MB hierarchy read small, in its own process,
#    only when the Eye wrote it again (BUILD_LOG 1477).
#  User intention (Andrew, 2026-09-25): "Add an Eye tree tab" — "with more of
#    a visuals centered concept".
# ============================================================================
from __future__ import annotations

import json
import sys
import time
import types
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "projects"), str(ROOT / "projects" / "behemoth_eye" / "eye" / "tests")]


@pytest.fixture(scope="module")
def app():
    """Intention: one Qt application, as the other window tests make it."""
    pytest.importorskip("PySide6")
    pytest.importorskip("qfluentwidgets")
    pytest.importorskip("torch")
    from PySide6.QtWidgets import QApplication
    application = QApplication.instance() or QApplication([])
    from warp2.app import theme
    theme.apply()
    return application


def _written(state: Path) -> None:
    """Intention: the hierarchy of two kinds with their opposites, written where the Eye writes it."""
    from behemoth_eye.eye.hierarchy import Hierarchy, summary
    from behemoth_eye.eye.relations import RelationBook
    from test_hierarchy import _book, _Deps
    book = _book()
    h = Hierarchy("concepts")
    h.update(book, _Deps())
    from behemoth_eye.eye.relations.link import Link
    eye = types.SimpleNamespace(concept_relations=book, concept_hierarchy=h,
                                action_relations=RelationBook(), action_hierarchy=Hierarchy("actions"),
                                concepts=types.SimpleNamespace(pairs={}), concept_link=Link())
    home = state / "models" / "eye"
    home.mkdir(parents=True, exist_ok=True)
    (home / "hierarchy.json").write_text(json.dumps(summary(eye)), encoding="utf-8")


def test_the_eye_tree_tab_draws_the_hierarchy_the_eye_wrote(app, tmp_path):
    from warp2.app.pages.eye_tree import EyeTreePage
    state = tmp_path / "state"
    _written(state)
    feed = types.SimpleNamespace(state=state, root=ROOT)
    from PySide6.QtCore import QObject, Signal

    class Standing(QObject):
        """Intention: the feed's quick reading, as the window has it."""
        standing = Signal(dict)
    ticks = Standing()
    feed.standing = ticks.standing
    (state / "models" / "eye" / "now.json").write_text(json.dumps(
        {"at": time.time(), "kind": "look", "piece": "piece 9", "gap": 0.2, "quiet": False, "made": [],
         "cycles": [[0, ["hot", "warm"]]], "actions": []}), encoding="utf-8")
    whole = EyeTreePage(feed)
    whole.show()
    page = whole.view
    page.draw({})
    # Intention (BUILD_LOG 1477): the hierarchy is now read in a child process; on the busy home PC (measured
    # 2026-11-09, the full app tests failed this at 20 s and passed alone in 19 s) that start needs longer.
    end = time.time() + 90
    while time.time() < end and not page.tree.dots:
        app.processEvents()
        time.sleep(0.05)
    assert len(page.tree.dots) == 7
    assert page.cards["opposite"].value.text() == "2"
    assert page.ties.rows and any(v < 0 for _w, v in page.ties.rows) and any(v > 0 for _w, v in page.ties.rows)
    ties = len(page.ties.rows)
    assert not hasattr(whole, "now"), "BUILD_LOG 1480: the Eye's in-use panel is gone"
    page.name_pick.setCurrentText("hot")
    assert page.name_ties.rows and page.mix_bars.rows
    page.switch.setCurrentItem("actions")
    page._side("actions")
    assert not page.tree.dots
    print(f"\n  [OK] {7} groups drawn, 2 opposite cuts, {ties} ties as bars; hot's mix shown; "
          f"no in-use panel")
    whole.close()


def test_the_hierarchy_is_read_small_in_its_own_process_and_only_again_when_written(tmp_path):
    """Intention (BUILD_LOG 1477): one table of weights instead of a list of rows; read again only after a new save."""
    pytest.importorskip("numpy")
    from warp2.app.parts.eye_digest import Relations, digest_home, read_digest
    home = tmp_path / "models" / "eye"
    home.mkdir(parents=True)
    rows = [["a", "b", 0.5, 3.0], ["b", "c", -0.9, 2.0], ["a", "c", 0.1, 1.0], ["c", "b", -0.8, 2.0]]
    (home / "hierarchy.json").write_text(json.dumps({"concepts": {"relations": rows, "tree": {"uid": 0}},
                                                     "actions": {}, "tasks": {}}), encoding="utf-8")
    got = read_digest(tmp_path, seconds=60)
    table = got["concepts"]["relations"]
    assert isinstance(table, Relations) and len(table) == 3 and got["concepts"]["tree"] == {"uid": 0}
    assert table.strongest() == [("b", "c", pytest.approx(-0.8)), ("a", "b", 0.5), ("a", "c", pytest.approx(0.1))]
    assert table.strongest({"a", "c"}) == [("a", "c", pytest.approx(0.1))]
    assert [o for o, _v in table.ties("c")] == ["b", "a"] and table.ties("nobody") == []
    made = (digest_home(tmp_path) / "concepts.npz").stat().st_mtime_ns
    read_digest(tmp_path, seconds=60)
    assert (digest_home(tmp_path) / "concepts.npz").stat().st_mtime_ns == made
    assert got["digest_why"] == ""


def test_deferred_scale_is_shown_as_prior_or_unknown(app, tmp_path):
    """Intention: a retained display measurement cannot appear newly measured after a lazy save."""
    from warp2.app.pages.eye_tree import EyeTreeView
    view = EyeTreeView(types.SimpleNamespace(state=tmp_path, root=ROOT))
    known = {"closest_real": 0.4, "usual_real": 0.8, "too_close": [],
             "current": False, "deferred_pairs": 7}
    view._fill({"concepts": {"space": known}})
    assert view.cards["spacing"].value.text() == "0.40"
    assert "prior scale" in view.cards["spacing"].caption.text()
    assert "7 pairs deferred" in view.cards["close"].caption.text()
    known["closest_real"] = None
    view._fill({"concepts": {"space": known}})
    assert view.cards["close"].value.text() == "—"
    assert "unmeasured" in view.cards["spacing"].caption.text()
    known["current"] = True
    view._fill({"concepts": {"space": known}})
    assert view.cards["close"].caption.text() == "models to merge"
    view.close()
