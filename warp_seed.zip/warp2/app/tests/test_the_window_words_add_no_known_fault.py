# WARP2/warp2/app/tests/test_the_window_words_add_no_known_fault.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_the_window_words_add_no_known_fault.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/app/parts/standing_words.py, warp2/builders/faults.py.
#  Description:
#    The window's words (Build 1455) added three faults of known kinds - two
#    times cut to a set width ([:19]) and an unmarked except that returned
#    None - so the start gate failed and set aside most of the tree
#    (BUILD_LOG 1457-1460). This test fails on that old file and passes on the
#    fixed one: no known fault in standing_words.py, a time is read whole, and
#    text that is not a time is shown as it was.
#  User intention (Andrew, 2026-10-16): builders may change the code on their
#    own; every fix carries a test that fails on the old code.
# ============================================================================
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from warp2.app.parts import standing_words as words
from warp2.builders import faults

FILE = Path(words.__file__)


def test_the_window_words_carry_no_known_fault():
    """Intention: the faults check finds nothing in the window's words, so they cannot fail the start gate."""
    assert faults.faults_in(FILE) == []


def test_a_time_with_fractions_is_read_whole():
    """Intention: a reading with fractions of a second still has an age; nothing is cut to a set width."""
    then = datetime(2026, 11, 8, 16, 55, 30, 500000).timestamp()
    assert words.measured_age("2026-11-08 16:55:30.500000", then + 60) == 60


def test_text_that_is_not_a_time_is_shown_as_it_was():
    """Intention: a long note in the time's place is not cut; the person sees it whole."""
    note = "not read yet - the runner has not written its first beat"
    assert words.local_time(note) == note
    assert words.local_time(note, clock_only=True) == note
