# WARP2/warp2/app/tests/test_the_window_says_what_is_going.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_the_window_says_what_is_going.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/app/parts/standing_words.py, warp2/app/pages/capability.py (ENDED).
#  Description:
#    The window says what is true: the main runner's step in flight with its
#    usual time, paused for memory, can't tell (never "not running" with a
#    Start beside a live runner), times in this machine's clock, colours as
#    temperatures, and outcomes the journals write coloured. Fails on the old
#    code, which had none of these words (standing_words.py did not exist).
#  User intention (Andrew, 2026-11-08): "The gui still doesn't say everything
#    is going fix it"; "look for other silly mistakes that could be in the gui
#    and try to get in lign with what a person would want to see" (BUILD_LOG 1455).
# ============================================================================
from __future__ import annotations

from datetime import datetime, timezone

from warp2.app import theme
from warp2.app.parts import standing_words as words

LONG = {"verb": "teach_eye_what_was_made", "running_seconds": 6660.0, "usual_seconds": 1206.0, "overdue": True}


def test_the_step_in_flight_is_named_with_its_usual_time():
    said = words.doing_line({"running": True, "step": LONG, "doing": "Warp: read the frontier · 1m ago"})
    assert said.startswith("Main runner: teach eye what was made - 1.9 h (usually 20 min)")
    assert "Latest finished: Warp: read the frontier" in said


def test_a_long_step_is_said_and_warms_with_how_far_past():
    text, colour, button = words.pill({"running": True, "step": LONG})
    assert "taking long" in text and button == "Stop"
    near = words.blend(theme.GOOD, theme.BAD, words.step_heat({**LONG, "running_seconds": 1300.0}))
    assert colour != near and words.step_heat(LONG) > words.step_heat({**LONG, "running_seconds": 1300.0})
    assert words.step_heat({**LONG, "running_seconds": 600.0}) == 0.0


def test_paused_for_memory_says_what_it_waits_for():
    stand = {"running": True, "floor_mb": 3201,
             "health": {"memory_said": {"last": {"free_mb": 1445, "waiting": True}}}}
    text, colour, button = words.pill(stand)
    assert text == "⏸ Paused for memory (1445 MB free, needs 3201 MB)" and colour == theme.WARN


def test_cannot_tell_never_offers_start():
    assert words.pill({"running": None})[2] == ""
    assert words.pill({"running": False, "health": {"runner_alive": True}})[2] == ""
    assert words.pill({"running": False, "health": {"runner_alive": False}}) == ("○ Not running", theme.QUIET, "Start")
    assert words.pill({"stopped": True, "running": True})[2] == "Resume"


def test_times_are_in_this_machine_s_clock():
    stamp = "2026-11-09T01:47:37+00:00"
    local = datetime(2026, 11, 9, 1, 47, 37, tzinfo=timezone.utc).astimezone()
    assert words.local_time(stamp) == local.strftime("%Y-%m-%d %H:%M:%S")
    assert words.local_time(stamp, clock_only=True) == local.strftime("%H:%M:%S")
    assert words.local_time("not a time") == "not a time"


def test_memory_warms_against_the_measured_floor():
    assert words.memory_heat(6400, 3200) == 0.0
    assert words.memory_heat(3200, 3200) == 1.0
    assert 0.0 < words.memory_heat(4800, 3200) < 1.0
    assert words.memory_heat(None, 3200) is None


def test_an_old_measure_says_how_old():
    then = datetime(2026, 11, 8, 16, 55, 30).timestamp()
    assert words.measured_age("2026-11-08 16:55:30", then + 3600) == 3600
    assert words.measured_age("", then) is None


def test_outcomes_the_journals_write_are_coloured():
    from warp2.app.pages.capability import ENDED
    assert ENDED["passed"] == theme.GOOD and ENDED["broken_test"] == theme.BAD and ENDED["written"] == theme.GOOD
