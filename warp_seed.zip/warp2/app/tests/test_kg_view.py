# WARP2/warp2/app/tests/test_kg_view.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_kg_view.py
#  Used by   : pytest (run_tests.py, RUN_TESTS.bat).
#  Uses      : warp2/app/parts/{kg_filter,kg_controls,graph}.py,
#              warp2/app/pages/knowledge.py (with PySide6 drawing off screen).
#  Description:
#    The KG view's controls proven: filters by kind, relation, grade and
#    machinery; the most joined things; a neighbourhood to a depth; the
#    shortest path; the suggestions; and on screen — the controls redraw the
#    graph, a path is drawn and lit, expanding adds and collapsing takes the
#    same things away, a moved dot stays pinned, back and forward walk the views.
#  User intention (Andrew, 2026-09-25): "we need better controle in the kg view".
# ============================================================================
from __future__ import annotations

import os

import pytest

from warp2.app.parts import kg_filter as kf

NODES = [{"id": "concept:a", "kind": "concept"}, {"id": "concept:b", "kind": "concept"},
         {"id": "warp2/c.py"}, {"id": "skill:d", "kind": "skill"}, {"id": "phrase:e", "kind": "phrase"}]
EDGES = [{"from": "concept:a", "to": "concept:b", "relation": "supports"},
         {"from": "concept:b", "to": "warp2/c.py", "relation": "defines", "proof": 4},
         {"from": "warp2/c.py", "to": "skill:d", "relation": "depends_on"},
         {"from": "concept:a", "to": "phrase:e", "relation": "derives"}]


def test_filters_keep_what_is_chosen_and_links_between_kept_things():
    """Intention: a kind hidden takes its links with it; a relation, a grade and machinery each filter links."""
    assert kf.kinds_of(NODES)[0] == "concept" and "file" in kf.kinds_of(NODES)
    nodes, edges = kf.filtered(NODES, EDGES, kinds={"concept", "file"})
    assert {n["id"] for n in nodes} == {"concept:a", "concept:b", "warp2/c.py"} and len(edges) == 2
    _n, edges = kf.filtered(NODES, EDGES, relations={"supports"})
    assert [e["relation"] for e in edges] == ["supports"]
    _n, edges = kf.filtered(NODES, EDGES, least_grade=4)
    assert [e["relation"] for e in edges] == ["defines"]
    _n, edges = kf.filtered(NODES, EDGES, hide_machinery=True)
    assert "derives" not in {e["relation"] for e in edges}


def test_most_joined_around_and_the_shortest_path():
    """Intention: the size, the depth and the path are all the graph's own answers."""
    nodes, _e = kf.most_joined(NODES, EDGES, 2)
    assert {n["id"] for n in nodes} == {"concept:a", "concept:b"}
    ring1, _e = kf.around(NODES, EDGES, "concept:b", 1)
    assert {n["id"]: n["ring"] for n in ring1} == {"concept:b": 0, "concept:a": 1, "warp2/c.py": 1}
    ring2, _e = kf.around(NODES, EDGES, "concept:b", 2)
    assert len(ring2) == 5
    assert kf.path_between(EDGES, "phrase:e", "skill:d") == ["phrase:e", "concept:a", "concept:b", "warp2/c.py", "skill:d"]
    assert kf.path_between(EDGES, "concept:a", "nowhere") == []
    assert kf.matching(NODES, "c.py", 3) == ["warp2/c.py"]
    assert kf.matching(NODES, "concept:a", 3)[0] == "concept:a"


os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture(scope="module")
def app():
    """Intention: one Qt application, dark Fluent theme set."""
    pytest.importorskip("PySide6")
    pytest.importorskip("qfluentwidgets")
    from PySide6.QtWidgets import QApplication
    application = QApplication.instance() or QApplication([])
    from warp2.app import theme
    theme.apply()
    return application


class _Feed:
    """Intention: a stand-in feed — a scratch state folder, nothing read."""

    def __init__(self, tmp_path) -> None:
        self.root, self.state = tmp_path, tmp_path / "state"


def test_the_controls_drive_the_graph(app, tmp_path):
    """Intention: filters redraw it; a path is drawn; expand and collapse; a pin stays; back and forward."""
    from warp2.app.pages.knowledge import KnowledgePage
    page = KnowledgePage(_Feed(tmp_path))
    page.show()
    page.draw({"kg": {"nodes": NODES, "edges": EDGES}})
    assert set(page.graph.dots) == {n["id"] for n in NODES}
    page.controls.kinds._tick("phrase", False)
    assert "phrase:e" not in page.graph.dots
    page.controls.start.setText("phrase")
    page.controls.kinds._all(True)
    page.find_path("concept:a", "skill:d")
    assert page.view["mode"] == "path" and set(page.graph.dots) == {"concept:a", "concept:b", "warp2/c.py", "skill:d"}
    assert page.graph.lit == set(page.view["chain"])
    page._step(-1)
    assert page.view["mode"] == "whole" and len(page.graph.dots) == 5
    page._step(1)
    assert page.view["mode"] == "path"
    page.go({"mode": "whole"})
    graph = page.graph
    graph.show_graph([{"id": "concept:a"}], [], layout="radial")
    added = graph.expand("concept:a", [{"id": "concept:b"}, {"id": "phrase:e"}],
                         [("concept:a", "concept:b", "supports"), ("concept:a", "phrase:e", "derives")])
    assert added == 2 and set(graph.dots) == {"concept:a", "concept:b", "phrase:e"}
    assert graph.collapse("concept:a") == 2 and set(graph.dots) == {"concept:a"}
    graph.dots["concept:a"].setPos(123.0, 45.0)
    assert graph.pinned["concept:a"] == (123.0, 45.0)
    graph.show_graph([{"id": "concept:a"}, {"id": "concept:b"}], [("concept:a", "concept:b", "supports")])
    assert (graph.dots["concept:a"].x(), graph.dots["concept:a"].y()) == (123.0, 45.0)
    page.close()
