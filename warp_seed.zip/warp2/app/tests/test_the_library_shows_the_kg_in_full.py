# WARP3/warp2/app/tests/test_the_library_shows_the_kg_in_full.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/app/tests/test_the_library_shows_the_kg_in_full.py
#  Used by   : pytest.
#  Uses      : warp2/app/parts/library_reads.py, warp2/app/pages/library.py, warp2/app/lean/parts.py, warp2/ask/{inbox,taking}.py,
#              warp2/corpus/convert/state_text.py (text_parts), warp2/store/store.py; PySide6 (offscreen).
#  Description:
#    A made state: a log kept in the text corpus is listed by its folder and
#    given back in full; a thing of the KG is listed by its type and its tag
#    and read in full; an added note, a user's tag and a dispute go through
#    the inbox and the runner's taking writes them, after which the thing
#    shows the tag and the dispute; the page opens, lists, opens a part and
#    finds words in it; the Library is one of the window's parts.
#  User intention (Andrew, 2026-11-19 16:48): "we need to add a tab that allows the user to look
#    at things in the kg as the rehydrated files in full. This should look
#    like a file system that allows the user to look through the system via
#    types and tags and other ways of separation and allow for search in the
#    opened part. It should also be a place where the user can add new
#    things to the kg themselves ... It should also allow the user to add
#    their own tags or dispute tags that were on something." BUILD_LOG 1700L.
# ============================================================================
"""The Library reads files and things in full, and its asks reach the KG through the inbox."""
from __future__ import annotations

import os
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from warp2.app.parts import library_reads as reads
from warp2.ask.inbox import Inbox
from warp2.corpus.convert.state_text import text_parts
from warp2.corpus.parts import TEXT
from warp2.store.store import Store, store_home

LOG = b"2026-11-19 16:00 the runner began a pass\n2026-11-19 16:01 kept entries-0001.bin\n" * 40


def _state(tmp_path):
    """Intention: a state with one log in the text corpus and one paper with a tag in the KG."""
    state = tmp_path / "state"
    state.mkdir()
    text_parts(state, "journals").add([("journals/run.log", "text", LOG)], TEXT)
    store = Store(store_home(state))
    try:
        paper = "https://arxiv.org/abs/0000.00001"
        store.assert_fact(paper, "has", attr="title", value="A paper on keeping files small")
        store.assert_fact(paper, "has", attr="text", value="the whole text of the paper " * 400)
        store.assert_fact("tag:provider=arxiv", "has", attr="kind", value="category")
        store.assert_fact(paper, "has", attr="content_digest", value=store.evidence.put("the abstract, held as evidence"))
        store.assert_fact("tag:provider=arxiv", "derives", paper)
        store.assert_fact("finding:9a1a", "has", attr="kind", value="finding")
        store.assert_fact("finding:9a1a", "has", attr="summary", value="walking a file in parts keeps it smaller")
        store.assert_fact("finding:9a1a", "derives", paper)
        store.assert_fact("need:adad", "has", attr="question", value="how small can a kept file be")   # says no kind
        store.assert_fact("need:adad", "supports", "finding:9a1a")
    finally:
        store.close()
    return state, paper


def _taken(state) -> list:
    """Intention: the runner's taking of what waits in the inbox, with only the parts these asks use."""
    from warp2.ask.taking import Taking
    store, inbox, done = Store(store_home(state)), Inbox(state), []
    try:
        taking = Taking.__new__(Taking)
        taking.store = store
        for asked in inbox.waiting():
            answer = taking._one(asked)
            inbox.handled(asked["id"], answer["how"], answer["made"])
            done.append(answer)
    finally:
        store.close()
    return done


def test_files_and_things_are_listed_and_read_in_full_and_asks_reach_the_kg(tmp_path):
    state, paper = _state(tmp_path)
    assert reads.file_text(state, "journals/run.log") == LOG.decode()
    tags = reads.inside(state, ("under", "tag:"))
    assert tags["kids"]["provider"]["kids"]["arxiv"]["names"] == ["tag:provider=arxiv"]
    read = reads.thing(state, paper)
    assert read["tags"] == ["tag:provider=arxiv"] and ("text", "the whole text of the paper " * 400) in read["facts"]
    assert ("content in full", "the abstract, held as evidence") in read["facts"]
    assert reads.thing(state, "tag:provider=arxiv")["on"] == [paper]
    assert reads.inside(state, ("files", "journals"))["kids"]["run.log"]["names"] == ["journals/run.log"]
    reads.add_tag(state, paper, "  worth  reading ")
    reads.dispute(state, paper, "tag:provider=arxiv", "it came from somewhere else")
    reads.add_text(state, "my note", "words of my own", paper)
    assert sorted(a["how"] for a in _taken(state)) == ["kept it", "kept the dispute beside the tag", "tagged it"]
    after = reads.thing(state, paper)
    assert after["tags"] == ["tag:provider=arxiv", "tag:user=worth reading"]
    assert after["disputes"] == [("tag:provider=arxiv", "it came from somewhere else")]
    assert reads.search(state, "worth")["n"] == 1


def test_a_window_holding_the_inbox_from_before_still_asks_for_a_tag(tmp_path, monkeypatch):
    from warp2.ask import inbox
    for name in ("TAG", "DISPUTE", "APART", "KEPT_APART"):          # the inbox as a window brought it in before 1700L
        monkeypatch.delattr(inbox, name)
    monkeypatch.setattr(inbox, "KINDS", tuple(k for k in inbox.KINDS if k not in ("tag", "dispute")))
    asked = reads.add_tag(tmp_path / "state", "thing:1", "mine")
    assert asked["kind"] == "tag" and (tmp_path / "state" / "asked" / "library" / f"{asked['id']}.json").is_file()


def _let_go() -> None:
    """Intention: the KG the Library holds open for a window is closed, so the test's folder can be taken away."""
    for (_state_, what), held in list(reads._HELD.items()):
        if what == "open":
            held.close()
    reads._HELD.clear()


def test_the_page_is_one_nest_that_reads_only_what_is_opened(tmp_path, monkeypatch):
    from PySide6.QtCore import QThreadPool
    from PySide6.QtWidgets import QApplication
    from warp2.app.lean.parts import PARTS
    from warp2.app.pages.library import MORE, SEP, WAITING, LibraryPage
    app = QApplication.instance() or QApplication([])
    state, paper = _state(tmp_path)
    store = Store(store_home(state))
    for k in range(300):                                     # a folder with more rows than a screen shows
        store.assert_fact(f"work:{k:03d}", "has", attr="kind", value="work")
    store.close()
    read = []
    inside = reads.inside
    monkeypatch.setattr(reads, "inside", lambda state_, lazy: (read.append(lazy), inside(state_, lazy))[1])

    def settle() -> None:
        """Intention: the reads sent off the window's thread have come back."""
        for _again in range(3):
            QThreadPool.globalInstance().waitForDone()
            app.processEvents()

    def rows(item) -> list:
        """Intention: the words of the rows under a row."""
        return [item.child(k).text(0) for k in range(item.childCount())]

    def row(item, begins: str):
        """Intention: the row under a row whose words begin so."""
        return [item.child(k) for k in range(item.childCount()) if item.child(k).text(0).startswith(begins)][0]

    try:
        assert "library" in [part[0] for part in PARTS]
        page = LibraryPage(SimpleNamespace(state=state))
        page.resize(1200, 900)
        page.show()
        settle()
        top = page.tree.invisibleRootItem()
        assert rows(top) == ["Research", "Everything in the KG, by name", "By type", "By tag", "Kept files (logs, research kept as files)"]
        research = top.child(0)
        assert research.isExpanded() and rows(research)[0] == "need" and read == []        # nothing of the KG read yet
        need = row(research, "need")
        need.setExpanded(True)
        settle()
        assert read == [("kind", "need")] and need.text(0) == "need   (1)"                  # only what was opened
        thing = need.child(0)
        assert thing.text(0) == f"how small can a kept file be{SEP}adad"                     # called what it says, on screen
        page.tree.itemClicked.emit(thing, 0)
        settle()
        assert page.opened == "need:adad"
        assert [page.links.item(k).text() for k in range(page.links.count())] == [
            f"supports: walking a file in parts keeps it smaller{SEP}finding:9a1a"]
        page.links.itemClicked.emit(page.links.item(0))      # a link followed: the finding, and what it is linked to
        settle()
        assert page.opened == "finding:9a1a" and "walking a file in parts" in page.text.toPlainText()
        assert sorted(page.links.item(k).text().split(SEP)[-1] for k in range(page.links.count())) == [paper, "need:adad"]
        sources = row(research, "source")
        sources.setExpanded(True)
        settle()
        site = sources.child(0)
        assert site.text(0) == "https://arxiv.org" and rows(site) == [WAITING]              # folders inside folders
        site.setExpanded(True)
        site.child(0).setExpanded(True)
        settle()
        leaf = site.child(0).child(0)
        assert leaf.text(0).startswith("A paper on keeping files small") and leaf.text(0).endswith(f"{SEP}0000.00001")
        page.tree.itemClicked.emit(leaf, 0)
        settle()
        assert "the whole text of the paper" in page.text.toPlainText() and page.tags.item(0).text() == "tag:provider=arxiv"
        page.new_tag.setText("mine")
        page.add_tag()
        assert [a["kind"] for a in Inbox(state).waiting()] == ["tag"] and "Asked" in page.said.text()
        assert "tag:user=mine" in page.tags.item(1).text() and "waiting" in page.tags.item(1).text()
        research.setExpanded(False)
        types = row(top, "By type")
        types.setExpanded(True)
        settle()
        work = row(types, "work")
        assert work.text(0) == "work   (300)"
        work.setExpanded(True)
        settle()
        inner = work
        shown = inner.childCount()
        assert shown < 300 and inner.child(shown - 1).text(0) == MORE                       # a screen of rows, not all
        page.tree.scrollToItem(inner.child(shown - 1))
        settle()
        assert inner.childCount() > shown                                                   # the next rows, when looked at
        while inner.child(inner.childCount() - 1).text(0) == MORE:
            page.tree.scrollToItem(inner.child(inner.childCount() - 1))
            settle()
        assert inner.childCount() == 300                                                    # and there is no end to it
        files = row(top, "Kept files")
        files.setExpanded(True)
        row(files, "journals").setExpanded(True)
        settle()
        page.tree.itemClicked.emit(row(files, "journals").child(0), 0)
        settle()
        assert page.text.toPlainText() == LOG.decode()
        page.find.setText("entries-0001")
        assert page.hits.text() == "40 found"
        page.find_next()
        assert page.text.textCursor().selectedText() == "entries-0001"
        page.everywhere.setText("smaller")                       # the whole KG searched
        page.search()
        settle()
        found = top.child(0)
        assert found.text(0) == "Found for 'smaller'   (1)" and found.child(0).text(0).endswith("[finding:9a1a]")
        page.tree.itemClicked.emit(found.child(0), 0)
        settle()
        assert page.opened == "finding:9a1a"
        page.close()
    finally:
        _let_go()


def test_a_folder_of_a_folded_kg_reads_only_the_rows_it_shows(tmp_path, monkeypatch):
    """Intention (2030o): on a KG that has been folded, a folder is a run of numbers - a name is read only for a
    row that is shown, folders are inside folders, and the things newer than the fold are at the end."""
    import random
    import warp2.record.journal as journal
    from warp2.store.small_kg.build import build
    from warp2.tags.dehydrated.whole_lane import WholeLane
    monkeypatch.setattr(journal, "ROTATE_AFTER_BYTES", 40000)
    state, rng = tmp_path / "state", random.Random(5)
    things = [f"finding:{k:04d}" for k in range(400)] + ["https://arxiv.org/abs/1", "https://arxiv.org/abs/1#part-1",
                                                          "https://arxiv.org/abs/1#part-2", "https://doi.org/10.1/x", "warp2/a.py", "warp2/a.py::f"]
    store = Store(state)
    for _again in range(4):
        for thing in rng.sample(things, len(things)):
            store.assert_fact(thing, "has", attr="kind", value="finding" if thing.startswith("finding") else "other")
            store.assert_fact(thing, "has", attr="note", value=f"{rng.random()} " * 20)
    tags = state / "store" / "tags"
    assert WholeLane(tags, say=lambda _t: None, form=2).run()["done"] >= 1
    build(state, say=lambda _t: None, workers=1)
    store.assert_fact("finding:new", "has", attr="kind", value="finding")
    store.close()
    read = []
    name_of = Store.name_of
    monkeypatch.setattr(Store, "name_of", lambda self, number: (read.append(number), name_of(self, number))[1])
    try:
        every = reads.inside(state, ("under", ""))
        assert every["n"] == len(things) + 1 and read == []                       # opened: no name read yet
        top = reads.rows(state, every, every["run"]["lo"], 10)
        assert [(piece, name, kid["n"]) for piece, name, kid in top["rows"]] == [
            ("finding", None, 400), ("https://arxiv.org", None, 3), ("https://doi.org", None, 1), ("warp2", None, 2)]
        assert top["at"] == every["run"]["hi"] and every["new"]["kids"]["finding"]["kids"]["new"]["names"] == ["finding:new"]
        read.clear()
        findings = top["rows"][0][2]
        first = reads.rows(state, findings, findings["run"]["lo"], 5)
        assert [name for _piece, name, _kid in first["rows"]] == [f"finding:{k:04d}" for k in range(5)]
        assert len(set(read)) <= 6                                                 # five rows shown, not four hundred
        site = reads.rows(state, top["rows"][1][2], top["rows"][1][2]["run"]["lo"], 5)["rows"][0][2]
        paper = reads.rows(state, site, site["run"]["lo"], 5)["rows"]
        assert [(piece, name, kid["n"]) for piece, name, kid in paper] == [("1", "https://arxiv.org/abs/1", 3)]   # the paper, its parts inside
        parts = reads.rows(state, paper[0][2], paper[0][2]["run"]["lo"], 5)["rows"]
        assert [(piece, name) for piece, name, _kid in parts] == [("part-1", "https://arxiv.org/abs/1#part-1"), ("part-2", "https://arxiv.org/abs/1#part-2")]
        code = reads.rows(state, top["rows"][3][2], top["rows"][3][2]["run"]["lo"], 5)["rows"]
        assert [(piece, name, kid["n"]) for piece, name, kid in code] == [("a.py", "warp2/a.py", 2)]
        kind = reads.inside(state, ("kind", "finding"))                            # by kind: the folder is not shown inside itself
        assert kind["n"] == 401 and kind["run"]["begins"] == "finding:" and kind["new"]["names"] == [] and list(kind["new"]["kids"]) == ["new"]
        assert reads.inside(state, ("kinds", ""))["kids"]["finding"]["n"] == 401
        from PySide6.QtCore import QThreadPool
        from PySide6.QtWidgets import QApplication
        from warp2.app.pages.library import MORE, NEW, LibraryPage
        app = QApplication.instance() or QApplication([])

        def settle() -> None:
            """Intention: the reads sent off the window's thread have come back."""
            for _again in range(4):
                QThreadPool.globalInstance().waitForDone()
                app.processEvents()

        page = LibraryPage(SimpleNamespace(state=state))
        page.resize(1200, 900)
        page.show()
        settle()
        research = page.tree.invisibleRootItem().child(0)
        research.setExpanded(False)
        everything = page.tree.invisibleRootItem().child(1)
        everything.setExpanded(True)
        settle()
        assert [everything.child(k).text(0) for k in range(everything.childCount())] == [
            "finding   (400)", "https://arxiv.org   (3)", "https://doi.org", "warp2   (2)", f"{NEW}   (1)"]
        found = everything.child(0)
        found.setExpanded(True)
        settle()
        shown = found.childCount()
        assert shown < 400 and found.child(shown - 1).text(0) == MORE and found.child(0).text(0).endswith("0000")
        while found.child(found.childCount() - 1).text(0) == MORE:
            page.tree.scrollToItem(found.child(found.childCount() - 1))
            settle()
        assert found.childCount() == 400
        page.close()
    finally:
        _let_go()


def test_names_are_nested_where_their_own_marks_cut_them():
    assert reads.pieces("https://arxiv.org/abs/0000.00001#part-2") == ["https://arxiv.org", "abs", "0000.00001", "part-2"]
    assert reads.pieces("projects/uhe/image.py::_apply") == ["projects", "uhe", "image.py", "_apply"]
    assert reads.pieces("tag:provider=arxiv") == ["tag", "provider", "arxiv"]
    nest = reads.nested(["a:b", "a:c", "a"])
    assert nest["n"] == 3 and nest["kids"]["a"]["names"] == ["a"] and sorted(nest["kids"]["a"]["kids"]) == ["b", "c"]
