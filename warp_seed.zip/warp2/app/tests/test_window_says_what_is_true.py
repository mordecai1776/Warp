# WARP2/warp2/app/tests/test_window_says_what_is_true.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_window_says_what_is_true.py
#  Used by   : pytest.
#  Uses      : warp2/app/record_index.py, warp2/app/capabilities.py,
#              warp2/app/parts/user_tasks_view.py (_working_on),
#              warp2/app/parts/now_view.py (_badge, RunningEngineCard).
#  Description:
#    The window shows only what the warp does: a capability that never ended
#    well has no tab, run counts are the whole record, the task "worked on
#    now" is the one the runner says, a lane is "running" only while its
#    newest step is fresh, and the run state pill follows the real state.
#  User intention (Andrew, 2026-10-02): "make sure the gui does not show
#    things it does not do and clean it up more".
# ============================================================================
from __future__ import annotations

import json
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


def _journal(state, rows):
    folder = state / "journals"
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / "continuous.jsonl").open("a", encoding="utf-8") as out:
        for row in rows:
            out.write(json.dumps(row) + "\n")


def test_the_whole_record_is_read_and_only_new_lines_after(tmp_path):
    from warp2.app.record_index import record_of
    _journal(tmp_path, [{"verb": "keep_webs", "outcome": "ok", "ts": "2026-09-28T01:00:00"}] * 3000)
    first = record_of(tmp_path, ["continuous.jsonl"])
    assert first["keep_webs"]["runs"] == 3000 and first["keep_webs"]["last_ok"].startswith("2026-09-28")
    _journal(tmp_path, [{"verb": "keep_webs", "outcome": "error", "ts": "2026-10-02T01:00:00"}])
    again = record_of(tmp_path, ["continuous.jsonl"])
    assert again["keep_webs"]["runs"] == 3001 and again["keep_webs"]["errors"] == 1
    assert again["keep_webs"]["last"].startswith("2026-10-02")


def test_a_step_that_never_ended_well_has_no_tab(tmp_path):
    from warp2.app.capabilities import Capabilities
    _journal(tmp_path, [{"verb": "refine_datasets", "outcome": "ok", "ts": "2026-10-02T01:00:00"},
                        {"verb": "assemble_webs", "outcome": "error", "ts": "2026-10-02T01:00:00"}])
    caps = Capabilities(tmp_path, tmp_path)
    keys = {c["key"] for c in caps.all([])}
    assert "refine_datasets" in keys and "assemble_webs" not in keys
    assert "running" in keys


def test_the_task_worked_on_is_the_one_the_runner_says():
    from warp2.app.parts.user_tasks_view import _working_on
    active = [{"title": "dog"}, {"title": "cat"}]
    assert _working_on(active, "an image of cat") == 1
    assert _working_on(active, "") == -1
    assert _working_on(active, "an image of a horse") == -1


def test_a_lane_is_running_only_while_its_step_is_fresh_and_the_pill_follows_the_state():
    from PySide6.QtWidgets import QApplication
    from qfluentwidgets import CaptionLabel
    from warp2.app.parts.now_view import RunningEngineCard, _badge
    app = QApplication.instance() or QApplication([])
    label = CaptionLabel("")
    _badge(label, 5.0)
    assert label.text() == "running"
    _badge(label, 3600.0)
    assert label.text().startswith("quiet")
    _badge(label, None)
    assert label.text() == "no steps"
    card = RunningEngineCard()
    assert card.status_pill.text() == "—"
    card.show_state({"stopped": True, "running": False})
    assert card.status_pill.text() == "ALL_STOP raised"
    card.show_state({"stopped": False, "running": True})
    assert card.status_pill.text() == "Runner up"
    card.show_state({"stopped": False, "running": False})
    assert card.status_pill.text() == "Runner not running"
    app.processEvents()
