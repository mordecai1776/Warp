# WARP2/warp2/app/tests/test_now_highlight.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_now_highlight.py
#  Used by   : pytest.
#  Uses      : warp2/app/parts/now_view.py (RunningEngineCard),
#              warp2/app/parts/user_tasks_view.py (ActiveTaskCard, UserTasksView),
#              PySide6.
#  Description:
#    Tests that the right panel highlights what it is working on in the moment
#    and shows what the background engine is running at the top.
#  User intention (Andrew, 2026-09-27):
#    "ok the right side should highlight exactly what it is working on in the
#    moment and have a thing at the top that says the other stuff when it is
#    running that it is doing."
# ============================================================================
from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")
pytest.importorskip("qfluentwidgets")


@pytest.fixture(scope="module")
def app():
    from PySide6.QtWidgets import QApplication
    application = QApplication.instance() or QApplication([])
    from warp2.app import theme
    theme.apply()
    return application


def test_running_engine_card_displays_background_lanes(app):
    from warp2.app.parts.now_view import RunningEngineCard

    card = RunningEngineCard()
    # Intention (2026-10-02): before a reading, the card says nothing rather
    # than inventing what the lanes do ("Building & Training" was fixed text).
    assert card.card_verb.text() == "—"
    assert card.web_verb.text() == "—"

    now_map = {
        "continuous": {
            "entry": {
                "verb": "practice_centering",
                "target": "cat",
                "outcome": "ok",
            },
            "owner": "phase:training",
            "ago": 4.5,
        },
        "web": {
            "entry": {
                "verb": "read_the_frontier",
                "target": "research:needs",
                "outcome": "ok",
            },
            "owner": "running",
            "ago": 2.1,
        },
    }
    caps_map = {
        "phase:training": {"name": "Vision Centering"},
        "running": {"name": "Web Research"},
    }

    card.update_lanes(now_map, caps_map)

    assert "Practice centering" in card.card_verb.text()
    assert "cat" in card.card_detail.text()
    assert card.card_badge.text() == "running"

    assert "Read the frontier" in card.web_verb.text()
    assert "research:needs" in card.web_detail.text()
    assert card.web_badge.text() == "running"


def test_active_task_card_focus_highlighting(app):
    from warp2.app.parts.user_tasks_view import ActiveTaskCard

    task = {
        "id": "20260928T003259-8fef9d5249",
        "title": "cat",
        "target": "project:centering_image",
        "kind": "image",
        "status": "in_progress",
    }

    focus_card = ActiveTaskCard(task, is_current_focus=True)
    assert focus_card.objectName() == "activeFocusCard"
    assert focus_card.is_current_focus is True

    queued_card = ActiveTaskCard(task, is_current_focus=False)
    assert queued_card.objectName() == "activeQueuedCard"
    assert queued_card.is_current_focus is False


def test_lane_distinguishes_liveness_from_progress(app):
    from warp2.app.parts.now_view import RunningEngineCard
    card = RunningEngineCard()
    now = {'entry': {'verb': 'measure_picture_concepts', 'outcome': 'in_progress'},
           'owner': 'running', 'ago': 600, 'heartbeat_age': 1}
    card.update_lanes({'continuous': now}, {})
    assert card.card_badge.text() == 'alive · no recent report'
    now.update(progress={'done': 4}, progress_age=1, progress_text='4/20 images checked')
    card.update_lanes({'continuous': now}, {})
    assert card.card_badge.text() == 'working'
    assert card.card_detail.text() == '4/20 images checked'
    now['progress_age'] = 600
    card.update_lanes({'continuous': now}, {})
    assert card.card_badge.text() == 'alive · progress overdue'
    now['heartbeat_age'] = 600
    card.update_lanes({'continuous': now}, {})
    assert card.card_badge.text() == 'heartbeat overdue'
