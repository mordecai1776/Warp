# WARP2/warp2/app/tests/test_waiting_is_not_progress.py
# Pathway   : WARP2 / GUI / current request and measured progress.
# Used by   : pytest.
# Uses      : app/capabilities.py; work/lane_progress.py; ask/waiting.py.
# Description: request context and fresh heartbeats never invent completed work.
# User intention: show live work truthfully, including when progress is unknown.
import json

from warp2.app.capabilities import Capabilities


def test_waiting_context_does_not_fabricate_progress(tmp_path, monkeypatch):
    from warp2.work import lane_progress
    from warp2.ask.waiting import Waiting
    monkeypatch.setattr(lane_progress, 'read', lambda state, lane:
                        {'heartbeat_age': 1, 'pid': 123} if lane == 'card' else {})
    monkeypatch.setattr(Waiting, 'someone', lambda self:
                        {'what': 'fixture image request', 'since': '2026-10-22T00:00:00+00:00'})
    inbox = tmp_path / 'centering_image' / 'inbox'
    inbox.mkdir(parents=True)
    (inbox / 'request.json').write_text(json.dumps({'resume': {'part_state':
        {'round': 7, 'part': 'teach'}}}), encoding='utf-8')
    row = Capabilities(tmp_path, tmp_path).now([], [])['continuous']
    assert 'Round 7 (teach)' in row['progress_text']
    assert 'progress unmeasured' in row['progress_text']
    assert row['entry']['verb'] == 'make_asked_image'
    assert row['heartbeat_age'] == 1
    assert 'progress' not in row
    assert 'progress_age' not in row


def test_actual_progress_keeps_its_measured_counts_and_age(tmp_path, monkeypatch):
    from warp2.work import lane_progress
    progress = {'verb': 'measure_picture_concepts', 'target': 'fixture',
                'done': 3, 'total': 8, 'checks': 4, 'total_checks': 16}
    monkeypatch.setattr(lane_progress, 'read', lambda state, lane:
        {'heartbeat_age': 1, 'pid': 123, 'progress': progress, 'progress_age': 601}
        if lane == 'card' else {})
    row = Capabilities(tmp_path, tmp_path).now([], [])['continuous']
    assert row['progress'] == progress
    assert row['progress_age'] == 601
    assert row['progress_text'] == '3/8 images checked; 4/16 concept checks'
