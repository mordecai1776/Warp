# WARP2/warp2/app/tests/test_one_window.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_one_window.py
#  Used by   : pytest (CHECK_FIXES.bat); runs without pytest too.
#  Uses      : warp2/app/one_window.py.
#  Description:
#    Opening the window again leaves one window: the newest claim wins, an
#    older window sees it has been replaced, a window reloading in place
#    (same process) is not replaced, and a missing or broken claim file
#    never closes a window.
#  User intention (Andrew): "one launcher, one window".
# ============================================================================
from __future__ import annotations

import tempfile
from pathlib import Path

from warp2.app.one_window import OneWindow


def _state() -> Path:
    """Intention: a fresh state folder for each test."""
    return Path(tempfile.mkdtemp())


def test_a_newer_window_replaces_the_older_one():
    """Intention: the second window's claim tells the first one to step aside."""
    state = _state()
    first, second = OneWindow(state, 100), OneWindow(state, 200)
    assert first.claim()
    assert not first.replaced()
    assert second.claim()
    assert first.replaced()
    assert not second.replaced()


def test_reloading_in_place_is_not_replaced():
    """Intention: the same process claiming again (a GUI reload) keeps its window."""
    state = _state()
    window = OneWindow(state, 300)
    window.claim()
    OneWindow(state, 300).claim()
    assert not window.replaced()


def test_no_claim_or_a_broken_claim_never_closes_a_window():
    """Intention: an unreadable claim file is not a reason to close."""
    state = _state()
    window = OneWindow(state, 400)
    assert not window.replaced()
    (state / "control").mkdir(parents=True, exist_ok=True)
    (state / "control" / "window.owner.json").write_text("not json", encoding="utf-8")
    assert not window.replaced()


if __name__ == "__main__":
    for name, test in sorted(globals().items()):
        if name.startswith("test_") and callable(test):
            test()
            print("PASSED", name)
