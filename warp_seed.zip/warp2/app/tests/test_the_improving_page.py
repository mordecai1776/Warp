# WARP2/warp2/app/tests/test_the_improving_page.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_the_improving_page.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/app/pages/improving.py, warp2/app/parts/health_card.py,
#              warp2/progress/gather.py (with PySide6 drawing off screen).
#  Description:
#    The "Is it improving?" page and the health card draw a real reading
#    built from files, draw an empty one without falling over, and show "—"
#    for what nobody measured.
#  User intention (Andrew, 2026-10-16): "lets do that now so I can give
#    feedback"; every part proven before it goes live.
# ============================================================================
from __future__ import annotations

import json
import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")
pytest.importorskip("qfluentwidgets")
pytest.importorskip("pyqtgraph")


class Feed:
    """Intention: the little of the feed the page and card use — its newest reading."""

    def __init__(self, last: dict) -> None:
        """Intention: the reading handed out first."""
        self.last = last


@pytest.fixture(scope="module")
def app():
    """Intention: one Qt application for these tests, dark theme set."""
    from PySide6.QtWidgets import QApplication
    application = QApplication.instance() or QApplication([])
    from warp2.app import theme
    theme.apply()
    return application


def _state(tmp_path):
    """Intention: a state folder with one promoted round, a graded day, a step, a decision point and a run."""
    state = tmp_path / "state"
    for folder in ("training", "work", "decisions", "journals", "control", "lanes"):
        (state / folder).mkdir(parents=True)
    (state / "training" / "round_ledger.jsonl").write_text(
        json.dumps({"event": "ended", "skill": "s", "round": 1, "promotion": "promoted",
                    "checked": {"pass_rate": 0.7, "against": 0.5}, "at": "2026-10-16T00:00:00"}) + "\n")
    (state / "training" / "outputs.jsonl").write_text(
        json.dumps({"e": "graded", "passed": True, "score": 0.8, "at": "2026-10-16T01:00:00"}) + "\n")
    (state / "work" / "side_progress.json").write_text(
        json.dumps({"refine_datasets": {"score": 0.16, "observations": {"count": 5, "mean": 0.19, "variance": 0.05}}}))
    (state / "decisions" / "gate_accepts.jsonl").write_text(
        json.dumps({"event": "asked", "id": "a", "rule": {"accept": 1.0}, "model": {"raw": {"refuse": 1.0}}}) + "\n"
        + json.dumps({"event": "settled", "id": "a", "outcome": "refuse"}) + "\n")
    (state / "journals" / "continuous.jsonl").write_text(
        json.dumps({"verb": "open_session", "ts": "2026-10-16T00:00:00+00:00"}) + "\n"
        + json.dumps({"verb": "make_asked_image", "outcome": "error", "error": "TypeError",
                      "dump": "C:\\x\\late.txt", "ts": "2026-10-16T00:01:00+00:00"}) + "\n")
    (state / "lanes" / "web.log").write_text("[WARP2] Low free RAM (381 MB); waiting\n")
    return state


def test_the_page_draws_a_real_reading_and_says_the_answer(app, tmp_path):
    """Intention: the banner, cards, charts and tables all take a reading gathered from real files."""
    from warp2.app.pages.improving import ImprovingPage
    from warp2.progress.gather import Progress
    reading = {"progress": Progress(tmp_path, _state(tmp_path)).gather()}
    page = ImprovingPage(Feed(reading))
    page.draw(reading)
    assert page.banner.answer.text() == "Yes"
    assert page.training.value.text() == "1 of 1"
    assert page.points.rowCount() == 1 and page.errors.rowCount() == 1
    assert page.errors.item(0, 3).text() == "late.txt"


def test_the_page_and_card_draw_nothing_measured_as_dashes(app):
    """Intention: an empty reading falls over nowhere and fills in no number."""
    from warp2.app.pages.improving import ImprovingPage
    from warp2.app.parts.health_card import HealthCard
    page = ImprovingPage(Feed({}))
    page.draw({})
    assert "first full reading" in page.failed.text()
    page.draw({"progress": {"verdict": {}, "failed": {}}})
    assert page.training.value.text() == "0 of 0" and page.graded.value.text() == "—"
    card = HealthCard()
    card.take({})
    assert card.note.text() == "No health reading yet."


def test_the_health_card_says_low_memory(app, tmp_path):
    """Intention: the runner's last memory line under its floor is said as trouble."""
    from warp2.app.parts.health_card import HealthCard
    from warp2.progress.gather import Progress
    card = HealthCard()
    card.take({"progress": Progress(tmp_path, _state(tmp_path)).gather()})
    assert "Memory is low" in card.note.text() and "runner silent" in card.runner.text()
