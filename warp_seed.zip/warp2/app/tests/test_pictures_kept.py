# WARP2/warp2/app/tests/test_pictures_kept.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_pictures_kept.py
#  Used by   : pytest.
#  Uses      : warp2/ask/media.py (keep_image, kept_home), warp2/ask/visual.py
#              (VisualLearning — whether a picture is approved), PIL.
#  Description:
#    A confirmed picture is moved into the kept set — gone from where it was
#    waiting, one file in one place — and approved and catalogued at its new
#    place; a name already kept is never written over.
#  User intention (Andrew, 2026-09-25): "have the image thing close out a
#    image and move it when I confirm it."
# ============================================================================
from __future__ import annotations

import pytest


def test_a_confirmed_picture_is_moved_into_the_kept_set(tmp_path):
    PIL = pytest.importorskip("PIL.Image")
    from warp2.ask.media import keep_image, kept_home, list_created_images
    from warp2.ask.visual import VisualLearning
    state = tmp_path / "state"
    state.mkdir()
    made = tmp_path / "made"
    made.mkdir()
    first, second = made / "cat.png", tmp_path / "cat.png"
    PIL.new("RGB", (16, 16), "red").save(first)
    PIL.new("RGB", (16, 16), "blue").save(second)
    res = keep_image(tmp_path, state, first)
    kept = kept_home(state) / "cat.png"
    assert not first.exists() and kept.is_file() and res["image_path"] == str(kept.resolve())
    assert VisualLearning(tmp_path, state).approved(kept)
    again = keep_image(tmp_path, state, second)
    assert not second.exists() and again["image_path"] != res["image_path"], "the kept one is never written over"
    assert {r["image_path"] for r in list_created_images(state)} >= {res["image_path"], again["image_path"]}
    print("\n  [OK] confirmed: moved out of where it waited into the kept set, approved there; "
          "a second of the same name kept beside it")
