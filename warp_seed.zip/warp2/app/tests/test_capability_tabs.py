# WARP2/warp2/app/tests/test_capability_tabs.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_capability_tabs.py
#  Used by   : pytest.
#  Uses      : warp2/app/capabilities.py, warp2/app/code_map.py,
#              warp2/app/window.py, warp2/app/pages/{capability,capabilities,
#              structure,home}.py, warp2/app/parts/now_view.py, PySide6,
#              qfluentwidgets (skipped where they are not installed).
#  Description:
#    Every capability is found and gets its own tab, a new kind of work in
#    the record grows a new tab, a capability's tab shows its runs whole,
#    the Now view shows what each lane is doing, the outline lists every
#    capability, and the code structure tab reads a file's header, parts
#    and links.
#  User intention (Andrew, 2026-09-25): tabs on the capabilities "to watch
#    what it dose whit as much info about that thing that we can have it
#    give", "make new tabs when it grows a capability", "the current active
#    thing ... to the right of the window ... a new constant view", "a home
#    outline", "the code structure like was in there before".
# ============================================================================
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from warp2.app.capabilities import RUNNING, Capabilities
from warp2.app.code_map import CodeMap, header_of, paths_named


def test_now_uses_live_progress_and_rejects_previous_process(tmp_path):
    import os
    import time
    from warp2.work.lane_progress import Progress
    folder = tmp_path / 'lanes'
    folder.mkdir()
    beat = folder / 'card.beat'
    beat.write_text(f'{os.getpid()} {time.time()}')
    progress = Progress(tmp_path, 'measure_picture_concepts', 'reference images')
    progress.write(0, 30, 0, 100)
    caps = Capabilities(tmp_path, tmp_path)
    now = caps.now([], [])['continuous']
    assert now['entry']['verb'] == 'measure_picture_concepts'
    assert now['progress_text'] == '0/30 images checked; 0/100 concept checks'
    beat.write_text(f'{os.getpid()+1} {time.time()}')
    assert 'progress' not in caps.now([], [])['continuous']
    beat.write_text(f'{os.getpid()} {time.time()}')
    progress.write(30, 30, 100, 100, status='done')
    assert 'progress' not in caps.now([], [])['continuous']


def _journal(state, lane, rows):
    """Intention: a journal as the warp writes one — appended to, never rewritten."""
    home = state / "journals"
    home.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc).isoformat()
    with (home / f"{lane}.jsonl").open("a", encoding="utf-8") as out:
        out.write("".join(json.dumps({"ts": now, **r}) + "\n" for r in rows))


def test_capabilities_are_found_not_listed(tmp_path):
    state = tmp_path / "state"
    _journal(state, "continuous", [
        {"verb": "keep_outputs", "outcome": "ok", "seconds": 1.2, "target": "state:training_blocks", "value": {"lines": 3}},
        {"verb": "do_work", "outcome": "ok", "target": "work:build:projects/a.py", "work_kind": "build"},
        {"verb": "index_tree", "outcome": "ok", "target": "C:/tree"}])
    caps = Capabilities(Path("."), state)
    entries = caps.entries()
    known = {c["key"]: c for c in caps.all(entries)}
    assert "keep_outputs" in known and "work:build" in known and RUNNING in known
    # Intention (2026-10-02): a phase that has never ended well in the record
    # has no tab — its being in the code is not the warp doing it.
    assert "phase:training" not in known
    assert caps.owner(entries[1], list(known.values())) == "work:build"
    assert caps.owner(entries[2], list(known.values())) == RUNNING, "nothing is left out"
    standing = caps.standing(known["keep_outputs"], caps.runs(known["keep_outputs"], entries, list(known.values())))
    assert standing["runs"] == 1 and standing["outcomes"] == {"ok": 1} and standing["ago"] < 60
    print(f"\n  [OK] {len(known)} capabilities found from the code and the record; build work grew its own")


def test_the_code_map_reads_headers_parts_and_links():
    here = CodeMap(Path("."))
    got = here.read("warp2/app/capabilities.py")
    assert got["header"]["Pathway"].endswith("warp2/app/capabilities.py")
    assert any(p["name"] == "Capabilities.standing" for p in got["parts"])
    assert "warp2/work/side/turns.py" in got["uses"]
    assert "warp2/app/window.py" in got["used_by"]
    assert paths_named("warp2/app/parts/{page,cards}.py") == ["warp2/app/parts/page.py", "warp2/app/parts/cards.py"]
    assert header_of("x = 1\n") == {}
    print(f"\n  [OK] a file's header, {len(got['parts'])} parts, {len(got['uses'])} files it uses, "
          f"{len(got['used_by'])} that say they use it")


@pytest.fixture(scope="module")
def app():
    """Intention: one Qt application, as the other window tests make it."""
    pytest.importorskip("PySide6")
    pytest.importorskip("qfluentwidgets")
    pytest.importorskip("pyqtgraph")
    from PySide6.QtWidgets import QApplication
    application = QApplication.instance() or QApplication([])
    from warp2.app import theme
    theme.apply()
    return application


def _pump(app, seconds: float) -> None:
    """Intention: the window's events run for a while."""
    import time
    end = time.time() + seconds
    while time.time() < end:
        app.processEvents()
        time.sleep(0.02)


def test_the_window_grows_a_tab_for_each_capability_and_shows_what_is_running(app, tmp_path):
    from warp2.app.window import WarpWindow
    state = tmp_path / "state"
    _journal(state, "continuous", [{"verb": "train_eye", "outcome": "ok", "seconds": 340.1,
                                    "target": "component:eye", "value": {"said": "the Eye trained"}}])
    _journal(state, "web", [{"verb": "do_work", "outcome": "ok", "target": "work:research:ab12",
                             "work_kind": "research", "value": {"said": "kept 3 source(s)"}}])
    window = WarpWindow(Path("."), state)
    window.show()
    for _ in range(100):
        _pump(app, 0.1)
        if "work:research" in window.cap_pages and window.now.lanes["web"].key:
            break
    assert "train_eye" in window.cap_pages and "work:research" in window.cap_pages
    assert window.now.lanes["continuous"].key == "train_eye" and "340.1" in window.now.lanes["continuous"].on.text()
    assert window.now.lanes["web"].key == "work:research"
    _journal(state, "continuous", [{"verb": "do_work", "outcome": "refused", "target": "work:connect:x",
                                    "work_kind": "connect"}])
    window._grow({})
    for _ in range(100):
        _pump(app, 0.1)
        if "work:connect" in window.cap_pages:
            break
    assert "work:connect" in window.cap_pages, "a new kind of work grew a new tab"
    window.open_cap("train_eye")
    page = window.cap_pages["train_eye"]
    for _ in range(100):
        _pump(app, 0.1)
        if page.runs.rowCount():
            break
    assert page.runs.rowCount() == 1 and "the Eye trained" in page.detail.toPlainText()
    window.switchTo(window.pages["home"])
    window.pages["home"].outline_read({})
    for _ in range(100):
        _pump(app, 0.1)
        if len(window.pages["home"].tiles.tiles) == len(window.cap_pages):
            break
    assert len(window.pages["home"].tiles.tiles) == len(window.cap_pages)
    structure = window.pages["structure"]
    window.switchTo(structure)
    for _ in range(200):
        _pump(app, 0.1)
        if structure.items:
            break
    structure.show_file("warp2/app/code_map.py")
    for _ in range(200):
        _pump(app, 0.1)
        if structure.parts.rowCount():
            break
    assert structure.parts.rowCount() > 3 and structure.used.rowCount() >= 1
    print(f"\n  [OK] {len(window.cap_pages)} capability tabs; a new kind grew one; the Now view shows both lanes; "
          f"the outline lists them all; the code structure reads a file")
    window.close()
