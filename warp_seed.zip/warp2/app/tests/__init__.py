# WARP2/warp2/app/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/__init__.py
#  Used by   : pytest, to import the tests in this directory as a package.
#  Uses      : nothing.
#  Description:
#    Package marker. Empty on purpose.
#  User intention (Andrew):
#    Modular. Tests sit beside the thing they test.
# ============================================================================
