# WARP2/warp2/app/tests/test_judge_rows.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_judge_rows.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat); runs without pytest too.
#  Uses      : warp2/app/parts/judge_rows.py.
#  Description:
#    The judges panel on the "Is it improving?" page says the disagreement
#    reading as it is: real shares as percents, "—" for what nobody
#    measured, and an empty reading without falling over.
#  User intention (Andrew, 2026-10-18): pairwise disagreement next to the
#    temperatures, measurement only.
# ============================================================================
from __future__ import annotations

from warp2.app.parts.judge_rows import judge_rows, pair_rows, reality_judge_rows, summary_lines

READING = {"answers": 113, "mean_disagreement": 0.3, "mean_off_verdict": 0.25, "c_bound": 0.36,
           "paired": 26, "unpaired": 87, "unpaired_share": 0.77,
           "verdict_off_reality": 0.19, "mean_off_reality": 0.22, "c_bound_reality": 0.31,
           "disagreement_heat": 0.18,
           "judges": [{"model": "huihui-qwen3.5-9b", "n": 112, "off_verdict": 0.36}],
           "reality_judges": [{"model": "huihui-qwen3.5-9b", "paired": 26, "unpaired": 86, "off_reality": 0.23}],
           "pairs": [{"a": "huihui-qwen3.5-9b", "b": "phi4-mini", "n": 107, "disagree": 0.46}]}


def test_a_real_reading_is_said_as_percents():
    """Intention: each number shows as the share it is."""
    lines = dict(summary_lines(READING))
    assert lines["Judged answers read"] == "113"
    assert lines["Two judges vote apart"] == "30%"
    assert lines["C-bound (how the panel hangs together)"] == "36%"
    assert lines["Paired with gate/test reality"] == "26"
    assert lines["Unpaired votes (never met gate/test)"] == "77%"
    assert lines["Verdict against reality"] == "19%"
    assert lines["A judge goes against reality"] == "22%"
    assert lines["C-bound against reality"] == "31%"
    assert lines["Lately"] == "about the same"
    assert judge_rows(READING) == [["huihui-qwen3.5-9b", 112, "36%"]]
    assert reality_judge_rows(READING) == [["huihui-qwen3.5-9b", 26, 86, "23%"]]
    assert pair_rows(READING) == [["huihui-qwen3.5-9b", "phi4-mini", 107, "46%"]]


def test_nothing_measured_is_a_dash_not_zero():
    """Intention: an empty or missing reading draws, with — where nothing was measured."""
    for empty in ({}, None, {"answers": 0, "c_bound": None, "judges": [], "pairs": []}):
        lines = dict(summary_lines(empty))
        assert lines["Two judges vote apart"] == "—"
        assert lines["C-bound (how the panel hangs together)"] == "—"
        assert lines["Unpaired votes (never met gate/test)"] == "—"
        assert lines["Verdict against reality"] == "—"
        assert lines["C-bound against reality"] == "—"
        assert lines["Lately"] == "too little to say"
        assert judge_rows(empty) == [] and reality_judge_rows(empty) == [] and pair_rows(empty) == []


if __name__ == "__main__":
    for name, test in list(globals().items()):
        if name.startswith("test_"):
            test()
            print("ok", name)
