# WARP2/warp2/app/tests/test_one_reading_shared.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_one_reading_shared.py
#  Used by   : pytest.
#  Uses      : warp2/app/feed.py (Feed's snapshot signal); PySide6.
#  Description:
#    Every page handed a reading gets the same object, not its own copy.
#  User intention (Andrew, 2026-10-02): "clean up the gui as well" — the
#    window held thirteen copies of one reading (3.5 GB).
# ============================================================================
from __future__ import annotations

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


def test_every_page_gets_the_same_reading(tmp_path):
    from PySide6.QtWidgets import QApplication
    from warp2.app.feed import Feed
    app = QApplication.instance() or QApplication([])
    feed = Feed(tmp_path, tmp_path / "state")
    got = []
    feed.snapshot.connect(got.append)
    feed.snapshot.connect(got.append)
    reading = {"kg": {"edges": [{"from": "a", "to": "b"}]}}
    feed.snapshot.emit(reading)
    app.processEvents()
    assert len(got) == 2 and got[0] is reading and got[1] is reading
