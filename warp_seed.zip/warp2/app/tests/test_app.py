# WARP2/warp2/app/tests/test_app.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_app.py
#  Used by   : pytest (run_tests.py, RUN_TESTS.bat).
#  Uses      : warp2/app/* (with PySide6 drawing off screen), warp2/store/store.py,
#              warp2/ask/thread.py.
#  Description:
#    The one window proven without a screen: it opens on a real (scratch)
#    workspace, every page draws a reading without falling over, the chat
#    shows the conversation and keeps what he typed, the layouts are the same
#    every time, and the chart history thins without losing its ends.
#  User intention (Andrew): every part proven before it goes live.
# ============================================================================
from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")
pytest.importorskip("qfluentwidgets")
pytest.importorskip("pyqtgraph")


@pytest.fixture(scope="module")
def app():
    """Intention: one Qt application for every test here, dark Fluent theme set."""
    from PySide6.QtWidgets import QApplication
    application = QApplication.instance() or QApplication([])
    from warp2.app import theme
    theme.apply()
    return application


def _pump(app, seconds: float) -> None:
    """Intention: the window's events run for a while, as they would on screen."""
    import time
    end = time.time() + seconds
    while time.time() < end:
        app.processEvents()
        time.sleep(0.02)


def test_every_page_opens_and_draws_a_reading(app, tmp_path):
    """Intention: the window opens on a real workspace and every page draws what the feed read."""
    from pathlib import Path

    from warp2.app.window import WarpWindow
    from warp2.store.store import Store, store_home
    state = tmp_path / "state"
    store = Store(store_home(state), run="app")
    store.assert_fact("warp2/a.py", "has", attr="status", value="built")
    store.assert_fact("warp2/a.py", "depends_on", "warp2/b.py")
    store.close()
    window = WarpWindow(Path("."), state)
    window.show()
    for _ in range(100):
        _pump(app, 0.1)
        if window.feed.last:
            break
    assert window.feed.last, "the feed read the machine"
    for name, page in window.pages.items():
        window.switchTo(page)
        _pump(app, 0.2)
        assert page.isVisible(), name
    window.close()


def test_the_chat_shows_the_conversation(app, tmp_path):
    """Intention: the turns on disk are drawn as bubbles; system side-work is left out."""
    from warp2.app.feed import Feed
    from warp2.app.pages.chat import ChatPage
    from warp2.ask.thread import ANDREW, WARP, Thread
    state = tmp_path / "state"
    thread = Thread(state)
    thread.add(ANDREW, "how is it going?")
    thread.add(WARP, "Webs: 3 use webs")
    thread.add(WARP, "well — nine parts proven")
    page = ChatPage(Feed(tmp_path, state))
    page.show()
    _pump(app, 0.3)
    page.take({})
    bubbles = [page.turns_box.itemAt(i).widget() for i in range(page.turns_box.count() - 1)]
    assert len(bubbles) == 2
    page.close_page()


def test_layouts_are_the_same_every_time():
    """Intention: the same graph is always laid out the same way; a flowchart reads top to bottom."""
    from warp2.app.parts.graph import layered_layout, spring_layout
    names = ["a", "b", "c", "d"]
    edges = [("a", "b"), ("b", "c"), ("c", "a"), ("c", "d")]
    assert spring_layout(names, edges) == spring_layout(names, edges)
    rows = layered_layout(names, edges, loops=[("c", "a")])
    assert rows["a"][1] < rows["b"][1] < rows["c"][1] < rows["d"][1]


def test_chart_history_thins_but_keeps_its_ends():
    """Intention: a long history is thinned in its old half, never cut, so both ends stay."""
    from warp2.app.feed import History
    history = History()
    for i in range(1000):
        history.add("x", i, at=float(i))
    times, values = history.of("x")
    assert values[0] == 0 and values[-1] == 999 and len(values) <= 700


def test_the_side_has_no_eye_panel_and_every_page_still_opens(app, tmp_path, monkeypatch):
    """Intention (BUILD_LOG 1480): "lets get rid of the eye in use now" - the right side carries only what the warp does."""
    from pathlib import Path
    from warp2.app.feed import Feed
    from warp2.app.window import WarpWindow
    monkeypatch.setattr(Feed, "start", lambda self: None)
    window = WarpWindow(Path("."), tmp_path / "state")
    from PySide6.QtCore import Qt
    window.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen)
    window.show()
    try:
        assert not hasattr(window.now, "carry") and not hasattr(window.pages["eye_tree"], "now")
        window.feed.standing.emit({"doing": "Warp working"})
        _pump(app, 0.1)
        assert window.now.doing.text() == "Warp working"
        window.open_cap("work:later")
        window._add_caps([{"key": "work:later", "name": "Later", "kind": "work"}])
        assert window.stackedWidget.currentWidget() is window.cap_pages["work:later"]
        from warp2.app.parts.tiles import HeldTile
        for key in HeldTile.DESTINATIONS.values():
            window.open_page(key)
            assert window.stackedWidget.currentWidget() is window.pages[key]
        _pump(app, 0.6)
        window.grab().save(str(tmp_path / "side.png"))
    finally:
        window.close()


def test_live_feed_updates_while_full_snapshot_is_waiting(app, tmp_path, monkeypatch):
    """Intention: a slow store cannot freeze the active Eye's update signal."""
    from threading import Event
    from warp2.app.feed import Feed
    from warp2.ui.snapshot import ObserverSnapshot
    release = Event()
    monkeypatch.setattr(ObserverSnapshot, "gather", lambda self: (release.wait(10), {})[1])
    feed = Feed(tmp_path, tmp_path / "state")
    monkeypatch.setattr(feed.reader, "_quick", lambda: {"doing": "still working"})
    readings = []
    feed.standing.connect(readings.append)
    feed.start()
    try:
        for _ in range(20):
            _pump(app, 0.1)
            if readings:
                break
        assert readings and readings[0]["doing"] == "still working"
    finally:
        release.set()
        feed.close()
