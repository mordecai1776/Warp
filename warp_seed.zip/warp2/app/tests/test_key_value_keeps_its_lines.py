# WARP3/warp2/app/tests/test_key_value_keeps_its_lines.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/app/tests/test_key_value_keeps_its_lines.py
#  Used by   : pytest; WARP3/CHECK_FIXES.bat.
#  Uses      : warp2/app/parts/cards.py (KeyValue), PySide6, qfluentwidgets.
#  Description:
#    A KeyValue written again and again keeps the lines it has: no new widget
#    is made while the number of pairs stays the same, so nothing waits on
#    Qt's deferred delete. The old KeyValue made and dropped every line on
#    every reading; in the window (busy queue) the drops never ran and it
#    held 85,500 lines and 9.3 GB (BUILD_LOG 2324).
#  User intention (Andrew, 2026-11-26 21:36): memory "adaptive moment to
#    moment"; the window must not grow without end.
# ============================================================================
from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")
pytest.importorskip("qfluentwidgets")


@pytest.fixture(scope="module")
def app():
    """Intention: one offscreen application for the module."""
    from PySide6.QtWidgets import QApplication
    application = QApplication.instance() or QApplication([])
    from warp2.app import theme
    theme.apply()
    return application


def _shown(kv) -> list:
    """Intention: the (name, value) each line of a KeyValue shows now."""
    return [(line.left.text(), line.right.text()) for line in kv.lines]


def test_the_same_number_of_pairs_makes_no_new_widget(app):
    """Intention: written 200 times with no event processing, the count of live widgets does not grow."""
    from warp2.app.parts.cards import KeyValue
    kv = KeyValue()
    kv.set([("a", 1), ("b", 2), ("c", 3)])
    before = len(app.allWidgets())
    for i in range(200):
        kv.set([("a", i), ("b", i + 1), ("c", i + 2)])
    assert len(app.allWidgets()) == before
    assert _shown(kv) == [("a", "199"), ("b", "200"), ("c", "201")]


def test_fewer_and_more_pairs_drop_and_add_lines(app):
    """Intention: fewer pairs let lines go, more pairs add them, and each line shows its own pair."""
    from warp2.app.parts.cards import KeyValue
    kv = KeyValue()
    kv.set([("a", 1), ("b", 2), ("c", 3)])
    kept = kv.lines[0]
    kv.set([("x", "y")])
    assert _shown(kv) == [("x", "y")]
    assert kv.lines[0] is kept
    assert kv.box.count() == 1
    kv.set([("p", 1), ("q", None), ("r", 3.5)])
    assert _shown(kv) == [("p", "1"), ("q", "None"), ("r", "3.5")]
    assert kv.box.count() == 3
    kv.set([])
    assert kv.lines == [] and kv.box.count() == 0


def test_a_dropped_line_leaves_the_style_manager(app):
    """Intention: a let-go line's labels are taken off qfluentwidgets' list, which otherwise keeps them alive."""
    from qfluentwidgets.common.style_sheet import styleSheetManager
    from warp2.app.parts.cards import KeyValue
    kv = KeyValue()
    kv.set([("a", 1), ("b", 2)])
    gone = kv.lines[1]
    assert gone.left in styleSheetManager.widgets
    kv.set([("a", 1)])
    assert gone.left not in styleSheetManager.widgets and gone.right not in styleSheetManager.widgets
