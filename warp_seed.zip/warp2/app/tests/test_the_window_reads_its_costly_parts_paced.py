# WARP2/warp2/app/tests/test_the_window_reads_its_costly_parts_paced.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/app/tests/test_the_window_reads_its_costly_parts_paced.py
#  Used by   : pytest.
#  Uses      : warp2/app/feed.py (Reader._floor_mb), warp2/app/parts/paced.py.
#  Description:
#    The memory floor (it walks every process on the machine) is read again
#    only after its own cost times COST_TIMES; between, the last reading
#    stands.
#  User intention (Andrew, 2026-11-09 09:49): "Yes and let's change the window
#    to work with more plain visuals if needed" - measured that day, the
#    window's busy time was a quarter the floor and a third the lane reads,
#    each read every second. (BUILD_LOG 1479.)
# ============================================================================
from __future__ import annotations

import pytest


def test_the_memory_floor_is_read_paced_by_its_own_cost(monkeypatch, tmp_path):
    """Intention: two quick readings in a row read the floor once; once due again, it is read again."""
    pytest.importorskip("PySide6")
    import warp2.work.memory_gate as gate
    from warp2.app.feed import Reader
    asked = []
    monkeypatch.setattr(gate, "floor_bytes", lambda: asked.append(1) or 512 * 2 ** 20)
    reader = Reader(tmp_path, tmp_path / "state")
    assert reader._floor_mb() == 512 and reader._floor_mb() == 512 and len(asked) == 1
    reader.floor_pace.ended -= 3600
    assert reader._floor_mb() == 512 and len(asked) == 2
