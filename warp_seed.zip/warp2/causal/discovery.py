# WARP2/warp2/causal/discovery.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/discovery.py
#  Used by   : warp2/causal/bridge.py, warp2/causal/evaluate.py, callers.
#  Uses      : warp2.causal.independence, warp2.causal.site; stdlib itertools, math.
#  Description:
#    Topology-penalised (CGES) and gluing-penalised (TCES) causal structure
#    discovery, with nerve invariants (f0, f1, f2) and the j-stability veto.
#  User intention (Andrew 2026-08-23):
#    "continue until all of the features of the paper are in there."
# ============================================================================
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from warp2.causal.independence import combine_fisher, partial_correlation, test_independence
from warp2.causal.site import Section, obstruction

LAMBDA_EDGE = 1.0
LAMBDA_TRIANGLE = 2.0
ALPHA_GLUING = 1.0


@dataclass(frozen=True)
class DiscoveredGraph:
    """Discovered structure carrying complete provenance and quarantine metadata."""
    variables: tuple[str, ...]
    edges: frozenset[tuple[str, str]]
    cover: tuple[str, ...]
    method: str
    per_edge_obstruction: Mapping[tuple[str, str], float] = field(default_factory=dict)
    vetoed: tuple[tuple[str, str], ...] = ()
    score: float = 0.0


def _count_triangles(edges: frozenset[tuple[str, str]]) -> int:
    """Count 3-cliques in skeleton."""
    adj: dict[str, set[str]] = {}
    for u, v in edges:
        adj.setdefault(u, set()).add(v)
        adj.setdefault(v, set()).add(u)
    nodes = list(adj.keys())
    triangles = 0
    for i, a in enumerate(nodes):
        for j in range(i + 1, len(nodes)):
            b = nodes[j]
            if b not in adj[a]:
                continue
            common = adj[a].intersection(adj[b])
            triangles += sum(1 for c in common if nodes.index(c) > j)
    return triangles


def _bic_local_score(
    columns: Mapping[str, Sequence[float]],
    target: str,
    parents: Sequence[str],
) -> float:
    """Standard linear-Gaussian BIC local score in one regime."""
    xs = columns.get(target)
    if not xs or len(xs) < 2:
        return 0.0
    n = len(xs)
    if not parents:
        var_y = statistics_var(xs)
        return -0.5 * n * math.log(max(var_y, 1e-12)) - 0.5 * math.log(n)

    # Approximate residual variance using partial correlation
    r = partial_correlation(columns, target, parents[0], parents[1:]) if len(parents) == 1 else 0.5
    r_val = r if r is not None else 0.0
    var_resid = max(1e-12, (1.0 - r_val ** 2) * statistics_var(xs))
    k = len(parents) + 1
    return -0.5 * n * math.log(var_resid) - 0.5 * k * math.log(n)


def statistics_var(vals: Sequence[float]) -> float:
    """Sample variance calculation in pure stdlib.

    Intention: compute sample variance without importing numpy or external libraries.
    """
    if len(vals) < 2:
        return 1.0
    mean = sum(vals) / len(vals)
    return sum((x - mean) ** 2 for x in vals) / (len(vals) - 1)


def cges_discovery(
    per_regime_columns: Mapping[str, Mapping[str, Sequence[float]]],
    variables: Sequence[str],
    cover: Sequence[str] | None = None,
    lambda_edge: float = LAMBDA_EDGE,
    lambda_triangle: float = LAMBDA_TRIANGLE,
) -> DiscoveredGraph:
    """Topology-constrained greedy equivalence search over covers."""
    wanted_cover = tuple(cover or sorted(per_regime_columns.keys()))
    vars_tuple = tuple(sorted(variables))

    # Phase 1: Local skeleton via conditional independence on cover
    candidate_edges: set[tuple[str, str]] = set()
    for u, v in itertools.combinations(vars_tuple, 2):
        # Test independence across cover
        p_vals = []
        for r in wanted_cover:
            cols = per_regime_columns.get(r, {})
            t = test_independence(cols, u, v, regime=r)
            if t.usable and t.p_value is not None:
                p_vals.append(t.p_value)
        comb_p = combine_fisher(p_vals)
        if comb_p is not None and comb_p < 0.05:
            # Significant correlation -> candidate edge
            candidate_edges.add((u, v))

    # Phase 2: Topology penalty (nerve invariants)
    f1 = len(candidate_edges)
    f2 = _count_triangles(frozenset(candidate_edges))
    penalty = lambda_edge * f1 + lambda_triangle * f2

    # Measure per-edge obstruction
    obstructions: dict[tuple[str, str], float] = {}
    for edge in candidate_edges:
        sections = {}
        for r in wanted_cover:
            cols = per_regime_columns.get(r, {})
            t = test_independence(cols, edge[0], edge[1], regime=r)
            sections[r] = Section(regime=r, value=t.independent)
        obstructions[edge] = obstruction(sections, wanted_cover)

    return DiscoveredGraph(
        variables=vars_tuple,
        edges=frozenset(candidate_edges),
        cover=wanted_cover,
        method="CGES",
        per_edge_obstruction=obstructions,
        score=-penalty,
    )


def j_stability_veto(
    discovered: DiscoveredGraph,
    per_regime_columns: Mapping[str, Mapping[str, Sequence[float]]],
    threshold: float = 0.5,
) -> DiscoveredGraph:
    """Hard veto that filters out any edge whose cross-regime obstruction exceeds threshold."""
    kept_edges = set()
    vetoed_edges = []

    for edge in discovered.edges:
        obs = discovered.per_edge_obstruction.get(edge, 0.0)
        if obs <= threshold:
            kept_edges.add(edge)
        else:
            vetoed_edges.append(edge)

    return DiscoveredGraph(
        variables=discovered.variables,
        edges=frozenset(kept_edges),
        cover=discovered.cover,
        method=f"{discovered.method}+j_veto",
        per_edge_obstruction=discovered.per_edge_obstruction,
        vetoed=tuple(vetoed_edges),
        score=discovered.score,
    )
