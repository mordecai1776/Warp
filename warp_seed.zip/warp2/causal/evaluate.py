# WARP2/warp2/causal/evaluate.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/evaluate.py
#  Used by   : tests, discovery evaluation, benchmark reports.
#  Uses      : warp2.causal.discovery (DiscoveredGraph); stdlib typing.
#  Description:
#    Evaluation metrics for causal structure discovery: Structural Hamming
#    Distance (directed and skeleton), precision/recall, j-stability index,
#    and empirical CI violation counts.
#  User intention (Andrew 2026-08-23):
#    "continue until all of the features of the paper are in there."
# ============================================================================
from __future__ import annotations

from typing import Any, Iterable, Mapping, Sequence

from warp2.causal.discovery import DiscoveredGraph


def _as_edge_set(graph: Any) -> frozenset[tuple[str, str]]:
    """Normalize input graph or edge collection to a canonical set of directed pairs.

    Intention: accept DiscoveredGraph, CausalModel, or raw pairs interchangeably.
    """
    if isinstance(graph, DiscoveredGraph):
        return frozenset((str(u), str(v)) for (u, v) in graph.edges)
    return frozenset((str(u), str(v)) for (u, v) in (graph or ()))


def structural_hamming_distance(truth: Any, estimate: Any) -> dict[str, Any]:
    """Calculate Structural Hamming Distance between ground truth and estimated graphs."""
    t = _as_edge_set(truth)
    e = _as_edge_set(estimate)

    missing = t - e
    extra = e - t

    # Skeletons (undirected edges)
    t_skel = frozenset(tuple(sorted((u, v))) for (u, v) in t)
    e_skel = frozenset(tuple(sorted((u, v))) for (u, v) in e)

    missing_skel = t_skel - e_skel
    extra_skel = e_skel - t_skel
    reversed_edges = frozenset((v, u) for (u, v) in t if (v, u) in e)

    directed_shd = len(missing) + len(extra)
    skeleton_shd = len(missing_skel) + len(extra_skel)

    return {
        "directed": directed_shd,
        "skeleton": skeleton_shd,
        "reversed": len(reversed_edges),
        "missing_count": len(missing),
        "extra_count": len(extra),
    }


def precision_recall(truth: Any, estimate: Any) -> dict[str, float]:
    """Precision, recall, and F1 score for discovered edges."""
    t = _as_edge_set(truth)
    e = _as_edge_set(estimate)

    tp = len(t.intersection(e))
    fp = len(e - t)
    fn = len(t - e)

    prec = tp / (tp + fp) if (tp + fp) > 0 else 1.0
    rec = tp / (tp + fn) if (tp + fn) > 0 else 1.0
    f1 = (2 * prec * rec) / (prec + rec) if (prec + rec) > 0 else 0.0

    return {
        "precision": prec,
        "recall": rec,
        "f1": f1,
        "true_positives": float(tp),
        "false_positives": float(fp),
        "false_negatives": float(fn),
    }


def j_stability_index(discovered: DiscoveredGraph) -> float:
    """Fraction of proposed candidate edges that survived cross-regime j-veto."""
    total_proposed = len(discovered.edges) + len(discovered.vetoed)
    if total_proposed == 0:
        return 1.0
    return float(len(discovered.edges)) / float(total_proposed)
