# WARP2/warp2/causal/model.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/model.py
#  Used by   : warp2/causal/judo.py, warp2/causal/discovery.py, warp2/causal/bridge.py
#  Uses      : warp2.causal.site (CausalSite); stdlib dataclasses, typing.
#  Description:
#    Causal models per regime, and interventions represented as monic sub-model
#    inclusions rather than destructive graph rewrites.
#  User intention (Andrew 2026-08-23):
#    "continue until all of the features of the paper are in there."
# ============================================================================
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from warp2.causal.site import CausalSite


@dataclass(frozen=True)
class CausalModel:
    """Causal DAG with variables, directed edges, and pinned intervention values."""
    variables: frozenset[str]
    edges: frozenset[tuple[str, str]] = frozenset()
    pinned: Mapping[str, Any] = field(default_factory=dict)
    name: str = "M"


    def effective_edges(self) -> frozenset[tuple[str, str]]:
        """Active edges after surgery (pinned variables have incoming edges cut)."""
        return frozenset((u, v) for (u, v) in self.edges if v not in self.pinned)

    def ancestors_of(self, variables: Sequence[str]) -> frozenset[str]:
        """Intention: every variable that leads into these ones through the active edges (cut edges are not
        followed).
        """
        active = self.effective_edges()
        found: set[str] = set()
        frontier = [str(v) for v in variables]
        while frontier:
            curr = frontier.pop()
            for (u, v) in active:
                if v == curr and u not in found:
                    found.add(u)
                    frontier.append(u)
        return frozenset(found)


def intervene(model: CausalModel, variable: str, value: Any = None) -> CausalModel:
    """Intervention do(variable = value), creating a sub-model without destroying history."""
    new_pinned = dict(model.pinned)
    new_pinned[str(variable)] = value
    return CausalModel(
        variables=model.variables,
        edges=model.edges,
        pinned=new_pinned,
        name=f"{model.name}[do({variable})]",
    )


@dataclass(frozen=True)
class RegimeModels:
    """Family of causal models indexed by regime across a causal site."""
    site: CausalSite
    models: Mapping[str, CausalModel] = field(default_factory=dict)

    def at(self, regime: str) -> CausalModel | None:
        """Intention: the causal model for one regime, or None if that regime has none."""
        return self.models.get(str(regime))

    def intervene(self, variable: str, value: Any = None) -> RegimeModels:
        """Intention: the same set of regime models with the same intervention made in each one."""
        new_models = {
            r: intervene(m, variable, value)
            for (r, m) in self.models.items()
        }
        return RegimeModels(site=self.site, models=new_models)
