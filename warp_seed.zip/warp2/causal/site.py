# WARP2/warp2/causal/site.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/site.py
#  Used by   : warp2/causal/model.py, warp2/causal/judo.py, warp2/causal/discovery.py
#  Uses      : stdlib only (dataclasses, typing).
#  Description:
#    The mathematical site of regimes, Grothendieck sieves, and sheaf gluing /
#    obstruction calculation. Provides the foundation for decentralized causal
#    inference where truth is evaluated over covers of regimes.
#  User intention (Andrew 2026-08-23):
#    "We need to build all of those mathical systems built into it" and
#    "continue until all of the features of the paper are in there."
# ============================================================================
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

GLUED = "GLUED"
LOCALLY_TRUE = "LOCALLY_TRUE"
UNGLUED = "UNGLUED"
UNDECIDED = "UNDECIDED"


@dataclass(frozen=True)
class Site:
    """Poset of regimes ordered by refinement / inclusion."""
    regimes: frozenset[str]
    order: frozenset[tuple[str, str]]  # (narrower, wider)
    extents: Mapping[str, frozenset[Any]] = field(default_factory=dict)

    def is_below(self, narrow: str, wide: str) -> bool:
        """True if narrow <= wide in the site poset."""
        if narrow == wide:
            return True
        return (str(narrow), str(wide)) in self.order


@dataclass(frozen=True)
class Sieve:
    """A downward-closed set of regimes below `base`."""
    base: str
    members: frozenset[str]

    def __contains__(self, regime: str) -> bool:
        """Intention: whether a regime is one of this sieve's members."""
        return str(regime) in self.members

    def __len__(self) -> int:
        """Intention: how many regimes this sieve holds."""
        return len(self.members)


@dataclass(frozen=True)
class CausalSite:
    """Site of regimes equipped with extent-based Grothendieck coverage."""
    site: Site

    @property
    def regimes(self) -> frozenset[str]:
        """Intention: the regimes of the site this causal site wraps."""
        return self.site.regimes


    def covers(self, base: str, candidates: Iterable[str]) -> bool:
        """True if candidates cover base (their joint extent contains base's extent)."""
        base_extent = self.site.extents.get(str(base), frozenset())
        if not base_extent:
            return True
        covered: set[Any] = set()
        for c in candidates:
            if self.site.is_below(c, base):
                covered.update(self.site.extents.get(str(c), frozenset()))
        return base_extent.issubset(covered)


@dataclass(frozen=True)
class Section:
    """A local evaluation or distribution in one regime."""
    regime: str
    value: Any
    usable: bool = True
    reason: str = ""


def glue(
    site: CausalSite,
    sections: Mapping[str, Section],
    cover: Sequence[str],
) -> dict[str, Any]:
    """Check whether local sections on a cover agree (glue into a global section)."""
    wanted = [str(r) for r in cover]
    present = [r for r in wanted if r in sections and sections[r].usable]
    if not present:
        return {"status": UNDECIDED, "glued_value": None, "obstruction": 1.0}

    values = [sections[r].value for r in present]
    # Check if all present values match
    all_match = all(v == values[0] for v in values)
    if all_match and site.covers(wanted[0] if wanted else "", present):
        return {"status": GLUED, "glued_value": values[0], "obstruction": 0.0}
    elif all_match:
        return {"status": LOCALLY_TRUE, "glued_value": values[0], "obstruction": 0.5}
    else:
        return {"status": UNGLUED, "glued_value": None, "obstruction": 1.0}


def obstruction(
    sections: Mapping[str, Section],
    cover: Sequence[str],
) -> float:
    """Scalar obstruction (0.0 to 1.0) to gluing across the cover."""
    usable = [sections[r].value for r in cover if r in sections and sections[r].usable]
    if len(usable) <= 1:
        return 0.0
    distinct = len(set(usable))
    return float(distinct - 1) / float(len(usable))
