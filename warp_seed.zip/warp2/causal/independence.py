# WARP2/warp2/causal/independence.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/independence.py
#  Used by   : warp2/causal/discovery.py, warp2/causal/judo.py
#  Uses      : stdlib only (math, statistics, dataclasses, typing).
#  Description:
#    Conditional independence testing per regime with Fisher-z, and closed-form
#    exact Fisher / Tippett combination functions over covers of regimes.
#  User intention (Andrew 2026-08-23):
#    "continue until all of the features of the paper are in there."
# ============================================================================
from __future__ import annotations

import math
import statistics
from dataclasses import dataclass
from typing import Mapping, Sequence

MIN_ROWS_OVER_CONDITIONING = 4


@dataclass(frozen=True)
class CITest:
    """One conditional independence verdict measured inside one regime."""
    x: str
    y: str
    given: tuple
    regime: str
    rows: int
    correlation: float | None
    statistic: float | None
    p_value: float | None
    usable: bool
    reason: str = ""

    @property
    def independent(self) -> bool | None:
        """Intention: whether the test says independent (p above the row-based alpha), or None when it could not
        be used.
        """
        if not self.usable or self.p_value is None:
            return None
        return self.p_value > _alpha_from_rows(self.rows)


def _alpha_from_rows(rows: int) -> float:
    """Adaptive significance threshold based on regime sample size.

    Intention: prevent false rejections under small sample regimes while bounding at 0.05.
    """
    return min(0.05, 1.0 / math.sqrt(max(rows, 4)))


def _normal_sf(z: float) -> float:
    """P(Z > z) for standard normal via math.erfc."""
    return 0.5 * math.erfc(z / math.sqrt(2.0))


def _chi2_even_sf(x: float, half_df: int) -> float:
    """P(X > x) for chi-square on 2*half_df degrees of freedom in closed form."""
    if half_df <= 0:
        return 1.0
    half = x / 2.0
    term = 1.0
    total = 1.0
    for i in range(1, half_df):
        term *= half / i
        total += term
    return min(1.0, math.exp(-half) * total)


def _pearson(xs: Sequence[float], ys: Sequence[float]) -> float | None:
    """Pearson correlation coefficient between two numeric sequences.

    Intention: compute exact Pearson r in pure stdlib without floating blowups.
    """
    n = len(xs)
    if n < 2:
        return None
    mx, my = statistics.fmean(xs), statistics.fmean(ys)
    sxx = sum((v - mx) ** 2 for v in xs)
    syy = sum((v - my) ** 2 for v in ys)
    if sxx <= 1e-18 or syy <= 1e-18:
        return None
    sxy = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
    return max(-1.0, min(1.0, sxy / math.sqrt(sxx * syy)))


def partial_correlation(
    columns: Mapping[str, Sequence[float]],
    x: str,
    y: str,
    given: Sequence[str],
) -> float | None:
    """Recursive partial correlation (stdlib, matrix-free)."""
    xs, ys = columns.get(x), columns.get(y)
    if xs is None or ys is None or len(xs) != len(ys) or len(xs) < 2:
        return None
    rest = [g for g in given if g in columns]
    if not rest:
        return _pearson(xs, ys)
    head, tail = rest[0], rest[1:]
    r_xy = partial_correlation(columns, x, y, tail)
    r_xz = partial_correlation(columns, x, head, tail)
    r_yz = partial_correlation(columns, y, head, tail)
    if r_xy is None or r_xz is None or r_yz is None:
        return None
    denom_sq = (1 - r_xz ** 2) * (1 - r_yz ** 2)
    if denom_sq <= 1e-12:
        return None
    value = (r_xy - r_xz * r_yz) / math.sqrt(max(0.0, denom_sq))
    return max(-1.0, min(1.0, value))


def test_independence(
    columns: Mapping[str, Sequence[float]],
    x: str,
    y: str,
    given: Sequence[str] = (),
    *,
    regime: str = "",
) -> CITest:
    """Fisher-z test of x _||_ y | given within a single regime."""
    conditioning = tuple(given)
    rows = len(columns.get(x) or ())
    base = {
        "x": str(x),
        "y": str(y),
        "given": conditioning,
        "regime": str(regime),
        "rows": rows,
    }

    if rows - len(conditioning) < MIN_ROWS_OVER_CONDITIONING:
        return CITest(
            **base,
            correlation=None,
            statistic=None,
            p_value=None,
            usable=False,
            reason=f"{rows} rows against {len(conditioning)} conditioning variables leaves no power",
        )

    r = partial_correlation(columns, x, y, conditioning)
    if r is None:
        return CITest(
            **base,
            correlation=None,
            statistic=None,
            p_value=None,
            usable=False,
            reason="partial correlation not computable",
        )

    r = max(-0.999999, min(0.999999, r))
    z = 0.5 * math.log((1 + r) / (1 - r))
    statistic = math.sqrt(rows - len(conditioning) - 3) * abs(z)
    p_value = 2.0 * _normal_sf(statistic)
    return CITest(
        **base,
        correlation=r,
        statistic=statistic,
        p_value=min(1.0, p_value),
        usable=True,
        reason="",
    )


def combine_fisher(p_values: Sequence[float]) -> float | None:
    """Exact Fisher's method for combining p-values."""
    usable = [p for p in p_values if p is not None]
    if not usable:
        return None
    statistic = -2.0 * sum(math.log(max(p, 1e-300)) for p in usable)
    return _chi2_even_sf(statistic, len(usable))


def combine_tippett(p_values: Sequence[float]) -> float | None:
    """Tippett's method with Sidak correction."""
    usable = [p for p in p_values if p is not None]
    if not usable:
        return None
    return 1.0 - (1.0 - min(usable)) ** len(usable)


@dataclass(frozen=True)
class CoverVerdict:
    """Independence verdict evaluated across an entire cover of regimes."""
    x: str
    y: str
    given: tuple
    per_regime: Mapping[str, CITest]
    combined_p: float | None
    method: str
    independent_everywhere: bool
    dependent_somewhere: tuple
    unusable: tuple


def independence_on_cover(
    per_regime_columns: Mapping[str, Mapping[str, Sequence[float]]],
    x: str,
    y: str,
    given: Sequence[str] = (),
    *,
    cover: Sequence[str] | None = None,
    method: str = "fisher",
) -> CoverVerdict:
    """Test x _||_ y | given per regime and combine across the cover."""
    wanted = tuple(str(r) for r in (cover if cover is not None else sorted(per_regime_columns)))
    results: dict[str, CITest] = {}
    dependent = []
    unusable = []

    for regime in wanted:
        columns = per_regime_columns.get(regime)
        if not columns:
            unusable.append(regime)
            results[regime] = CITest(
                x=str(x),
                y=str(y),
                given=tuple(given),
                regime=regime,
                rows=0,
                correlation=None,
                statistic=None,
                p_value=None,
                usable=False,
                reason="no data for regime",
            )
            continue

        outcome = test_independence(columns, x, y, given, regime=regime)
        results[regime] = outcome
        if not outcome.usable:
            unusable.append(regime)
        elif outcome.independent is False:
            dependent.append(regime)

    p_vals = [r.p_value for r in results.values() if r.usable and r.p_value is not None]
    combined = combine_tippett(p_vals) if method == "tippett" else combine_fisher(p_vals)

    return CoverVerdict(
        x=str(x),
        y=str(y),
        given=tuple(given),
        per_regime=results,
        combined_p=combined,
        method=str(method),
        independent_everywhere=not dependent,
        dependent_somewhere=tuple(dependent),
        unusable=tuple(unusable),
    )
