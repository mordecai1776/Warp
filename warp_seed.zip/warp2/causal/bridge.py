# WARP2/warp2/causal/bridge.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/bridge.py
#  Used by   : warp2/run.py (causal commands), warp2/store/store.py, callers.
#  Uses      : warp2.causal.discovery (DiscoveredGraph), warp2.causal.model; stdlib.
#  Description:
#    The quarantine bridge between causal structure discovery and the WARP2 store.
#    Turns discovered graphs into quarantined hypothesis records with evidence
#    metadata — never directly stating statistical discoveries as proven facts.
#  User intention (Andrew 2026-08-23):
#    "I want to have it more tuned to use the kg as the main part and the models
#    being just what runs it."
# ============================================================================
from __future__ import annotations

from typing import Any, Mapping, Sequence

from warp2.causal.discovery import DiscoveredGraph
from warp2.causal.model import CausalModel, RegimeModels
from warp2.causal.site import CausalSite, Site
from warp2.util import now_iso


def build_quarantined_payload(discovered: DiscoveredGraph) -> dict[str, Any]:
    """Package a discovered structure into a quarantined hypothesis document."""
    edges_list = [
        {
            "from": u,
            "to": v,
            "obstruction": discovered.per_edge_obstruction.get((u, v), 0.0),
        }
        for (u, v) in sorted(discovered.edges)
    ]
    vetoed_list = [
        {"from": u, "to": v}
        for (u, v) in sorted(discovered.vetoed)
    ]

    return {
        "kind": "causal_hypothesis",
        "status": "QUARANTINED_STATISTICAL_HYPOTHESIS",
        "method": discovered.method,
        "cover": list(discovered.cover),
        "variables": list(discovered.variables),
        "edges_count": len(edges_list),
        "vetoed_count": len(vetoed_list),
        "edges": edges_list,
        "vetoed": vetoed_list,
        "generated_at": now_iso(),
        "quarantine_note": (
            "Statistical discovery only. Must not be stated as ground-truth "
            "causality without explicit verification."
        ),
    }


def site_from_regimes(
    regimes: Sequence[str],
    hierarchy: Sequence[tuple[str, str]] = (),
) -> CausalSite:
    """Construct a CausalSite from a list of regime identifiers and ordering pairs."""
    reg_set = frozenset(str(r) for r in regimes)
    ord_set = frozenset((str(u), str(v)) for (u, v) in hierarchy)
    site = Site(regimes=reg_set, order=ord_set)
    return CausalSite(site=site)
