# WARP2/warp2/causal/tests/test_causal.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/tests/test_causal.py
#  Used by   : pytest
#  Uses      : warp2.causal.*
#  Description:
#    Verification suite for decentralized causal inference, Fisher-z independence,
#    j-do-calculus, structure discovery (CGES + TCES + veto), and evaluation metrics.
#  User intention:
#    Prove all mathematical causal theorems, stdlib calculations, and quarantine rules.
# ============================================================================
from __future__ import annotations

from warp2.causal import (
    Aggregator,
    CausalModel,
    RegimeModels,
    build_quarantined_payload,
    cges_discovery,
    combine_fisher,
    combine_tippett,
    independence_on_cover,
    intervene,
    j_stability_index,
    j_stability_veto,
    partial_correlation,
    precision_recall,
    rule_1_observation,
    rule_2_action_observation,
    rule_3_action_deletion,
    site_from_regimes,
    structural_hamming_distance,
)
from warp2.causal.independence import test_independence as run_ci_test


def test_independence_and_combining():
    # Linear model: X -> Y -> Z with realistic variation
    xs = [float(i) for i in range(100)]
    ys = [2.0 * x + 5.0 * ((i * 3) % 7) for i, x in enumerate(xs)]
    zs = [3.0 * y + 5.0 * ((i * 5) % 9) for i, y in enumerate(ys)]
    cols = {"X": xs, "Y": ys, "Z": zs}

    # Marginal correlation X and Z is high
    t_xz = run_ci_test(cols, "X", "Z", regime="r1")
    assert t_xz.usable is True
    assert t_xz.independent is False

    # Partial correlation X and Z given Y is near zero (d-separated by Y)
    t_xz_given_y = run_ci_test(cols, "X", "Z", given=("Y",), regime="r1")
    assert t_xz_given_y.usable is True
    assert t_xz_given_y.independent is True

    # P-value combination
    p_vals = [0.01, 0.02, 0.04]
    p_comb = combine_fisher(p_vals)
    assert p_comb is not None and p_comb < 0.01

    p_tip = combine_tippett(p_vals)
    assert p_tip is not None and p_tip < 0.05


def test_causal_model_and_interventions():
    edges = frozenset([("X", "Y"), ("Y", "Z"), ("W", "Y")])
    model = CausalModel(variables=frozenset(["X", "Y", "Z", "W"]), edges=edges)

    assert model.ancestors_of(["Z"]) == frozenset(["X", "Y", "W"])

    # Intervene on Y: cut incoming edges
    model_do_y = intervene(model, "Y", 5.0)
    assert model_do_y.pinned["Y"] == 5.0
    assert model_do_y.ancestors_of(["Z"]) == frozenset(["Y"])  # X and W no longer ancestors of Z


def test_judo_calculus_rules():
    # Graph: X -> Y -> Z
    edges = frozenset([("X", "Y"), ("Y", "Z")])
    model = CausalModel(variables=frozenset(["X", "Y", "Z"]), edges=edges)

    site = site_from_regimes(["r1", "r2"])
    regime_models = RegimeModels(site=site, models={"r1": model, "r2": model})

    # Rule 1: P(z | do(x), y) = P(z | y) because Z _||_ X | Y in G_{\bar{X}}
    v1 = rule_1_observation(regime_models, y="Z", z="X", x="", w=("Y",))
    assert v1.holds is True
    assert len(v1.certified_on) == 2

    # Aggregator monotonicity
    agg = Aggregator()
    v_low = {"r1": 1.0, "r2": 2.0}
    v_high = {"r1": 1.5, "r2": 2.5}
    assert agg.mean(v_low) < agg.mean(v_high)


def test_cges_discovery_and_veto():
    # Synthetic data for 3 regimes
    data = {}
    for r in ["r1", "r2", "r3"]:
        xs = [float(i) for i in range(50)]
        ys = [1.5 * x + (0.5 * (i % 7)) for i, x in enumerate(xs)]
        zs = [float((i * 11) % 5) for i in range(50)]  # independent Z
        data[r] = {"A": xs, "B": ys, "C": zs}

    discovered = cges_discovery(data, variables=["A", "B", "C"])
    assert ("A", "B") in discovered.edges or ("B", "A") in discovered.edges
    assert ("A", "C") not in discovered.edges

    # Veto check
    vetoed_graph = j_stability_veto(discovered, data, threshold=0.1)
    assert j_stability_index(vetoed_graph) <= 1.0


def test_evaluate_and_quarantine():
    truth = frozenset([("A", "B"), ("B", "C")])
    estimate = frozenset([("A", "B"), ("C", "B")])  # one match, one reversed

    shd = structural_hamming_distance(truth, estimate)
    assert shd["directed"] == 2
    assert shd["reversed"] == 1
    assert shd["skeleton"] == 0  # skeletons identical

    pr = precision_recall(truth, estimate)
    assert pr["precision"] == 0.5
    assert pr["recall"] == 0.5

    # Bridge payload
    from warp2.causal.discovery import DiscoveredGraph
    d_graph = DiscoveredGraph(
        variables=("A", "B", "C"),
        edges=frozenset([("A", "B")]),
        cover=("r1", "r2"),
        method="CGES",
    )
    payload = build_quarantined_payload(d_graph)
    assert payload["status"] == "QUARANTINED_STATISTICAL_HYPOTHESIS"
    assert len(payload["edges"]) == 1
