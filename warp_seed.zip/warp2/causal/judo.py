# WARP2/warp2/causal/judo.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/judo.py
#  Used by   : warp2/causal/__init__.py, warp2/causal/bridge.py, callers.
#  Uses      : warp2.causal.model, warp2.causal.site, warp2.causal.independence.
#  Description:
#    j-do-calculus: Pearl's three rules certified on covers of regimes rather
#    than against a single global DAG, with monotone interventional aggregation.
#  User intention (Andrew 2026-08-23):
#    "continue until all of the features of the paper are in there."
# ============================================================================
from __future__ import annotations

import statistics
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from warp2.causal.model import CausalModel, RegimeModels, intervene


@dataclass(frozen=True)
class JudoVerdict:
    """Verdict for a do-calculus rule evaluated on a cover."""
    rule: str
    holds: bool
    certified_on: tuple[str, ...]
    failed_on: tuple[str, ...]
    unmeasured: tuple[str, ...]
    detail: str = ""


def _d_separated(model: CausalModel, x: str, y: str, given: Sequence[str]) -> bool:
    """Check d-separation between x and y given conditioning set in a single model."""
    conditioned = {str(g) for g in given}
    ancestors_of_cond = model.ancestors_of(conditioned)
    active = model.effective_edges()
    adj: dict[str, list[tuple[str, str]]] = {v: [] for v in model.variables}
    for u, v in active:
        adj.setdefault(u, []).append((v, "out"))
        adj.setdefault(v, []).append((u, "in"))

    # Bayes-ball traversal from x to y
    visited: set[tuple[str, str]] = set()  # (node, direction)
    queue: list[tuple[str, str]] = [(str(x), "from_child"), (str(x), "from_parent")]

    while queue:
        node, direction = queue.pop(0)
        if (node, direction) in visited:
            continue
        visited.add((node, direction))

        if node == str(y) and node != str(x):
            return False  # Path is active -> not d-separated

        is_cond = node in conditioned
        is_cond_anc = node in ancestors_of_cond

        if direction == "from_child":
            if not is_cond:
                # Transmit to parents and children
                for neighbor, edge_dir in adj.get(node, []):
                    if edge_dir == "in":
                        queue.append((neighbor, "from_child"))
                    elif edge_dir == "out":
                        queue.append((neighbor, "from_parent"))
        elif direction == "from_parent":
            if not is_cond:
                # Transmit to children
                for neighbor, edge_dir in adj.get(node, []):
                    if edge_dir == "out":
                        queue.append((neighbor, "from_parent"))
            if is_cond_anc:
                # Collider activates and transmits to parents
                for neighbor, edge_dir in adj.get(node, []):
                    if edge_dir == "in":
                        queue.append((neighbor, "from_child"))

    return True


def rule_1_observation(
    regime_models: RegimeModels,
    y: str,
    z: str,
    x: str = "",
    w: Sequence[str] = (),
    cover: Sequence[str] | None = None,
) -> JudoVerdict:
    r"""Rule 1: P(y | do(x), z, w) = P(y | do(x), w) if (Y _||_ Z | X, W) in G_{\bar{X}}."""
    wanted = tuple(cover or sorted(regime_models.models.keys()))
    certified, failed, unmeasured = [], [], []

    conditioning = [x] + list(w) if x else list(w)
    for r in wanted:
        m = regime_models.at(r)
        if m is None:
            unmeasured.append(r)
            continue
        # Graph G_{\bar{X}} is formed by intervening on X (cutting incoming edges to X)
        m_x = intervene(m, x) if x else m
        if _d_separated(m_x, y, z, conditioning):
            certified.append(r)
        else:
            failed.append(r)

    holds = len(certified) == len(wanted) and not unmeasured
    return JudoVerdict(
        rule="rule_1_observation",
        holds=holds,
        certified_on=tuple(certified),
        failed_on=tuple(failed),
        unmeasured=tuple(unmeasured),
        detail=f"Certified on {len(certified)}/{len(wanted)} regimes",
    )


def rule_2_action_observation(
    regime_models: RegimeModels,
    y: str,
    z: str,
    x: str = "",
    w: Sequence[str] = (),
    cover: Sequence[str] | None = None,
) -> JudoVerdict:
    r"""Rule 2: P(y | do(x), do(z), w) = P(y | do(x), z, w) if (Y _||_ Z | X, W) in G_{\bar{X}\underline{Z}}."""
    wanted = tuple(cover or sorted(regime_models.models.keys()))
    certified, failed, unmeasured = [], [], []

    conditioning = [x] + list(w) if x else list(w)
    for r in wanted:
        m = regime_models.at(r)
        if m is None:
            unmeasured.append(r)
            continue
        # G_{\bar{X}\underline{Z}}: cut incoming to X, cut outgoing from Z
        m_x = intervene(m, x) if x else m
        # Cut outgoing from Z:
        filtered_edges = frozenset((u, v) for (u, v) in m_x.edges if u != str(z))
        m_mod = CausalModel(variables=m_x.variables, edges=filtered_edges, pinned=m_x.pinned)
        if _d_separated(m_mod, y, z, conditioning):
            certified.append(r)
        else:
            failed.append(r)

    holds = len(certified) == len(wanted) and not unmeasured
    return JudoVerdict(
        rule="rule_2_action_observation",
        holds=holds,
        certified_on=tuple(certified),
        failed_on=tuple(failed),
        unmeasured=tuple(unmeasured),
        detail=f"Certified on {len(certified)}/{len(wanted)} regimes",
    )


def rule_3_action_deletion(
    regime_models: RegimeModels,
    y: str,
    z: str,
    x: str = "",
    w: Sequence[str] = (),
    cover: Sequence[str] | None = None,
) -> JudoVerdict:
    r"""Rule 3: P(y | do(x), do(z), w) = P(y | do(x), w) if (Y _||_ Z | X, W) in G_{\bar{X},\bar{Z(W)}}."""
    wanted = tuple(cover or sorted(regime_models.models.keys()))
    certified, failed, unmeasured = [], [], []

    conditioning = [x] + list(w) if x else list(w)
    for r in wanted:
        m = regime_models.at(r)
        if m is None:
            unmeasured.append(r)
            continue
        # Cut incoming to X and incoming to Z
        m_x = intervene(m, x) if x else m
        m_xz = intervene(m_x, z)
        if _d_separated(m_xz, y, z, conditioning):
            certified.append(r)
        else:
            failed.append(r)

    holds = len(certified) == len(wanted) and not unmeasured
    return JudoVerdict(
        rule="rule_3_action_deletion",
        holds=holds,
        certified_on=tuple(certified),
        failed_on=tuple(failed),
        unmeasured=tuple(unmeasured),
        detail=f"Certified on {len(certified)}/{len(wanted)} regimes",
    )


class Aggregator:
    """Monotone combining functions for per-regime interventional quantities."""

    @staticmethod
    def mean(values: Mapping[str, float]) -> float | None:
        """Intention: plain average of the regime values, skipping missing ones; None if none are left."""
        vals = [float(v) for v in values.values() if v is not None]
        return statistics.fmean(vals) if vals else None

    @staticmethod
    def weighted(values: Mapping[str, float], weights: Mapping[str, float]) -> float | None:
        """Intention: weighted average of the regime values (weight 1 if not given), skipping missing; None if
        none or zero weight.
        """
        usable = [(values[r], weights.get(r, 1.0)) for r in values if values[r] is not None]
        if not usable:
            return None
        total_w = sum(w for _, w in usable)
        if total_w <= 0:
            return None
        return sum(v * w for v, w in usable) / total_w

