# WARP2/warp2/causal/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/causal/__init__.py
#  Used by   : any module performing causal discovery or do-calculus reasoning.
#  Uses      : warp2.causal.*
#  Description:
#    Package entrypoint for decentralized causal inference and discovery.
#  User intention:
#    Make the causal presheaf machinery cleanly importable as a modular package.
# ============================================================================
from __future__ import annotations

from warp2.causal.bridge import build_quarantined_payload, site_from_regimes
from warp2.causal.discovery import (
    DiscoveredGraph,
    cges_discovery,
    j_stability_veto,
)
from warp2.causal.evaluate import (
    j_stability_index,
    precision_recall,
    structural_hamming_distance,
)
from warp2.causal.independence import (
    CITest,
    CoverVerdict,
    combine_fisher,
    combine_tippett,
    independence_on_cover,
    partial_correlation,
    test_independence,
)
from warp2.causal.judo import (
    Aggregator,
    JudoVerdict,
    rule_1_observation,
    rule_2_action_observation,
    rule_3_action_deletion,
)
from warp2.causal.model import CausalModel, RegimeModels, intervene
from warp2.causal.site import CausalSite, Section, Sieve, Site, glue, obstruction

__all__ = [
    "Aggregator",
    "CITest",
    "CausalModel",
    "CausalSite",
    "CoverVerdict",
    "DiscoveredGraph",
    "JudoVerdict",
    "RegimeModels",
    "Section",
    "Sieve",
    "Site",
    "build_quarantined_payload",
    "cges_discovery",
    "combine_fisher",
    "combine_tippett",
    "glue",
    "independence_on_cover",
    "intervene",
    "j_stability_index",
    "j_stability_veto",
    "obstruction",
    "partial_correlation",
    "precision_recall",
    "rule_1_observation",
    "rule_2_action_observation",
    "rule_3_action_deletion",
    "site_from_regimes",
    "structural_hamming_distance",
    "test_independence",
]
