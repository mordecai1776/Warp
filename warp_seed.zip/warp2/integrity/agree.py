# WARP2/warp2/integrity/agree.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/agree.py
#  Used by   : warp2/work/loop.py (a judgement is recorded through it),
#              warp2/run.py (`agree`).
#  Uses      : warp2/store/store.py, warp2/util.py, warp2/settings.py.
#  Description:
#    Judgements about the same bytes, kept together: who said it, what they
#    judged, how far apart they are, and the refusal when one judge changes its
#    answer about evidence that did not change.
#  User intention (Andrew):
#    Every judgement must be attributable and no single opinion settles
#    anything.
#  THE NUMBER THIS FILE EXISTS FOR. WARP's scoring subsystem recorded 115
#    scores over 34 subjects that more than one scorer looked at — every scorer
#    seeing the IDENTICAL bytes, confirmed by a matching fingerprint on every
#    row. The confidence spread across those scorers had a **median of 815 out
#    of 1000**, a mean of 564, and was 500 or more on 20 of the 34. Two judges
#    on the same bytes, typically 815 points apart. WARP had 506 lines of
#    refutation and 216 of conformance, and `refute` appears **0 times** in
#    52,412 recorded events: the disagreement sat in a SQLite file, complete
#    and unread, for the whole life of the tree.
# ============================================================================
from __future__ import annotations

from warp2.settings import number
from warp2.util import now_iso, sha256_hex

JUDGEMENT = "judgement:"

# How far apart two readings of the same bytes may be before the judges are
# said not to agree. WARP's median was 815; anything near that is not a
# difference of opinion, it is at least one judge measuring something other
# than what it claims to.
FAR_APART = number("WARP2_AGREE_FAR_APART", 300, minimum=1)

# How many judgements one thing needs before the spread means anything. Two is
# the fewest that can disagree; the report says how many it rests on either way.
ENOUGH_JUDGES = number("WARP2_AGREE_ENOUGH_JUDGES", 2, minimum=2)

# How many readings a judge needs before its distance from the others is a
# fact about the judge rather than about one hard subject.
ENOUGH_READINGS = number("WARP2_AGREE_ENOUGH_READINGS", 3, minimum=1)


class Disputed(Exception):
    """The same judge, the same bytes, a different answer.

    Intention: WARP's `ScoreConflict`, which was defined and **never once
    raised**. The digest pins what was judged, so a second and different score
    on the same bytes from the same judge is either a correction that has to be
    recorded as one, or a defect. Silently taking the newer number is how a
    scoreboard becomes whatever was written last.
    """


class Agreement:
    """What was judged, by whom, and how far apart they are."""

    def __init__(self, store) -> None:
        """Intention: keep the store the judgements are read from."""
        self.store = store

    # -- recording one --------------------------------------------------------

    def judged(self, about: str, by: str, score: int, saw: bytes | str = b"",
               why: str = "", correcting: str = "") -> dict:
        """One judge's reading of one thing, signed and pinned to what it saw.

        Intention: A VERDICT NEEDS A SIGNER AND A SUBJECT. Without the signer a
        score cannot be argued with, weighted by past accuracy, or caught
        rewriting itself; without the digest of what was actually read, two
        scores about different versions look like disagreement and two about
        the same version look like independent confirmation.
        """
        raw = saw if isinstance(saw, bytes) else str(saw).encode("utf-8")
        digest = sha256_hex(raw) if raw else ""
        name = f"{JUDGEMENT}{by}:{digest[:16] or 'nothing'}:{about}"
        said = int(max(1, min(1000, int(score))))

        before = self._int(name, "score")
        if before and before != said and not correcting:
            raise Disputed(
                f"{by} already scored {about} at {before} on these exact bytes "
                f"and now says {said}. Nothing about the evidence changed, so "
                f"say what changed your mind — pass `correcting`.")

        self.store.assert_fact(name, "has", attr="kind", value="judgement")
        self.store.assert_fact(name, "has", attr="about", value=str(about))
        self.store.assert_fact(name, "has", attr="by", value=str(by))
        self.store.assert_fact(name, "has", attr="saw", value=digest)
        self.store.assert_fact(name, "has", attr="score", value=str(said))
        self.store.assert_fact(name, "has", attr="at", value=now_iso())
        if why:
            self.store.assert_fact(name, "has", attr="why", value=why[:500])
        if correcting:
            # Intention: a change of mind is KEPT, with its reason, rather than
            # overwriting. The store is temporal, so both readings and the
            # reason for the second are all still there to be read.
            self.store.assert_fact(name, "has", attr="corrected_because",
                                   value=correcting[:500])
        self.store.assert_fact(name, "derives", str(about))
        return {"judgement": name, "about": about, "by": by, "score": said,
                "saw": digest}

    # -- reading them together -----------------------------------------------

    def on(self, about: str) -> list:
        """Every judgement of one thing, newest reading per judge."""
        found = {}
        for fact in self.store.current(attr="about"):
            if str(fact["value"]) != str(about):
                continue
            name = fact["subject"]
            if not name.startswith(JUDGEMENT):
                continue
            found[(self._text(name, "by"), self._text(name, "saw"))] = {
                "judgement": name, "by": self._text(name, "by"),
                "saw": self._text(name, "saw"),
                "score": self._int(name, "score"),
                "why": self._text(name, "why"),
                "corrected": bool(self._text(name, "corrected_because"))}
        return sorted(found.values(), key=lambda one: (-one["score"], one["by"]))

    def spread(self, about: str) -> dict:
        """How far apart the judges are, on the bytes they actually shared.

        Intention: THE MEASUREMENT WARP HAD AND NEVER MADE. Judgements are
        grouped by what was SEEN, because two readings of different versions
        are not a disagreement — WARP's rows all shared a fingerprint, which is
        what made its 815-point median a real finding rather than an artefact.
        """
        by_bytes: dict[str, list] = {}
        for one in self.on(about):
            by_bytes.setdefault(one["saw"], []).append(one)
        best = max(by_bytes.values(), key=len) if by_bytes else []
        scores = [one["score"] for one in best]
        if len(scores) < int(ENOUGH_JUDGES):
            return {
                "about": about, "judges": len(scores), "spread": 0,
                "agree": None, "scores": scores,
                # Intention: A LONE JUDGEMENT IS NOT A VERDICT, and the report
                # says it in words rather than returning a comfortable number.
                # WARP's production median says a second judge would typically
                # land 815 points away.
                "says": (f"only one judge has looked at {about} — that is a "
                         f"reading, not a verdict" if scores else
                         f"nothing has judged {about}"),
            }
        gap = max(scores) - min(scores)
        agree = gap < int(FAR_APART)
        return {
            "about": about, "judges": len(scores), "spread": gap,
            "scores": scores, "agree": agree,
            "middle": sorted(scores)[len(scores) // 2],
            "says": (f"{len(scores)} judges within {gap} of each other"
                     if agree else
                     f"{len(scores)} judges {gap} APART out of 1000 on the same "
                     f"bytes — at least one is not measuring what it claims to"),
        }

    def judges(self) -> list:
        """Each judge, and how far its readings sit from everyone else's.

        Intention: DISAGREEMENT IS A FACT ABOUT THE JUDGE, not only about the
        work. Two scorers 815 apart are not both slightly wrong, and which one
        is drifting is answerable from the record they both wrote.
        """
        gaps: dict[str, list] = {}
        for about in self._subjects():
            found = self.spread(about)
            if found["judges"] < int(ENOUGH_JUDGES):
                continue
            middle = found["middle"]
            for one in self.on(about):
                if one["score"] in found["scores"]:
                    gaps.setdefault(one["by"], []).append(abs(one["score"] - middle))
        rows = []
        for who, distances in gaps.items():
            average = int(round(sum(distances) / len(distances)))
            rows.append({"judge": who, "readings": len(distances),
                         "usually_off_by": average,
                         "an_outlier": (len(distances) >= int(ENOUGH_READINGS)
                                        and average >= int(FAR_APART))})
        rows.sort(key=lambda one: -one["usually_off_by"])
        return rows

    def report(self) -> dict:
        """Whether the judges agree — and how much has been judged at all.

        Intention: COVERAGE TRAVELS WITH THE MEASUREMENT. WARP registered
        84,899 subjects for scoring and scored 39 — 0.046% — and the subsystem
        read as working. A measurement covering almost nothing has to say so in
        the same breath as its result.
        """
        subjects = self._subjects()
        looked = [self.spread(about) for about in subjects]
        together = [one for one in looked if one["judges"] >= int(ENOUGH_JUDGES)]
        apart = [one for one in together if one["agree"] is False]
        alone = [one["about"] for one in looked if one["judges"] == 1]
        return {
            "judged": len(subjects), "with_more_than_one": len(together),
            "disagreeing": len(apart), "alone": alone,
            "worst": sorted(together, key=lambda one: -one["spread"])[:5],
            "judges": self.judges(),
            "middle_spread": (sorted(one["spread"] for one in together)[len(together) // 2]
                              if together else 0),
            "says": ("nothing has been judged yet" if not subjects else
                     f"{len(subjects)} thing(s) judged, {len(together)} by more "
                     f"than one judge, {len(apart)} of those in disagreement"
                     + (f"; {len(alone)} rest on a single opinion" if alone else "")),
        }

    # -- the small parts -----------------------------------------------------

    def _subjects(self) -> list:
        """Intention: every subject some judgement is about, sorted, so each can be checked for agreement."""
        found = set()
        for fact in self.store.current(attr="about"):
            if str(fact["subject"]).startswith(JUDGEMENT):
                found.add(str(fact["value"]))
        return sorted(found)

    def _text(self, subject: str, attr: str) -> str:
        """Intention: the latest current value of one attribute of a subject as text, or empty if there is none."""
        got = self.store.current(subject=subject, attr=attr)
        return str(got[-1]["value"]) if got else ""

    def _int(self, subject: str, attr: str) -> int:
        """Intention: the same value read as a whole number; anything that is not a number counts as 0."""
        try:
            return int(self._text(subject, attr))
        except ValueError:
            return 0
