# WARP2/warp2/integrity/runtime_audit.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/runtime_audit.py
#  Used by   : warp2/overview.py
#  Uses      : the standard library only
#  Description:
#    Evidence-only audit of KG claims against the live WARP2 runtime.
#  User intention:
#    Not written down in this file yet; noted to ask Andrew (2026-09-18).
# ============================================================================
"""Evidence-only audit of KG claims against the live WARP2 runtime."""
from __future__ import annotations

import ast
import json
from pathlib import Path


# Intention: for every WARP2 file, what the record can show about it —
# indexed, proven, tested, or only on disk. Evidence only: nothing here
# changes the store. Read by the overview the cockpit draws.
def audit(root: Path, machine) -> dict:
    rows = []
    for path in sorted(Path(root).joinpath("warp2").rglob("*.py")):
        if "__pycache__" in path.parts or "tests" in path.parts:
            continue
        rel = path.relative_to(root).as_posix()
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
            symbols = sorted({node.name for node in ast.walk(tree)
                              if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))})
            parsed = True
        except SyntaxError:
            symbols, parsed = [], False
        indexed = bool(machine.store.current(subject=rel, attr="content_digest"))
        proofs = machine.store.current(subject=rel, attr="verified_by")
        work = machine.store.current(relation="derives", obj=rel)
        stem = path.stem
        tests = sorted(str(test.relative_to(root).as_posix()) for test in
                       path.parent.rglob(f"test_{stem}.py"))
        if not tests:
            tests = sorted(str(test.relative_to(root).as_posix()) for test in
                           root.joinpath("warp2").rglob(f"test_{stem}.py"))
        rows.append({"path": rel, "parsed": parsed, "symbols": symbols,
                     "kg_indexed": indexed, "proof_count": len(proofs),
                     "work_references": len(work), "test_candidates": tests,
                     "status": ("proven" if proofs else
                                "test_candidate" if tests else
                                "indexed" if indexed else
                                "source_only" if parsed else "syntax_error")})
    statuses = ("proven", "test_candidate", "indexed", "source_only", "syntax_error")
    return {"schema": "warp2.runtime_audit.v1", "rows": rows,
            "summary": {status: sum(row["status"] == status for row in rows)
                        for status in statuses}}

