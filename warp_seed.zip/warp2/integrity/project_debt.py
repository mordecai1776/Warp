# WARP2/warp2/integrity/project_debt.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/project_debt.py
#  Used by   : warp2/integrity/source_watch.py (ChangedSourceCheck — one listed
#              file offered to be mended each sitting, and the list settled),
#              warp2/tests/test_project_files_keep_the_rule.py (the suite).
#  Uses      : warp2/integrity/discipline.py (header_problems, bare_parts — the
#              tree's own rules), warp2/util.py (atomic_write_bytes); stdlib
#              json, pathlib.
#  Description:
#    The project files that broke the tree's rules when the list was made,
#    grandfathered with how many problems each had (docs/project_rule_debt.json).
#    A file not on the list must keep the rules; a listed file may not get
#    worse; the list only shrinks as files are mended; and one listed file at
#    a time — the one with the most problems — is the next to be mended.
#  User intention (Andrew, 2026-09-23): grandfather what is already there,
#    "but there should be a system to update things". Fix plan 7.3 (check H2):
#    312 project files broke the header or note rules on 2026-10-15.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.integrity.discipline import bare_parts, header_problems
from warp2.util import atomic_write_bytes

LIST = "docs/project_rule_debt.json"


def _scanned(path: Path) -> bool:
    """Intention: project source to keep the rules — not old code in an archive or retired folder, not a cache."""
    return not any(part in ("archive", "__pycache__") or part.startswith("_retired") for part in path.parts)


def scan(root) -> dict:
    """Every project file that breaks the tree's rules, with how many problems it has.

    Intention: the same rules the warp2 tree keeps (warp2/integrity/discipline.py),
    so a project file is held to exactly what the rest of the tree is.
    """
    root = Path(root)
    found = {}
    for path in sorted((root / "projects").rglob("*.py")):
        rel = path.relative_to(root)
        if not _scanned(rel):
            continue
        problems = header_problems(path, root) + bare_parts(path, root)
        if problems:
            found[rel.as_posix()] = len(problems)
    return found


class Debt:
    """The grandfathered list: which project files may still break the rules, and by how much."""

    def __init__(self, root) -> None:
        """Intention: the list lives with the docs, beside the build log, so it travels with the code."""
        self.root = Path(root)
        self.path = self.root / LIST

    def listed(self) -> dict:
        """Intention: the list as it is on disk; empty when there is none yet."""
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return {str(k): int(v) for k, v in data.items()} if isinstance(data, dict) else {}

    def _write(self, listed: dict) -> None:
        """Intention: the list written whole, sorted, so its changes read plainly in a diff."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_bytes(self.path, (json.dumps(dict(sorted(listed.items())), indent=1) + "\n").encode("utf-8"))

    def record(self, found: dict) -> None:
        """Intention: make the list from what breaks the rules now — done once, when the rule came in."""
        self._write(dict(found))

    def breaking(self, found: dict) -> dict:
        """The files that break the rules and are not let off: new ones, and listed ones that got worse.

        Intention: what the suite refuses; a listed file that is better than
        its count, or mended, is fine.
        """
        listed = self.listed()
        out = {}
        for rel, count in found.items():
            if rel not in listed:
                out[rel] = "not on the grandfathered list"
            elif count > listed[rel]:
                out[rel] = f"{count} problems, more than the {listed[rel]} it was let off with"
        return out

    def settle(self, found: dict) -> dict:
        """The list lowered to what each listed file has now; mended files come off. Returns the new list.

        Intention: THE LIST ONLY SHRINKS. A file is never added here, and a
        count never rises: what is better is kept as the new most.
        """
        listed = self.listed()
        settled = {rel: min(count, found[rel]) for rel, count in listed.items() if found.get(rel)}
        if settled != listed:
            self._write(settled)
        return settled

    def next_to_mend(self, found: dict) -> str:
        """Intention: the listed file with the most problems now, mended first; "" when nothing is left."""
        listed = self.listed()
        open_ = {rel: count for rel, count in found.items() if rel in listed}
        return max(sorted(open_), key=lambda rel: open_[rel]) if open_ else ""
