# WARP2/warp2/integrity/discipline.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/discipline.py
#  Used by   : warp2/integrity/source_watch.py (changed files, checked at the
#              runner's start), warp2/tests/test_the_tree_keeps_its_discipline.py
#              (the whole tree, checked by the suite), warp2/gate/checks.py
#              (the same rules for every file the gate lets in).
#  Uses      : stdlib ast, pathlib; warp2/integrity/silence.py (silent_handlers —
#              an error dropped without a word, fix 7.6).
#  Description:
#    The per-file rules every WARP2 source file keeps: the pathway on the first
#    line, the five header fields, and an intention note on every function
#    and class, at any depth (methods and parts inside parts too). One copy of the rules, read by the test suite and by
#    the running machine.
#  User intention (Andrew, project standard):
#    "Intention notes of what a part of the code is meant to do and why it is
#    there ... will be on every part of the code ... Each file will also have
#    a header that will have all files that are using said file and what files
#    it uses." Andrew, 2026-09-18: "build things into the right system to keep
#    those from happening again." Files written 09-15..17 broke these rules
#    and nothing noticed until a person ran the suite; the machine now checks
#    every changed file itself.
# ============================================================================
from __future__ import annotations

import ast
from pathlib import Path

REQUIRED = ("Pathway   :", "Used by   :", "Uses      :", "Description:", "User intention")

# Intention: how far above a definition an "Intention" comment may sit and
# still count as its note. The same 12 lines the suite has always used.
NOTE_REACH = 12


def header_problems_text(text: str, rel: str) -> list:
    """What is wrong with the header of a file's text, for a file at `rel` (its path from the WARP2 root).

    Intention (2026-10-09, fix 7.2, check D12): ONE HEADER RULE for the tree
    and for the gate, so a file the gate lets in is a file the tree passes.
    The gate had its own, weaker rule (the path anywhere in the top 80 lines,
    or only the file's name).
    """
    first = text.splitlines()[0] if text.strip() else ""
    expected = "# WARP2/" + rel
    if first.strip() != expected:
        return [f"{rel}: first line should be '{expected}'"]
    return [f"{rel}: header is missing '{field.strip()}'" for field in REQUIRED if field not in text]


def header_problems(path: Path, root: Path) -> list:
    """What is wrong with one file's header, in the words the suite uses."""
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    return header_problems_text(text, Path(path).relative_to(root).as_posix())


PARTS = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def _parts(body: list, prefix: str = ""):
    """Every function and class in this body and inside them, each with its dotted name.

    Intention (2026-10-09, fix 7.1, check H1): EVERY PART, NOT ONLY THE TOP
    LEVEL. The check read `tree.body` alone, so 359 methods in warp2/ had no
    note and nothing noticed. A part inside another is named with the parts
    it sits in (Holder.method, outer.inside).
    """
    for node in body:
        if isinstance(node, PARTS):
            name = f"{prefix}{node.name}"
            yield name, node
            yield from _parts(node.body, name + ".")
        elif isinstance(node, (ast.If, ast.Try, ast.With, ast.For, ast.While)):
            # Intention: a part defined under an if, a try or a loop is still a part.
            for field in ("body", "orelse", "finalbody"):
                yield from _parts(getattr(node, field, []) or [], prefix)
            for handler in getattr(node, "handlers", []) or []:
                yield from _parts(handler.body, prefix)


def _comment_above(lines: list, top: int) -> str:
    """The comment lines directly above line `top` (1-based), up to NOTE_REACH, blank lines between them allowed.

    Intention (2026-10-09, fix 7.1): THE NOTE MUST BE THE PART'S OWN. Any
    "Intention" within twelve lines counted, so a class's docstring passed
    for the bare methods right under it. Only the comment block that sits
    directly on the part (above its decorators) is its note now.
    """
    found = []
    at = top - 2
    while at >= 0 and top - 1 - at <= NOTE_REACH:
        line = lines[at].strip()
        if line.startswith("#"):
            found.append(line)
        elif line:
            break
        at -= 1
    return "\n".join(found)


def _noted(node, lines: list) -> bool:
    """Intention: a part's note is its docstring, or an "Intention" comment directly above it."""
    if ast.get_docstring(node):
        return True
    top = min([node.lineno] + [d.lineno for d in getattr(node, "decorator_list", [])])
    return "Intention" in _comment_above(lines, top)


def is_test(rel: str) -> bool:
    """Intention: a test file — in a tests folder, or named test_*.py; it says what it is for in its names."""
    path = Path(rel)
    return "tests" in path.parts or path.name.startswith("test_")


def bare_parts_text(text: str, rel: str) -> list:
    """Functions and classes, at any depth, with no intention note, in a file's text at `rel`.

    Intention: production files only. A test says what it is for in its name.
    A file that does not parse is reported as that, because nothing else can
    be said about it. Read by the tree's check and by the gate (fix 7.2).
    """
    if is_test(rel):
        return []
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return [f"{rel}: does not parse ({exc.msg}, line {exc.lineno})"]
    lines = text.splitlines()
    return [f"{rel}::{name} has no intention note" for name, node in _parts(tree.body)
            if not _noted(node, lines)]


def bare_parts(path: Path, root: Path) -> list:
    """Intention: one file's parts with no intention note, read from disk."""
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    return bare_parts_text(text, Path(path).relative_to(root).as_posix())


def check(paths, root: Path) -> dict:
    """Every problem in these files, by file.

    Intention: grouped by file, because a fix is made one file at a time and
    the work raised for it is one unit per file.
    """
    found = {}
    for path in paths:
        path = Path(path)
        if path.suffix != ".py" or not path.is_file():
            continue
        problems = header_problems(path, root) + bare_parts(path, root) + _silent(path, root)
        if problems:
            found[path.relative_to(root).as_posix()] = problems
    return found


def _silent(path: Path, root: Path) -> list:
    """Intention (2026-10-15, fix 7.6): a broad catch that drops an error without a word is a problem like a missing note."""
    from warp2.integrity.silence import silent_handlers
    return [f"{where} drops an error without a word: say it (warp2/record/swallowed.py noted) "
            "or say on the line why stepping past it is right" for where in silent_handlers(path, root)]
