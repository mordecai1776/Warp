# WARP2/warp2/integrity/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/__init__.py
#  Used by   : the loop, which looks at what it just made; the test suite.
#  Uses      : nothing at import time, by design.
#  Description:
#    Looking at the work after it is done. The twin scores, what they catch,
#    and the root-cause probing that follows a measured weakness.
#  User intention (Andrew):
#    Self-analysis is not a grade. It is a magnitude and a set of named
#    failures, so the system can say what is likely wrong rather than how it
#    feels about itself.
# ============================================================================
