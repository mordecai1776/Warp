# WARP2/warp2/integrity/twin.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/twin.py
#  Used by   : the loop, after anything is built; warp2/integrity/deepen.py.
#  Uses      : stdlib ast, math, warp2/settings.py. Nothing from the store —
#              a thing is judged on what it IS, not on what is recorded about it.
#  Description:
#    The twin scores. How complex a thing is, how sure we are it is right, and
#    the risk that follows from both — plus the named failures they catch.
#  User intention (Andrew):
#    Twin scores, and a continuous magnitude rather than a pass or a fail. A
#    big gap between what the maker declared and what the thing measures is
#    overconfidence, and overconfidence is itself a caught failure.
# ============================================================================
from __future__ import annotations

import ast
import math

from warp2.settings import number

# The scales. A saturating curve rather than a cap: more evidence climbs toward
# a thousand and never exceeds it, so nothing is ever "as complex as possible"
# and there is always room above.
CODE_SCALE = number("WARP2_TWIN_CODE_SCALE", 120, minimum=1)
SHAPE_SCALE = number("WARP2_TWIN_SHAPE_SCALE", 60, minimum=1)

# How far a maker's declared confidence may sit above the measured one before
# it is called overconfidence. Four hundred on a thousand-point scale is not a
# quibble; it is a maker who has not looked at what they made.
OVERCONFIDENT_BY = number("WARP2_TWIN_OVERCONFIDENT_BY", 400, minimum=1)

# Below this, a thing is not trusted enough to stand on. Above the risk floor,
# it is complex enough and unsure enough that something should look at it.
CONFIDENCE_FLOOR = number("WARP2_TWIN_CONFIDENCE_FLOOR", 400, minimum=1)
RISK_FLOOR = number("WARP2_TWIN_RISK_FLOOR", 250, minimum=1)


def complexity(thing) -> dict:
    """How much room this thing has to be wrong, 0..1000.

    Intention: decisions, definitions, nesting and live lines for code; links,
    sub-parts and size for a shape. HIGHER IS NOT WORSE — it is more room to be
    wrong, which is only a problem next to low confidence. That pairing is the
    whole reason there are two scores and not one.
    """
    if isinstance(thing, str):
        try:
            tree = ast.parse(thing)
        except SyntaxError:
            # Broken means maximal uncertainty, not zero complexity: nobody
            # knows how complex a thing is that cannot be read.
            return {"score": 1000, "signals": {"parses": False}}
        decisions = sum(isinstance(node, (ast.If, ast.For, ast.While, ast.Try,
                                          ast.ExceptHandler, ast.BoolOp, ast.With,
                                          ast.comprehension))
                        for node in ast.walk(tree))
        defined = sum(isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                                        ast.ClassDef)) for node in ast.walk(tree))
        lines = len([line for line in thing.splitlines() if line.strip()])
        deep = _depth(tree)
        raw = decisions * 3 + defined * 2 + deep * 4 + lines * 0.2
        return {"score": _saturating(raw, float(CODE_SCALE)),
                "signals": {"parses": True, "decisions": decisions,
                            "defines": defined, "lines": lines, "depth": deep}}
    if isinstance(thing, dict):
        links = len(thing.get("links") or ())
        parts = len(thing.get("parts") or ())
        size = len(str(thing))
        raw = links * 2 + parts * 2 + size * 0.02
        return {"score": _saturating(raw, float(SHAPE_SCALE)),
                "signals": {"links": links, "parts": parts, "bytes": size}}
    return {"score": 0, "signals": {}}


def confidence(thing, declared: int | None = None, ask=None) -> dict:
    """How sure we are the thing is right, 0..1000.

    Intention: from concrete checks — does it parse, is it empty, does it carry
    what its shape requires — and compared against what the MAKER declared. A
    model may be asked, and asking is explicit: WARP silently built an auditor
    here that used the wrong working directory and could recurse into this very
    function when the model was unavailable.
    """
    signals: dict = {}
    sure = 1.0
    if isinstance(thing, str):
        if not thing.strip():
            sure = 0.0
            signals["empty"] = True
        else:
            try:
                ast.parse(thing)
                signals["parses"] = True
            except SyntaxError:
                sure *= 0.05
                signals["parses"] = False
            if "pass" in thing and len(thing.strip().splitlines()) <= 2:
                sure *= 0.3
                signals["barely_there"] = True
    elif isinstance(thing, dict):
        missing = [field for field in ("id", "kind") if not thing.get(field)]
        if missing:
            sure *= max(0.1, 1 - 0.25 * len(missing))
            signals["missing"] = missing

    measured = int(round(1000 * sure))
    if ask is not None:
        try:
            measured = int(round((measured + float(ask(thing))) / 2))
            signals["asked_a_model"] = True
        except Exception:
            # Intention: a model that cannot answer leaves the measured score
            # exactly as it was. A judgement that changes because a backend was
            # down is not a judgement.
            signals["asked_a_model"] = False
    if declared is not None:
        signals["declared"] = int(declared)
        signals["overconfident"] = bool(int(declared) - measured > int(OVERCONFIDENT_BY))
    return {"score": max(0, min(1000, measured)), "signals": signals}


def look(thing, declared: int | None = None, ask=None) -> dict:
    """Both scores, the risk that follows, and what they caught.

    Intention: `risk = complexity x (1 - confidence)`, continuous, so nothing
    is ever merely pass or fail. A thing can be simple and unsure (low risk,
    fix it), complex and sure (low risk, leave it), or complex and unsure —
    which is the only combination worth anybody's attention.
    """
    how_complex = complexity(thing)
    how_sure = confidence(thing, declared=declared, ask=ask)
    risk = int(round(how_complex["score"] * (1 - how_sure["score"] / 1000)))

    caught = []
    if how_sure["signals"].get("empty"):
        caught.append("it is empty")
    if how_sure["signals"].get("parses") is False:
        caught.append("it does not parse")
    if how_sure["signals"].get("barely_there"):
        caught.append("it is a body with nothing in it")
    if how_sure["signals"].get("missing"):
        caught.append("it is missing " + ", ".join(how_sure["signals"]["missing"]))
    if how_sure["signals"].get("overconfident"):
        caught.append(f"the maker declared {how_sure['signals']['declared']} "
                      f"and it measures {how_sure['score']}")
    return {
        "complexity": how_complex["score"],
        "confidence": how_sure["score"],
        "risk": risk,
        "caught": caught,
        "failing": bool(caught) or how_sure["score"] < int(CONFIDENCE_FLOOR),
        "worth_looking_at": risk >= int(RISK_FLOOR),
        "signals": {"complexity": how_complex["signals"],
                    "confidence": how_sure["signals"]},
    }


# Intention: a smooth curve to a ceiling, never a hard cap. More evidence
# climbs toward a thousand and never exceeds it, so nothing is ever "as complex
# as possible" and there is always room above.
def _saturating(raw: float, scale: float) -> int:
    return int(round(1000 * (1 - math.exp(-max(0.0, raw) / max(1e-9, scale)))))


# Intention: how deeply nested the deepest part is. Nesting is where a reader
# loses the thread, which is why it weighs more per level than a line does.
def _depth(node, level: int = 0) -> int:
    children = list(ast.iter_child_nodes(node))
    return level if not children else max(_depth(child, level + 1)
                                          for child in children)
