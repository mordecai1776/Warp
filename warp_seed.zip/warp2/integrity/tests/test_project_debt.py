# WARP2/warp2/integrity/tests/test_project_debt.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/tests/test_project_debt.py
#  Used by   : pytest.
#  Uses      : warp2/integrity/project_debt.py.
#  Description:
#    Fix 7.3 (check H2). The project files that broke the tree's rules on
#    2026-10-15 are grandfathered on a list with how many problems each had;
#    a new file must keep the rules, a listed file may not get worse, the
#    list only shrinks, and one listed file is offered to be mended at a time
#    — the one with the most problems first.
#  User intention (Andrew, 2026-09-23): grandfather what is there, "but there
#    should be a system to update things".
# ============================================================================
from __future__ import annotations

import json

from warp2.integrity.project_debt import Debt, scan

GOOD = ('# WARP2/projects/p/good.py\n#\n#  Pathway   : WARP2/projects/p/good.py\n'
        '#  Used by   : nothing.\n#  Uses      : nothing.\n#  Description: x.\n#  User intention: y.\n'
        'def f():\n    """Intention: x."""\n    return 1\n')
BAD = "def f():\n    return 1\n\ndef g():\n    return 2\n"


def _tree(tmp_path, files: dict):
    """Intention: a WARP2 root holding these project files."""
    for rel, text in files.items():
        path = tmp_path / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    return tmp_path


def test_a_new_file_must_keep_the_rules(tmp_path):
    """Intention: only what was there when the list was made is let off."""
    root = _tree(tmp_path, {"projects/p/good.py": GOOD, "projects/p/new.py": BAD})
    debt = Debt(root)
    assert debt.breaking(scan(root)) == {"projects/p/new.py": "not on the grandfathered list"}


def test_a_listed_file_may_not_get_worse_and_may_get_better(tmp_path):
    """Intention: the count on the list is the most problems the file may have."""
    root = _tree(tmp_path, {"projects/p/old.py": BAD})
    debt = Debt(root)
    debt.record(scan(root))
    assert debt.breaking(scan(root)) == {}
    (root / "projects/p/old.py").write_text(BAD + "\ndef h():\n    return 3\n", encoding="utf-8")
    assert "projects/p/old.py" in debt.breaking(scan(root))
    (root / "projects/p/old.py").write_text(GOOD.replace("good.py", "old.py"), encoding="utf-8")
    assert debt.breaking(scan(root)) == {}


def test_the_list_only_shrinks(tmp_path):
    """Intention: a mended file comes off; a file never goes on again by settling."""
    root = _tree(tmp_path, {"projects/p/a.py": BAD, "projects/p/b.py": BAD})
    debt = Debt(root)
    debt.record(scan(root))
    (root / "projects/p/a.py").write_text(GOOD.replace("good.py", "a.py"), encoding="utf-8")
    (root / "projects/p/c.py").write_text(BAD, encoding="utf-8")
    debt.settle(scan(root))
    listed = json.loads(debt.path.read_text(encoding="utf-8"))
    assert set(listed) == {"projects/p/b.py"}


def test_the_file_with_most_problems_is_mended_first(tmp_path):
    """Intention: one at a time, the heaviest first."""
    root = _tree(tmp_path, {"projects/p/a.py": "def f():\n    return 1\n", "projects/p/b.py": BAD})
    debt = Debt(root)
    debt.record(scan(root))
    assert debt.next_to_mend(scan(root)) == "projects/p/b.py"


def test_archived_code_is_not_scanned(tmp_path):
    """Intention: old code kept in an archive folder is not mended."""
    root = _tree(tmp_path, {"projects/p/archive/old.py": BAD, "projects/p/_retired_x/old.py": BAD})
    assert scan(root) == {}
