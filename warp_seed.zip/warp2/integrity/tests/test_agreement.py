# WARP2/warp2/integrity/tests/test_agreement.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/tests/test_agreement.py
#  Used by   : pytest.
#  Uses      : warp2/integrity/agree.py, warp2/store/store.py.
#  Description:
#    Holds agreement to the number WARP had and never read: on the 34 subjects
#    more than one of its scorers looked at, the median confidence spread was
#    815 out of 1000, on identical bytes.
#  User intention (Andrew):
#    Every judgement must be attributable and no single opinion settles
#    anything.
# ============================================================================
from __future__ import annotations

import pytest

from warp2.integrity.agree import Agreement, Disputed, FAR_APART
from warp2.store.store import Store

BYTES = b"def hold(n):\n    return max(1, n)\n"


def _agree(tmp_path):
    return Agreement(Store(tmp_path / "state"))


def test_a_judgement_says_who_said_it_and_what_they_saw(tmp_path):
    """Intention: without the signer a score cannot be argued with, weighted by
    past accuracy, or caught rewriting itself; without the digest of what was
    read, two scores about different versions look like disagreement."""
    agreed = _agree(tmp_path)
    made = agreed.judged("pkg/a.py", by="mini", score=900, saw=BYTES, why="looks fine")
    assert made["by"] == "mini" and made["score"] == 900
    assert len(made["saw"]) == 64
    assert agreed.on("pkg/a.py")[0]["why"] == "looks fine"


def test_one_judge_is_a_reading_and_not_a_verdict(tmp_path):
    """Intention: WARP's production median says a second judge looking at the
    identical bytes would typically land 815 points away. A lone score is worth
    very little and the report says so in words rather than returning a
    comfortable number."""
    agreed = _agree(tmp_path)
    agreed.judged("pkg/a.py", by="mini", score=900, saw=BYTES)
    found = agreed.spread("pkg/a.py")
    assert found["judges"] == 1 and found["agree"] is None
    assert "a reading, not a verdict" in found["says"]
    assert agreed.report()["alone"] == ["pkg/a.py"]


def test_judges_far_apart_on_the_same_bytes_are_named(tmp_path):
    """Intention: THE NUMBER THIS FILE EXISTS FOR. Two judges on identical
    bytes, 815 apart out of 1000, was WARP's median — and `refute` appears 0
    times in 52,412 events. The disagreement sat in a database, unread."""
    agreed = _agree(tmp_path)
    agreed.judged("pkg/a.py", by="mini", score=950, saw=BYTES)
    agreed.judged("pkg/a.py", by="other", score=135, saw=BYTES)

    found = agreed.spread("pkg/a.py")
    assert found["judges"] == 2 and found["spread"] == 815
    assert found["agree"] is False
    assert "815 APART out of 1000 on the same bytes" in found["says"]
    assert agreed.report()["disagreeing"] == 1


def test_judges_that_agree_are_left_alone(tmp_path):
    """Intention: the alarm must not fire on agreement, or the next real
    disagreement is ignored."""
    agreed = _agree(tmp_path)
    agreed.judged("pkg/a.py", by="mini", score=900, saw=BYTES)
    agreed.judged("pkg/a.py", by="other", score=880, saw=BYTES)
    found = agreed.spread("pkg/a.py")
    assert found["agree"] is True and found["spread"] == 20
    assert "within 20 of each other" in found["says"]
    assert agreed.report()["disagreeing"] == 0


def test_two_readings_of_different_versions_are_not_a_disagreement(tmp_path):
    """Intention: WARP's rows all shared a fingerprint, which is what made its
    815-point median a real finding rather than an artefact. Judgements are
    grouped by what was SEEN."""
    agreed = _agree(tmp_path)
    agreed.judged("pkg/a.py", by="mini", score=950, saw=BYTES)
    agreed.judged("pkg/a.py", by="other", score=135, saw=b"something else entirely")
    found = agreed.spread("pkg/a.py")
    assert found["judges"] == 1          # no two judges shared any bytes
    assert found["agree"] is None


def test_a_judge_may_not_change_its_answer_about_unchanged_evidence(tmp_path):
    """Intention: WARP's `ScoreConflict` was defined and NEVER ONCE RAISED.
    Silently taking the newer number is how a scoreboard becomes whatever was
    written last."""
    agreed = _agree(tmp_path)
    agreed.judged("pkg/a.py", by="mini", score=900, saw=BYTES)
    agreed.judged("pkg/a.py", by="mini", score=900, saw=BYTES)      # same answer is fine
    with pytest.raises(Disputed) as disputed:
        agreed.judged("pkg/a.py", by="mini", score=200, saw=BYTES)
    assert "Nothing about the evidence changed" in str(disputed.value)


def test_a_change_of_mind_is_kept_with_its_reason(tmp_path):
    """Intention: a correction is recorded as one rather than overwriting. The
    store is temporal, so both readings and the reason are still there."""
    agreed = _agree(tmp_path)
    agreed.judged("pkg/a.py", by="mini", score=900, saw=BYTES)
    agreed.judged("pkg/a.py", by="mini", score=200, saw=BYTES,
                  correcting="the test it passed was checking the wrong thing")
    now = agreed.on("pkg/a.py")[0]
    assert now["score"] == 200 and now["corrected"] is True


def test_a_judge_that_is_usually_far_from_the_others_is_named(tmp_path):
    """Intention: DISAGREEMENT IS A FACT ABOUT THE JUDGE. Two scorers 815 apart
    are not both slightly wrong, and which one is drifting is answerable from
    the record they both wrote."""
    agreed = _agree(tmp_path)
    for index in range(4):
        seen = BYTES + str(index).encode()
        agreed.judged(f"pkg/{index}.py", by="steady", score=800, saw=seen)
        agreed.judged(f"pkg/{index}.py", by="also-steady", score=820, saw=seen)
        agreed.judged(f"pkg/{index}.py", by="wild", score=100, saw=seen)

    judges = {row["judge"]: row for row in agreed.judges()}
    assert judges["wild"]["an_outlier"] is True
    assert judges["wild"]["usually_off_by"] >= int(FAR_APART)
    assert judges["steady"]["an_outlier"] is False


def test_coverage_travels_with_the_measurement(tmp_path):
    """Intention: WARP registered 84,899 subjects for scoring and scored 39 —
    0.046% — and the subsystem read as working. A measurement covering almost
    nothing has to say so in the same breath as its result."""
    agreed = _agree(tmp_path)
    assert agreed.report()["says"] == "nothing has been judged yet"
    agreed.judged("pkg/a.py", by="mini", score=900, saw=BYTES)
    agreed.judged("pkg/b.py", by="mini", score=900, saw=b"other")
    agreed.judged("pkg/b.py", by="other", score=880, saw=b"other")
    found = agreed.report()
    assert found["judged"] == 2 and found["with_more_than_one"] == 1
    assert found["alone"] == ["pkg/a.py"]
    assert "1 rest on a single opinion" in found["says"]
