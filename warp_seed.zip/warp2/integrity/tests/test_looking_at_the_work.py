# WARP2/warp2/integrity/tests/test_looking_at_the_work.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/tests/test_looking_at_the_work.py
#  Used by   : pytest.
#  Uses      : warp2/integrity/{twin,deepen}.py.
#  Description:
#    The twin scores and the probing, held to what makes them useful: two
#    numbers rather than a grade, a risk that follows from both, and a guess
#    that says how to settle itself.
#  User intention (Andrew):
#    Twin scores, and a continuous magnitude rather than a pass or a fail.
# ============================================================================
from __future__ import annotations

from warp2.integrity.deepen import MODERATE, SEVERE, probe, weakness
from warp2.integrity.twin import complexity, confidence, look

SIMPLE = "def hold(number):\n    return max(1, number)\n"
GNARLY = ("def hold(a, b, c):\n"
          "    for x in range(a):\n"
          "        if x > b:\n"
          "            for y in range(c):\n"
          "                if y:\n"
          "                    try:\n"
          "                        with open('x') as f:\n"
          "                            return [i for i in f if i and x]\n"
          "                    except Exception:\n"
          "                        pass\n"
          "    return None\n")


def test_complexity_is_room_to_be_wrong_not_badness():
    """Intention: higher is not worse. It is more room to be wrong, which is
    only a problem next to low confidence — and that pairing is the whole
    reason there are two scores and not one."""
    assert complexity(SIMPLE)["score"] < complexity(GNARLY)["score"]
    assert complexity(SIMPLE)["signals"]["parses"] is True
    # Something that cannot be read is maximally uncertain, not simple.
    assert complexity("def hold(:")["score"] == 1000
    assert complexity("def hold(:")["signals"]["parses"] is False


def test_a_maker_who_did_not_look_at_what_they_made_is_caught():
    """Intention: a big gap between what the maker declared and what the thing
    measures is overconfidence, and overconfidence is itself a caught failure."""
    honest = confidence(SIMPLE, declared=900)
    assert honest["signals"]["overconfident"] is False
    proud = confidence("def hold(n):\n    pass\n", declared=990)
    assert proud["signals"]["overconfident"] is True
    assert "the maker declared 990" in " ".join(
        look("def hold(n):\n    pass\n", declared=990)["caught"])


def test_risk_is_continuous_and_pairs_the_two():
    """Intention: `risk = complexity x (1 - confidence)`. A thing can be simple
    and unsure, complex and sure, or complex and unsure — and only the last is
    worth anybody's attention."""
    broken = look("def hold(:")
    assert broken["risk"] > 900 and broken["worth_looking_at"] is True
    fine = look(SIMPLE)
    assert fine["risk"] == 0 and fine["worth_looking_at"] is False
    assert fine["failing"] is False


def test_asking_a_model_is_explicit_and_a_silent_one_changes_nothing():
    """Intention: WARP silently built an auditor here that used the wrong
    working directory and could recurse into this very function when the model
    was unavailable. A judgement that changes because a backend was down is not
    a judgement."""
    without = confidence(SIMPLE)["score"]
    asked = confidence(SIMPLE, ask=lambda thing: 200)
    assert asked["score"] == (without + 200) // 2
    assert asked["signals"]["asked_a_model"] is True

    def broken(thing):
        raise RuntimeError("the model is not there")

    unchanged = confidence(SIMPLE, ask=broken)
    assert unchanged["score"] == without
    assert unchanged["signals"]["asked_a_model"] is False


def test_every_guess_says_how_to_settle_it():
    """Intention: a root cause nobody can check is a story, and a system that
    tells itself stories about its failures will keep having them."""
    found = probe(GNARLY, text=GNARLY)
    assert found["guesses"]
    for guess in found["guesses"]:
        assert guess["guess"] and guess["because"] and guess["settled_by"]
    said = {guess["guess"] for guess in found["guesses"]}
    assert "a failure is being swallowed" in said
    assert "it catches everything" in said


def test_failing_the_same_way_every_time_means_something_different(tmp_path):
    """Intention: no edit to the thing has changed the outcome, so the fault is
    probably in what it is being asked for rather than in the answer — which is
    the opposite conclusion from failing differently every time."""
    same = probe(SIMPLE, text=SIMPLE,
                 failures=[{"why": "no test"}] * 3)["guesses"]
    assert any("the same way every time" in guess["guess"] for guess in same)
    varied = probe(SIMPLE, text=SIMPLE,
                   failures=[{"why": "a"}, {"why": "b"}, {"why": "c"}])["guesses"]
    assert any("differently every time" in guess["guess"] for guess in varied)


def test_nothing_wrong_is_a_real_answer():
    """Intention: a prober that always produces something is a prober nobody
    can believe when it produces the right thing."""
    found = probe(SIMPLE, text=SIMPLE)
    assert found["guesses"] == []
    assert found["says"] == "nothing about this looks wrong from here"
    assert found["weakness"] == "minor"


def test_severity_is_read_from_the_numbers_that_already_exist():
    # Intention: severity is not a fourth score.
    assert weakness(950, 0) == SEVERE
    assert weakness(0, 4) == SEVERE
    assert weakness(400, 0) == MODERATE
    assert weakness(10, 0) == "minor"


def test_probing_changes_nothing():
    """Intention: it reads, it guesses, and it says how to find out. A guess
    that acts on itself is a second unaccountable writer."""
    before = GNARLY
    probe(GNARLY, text=GNARLY, failures=[{"why": "x"}] * 5, declared=999)
    assert GNARLY == before
