# WARP2/warp2/integrity/tests/test_every_method_has_a_note.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/tests/test_every_method_has_a_note.py
#  Used by   : pytest.
#  Uses      : warp2/integrity/discipline.py (bare_parts).
#  Description:
#    Fix 7.1 (check H1). The rule check looks at every function and class in
#    a file — methods and parts inside parts too — not only the top level,
#    where 359 methods in warp2/ had no intention note and nothing noticed.
#  User intention (Andrew, project standard): "Intention notes of what a part
#    of the code is meant to do and why it is there ... will be on every part
#    of the code."
# ============================================================================
from __future__ import annotations

from warp2.integrity.discipline import bare_parts

SOURCE = '''# WARP2/pkg/thing.py
class Holder:
    """Intention: holds a thing."""

    def noted(self):
        """Intention: says why."""
        return 1

    # Intention: a comment above counts as the note.
    def commented(self):
        return 2

    def bare(self):
        return 3

    class Inner:
        pass


def outer():
    """Intention: has a note, but the part inside it does not."""
    def inside():
        return 4
    return inside
'''


def test_a_method_without_a_note_is_named(tmp_path):
    """Intention: nested parts are named with the parts they sit in."""
    path = tmp_path / "pkg" / "thing.py"
    path.parent.mkdir()
    path.write_text(SOURCE, encoding="utf-8")
    bare = bare_parts(path, tmp_path)
    assert bare == ["pkg/thing.py::Holder.bare has no intention note",
                    "pkg/thing.py::Holder.Inner has no intention note",
                    "pkg/thing.py::outer.inside has no intention note"]


def test_a_test_file_is_still_left_out(tmp_path):
    """Intention: a test says what it is for in its name."""
    path = tmp_path / "pkg" / "tests" / "test_thing.py"
    path.parent.mkdir(parents=True)
    path.write_text(SOURCE, encoding="utf-8")
    assert bare_parts(path, tmp_path) == []
