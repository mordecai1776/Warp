# WARP2/warp2/integrity/tests/test_new_parts_noted_1029.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/tests/test_new_parts_noted_1029.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/integrity/discipline.py (check: headers and notes).
#  Description:
#    BUILD_LOG 894, 905-911 added parts with no intention note (front.py,
#    rule_scores.py, worst_first.py, true_image_choice.py, graph_play
#    paper.py and play.py) and two files with a short header; the warp's own
#    change check said so at start-up (2026-10-29 07:58 and 08:40 UTC).
#    This test keeps every part and header of those files whole.
#  User intention (Andrew, project standard): "Intention notes of what a part
#    of the code is meant to do and why it is there ... will be on every part
#    of the code."
# ============================================================================
from __future__ import annotations

from pathlib import Path

from warp2.integrity.discipline import check

ROOT = Path(__file__).resolve().parents[3]

FILES = (
    "warp2/train/front.py",
    "warp2/train/rule_scores.py",
    "warp2/train/worst_first.py",
    "warp2/work/side/true_image_choice.py",
    "warp2/graph_play/paper.py",
    "warp2/graph_play/play.py",
    "warp2/graph_play/tests/__init__.py",
    "warp2/train/tests/test_code_front.py",
)


# Intention: every part of these files has its note and every header is whole.
def test_new_files_have_every_part_noted_and_a_whole_header():
    found = check([ROOT / rel for rel in FILES], ROOT)
    assert found == {}, found
