# WARP2/warp2/integrity/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/tests/__init__.py
#  Used by   : pytest, for package discovery.
#  Uses      : nothing.
#  Description:
#    Makes the integrity tests a package. Empty on purpose.
#  User intention (Andrew):
#    Every file declares its pathway, including the ones with nothing in them.
# ============================================================================
