# WARP2/warp2/integrity/tests/test_batch_write_parts_noted.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/tests/test_batch_write_parts_noted.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/integrity/discipline.py (bare_parts).
#  Description:
#    BUILD_LOG 703 put new parts (journal sync_now, store writing_many)
#    between an older part and the "Intention" comment above it, so
#    Journal._rotate_if_needed and store._stamp_digest lost their notes and
#    the warp's own change check said so at start-up (2026-10-26 14:25 UTC).
#    This test keeps every part of those two files noted.
#  User intention (Andrew, project standard): "Intention notes of what a part
#    of the code is meant to do and why it is there ... will be on every part
#    of the code."
# ============================================================================
from __future__ import annotations

from pathlib import Path

from warp2.integrity.discipline import bare_parts

ROOT = Path(__file__).resolve().parents[3]


# Intention: the two files the batch write changed carry a note on every part.
def test_batch_write_files_have_every_part_noted():
    for rel in ("warp2/record/journal.py", "warp2/store/store.py"):
        assert bare_parts(ROOT / rel, ROOT) == [], rel
