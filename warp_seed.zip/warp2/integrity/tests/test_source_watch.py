# WARP2/warp2/integrity/tests/test_source_watch.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/tests/test_source_watch.py
#  Used by   : pytest.
#  Uses      : warp2/integrity/source_watch.py, warp2/integrity/discipline.py,
#              warp2/ask/thread.py.
#  Description:
#    A changed source file that breaks the tree's rules is caught at the next
#    start: written down, told to Andrew, and offered as work. The first
#    start only records; an unchanged tree says nothing.
#  User intention (Andrew, 2026-09-18):
#    "build things into the right system to keep those from happening again."
# ============================================================================
from __future__ import annotations

from warp2.ask.thread import Thread
from warp2.integrity.source_watch import ChangedSourceCheck

GOOD = ('# WARP2/warp2/pkg/good.py\n#  Pathway   : x\n#  Used by   : x\n#  Uses      : x\n'
        '#  Description: x\n#  User intention: x\n\n\ndef hold(n):\n    """Intention: keep it."""\n    return n\n')


class _Queue:
    """Intention: remembers what work was offered."""

    def __init__(self) -> None:
        self.offered = []

    def offer(self, **kw) -> dict:
        """Intention: take everything."""
        self.offered.append(kw)
        return kw


def _tree(tmp_path):
    """Intention: a WARP2-shaped folder with one good file and a build log."""
    root = tmp_path / "WARP2"
    (root / "warp2" / "pkg").mkdir(parents=True)
    (root / "warp2" / "pkg" / "good.py").write_text(GOOD, encoding="utf-8")
    (root / "docs").mkdir()
    (root / "docs" / "BUILD_LOG.md").write_text("# log\n", encoding="utf-8")
    return root, tmp_path / "state"


def test_the_first_start_only_records(tmp_path):
    """Intention: judging the whole tree is the suite's job."""
    root, state = _tree(tmp_path)
    got = ChangedSourceCheck(root, state, _Queue())()
    assert got["first"] is True and got["changed"] == 0 and not got["breaking"]


def test_a_changed_file_that_breaks_the_rules_is_caught_told_and_offered(tmp_path):
    """Intention: the whole point — caught at the next start, not by a person."""
    root, state = _tree(tmp_path)
    queue = _Queue()
    ChangedSourceCheck(root, state, queue)()
    (root / "warp2" / "pkg" / "bad.py").write_text("def naked():\n    return 1\n", encoding="utf-8")
    got = ChangedSourceCheck(root, state, queue)()
    assert list(got["breaking"]) == ["warp2/pkg/bad.py"]
    assert got["unlogged"] is True
    assert [o["target"] for o in queue.offered] == ["warp2/pkg/bad.py"]
    said = Thread(state).recent()[-1]["said"]
    assert "warp2/pkg/bad.py" in said and "build log" in said


def test_a_clean_change_with_a_log_entry_says_nothing(tmp_path):
    """Intention: a good change, logged, is not noise."""
    root, state = _tree(tmp_path)
    ChangedSourceCheck(root, state, _Queue())()
    (root / "warp2" / "pkg" / "good.py").write_text(GOOD + "\n", encoding="utf-8")
    (root / "docs" / "BUILD_LOG.md").write_text("# log\n\n## 1. changed good\n", encoding="utf-8")
    got = ChangedSourceCheck(root, state, _Queue())()
    assert got["changed"] == 1 and not got["breaking"] and got["unlogged"] is False
    assert Thread(state).recent() == []


def test_one_grandfathered_project_file_is_offered_to_be_mended_each_sitting(tmp_path):
    """Intention (2026-10-09, fix 7.3): the grandfathered project files are
    mended in turn — one a sitting, the one with the most problems — and a
    mended file comes off the list."""
    from warp2.integrity.project_debt import Debt, scan
    root, state = _tree(tmp_path)
    (root / "projects" / "p").mkdir(parents=True)
    (root / "projects" / "p" / "a.py").write_text("def f():\n    return 1\n", encoding="utf-8")
    (root / "projects" / "p" / "b.py").write_text("def f():\n    return 1\n\ndef g():\n    return 2\n",
                                                  encoding="utf-8")
    Debt(root).record(scan(root))
    queue = _Queue()
    got = ChangedSourceCheck(root, state, queue)()
    assert got["mend"] == "projects/p/b.py"
    assert [o["target"] for o in queue.offered] == ["projects/p/b.py"]
    (root / "projects" / "p" / "b.py").write_text(GOOD.replace("warp2/pkg/good.py", "projects/p/b.py"),
                                                  encoding="utf-8")
    got = ChangedSourceCheck(root, state, _Queue())()
    assert got["mend"] == "projects/p/a.py"
    assert set(Debt(root).listed()) == {"projects/p/a.py"}


def test_a_project_file_that_breaks_the_rules_beyond_its_let_off_is_mended_first(tmp_path):
    """Intention (2026-10-15, fix 7.3): a new project file that breaks the
    rules, or a listed one that got worse, is offered before the oldest
    debt, and as urgently as a broken file of the warp's own."""
    from warp2.integrity.project_debt import Debt, scan
    root, state = _tree(tmp_path)
    (root / "projects" / "p").mkdir(parents=True)
    (root / "projects" / "p" / "old.py").write_text("def f():\n    return 1\n\ndef g():\n    return 2\n",
                                                    encoding="utf-8")
    Debt(root).record(scan(root))
    (root / "projects" / "p" / "new.py").write_text("def f():\n    return 1\n", encoding="utf-8")
    queue = _Queue()
    got = ChangedSourceCheck(root, state, queue)()
    assert got["mend"] == "projects/p/new.py"
    assert queue.offered[-1]["target"] == "projects/p/new.py" and queue.offered[-1]["rank"] == 0.9
