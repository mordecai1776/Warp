# WARP2/warp2/integrity/silence.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/silence.py
#  Used by   : warp2/integrity/discipline.py (check — the tree's rules, read by
#              the suite and by the changed-files check at each start),
#              warp2/tests/test_no_error_is_dropped_without_a_word.py.
#  Uses      : stdlib ast, pathlib.
#  Description:
#    Finds every broad `except` (bare, Exception or BaseException) whose whole
#    body is `pass` and that gives no reason — no comment on the `except`
#    line or inside it. Such a handler drops an error without a word.
#  User intention (Andrew, defect rule 7): no silent degradation. Fix plan 7.6
#    (check H5): 226 such handlers in warp2/ and the two projects the warp
#    runs every day; each now reports (warp2/record/swallowed.py) or says why
#    silence is right.
# ============================================================================
from __future__ import annotations

import ast
from pathlib import Path

BROAD = ("Exception", "BaseException")


def _broad(handler: ast.ExceptHandler) -> bool:
    """Intention: a handler that catches everything — bare, Exception or BaseException, alone or in a tuple."""
    kind = handler.type
    if kind is None:
        return True
    names = kind.elts if isinstance(kind, ast.Tuple) else [kind]
    return any(isinstance(n, ast.Name) and n.id in BROAD for n in names)


def _silent_lines(text: str) -> list:
    """The line of every broad `except: pass` in this code that says no reason; [] when it does not parse.

    Intention: the reason may sit on the `except` line or on the `pass` line
    or between them; a reason far above is not this handler's.
    """
    try:
        tree = ast.parse(str(text))
    except SyntaxError:
        return []
    lines = str(text).splitlines()
    found = []
    for node in ast.walk(tree):
        if not (isinstance(node, ast.ExceptHandler) and _broad(node) and len(node.body) == 1
                and isinstance(node.body[0], ast.Pass)):
            continue
        span = lines[node.lineno - 1:node.body[0].lineno]
        if not any("#" in line for line in span):
            found.append(node.lineno)
    return sorted(found)


def silent_handlers(path: Path, root: Path) -> list:
    """Every broad `except: pass` in one file that says no reason, as "file:line".

    Intention: tests are not checked — a test's catch is part of what it shows.
    """
    rel = Path(path).relative_to(root).as_posix()
    if "tests" in Path(rel).parts:
        return []
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    return [f"{rel}:{line}" for line in _silent_lines(text)]
