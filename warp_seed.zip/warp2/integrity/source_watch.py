# WARP2/warp2/integrity/source_watch.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/source_watch.py
#  Used by   : warp2/run.py (`go`: once at the start of every sitting, through
#              the pathway, as `check_changed_source`).
#  Uses      : warp2/builders/ (last_good, scores, entries — BUILD_LOG 1005),
#              warp2/integrity/discipline.py (the rules),
#              warp2/integrity/project_debt.py (the grandfathered project
#              files, mended one a sitting), warp2/work/queue.py
#              (work offered to fix a file), warp2/ask/thread.py (telling
#              Andrew), warp2/util.py.
#  Description:
#    Which of WARP2's own files changed since the last sitting, and whether
#    each still keeps the tree's rules. A file that does not is written down,
#    shown to Andrew, and offered as work. Source that changed with no build
#    log entry is said too. And each sitting, the grandfathered project file
#    with the most problems is offered to be mended (fix 7.3).
#  User intention (Andrew, 2026-09-18):
#    "build things into the right system to keep those from happening again."
#    Between 09-15 and 09-17 about fifty files changed. Twenty-seven lost their
#    headers, six parts lost their intention notes, and none of it reached the
#    build log. Nothing noticed until a person ran the suite. Every change now
#    passes through here the next time the runner starts — and the runner
#    restarts on every source change (see `_Reload` in warp2/run.py).
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.integrity.discipline import check
from warp2.util import atomic_write_bytes, now_iso
from warp2.record.swallowed import noted

LOG = "docs/BUILD_LOG.md"


class SourceWatch:
    """The last-seen fingerprint of the source, and what differs from it now.

    Intention: the fingerprint is size and modified time, the same cheap
    reading the reload boundary uses. The first sitting ever only records it —
    judging the whole tree is the suite's job, not a start-up's.
    """

    def __init__(self, root, state) -> None:
        """Intention: `root` is WARP2/, the folder `# WARP2/...` paths are relative to."""
        self.root = Path(root)
        self.seen = Path(state) / "locks" / "source_seen.json"

    # Intention (BUILD_LOG 1005): the folders watched — the warp, the Eye and the design — every builder's ground.
    WATCHED = ("warp2", "projects/behemoth_eye", "design")

    def now(self) -> dict:
        """Intention: every .py under the watched folders, plus the build log."""
        out = {}
        for folder in self.WATCHED:
            home = self.root / folder
            if not home.is_dir():
                continue
            for path in sorted(home.rglob("*.py")):
                if "__pycache__" in path.parts or "_to_delete" in path.parts or "archive" in path.parts:
                    continue
                stat = path.stat()
                out[path.relative_to(self.root).as_posix()] = [stat.st_mtime_ns, stat.st_size]
        log = self.root / LOG
        if log.is_file():
            out[LOG] = [log.stat().st_mtime_ns, log.stat().st_size]
        return out

    def changed(self) -> dict:
        """What changed since last time, and the new fingerprint (not yet saved)."""
        current = self.now()
        try:
            before = json.loads(self.seen.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            before = None
        if before is None:
            return {"first": True, "files": [], "logged": True, "current": current}
        files = sorted(rel for rel, mark in current.items()
                       if rel != LOG and before.get(rel) != mark)
        return {"first": False, "files": files, "logged": current.get(LOG) != before.get(LOG),
                "current": current}

    def remember(self, current: dict) -> None:
        """Intention: saved only after the check ran, so a crash re-checks next time."""
        self.seen.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_bytes(self.seen, json.dumps(current).encode("utf-8"))


class ChangedSourceCheck:
    """The pathway body: check what changed, say it, and offer the fixes."""

    def __init__(self, root, state, queue=None, store=None) -> None:
        """Intention: the queue and store are the loop's own, so the work lands in the same ledger."""
        self.watch = SourceWatch(root, state)
        self.root = Path(root)
        self.state = Path(state)
        self.queue = queue
        self.store = store

    def __call__(self) -> dict:
        """Intention: one report; every finding also becomes a fact and a unit of work."""
        seen = self.watch.changed()
        found = check([self.root / rel for rel in seen["files"]], self.root)
        unlogged = bool(seen["files"]) and not seen["logged"]
        for rel, problems in found.items():
            self._record(rel, problems)
        if found or unlogged:
            self._tell(seen["files"], found, unlogged)
        self.watch.remember(seen["current"])
        builders = self._builders(seen, unlogged)
        return {"first": seen["first"], "changed": len(seen["files"]),
                "breaking": found, "unlogged": unlogged, "mend": self._mend_in_turn(), "builders": builders}

    def _builders(self, seen: dict, unlogged: bool) -> dict:
        """Intention (BUILD_LOG 1005; Andrew, 2026-10-31: "giving scores for the hourly models that make changes and
        reduce ability based of of said scores"): this start passed the gate, so the files as they are now are the good
        copies (every file the first time, the changed ones after); an unlogged change is a mark against "unknown";
        the last entry number is kept so the next failed start knows which entries to read; and the scores are
        worked out afresh and written. None of this ever stops a start."""
        try:
            from warp2.builders.last_good import LastGood
            from warp2.builders.scores import Scores
            from warp2.builders.entries import LogEntries
            import json
            rels = list(seen["current"]) if seen["first"] else list(seen["files"])
            kept = LastGood(self.root, self.state).keep([r for r in rels if r != LOG])
            home = self.state / "builders"
            home.mkdir(parents=True, exist_ok=True)
            if unlogged:
                with (home / "unlogged.jsonl").open("a", encoding="utf-8") as out:
                    out.write(json.dumps({"at": now_iso(), "files": seen["files"]}) + "\n")
            last = max([e.number for e in LogEntries(self.root).all()] or [0])
            atomic_write_bytes(home / "last_sitting.json", json.dumps({"entry": last, "at": now_iso()}).encode("utf-8"))
            scores = Scores(self.root, self.state).refresh()
            return {"kept_good": kept, "last_entry": last,
                    "scores": {a: r["score"] for a, r in scores.get("builders", {}).items()}}
        except Exception as exc:  # noqa: BLE001 — a reading beside the start, never the start itself
            noted("warp2/integrity/source_watch.py:ChangedSourceCheck._builders", exc)
            return {"error": f"{type(exc).__name__}: {exc}"}

    def _mend_in_turn(self) -> str:
        """The grandfathered project file offered to be mended this sitting; "" when none.

        Intention (2026-10-09, fix 7.3, check H2; Andrew, 2026-09-23: "there
        should be a system to update things"): ONE A SITTING, THE HEAVIEST
        FIRST. The list is settled first, so a file mended since the last
        sitting comes off and the next one is offered. With no list, nothing.
        """
        from warp2.integrity.project_debt import Debt, scan
        debt = Debt(self.root)
        if not debt.path.is_file():
            return ""
        found = scan(self.root)
        debt.settle(found)
        # Intention (2026-10-15, fix 7.3): a project file that breaks the rules
        # beyond what it was let off with — a new one, or one that got worse —
        # goes first, as urgently as a broken file of the warp's own (0.9);
        # then the heaviest of the old debt (0.5).
        broken = sorted(debt.breaking(found))
        rel = broken[0] if broken else debt.next_to_mend(found)
        if rel and self.queue is not None:
            from warp2.work.queue import Refused
            try:
                self.queue.offer(item_id=f"work:revise:{rel}", kind="revise", target=rel,
                                 rank=0.9 if broken else 0.5,
                                 verification="the file keeps the tree's discipline: pathway, "
                                              "header and an intention note on every part")
            except Refused:
                pass
        return rel

    def _record(self, rel: str, problems: list) -> None:
        """Intention: a fact on the file, and work to fix it that says how it will be checked."""
        if self.store is not None:
            self.store.assert_fact(rel, "has", attr="discipline_problem", value="; ".join(problems)[:500])
        if self.queue is None:
            return
        from warp2.work.queue import Refused
        try:
            self.queue.offer(item_id=f"work:revise:{rel}", kind="revise", target=rel, rank=0.9,
                             verification="the file keeps the tree's discipline: pathway, "
                                          "header and an intention note on every part")
        except Refused:
            pass

    def _tell(self, files: list, found: dict, unlogged: bool) -> None:
        """Intention: Andrew sees it in the Action Centre, in plain words."""
        lines = [f"{len(files)} of my own files changed since the last run."]
        for rel, problems in sorted(found.items()):
            lines.append(f"- {rel}: {problems[0]}" + (f" (+{len(problems) - 1} more)" if len(problems) > 1 else ""))
        if unlogged:
            lines.append("The build log was not updated with them.")
        try:
            from warp2.ask.thread import Thread, WARP
            Thread(self.state).add(WARP, "\n".join(lines), system=True, grounds=f"source check {now_iso()[:19]}")
        except Exception as exc:
            noted("warp2/integrity/source_watch.py:ChangedSourceCheck._tell", exc)
