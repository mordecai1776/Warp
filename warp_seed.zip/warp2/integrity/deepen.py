# WARP2/warp2/integrity/deepen.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/integrity/deepen.py
#  Used by   : the loop, when something it made comes back failing; a person,
#              through `python -m warp2.run why <thing>`.
#  Uses      : warp2/integrity/twin.py, warp2/store/store.py (read only),
#              warp2/settings.py.
#  Description:
#    Root-cause probing on a measured weakness. It produces hypotheses and what
#    would settle each one — never a change, never a background watcher.
#  User intention (Andrew):
#    Diagnostic probing on measured weakness, without mutating anything and
#    without spawning a watcher. A guess that says how to test itself is worth
#    something; a guess that acts on itself is a second unaccountable writer.
# ============================================================================
from __future__ import annotations

import ast

from warp2.integrity.twin import look
from warp2.settings import number

# How many times a thing must have failed before its history counts as a
# pattern rather than as bad luck.
A_PATTERN_IS = number("WARP2_DEEPEN_PATTERN", 2, minimum=1)

SEVERE = "severe"
MODERATE = "moderate"
MINOR = "minor"


def weakness(risk: int, failures: int) -> str:
    """How bad it is, in one word, from two numbers.

    Intention: severity is not a fourth score. It is a reading of the two that
    already exist plus how often this has happened, so nothing new has to be
    measured for it to be sayable.
    """
    if risk >= 700 or failures >= int(A_PATTERN_IS) * 2:
        return SEVERE
    if risk >= 350 or failures >= int(A_PATTERN_IS):
        return MODERATE
    return MINOR


def probe(thing, text: str = "", failures=(), declared: int | None = None) -> dict:
    """Why is this weak, and what would settle each guess.

    Intention: EVERY HYPOTHESIS CARRIES ITS OWN TEST. A root cause nobody can
    check is a story, and a system that tells itself stories about its failures
    will keep having them. Nothing here changes anything: it reads, it guesses,
    and it says how to find out.
    """
    history = list(failures or ())
    scores = look(text if text else thing, declared=declared)
    found = []

    if scores["confidence"] < 100 and scores["signals"]["confidence"].get("parses") is False:
        found.append(_guess(
            "it does not parse",
            "nothing downstream of this has ever run, so every later failure "
            "about it is about this and not about itself",
            "parse it and read the first error"))
    for note in _shapes(text):
        found.append(note)
    if scores["signals"]["confidence"].get("overconfident"):
        found.append(_guess(
            "the maker did not look at what it made",
            f"declared {scores['signals']['confidence']['declared']}, "
            f"measures {scores['confidence']}",
            "compare the declared score against the measured one over several "
            "attempts — if the gap is constant it is the maker, not the work"))
    if len(history) >= int(A_PATTERN_IS):
        same = {str(one.get("why") or one) for one in history}
        if len(same) == 1:
            found.append(_guess(
                "it fails the same way every time",
                f"{len(history)} attempts, one complaint: {sorted(same)[0][:120]}",
                "no edit to this has changed the outcome, so the fault is "
                "probably in what it is being asked for, not in the answer"))
        else:
            found.append(_guess(
                "it fails differently every time",
                f"{len(history)} attempts, {len(same)} different complaints",
                "the thing is unstable rather than wrong in one place — look "
                "at what changes between attempts, not at the file"))

    return {
        "risk": scores["risk"],
        "confidence": scores["confidence"],
        "complexity": scores["complexity"],
        "failures": len(history),
        "weakness": weakness(scores["risk"], len(history)),
        "caught": scores["caught"],
        "guesses": found,
        # Intention: THE HONEST EMPTY ANSWER. "Nothing here looks wrong" is a
        # real finding, and a prober that always produces something is a
        # prober nobody can believe when it produces the right thing.
        "says": (found[0]["guess"] if found else
                 "nothing about this looks wrong from here"),
    }


# Intention: the shapes that are wrong on sight, each with what settles it.
# Read from the text, because a thing's own body is the cheapest evidence
# there is and needs nothing else to be available.
def _shapes(text: str) -> list:
    if not text:
        return []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    found = []
    swallowed = [node for node in ast.walk(tree)
                 if isinstance(node, ast.ExceptHandler)
                 and all(isinstance(one, ast.Pass) for one in node.body)]
    if swallowed:
        found.append(_guess(
            "a failure is being swallowed",
            f"{len(swallowed)} handler(s) that do nothing",
            "remove one and run it — if the behaviour changes, that handler "
            "was hiding the real fault"))
    broad = [node for node in ast.walk(tree)
             if isinstance(node, ast.ExceptHandler)
             and (node.type is None
                  or (isinstance(node.type, ast.Name) and node.type.id == "Exception"))]
    if broad:
        found.append(_guess(
            "it catches everything",
            f"{len(broad)} handler(s) catching Exception or bare",
            "name the errors it means — anything else it catches is a fault "
            "it was never written to survive"))
    globals_written = [node for node in ast.walk(tree) if isinstance(node, ast.Global)]
    if globals_written:
        found.append(_guess(
            "it writes to state outside itself",
            f"{len(globals_written)} global statement(s)",
            "run it twice in one process — if the second run behaves "
            "differently, the state between them is the fault"))
    return found


# Intention: ONE SHAPE FOR EVERY GUESS, so no hypothesis can be written
# without saying what would settle it. The shape is the rule — a guess with no
# test is not expressible here, rather than merely discouraged.
def _guess(guess: str, because: str, settle_it: str) -> dict:
    return {"guess": guess, "because": because, "settled_by": settle_it}
