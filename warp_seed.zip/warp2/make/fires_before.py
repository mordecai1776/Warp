# WARP2/warp2/make/fires_before.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/fires_before.py
#  Used by   : warp2/make/{stage,eye_makers}.py.
#  Uses      : warp2/make/ledger.py, warp2/chat_learning/certainty.py
#              (through the ledger's bounds).
#  Description:
#    What fires before each of the Eye's parts. Every stage fires its agents
#    and makers in order; for the Eye's part at that level, each model that
#    fired before it is counted, run by run, as having come before a pass or
#    not. When a model has come before the part's passes in more than half of
#    all its runs — measured, at one spread below its record, so a few lucky
#    runs are not enough — it is joined to the part: from then on, wherever
#    the part is used, what that model said is part of what the part reads,
#    and the two are taught together through the warp.
#  User intention (Andrew, 2026-09-24): "when the eye trains smaller parts and
#    places them into the master and the smaller parts find that a model is
#    triggered before them in the activation enough times it should add those
#    models in where the smaller parts are used in other places and trained
#    through the warp."
# ============================================================================
from __future__ import annotations

import math

# Intention: the ledger kind for one part's record of what came before it.
BEFORE = "before:"


def record(ledger, part: str, fired: list, passed: bool, everyone: list) -> None:
    """Intention: for every model there is, whether it fired before this part on a run that passed."""
    fired = set(m for m in fired if m)
    for model in everyone:
        ledger.add(BEFORE + part, model, "*", 1.0 if (model in fired and passed) else 0.0)


def joined(ledger, part: str, everyone: list) -> list:
    """Intention: the models joined to this part — above half, at their low bound."""
    out = []
    for model in everyone:
        low, _high = ledger.bounds(BEFORE + part, model, "*")
        if not math.isinf(low) and low > 0.5:
            out.append(model)
    return sorted(out)
