# WARP2/warp2/make/final_eval.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/final_eval.py
#  Used by   : warp2/make/cycle.py.
#  Uses      : warp2/gate/contracts.py (the gate's whole contract for the
#              kind), warp2/make/{judges,ledger,trust}.py,
#              warp2/chat_learning/tagging.py (agree — the tags most of the
#              judges' trust gave).
#  Description:
#    The evaluation of the entire thing. Before the file is written: the
#    gate's whole contract, then every model judges and tags the whole file
#    (the one big lump, always all of them). After the loop has written and
#    proven it: how it really turned out flows back to every model and role
#    that took part — each judge by how near its score was to the outcome,
#    each tagger by whether its tags were right and how many were agreed,
#    each judge's right-or-wrong call by whether it was, each role by the
#    outcome — and that is what trust is measured from.
#  User intention (Andrew, 2026-09-24): "there should be a final evaluation of
#    the entire thing. All models should give tags."
# ============================================================================
from __future__ import annotations

from warp2.make.judges import Judges
from warp2.make.ledger import FINAL, JUDGED, RIGHT, TAGGED

WHOLE = "whole"


def before_writing(ctx, job, code: str) -> dict:
    """Intention: {passed, score, gate, verdict} for the whole file, before it is written."""
    from warp2.gate.contracts import contract_for
    contract = contract_for(job.row.get("kind") or "build")
    context = dict((ctx.sliced or {}).get("context") or {})
    complaints = [said for _n, said in contract.complaints(code, context) if said] if contract else []
    checks = sorted({c for n in job.nodes.values() for c in n.get("checks", [])})
    target = str(job.row.get("path") or job.row.get("target") or job.row.get("item") or "")
    verdict = Judges(ctx.fleet, ctx.ledger).judge(WHOLE, job.row["target"], code, checks,
                                                 context=job.row.get("understood", ""), everyone=True,
                                                 target=target)
    return {"passed": verdict["passed"] and not complaints, "score": verdict["score"],
            "gate": complaints, "verdict": verdict}


def after_settling(ctx, job, outcome: float) -> dict:
    """Intention: how it really turned out, fed back to every judge, tagger and role."""
    from warp2.chat_learning.tagging import agree
    from warp2.make.agents.who import played
    ledger, judged, tagged = ctx.ledger, 0, 0
    # Intention (2026-10-09, fix 5.5, check D11): each verdict is counted once,
    # against the first outcome after it. A job settled "not done" goes back
    # to making with its verdicts kept, and the next settling counted them
    # all again, so trust grew from the same verdicts over and over.
    verdicts = [(n["level"], v) for n in job.nodes.values() for v in n.get("verdicts", {}).values()
                if not v.get("settled")]
    final = job.row.get("final", {}).get("verdict")
    if final and not final.get("settled"):
        verdicts.append((WHOLE, final))
    for level, verdict in verdicts:
        verdict["settled"] = True
        for model, score in verdict.get("by", {}).items():
            ledger.add(JUDGED, model, level, 1.0 - abs(float(score) - outcome))
            judged += 1
        # Intention: A TAG IS JUDGED BY WHETHER IT WAS RIGHT (Andrew,
        # 2026-09-24). A tag's weight says the answer does a thing (above 0)
        # or fails at it (below 0); it was right when that matches how the
        # work really turned out. Half of a tagger's record is that, half is
        # agreeing with the others — so a lone tagger who is right still
        # counts, and a crowd that is wrong together does not.
        agreed = {t["name"] for t in agree(verdict.get("tags", {}), {})}
        for model, tags in verdict.get("tags", {}).items():
            names = {t["name"] for t in tags}
            if names:
                right = sum(1 for t in tags if (float(t.get("weight", 1.0)) >= 0) == (outcome >= 0.5))
                ledger.add(TAGGED, model, level,
                           0.5 * right / len(tags) + 0.5 * len(names & agreed) / len(names))
                tagged += 1
        for model, said_right in verdict.get("rights", {}).items():
            ledger.add(RIGHT, model, level, 1.0 if bool(said_right) == (outcome >= 0.5) else 0.0)
    for node in job.nodes.values():
        # Intention (2026-10-09, fix 5.5): each role played is counted once too —
        # who was counted is kept, so a role played again by a model is new.
        counted = node["data"].setdefault("roles_settled", {})
        for role in ("research", "socratic", "problems", "kg"):
            by = node["data"].get(f"{role}_by", "")
            if by and counted.get(role) != by:
                played(ledger, {"problems": "common_problems", "kg": "kg_plan"}.get(role, role), by, outcome)
                counted[role] = by
    ledger.add(FINAL, job.row.get("kind") or "build", "*", outcome)
    return {"judges": judged, "taggers": tagged, "outcome": outcome}
