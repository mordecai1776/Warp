# WARP2/warp2/make/scoring.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/scoring.py
#  Used by   : warp2/make/judges.py.
#  Uses      : warp2/chat_learning/asking.py (json_in),
#              warp2/chat_learning/tagging.py (parse_tags — the same formed
#              tags the chat learning keeps).
#  Description:
#    What a judge is asked, and what is read back from its answer: one score
#    from 0 to 1, whether it is right, which items of a list are wrong, and
#    the tags it gives. An answer with no score it could give counts as no
#    judgement at all, not as a zero; one that does not say right or wrong is
#    read as right when its score is above one half.
#    The same work can also be asked as one yes/no question (yes_prompt),
#    read from the judge's token chances — the fixed-option path of item f.
#  User intention (Andrew, 2026-09-24): "Then a set of models will all score
#    their work and give tags."
# ============================================================================
from __future__ import annotations

from warp2.chat_learning.asking import json_in
from warp2.chat_learning.tagging import parse_tags

PROMPT = (
    "You are judging one piece of work.\n\n"
    "The work was: {level} — {what}\n\n"
    "{context}"
    "Things it must get right:\n{checks}\n\n"
    "The answer given:\n{answer}\n\n"
    "Score it from 0 to 1: 1 when it fully and correctly does what was asked, "
    "0 when it does not do it at all or is wrong. Check each thing it must get right.\n"
    "Say plainly whether it is right. If the answer is a list, say which items in it are wrong "
    "(counting from 1).\n"
    "Then give tags: short names for what the answer is or does, each with a weight from -1 to 1 "
    "(below 0 when the answer fails at it).\n"
    "Answer only with one JSON object shaped like this example, with your own judgement in it:\n"
    '{{"score": 0.7, "right": true, "wrong_items": [2], "why": "item 2 is already known", '
    '"tags": [{{"name": "fills a real gap", "says": "item 1", "why": "nothing above answers it", '
    '"weight": 0.8}}]}}')

# Intention: the example's own words — a judge that copies the example back
# has judged nothing, so tags carrying these are dropped (MEASURED on the live
# run 2026-09-24: tags named "a short concept the answer is or does").
_COPIED = ("a short concept", "fills a real gap", "what in it shows", "why it matters")


# Intention (item f, 2026-10-17): THE FIXED-OPTION QUESTION. The same work,
# context and checks as PROMPT — the same opening, so a service that keeps
# the prompt it has already read does not read it twice — then one question
# answered with one word, whose chance of "yes" is the judge's score.
YES_PROMPT = (
    "You are judging one piece of work.\n\n"
    "The work was: {level} — {what}\n\n"
    "{context}"
    "Things it must get right:\n{checks}\n\n"
    "The answer given:\n{answer}\n\n"
    "Does the answer fully and correctly do what was asked, getting each of those things right? "
    "Answer with one word: yes or no.")


def yes_prompt(level: str, what: str, answer: str, checks: list, context: str = "") -> str:
    """Intention: the fixed-option question on the same work, the checks listed as in `prompt`."""
    listed = "\n".join(f"- {c}" for c in checks) or "- nothing extra"
    return YES_PROMPT.format(level=level, what=what, answer=answer, checks=listed,
                             context=f"What is known:\n{context}\n\n" if context else "")


def prompt(level: str, what: str, answer: str, checks: list, context: str = "") -> str:
    """Intention: the judge's prompt; the checks listed one a line, or 'nothing extra'."""
    listed = "\n".join(f"- {c}" for c in checks) or "- nothing extra"
    return PROMPT.format(level=level, what=what, answer=answer, checks=listed,
                         context=f"What is known:\n{context}\n\n" if context else "")


def _objects(text: str) -> list:
    """Every balanced {...} in the text, last first.

    Intention: MODELS THAT THINK OUT LOUD. A model that writes its reasoning
    (a <think> block, or prose with braces in it) before its JSON made the
    first-to-last-brace read fail — MEASURED on the live run 2026-09-24: of 8
    judges only 3 answers could be read. Each balanced object is tried, the
    last first, since the answer comes after the thinking.
    """
    import re
    text = re.sub(r"(?s)<think>.*?</think>", " ", str(text or ""))
    found, depth, start, quoted, escaped = [], 0, -1, False, False
    for at, ch in enumerate(text):
        if quoted:
            escaped = (ch == "\\") and not escaped
            if ch == '"' and not escaped:
                quoted = False
            continue
        if ch == '"':
            quoted = True
        elif ch == "{":
            depth += 1
            if depth == 1:
                start = at
        elif ch == "}" and depth:
            depth -= 1
            if depth == 0 and start >= 0:
                found.append(text[start:at + 1])
    return found[::-1]


def _python_literal(candidate: str):
    """Intention: a dict written as Python (True/False/None, single quotes), or None; never runs code."""
    import ast
    try:
        got = ast.literal_eval(candidate)
    except (ValueError, SyntaxError, MemoryError, RecursionError):
        return None
    return got if isinstance(got, dict) else None


def read(text: str) -> dict | None:
    """Intention: {score, right, wrong_items, why, tags} out of a judge's answer, or None when it gave no score."""
    import json
    found = None
    for candidate in _objects(text):
        try:
            got = json.loads(candidate)
        except ValueError:
            # Intention (2026-10-08): SOME JUDGES WRITE PYTHON, NOT JSON —
            # `"right": True` (measured in the make jobs: moondream's and
            # candidate_fast_coder's verdicts were all "unread" for this one
            # word). A judge that cannot be read can never earn trust, so the
            # same dict is read as a Python literal before it is given up on.
            got = _python_literal(candidate)
            if got is None:
                continue
        if isinstance(got, dict) and "score" in got:
            found = got
            break
    if found is None:
        found = json_in(text, "{", "}")
    if not isinstance(found, dict):
        return None
    try:
        score = max(0.0, min(1.0, float(found.get("score"))))
    except (TypeError, ValueError):
        return None
    import json
    right = found.get("right")
    right = right if isinstance(right, bool) else (score > 0.5)
    wrong = []
    for n in found.get("wrong_items") or []:
        try:
            wrong.append(int(n))
        except (TypeError, ValueError):
            continue
    tags = [t for t in parse_tags(json.dumps(found.get("tags") or []))
            if not any(t["name"].startswith(c) for c in _COPIED)]
    why = str(found.get("why") or "")
    if why == "item 2 is already known":
        return None
    return {"score": score, "right": right, "wrong_items": sorted(set(w for w in wrong if w > 0)),
            "why": why, "tags": tags}
