# WARP2/warp2/make/judges.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/judges.py
#  Used by   : warp2/make/{stage,final_eval}.py.
#  Uses      : warp2/make/{scoring,trust,step_trust,ledger}.py,
#              warp2/chat_learning/asking.py (ask — one model, one prompt),
#              warp2/make/eye_judge.py (the Eye's votes: master and combined
#              parts),
#              warp2/train/outputs.py (through the fleet's `outputs`: the
#              judged work and each judge's own answer, graded),
#              warp2/wise_men/tally.py (heard_enough — the one quorum rule),
#              warp2/models/backends.py (Unreachable — a judge that could
#              not be asked at all).
#  Description:
#    Several models judge one answer: each gives a score, whether it is right,
#    which items of a list are wrong, and tags. The
#    verdict is the mean of the scores, each counted 1 + its judge's trust,
#    so an untried judge still counts and a proven one counts more; it passes
#    when that is above one half AND more than half of the judges' weight says
#    it is right, AND the judges who gave a readable verdict (the Eye's
#    votes included) hold more than half of the panel's weight — the same
#    quorum as the 3 wise men. Items most of the weight calls wrong are named. The maker of an answer never
#    judges its own. How many are asked is tempered by trust: once the
#    verdict can no longer change, each judge still waiting is asked with a
#    chance of one less the pool's trust — so with no trusted judges (now)
#    every model judges and tags, and as they earn trust the asking thins
#    and moves to the final evaluation, where all are always asked.
#    Each judge's score and right-or-wrong are read first from its token
#    chances on one yes/no question (the fixed-option path, item f), so they
#    cannot be unreadable; the text answer still gives tags, reasons and
#    wrong items. A judge with no token chances is read from its text, and
#    every verdict says which path it used ("paths"). When both paths give
#    a reading on the same call, both are kept ("readings", and in each
#    judge's graded line), so how far the two agree is measured, not argued.
#    A judge that could not be asked at all (its chance call raised
#    Unreachable and its text came back empty) is SKIPPED, like a judge the
#    thinning passed over: it is not listed as unreadable and not graded as
#    a failed judge, because "did not answer" is not "answered badly"
#    (backends.Unreachable). Its weight stays in the panel, as a skipped one's
#    does, so the quorum rule is unchanged. Verdicts list them ("skipped").
#  User intention (Andrew, 2026-09-24): "All models should give tags."
#    (2026-10-16, item f): "JUDGES BY FIXED-OPTION SCORING" — score the
#    fixed options directly; keep the text path only where logprobs are not
#    available, and record which path each verdict used. "as
#    the models get more capable the tag phase should be more shifted to the
#    end in one big lump to speed it up".
# ============================================================================
from __future__ import annotations

import hashlib

from warp2.chat_learning.asking import ask
from warp2.make import scoring, step_trust
from warp2.models.backends import Unreachable
from warp2.record.swallowed import noted
from warp2.wise_men.tally import heard_enough

# Intention: the score an answer must pass — more right than wrong.
PASS = 0.5


def _still_asked(answer: str, model: str, pool_trust: float) -> bool:
    """Intention: a steady draw, the same for the same answer and judge, below 1 - trust."""
    draw = int(hashlib.sha256(f"{answer}|{model}".encode("utf-8")).hexdigest()[:8], 16) / 0xFFFFFFFF
    return draw >= pool_trust


def _settled(scores: dict, weights: dict, waiting: float) -> bool:
    """Intention: whether the judges not yet asked could still move the verdict across PASS."""
    total = sum(weights[m] for m in scores)
    if not total:
        return False
    lean = sum(weights[m] * (scores[m] - PASS) for m in scores)
    return abs(lean) > waiting * max(PASS, 1.0 - PASS)


class Judges:
    """Every model a judge; the verdict weighted by what each has earned."""

    def __init__(self, fleet, ledger, state_dir=None) -> None:
        """Intention: the fleet asks; the ledger says how far each judge is trusted; with a state, the Eye judges too."""
        self.fleet = fleet
        self.ledger = ledger
        self.state_dir = state_dir

    def eye_votes(self, level: str, seen, answer: str, maker: str) -> dict:
        """The Eye's votes on this answer, none from the maker itself; {} when the Eye cannot vote.

        Intention: THE EYE IS A JUDGE LIKE ANY OTHER (Andrew, 2026-09-25) —
        its master and its combined parts (warp2/make/eye_judge.py), each
        weighted by the trust its record earns, and never grading itself.
        Asking it must never be what stops the others' verdict.
        """
        if self.state_dir is None or seen is None:
            return {}
        try:
            from warp2.make.eye_judge import votes
            return {k: v for k, v in votes(self.state_dir, level, seen, answer).items() if k != maker}
        except Exception:
            return {}

    def pool(self, maker: str = "", level: str = "*") -> list:
        """Intention: every model but the maker, most trusted first — trusted at this level.

        (2026-10-09, fix 5.5, check D9): trust is written by level and was read
        at "*", which nothing writes, so the order was alphabetical.
        """
        names = [n for n in self.fleet.names() if n != maker] if self.fleet is not None else []
        return sorted(names, key=lambda n: (-step_trust.of(self.ledger, n, level), n))

    def _keep(self, level, what, answer, maker, score, scores, right, wrong_items, why, heard_by, total,
              passed, readings=None, target: str = "") -> None:
        """The judged work and every judge's own answer, graded in the record of everything.

        Intention: THE TEMPERATURE OF THE WORK (Andrew, 2026-09-25: "how good
        or bad it has done according to all other models who's output should
        be weighted by their competence in said thing") — the score here is
        already weighted by each judge's trust at this level. And each judge
        is graded too: how near its own score came to that weighted verdict,
        and whether it could be read at all — so a judge is taught by being
        right, like everything else. `target` keeps the file or item id the
        work belongs to so the vote can be paired with its later gate/check
        outcome (relay claude-31..33 / muse-53..55).
        """
        outputs = getattr(self.fleet, "outputs", None)
        if outputs is None:
            return
        try:
            faults = [f"item {n} was called wrong by most of the judges' weight" for n in wrong_items]
            faults += [f"{m}: {w}" for m, w in why.items() if w and scores.get(m, 1.0) <= PASS]
            outputs.graded_answer(maker or "unknown", answer, passed=passed,
                                  score=score if total else None, faults=faults, by=scores,
                                  how="judges", kind=f"judged:{level}", about=str(what),
                                  target=str(target or ""))
            for model, heard in heard_by.items():
                read = model in scores
                outputs.graded_answer(model, heard, passed=read,
                                      score=(1.0 - abs(float(scores[model]) - float(score))) if read else 0.0,
                                      faults=[] if read else ["its judgement could not be read"],
                                      how="judge, against the weighted verdict", kind=f"judge:{level}",
                                      about=str(what), readings=(readings or {}).get(model),
                                      target=str(target or ""))
            if faults and not passed and self.state_dir is not None:
                from warp2.store.store import Store, store_home
                from warp2.train.mistakes import Mistakes

                mark_target = str(target or f"judged:{level}:{maker or 'unknown'}")
                store = Store(store_home(self.state_dir))
                try:
                    Mistakes(store).note(
                        mark_target,
                        "; ".join(faults[:3]),
                        stamped_by=f"judges:{level}",
                        appeal_check="re-run multi-party judge panel or verification check on current bytes",
                    )
                finally:
                    store.close()
        except Exception as exc:
            noted("warp2/make/judges.py:Judges._keep", exc)

    def judge(self, level: str, what: str, answer: str, checks: list, maker: str = "",
              context: str = "", everyone: bool = False, seen=None, target: str = "") -> dict:
        """The verdict on one answer: {score, passed, by, tags, why}.

        Intention: `everyone` asks every judge whatever trust says — the
        final evaluation's one big lump, and the KG wiring plan — and the
        maker gives its tags too (not its score).
        """
        judges = self.pool(maker, level)
        # Intention (2026-10-08): trust earned at each step counts too (warp2/make/step_trust.py).
        weights = {m: 1.0 + step_trust.of(self.ledger, m, level) for m in judges}
        pool_trust = 0.0 if everyone else step_trust.pool(self.ledger, judges, level)
        asked = scoring.prompt(level, what, answer, checks, context)
        yes_asked = scoring.yes_prompt(level, what, answer, checks, context)
        scores, tags, why, rights, wrong, unread = {}, {}, {}, {}, {}, {}
        # Intention (item f): which path each verdict was read by — "options" or "text".
        paths = {}
        # Intention (relay muse-23): every reading each judge gave — the
        # chance and the text score side by side when both came back.
        readings = {}
        # Intention: what each judge said, word for word, so its own answer is graded as itself.
        heard_by = {}
        # Intention: judges that could not be asked at all, and why (counted as skipped).
        skipped = {}
        for at, model in enumerate(judges):
            waiting = sum(weights[m] for m in judges[at:])
            # Intention (2026-10-16): asking thins only once a quorum has been
            # heard — trust may cut the asking, never below half the panel.
            if (scores and _settled(scores, weights, waiting)
                    and heard_enough({"voters": list(scores)}, weights)
                    and not _still_asked(answer, model, pool_trust)):
                continue
            heard = ask(self.fleet, model, asked)
            heard_by[model] = heard
            said = scoring.read(heard)
            sure, reached = self._reading(model, yes_asked)
            if said is None and not reached:
                # Intention (Unreachable counted as skipped): nobody was there
                # to ask — not an unreadable answer, so the judge is neither
                # listed as unread nor graded as a failed judge.
                heard_by.pop(model, None)
                skipped[model] = "could not be asked"
                continue
            readings[model] = {k: v for k, v in (("options", sure),
                                                 ("text", said["score"] if said else None))
                               if v is not None}
            if sure is not None:
                # Intention (item f): THE FIXED OPTIONS DECIDE. The score is the
                # judge's chance of "yes"; the text, when it can be read, still
                # gives the tags, the reasons and the wrong items.
                said = said or {"tags": [], "why": "", "wrong_items": []}
                said = dict(said, score=sure, right=sure > PASS)
                paths[model] = "options"
            elif said is not None:
                paths[model] = "text"
            if said is None:
                # Intention: a judge whose answer could not be read says so, with
                # what it said, so a model that never answers usably can be seen.
                unread[model] = " ".join(str(heard).split())[:200] or "(said nothing)"
                continue
            scores[model], tags[model], why[model] = said["score"], said["tags"], said["why"]
            rights[model], wrong[model] = said["right"], said["wrong_items"]
        # Intention: AND THE EYE'S VOTES (`seen` is the work as the Eye reads it).
        for voter, share in self.eye_votes(level, seen, answer, maker).items():
            weights[voter] = 1.0 + step_trust.of(self.ledger, voter, level)
            scores[voter], rights[voter], wrong[voter] = float(share), float(share) > PASS, []
        # Intention: WHEN EVERY MODEL IS ASKED, THE MAKER TAGS ITS OWN WORK TOO —
        # its tags join everyone's, but its score is never counted: no model
        # grades itself (Andrew, 2026-09-24: "it should have its plan tagged by
        # all of the models").
        if everyone and maker and self.fleet is not None and maker in self.fleet.names():
            own = scoring.read(ask(self.fleet, maker, asked))
            if own is not None:
                tags[maker], why[maker] = own["tags"], own["why"]
        total = sum(weights[m] for m in scores)
        score = sum(weights[m] * scores[m] for m in scores) / total if total else 0.0
        # Intention: RIGHT OR WRONG IS ITS OWN JUDGEMENT (Andrew, 2026-09-24:
        # "The tag thing should also judge weather it was right"). It passes
        # only when the weighted judges both score it above one half and say
        # it is right; an item most of their weight calls wrong is named.
        right = sum(weights[m] for m in scores if rights.get(m)) / total if total else 0.0
        items: dict = {}
        for model, numbers in wrong.items():
            for n in numbers:
                items[n] = items.get(n, 0.0) + weights[model]
        wrong_items = sorted(n for n, w in items.items() if total and w / total > PASS)
        # Intention (2026-10-16, phase 7 finding): A VERDICT NEEDS A QUORUM.
        # One judge out of many, or the Eye's votes alone while the models
        # could not be read, used to pass work. Now the judges heard must hold
        # more than half of the panel's weight (every judge asked or skipped,
        # plus the Eye's voters) — the rule the 3 wise men already keep.
        quorum = heard_enough({"voters": list(scores)}, weights)
        passed = bool(scores) and quorum and score > PASS and right > PASS
        self._keep(level, what, answer, maker, score, scores, right, wrong_items, why, heard_by, total,
                   passed, readings, target=target)
        return {"score": round(score, 4), "right": round(right, 4), "quorum": quorum,
                "passed": passed,
                "wrong_items": wrong_items, "rights": rights, "unread": unread,
                "paths": paths, "readings": readings, "skipped": skipped, "by": scores, "tags": tags, "why": why}

    def _chance(self, model: str, prompt: str) -> float | None:
        """The judge's chance of "yes" on the fixed-option question, or None to read its text.

        Intention (item f): a fleet without token chances (or a judge that gave
        none, or could not be asked) is read by the text path, as before; one
        judge's trouble never stops the others.
        """
        return self._reading(model, prompt)[0]

    def _reading(self, model: str, prompt: str) -> tuple:
        """(the judge's chance of "yes" or None, whether the judge could be asked at all).

        Intention (judge fix, Unreachable counted as skipped): the same
        reading as `_chance`, but a call that raised `Unreachable` says the
        model could not be asked, so the judge can be skipped rather than
        charged with an unreadable verdict. Any other failure is a judge
        that was there and gave nothing readable, as before.
        """
        reader = getattr(self.fleet, "chance", None)
        if reader is None:
            return None, True
        try:
            return reader(model, prompt), True
        except Unreachable as exc:
            noted("warp2/make/judges.py:Judges._reading", exc)
            return None, False
        except Exception as exc:
            noted("warp2/make/judges.py:Judges._chance", exc)
            return None, True
