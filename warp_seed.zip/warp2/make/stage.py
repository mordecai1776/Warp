# WARP2/warp2/make/stage.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/stage.py
#  Used by   : warp2/make/cycle.py (one step of one node, each pass).
#  Uses      : warp2/make/agents/{research,socratic,common_problems,kg_plan,who}.py,
#              warp2/make/{levels,ladder,eye_makers,judges,limits,repeats,
#              library,lessons,trust,ledger,job,fires_before,agent_review,
#              prompt_keeper}.py, warp2/tags/apply.py (the make family, via store.applier),
#              warp2/tags/dehydrate.py (the Eye reads the context as dehydrated tags).
#  Description:
#    One stage, the same at every level, one step a pass:
#      research → Socratic → wait for the research → common problems →
#      make (three makers) → judge and tag → record.
#    A common problem not met before sends the stage back to its research
#    with the problem marked. A stage that does not pass goes back to its
#    research with why it failed; after as many tries as passes here have
#    taken, the models' maker climbs to the next rung (code, then models from
#    the smallest up); past the last rung a part is broken down again, and
#    past that the node waits for a training round. Every settled stage is a
#    lesson, pass or fail.
#  User intention (Andrew, 2026-09-24): the cycle as he set it out — "a
#    research agent ... Then the Socratic agent and a common problem agent ...
#    Then a set of models will all score their work and give tags. If that
#    fails it restarts to a limit like before, if not it adds the things to
#    the kg and all of its actions are added to the kg as training."
# ============================================================================
from __future__ import annotations

import hashlib

from warp2.make import eye_makers, fires_before, ladder, levels, limits, repeats, trust
from warp2.make.agent_review import reviewer
from warp2.make.agents import common_problems, kg_plan, research, socratic
from warp2.make.agents.who import ROLE
from warp2.make.job import BREAKDOWN, DONE, FAILED, OPEN, PART, WAITING, new_node
from warp2.make.judges import Judges
from warp2.make.ledger import MADE
from warp2.make.lessons import Lessons
from warp2.make.library import Library

# Intention: the steps of a stage, in order.
STEPS = ("research", "socratic", "wait", "problems", "make", "judge", "record")

# Intention: the models' maker, as the ledger knows it beside the Eye's two.
MODELS = "models"


def _skipped(ctx, role: str, node: dict) -> bool:
    """Intention: a step asked less as its role earns trust — a steady draw below the role's trust."""
    level = trust.pool(ctx.ledger, ROLE + role, list(ctx.fleet.names()) if ctx.fleet is not None else [])
    draw = int(hashlib.sha256(f"{node['id']}|{node['attempt']}|{role}".encode("utf-8")).hexdigest()[:8], 16)
    return draw / 0xFFFFFFFF < level


def _agent_score(node: dict, role: str) -> str:
    """Intention: what the other models made of an agent's work, as a short note for the step's line."""
    verdict = node["data"].get("agent_verdicts", {}).get(role)
    if not verdict or not verdict.get("by"):
        return ""
    tags = sorted({t["name"] for ts in verdict.get("tags", {}).values() for t in ts})[:4]
    unread = len(verdict.get("unread", {}))
    return (f" (the others scored it {verdict['score']:.2f} from {len(verdict['by'])} model(s)"
            + (f", {unread} answer(s) could not be read" if unread else "")
            + ("" if verdict["passed"] else " — turned down") + (f"; tags: {', '.join(tags)}" if tags else "") + ")")


def _open_needs(ctx, node: dict) -> int:
    """Intention: how many of this node's needs are still open."""
    from warp2.research.need import OPEN as NEED_OPEN
    count = 0
    for need in node["needs"]:
        facts = ctx.store.current(subject=need, attr="state")
        if facts and facts[0]["value"] == NEED_OPEN:
            count += 1
    return count


def _joined(ctx, node) -> list:
    """Intention: the models joined to this level's Eye part (warp2/make/fires_before.py)."""
    everyone = list(ctx.fleet.names()) if ctx.fleet is not None else []
    return fires_before.joined(ctx.ledger, eye_makers.part_name(node["level"]), everyone)


def _ladder(ctx, job, node) -> list:
    """Intention: this node's ladder of rungs, certainly-worse rungs stepped over."""
    kind = job.row.get("kind") or "build"
    return ladder.climbable(ctx.ledger, node["level"],
                            ladder.rungs(ctx.fleet, kind, levels.has_code(node["level"])))


def _model_rungs(ctx, job, node, every=None) -> list:
    """Intention (BUILD_LOG 931): the ladder without the Eye's rungs — what `node["rung"]` indexes."""
    return [r for r in (every if every is not None else _ladder(ctx, job, node)) if r not in ladder.EYE_RUNGS]


def step(ctx, job, node) -> str:
    """Take one step of this node's stage; say what was done."""
    name = STEPS[node["step"]]
    return globals()["_" + name](ctx, job, node)


def _target(ctx, job) -> str:
    """Intention: the file or item id this job makes, so every vote can be joined to its gate outcome."""
    return str(job.row.get("path") or job.row.get("target") or ctx.about(job.row) or "")


def _research(ctx, job, node) -> str:
    """Intention: the research agent calls for what must be looked up."""
    node["step"] += 1
    if _skipped(ctx, research.ROLE, node):
        return "research: asked less now it is trusted — skipped this time"
    said = research.call(ctx.fleet, ctx.ledger, ctx.needs, ctx.about(job.row), node["level"],
                         node["what"], ctx.known(node), turn=f"{node['id']}|{node['attempt']}",
                         review=reviewer(ctx, node, research.ROLE, target=_target(ctx, job)))
    node["needs"] += said["needs"]
    node["data"]["research_by"] = said["model"]
    node["data"]["research_heard"] = said["heard"]
    return (f"research: {said['model'] or 'no model'} asked for {len(said['needs'])} thing(s) to be looked up"
            + _agent_score(node, research.ROLE)
            + ("" if said["needs"] else f" — it said: {said['heard'][:90]}"))


def _socratic(ctx, job, node) -> str:
    """Intention: the Socratic agent questions the work; its doubts become research."""
    node["step"] += 1
    if _skipped(ctx, socratic.ROLE, node):
        return "socratic: asked less now it is trusted — skipped this time"
    said = socratic.call(ctx.fleet, ctx.ledger, ctx.needs, ctx.about(job.row), node["level"],
                         node["what"], ctx.known(node), turn=f"{node['id']}|{node['attempt']}",
                         review=reviewer(ctx, node, socratic.ROLE, target=_target(ctx, job)))
    node["needs"] += said["needs"]
    node["data"]["socratic_by"] = said["model"]
    node["data"]["socratic_heard"] = said["heard"]
    return (f"socratic: {said['model'] or 'no model'} raised {len(said['needs'])} doubt(s) to research"
            + _agent_score(node, socratic.ROLE)
            + ("" if said["needs"] else f" — it said: {said['heard'][:90]}"))


def _wait(ctx, job, node) -> str:
    """Intention: nothing is made until what was asked for has been looked up."""
    open_now = _open_needs(ctx, node)
    if open_now:
        node["status"] = WAITING
        node["why"] = f"waiting on {open_now} research question(s)"
        return f"wait: {open_now} research question(s) still open — the web lane is on them"
    node["step"] += 1
    return "wait: the research is in"


def _problems(ctx, job, node) -> str:
    """Intention: the common problem agent; a problem new to this node sends the stage back to research."""
    said = common_problems.call(ctx.fleet, ctx.ledger, ctx.needs, ctx.store, ctx.about(job.row),
                                node, ctx.known(node),
                                review=reviewer(ctx, node, common_problems.ROLE, target=_target(ctx, job)))
    node["data"]["problems_by"] = said["model"]
    if said["new"] and node["attempt"] + 1 < limits.limit(ctx.ledger, node["level"]):
        node["attempt"] += 1
        node["step"] = STEPS.index("wait")
        return f"problems: {len(said['new'])} new — marked, researched, and the stage tries again"
    node["step"] += 1
    return f"problems: {len(said['new'])} new, none left to stop it"


def _models_answer(ctx, job, node) -> tuple:
    """Intention: (answer, by, why) from the models' maker at its current rung."""
    every = _ladder(ctx, job, node)
    # Intention (BUILD_LOG 931): THE EYE'S RUNGS ARE ASKED FIRST, EVERY STEP, before the models' ladder is climbed —
    # the Eye is the smallest rung (warp2/make/ladder.py). An Eye rung the ledger has stepped over is not in `every`.
    # An Eye rung with no usable answer costs no try and no climb: the models' rung below answers in the same step,
    # and the Eye's own second making (`_make`) keeps judging and teaching it. `node["rung"]` counts the models'
    # rungs only, so the runner's "it climbed" reading (warp2/make/runner.py) keeps its meaning.
    for rung in (r for r in every if r in ladder.EYE_RUNGS):
        answer, why = eye_makers.answer(ctx.state, job.row, node, rung, _joined(ctx, node))
        if answer and not why and not repeats.is_repeat(node, answer) and not levels.usable(job, node, answer):
            return answer, rung, ""
    rungs = _model_rungs(ctx, job, node, every)
    while node["rung"] < len(rungs):
        rung = rungs[node["rung"]]
        if rung == ladder.CODE:
            made = levels.by_code(ctx, job, node)
            if made:
                return made, ladder.CODE, ""
            node["rung"] += 1
            continue
        refused = "; ".join(node.get("whys", [])[-2:])
        from warp2.make.prompt_keeper import PromptKeeper
        keeper = PromptKeeper(ctx.fleet)
        held = getattr(ctx.worker, "fleet", None)
        ctx.fleet = keeper
        if ctx.worker is not None:
            ctx.worker.fleet = keeper
        try:
            answer, why = levels.by_model(ctx, job, node, rung, refused)
        finally:
            ctx.fleet = keeper._fleet
            if ctx.worker is not None:
                ctx.worker.fleet = held
        node["data"]["asked"] = keeper.last.get(rung, "")
        return answer, rung, why
    return "", "", "every rung has been tried"


def _make(ctx, job, node) -> str:
    """Intention: every task made three times — the models, the Eye's parts, the Eye master."""
    made = {}
    answer, by, why = _models_answer(ctx, job, node)
    made[MODELS] = {"answer": answer, "by": by, "why": why}
    joined = _joined(ctx, node)
    node["answers"] = {MODELS: made[MODELS]}
    for which in (eye_makers.EYE_PARTS, eye_makers.EYE_MASTER):
        if by == which:
            # Intention (BUILD_LOG 931): this Eye maker was the models' rung this step — its answer is already made.
            made[which] = {"answer": answer, "by": which, "why": why}
            continue
        eye_answer, eye_why = eye_makers.answer(ctx.state, job.row, node, which, joined)
        made[which] = {"answer": eye_answer, "by": which, "why": eye_why}
    for maker, row in made.items():
        if not row["answer"] and not row["why"]:
            row["why"] = "there was no answer"
        if row["answer"] and not row["why"]:
            row["why"] = ("it gave again an answer that already failed here"
                          if repeats.is_repeat(node, row["answer"]) else levels.usable(job, node, row["answer"]))
    node["answers"] = made
    node["step"] += 1
    usable = [m for m, r in made.items() if r["answer"] and not r["why"]]
    said = f"make: {len(usable)} of 3 makers gave a usable answer ({', '.join(usable) or 'none'})"
    if MODELS not in usable:
        said += f" — {made[MODELS]['by'] or 'the models'}: {made[MODELS]['why'][:100]}"
    return said


def _judge(ctx, job, node) -> str:
    """Intention: every usable answer judged and tagged; the maker never judges its own."""
    judges = Judges(ctx.fleet, ctx.ledger, state_dir=ctx.state)
    # Intention: the work as the Eye reads it, so the Eye judges it too (warp2/make/eye_judge.py).
    seen = eye_makers.tags_of(job.row, node, _joined(ctx, node))
    node["verdicts"] = {}
    for maker, row in node["answers"].items():
        if row["answer"] and not row["why"]:
            node["verdicts"][maker] = judges.judge(node["level"], node["what"], row["answer"],
                                                   node["checks"], maker=row["by"], context=ctx.known(node),
                                                   everyone=node["level"] in levels.EVERY_JUDGE, seen=seen,
                                                   target=_target(ctx, job))
    node["step"] += 1
    shown = ", ".join(f"{m} {v['score']:.2f}" for m, v in node["verdicts"].items()) or "nothing to judge"
    return f"judge: {shown}"


def _record(ctx, job, node) -> str:
    """Intention: pass or fail, it is written down and learned from; the best that passed is kept."""
    verdicts = node.get("verdicts", {})
    for maker, row in node["answers"].items():
        score = verdicts.get(maker, {}).get("score", 0.0)
        ctx.ledger.add(MADE, maker, node["level"], score)
        if maker == MODELS and row["by"]:
            ladder.passed(ctx.ledger, node["level"], row["by"], score)
    # Intention (Andrew, 2026-10-08: "Earn trust at each step"): every judge
    # scored against the other judges at this step (warp2/make/step_trust.py).
    from warp2.make import step_trust
    step_trust.record(ctx.ledger, node["level"], verdicts)
    winners = [m for m, v in verdicts.items() if v["passed"]]
    best = max(winners, key=lambda m: verdicts[m]["score"]) if winners else ""
    joined = _joined(ctx, node)
    fired = [node["data"].get(k, "") for k in ("research_by", "socratic_by", "problems_by")]
    fired.append(node["answers"].get(MODELS, {}).get("by", ""))
    fires_before.record(ctx.ledger, eye_makers.part_name(node["level"]), fired,
                        bool(verdicts.get(eye_makers.EYE_PARTS, {}).get("passed")) or bool(best),
                        list(ctx.fleet.names()) if ctx.fleet is not None else [])
    lesson = {"item": job.row["item"], "node": node["id"], "level": node["level"], "what": node["what"],
              "asked": node["data"].get("asked", ""),
              "answers": {m: {k: r[k] for k in ("by", "why")} for m, r in node["answers"].items()},
              "verdicts": verdicts, "passed": bool(best), "chosen_by": best, "joined": joined,
              "eye_tags": eye_makers.tags_of(job.row, node, joined, ctx.sliced)}
    if best:
        return _passed(ctx, job, node, best, lesson)
    return _failed(ctx, job, node, lesson)


def _passed(ctx, job, node, best: str, lesson: dict) -> str:
    """Intention: the answer kept, the KG told, the next nodes made."""
    answer = node["answers"][best]["answer"]
    score = node["verdicts"][best]["score"]
    node.update(status=DONE, chosen=answer, chosen_by=best, score=score)
    limits.took(ctx.ledger, node["level"], node["attempt"] + 1)
    key = Library(ctx.state).add(node["level"], node["what"], answer, score, node["answers"][best]["by"])
    plan = kg_plan.call(ctx.fleet, ctx.ledger, node["level"], node["what"], ctx.known(node), answer)
    kept = reviewer(ctx, node, kg_plan.ROLE, target=_target(ctx, job))(plan["facts"], plan["model"]) if plan["model"] else None
    written = kg_plan.write(ctx.store, kept, f"make:{job.row['item']}:{node['id']}") if kept else 0
    node["data"]["kg_by"] = plan["model"]
    # Intention: the make family of tag types applies to what is being made, by code.
    applier = getattr(ctx.store, "applier", None)
    if applier is not None:
        applier.on("make", {"subject": ctx.about(job.row), "kind": f"make:{node['level']}", "passed": True})
    for child in levels.passed(job, node, answer):
        job.add(child)
    Lessons(ctx.state).add(dict(lesson, score=score, library_id=key, kg_facts=written))
    return f"record: passed — {best} ({node['answers'][best]['by']}) at {score:.2f}; {written} fact(s) to the KG"


def _failed(ctx, job, node, lesson: dict) -> str:
    """Intention: why it failed is kept; the stage tries again, then climbs, then splits, then waits for training."""
    whys = []
    for maker, verdict in node.get("verdicts", {}).items():
        said = [w for w in (verdict.get("why") or {}).values() if w]
        whys.append(f"{maker} scored {verdict['score']:.2f}" + (f": {said[0]}" if said else ""))
    whys += [f"{r['by']}: {r['why']}" for m, r in node["answers"].items()
             if r["why"] and (r["answer"] or m == MODELS)]
    node.setdefault("whys", []).extend(w for w in whys if w)
    for row in node["answers"].values():
        if row["answer"]:
            repeats.failed(node, row["answer"])
    Lessons(ctx.state).add(dict(lesson, score=0.0))
    node["attempt"] += 1
    node["step"] = 0
    if node["attempt"] < limits.limit(ctx.ledger, node["level"]):
        return f"record: not passed — try {node['attempt'] + 1} of {limits.limit(ctx.ledger, node['level'])}"
    # Intention (2026-10-09, fix 5.2): the rung ran out — the limit learns that.
    limits.missed(ctx.ledger, node["level"], node["attempt"])
    node["attempt"] = 0
    node["rung"] += 1
    if node["rung"] < len(_model_rungs(ctx, job, node)):
        return "record: not passed at this rung — on to the next, bigger rung"
    return _exhausted(ctx, job, node)


def _exhausted(ctx, job, node) -> str:
    """Intention: a part every rung failed is broken down smaller; anything else waits for training."""
    if node["level"] == PART and not node["data"].get("split"):
        node["status"] = FAILED
        job.add(new_node(BREAKDOWN, f"the part `{node['data']['name']}` broken smaller", node["id"],
                         {"split": node["data"]["name"]}))
        return "record: every rung failed this part — it is broken down smaller"
    node.update(status=WAITING, rung=0, why="waiting for a training round")
    node["data"]["training_at"] = _rounds(ctx)
    return "record: every rung failed — waiting for a training round, then it tries again"


def _rounds(ctx) -> int:
    """Intention: how many training rounds have ended, from their ledger."""
    from pathlib import Path
    path = Path(ctx.state) / "training" / "round_ledger.jsonl"
    try:
        return sum(1 for line in path.read_text(encoding="utf-8").splitlines() if '"ended"' in line)
    except OSError:
        return 0


def wake(ctx, job) -> int:
    """Intention: waiting nodes whose research is in, or whose training round came, go on; how many."""
    woke = 0
    for node in job.waiting():
        if node.get("why", "").startswith("waiting for a training"):
            if _rounds(ctx) > int(node["data"].get("training_at", 0)):
                node.update(status=OPEN, step=0, why="")
                woke += 1
        elif not _open_needs(ctx, node):
            node.update(status=OPEN, why="")
            woke += 1
    return woke


def could_wake(ctx, job) -> bool:
    """Intention: whether any waiting node could go on now (without changing it)."""
    for node in job.waiting():
        if node.get("why", "").startswith("waiting for a training"):
            if _rounds(ctx) > int(node["data"].get("training_at", 0)):
                return True
        elif not _open_needs(ctx, node):
            return True
    return False
