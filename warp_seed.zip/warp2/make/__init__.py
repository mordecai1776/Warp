# WARP2/warp2/make/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/__init__.py
#  Used by   : warp2/work/loop.py (the make cycle, for work that makes a new
#              file), warp2/work/phases.py (the action cycle's phases).
#  Uses      : nothing itself — each file here is one small part.
#  Description:
#    The make cycle: how a thing gets made. One stage — research, Socratic
#    questions, a check for common problems, make, judge and tag, record —
#    run at every level of the work: the task, its plan, the plan broken to
#    its smallest parts, and each part. Every task is made three times (the
#    models, the Eye's parts, the Eye master); every model tags; every stage
#    is trained on; the whole is evaluated at the end. How guarded it is
#    follows how well things are doing (trust). See docs/MAKE_CYCLE_PLAN.md.
#  User intention (Andrew, 2026-09-24): "When things are made they should not
#    just be made that would not be breaking it down into its smallest parts."
#    "The system is designed to be slow and to refine thousands of times more
#    than it builds."
# ============================================================================
