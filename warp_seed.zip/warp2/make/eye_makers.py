# WARP2/warp2/make/eye_makers.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/eye_makers.py
#  Used by   : warp2/make/stage.py (two of every task's three makers),
#              warp2/make/eye_lessons.py (the same inputs are taught).
#  Uses      : projects/behemoth_eye/eye/warp_eye.py (EyeBook — the WARP's one
#              Eye, its parts and its master), warp2/make/library.py,
#              warp2/tags/dehydrate.py (what is known, as dehydrated tags).
#  Description:
#    The Eye making: its small part for a level (`make: <level>`) and its
#    master (the everything part) each choose, from the answers that once
#    passed at that level, the one this work calls for. A level the Eye has
#    not been taught yet has nothing to choose from, and says so. What the
#    Eye reads is the work as tags: its level, what it is, its kind, and the
#    part's own name.
#  User intention (Andrew, 2026-09-24): "every task should be done 3 times one
#    by the normal models one by the eyes small parts and one by the eye
#    master". The point of the Eye "is to take over all of the jobs and have
#    the other models as backup."
# ============================================================================
from __future__ import annotations

from warp2.make.library import Library

# Intention: the two Eye makers' names, as the ledger and the judges know them.
EYE_PARTS, EYE_MASTER = "eye:parts", "eye:master"


def part_name(level: str) -> str:
    """Intention: the Eye's small part for one level of making."""
    return f"make: {level}"


def tags_of(job_row: dict, node: dict, joined: list = (), sliced: dict | None = None) -> list:
    """The work as the Eye reads it.

    Intention: its level, what it is, its kind and the part's name — and,
    for every model joined to this level's part (warp2/make/fires_before.py),
    what that model said here, so the part reads them as one.
    """
    tags = [{"name": f"level={node['level']}", "weight": 1.0, "holds": []},
            {"name": f"kind={job_row.get('kind', '')}", "weight": 1.0, "holds": []},
            {"name": "what", "weight": 1.0, "says": node["what"], "holds": []}]
    name = node.get("data", {}).get("name")
    if name:
        tags.append({"name": f"part={str(name).split('.')[-1]}", "weight": 1.0, "holds": []})
    said = node.get("answers", {}).get("models", {})
    for model in joined:
        if said.get("by") == model and said.get("answer"):
            tags.append({"name": f"joined={model}", "weight": 1.0, "says": said["answer"], "holds": []})
    # Intention: AND WHAT IS KNOWN, AS DEHYDRATED TAGS (Andrew, 2026-09-24:
    # every model, the Eye too, works through dehydrated tags) — the context
    # slice held inside one tag, each fact a tag of its own.
    items = (sliced or {}).get("items") or []
    if items:
        from warp2.tags.dehydrate import as_formed
        tags.append({"name": "known", "weight": 1.0, "says": str((sliced or {}).get("focus") or ""),
                     "holds": as_formed(items)})
    return tags


def part_reading(reading: dict) -> list:
    """Intention: what the part said, as tags the master reads beside the work — the master built from its parts."""
    return [{"name": f"part_says={key}", "weight": float(value), "holds": []}
            for key, value in sorted(reading.items(), key=lambda kv: -kv[1])[:8]]


def _book(state_dir):
    """Intention: the WARP's one Eye, looked up each time (never held)."""
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    return EyeBook(state_dir)


def _best(reading: dict, allowed: list, prefix: str = "") -> str:
    """Intention: the most likely allowed answer id in one reading, or ""."""
    chosen = {k[len(prefix):]: v for k, v in reading.items() if k.startswith(prefix) and k[len(prefix):] in allowed}
    return max(chosen, key=chosen.get) if chosen else ""


def answer(state_dir, job_row: dict, node: dict, which: str, joined: list = (),
           sliced: dict | None = None) -> tuple:
    """(the answer, why none) from one of the Eye's two makers.

    Intention: the part reads its own classes; the master reads every
    part's, named `make: <level>: <id>`, and only this level's count.
    """
    library = Library(state_dir)
    allowed = library.ids(node["level"])
    if not allowed:
        return "", "the Eye has not been taught this level yet"
    try:
        book = _book(state_dir)
        task = part_name(node["level"])
        if task not in book.tasks():
            return "", "the Eye has no part for this level yet"
        from projects.behemoth_eye.pairs.fronts import VECTOR
        seen = tags_of(job_row, node, joined, sliced)
        from_part = book.read(task, [seen])[0]
        if which == EYE_PARTS:
            key = _best(from_part, allowed)
        else:
            master = book.everything_name(VECTOR)
            if master not in book.tasks():
                return "", "the Eye's master has not been taught yet"
            reading = book.read(master, [seen + part_reading(from_part)])[0]
            key = _best(reading, allowed, prefix=f"{task}: ")
    except Exception as exc:
        return "", f"the Eye could not be asked: {type(exc).__name__}: {exc}"
    row = library.get(key) if key else None
    return (row["answer"], "") if row else ("", "the Eye chose nothing it was taught")
