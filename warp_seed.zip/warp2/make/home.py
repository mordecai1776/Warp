# WARP2/warp2/make/home.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/home.py
#  Used by   : every file in warp2/make/ that keeps something on disk.
#  Uses      : stdlib pathlib.
#  Description:
#    Where the make cycle keeps its things, in one place: the jobs, the
#    library of answers that passed, the ledger of scores and tags, the
#    learned limits, and the training rows.
#  User intention (Andrew): clean — nothing left where it can mix with new data.
# ============================================================================
from __future__ import annotations

from pathlib import Path


def home(state_dir) -> Path:
    """Intention: state/make — made on first use."""
    path = Path(state_dir) / "make"
    path.mkdir(parents=True, exist_ok=True)
    return path


def jobs(state_dir) -> Path:
    """Intention: one file per job, so a restart carries every job on."""
    path = home(state_dir) / "jobs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def slug(text: str) -> str:
    """Intention: a thing's name as a safe file name."""
    safe = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in str(text))
    return safe.strip("_")[:120] or "job"
