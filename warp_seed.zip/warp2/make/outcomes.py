# WARP2/warp2/make/outcomes.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/outcomes.py
#  Used by   : warp2/make/cycle.py (a job settled), warp2/make/tag_catchup.py
#              (late tags scored against how the work turned out).
#  Uses      : warp2/make/home.py; stdlib json.
#  Description:
#    How each settled job really turned out, one line each, so anything that
#    judges or tags the job's work later can still be scored against the truth.
#  User intention (Andrew, 2026-09-24): the tags "should also judge weather it
#    was right".
# ============================================================================
from __future__ import annotations

import json

from warp2.make.home import home


def _path(state_dir):
    """Intention: state/make/outcomes.jsonl."""
    return home(state_dir) / "outcomes.jsonl"


def settled(state_dir, item: str, outcome: float) -> None:
    """Intention: one job's outcome, written as it is known."""
    with _path(state_dir).open("a", encoding="utf-8") as out:
        out.write(json.dumps({"item": str(item), "outcome": float(outcome)}) + "\n")


def of(state_dir, item: str):
    """Intention: the latest outcome of one job, or None while it is not settled."""
    try:
        lines = _path(state_dir).read_text(encoding="utf-8").splitlines()
    except OSError:
        return None
    found = None
    for line in lines:
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if row.get("item") == str(item):
            found = float(row["outcome"])
    return found
