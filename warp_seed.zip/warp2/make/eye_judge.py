# WARP2/warp2/make/eye_judge.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/eye_judge.py
#  Used by   : warp2/make/judges.py (Judges.judge — the Eye's two votes join
#              the models', weighted by the Eye's own measured competence),
#              warp2/make/stage.py (passes the Eye what it needs to read).
#  Uses      : warp2/make/eye_makers.py (tags_of, part_name, part_reading,
#              EYE_PARTS, EYE_MASTER), warp2/make/eye_lessons.py (judge_name,
#              VERDICTS — the judgement parts the Eye is taught from every
#              stage), projects/behemoth_eye/eye/warp_eye.py (EyeBook),
#              projects/behemoth_eye/pairs/fronts.py (VECTOR).
#  Description:
#    The Eye judging. Its small parts vote with the judgement part for the
#    level (`judge: <level>`) read together with the level's making part
#    (`make: <level>`) — the parts that bear on this work, combined. Its
#    master votes by reading the work with what those parts said, the way
#    it makes. Each vote is the share it gives "passed" against "failed",
#    0 to 1, and counts like any judge's: weighted by the trust its record
#    has earned at that level, and fed back when the work settles
#    (warp2/make/final_eval.py). An Eye not yet taught a level does not vote.
#  User intention (Andrew, 2026-09-25): add the Eye as a judge "and use the
#    master and the relevant smaller combined parts for task". 2026-09-24:
#    the Eye's point "is to take over all of the jobs and have the other
#    models as backup."
# ============================================================================
from __future__ import annotations

from warp2.make.eye_lessons import VERDICTS, judge_name
from warp2.make.eye_makers import EYE_MASTER, EYE_PARTS, part_name, part_reading


def passed_share(reading: dict, prefix: str = "") -> float | None:
    """Intention: how much a reading leans to "passed" over "failed", 0 to 1; None when it says neither."""
    yes = reading.get(f"{prefix}{VERDICTS[0]}")
    no = reading.get(f"{prefix}{VERDICTS[1]}")
    if yes is None or no is None or (yes + no) <= 0:
        return None
    return float(yes) / float(yes + no)


def seen_with_answer(seen: list, answer: str) -> list:
    """Intention: the work as the Eye reads it, and the answer being judged beside it."""
    return list(seen or []) + [{"name": "answer", "weight": 1.0, "says": str(answer or ""), "holds": []}]


def votes(state_dir, level: str, seen: list, answer: str, book=None) -> dict:
    """The Eye's votes on one answer: {eye:parts: share, eye:master: share}, only those it can give.

    Intention: THE PARTS COMBINED. The judgement part reads the work and the
    answer; the level's making part, when it has been taught, reads them
    too, and what it said joins what the judgement part reads — so the parts
    that bear on the work vote as one. The master reads the work with what
    every one of those parts said.
    """
    if state_dir is None or seen is None:
        return {}
    if book is None:
        from projects.behemoth_eye.eye.warp_eye import EyeBook
        book = EyeBook(state_dir)
    judge = judge_name(level)
    if judge not in book.tasks():
        return {}
    looked = seen_with_answer(seen, answer)
    making = part_name(level)
    beside = part_reading(book.read(making, [looked])[0]) if making in book.tasks() else []
    from_judge = book.read(judge, [looked + beside])[0]
    out = {}
    share = passed_share(from_judge)
    if share is not None:
        out[EYE_PARTS] = share
    from projects.behemoth_eye.pairs.fronts import VECTOR
    master = book.everything_name(VECTOR)
    if master in book.tasks():
        whole = book.read(master, [looked + beside + part_reading(from_judge)])[0]
        share = passed_share(whole, prefix=f"{judge}: ")
        if share is not None:
            out[EYE_MASTER] = share
    return out
