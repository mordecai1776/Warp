# WARP2/warp2/make/book.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/book.py
#  Used by   : warp2/make/cycle.py.
#  Uses      : warp2/make/{home,job}.py, warp2/util.py (atomic_write_bytes);
#              stdlib json.
#  Description:
#    The jobs on disk: one file each, read when asked for and written whole
#    after every step, so a job is never half-saved and a restart carries on.
#  User intention (Andrew): clean and resumable — nothing kept in memory only.
# ============================================================================
from __future__ import annotations

import json

from warp2.make.home import jobs, slug
from warp2.make.job import Job


class JobBook:
    """Every job, by the work item it makes."""

    def __init__(self, state_dir) -> None:
        """Intention: the folder the jobs live in."""
        self.home = jobs(state_dir)

    def _path(self, item: str):
        """Intention: one file per item."""
        return self.home / f"{slug(item)}.json"

    def get(self, item: str) -> Job | None:
        """Intention: the item's job; none when it has none or its file is torn."""
        try:
            return Job(json.loads(self._path(item).read_text(encoding="utf-8")))
        except (OSError, ValueError):
            return None

    def put(self, job: Job) -> None:
        """Intention: the whole job, written at once."""
        from warp2.util import atomic_write_bytes
        atomic_write_bytes(self._path(job.row["item"]),
                           json.dumps(job.row, indent=1, sort_keys=True).encode("utf-8"))

    def all(self) -> list:
        """Intention: every job on disk."""
        out = []
        for path in sorted(self.home.glob("*.json")):
            try:
                out.append(Job(json.loads(path.read_text(encoding="utf-8"))))
            except (OSError, ValueError):
                continue
        return out

    def finish(self, item: str) -> None:
        """Intention: a finished job is moved aside, not deleted, so its record stays readable."""
        path = self._path(item)
        done = self.home / "done"
        done.mkdir(exist_ok=True)
        try:
            path.replace(done / path.name)
        except OSError:
            pass
