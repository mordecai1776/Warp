# WARP2/warp2/make/context.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/context.py
#  Used by   : warp2/make/{cycle,stage,levels,final_eval}.py.
#  Uses      : nothing — it only holds what a step needs.
#  Description:
#    Everything one step of the make cycle works with, handed down in one
#    piece: the tree, the state folder, the store, the fleet and the worker,
#    the needs, the ledger, and this pass's work item with its narrowed view
#    of the knowledge graph (the context slice the loop already builds).
#  User intention (Andrew, 2026-09-24): "Previous data will be available to
#    the model through the cockpit interface to the kg that is narrowed for
#    the set task."
# ============================================================================
from __future__ import annotations


class Ctx:
    """One step's world."""

    def __init__(self, root, state, store, fleet, worker, needs, ledger, item: dict, sliced: dict) -> None:
        """Intention: held as they are; nothing here is copied or changed."""
        self.root, self.state, self.store = root, state, store
        self.fleet, self.worker, self.needs, self.ledger = fleet, worker, needs, ledger
        self.item, self.sliced = item, sliced

    def known(self, node: dict | None = None) -> str:
        """Intention: what is known for this work — the narrowed KG view, and the checks this node carries."""
        text = str((self.sliced or {}).get("text") or "")
        checks = (node or {}).get("checks") or []
        if checks:
            text += "\n\nit must get these right:\n" + "\n".join(f"- {c}" for c in checks)
        whys = (node or {}).get("whys") or []
        if whys:
            text += "\n\nwhat went wrong in the tries before:\n" + "\n".join(f"- {w}" for w in whys[-4:])
        return text.strip()

    def about(self, job_row: dict) -> str:
        """Intention: what research is raised about — the thing being made, so what is found reaches its view."""
        return job_row.get("target") or job_row.get("item")
