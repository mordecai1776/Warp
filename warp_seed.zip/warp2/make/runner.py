# WARP2/warp2/make/runner.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/runner.py
#  Used by   : warp2/make/{research_review,self_improve}.py.
#  Uses      : warp2/make/{book,job,stage,context,ledger}.py.
#  Description:
#    One step of a one-node job — the same stage every file goes through —
#    for work that is not a file: a finding reviewed, a way to improve
#    proposed. It says whether the node passed, is still going, or did not
#    pass at its first rung (which, for these, is the end of it).
#  User intention (Andrew, 2026-09-24): research and self-improvement are
#    "handled like in action task".
# ============================================================================
from __future__ import annotations

from warp2.make import stage
from warp2.make.book import JobBook
from warp2.make.context import Ctx
from warp2.make.job import DONE, Job
from warp2.make.ledger import make_ledger

# Intention: what one step came to.
PASSED, GOING, ENDED = "passed", "going", "ended"


def step(root, state, store, fleet, worker, needs, key: str, level: str, what: str, extra: dict) -> dict:
    """Intention: {outcome, said, job} after one step of the job `key`."""
    book, ledger = JobBook(state), make_ledger(state)
    item = {"item": key, "kind": level, "target": what}
    job = book.get(key)
    if job is None:
        job = Job.start(item, "", level=level, what=what)
        job.row.update(extra)
    ctx = Ctx(root, state, store, fleet, worker, needs, ledger, item, {"text": str(extra.get("known", ""))})
    stage.wake(ctx, job)
    node = job.nodes[job.row["root"]]
    said = stage.step(ctx, job, node) if node["status"] == "open" else f"waiting — {node['why']}"
    outcome = GOING
    if node["status"] == DONE:
        outcome = PASSED
    elif node["rung"] > 0 or node["status"] == "failed" or node["why"].startswith("waiting for a training"):
        outcome = ENDED
    book.put(job)
    ledger.save()
    if outcome != GOING:
        book.finish(key)
    return {"outcome": outcome, "said": said, "job": job}
