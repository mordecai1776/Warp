# WARP2/warp2/make/assemble.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/assemble.py
#  Used by   : warp2/make/cycle.py (when every part has passed).
#  Uses      : warp2/parts/{imports_fill,header_write}.py through the
#              worker's PartsBuilder — the same imports and header the parts
#              builder has always added.
#  Description:
#    The finished parts put together into the file: the outline with every
#    part written, the imports each name needs, and the file's header.
#  User intention (Andrew): every file opens with its pathway, what uses it,
#    what it uses, a description and his intention notes.
# ============================================================================
from __future__ import annotations


def whole(worker, job) -> str:
    """Intention: the file as it will be written."""
    path, code = job.row["path"], job.row["skeleton"]
    builder = getattr(worker, "parts", None)
    if builder is None:
        return code
    code, _added = builder.imports(path, code)
    intention = job.row.get("understood", "").split("\n", 1)[0][:300]
    return builder.header(path, code, job.row.get("kind", ""), intention, "the make cycle's understanding")
