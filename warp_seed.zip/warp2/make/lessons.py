# WARP2/warp2/make/lessons.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/lessons.py
#  Used by   : warp2/make/stage.py (a lesson after every stage),
#              warp2/make/eye_lessons.py (the Eye is taught them),
#              warp2/make/training_rows.py (the models are trained on them).
#  Uses      : warp2/make/home.py; stdlib json, time.
#  Description:
#    What every stage did, written down the moment it settles, pass or fail:
#    the level, the work, who made what, every score, every tag, and which
#    answer passed. Written to disk at once so nothing waits in memory for a
#    save that a freed card could lose.
#  User intention (Andrew, 2026-09-24): "after every time it should train on
#    what it has done no matter what". A failed answer is kept as a score, and
#    only what passed is ever taught as the answer.
# ============================================================================
from __future__ import annotations

import json
import time

from warp2.make.home import home


class Lessons:
    """One line per settled stage."""

    def __init__(self, state_dir) -> None:
        """Intention: state/make/lessons.jsonl, and how far each learner has read it."""
        self.path = home(state_dir) / "lessons.jsonl"
        self.read_at = home(state_dir) / "lessons_read.json"

    def add(self, row: dict) -> None:
        """Intention: one stage's lesson, with when."""
        row = dict(row, when=time.strftime("%Y-%m-%dT%H:%M:%S"))
        with self.path.open("a", encoding="utf-8") as out:
            out.write(json.dumps(row, ensure_ascii=False) + "\n")

    def rows(self) -> list:
        """Intention: every lesson so far."""
        try:
            return [json.loads(l) for l in self.path.read_text(encoding="utf-8").splitlines() if l.strip()]
        except (OSError, ValueError):
            return []

    def unread(self, learner: str) -> list:
        """Intention: the lessons this learner has not been taught yet."""
        return self.rows()[self._at(learner):]

    def read(self, learner: str, count: int) -> None:
        """Intention: this learner has now been taught `count` more."""
        try:
            at = json.loads(self.read_at.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            at = {}
        at[learner] = self._at(learner) + int(count)
        self.read_at.write_text(json.dumps(at), encoding="utf-8")

    def _at(self, learner: str) -> int:
        """Intention: how far this learner has read."""
        try:
            return int(json.loads(self.read_at.read_text(encoding="utf-8")).get(learner, 0))
        except (OSError, ValueError):
            return 0
