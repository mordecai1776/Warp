# WARP2/warp2/make/agent_review.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agent_review.py
#  Used by   : warp2/make/stage.py (after the research, Socratic, common
#              problem and KG agents each give their work).
#  Uses      : warp2/make/judges.py (the same judges, the same trust),
#              warp2/make/agents/who.py (played — the role's record).
#  Description:
#    The agents' own work is judged and tagged by the other models, like
#    anything made: the research agent's questions, the Socratic agent's
#    doubts, the problems the common problem agent found, and the facts the
#    KG agent planned — or its word that there is nothing. Each gets a score
#    and tags from every other model (tempered by trust, as all judging is).
#    The score goes straight into that model's record in that role. Work that
#    passes is used without the items most of the judges said are wrong. Work
#    that does not pass: its problems are not marked and its facts are not
#    written — a wrong one does harm. Questions and doubts are only asked, so a
#    research or Socratic answer that falls short is used by its temperature,
#    not dropped at a bar (BUILD_LOG 1443): the share of its questions its
#    score earns, first ones first, never the ones called wrong. When no judge
#    could answer, it is used as it is — nothing could tell against it.
#  User intention (Andrew, 2026-09-24): "What were the confidence tags in the
#    socratic agents like by the other models they should get tags to".
#    2026-11-08: "check to make sure the warp is doing its needed research." —
#    from Nov 4 the judges scored nearly every research answer just under the
#    bar (0.42-0.51), so nothing was looked up; temperatures, not solid bars.
# ============================================================================
from __future__ import annotations

from warp2.make.agents.who import played
from warp2.make.judges import Judges

# Intention: what each agent's work must get right, as the judges are told.
CHECKS = {
    "research": ["each question asks something not already known above",
                 "each question is needed to do this work", "each question can be looked up"],
    "socratic": ["each doubt is a real doubt about this work, not a general one",
                 "each doubt is a question someone could look up"],
    "common_problems": ["each problem could really happen in this work",
                        "each way to avoid it would work"],
    "kg_plan": ["each fact is true", "each fact is about this work or what was learned for it"],
}

# Intention: the roles whose work is only asked — questions and doubts to look up — so an answer that falls short is
# used by the share its score earns instead of not at all.
ASKED_BY_SCORE = frozenset({"research", "socratic"})

# Intention: what an agent's empty answer claims, so the claim itself is judged.
EMPTY = {
    "research": "(no questions: it says nothing needs looking up first)",
    "socratic": "(no doubts: it says nothing about this work is unclear or assumed)",
    "common_problems": "(no problems: it says none of the known problems could happen here)",
    "kg_plan": "(no facts: it says nothing learned here belongs in the knowledge graph)",
}


def listed(items) -> str:
    """Intention: an agent's work as plain lines, one a line."""
    lines = []
    for item in items:
        if isinstance(item, (tuple, list)):
            lines.append("- " + " — ".join(str(x) for x in item))
        else:
            lines.append(f"- {item}")
    return "\n".join(lines)


def reviewer(ctx, node: dict, role: str, target: str = ""):
    """A callable that judges and tags one agent's work: what of it may be used, or None.

    Intention: the verdict is kept on the node beside the role's name, so
    the cockpit and the lesson show what the other models said of it. Work
    that passes is used without the items most of the judges called wrong;
    work that does not pass is not used at all (None).
    """
    item = getattr(ctx, "item", None) or {}
    join_target = str(target or item.get("path") or item.get("target") or item.get("item") or "")

    def review(items, model: str):
        """Intention: judge one agent's work, keep the verdict on the node, and return the items that may be
        used, or None.
        """
        text = listed(items) or EMPTY[role]
        verdict = Judges(ctx.fleet, ctx.ledger).judge(
            f"{node['level']}:{role}", f"the {role.replace('_', ' ')} agent's work on {node['what']}",
            text, CHECKS[role], maker=model, context=ctx.known(node), target=join_target)
        node["data"].setdefault("agent_verdicts", {})[role] = {**verdict, "model": model, "work": text}
        items = list(items)
        if not verdict["by"]:
            return items
        played(ctx.ledger, role, model, verdict["score"])
        kept = [item for at, item in enumerate(items, start=1) if at not in verdict["wrong_items"]]
        if verdict["passed"]:
            return kept
        return by_temperature(role, kept, verdict["score"])
    return review


def by_temperature(role: str, kept: list, score) -> list | None:
    """What of an answer that fell short may still be used: for questions and doubts, the share its score earns.

    Intention: the first questions first — the agent lists what matters
    most first — as many as the score's share of them, rounded down; none
    (None) when that share is none, and none for work that would do harm if
    wrong (problems marked, facts written).
    """
    if role not in ASKED_BY_SCORE:
        return None
    share = int(len(kept) * max(0.0, min(1.0, float(score or 0.0))))
    return kept[:share] or None
