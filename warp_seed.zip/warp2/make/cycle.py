# WARP2/warp2/make/cycle.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/cycle.py
#  Used by   : warp2/work/loop.py (work that makes a new Python file is done
#              through it: one step each pass, then the finished file is
#              handed back to be written, gated, proven and settled like any
#              other), warp2/work/side/make_eye.py.
#  Uses      : warp2/make/{book,job,stage,assemble,final_eval,context,ledger,
#              training_rows,limits}.py.
#  Description:
#    The make cycle for one work item at a time: its job is found or started,
#    waiting nodes whose research is in are woken, and one step of the next
#    node is taken. While the job is making, the unit is left open and no
#    attempt is counted — it is not being tried, it is being made. When every
#    part has passed, the file is put together and evaluated whole; if it
#    passes it is handed to the loop to write. After the loop has settled it,
#    how it turned out goes back to every model and role that took part.
#    (2026-11-03, BUILD_LOG 1119) With `whole_stage` set (the loop sets it),
#    a turn takes the rest of the node's stage while the node can go on, so
#    a job moves a stage a turn instead of a step.
#  User intention (Andrew, 2026-09-24): "When something is made it should go
#    like this ..." — and "It is fine if it is really slow we are reaching for
#    quality not speed".
# ============================================================================
from __future__ import annotations

from collections import Counter

from warp2.make import assemble, final_eval, limits, stage
from warp2.make.book import JobBook
from warp2.make.context import Ctx
from warp2.make.job import BREAKDOWN, DONE, PART, WAITING, Job, new_node
from warp2.make.ledger import make_ledger

# Intention: the job states, in order.
MAKING, READY, HANDED = "making", "ready", "handed"


class MakeCycle:
    """Makes new files through the stages, one step a pass."""

    def __init__(self, root, state, store, fleet, worker, needs) -> None:
        """Intention: what every step is given; the jobs live on disk."""
        self.root, self.state, self.store = root, state, store
        self.fleet, self.worker, self.needs = fleet, worker, needs
        self.book = JobBook(state)
        self.ledger = make_ledger(state)

    def _path(self, item: dict, sliced: dict) -> str:
        """Intention: the file this item makes, as the worker reads it."""
        return self.worker._target_file(item, sliced or {})

    def wanted(self, item: dict, sliced: dict) -> bool:
        """Whether this work is made here: a Python file being built or tested, new or made again.

        Intention: A FILE BUILT AGAIN IS MADE LIKE A NEW ONE. The parts
        builder only takes files that do not exist yet, so a build reopened
        because its file was wrong went back to one model writing it whole —
        MEASURED on the live run 2026-09-24 (recursive_self_improvement_lab,
        70 s, one model). Changing an existing file on purpose (revise) still
        goes as it did.
        """
        from warp2.parts.builder import KINDS
        if getattr(self.worker, "parts", None) is None or self.fleet is None:
            return False
        return str(item.get("kind") or "") in KINDS and self._path(item, sliced).endswith(".py")

    def can_take(self, item: dict) -> bool:
        """Intention: False only for a job that is waiting and could not go on now — so other work is taken."""
        job = self.book.get(str(item.get("item") or ""))
        if job is None or job.row["state"] != MAKING:
            return True
        if job.movable() is not None:
            return True
        return stage.could_wake(self._ctx(item, {}), job) or job.all_parts_done()

    def _ctx(self, item: dict, sliced: dict) -> Ctx:
        """Intention: this step's world."""
        return Ctx(self.root, self.state, self.store, self.fleet, self.worker, self.needs,
                   self.ledger, item, sliced)

    def __call__(self, item: dict, sliced: dict) -> dict:
        """One step of this item's job; the finished file when it is ready.

        Intention: shaped as the worker's answer, so the loop needs to know
        nothing more: an empty `model` leaves the unit open with no attempt
        counted; `files` are written, gated, proven and settled.
        """
        ctx = self._ctx(item, sliced)
        job = self.book.get(str(item["item"])) or Job.start(item, self._path(item, sliced))
        try:
            said = self._advance(ctx, job)
            return self._rest_of_stage(ctx, job, said) if self.whole_stage else said
        finally:
            self.book.put(job)
            self.ledger.save()

    # Intention (BUILD_LOG 1119): set by the loop — a turn takes the node's whole stage, not one step. A cycle made
    # without it (the tests, make_eye) still takes one step a call.
    whole_stage = False
    # Intention (BUILD_LOG 1119): the loop's stop, so the rest of a stage is not taken once the stop is raised.
    stop = None

    def _rest_of_stage(self, ctx, job, said: dict) -> dict:
        """The rest of the node's stage in this turn, until the node waits, ends, or another node is next.

        Intention (BUILD_LOG 1119): A BUILD MUST BE ABLE TO FINISH. Measured
        2026-11-03: a unit of work is taken about once in two hours, the queue
        hands each turn to a different unit, and the cycle took one step a
        turn — so each of the ~60 open jobs moved one step every few days, and
        q_bert's job was still on its first node after a week. A stage is the
        cycle's own piece (research, Socratic, wait, problems, make, judge,
        record): it runs on in the same turn while its node can, and no
        further than its own seven steps, so control still comes back.
        """
        first = said.get("node")
        lines, steps = [said.get("said", "")], 1
        while first and not said.get("files") and steps < len(stage.STEPS) and not self._stopped():
            node = job.movable()
            if node is None or node["id"] != first or job.row["state"] != MAKING:
                break
            said = self._advance(ctx, job)
            lines.append(said.get("said", ""))
            steps += 1
        if steps > 1 and not said.get("files"):
            said = {**said, "said": " | ".join(line for line in lines if line), "steps": steps}
        return said

    def _stopped(self) -> bool:
        """Intention: whether the loop's stop is raised (False with no stop given)."""
        try:
            return bool(self.stop is not None and self.stop.raised())
        except Exception:  # noqa: BLE001 — a stop that cannot be read is no stop, as before
            return False

    def _advance(self, ctx, job) -> dict:
        """Intention: wake, then one step, or put the whole together, or hand it over."""
        if job.row["state"] in (READY, HANDED):
            job.row["state"] = HANDED
            return self._handed(job)
        woke = stage.wake(ctx, job)
        node = job.movable()
        if node is not None:
            said = stage.step(ctx, job, node)
            return {"model": "", "said": f"make cycle: {node['level']} — {said}", "reached": True,
                    "woke": woke, "node": node["id"]}
        if job.all_parts_done():
            return self._finish(ctx, job)
        waiting = job.waiting()
        return {"model": "", "reached": True,
                "said": "make cycle: waiting — " + "; ".join(n["why"] for n in waiting[:3])}

    def _finish(self, ctx, job) -> dict:
        """Intention: the parts put together and evaluated whole; handed over only when it passes."""
        code = assemble.whole(self.worker, job)
        final = final_eval.before_writing(ctx, job, code)
        job.row["final"] = final
        if final["passed"]:
            job.row.update(state=HANDED, made=code)
            return self._handed(job)
        return self._again(ctx, job, final["gate"] + list(final["verdict"].get("why", {}).values()))

    def _again(self, ctx, job, whys: list) -> dict:
        """Intention: the whole did not pass — its parts are made again with why, to a learned limit."""
        job.row["final_tries"] = int(job.row.get("final_tries", 0)) + 1
        if job.row["final_tries"] >= limits.limit(self.ledger, final_eval.WHOLE):
            job.row["state"] = MAKING
            done = [n for n in job.of_level(PART) if n["status"] == DONE]
            for node in done:
                node.update(status=WAITING, why="waiting for a training round")
                node["data"]["training_at"] = stage._rounds(ctx)
            return {"model": "", "reached": True, "said": "make cycle: the whole failed again — waiting for training"}
        breakdowns = [n for n in job.of_level(BREAKDOWN) if n["status"] == DONE]
        base = breakdowns[-1]["chosen"] if breakdowns else job.row["skeleton"]
        job.row["skeleton"] = base
        parent = new_node(BREAKDOWN, f"the whole of {job.row['path']}, made again", job.row["root"],
                          {"again": job.row["final_tries"]})
        parent.update(status=DONE, chosen=base, chosen_by="final evaluation")
        job.add(parent)
        from warp2.parts.skeleton import Skeleton
        for name in Skeleton(base).stubs():
            part = new_node(PART, f"the part `{name}` of {job.row['path']}", parent["id"], {"name": name})
            part["checks"] = [w for w in whys if w]
            job.add(part)
        return {"model": "", "reached": True,
                "said": f"make cycle: the whole did not pass — {len(Skeleton(base).stubs())} part(s) made again"}

    def _handed(self, job) -> dict:
        """Intention: the file, as the worker would give it; its model is who made most of its parts."""
        makers = Counter(n["answers"].get(n["chosen_by"], {}).get("by", "") for n in job.of_level(PART)
                         if n["status"] == DONE)
        by = next((m for m, _ in makers.most_common() if m and m != "code"), "") or "code"
        return {"model": by, "files": {job.row["path"]: job.row["made"]}, "issues": [],
                "said": f"made by the make cycle: {len(job.of_level(PART))} part(s)",
                "make_cycle": {"final": job.row.get("final", {}).get("score")}}

    def _late_tags(self, job, outcome: float) -> int:
        """Intention: tags given late (warp2/make/tag_catchup.py) scored now the outcome is known."""
        from warp2.make.tag_catchup import late, score
        count = 0
        for tag in late(self.state):
            if tag.get("item") == job.row["item"] and tag.get("score") is not None and not tag.get("own_work"):
                score(self.ledger, tag["level"], tag, tag["model"], outcome)
                count += 1
        return count

    def settled(self, item: dict, verdict: dict) -> dict | None:
        """Intention: how the loop settled a handed file goes back to everyone who took part."""
        job = self.book.get(str(item.get("item") or ""))
        if job is None or job.row["state"] != HANDED or not isinstance(verdict, dict):
            return None
        state = str(verdict.get("state") or "")
        outcome = 1.0 if (verdict.get("passed") or state == "done") else 0.0
        ctx = self._ctx(item, {})
        said = final_eval.after_settling(ctx, job, outcome)
        from warp2.make import outcomes
        outcomes.settled(self.state, job.row["item"], outcome)
        said["late_tags"] = self._late_tags(job, outcome)
        from warp2.make.training_rows import write_rows
        said["rows"] = write_rows(self.state, job, outcome)
        self.ledger.save()
        if state in ("done", "sunk"):
            self.book.finish(job.row["item"])
        else:
            job.row["state"] = MAKING
            self._again(ctx, job, [str(verdict.get("error") or verdict.get("why") or "it did not settle")])
            self.book.put(job)
        return said
