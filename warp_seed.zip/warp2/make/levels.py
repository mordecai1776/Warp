# WARP2/warp2/make/levels.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/levels.py
#  Used by   : warp2/make/stage.py.
#  Uses      : warp2/make/agents/{understand,planner,breaker,part_maker,proposal,wiring}.py,
#              warp2/make/job.py.
#  Description:
#    What each level makes, and what comes after it. For every level: what
#    code can make without a model (or nothing), what a model is asked, what
#    makes an answer usable, and — when it passes — how the job changes and
#    which nodes come next: the task → its plan → the plan broken to its
#    smallest parts → one node per part.
#  User intention (Andrew, 2026-09-24): "Then a planner agent comes in and
#    makes a plan and this all happens again. Then a agent breaks that plan
#    down into its smallest parts and off it happens again, then for each part
#    of it happens again until all of it is done."
# ============================================================================
from __future__ import annotations

from warp2.make.agents import breaker, part_maker, planner, proposal, understand, wiring
from warp2.make.job import BREAKDOWN, PART, PLAN, TASK, new_node

# Intention: the two levels that are not a file: a research finding being
# reviewed as an action task, and a way to improve itself being proposed as
# a project (warp2/make/{research_review,self_improve}.py).
REVIEW, PROPOSAL = "review", "proposal"

# Intention: the level that only wires the knowledge graph (warp2/make/
# kg_wiring.py), and the levels whose answers every model judges and tags
# whatever trust says (Andrew, 2026-09-24: "it should have its plan tagged by
# all of the models").
WIRING = "wiring"
EVERY_JUDGE = (WIRING,)
from warp2.parts.part_check import PartCheck
from warp2.parts.skeleton import Skeleton


def has_code(level: str) -> bool:
    """Intention: the levels where the tree's own code may make the answer."""
    return level in (PLAN, PART, REVIEW)


def by_code(ctx, job, node) -> str:
    """Intention: the answer code makes for this node, or ""."""
    if node["level"] == PLAN:
        return planner.by_code(ctx.root, ctx.item, ctx.sliced)
    if node["level"] == PART:
        return part_maker.by_code(ctx.worker, job.row["skeleton"], node["data"]["name"])
    if node["level"] == REVIEW:
        return str(job.row.get("finding") or "")
    return ""


def told(ctx, job, node) -> str:
    """Intention: what a part is told the task is: the understanding, the checks, what is known."""
    parts = [job.row.get("understood", ""), ctx.known(node)]
    return "\n\n".join(p for p in parts if p)


def by_model(ctx, job, node, model: str, refused: str) -> tuple:
    """Intention: (answer, why not) from one model, for this node's level."""
    level, w = node["level"], ctx.worker
    if level == REVIEW:
        return "", "a finding is what was read; a model does not remake it"
    if level == PROPOSAL:
        return proposal.ask(ctx.fleet, model, node["what"], ctx.known(node), refused)
    if level == WIRING:
        return wiring.ask(ctx.fleet, model, node["what"], job.row.get("known", ""), refused)
    if level == TASK:
        return understand.ask(w, model, ctx.item, ctx.sliced, node, refused)
    if level == PLAN:
        return planner.ask(w, model, ctx.item, ctx.sliced, job.row["path"], job.row.get("understood", ""),
                           node["checks"], refused)
    if level == BREAKDOWN:
        return breaker.ask(w, model, job.row["path"], job.row["skeleton"], job.row.get("understood", ""),
                           node["checks"], refused)
    return part_maker.ask(w, model, job.row["path"], job.row["skeleton"], node["data"]["name"],
                          told(ctx, job, node), refused)


def usable(job, node, answer: str) -> str:
    """Intention: "" when this answer can be used at this node, else why not."""
    level = node["level"]
    if not str(answer or "").strip():
        return "there was no answer"
    if level == REVIEW:
        return ""
    if level == PROPOSAL:
        return proposal.read(answer)[1]
    if level == WIRING:
        return wiring.read(answer, job.row.get("known", ""))[1]
    if level == TASK:
        return understand.read(answer)[1]
    if level == PLAN:
        return planner.read(answer)[1]
    if level == BREAKDOWN:
        return breaker.read(answer, job.row["skeleton"])[1]
    why = PartCheck().issue(answer)
    return why or part_maker.fits(job.row["skeleton"], node["data"]["name"], answer)[1]


def passed(job, node, answer: str) -> list:
    """Intention: the job changed by a passed answer, and the nodes that come next."""
    level, path = node["level"], job.row["path"]
    if level in (REVIEW, PROPOSAL, WIRING):
        job.row["passed_answer"] = answer
        return []
    if level == TASK:
        job.row["understood"] = answer
        return [new_node(PLAN, f"the plan of {path}", node["id"])]
    if level == PLAN:
        job.row["skeleton"] = answer
        return [new_node(BREAKDOWN, f"the smallest parts of {path}", node["id"])]
    if level == BREAKDOWN:
        job.row["skeleton"] = answer
        # Intention (2026-10-09, fix 5.1, check D1): a piece of a split carries
        # the part it was split from, so it is not split again (stage.py
        # _exhausted reads this) — the guard read a mark no part carried.
        split = (node.get("data") or {}).get("split")
        return [new_node(PART, f"the part `{name}` of {path}", node["id"],
                         {"name": name, **({"split": split} if split else {})})
                for name in Skeleton(answer).stubs()]
    job.row["skeleton"] = part_maker.fits(job.row["skeleton"], node["data"]["name"], answer)[0]
    return []
