# WARP2/warp2/make/library.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/library.py
#  Used by   : warp2/make/{eye_makers,eye_lessons,stage}.py.
#  Uses      : warp2/make/{home,repeats}.py; stdlib json.
#  Description:
#    Every answer that passed its judges, by level, each with an id. The
#    Eye's makers answer by choosing one of these, and are taught which one
#    was right — so what the Eye can give is only ever what once passed.
#    Nothing that failed is ever kept here: a mistake sets a lesson's weight,
#    it is never the lesson.
#  User intention (Andrew, 2026-09-24): "every task should be done 3 times one
#    by the normal models one by the eyes small parts and one by the eye
#    master".
# ============================================================================
from __future__ import annotations

import json

from warp2.make.home import home
from warp2.make.repeats import mark


class Library:
    """The passed answers, one line each, read whole when asked."""

    def __init__(self, state_dir) -> None:
        """Intention: state/make/library.jsonl."""
        self.path = home(state_dir) / "library.jsonl"

    def rows(self) -> list:
        """Intention: every kept answer; none when there is no file yet."""
        try:
            return [json.loads(l) for l in self.path.read_text(encoding="utf-8").splitlines() if l.strip()]
        except (OSError, ValueError):
            return []

    def add(self, level: str, what: str, answer: str, score: float, by: str) -> str:
        """Intention: keep a passed answer once; its id either way."""
        key = f"{level}:{mark(answer)}"
        if any(r["id"] == key for r in self.rows()):
            return key
        row = {"id": key, "level": level, "what": what, "answer": answer, "score": float(score), "by": by}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as out:
            out.write(json.dumps(row) + "\n")
        return key

    def get(self, key: str) -> dict | None:
        """Intention: one kept answer by id."""
        return next((r for r in self.rows() if r["id"] == key), None)

    def ids(self, level: str) -> list:
        """Intention: the ids kept at one level, in the order they were kept."""
        return [r["id"] for r in self.rows() if r["level"] == level]
