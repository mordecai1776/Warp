# WARP2/warp2/make/job.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/job.py
#  Used by   : warp2/make/{book,stage,cycle,levels,assemble}.py.
#  Uses      : stdlib hashlib.
#  Description:
#    One job: one work item being made, as a tree of nodes. A node is one
#    stage at one level — the task, the plan, the breakdown, or one part —
#    with where it is in its steps, its tries, the answers each maker gave
#    and what the judges said. Plain data, so it is saved as it is and a
#    restart carries on exactly where it was.
#  User intention (Andrew, 2026-09-24): "Then a planner agent comes in and
#    makes a plan and this all happens again. Then a agent breaks that plan
#    down into its smallest parts and off it happens again, then for each part
#    of it happens again until all of it is done."
# ============================================================================
from __future__ import annotations

import hashlib

# Intention: the levels, in the order the work goes down them.
TASK, PLAN, BREAKDOWN, PART = "task", "plan", "breakdown", "part"

# Intention: the states a node can be in.
OPEN, WAITING, DONE, FAILED = "open", "waiting", "done", "failed"


def new_node(level: str, what: str, parent: str = "", data: dict | None = None) -> dict:
    """Intention: a fresh node at its first step, nothing tried."""
    key = hashlib.sha256(f"{level}|{what}|{parent}".encode("utf-8")).hexdigest()[:12]
    return {"id": f"{level}-{key}", "level": level, "what": str(what), "parent": parent,
            "status": OPEN, "step": 0, "attempt": 0, "rung": 0, "tried": [], "needs": [],
            "checks": [], "problems": [], "answers": {}, "verdicts": {}, "chosen": "",
            "chosen_by": "", "score": None, "children": [], "data": dict(data or {}),
            "why": ""}


class Job:
    """One work item's tree of nodes, and the file it is becoming."""

    def __init__(self, row: dict) -> None:
        """Intention: a job is its saved row; this only reads and changes it."""
        self.row = row

    @classmethod
    def start(cls, item: dict, path: str, level: str = TASK, what: str = "") -> "Job":
        """Intention: a new job with one node at the top — the task, unless the job is of another level."""
        root = new_node(level, what or str(item.get("target") or item.get("item")))
        return cls({"item": str(item["item"]), "kind": str(item.get("kind") or ""),
                    "target": str(item.get("target") or ""), "path": str(path),
                    "nodes": {root["id"]: root}, "order": [root["id"]], "root": root["id"],
                    "skeleton": "", "state": "making", "made": "", "final": {}})

    @property
    def nodes(self) -> dict:
        """Intention: every node by id."""
        return self.row["nodes"]

    def add(self, node: dict) -> dict:
        """Intention: a child node, kept in the order it was made; the same node twice is kept once."""
        if node["id"] not in self.nodes:
            self.nodes[node["id"]] = node
            self.row["order"].append(node["id"])
            parent = self.nodes.get(node["parent"])
            if parent is not None and node["id"] not in parent["children"]:
                parent["children"].append(node["id"])
        return self.nodes[node["id"]]

    def movable(self) -> dict | None:
        """The first open node in the order it was made — the one to move now.

        Intention: depth follows order: a node's children are made after it,
        so the plan comes after the task, the parts after the breakdown.
        """
        for key in self.row["order"]:
            node = self.nodes[key]
            if node["status"] == OPEN:
                return node
        return None

    def waiting(self) -> list:
        """Intention: every node waiting on something outside it (research, training)."""
        return [self.nodes[k] for k in self.row["order"] if self.nodes[k]["status"] == WAITING]

    def of_level(self, level: str) -> list:
        """Intention: every node of one level, in order."""
        return [self.nodes[k] for k in self.row["order"] if self.nodes[k]["level"] == level]

    def all_parts_done(self) -> bool:
        """Intention: there are parts, and every one of them passed — or was broken smaller and its pieces did."""
        parts = self.of_level(PART)
        return bool(parts) and all(self.part_done(p) for p in parts)

    def part_done(self, part: dict) -> bool:
        """Whether a part passed, or failed and was broken into pieces that are all done.

        Intention (2026-10-09, fix 5.1, check D1): a part every rung failed is
        broken smaller and stays "failed"; counted as not done, the job could
        never complete however well its pieces did.
        """
        if part["status"] == DONE:
            return True
        if part["status"] != FAILED:
            return False
        splits = [self.nodes[k] for k in part["children"]
                  if self.nodes[k]["level"] == BREAKDOWN and self.nodes[k]["status"] == DONE]
        pieces = [self.nodes[k] for split in splits for k in split["children"] if self.nodes[k]["level"] == PART]
        return bool(pieces) and all(self.part_done(p) for p in pieces)
