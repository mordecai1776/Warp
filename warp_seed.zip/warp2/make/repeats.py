# WARP2/warp2/make/repeats.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/repeats.py
#  Used by   : warp2/make/stage.py (an answer already failed is a fail).
#  Uses      : stdlib hashlib, re.
#  Description:
#    An answer is known by its words with spacing, blank lines and comments
#    taken away, so the same answer said again with different spacing is the
#    same answer. A node remembers every answer that failed; giving one of
#    them again fails at once, without asking the judges.
#  User intention (Andrew, 2026-09-24): "There will be checks for repeats and
#    those will be treated as fails."
# ============================================================================
from __future__ import annotations

import hashlib
import re


def mark(answer: str) -> str:
    """Intention: the answer's identity, the same however it is spaced."""
    text = re.sub(r"(?m)#.*$", "", str(answer or ""))
    text = " ".join(text.split()).lower()
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def is_repeat(node: dict, answer: str) -> bool:
    """Intention: this answer already failed at this node."""
    return mark(answer) in node.get("tried", [])


def failed(node: dict, answer: str) -> None:
    """Intention: remember a failed answer so it is never taken again here."""
    key = mark(answer)
    if key not in node["tried"]:
        node["tried"].append(key)
