# WARP2/warp2/make/prompt_keeper.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/prompt_keeper.py
#  Used by   : warp2/make/stage.py (around the models' maker).
#  Uses      : nothing — it stands in front of the fleet.
#  Description:
#    The fleet, with the last prompt each model was asked kept. The models'
#    maker is asked through it, so a lesson can carry exactly what was asked —
#    which is what practice asks again of a model that needs it.
#  User intention (Andrew, 2026-09-24): "it should also look for what it needs
#    to pratice on."
# ============================================================================
from __future__ import annotations


class PromptKeeper:
    """The fleet, remembering what it last asked each model."""

    def __init__(self, fleet) -> None:
        """Intention: every call but ask goes straight through."""
        self._fleet = fleet
        self.last: dict = {}

    def __getattr__(self, name):
        """Intention: the fleet's own everything else."""
        return getattr(self._fleet, name)

    def ask(self, model: str, prompt: str) -> str:
        """Intention: asked as the fleet asks, with the prompt kept."""
        self.last[str(model)] = str(prompt)
        return self._fleet.ask(model, prompt)
