# WARP2/warp2/make/kg_wiring.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/kg_wiring.py
#  Used by   : warp2/work/loop.py (Loop.take_a_phase, the wiring phase).
#  Uses      : warp2/make/{runner,levels}.py, warp2/make/agents/{wiring,
#              kg_plan}.py, warp2/store/store.py (degrees: each concept's count of
#              relations, grouped in one query).
#  Description:
#    A stage that only wires the knowledge graph. The least connected concept
#    not wired lately is picked, with the concepts whose names share the most
#    words with it; a wiring plan is made, and — like anything made — it is
#    researched, questioned, checked for common problems, then judged and
#    tagged, here by EVERY model whatever trust says. A plan that passes is
#    written: facts only between concepts that were already there. Either
#    way the concept is marked as wired now, so the next turn goes elsewhere.
#  User intention (Andrew, 2026-09-24): "we need to add a stage that just works
#    on wiring the kg it should have its plan tagged by all of the models."
# ============================================================================
from __future__ import annotations

from warp2.make import runner
from warp2.make.agents.kg_plan import RELATIONS, write
from warp2.make.agents.wiring import read
from warp2.make.levels import WIRING

# Intention: the attribute a concept carries once a wiring turn has looked at it.
WIRED = "wired_at"


def _degrees(store) -> dict:
    """Intention: how many relations each concept has, counted by the store in one grouped query
    (2026-11-06: the old per-pair loop held the runner silent for 122 s)."""
    return store.degrees(RELATIONS + ("derives",), "concept:")


def _names(store) -> dict:
    """Intention: every concept's name."""
    return {str(s): str(v) for s, v in store.attributed("name") if str(s).startswith("concept:")}


def _pick(store) -> tuple:
    """(seed, its neighbours by shared words) — the least connected concept not yet wired.

    Intention: the neighbours offered are the ones whose names share the most
    words with it, as many as have any shared word, most first; with none,
    the best connected concepts, so it is wired toward the graph's middle.
    """
    names = _names(store)
    if len(names) < 2:
        return "", []
    degree = _degrees(store)
    wired = {str(s) for s, _v in store.attributed(WIRED)}
    todo = sorted((c for c in names if c not in wired), key=lambda c: (degree.get(c, 0), c))
    if not todo:
        return "", []
    seed = todo[0]
    words = set(names[seed].lower().split())
    near = sorted((c for c in names if c != seed), key=lambda c: (-len(words & set(names[c].lower().split())),
                                                                   -degree.get(c, 0), c))
    shared = [c for c in near if words & set(names[c].lower().split())]
    return seed, (shared or near)


def _known(store, seed: str, near: list, names: dict, room: int) -> str:
    """Intention: the concepts as `- name: definition` lines, the seed first, as many as fit the room."""
    lines, used = [], 0
    for cid in [seed] + near:
        said = store.current(subject=cid, attr="definition")
        line = f"- {names[cid]}: {said[0]['value'] if said else '(no definition yet)'}"
        if room and used + len(line) > room and len(lines) >= 2:
            break
        lines.append(line)
        used += len(line) + 1
    return "\n".join(lines)


def _without_wrong(job) -> str:
    """The passed plan without the facts most of the judges' weight called wrong.

    Intention: a plan that passes may still have a wrong fact in it; only
    what the judges held right is written (Andrew, 2026-09-24: the tagging
    "should also judge weather it was right").
    """
    import json
    node = job.nodes[job.row["root"]]
    wrong = set(node.get("verdicts", {}).get(node.get("chosen_by", ""), {}).get("wrong_items", []))
    try:
        rows = json.loads(job.row.get("passed_answer", "") or "[]")
    except ValueError:
        return ""
    return json.dumps([row for at, row in enumerate(rows, start=1) if at not in wrong])


def step(root, state, store, fleet, worker, needs) -> dict:
    """Intention: one step of wiring one concept; {"did": ...} with what happened."""
    from warp2.make.book import JobBook
    going = [j for j in JobBook(state).all() if j.row.get("kind") == WIRING]
    if going:
        seed, known = going[0].row["seed"], going[0].row["known"]
    else:
        seed, near = _pick(store)
        if not seed:
            return {"did": "nothing", "why": "no concept waits for wiring"}
        room = max((fleet.room_for_prompt(n) for n in fleet.names()), default=0) // 3 if fleet else 0
        known = _known(store, seed, near, _names(store), room)
    name = known.splitlines()[0][2:].split(":", 1)[0]
    said = runner.step(root, state, store, fleet, worker, needs, f"wire:{seed}", WIRING,
                       f"wiring the concept '{name}' into the knowledge graph",
                       {"seed": seed, "known": known, "target": seed})
    if said["outcome"] == runner.GOING:
        return {"did": "going", "seed": seed, "said": said["said"]}
    store.assert_fact(seed, "has", attr=WIRED, value=said["outcome"])
    if said["outcome"] == runner.PASSED:
        facts, _why = read(_without_wrong(said["job"]), known)
        written = write(store, facts, f"kg wiring of {seed}")
        return {"did": "wired", "seed": seed, "facts": written}
    return {"did": "not wired", "seed": seed, "said": said["said"]}
