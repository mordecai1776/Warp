# WARP2/warp2/make/step_trust.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/step_trust.py
#  Used by   : warp2/make/stage.py (_record — after every judged step),
#              warp2/make/judges.py (pool, judge — how far a judge is trusted),
#              warp2/make/tests/test_step_trust.py.
#  Uses      : warp2/make/trust.py (of), warp2/make/ledger.py (JUDGED).
#  Description:
#    Judges earn trust at each step, not only from a finished job. After a
#    step is judged, each judge is scored against what the OTHER judges
#    decided (their mean above one half or not) — leaving itself out, so no
#    judge grades itself — and that goes in the ledger as STEP_JUDGED.
#    A judge's trust is the higher of its final-evaluation trust and half its
#    step trust: agreeing with the others at a step is a weaker sign than
#    being right about how the whole job turned out, so it can lift a judge
#    only half way, and the final evaluation still decides the rest.
#  User intention (Andrew, 2026-10-08): chose "Earn trust at each step" —
#    "Judges also earn trust from how each step turns out, not only from a
#    finished job, so the fast mode can start sooner." (No make job had ever
#    finished, so no judge had ever earned trust, so judging never thinned.)
# ============================================================================
from __future__ import annotations

from warp2.make import trust
from warp2.make.ledger import JUDGED

STEP_JUDGED = "step_judged"   # a judge: how near its score was to what the other judges decided, by level

# Intention: the score a step passes at — the same line the judges use.
PASS = 0.5


def record(ledger, level: str, verdicts: dict) -> int:
    """Every judge of every verdict at this step scored against the others; how many were scored.

    Intention: a verdict needs two judges or more — with one, there is no one
    else to be measured against.
    """
    scored = 0
    for verdict in (verdicts or {}).values():
        by = {m: float(s) for m, s in (verdict.get("by") or {}).items()}
        if len(by) < 2:
            continue
        for model, score in by.items():
            others = [s for m, s in by.items() if m != model]
            outcome = 1.0 if sum(others) / len(others) > PASS else 0.0
            ledger.add(STEP_JUDGED, model, level, 1.0 - abs(score - outcome))
            scored += 1
    return scored


def of(ledger, model: str, level: str = "*") -> float:
    """Intention: a judge's trust — its final-evaluation trust, or half its step trust, whichever is more."""
    return max(trust.of(ledger, JUDGED, model, level), 0.5 * trust.of(ledger, STEP_JUDGED, model, level))


def pool(ledger, models: list, level: str = "*") -> float:
    """Intention: a pool's trust — the mean of its judges'; an empty pool is 0."""
    models = list(models)
    return sum(of(ledger, m, level) for m in models) / len(models) if models else 0.0
