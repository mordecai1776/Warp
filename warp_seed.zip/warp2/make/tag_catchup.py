# WARP2/warp2/make/tag_catchup.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tag_catchup.py
#  Used by   : warp2/work/side/tag_catchup.py (the general training phase).
#  Uses      : warp2/make/{lessons,library,scoring,ledger,outcomes,home}.py,
#              warp2/chat_learning/asking.py (ask).
#  Description:
#    Everything made that not every model has tagged yet, tagged by the ones
#    that have not — newest first, one made thing a turn, every missing model
#    asked. While trust is growing, judging thins out during the make cycle
#    to save time; this is where the rest catch up, so every model's tags sit
#    beside every other model's on every piece of work — the maker's own
#    tags too, though its score of its own work is never counted. A late tag
#    is scored against how the work turned out as soon as that is known.
#  User intention (Andrew, 2026-09-24): "lets have the newest things made
#    during the run that were not tagged by everything be tagged by
#    everything in the general training".
# ============================================================================
from __future__ import annotations

import json

from warp2.chat_learning.asking import ask
from warp2.make import outcomes, scoring
from warp2.make.home import home
from warp2.make.ledger import JUDGED, RIGHT, TAGGED
from warp2.make.lessons import Lessons
from warp2.make.library import Library


def _late_path(state_dir):
    """Intention: state/make/late_tags.jsonl — one line per late judgement."""
    return home(state_dir) / "late_tags.jsonl"


def late(state_dir) -> list:
    """Intention: every late judgement so far."""
    try:
        return [json.loads(l) for l in _late_path(state_dir).read_text(encoding="utf-8").splitlines() if l.strip()]
    except (OSError, ValueError):
        return []


def _key(row: dict) -> str:
    """Intention: one made thing — the job and the node."""
    return f"{row.get('item')}|{row.get('node')}"


def _tagged(row: dict, done: dict) -> set:
    """Intention: every model that already judged or tagged this made thing."""
    verdict = row.get("verdicts", {}).get(row.get("chosen_by", ""), {})
    return set(verdict.get("by", {})) | set(verdict.get("tags", {})) | done.get(_key(row), set())


def missing(state_dir, names: list) -> tuple:
    """(the newest passed lesson not every model has tagged, the models missing) — or (None, [])."""
    done: dict = {}
    for tag in late(state_dir):
        done.setdefault(tag["key"], set()).add(tag["model"])
    for row in reversed(Lessons(state_dir).rows()):
        if not row.get("passed") or not row.get("library_id"):
            continue
        gone = [n for n in names if n not in _tagged(row, done)]
        if gone:
            return row, gone
    return None, []


def score(ledger, level: str, said: dict, model: str, outcome: float) -> None:
    """Intention: one late judgement scored against the outcome — its score, its right call, its tags."""
    ledger.add(JUDGED, model, level, 1.0 - abs(float(said["score"]) - outcome))
    ledger.add(RIGHT, model, level, 1.0 if bool(said["right"]) == (outcome >= 0.5) else 0.0)
    tags = said.get("tags") or []
    if tags:
        right = sum(1 for t in tags if (float(t.get("weight", 1.0)) >= 0) == (outcome >= 0.5))
        ledger.add(TAGGED, model, level, right / len(tags))


def turn(state_dir, fleet, ledger) -> dict:
    """Intention: one made thing tagged by every model that has not; what was done."""
    names = list(fleet.names()) if fleet is not None else []
    row, gone = missing(state_dir, names)
    if row is None:
        return {"did": "nothing", "why": "everything made has been tagged by every model"}
    kept = Library(state_dir).get(row["library_id"])
    if kept is None:
        return {"did": "nothing", "why": "the made answer is no longer kept"}
    asked = scoring.prompt(row["level"], row["what"], kept["answer"], [])
    outcome = outcomes.of(state_dir, row.get("item", ""))
    maker = row.get("answers", {}).get(row.get("chosen_by", ""), {}).get("by", "")
    got = 0
    with _late_path(state_dir).open("a", encoding="utf-8") as out:
        for model in gone:
            said = scoring.read(ask(fleet, model, asked))
            if said is None:
                said = {"score": None, "right": None, "tags": [], "why": "no usable answer"}
            else:
                got += 1
                if outcome is not None and model != maker:
                    score(ledger, row["level"], said, model, outcome)
            out.write(json.dumps({"key": _key(row), "item": row.get("item"), "level": row["level"],
                                  "model": model, "own_work": model == maker, **said},
                                 ensure_ascii=False) + "\n")
    ledger.save()
    return {"did": "tagged", "what": row["what"], "level": row["level"], "asked": len(gone), "answered": got}
