# WARP2/warp2/make/ladder.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/ladder.py
#  Used by   : warp2/make/stage.py (who the models' maker is at this try).
#  Uses      : warp2/make/ledger.py (RUNG — how each rung has done at a level);
#              stdlib re.
#  Description:
#    The smallest solution first. The rungs of the models' maker, in order:
#    code that the tree already has (automations), then every model from the
#    smallest to the biggest. A node climbs one rung each time it runs out of
#    tries. A rung whose record at this level is certainly worse than a rung
#    above it (its best is below the other's worst) is stepped over — so work
#    starts where it has been done well, and moves down to smaller rungs as
#    smaller rungs learn it.
#  User intention (Andrew, 2026-09-24): "there should be a part in every part
#    where it tries to find automations then action models or ml solutions
#    then bigger and bigger things to do everything wanting to use smaller
#    parts for everything."
# ============================================================================
from __future__ import annotations

import re

from warp2.make.ledger import RUNG

# Intention: the rung that is the tree's own code.
CODE = "code"


def size_of(name: str) -> float:
    """Intention: a model's size in billions from its name; unknown is read as middling."""
    found = re.findall(r"(\d+(?:\.\d+)?)\s*b\b", str(name).lower().replace("-", " ").replace(":", " "))
    return float(found[-1]) if found else float("nan")


# Intention (Andrew, 2026-10-29: "The other models are meant to be nannies that eventually get replaced by the eye
# itself. So there needs to be a system to do so."; BUILD_LOG 931): THE EYE IS THE SMALLEST RUNG. Its makers (the
# level's part, then the master — warp2/make/eye_makers.py) stand on the ladder right after the tree's own code and
# before every model, so the Eye is asked first at every level. An Eye rung whose record at a level is certainly
# worse than a model's is stepped over like any rung (`climbable`); a rung with no record is never stepped over, so
# an unproven Eye is tried, never skipped. As the Eye's record at a level rises, the models above it are reached
# less and less — that is the nannies being replaced, by the same rule that already orders the rungs.
EYE_RUNGS = ("eye:parts", "eye:master")


def rungs(fleet, kind: str, with_code: bool, with_eye: bool = True) -> list:
    """Intention: code (when this level has code that can do it), then the Eye's makers, then the models, smallest
    first."""
    names = list(fleet.names(kind)) if fleet is not None else []
    known = sorted(size_of(n) for n in names if size_of(n) == size_of(n))
    middle = known[len(known) // 2] if known else 0.0
    ordered = sorted(names, key=lambda n: (size_of(n) if size_of(n) == size_of(n) else middle, n))
    return ([CODE] if with_code else []) + (list(EYE_RUNGS) if with_eye else []) + ordered


def climbable(ledger, level: str, ladder: list) -> list:
    """Intention: the ladder with every rung certainly worse than one above it stepped over."""
    kept = []
    for at, rung in enumerate(ladder):
        _low, high = ledger.bounds(RUNG, rung, level)
        if any(high < ledger.bounds(RUNG, above, level)[0] for above in ladder[at + 1:]):
            continue
        kept.append(rung)
    return kept or list(ladder)


def passed(ledger, level: str, rung: str, score: float) -> None:
    """Intention: how a rung's answer did at this level."""
    ledger.add(RUNG, rung, level, float(score))
