# WARP2/warp2/make/training_needs.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/training_needs.py
#  Used by   : warp2/work/loop.py (the training phase orders its round by it),
#              warp2/make/practice.py (the top need is what is practised),
#              warp2/ui/make_tab.py (shown).
#  Uses      : warp2/make/{ledger,trust}.py, warp2/research/weak_spots.py,
#              warp2/makers/skills.py (ranked).
#  Description:
#    What needs training most, measured and ranked, one number each from 0
#    (fine) to 1 (can do nothing): each maker at each level of making (the
#    models, the Eye's parts, the Eye's master) by the scores its answers
#    earned, each agent role by the trust the models have earned in it, each
#    gate rule by how often it refuses, and each task the Eye cannot do. A
#    record with little in it counts for little either way (n/(n+1)), so an
#    untried area reads as needing it. Written to state/make/training_needs.json
#    each time so the cockpit can show it.
#    BUILD_LOG 1466 (Andrew, 2026-11-08 20:44: practice "would be general
#    practice"): every skill in the skills table (warp2/makers/skills.py) is a
#    need too - each game played, each game made, each coding task, the Eye's
#    judgement part at each level, each of the Eye's block domains - its kind
#    "skill:<kind>", its need the table's own (room left times how it moves or
#    how long since it was tried).
#  User intention (Andrew, 2026-09-24): "have a system to what needs the most
#    training it should also look for what it needs to pratice on."
# ============================================================================
from __future__ import annotations

import json

from warp2.make import trust
from warp2.make.home import home
from warp2.make.ledger import MADE

# Intention: the three makers and the agent roles, as the ledger names them.
MAKERS = ("models", "eye:parts", "eye:master")
ROLES = ("research", "socratic", "common_problems", "kg_plan")

# Intention: which side steps answer which kind of need, first to last.
STEPS_FOR = {
    "eye": ("practice_what_is_weakest", "teach_eye_what_was_made", "train_eye"),
    "models": ("practice_what_is_weakest", "tag_what_all_have_not"),
    "role": ("practice_what_is_weakest", "tag_what_all_have_not"),
    "gate": ("practice_what_is_weakest", "weigh_the_gate"),
    "capability": ("try_eye_on_tasks",),
    # Intention (BUILD_LOG 1466): the skills table's kinds - practice first, then the step that does that work.
    "skill:play": ("practice_what_is_weakest", "make_and_play_game"),
    "skill:game": ("practice_what_is_weakest", "make_and_play_game"),
    "skill:code": ("practice_what_is_weakest", "make_code"),
    "skill:judge": ("practice_what_is_weakest", "teach_eye_what_was_made"),
    "skill:blocks": ("train_pairs",),
}


def _levels(ledger) -> list:
    """Intention: every level any maker has been scored at."""
    found = set()
    for key in ledger.scores:
        kind, _source, thing = key.split("|", 2)
        if kind == MADE:
            found.add(thing)
    return sorted(found)


def needs(state_dir, store, fleet, ledger) -> list:
    """Intention: every need, most first: {area, kind, need, why, ...}."""
    rows = []
    for level in _levels(ledger):
        for maker in MAKERS:
            mean, count = ledger.mean(MADE, maker, level)
            rows.append({"area": f"{maker} at {level}", "kind": "eye" if maker.startswith("eye") else "models",
                         "maker": maker, "level": level, "need": round(1.0 - mean * count / (count + 1.0), 4),
                         "why": f"its answers scored {mean:.2f} over {count}"})
    names = list(fleet.names()) if fleet is not None else []
    for role in ROLES:
        held = trust.pool(ledger, "role:" + role, names)
        rows.append({"area": f"the {role.replace('_', ' ')} agent", "kind": "role", "role": role,
                     "need": round(1.0 - held, 4), "why": f"the models' trust in it is {held:.2f}"})
    if store is not None:
        from warp2.research.weak_spots import WeakSpots
        for spot in WeakSpots(store, state_dir).questions():
            # Intention: a decision point that has not graduated is its own
            # kind (2026-10-23); no side step trains it yet, so it orders no
            # step — it reaches self-improvement through WeakSpots instead.
            kind = ("capability" if spot["about"].startswith("task:")
                    else "decision" if spot["about"].startswith("decision:") else "gate")
            rows.append({"area": spot["about"], "kind": kind, "about": spot["about"],
                         "need": round(float(spot["weakness"]), 4), "why": spot["why"]})
    from warp2.makers.skills import ranked
    for skill in ranked(state_dir):
        rows.append({"area": skill["skill"], "kind": f"skill:{skill['kind']}", "skill": skill["skill"],
                     "skill_kind": skill["kind"], "need": skill["need"],
                     "why": f"level {skill['level']:.2f} over {skill['tries']} tries, moving {skill['progress']}, "
                            f"stale {skill['stale']:.2f}"})
    rows.sort(key=lambda r: (-r["need"], r["area"]))
    try:
        (home(state_dir) / "training_needs.json").write_text(json.dumps(rows[:50], indent=1), encoding="utf-8")
    except OSError:
        pass
    return rows


def steps_first(rows: list) -> list:
    """Intention: the side steps that answer the biggest needs, in that order, each once."""
    out = []
    for row in rows:
        for verb in STEPS_FOR.get(row["kind"], ()):
            if verb not in out:
                out.append(verb)
    return out
