# WARP2/warp2/make/agents/part_maker.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/part_maker.py
#  Used by   : warp2/make/levels.py (what the part level makes).
#  Uses      : warp2/parts/{body_ask,simple_body,skeleton,part_check}.py — the
#              parts builder's own part-doers, kept as they are.
#  Description:
#    One part's body. Code writes it when code can (a part whose whole job is
#    known from its name, or one the tree already writes one common way);
#    otherwise a model is asked for that one part alone, with the whole
#    outline and what the task is. A part that will not fit into the file, or
#    is not finished, is not usable.
#  User intention (Andrew, 2026-09-24): "for each part of it happens again
#    until all of it is done" — and every part tries automations first.
# ============================================================================
from __future__ import annotations

import textwrap

from warp2.parts.body_ask import BodyAsk
from warp2.parts.part_check import PartCheck
from warp2.parts.simple_body import SimpleBody
from warp2.parts.skeleton import Skeleton


def by_code(worker, outline: str, name: str) -> str:
    """Intention: the part as code writes it, or "" to ask a model."""
    skeleton = Skeleton(outline)
    stub = skeleton.part(name)
    simple = SimpleBody()(name, stub, skeleton.parameters(name))
    if simple:
        return simple
    siblings = getattr(getattr(worker, "parts", None), "siblings", None)
    if siblings is not None:
        written, _source = siblings(name, stub, skeleton.parameters(name))
        if written and not PartCheck().issue(textwrap.dedent(written)):
            return written
    return ""


def ask(worker, model: str, path: str, outline: str, name: str, told: str, refused: str = "") -> tuple:
    """Intention: (the part, "") or ("", why it is not usable)."""
    return BodyAsk()(worker, model, name, Skeleton(outline).part(name), path, outline, told, refused)


def fits(outline: str, name: str, written: str) -> tuple:
    """Intention: (the outline with the part in it, "") or ("", why it would not go in)."""
    try:
        return Skeleton(outline).fill(name, written).source, ""
    except (KeyError, ValueError) as exc:
        return "", f"it would not fit into the file: {exc}"
