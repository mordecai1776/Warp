# WARP2/warp2/make/agents/breaker.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/breaker.py
#  Used by   : warp2/make/levels.py (what the breakdown level makes).
#  Uses      : warp2/parts/skeleton.py, warp2/work/patch.py (the parts of a file by name).
#  Description:
#    The breaker: takes the plan's outline and splits every part that does
#    more than one thing into smaller parts — new functions, each with its
#    signature and one Intention line — that the bigger part will call. Every
#    part already in the plan stays, with its name and signature. An outline
#    whose parts are each one small thing already comes back as it was.
#  User intention (Andrew, 2026-09-24): "Then a agent breaks that plan down
#    into its smallest parts and off it happens again".
# ============================================================================
from __future__ import annotations

from warp2.parts.skeleton import Skeleton

TAIL = [
    "break this outline down into its smallest parts:",
    "- any function or method that does more than one thing gets smaller functions (or methods)",
    "  that it will call, each with its full signature and one docstring line starting `Intention:`;",
    "- keep every existing class, function and method, with the same name and signature;",
    "- every body stays `...` — nothing is written yet;",
    "- if every part is already one small thing, give the outline back unchanged.",
    "",
    "answer with the whole outline in one fenced python block, its path on the first line as a comment:",
]


def ask(worker, model: str, path: str, outline: str, understood: str, checks: list,
        refused: str = "") -> tuple:
    """Intention: (the broken-down outline, "") or ("", why it is not usable)."""
    room = worker.fleet.room_for_prompt(model)
    lines = [f"the plan of {path}:", "```python", worker._fits(outline, room, []), "```", ""]
    if understood:
        lines += ["what the task is:", worker._fits(understood, room // 3, lines), ""]
    if checks:
        lines += ["it must get these right:"] + [f"- {c}" for c in checks] + [""]
    if refused:
        lines += ["the last breakdown was turned down for:", refused, ""]
    answer = worker.fleet.ask(model, "\n".join(lines + TAIL + [f"# path: {path}"]))
    return read(worker.files(answer or "", expected_path=path).get(path, ""), outline)


def read(source: str, before: str) -> tuple:
    """Intention: usable when it parses and keeps every part the plan had."""
    outline = Skeleton(source)
    if not outline.parses():
        return "", "the breakdown is not Python that parses"
    lost = [name for name in Skeleton(before).stubs() if name not in outline.stubs()]
    if lost:
        return "", "the breakdown dropped parts the plan had: " + ", ".join(lost[:4])
    emptied = [name for name in _written(before) if name in outline.stubs()]
    if emptied:
        return "", "the breakdown emptied parts already written: " + ", ".join(emptied[:4])
    return outline.source, ""


def _written(source: str) -> list:
    """Intention: the parts of an outline that already have their bodies."""
    from warp2.work import patch
    stubs = set(Skeleton(source).stubs())
    return [name for name in patch._spans(source) if name not in stubs]
