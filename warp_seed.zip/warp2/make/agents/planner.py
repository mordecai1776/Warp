# WARP2/warp2/make/agents/planner.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/planner.py
#  Used by   : warp2/make/levels.py (what the plan level makes).
#  Uses      : warp2/parts/outline_ask.py (TAIL — the outline the parts
#              builder already asks for), warp2/parts/outline_of_a_test.py
#              (a test's outline, when code knows it), warp2/parts/skeleton.py.
#  Description:
#    The planner: the plan of a file is its outline — every class and
#    function it needs with its signature and one Intention line, bodies
#    left empty — made from what the task level understood. Code makes it
#    when code knows it (a test); otherwise a model.
#  User intention (Andrew, 2026-09-24): "Then a planner agent comes in and
#    makes a plan and this all happens again."
# ============================================================================
from __future__ import annotations

from warp2.parts.outline_ask import TAIL
from warp2.parts.skeleton import Skeleton


def by_code(root, item: dict, sliced: dict) -> str:
    """Intention: the outline code knows for sure, or "" to ask a model."""
    from warp2.parts.outline_of_a_test import OutlineOfATest
    return OutlineOfATest(root)(str(item.get("kind") or ""), sliced.get("context") or {}) or ""


def ask(worker, model: str, item: dict, sliced: dict, path: str, understood: str,
        checks: list, refused: str = "") -> tuple:
    """Intention: (the outline, "") or ("", why it is not usable)."""
    room = worker.fleet.room_for_prompt(model)
    lines = worker.head(item, sliced, room)
    if understood:
        lines += ["what the task is, as it was understood:", understood, ""]
    if checks:
        lines += ["it must get these right:"] + [f"- {c}" for c in checks] + [""]
    if refused:
        lines += ["the last plan was turned down for:", refused, ""]
    answer = worker.fleet.ask(model, "\n".join(lines + TAIL + [f"# path: {path}"]))
    return read(worker.files(answer or "", expected_path=path).get(path, ""))


def read(source: str) -> tuple:
    """Intention: usable when it parses and has parts still to write."""
    outline = Skeleton(source)
    if not outline.parses():
        return "", "the outline is not Python that parses"
    if not outline.stubs():
        return "", "the outline has no parts left to write"
    return outline.source, ""
