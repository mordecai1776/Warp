# WARP2/warp2/make/agents/socratic.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/socratic.py
#  Used by   : warp2/make/stage.py (the second step of every stage).
#  Uses      : warp2/make/agents/{who,questions}.py.
#  Description:
#    The Socratic agent: questions the work itself — what it assumes, what
#    would make it wrong, what it depends on, what is unclear. Its questions
#    go to the knowledge graph as more research for this task.
#  User intention (Andrew, 2026-09-24): "The soc agent sends its output to the
#    kg for more research calls for the task."
# ============================================================================
from __future__ import annotations

from warp2.make.agents.questions import asked_for, raise_all
from warp2.make.agents.who import who

ROLE = "socratic"

PROMPT = (
    "Question this piece of work the way Socrates would: {level} — {what}\n\n"
    "What is already known:\n{known}\n\n"
    "What does it assume? What would make it wrong? What does it depend on? What is "
    "unclear about what is wanted? Turn each doubt into a question someone could look up. "
    "Answer only with a JSON list of strings; an empty list if there is no real doubt.")


def call(fleet, ledger, needs, about: str, level: str, what: str, known: str, turn: str = "",
         review=None) -> dict:
    """Intention: {model, needs} (and what was turned down, when it was) — the doubts raised as needs about `about`."""
    model = who(fleet, ledger, ROLE, turn=turn)
    if not model:
        return {"model": "", "heard": "", "needs": []}
    heard: dict = {}
    questions = asked_for(fleet, model, PROMPT.format(level=level, what=what, known=known or "(nothing yet)"),
                          heard)
    # Intention: the other models judge and tag this work first (warp2/make/
    # agent_review.py); work they turn down is not raised.
    if review is not None:
        kept = review(questions, model)
        if kept is None:
            return {"model": model, "heard": heard.get("said", ""), "needs": [], "turned_down": questions}
        questions = kept
    return {"model": model, "heard": heard.get("said", ""), "needs": raise_all(needs, about, questions, f"make: socratic agent ({level})")}
