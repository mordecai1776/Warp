# WARP2/warp2/make/agents/who.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/who.py
#  Used by   : warp2/make/agents/{research,socratic,common_problems,kg_plan}.py.
#  Uses      : warp2/make/ledger.py (the role records it is handed).
#  Description:
#    Which model plays an agent's role: while any model has no record in it,
#    those models in turn (the one the fleet would most likely pick first),
#    the turn moving along by how many times the role has been played; once
#    all have records, the one whose record could be the best (mean plus one
#    standard error), so every model earns (or loses) trust in every role.
#  User intention (Andrew, 2026-09-24): "tempered by how well things are doing."
# ============================================================================
from __future__ import annotations

# Intention: the ledger kind a role's record is kept under.
ROLE = "role:"


def who(fleet, ledger, role: str, kind: str = "build", turn: str = "") -> str:
    """The model to play `role` now; "" when there is no model.

    Intention: `turn` (the node and its try) moves the untrusted turn along
    the fleet between tries, so every model plays every role long before any
    job is settled.
    """
    names = list(fleet.names()) if fleet is not None else []
    if not names:
        return ""
    # Intention (2026-10-09, fix 5.5, check D10): EXPLORE BEFORE EXPLOIT. The
    # first model with any trust took the role for good, so the others never
    # earned a record in it. Every model plays it until it has a record (two
    # plays); then the role goes to the one whose record could be the best —
    # its mean plus one standard error — so a model loses turns only once it
    # is surely worse (Graves et al. 2017).
    unmeasured = [n for n in names if ledger.mean(ROLE + role, n, "*")[1] < 2]
    if not unmeasured:
        return max(names, key=lambda n: (ledger.bounds(ROLE + role, n, "*")[1], n))
    played = sum(ledger.mean(ROLE + role, n, "*")[1] for n in names)
    likely = fleet.likely(kind) if hasattr(fleet, "likely") else ""
    order = ([likely] if likely in unmeasured else []) + [n for n in sorted(unmeasured) if n != likely]
    import hashlib
    step = int(hashlib.sha256(str(turn).encode("utf-8")).hexdigest()[:8], 16) if turn else 0
    return order[(int(played) + step) % len(order)]


def played(ledger, role: str, model: str, score: float) -> None:
    """Intention: how the work this model's role served turned out."""
    if model:
        ledger.add(ROLE + role, model, "*", float(score))
