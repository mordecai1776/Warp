# WARP2/warp2/make/agents/proposal.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/proposal.py
#  Used by   : warp2/make/levels.py (what the proposal level makes).
#  Uses      : warp2/chat_learning/asking.py (json_in).
#  Description:
#    A way for the warp to improve itself, written as a project: a name,
#    what it is for, and its areas — each a small thing to build, with what
#    it is for. Made from one weak spot (a gate rule that keeps refusing, a
#    task the Eye cannot do, a step that keeps failing).
#  User intention (Andrew, 2026-09-24): "then check for any ways to self
#    improve and make a project for them which should look like a action task".
# ============================================================================
from __future__ import annotations

import json

from warp2.chat_learning.asking import json_in

PROMPT = (
    "The system that asked you this builds and trains itself. It is weak here: {what}\n\n"
    "What is known:\n{known}\n\n"
    "Propose one project that would make it stronger here. Answer only with one JSON object: "
    '{{"project": "a_short_snake_case_name", "for": "what the project is for, in one plain sentence", '
    '"areas": [{{"name": "a_short_snake_case_name", "for": "the one small thing this area builds"}}]}}')


def ask(fleet, model: str, what: str, known: str, refused: str = "") -> tuple:
    """Intention: (the proposal as JSON text, "") or ("", why it is not usable)."""
    extra = f"\n\nThe last proposal was turned down for: {refused}" if refused else ""
    try:
        said = fleet.ask(model, PROMPT.format(what=what, known=known or "(nothing yet)") + extra)
    except Exception as exc:
        return "", f"{type(exc).__name__}: {exc}"
    found = json_in(str(said or ""), "{", "}")
    if not isinstance(found, dict):
        return "", "it gave no proposal as JSON"
    text = json.dumps(found, sort_keys=True)
    return (text, "") if not read(text)[1] else ("", read(text)[1])


def _name(text) -> str:
    """Intention: a snake_case name, or "" when it is not one."""
    name = "".join(ch if ch.isalnum() else "_" for ch in str(text or "").strip().lower()).strip("_")
    return name if name and name[0].isalpha() else ""


def read(text: str) -> tuple:
    """Intention: (the proposal as a dict, "") or (None, why it is not usable)."""
    try:
        found = json.loads(text)
    except (TypeError, ValueError):
        return None, "the proposal is not JSON"
    project = _name(found.get("project"))
    areas = [{"name": _name(a.get("name")), "for": " ".join(str(a.get("for") or "").split())}
             for a in found.get("areas") or [] if isinstance(a, dict)]
    areas = [a for a in areas if a["name"] and a["for"]]
    if not project or not str(found.get("for") or "").strip() or not areas:
        return None, "a proposal needs a project name, what it is for, and at least one area"
    return {"project": project, "for": " ".join(str(found["for"]).split()), "areas": areas}, ""
