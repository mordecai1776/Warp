# WARP2/warp2/make/agents/kg_plan.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/kg_plan.py
#  Used by   : warp2/make/stage.py (after a stage passes).
#  Uses      : warp2/make/agents/who.py, warp2/chat_learning/asking.py;
#              warp2/store/schema.py through the store (its relation words),
#              warp2/tags/dehydrate.py (answers read as dehydrated tags).
#  Description:
#    The KG agent: from what was learned and made at a stage, plans what to
#    add to the knowledge graph — facts as subject, relation, object, with
#    the relation one of a few plain kinds. Only well-formed facts are kept;
#    they are written when the stage passes.
#  User intention (Andrew, 2026-09-24): "If not then it does all of the
#    researched and a kg agent makes a plan to add it to the kg."
# ============================================================================
from __future__ import annotations

from warp2.chat_learning.asking import ask, json_in
from warp2.make.agents.who import who

ROLE = "kg_plan"

# Intention: the relations a planned fact may use — the store's own words
# (warp2/store/schema.py), the ones that say how two things stand: each is a
# question the graph can answer ("what does X depend on?").
RELATIONS = ("contains", "depends_on", "supports", "contradicts", "defines", "triggers")

PROMPT = (
    "This was just done: {level} — {what}\n\n"
    "What was known and learned:\n{known}\n\n"
    "What was made:\n{made}\n\n"
    "Plan what to add to a knowledge graph, as dehydrated tags, one per line: "
    "[[relation object] subject], where relation is one of {relations}, "
    "and subject and object are short names (quote a name that has spaces).\n"
    "Example:\n[[depends_on \"shortest path\"] \"priority queue\"]")


def _name(text) -> str:
    """Intention: a fact's end as a short lower-case name; "" when it is not one."""
    words = " ".join(str(text or "").lower().split())
    return words if words and not any(ch in words for ch in "{}[]\\`") else ""


def call(fleet, ledger, level: str, what: str, known: str, made: str) -> dict:
    """Intention: {model, facts} — the well-formed facts the KG agent planned."""
    model = who(fleet, ledger, ROLE)
    if not model:
        return {"model": "", "facts": []}
    heard = ask(fleet, model, PROMPT.format(level=level, what=what, known=known or "(nothing)",
                                            made=made, relations=", ".join(RELATIONS)))
    # Intention: THE ANSWER IS READ AS DEHYDRATED TAGS FIRST (Andrew,
    # 2026-09-24: the models "work through dehydrated tags"); a JSON list is
    # still read, so a model still learning the form is not wasted. How much
    # of what it said was well-formed tags is its score at this role, so the
    # models that use the form well are picked for it more (who.py).
    from warp2.tags.dehydrate import parse, trees
    tagged = [f for f in parse(heard) if f["relation"] != "has"]
    said = tagged or json_in(heard)
    if model and ledger is not None:
        from warp2.make.agents.who import played
        played(ledger, ROLE, model, len(tagged) / max(1, len(trees(heard))) if trees(heard) else 0.0)
    facts = []
    for row in said if isinstance(said, list) else []:
        if not isinstance(row, dict):
            continue
        subject, obj = _name(row.get("subject")), _name(row.get("object"))
        relation = str(row.get("relation") or "")
        if subject and obj and relation in RELATIONS and (subject, relation, obj) not in facts:
            facts.append((subject, relation, obj))
    return {"model": model, "facts": facts}


def write(store, facts: list, source: str) -> int:
    """Intention: each planned fact into the store as concepts, saying where it came from — graded "judged", since every model reviewed it."""
    from warp2.tags.grounding import JUDGED
    speaking = store.as_source(JUDGED) if hasattr(store, "as_source") else None
    if speaking is not None:
        with speaking:
            return _write(store, facts, source)
    return _write(store, facts, source)


def _write(store, facts: list, source: str) -> int:
    """Intention: the facts written as concepts, with where they came from."""
    for subject, relation, obj in facts:
        a, b = f"concept:{subject.replace(' ', '_')}", f"concept:{obj.replace(' ', '_')}"
        store.assert_fact(a, "has", attr="name", value=subject)
        store.assert_fact(b, "has", attr="name", value=obj)
        store.assert_fact(a, relation, b)
        store.assert_fact(a, "has", attr="told_by", value=source)
    return len(facts)
