# WARP2/warp2/make/agents/questions.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/questions.py
#  Used by   : warp2/make/agents/{research,socratic,common_problems}.py.
#  Uses      : warp2/chat_learning/asking.py (ask, json_in),
#              warp2/research/need.py (Needs.raise_need, NotAQuestion).
#  Description:
#    The shared half of every agent that calls for research: ask a model for
#    a JSON list of questions, and raise each one as a need about the thing
#    being made, saying which agent raised it. A question that is not a
#    question is dropped by the need's own check. The web lane answers them.
#  User intention (Andrew, 2026-09-24): "There should be a research agent that
#    looks at what needs to be done and calls for research."
# ============================================================================
from __future__ import annotations

from warp2.chat_learning.asking import ask, json_in


def asked_for(fleet, model: str, prompt: str, heard: dict | None = None) -> list:
    """The list of questions a model gave; none when it gave none.

    Intention: `heard`, when given, keeps the first of what the model really
    said — so "it asked for nothing" can be told apart from "it said
    something that was not a list".
    """
    said = ask(fleet, model, prompt)
    if heard is not None:
        heard["said"] = " ".join(str(said).split())[:300]
    found = json_in(said)
    if not isinstance(found, list):
        return []
    out = []
    for q in found:
        text = " ".join(str(q.get("question") if isinstance(q, dict) else q).split())
        if text and text not in out:
            out.append(text)
    return out


def raise_all(needs, about: str, questions: list, seed: str) -> list:
    """Intention: each question raised as a need about `about`; the needs raised."""
    from warp2.research.need import NotAQuestion
    raised = []
    for question in questions:
        try:
            made = needs.raise_need(about, question, seed=seed)
        except (NotAQuestion, ValueError):
            continue
        raised.append(made["need"])
    return raised
