# WARP2/warp2/make/agents/known_problems.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/known_problems.py
#  Used by   : warp2/make/agents/common_problems.py.
#  Uses      : warp2/research/weak_spots.py (the gate rules that refuse, and
#              how often), warp2/train/mistakes.py (Mistakes — every complaint
#              that came back more than once).
#  Description:
#    Every problem that has happened before, worst first: the gate rules that
#    refuse work (by the share of times they refused), the complaints that
#    came back again and again, and what went wrong at this node before.
#  User intention (Andrew, 2026-09-24): "The common problem looks at their
#    actions and stops any common problems".
# ============================================================================
from __future__ import annotations
from warp2.record.swallowed import noted


def known(store, node: dict) -> list:
    """Intention: [{"problem", "weight"}] worst first, each problem once."""
    from warp2.research.weak_spots import WeakSpots
    rows = []
    for spot in WeakSpots(store).refusals():
        rows.append({"problem": spot["question"].replace("how do experienced programmers ", "failing to ")
                     .replace(" in python code", ""), "weight": spot["weakness"]})
    try:
        from warp2.train.mistakes import Mistakes
        for one in Mistakes(store).worst():
            if int(one.get("repeats") or 0) >= 2 and one.get("said"):
                rows.append({"problem": " ".join(str(one["said"]).split()),
                             "weight": min(1.0, int(one["repeats"]) / (int(one["total"]) or 1))})
    except Exception as exc:
        noted("warp2/make/agents/known_problems.py:known", exc)
    for why in node.get("whys", []):
        rows.append({"problem": str(why), "weight": 1.0})
    seen, out = set(), []
    for row in sorted(rows, key=lambda r: -r["weight"]):
        if row["problem"] and row["problem"] not in seen:
            seen.add(row["problem"])
            out.append(row)
    return out


def fitted(rows: list, room: int) -> str:
    """Intention: as many problems, worst first, as fit in the model's room; all when it said none."""
    lines, used = [], 0
    for row in rows:
        line = f"- {row['problem']}"
        if room and used + len(line) > room:
            break
        lines.append(line)
        used += len(line) + 1
    return "\n".join(lines)
