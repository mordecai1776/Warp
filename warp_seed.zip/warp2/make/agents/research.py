# WARP2/warp2/make/agents/research.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/research.py
#  Used by   : warp2/make/stage.py (the first step of every stage).
#  Uses      : warp2/make/agents/{who,questions}.py.
#  Description:
#    The research agent: reads what is to be done and what is already known,
#    and says what must be looked up first — only what is not already known.
#    Each question becomes a need; the stage waits until they are answered.
#  User intention (Andrew, 2026-09-24): "There should be a research agent that
#    looks at what needs to be done and calls for research."
# ============================================================================
from __future__ import annotations

from warp2.make.agents.questions import asked_for, raise_all
from warp2.make.agents.who import who

ROLE = "research"

PROMPT = (
    "Something is about to be done: {level} — {what}\n\n"
    "What is already known:\n{known}\n\n"
    "Before it is done, what has to be looked up? List only questions whose answers "
    "are NOT already known above, each one a full question someone could search for. "
    "Answer only with a JSON list of strings; an empty list if nothing needs looking up.")


def call(fleet, ledger, needs, about: str, level: str, what: str, known: str, turn: str = "",
         review=None) -> dict:
    """Intention: {model, needs} (and what was turned down, when it was) — the questions raised as needs about `about`."""
    model = who(fleet, ledger, ROLE, turn=turn)
    if not model:
        return {"model": "", "heard": "", "needs": []}
    heard: dict = {}
    questions = asked_for(fleet, model, PROMPT.format(level=level, what=what, known=known or "(nothing yet)"),
                          heard)
    # Intention: the other models judge and tag this work first (warp2/make/
    # agent_review.py); work they turn down is not raised.
    if review is not None:
        kept = review(questions, model)
        if kept is None:
            return {"model": model, "heard": heard.get("said", ""), "needs": [], "turned_down": questions}
        questions = kept
    return {"model": model, "heard": heard.get("said", ""), "needs": raise_all(needs, about, questions, f"make: research agent ({level})")}
