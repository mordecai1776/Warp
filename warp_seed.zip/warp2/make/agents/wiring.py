# WARP2/warp2/make/agents/wiring.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/wiring.py
#  Used by   : warp2/make/levels.py (what the wiring level makes).
#  Uses      : warp2/chat_learning/asking.py (json_in),
#              warp2/make/agents/kg_plan.py (RELATIONS — the store's words).
#  Description:
#    The KG wiring plan: given one concept that is barely connected and the
#    concepts it most likely belongs with, a model plans how they are wired —
#    facts between them, with the store's own relations. Only facts between
#    the concepts offered are usable: wiring joins what is there, it does not
#    invent new things.
#  User intention (Andrew, 2026-09-24): "we need to add a stage that just works
#    on wiring the kg it should have its plan tagged by all of the models."
# ============================================================================
from __future__ import annotations

import json

from warp2.chat_learning.asking import json_in
from warp2.make.agents.kg_plan import RELATIONS

PROMPT = (
    "These are concepts in a knowledge graph. The first one is barely connected to the rest.\n\n"
    "{concepts}\n\n"
    "Plan how they are really connected. Answer only with a JSON list of facts "
    '{{"subject": "a concept name above", "relation": one of {relations}, "object": "a concept name above", '
    '"why": "one line"}}. Only facts that are true; an empty list if none are.')


def ask(fleet, model: str, what: str, known: str, refused: str = "") -> tuple:
    """Intention: (the wiring plan as JSON text, "") or ("", why it is not usable)."""
    extra = f"\n\nThe last plan was turned down for: {refused}" if refused else ""
    try:
        said = fleet.ask(model, PROMPT.format(concepts=known, relations=", ".join(RELATIONS)) + extra)
    except Exception as exc:
        return "", f"{type(exc).__name__}: {exc}"
    found = json_in(str(said or ""))
    if not isinstance(found, list):
        return "", "it gave no wiring plan as a JSON list"
    text = json.dumps(found, sort_keys=True)
    return (text, "") if not read(text, known)[1] else ("", read(text, known)[1])


def offered(known: str) -> set:
    """Intention: the concept names offered, from the lines `- name: definition`."""
    return {line[2:].split(":", 1)[0].strip().lower() for line in known.splitlines() if line.startswith("- ")}


def read(text: str, known: str) -> tuple:
    """Intention: (the facts, "") — only well-formed facts between offered concepts — or ([], why)."""
    try:
        found = json.loads(text)
    except (TypeError, ValueError):
        return [], "the plan is not JSON"
    names = offered(known)
    facts = []
    for row in found if isinstance(found, list) else []:
        if not isinstance(row, dict):
            continue
        a = " ".join(str(row.get("subject") or "").lower().split())
        b = " ".join(str(row.get("object") or "").lower().split())
        relation = str(row.get("relation") or "")
        if a in names and b in names and a != b and relation in RELATIONS and (a, relation, b) not in facts:
            facts.append((a, relation, b))
    if not facts:
        return [], "the plan has no true-looking facts between the concepts offered"
    return facts, ""
