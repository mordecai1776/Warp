# WARP2/warp2/make/agents/understand.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/understand.py
#  Used by   : warp2/make/levels.py (what the task level makes).
#  Uses      : warp2/models/worker.py (Worker.head — the same view of the
#              work every ask about it shares).
#  Description:
#    The task level's answer: before anything is made, the task said plainly —
#    what it is for, what goes in and comes out, what is known that matters,
#    what is not known, and how it will be known to be done. This is what
#    the planner and every part are told the task is.
#  User intention (Andrew, 2026-09-24): the cycle starts with the task itself,
#    looked at and researched before any plan.
# ============================================================================
from __future__ import annotations

TAIL = [
    "Do not make anything yet. First say plainly, under these five headings:",
    "What it is for:", "What goes in and what comes out:", "What is known that matters:",
    "What is not known:", "How we will know it is done:",
]


def ask(worker, model: str, item: dict, sliced: dict, node: dict, refused: str = "") -> tuple:
    """Intention: (the understanding, "") or ("", why it is not usable)."""
    room = worker.fleet.room_for_prompt(model)
    lines = worker.head(item, sliced, room)
    if node.get("checks"):
        lines += ["it must get these right:"] + [f"- {c}" for c in node["checks"]] + [""]
    if refused:
        lines += ["the last try at this was turned down for:", refused, ""]
    answer = str(worker.fleet.ask(model, "\n".join(lines + TAIL)) or "").strip()
    return read(answer)


def read(answer: str) -> tuple:
    """Intention: usable when it speaks to most of the five headings."""
    said = sum(1 for head in TAIL[1:] if head.lower().rstrip(":") in answer.lower())
    if said < 3:
        return "", "it did not say what the task is under the headings asked for"
    return answer, ""
