# WARP2/warp2/make/agents/common_problems.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/common_problems.py
#  Used by   : warp2/make/stage.py (the step before anything is made).
#  Uses      : warp2/make/agents/{who,questions,known_problems}.py,
#              warp2/chat_learning/asking.py (ask, json_in).
#  Description:
#    The common problem agent: looks at what is about to be done against every
#    problem that has happened before, and says which could happen here and
#    how to avoid each. A problem it finds that this node has not met before
#    is marked on the node, becomes a check the judges must look for, and
#    research is raised for how to avoid it — and the stage retries from its
#    research, with that research in hand.
#  User intention (Andrew, 2026-09-24): "The common problem looks at their
#    actions and stops any common problems and if there are any it marks them
#    and it retries ... Every time the common problem agent finds a problem
#    they will do research for solutions and that will be added to the judge
#    cycle."
# ============================================================================
from __future__ import annotations

from warp2.chat_learning.asking import ask, json_in
from warp2.make.agents.known_problems import fitted, known
from warp2.make.agents.questions import raise_all
from warp2.make.agents.who import who

ROLE = "common_problems"

PROMPT = (
    "Something is about to be done: {level} — {what}\n\n"
    "What is known about how it will be done:\n{known}\n\n"
    "Problems that have happened before, worst first:\n{problems}\n\n"
    "Which of these problems (or any other common mistake) could happen here? "
    "Answer only with a JSON list of objects {{\"problem\": \"the problem\", "
    "\"avoid\": \"how to avoid it here\"}}; an empty list if none could.")


def call(fleet, ledger, needs, store, about: str, node: dict, known_text: str, review=None) -> dict:
    """Intention: {model, new} — the problems newly found at this node, already marked and researched."""
    model = who(fleet, ledger, ROLE, turn=f"{node['id']}|{node['attempt']}")
    if not model:
        return {"model": "", "new": []}
    rows = known(store, node)
    room = fleet.room_for_prompt(model) if hasattr(fleet, "room_for_prompt") else 0
    raw = ask(fleet, model, PROMPT.format(level=node["level"], what=node["what"],
                                          known=known_text or "(nothing yet)",
                                          problems=fitted(rows, room // 2) or "- none on record"))
    node["data"]["problems_heard"] = " ".join(str(raw).split())[:300]
    said = json_in(raw)
    hits = [h for h in (said if isinstance(said, list) else []) if isinstance(h, dict)]
    # Intention: the other models judge and tag the problems found first
    # (warp2/make/agent_review.py); problems they turn down are not marked.
    if review is not None:
        kept = review([(h.get("problem", ""), h.get("avoid", "")) for h in hits], model)
        if kept is None:
            return {"model": model, "new": [], "turned_down": len(hits)}
        hits = [h for h in hits if (h.get("problem", ""), h.get("avoid", "")) in kept]
    new = []
    for hit in hits:
        if not isinstance(hit, dict):
            continue
        problem = " ".join(str(hit.get("problem") or "").split())
        avoid = " ".join(str(hit.get("avoid") or "").split())
        if not problem or problem in node["problems"]:
            continue
        node["problems"].append(problem)
        node["checks"].append(f"{problem} — avoided: {avoid}" if avoid else problem)
        new.append(problem)
    node["needs"] += raise_all(needs, about, [f"how do you avoid {p} when doing {node['what']}" for p in new],
                               f"make: common problem agent ({node['level']})")
    return {"model": model, "new": new}
