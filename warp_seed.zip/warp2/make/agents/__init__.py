# WARP2/warp2/make/agents/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/agents/__init__.py
#  Used by   : warp2/make/stage.py (each step asks its agent).
#  Uses      : nothing itself.
#  Description:
#    The agents of a stage, one small file each: research, Socratic, common
#    problems, the KG plan, and the makers of each level (understanding,
#    plan, breakdown, part). Each asks one model one prompt and returns plain
#    data; none writes anything itself.
#  User intention (Andrew, 2026-09-24): "There should be a research agent that
#    looks at what needs to be done and calls for research. Then the Socratic
#    agent and a common problem agent look at it."
# ============================================================================
