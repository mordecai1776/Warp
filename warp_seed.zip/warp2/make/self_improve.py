# WARP2/warp2/make/self_improve.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/self_improve.py
#  Used by   : warp2/work/phases.py (the self-improvement phase).
#  Uses      : warp2/make/{runner,levels}.py, warp2/make/agents/proposal.py,
#              warp2/research/weak_spots.py (what the warp is bad at),
#              warp2/store/projects.py (Projects — open a project, add areas).
#  Description:
#    Looks for a way to improve itself and makes a project for it, as an
#    action task: the worst weak spot not yet worked on (a gate rule that
#    keeps refusing, a task the Eye cannot do) is proposed as a project,
#    researched, questioned, checked for common problems, and judged by every
#    model. A proposal that passes is opened as a project with its areas —
#    and from there each area is built through the make cycle like anything
#    else.
#  User intention (Andrew, 2026-09-24): "then check for any ways to self
#    improve and make a project for them which should look like a action
#    task, then repeat." "if it needs to make a new project it should do so."
# ============================================================================
from __future__ import annotations

from warp2.make import runner
from warp2.make.agents.proposal import read
from warp2.make.levels import PROPOSAL

# Intention: the attribute a weak spot carries once a project was made for it.
WORKED_ON = "improved_by"


def _pick(store, state) -> dict | None:
    """Intention: the worst weak spot no project has been made for yet."""
    from warp2.research.weak_spots import WeakSpots
    for spot in WeakSpots(store, state).questions():
        if not store.current(subject=spot["about"], attr=WORKED_ON):
            return spot
    return None


def step(root, state, store, fleet, worker, needs, projects) -> dict:
    """Intention: one step of proposing one project; {"did": ...} with what happened."""
    from warp2.make.book import JobBook
    going = [j for j in JobBook(state).all() if j.row.get("kind") == PROPOSAL]
    spot = None
    if going:
        about, what = going[0].row["target_about"], going[0].nodes[going[0].row["root"]]["what"]
    else:
        spot = _pick(store, state)
        if spot is None:
            return {"did": "nothing", "why": "no weak spot waits for a project"}
        about, what = spot["about"], f"{spot['why']} ({spot['question']})"
    said = runner.step(root, state, store, fleet, worker, needs, f"improve:{about}", PROPOSAL, what,
                       {"target_about": about, "target": about})
    if said["outcome"] == runner.PASSED:
        plan, _ = read(said["job"].row.get("passed_answer", ""))
        if plan and projects is not None:
            projects.open(plan["project"], intention=plan["for"], source=f"self-improvement: {about}")
            for area in plan["areas"]:
                projects.add_area(plan["project"], area["name"], area["for"])
            store.assert_fact(about, "has", attr=WORKED_ON, value=plan["project"])
            return {"did": "project opened", "project": plan["project"], "areas": len(plan["areas"])}
    if said["outcome"] == runner.ENDED:
        store.assert_fact(about, "has", attr=WORKED_ON, value="no proposal passed yet")
    return {"did": said["outcome"], "about": about, "said": said["said"]}
