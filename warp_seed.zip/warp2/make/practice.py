# WARP2/warp2/make/practice.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/practice.py
#  Used by   : warp2/work/side/practice.py (the general training phase).
#  Uses      : warp2/make/{training_needs,lessons,library,eye_makers,judges,
#              ladder,ledger,scoring}.py, projects/behemoth_eye/eye/warp_eye.py,
#              warp2/makers/practise_skill.py.
#  Description:
#    Practice on what needs it most (training_needs.py), one turn at a time:
#      - the Eye at a level: it answers every passed piece of work at that
#        level again without being shown the answer; the ones it gets wrong
#        are taught again, and how many it got right is its practice score;
#      - the models at a level, or an agent role: the model with the weakest
#        record there is asked again exactly what was asked for the newest
#        passed piece of work, and every model judges its new answer with the
#        passed one beside it; a pass is a lesson like any other;
#      - a gate rule: the open updates that pay that rule go to the front of
#        the queue, so the models practise exactly that fix.
#    BUILD_LOG (2026-11-05): turn() can leave out kinds of need already tried
#    this turn elsewhere (the Eye's, in a child process).
#    BUILD_LOG 1466 (Andrew, 2026-11-08 20:44: "general practice"): a skill
#    from the skills table - a game played, a game made, a coding task - is
#    practised by its kind (warp2/makers/practise_skill.py); the Eye's
#    judgement part is practised in a child process (practice_child.py).
#  User intention (Andrew, 2026-09-24): "have a system to what needs the most
#    training it should also look for what it needs to pratice on."
# ============================================================================
from __future__ import annotations

from warp2.make.ledger import MADE, RUNG
from warp2.make.lessons import Lessons
from warp2.make.library import Library
from warp2.makers.practise_skill import HERE, practise

# Intention: the ledger kind practice scores are kept under.
PRACTICED = "practiced"


def _passed_at(state_dir, level: str) -> list:
    """Intention: the passed lessons at one level, newest last."""
    return [r for r in Lessons(state_dir).rows() if r.get("passed") and r.get("level") == level
            and r.get("library_id") and r.get("eye_tags")]


def eye(state_dir, ledger, level: str) -> dict:
    """Intention: the Eye's part answers its level's work unseen; misses are taught again."""
    from warp2.make.eye_makers import part_name
    rows = _passed_at(state_dir, level)
    if not rows:
        return {"did": "nothing", "why": f"nothing has passed at {level} for the Eye to practise"}
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    from projects.behemoth_eye.pairs.fronts import VECTOR
    book = EyeBook(state_dir)
    task = part_name(level)
    if task not in book.tasks():
        return {"did": "nothing", "why": f"the Eye has no part for {level} yet"}
    readings = book.read(task, [r["eye_tags"] for r in rows])
    right = [max(read, key=read.get) == r["library_id"] if read else False for read, r in zip(readings, rows)]
    missed = [r for r, ok in zip(rows, right) if not ok]
    # Intention (2026-10-09, fix 4.8): every piece already right is nothing to
    # practise — the score is kept, and the turn goes on to the next need. It
    # was counted as practised, and the same right answers won every turn.
    if not missed:
        ledger.add(PRACTICED, "eye:parts", level, 1.0)
        return {"did": "nothing", "why": f"the Eye already gets all {len(rows)} at {level} right"}
    book.learn(task, [r["eye_tags"] for r in missed], [r["library_id"] for r in missed],
               Library(state_dir).ids(level), VECTOR, everything=False)
    book.save()
    share = sum(right) / len(right)
    ledger.add(PRACTICED, "eye:parts", level, share)
    return {"did": "practised", "who": "the Eye", "level": level, "right": sum(right), "of": len(right),
            "taught_again": len(missed)}


def _weakest(ledger, fleet, level: str) -> str:
    """Intention: the model with the lowest record at this level; one never tried there counts lowest."""
    names = list(fleet.names()) if fleet is not None else []
    if not names:
        return ""
    return min(names, key=lambda n: (ledger.mean(RUNG, n, level)[0] if ledger.mean(RUNG, n, level)[1] else -1.0, n))


def models(state_dir, fleet, ledger, level: str) -> dict:
    """Intention: the weakest model asked again what was asked for the newest passed work; all judge it."""
    rows = [r for r in _passed_at(state_dir, level) if r.get("asked")]
    if not rows:
        return {"did": "nothing", "why": f"nothing asked at {level} is kept to practise on"}
    row = rows[-1]
    model = _weakest(ledger, fleet, level)
    kept = Library(state_dir).get(row["library_id"]) or {}
    try:
        answer = str(fleet.ask(model, row["asked"]) or "")
    except Exception as exc:
        return {"did": "nothing", "why": f"{model} could not be asked: {type(exc).__name__}"}
    from warp2.make.judges import Judges
    verdict = Judges(fleet, ledger).judge(level, row["what"], answer, [], maker=model,
                                          context="An answer that passed before, to judge against:\n"
                                                  + str(kept.get("answer", ""))[:4000], everyone=True)
    ledger.add(RUNG, model, level, verdict["score"])
    ledger.add(MADE, "models", level, verdict["score"])
    ledger.add(PRACTICED, model, level, verdict["score"])
    if verdict["passed"]:
        key = Library(state_dir).add(level, row["what"], answer, verdict["score"], model)
        Lessons(state_dir).add({**{k: row[k] for k in ("item", "node", "level", "what", "asked", "eye_tags")},
                                "passed": True, "chosen_by": "models", "library_id": key,
                                "score": verdict["score"], "verdicts": {"models": verdict},
                                "answers": {"models": {"by": model, "why": ""}}, "practice": True})
    return {"did": "practised", "who": model, "level": level, "score": verdict["score"],
            "passed": verdict["passed"]}


def gate(queue, store, about: str) -> dict:
    """Intention: the open updates that pay this gate rule go to the front of the queue."""
    clause = about.split(":", 1)[-1]
    moved = 0
    for item in queue.open_items():
        if item.get("kind") in ("update", "update_test") and f":{clause}:" in str(item["item"]):
            store.assert_fact(item["item"], "has", attr="rank", value="1.000000")
            moved += 1
    return {"did": "practised" if moved else "nothing", "who": "the models", "rule": clause,
            "moved_to_the_front": moved}


def turn(state_dir, store, fleet, queue, ledger, skip_kinds=(), root=None, loop=None) -> dict:
    """Intention: practise the biggest need that has something to practise on.

    Intention (2026-11-05): `skip_kinds` leaves out needs already tried this turn elsewhere — the Eye's, tried in a
    child process (warp2/work/side/practice_child.py), so the runner goes on to the models and the gate rules.
    Intention (BUILD_LOG 1466): `root` and `loop` reach the game player, the project board and the fleet for a skill.
    """
    from warp2.make.training_needs import needs
    for row in needs(state_dir, store, fleet, ledger):
        if row["kind"] in skip_kinds:
            continue
        if row["kind"] == "eye" and row["maker"] == "eye:parts":
            said = eye(state_dir, ledger, row["level"])
        elif row["kind"] == "models":
            said = models(state_dir, fleet, ledger, row["level"])
        elif row["kind"] == "gate":
            said = gate(queue, store, row["about"])
        elif row["kind"].startswith("skill:") and row["skill_kind"] in HERE:
            said = practise(row, root, state_dir, loop)
        else:
            continue
        if said.get("did") == "practised":
            ledger.save()
            return dict(said, need=row["need"], area=row["area"])
    return {"did": "nothing", "why": "nothing that needs training has anything to practise on yet"}
