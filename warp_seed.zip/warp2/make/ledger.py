# WARP2/warp2/make/ledger.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/ledger.py
#  Used by   : warp2/make/{limits,trust,judges,ladder,final_eval}.py.
#  Uses      : warp2/chat_learning/ledger.py (Ledger — running means with
#              their spread, kept on disk), warp2/make/home.py.
#  Description:
#    The make cycle's one ledger: every score every maker earned, every score
#    every judge gave and how near it was to how things turned out, every
#    rung's passes, and how many tries successes took. The same running-mean
#    ledger the chat learning keeps, in its own folder.
#  User intention (Andrew, 2026-09-24): all models give tags and scores "so it
#    can be used with all the other ones it has given with the scores of all
#    other models to give a general view on capability and understanding."
# ============================================================================
from __future__ import annotations

from warp2.chat_learning.ledger import Ledger
from warp2.make.home import home

# Intention: the kinds of line the make ledger keeps.
MADE = "made"          # a maker's answer: its score, by level
JUDGED = "judged"      # a judge: how near its score was to the final outcome, by level
TAGGED = "tagged"      # a tagger: whether its tags were right, and agreed, by level
RIGHT = "right"        # a judge's right-or-wrong call: whether it was, by level
RUNG = "rung"          # a ladder rung: passed or not, by level
TRIES = "tries"        # how many tries a pass took, by level
FINAL = "final"        # the final evaluation of a whole job, by kind


def make_ledger(state_dir) -> Ledger:
    """Intention: the ledger, read from state/make/ledger.json."""
    return Ledger(home(state_dir))
