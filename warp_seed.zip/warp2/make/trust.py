# WARP2/warp2/make/trust.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/trust.py
#  Used by   : warp2/make/{judges,stage,ladder}.py — every guard reads it.
#  Uses      : warp2/make/ledger.py.
#  Description:
#    How far a model can be trusted in a role, from 0 to 1, measured: the low
#    end of its record in that role (its mean less one spread), so a short
#    record is trusted little and a long good one a lot. Nothing measured is
#    trust 0 — the slowest, most guarded form. A pool's trust is the mean of
#    its members'. Trust falls the same way it rises.
#  User intention (Andrew, 2026-09-24): "This should be the slowest and most
#    guarded plan for when there are no confident models ... All of this should
#    also be tempered by how well things are doing."
# ============================================================================
from __future__ import annotations

import math


def of(ledger, kind: str, source: str, thing: str = "*") -> float:
    """Intention: one source's trust in one kind of line, 0 to 1."""
    low, _high = ledger.bounds(kind, source, thing)
    if math.isinf(low):
        return 0.0
    # Intention: NEVER WHOLLY TRUSTED. A record with no spread has a low end
    # equal to its mean, so two perfect measures read as trust 1 — and a
    # phase or a judge trusted 1 is skipped every time. Counted n/(n+1), trust
    # nears 1 as the record grows and never reaches it.
    _mean, count = ledger.mean(kind, source, thing)
    return max(0.0, min(1.0, low)) * count / (count + 1.0)


def pool(ledger, kind: str, sources: list, thing: str = "*") -> float:
    """Intention: a pool's trust — the mean of its members'; an empty pool is 0."""
    sources = list(sources)
    if not sources:
        return 0.0
    return sum(of(ledger, kind, s, thing) for s in sources) / len(sources)
