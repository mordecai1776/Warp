# WARP2/warp2/make/limits.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/limits.py
#  Used by   : warp2/make/stage.py (how many tries a node gets at one rung).
#  Uses      : warp2/make/ledger.py (TRIES).
#  Description:
#    How many tries a stage at a level gets before it goes to the next maker:
#    what passes at that level have actually taken — their mean and one
#    spread above it — so the limit moves with every outcome. Before any pass
#    is on record it is two (one try and one retry), the least that is a
#    retry at all. A rung that ran out of tries counts as needing twice as
#    many, so failures raise it (2026-10-09).
#  User intention (Andrew, 2026-09-24): "it retries (this is none to a set
#    self-adjusted limit.)" — and no hard limits: the design sets it.
# ============================================================================
from __future__ import annotations

import math

from warp2.make.ledger import TRIES


def limit(ledger, level: str) -> int:
    """Intention: tries allowed at one rung for this level."""
    mean, count = ledger.mean(TRIES, level, "*")
    if count < 1:
        return 2
    low, high = ledger.bounds(TRIES, level, "*")
    # Intention (2026-10-09, fix 5.2, check D4): one measure has no spread of
    # its own yet, so it is given half of itself, as RFC 6298 starts — one
    # first-try pass had made the limit one, for good.
    spread = mean / 2.0 if math.isinf(high) else max(0.0, high - mean)
    return max(1, int(math.ceil(mean + spread)))


def took(ledger, level: str, tries: int) -> None:
    """Intention: a pass at this level took this many tries — the limit learns from it."""
    ledger.add(TRIES, level, "*", float(max(1, int(tries))))


def missed(ledger, level: str, tried: int) -> None:
    """A rung at this level ran out of tries without a pass — a pass needs more than that.

    Intention (2026-10-09, fix 5.2, check D4): recorded as twice the tries
    it had, as a time-out doubles the wait in RFC 6298, so failures raise
    the limit; they were never recorded, so nothing raised it.
    """
    ledger.add(TRIES, level, "*", float(2 * max(1, int(tried))))
