# WARP2/warp2/make/research_review.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/research_review.py
#  Used by   : warp2/work/phases.py (the random research phase).
#  Uses      : warp2/make/{runner,levels}.py, warp2/research/need.py,
#              warp2/research/grade.py (checked only once review passes it).
#  Description:
#    Random research, handled like an action task. A question the web lane
#    answered is picked at random from those not yet reviewed, and its finding
#    goes through the same stage as anything made: the research agent and the
#    Socratic agent raise what is still unknown about it, the common problem
#    agent looks for known mistakes, and every model judges and tags it. A
#    finding that passes is marked reviewed and its facts go to the KG; one
#    that does not is opened again, so it is looked up again with what was
#    learned.
#  User intention (Andrew, 2026-09-24): "then do random research with it
#    handled like in action task".
# ============================================================================
from __future__ import annotations

import random

from warp2.make import runner
from warp2.make.levels import REVIEW

# Intention: the attribute a reviewed need carries.
REVIEWED = "reviewed"


def _findings(store, need: str) -> str:
    """Intention: what was found for a need, as plain lines."""
    lines = []
    for fact in store.current(relation="derives", obj=need):
        subject = str(fact["subject"])
        if subject.startswith("finding:"):
            said = store.current(subject=subject, attr="summary")
            if said:
                lines.append(str(said[0]["value"]))
    return "\n".join(lines)


# Intention (2026-10-09, fix 5.4, check D7): a finding that did not pass
# review is opened and looked up again — answered again, it is reviewed
# again. Any review mark had kept it out of review for good.
def _due_review(store, need: str) -> bool:
    """Whether an answered need waits for review: never reviewed, or its last review did not pass."""
    marks = store.current(subject=need, attr=REVIEWED)
    return not marks or str(marks[0]["value"]).startswith("did not pass")


def _pick(store, seed: int) -> str:
    """Intention: one answered need not yet reviewed, drawn at random (steady for one seed)."""
    answered = [f["subject"] for f in store.current(attr="state")
                if str(f["subject"]).startswith("need:") and f["value"] == "answered"]
    fresh = [n for n in answered if _due_review(store, n)]
    return random.Random(seed).choice(sorted(fresh)) if fresh else ""


def step(root, state, store, fleet, worker, needs, seed: int) -> dict:
    """Intention: one step of reviewing one finding; {"did": ...} with what happened."""
    from warp2.make.book import JobBook
    from warp2.research import grade
    # Intention (2026-09-25): findings written "checked" before grading waited
    # for review go back to "not known", once per store.
    grade.catch_up(store)
    going = [j for j in JobBook(state).all() if j.row.get("kind") == REVIEW]
    need = going[0].row["item"].split("review:", 1)[-1] if going else _pick(store, seed)
    if not need:
        return {"did": "nothing", "why": "no answered research waits for review"}
    question = store.current(subject=need, attr="question")
    what = f"the finding for: {question[0]['value']}" if question else f"the finding for {need}"
    finding = _findings(store, need)
    if not finding:
        store.assert_fact(need, "has", attr=REVIEWED, value="nothing was found to review")
        return {"did": "skipped", "need": need}
    said = runner.step(root, state, store, fleet, worker, needs, f"review:{need}", REVIEW, what,
                       {"finding": finding, "known": finding, "target": need})
    if said["outcome"] == runner.PASSED:
        store.assert_fact(need, "has", attr=REVIEWED, value="passed")
        # Intention: passed by every model's review — now it is "checked".
        grade.passed(store, need)
    elif said["outcome"] == runner.ENDED:
        store.assert_fact(need, "has", attr=REVIEWED, value="did not pass; looked up again")
        store.assert_fact(need, "has", attr="state", value="open")
    return {"did": said["outcome"], "need": need, "said": said["said"]}
