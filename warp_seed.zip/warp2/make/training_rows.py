# WARP2/warp2/make/training_rows.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/training_rows.py
#  Used by   : warp2/make/cycle.py (when a job is settled),
#              warp2/train/dataset.py (the rows of a file that is proven are
#              taken into the training set).
#  Uses      : warp2/make/home.py, warp2/util.py (sha256_hex); stdlib json.
#  Description:
#    What a finished job teaches the models: for every stage that passed, the
#    work it was asked and the answer that passed, one row per role — the
#    understanding, the plan, the breakdown, each part — each carrying the
#    bytes of the file it went into. A row becomes a training example only
#    when that exact file is later proven by its test (warp2/train/dataset.py
#    checks the bytes), so nothing is taught that did not really work. Its
#    weight is how well it scored, times how the whole turned out.
#  User intention (Andrew, 2026-09-24): "if not it adds the things to the kg
#    and all of its actions are added to the kg as training" ... "Then it
#    trains all of the models on all of the scores."
# ============================================================================
from __future__ import annotations

import json

from warp2.make.home import home


def _path(state_dir):
    """Intention: state/make/training_rows.jsonl."""
    return home(state_dir) / "training_rows.jsonl"


def write_rows(state_dir, job, outcome: float) -> int:
    """Intention: one row per passed stage of a settled job; how many."""
    from warp2.util import sha256_hex
    made = str(job.row.get("made") or "")
    digest = sha256_hex(made.encode("utf-8"))
    rows = []
    for node in job.nodes.values():
        if node["status"] != "done" or not node.get("chosen") or not node.get("chosen_by"):
            continue
        rows.append({"artifact": job.row["path"], "artifact_bytes": digest, "kind": f"make:{node['level']}",
                     "instruction": f"{node['level']}: {node['what']}", "response": node["chosen"],
                     "weight": round(float(node.get("score") or 0.0) * float(outcome), 4),
                     "verification": "make_cycle"})
    with _path(state_dir).open("a", encoding="utf-8") as out:
        for row in rows:
            out.write(json.dumps(row, ensure_ascii=False) + "\n")
    return len(rows)


def proven_rows(state_dir, artifact: str, source_bytes: bytes) -> list:
    """Intention: the rows of this artifact whose file is exactly the one that is proven now."""
    from warp2.util import sha256_hex
    digest = sha256_hex(source_bytes)
    try:
        lines = _path(state_dir).read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for line in lines:
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if row.get("artifact") == artifact and row.get("artifact_bytes") == digest and row.get("weight", 0) > 0:
            out.append(dict(row, verification="hash_bound"))
    return out
