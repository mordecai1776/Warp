# WARP2/warp2/make/tests/test_research_falls_short_by_temperature.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_research_falls_short_by_temperature.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/make/agent_review.py (reviewer, by_temperature).
#  Description:
#    Research by temperature, not by a bar (BUILD_LOG 1443): a research or
#    Socratic answer the judges scored just short still raises the share of
#    its questions its score earns, first ones first, never the ones called
#    wrong; a score that earns none raises none; problems and facts that fall
#    short are still not used; an answer that passes is used whole but for
#    the wrong ones.
#  User intention (Andrew, 2026-11-08): "check to make sure the warp is doing
#    its needed research."
# ============================================================================
"""Tests that research which falls just short is still looked up, by the share its score earns."""
from __future__ import annotations

from types import SimpleNamespace

from warp2.make import agent_review
from warp2.make.agent_review import by_temperature

QUESTIONS = ["What are the alternatives?", "How is it measured?", "What breaks it?", "Who uses it?"]


def _review(monkeypatch, role, score, passed, wrong=()):
    """Intention: the reviewer as the stage calls it, with the judges' verdict given."""
    verdict = {"score": score, "passed": passed, "by": ["a", "b"], "wrong_items": list(wrong), "tags": {}}
    monkeypatch.setattr(agent_review.Judges, "__init__", lambda self, fleet, ledger: None)
    monkeypatch.setattr(agent_review.Judges, "judge", lambda self, *a, **k: verdict)
    monkeypatch.setattr(agent_review, "played", lambda *a, **k: None)
    ctx = SimpleNamespace(fleet=None, ledger=None, item={}, known=lambda node: "")
    node = {"level": "code", "what": "a part", "data": {}}
    return agent_review.reviewer(ctx, node, role)(QUESTIONS, "some-model")


def test_research_just_short_is_looked_up_by_its_share(monkeypatch):
    """Intention: 0.51 of four questions is the first two — they are looked up, not thrown away."""
    assert _review(monkeypatch, "research", 0.51, False) == QUESTIONS[:2]


def test_the_ones_called_wrong_are_never_asked(monkeypatch):
    """Intention: a question most judges called wrong stays out even when the answer is used by its share."""
    assert _review(monkeypatch, "socratic", 0.7, False, wrong=[1]) == QUESTIONS[1:3]


def test_a_score_that_earns_none_raises_none(monkeypatch):
    """Intention: 0.06 of four questions is none — nothing is asked."""
    assert _review(monkeypatch, "research", 0.06, False) is None


def test_problems_and_facts_that_fall_short_are_still_not_used(monkeypatch):
    """Intention: a wrong problem or fact does harm, so short of passing it is not used at all."""
    assert _review(monkeypatch, "common_problems", 0.5, False) is None
    assert by_temperature("kg_plan", QUESTIONS, 0.9) is None


def test_a_passed_answer_is_used_whole_but_for_the_wrong_ones(monkeypatch):
    """Intention: passing work is used as before."""
    assert _review(monkeypatch, "research", 0.8, True, wrong=[4]) == QUESTIONS[:3]
