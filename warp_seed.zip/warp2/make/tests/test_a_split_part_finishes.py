# WARP2/warp2/make/tests/test_a_split_part_finishes.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_a_split_part_finishes.py
#  Used by   : pytest.
#  Uses      : warp2/make/job.py (Job, new_node), warp2/make/levels.py (passed),
#              warp2/make/stage.py (_exhausted).
#  Description:
#    A part that failed and was broken smaller counts as done when the parts
#    it was broken into are done, so the job can finish; and a part made by a
#    split is not split again — it waits for training instead.
#  User intention (Andrew): smallest parts, made until they pass. 2026-10-09,
#    "ok lets get it done" — fix 5.1 of claude/warp2_fix_plan_2026_10_09.md
#    (check D1: the job could never complete, and it split with no end).
# ============================================================================
from __future__ import annotations

from types import SimpleNamespace

from warp2.make import levels, stage
from warp2.make.job import BREAKDOWN, DONE, FAILED, PART, WAITING, Job, new_node


def _job_with_a_split():
    """Intention: two parts; "b" failed, was broken down, and gave pieces "b1" and "b2"."""
    job = Job.start({"item": "x"}, "pkg/thing.py")
    for name in ("a", "b"):
        job.add(new_node(PART, f"the part `{name}`", job.row["root"], {"name": name}))
    a, b = job.of_level(PART)
    a["status"], b["status"] = DONE, FAILED
    split = job.add(new_node(BREAKDOWN, "the part `b` broken smaller", b["id"], {"split": "b"}))
    split["status"] = DONE
    job.row["skeleton"] = "def b1():\n    ...\n\n\ndef b2():\n    ...\n"
    pieces = [job.add(n) for n in levels.passed(job, split, job.row["skeleton"])]
    return job, pieces


def test_a_split_part_is_done_when_its_pieces_are():
    """Intention: check D1 — the failed part kept "every part done" false for ever."""
    job, pieces = _job_with_a_split()
    assert not job.all_parts_done()
    for piece in pieces:
        piece["status"] = DONE
    assert job.all_parts_done()


def test_a_piece_of_a_split_is_not_split_again():
    """Intention: check D1 — the guard read a mark no part carried, so pieces split with no end."""
    job, pieces = _job_with_a_split()
    piece = pieces[0]
    stage._exhausted(SimpleNamespace(state="."), job, piece)
    assert piece["status"] == WAITING
    assert len(job.of_level(BREAKDOWN)) == 1
