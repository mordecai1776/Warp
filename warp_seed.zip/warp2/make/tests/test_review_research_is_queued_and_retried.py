# WARP2/warp2/make/tests/test_review_research_is_queued_and_retried.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_review_research_is_queued_and_retried.py
#  Used by   : pytest.
#  Uses      : warp2/work/sources.py (unanswered_needs),
#              warp2/make/research_review.py (_pick), warp2/research/need.py,
#              warp2/store/store.py.
#  Description:
#    A question raised while a finding is reviewed is put on the work list
#    like any other; and a finding that failed review, once looked up again,
#    is reviewed again.
#  User intention (Andrew): nonsense stays "not known" until all review it.
#    2026-10-09, "ok lets get it done" — fix 5.4 of
#    claude/warp2_fix_plan_2026_10_09.md (checks D6, D7).
# ============================================================================
from __future__ import annotations

from warp2.make.research_review import REVIEWED, _pick
from warp2.research.need import Needs
from warp2.store.store import Store
from warp2.work.sources import unanswered_needs


def _store(tmp_path):
    """Intention: a store and its needs."""
    store = Store(tmp_path / "state", run="rev", view_path=tmp_path / "view.sqlite3")
    return store, Needs(store)


def test_a_question_raised_in_review_is_queued(tmp_path):
    """Intention: check D6 — questions about the need under review were skipped, and the review stalled."""
    store, needs = _store(tmp_path)
    raised = needs.raise_need("need:0a1b2c", "which source says the lock is taken first")["need"]
    assert any(row["target"] == raised for row in unanswered_needs(needs, store=store))


def test_a_finding_that_failed_review_is_reviewed_again(tmp_path):
    """Intention: check D7 — any review mark kept it out of review for good."""
    store, needs = _store(tmp_path)
    need = needs.raise_need("pkg/thing.py", "how should the shrink guard behave")["need"]
    store.assert_fact(need, "has", attr=REVIEWED, value="did not pass; looked up again")
    store.assert_fact(need, "has", attr="state", value="answered")
    assert _pick(store, 0) == need
    store.assert_fact(need, "has", attr=REVIEWED, value="passed")
    assert _pick(store, 0) == ""
