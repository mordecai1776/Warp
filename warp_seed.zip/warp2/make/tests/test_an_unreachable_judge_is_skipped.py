# WARP2/warp2/make/tests/test_an_unreachable_judge_is_skipped.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_an_unreachable_judge_is_skipped.py
#  Used by   : pytest (and WARP2/CHECK_FIXES.bat).
#  Uses      : warp2/make/judges.py (Judges), warp2/make/ledger.py (make_ledger),
#              warp2/models/backends.py (Unreachable).
#  Description:
#    A judge whose chance call raises Unreachable and whose text comes back
#    empty could not be asked at all: it is counted as skipped, not listed
#    as unreadable and not graded as a failed judge. A judge that was there
#    and failed some other way is still unread, as before.
#  User intention (Andrew, standing rules): keep everything and judge it in
#    place; "did not answer" is not "answered badly" (backends.Unreachable).
#    Open item from the 2026-11-06 handoffs: judge fix, Unreachable in
#    _chance counted as skipped.
# ============================================================================
from __future__ import annotations

import json

from warp2.make.judges import Judges
from warp2.make.ledger import make_ledger
from warp2.models.backends import Unreachable


class Panel:
    """Intention: stand-in judges; "gone" ones have no server (text fails, chance raises Unreachable)."""

    def __init__(self, scores, gone=(), broken=()):
        self.scores, self.gone, self.broken, self.graded = scores, set(gone), set(broken), []

    def names(self, kind=""):
        """Intention: every stand-in judge, by name."""
        return sorted(self.scores)

    def ask(self, model, prompt):
        """Intention: a readable verdict, or a failed call for a gone or broken judge."""
        if model in self.gone or model in self.broken:
            raise RuntimeError("no answer")
        score = self.scores[model]
        return json.dumps({"score": score, "right": score > 0.5, "why": "x", "tags": []})

    def chance(self, model, prompt):
        """Intention: the set score as a chance; Unreachable when gone; another failure when broken."""
        if model in self.gone:
            raise Unreachable(f"{model} at http://127.0.0.1:1: URLError", reached=False)
        if model in self.broken:
            raise RuntimeError("the child died")
        return self.scores[model]



class Graded:
    """Intention: stand-in for the fleet's `outputs` — remembers who was graded, how, and as what kind."""

    def __init__(self, panel):
        self.panel = panel

    def graded_answer(self, model, heard, **kw):
        """Intention: one graded line kept as (model, passed, kind)."""
        self.panel.graded.append((model, kw.get("passed"), kw.get("kind", "")))


def _panel(*a, **k):
    """Intention: a panel whose gradings are recorded."""
    panel = Panel(*a, **k)
    panel.outputs = Graded(panel)
    return panel


def test_an_unreachable_judge_is_skipped_not_unread(tmp_path):
    """Intention: c's server is not there — it is skipped, not unread, and not graded as a failed judge."""
    panel = _panel({"a": 0.9, "b": 0.8, "c": 0.7}, gone=["c"])
    verdict = Judges(panel, make_ledger(tmp_path)).judge("part", "x", "answer", [])
    assert verdict["unread"] == {}
    assert verdict["skipped"] == {"c": "could not be asked"}
    assert set(verdict["by"]) == {"a", "b"} and verdict["passed"]
    judged = [m for m, _, kind in panel.graded if kind.startswith("judge:")]
    assert "c" not in judged and set(judged) == {"a", "b"}


def test_a_judge_that_was_there_but_failed_is_still_unread(tmp_path):
    """Intention: any other failure is unchanged — the judge is unread and graded as not read."""
    panel = _panel({"a": 0.9, "b": 0.8, "c": 0.7}, broken=["c"])
    verdict = Judges(panel, make_ledger(tmp_path)).judge("part", "x", "answer", [])
    assert "c" in verdict["unread"] and verdict["skipped"] == {}
    assert ("c", False, "judge:part") in panel.graded
