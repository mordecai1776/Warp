# WARP2/warp2/make/tests/test_judge_guesses_before_after.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_judge_guesses_before_after.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/make/eye_lessons.py (teach), with a stand-in Eye and
#              lesson record (no torch needed).
#  Description:
#    teach_eye_what_was_made files, in its one result row, how many new
#    stages each judgement part guessed right BEFORE it was taught them and
#    AFTER — so whether teaching moved the Eye's pass/fail guesses toward
#    what really happened is readable without joining two records
#    (Muse-804, 2026-10-29; BUILD_LOG 917). Old code filed no such row.
#  User intention (Andrew, 2026-09-25): "the fails can be just as important
#    as the pass".
# ============================================================================
from __future__ import annotations

import sys
import types

import warp2.make.eye_lessons as eye_lessons


class GuessingBook:
    """Intention: a judge that guesses "passed" for everything until taught, then guesses each stage's label."""

    def __init__(self, state_dir=None):
        self.parts = {"judge: task": {}}

    def tasks(self):
        return sorted(self.parts)

    def learn(self, task, inputs, labels, classes, kind="vector", weights=None, everything=True, holdable=None):
        known = self.parts.setdefault(task, {})
        for tags, label in zip(inputs, labels):
            known[tuple(tags)] = label
        return {}

    def read(self, task, inputs):
        known = self.parts[task]
        out = []
        for tags in inputs:
            label = known.get(tuple(tags), "passed")
            out.append({"passed": 1.0 if label == "passed" else 0.0, "failed": 1.0 if label == "failed" else 0.0})
        return out

    def everything_name(self, kind):
        return f"everything: {kind}"

    def save(self):
        pass


class JudgingLessons:
    """Intention: three stages to judge (one passed, two failed); nothing to teach as an answer."""

    ROWS = [
        {"level": "task", "passed": True, "eye_tags": ["a"], "score": 0.9},
        {"level": "task", "passed": False, "eye_tags": ["b"], "score": 0.1},
        {"level": "task", "passed": False, "eye_tags": ["c"], "score": 0.2},
        {"level": "plan", "passed": True, "eye_tags": ["d"], "score": 0.8},
    ]

    def __init__(self, state_dir):
        pass

    def unread(self, reader):
        return list(self.ROWS) if reader == eye_lessons.JUDGE else []

    def read(self, reader, n):
        pass

    def rows(self):
        return list(self.ROWS)


def test_the_judges_guesses_before_and_after_are_in_one_row(tmp_path, monkeypatch):
    warp_eye = types.ModuleType("projects.behemoth_eye.eye.warp_eye")
    warp_eye.EyeBook = GuessingBook
    fronts = types.ModuleType("projects.behemoth_eye.pairs.fronts")
    fronts.VECTOR = "vector"
    monkeypatch.setitem(sys.modules, "projects.behemoth_eye.eye.warp_eye", warp_eye)
    monkeypatch.setitem(sys.modules, "projects.behemoth_eye.pairs.fronts", fronts)
    monkeypatch.setattr(eye_lessons, "Lessons", JudgingLessons)
    said = eye_lessons.teach(tmp_path)
    guesses = said.get("judge_guesses")
    assert guesses is not None, "the row says how the judge guessed"
    assert guesses["task"] == {"before": {"right": 1, "of": 3}, "after": {"right": 3, "of": 3}}
    # A level whose judgement part did not exist before has no honest "before".
    assert guesses["plan"]["before"] is None and guesses["plan"]["after"] == {"right": 1, "of": 1}
    assert said["judged"]["task"] == {"passed": 1, "failed": 2}, "the old counts are unchanged"
