# WARP2/warp2/make/tests/test_eye_master_trains_a_missing_part.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_eye_master_trains_a_missing_part.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/make/eye_lessons.py (teach), with a stand-in Eye,
#              lesson record and library (no torch needed).
#  Description:
#    The master pass reads every level's part over all passed lessons. A
#    level whose part the Eye does not hold (its lessons already read, the
#    Eye new or rebuilt) raised KeyError("no part has been trained for
#    make: plan") and the whole teach_eye_what_was_made step failed
#    (journal 2026-10-29 05:35 UTC). Now that part learns its level's
#    history first and is then read like the rest.
#  User intention (Andrew, 2026-10-29): "The fact that it hasn't proven
#    something shouldn't be a barrier".
# ============================================================================
from __future__ import annotations

import sys
import types

import warp2.make.eye_lessons as eye_lessons


class FakeBook:
    """Intention: an Eye holding only the parts it was taught."""

    def __init__(self, state_dir=None):
        self.parts = {}
        self.saved = False

    def tasks(self):
        return sorted(self.parts)

    def learn(self, task, inputs, labels, classes, kind="vector", weights=None, everything=True, holdable=None):
        self.parts.setdefault(task, []).extend(labels)
        return {}

    def read(self, task, inputs):
        if task not in self.parts:
            raise KeyError(f"no part has been trained for {task}")
        return [{} for _ in inputs]

    def everything_name(self, kind):
        return f"everything: {kind}"

    def pair(self, task, classes, kind="vector"):
        book = self

        class Pair:
            def learn(self, inputs, labels):
                book.parts.setdefault(task, []).extend(labels)
        return Pair()

    def save(self):
        self.saved = True


BOOKS = []


def _make_book(state_dir):
    book = FakeBook(state_dir)
    BOOKS.append(book)
    return book


class FakeLessons:
    """Intention: one passed plan lesson already read; one fresh task lesson unread."""

    ROWS = [
        {"level": "plan", "passed": True, "library_id": "p1", "eye_tags": ["a"], "score": 0.9},
        {"level": "task", "passed": True, "library_id": "t1", "eye_tags": ["b"], "score": 0.8},
    ]

    def __init__(self, state_dir):
        pass

    def unread(self, reader):
        return [self.ROWS[1]] if reader == eye_lessons.LEARNER else []

    def read(self, reader, n):
        pass

    def rows(self):
        return list(self.ROWS)


class FakeLibrary:
    def __init__(self, state_dir):
        pass

    def ids(self, level):
        return ["p1"] if level == "plan" else ["t1"]


def test_a_level_with_no_part_is_taught_then_read(tmp_path, monkeypatch):
    warp_eye = types.ModuleType("projects.behemoth_eye.eye.warp_eye")
    warp_eye.EyeBook = _make_book
    fronts = types.ModuleType("projects.behemoth_eye.pairs.fronts")
    fronts.VECTOR = "vector"
    monkeypatch.setitem(sys.modules, "projects.behemoth_eye.eye.warp_eye", warp_eye)
    monkeypatch.setitem(sys.modules, "projects.behemoth_eye.pairs.fronts", fronts)
    monkeypatch.setattr(eye_lessons, "Lessons", FakeLessons)
    monkeypatch.setattr(eye_lessons, "Library", FakeLibrary)
    said = eye_lessons.teach(tmp_path)
    book = BOOKS[-1]
    assert "make: plan" in book.tasks(), "the missing part was taught its level's history"
    assert said["taught"].get("plan") == 1 and said["taught"].get("task") == 1
    assert said["master"] == 2, "the master was taught every passed lesson, both levels"
    assert book.saved
