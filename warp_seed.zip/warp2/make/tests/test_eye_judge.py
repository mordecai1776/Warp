# WARP2/warp2/make/tests/test_eye_judge.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_eye_judge.py
#  Used by   : pytest.
#  Uses      : warp2/make/eye_judge.py (votes), warp2/make/judges.py
#              (Judges — the Eye's votes among the models'), warp2/make/
#              eye_lessons.py (judge_name), projects/behemoth_eye/eye/
#              warp_eye.py (EyeBook, EyeMaster — needs torch; those tests
#              are skipped without it), warp2/make/ledger.py.
#  Description:
#    The Eye judges: its judgement part, read with the level's making part,
#    votes for its parts, and its master — which reads every part's
#    concepts — votes too. Each counts like any judge, weighted by trust,
#    and never judges work it made itself. The master read nothing at all
#    before (its own class list is never filled).
#  User intention (Andrew, 2026-09-25): add the Eye as a judge "and use the
#    master and the relevant smaller combined parts for task".
# ============================================================================
from __future__ import annotations

import json

import pytest

from warp2.make.judges import Judges
from warp2.make.ledger import make_ledger


def _tags(what):
    """Intention: the work as the Eye reads it."""
    return [{"name": "level=plan", "weight": 1.0, "holds": []},
            {"name": "what", "weight": 1.0, "says": what, "holds": []}]


def test_the_eye_votes_with_its_parts_and_its_master(tmp_path):
    pytest.importorskip("torch")
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    from projects.behemoth_eye.pairs.fronts import VECTOR
    from warp2.make.eye_judge import votes
    from warp2.make.eye_lessons import judge_name
    state = tmp_path / "state"
    state.mkdir()
    book = EyeBook(state)
    book.learn(judge_name("plan"), [_tags("good a"), _tags("bad b"), _tags("good c"), _tags("bad d")],
               ["passed", "failed", "passed", "failed"], ["passed", "failed"], VECTOR)
    master = book.pair(book.everything_name(VECTOR), [], VECTOR).read([_tags("x")])[0]
    assert set(master) == {"judge: plan: passed", "judge: plan: failed"}, "the master reads every part's concepts"
    got = votes(state, "plan", _tags("good e"), "the plan", book=book)
    assert set(got) == {"eye:parts", "eye:master"} and all(0.0 <= v <= 1.0 for v in got.values())
    assert votes(state, "task", _tags("x"), "y", book=book) == {}, "a level it was never taught: no vote"
    print(f"\n  [OK] the Eye votes: parts {got['eye:parts']:.3f}, master {got['eye:master']:.3f}; "
          f"the master reads {len(master)} concepts from its parts")


class Scorers:
    """Intention: model judges that each give a set score."""

    def __init__(self, scores):
        self.scores = scores

    def names(self, kind=""):
        return sorted(self.scores)

    def ask(self, model, prompt):
        return json.dumps({"score": self.scores[model], "right": self.scores[model] > 0.5, "why": "x"})


def test_the_eyes_votes_count_like_any_judge_and_never_on_its_own_work(tmp_path, monkeypatch):
    from warp2.make import eye_judge
    monkeypatch.setattr(eye_judge, "votes", lambda state, level, seen, answer, book=None:
                        {"eye:parts": 0.1, "eye:master": 0.1})
    judges = Judges(Scorers({"a": 0.9}), make_ledger(tmp_path), state_dir=tmp_path)
    with_eye = judges.judge("plan", "x", "answer", [], maker="m", seen=_tags("x"))
    assert set(with_eye["by"]) == {"a", "eye:parts", "eye:master"} and with_eye["score"] < 0.9
    own = judges.judge("plan", "x", "answer", [], maker="eye:parts", seen=_tags("x"))
    assert "eye:parts" not in own["by"] and "eye:master" in own["by"]
    none = Judges(Scorers({"a": 0.9}), make_ledger(tmp_path)).judge("plan", "x", "answer", [])
    assert set(none["by"]) == {"a"}
    print(f"\n  [OK] with the Eye: {with_eye['score']:.2f} from 3 judges; the Eye's parts never judge "
          f"their own answer; with no state the models judge as before")
