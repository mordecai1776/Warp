# WARP2/warp2/make/tests/test_eye_judges.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_eye_judges.py
#  Used by   : pytest.
#  Uses      : warp2/make/eye_lessons.py (teach), warp2/make/lessons.py; a
#              stand-in for the Eye's book (projects/behemoth_eye/eye/
#              warp_eye.py needs torch), put in its place for the test only.
#  Description:
#    Every stage, passed or failed, teaches the Eye a judgement per level:
#    the fails the Eye was never shown before are taught as fails, the
#    passes as passes, and each stage is taught once.
#  User intention (Andrew, 2026-09-25): "the fails can be just as important
#    as the pass".
# ============================================================================
from __future__ import annotations

import sys
import types

from warp2.make import eye_lessons
from warp2.make.lessons import Lessons


class Book:
    """Intention: the Eye's book as far as the lessons use it — every learn call remembered."""
    taught: list = []

    def __init__(self, state_dir=None):
        pass

    def learn(self, task, inputs, labels, classes, kind, weights=None, everything=True):
        Book.taught.append((task, list(labels), list(weights or []), everything))

    def save(self):
        return []


def _stand_in(monkeypatch):
    """Intention: the Eye's modules replaced for this test, so no model is loaded."""
    eye = types.ModuleType("projects.behemoth_eye.eye.warp_eye")
    eye.EyeBook = Book
    fronts = types.ModuleType("projects.behemoth_eye.pairs.fronts")
    fronts.VECTOR = "vector"
    monkeypatch.setitem(sys.modules, "projects.behemoth_eye.eye.warp_eye", eye)
    monkeypatch.setitem(sys.modules, "projects.behemoth_eye.pairs.fronts", fronts)
    Book.taught = []


def test_every_stage_passed_or_failed_teaches_the_eye_a_judgement(tmp_path, monkeypatch):
    _stand_in(monkeypatch)
    lessons = Lessons(tmp_path)
    lessons.path.parent.mkdir(parents=True, exist_ok=True)
    tags = [{"name": "level=plan", "weight": 1.0}]
    for passed, score in (("False", 0.0), ("False", 0.0), ("True", 0.72)):
        lessons.add({"level": "plan", "passed": passed, "score": score, "eye_tags": tags})
    lessons.read(eye_lessons.LEARNER, 3)  # the old reader had already read them all
    said = eye_lessons.teach(tmp_path)
    assert said["judged"] == {"plan": {"passed": 1, "failed": 2}}
    task, labels, weights, everything = Book.taught[0]
    assert task == "judge: plan" and labels == ["failed", "failed", "passed"] and everything
    assert all(w > 0 for w in weights) and weights[0] > weights[2], "a clear fail says more than a near pass"
    assert eye_lessons.teach(tmp_path)["judged"] == {}, "each stage taught once"
    print("\n  [OK] 2 fails and 1 pass the Eye had already read, taught now as a judgement, parts and master")
