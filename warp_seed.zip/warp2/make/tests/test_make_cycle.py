# WARP2/warp2/make/tests/test_make_cycle.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_make_cycle.py
#  Used by   : the test suite.
#  Uses      : warp2/make/*, warp2/models/worker.py, warp2/parts/builder.py,
#              warp2/store/store.py, warp2/research/need.py.
#  Description:
#    The make cycle end to end with stand-in models: a new file goes through
#    the task, the plan, the breakdown and each part — research, questions,
#    common problems, three makers, judges — one step a call, and comes out
#    whole, with every stage a lesson, every pass in the library, and every
#    maker and judge in the ledger. And the guards: a failed answer given
#    again fails at once, a research question holds the stage until it is
#    answered, and a stage that keeps failing climbs to the next rung.
#  User intention (Andrew, 2026-09-24): the make cycle as he set it out.
# ============================================================================
from __future__ import annotations

import json

from warp2.make.cycle import MakeCycle
from warp2.make.job import new_node
from warp2.make.ledger import MADE, make_ledger
from warp2.make.library import Library
from warp2.make.lessons import Lessons
from warp2.make import repeats

OUTLINE = ("# path: projects/demo/hold.py\n"
           "def hold(number):\n    \"\"\"Intention: keep the number at one or above.\"\"\"\n    ...\n")
BODY = "def hold(number):\n    \"\"\"Intention: keep the number at one or above.\"\"\"\n    return max(1, number)\n"


class Fleet:
    """Stand-in models: each prompt kind gets its one right answer; judges score as told."""

    def __init__(self, judge_score=0.9, questions=()):
        self.judge_score, self.questions, self.asked = judge_score, list(questions), []

    def names(self, kind=""):
        return ["tiny-1b", "big-7b"]

    def likely(self, kind):
        return "tiny-1b"

    def room_for_prompt(self, name):
        return 0

    def answer_room(self, name):
        return 0

    def second(self, kind, after=""):
        return "big-7b"

    def ask(self, model, prompt):
        self.asked.append((model, prompt[:60]))
        if "has to be looked up" in prompt:
            said, self.questions = self.questions, []
            return json.dumps(said)
        if "Socrates" in prompt or "Problems that have happened before" in prompt:
            return "[]"
        if "You are judging" in prompt:
            return json.dumps({"score": self.judge_score, "why": "checked",
                               "tags": [{"name": "keeps a floor", "weight": 1.0}]})
        if "Plan what to add" in prompt:
            return json.dumps([{"subject": "hold", "relation": "defines", "object": "keep a floor"}])
        if "under these five headings" in prompt:
            return ("What it is for: a floor.\nWhat goes in and what comes out: a number in, a number out.\n"
                    "What is known that matters: max.\nWhat is not known: nothing.\n"
                    "How we will know it is done: hold(0) is 1.")
        if "break this outline down" in prompt or "write ONLY the outline" in prompt:
            return "```python\n" + OUTLINE + "```"
        if "write one part of" in prompt:
            return "```python\n" + BODY + "```"
        return ""


def _cycle(tmp_path, fleet):
    """Intention: a make cycle over a real store, a real worker and the stand-in fleet."""
    from warp2.models.worker import Worker
    from warp2.parts.builder import PartsBuilder
    from warp2.research.need import Needs
    from warp2.store.store import Store, store_home
    root = tmp_path / "tree"
    (root / "projects" / "demo").mkdir(parents=True)
    store = Store(store_home(tmp_path / "state"), run="make")
    worker = Worker(fleet)
    worker.parts = PartsBuilder(root)
    return MakeCycle(root, tmp_path / "state", store, fleet, worker, Needs(store)), store


ITEM = {"item": "work:build:projects/demo/hold.py", "kind": "build", "target": "projects/demo/hold.py"}
SLICED = {"context": {"artifact_path": "projects/demo/hold.py"}, "text": "a number floor"}


def _run(cycle, limit=200):
    """Intention: steps until the file is handed over; every step's answer."""
    said = []
    for _ in range(limit):
        got = cycle(ITEM, SLICED)
        said.append(got)
        if got.get("files"):
            return said
    return said


def test_a_new_file_goes_through_every_level_and_comes_out_whole(tmp_path):
    """Intention: task → plan → breakdown → part, and a whole file that runs."""
    cycle, store = _cycle(tmp_path, Fleet())
    try:
        said = _run(cycle)
        code = said[-1]["files"]["projects/demo/hold.py"]
        assert "return max(1, number)" in code and code.startswith("# WARP2/projects/demo/hold.py")
        levels = [row["level"] for row in Lessons(tmp_path / "state").rows() if row["passed"]]
        assert levels == ["task", "plan", "breakdown", "part"]
        assert len(Library(tmp_path / "state").rows()) == 4
        ledger = make_ledger(tmp_path / "state")
        assert ledger.mean(MADE, "models", "part")[1] == 1 and ledger.mean(MADE, "eye:parts", "part")[1] == 1
        assert store.current(subject="concept:hold", relation="defines")
        assert any("make cycle: task — research" in s["said"] for s in said)
    finally:
        store.close()


def test_research_holds_the_stage_until_it_is_answered(tmp_path):
    """Intention: nothing is made while a question the research agent raised is open."""
    from warp2.research.need import Needs
    cycle, store = _cycle(tmp_path, Fleet(questions=["what is the usual way to keep a number above a floor"]))
    try:
        for _ in range(3):
            got = cycle(ITEM, SLICED)
        assert "waiting on 1 research question" in got["said"] or "still open" in got["said"]
        assert not cycle.can_take(ITEM)
        need = Needs(store).open_needs()[0]["need"]
        Needs(store).attempted(need, found=True)
        assert cycle.can_take(ITEM)
    finally:
        store.close()


def test_a_failed_answer_given_again_fails_at_once():
    """Intention: repeats are fails, however they are spaced."""
    node = new_node("part", "x")
    repeats.failed(node, "def f():\n    return 1\n")
    assert repeats.is_repeat(node, "def f():  return 1  # same")
    assert not repeats.is_repeat(node, "def f():\n    return 2\n")


def test_a_stage_that_keeps_failing_climbs_to_a_bigger_rung(tmp_path):
    """Intention: judges below one half, and after the learned limit the models' maker moves up."""
    cycle, store = _cycle(tmp_path, Fleet(judge_score=0.1))
    try:
        for _ in range(40):
            cycle(ITEM, SLICED)
        job = cycle.book.get(ITEM["item"])
        task = job.nodes[job.row["root"]]
        assert task["rung"] >= 1 or task["status"] == "waiting"
        assert all(r["passed"] is False for r in Lessons(tmp_path / "state").rows())
    finally:
        store.close()


def test_the_agents_work_is_tagged_by_the_other_models_and_turned_down_when_it_fails(tmp_path):
    """Intention: Andrew — the Socratic and other agents "should get tags to"."""
    cycle, store = _cycle(tmp_path, Fleet(judge_score=0.1, questions=["what is a floor on a number"]))
    try:
        cycle(ITEM, SLICED)
        job = cycle.book.get(ITEM["item"])
        node = job.nodes[job.row["root"]]
        verdict = node["data"]["agent_verdicts"]["research"]
        assert verdict["by"] and not verdict["passed"] and verdict["tags"]
        assert node["needs"] == []
    finally:
        store.close()
