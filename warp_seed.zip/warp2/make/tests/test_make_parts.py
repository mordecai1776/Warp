# WARP2/warp2/make/tests/test_make_parts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_make_parts.py
#  Used by   : the test suite.
#  Uses      : warp2/make/{judges,trust,limits,ladder,fires_before,ledger,
#              research_review,self_improve}.py, warp2/work/phases.py.
#  Description:
#    The smaller parts of the make cycle, each on its own: judges tempered by
#    trust, trust from the record, limits that learn, the ladder smallest
#    first, what fires before a part, the action cycle's order, research
#    reviewed as an action task, and a weak spot made into a project.
#  User intention (Andrew, 2026-09-24): the make cycle, "tempered by how well
#    things are doing".
# ============================================================================
from __future__ import annotations

import json

from warp2.make import fires_before, ladder, limits, trust
from warp2.make.judges import Judges
from warp2.make.ledger import JUDGED, make_ledger
from warp2.make.tests.test_make_cycle import Fleet, _cycle


class Scorers:
    """Stand-in judges: each gives the score it is set to."""

    def __init__(self, scores):
        self.scores, self.asked = scores, []

    def names(self, kind=""):
        return sorted(self.scores)

    def ask(self, model, prompt):
        self.asked.append(model)
        return json.dumps({"score": self.scores[model], "why": "x", "tags": [{"name": "t", "weight": 1}]})


def test_with_no_trust_every_judge_is_asked_and_the_maker_never_judges_itself(tmp_path):
    """Intention: the slowest, most guarded form: all of them, but never the maker."""
    fleet = Scorers({"a": 0.9, "b": 0.9, "c": 0.9, "d": 0.9})
    verdict = Judges(fleet, make_ledger(tmp_path)).judge("part", "x", "answer", [], maker="d")
    assert sorted(fleet.asked) == ["a", "b", "c"] and verdict["passed"] and verdict["score"] == 0.9


def test_trusted_judges_are_asked_less_once_the_verdict_cannot_change(tmp_path):
    """Intention: with high trust the asking thins; with everyone=True all are asked anyway."""
    ledger = make_ledger(tmp_path)
    for model in "abcdefgh":
        for _ in range(30):
            ledger.add(JUDGED, model, "part", 0.99)
    fleet = Scorers({m: 0.95 for m in "abcdefgh"})
    Judges(fleet, ledger).judge("part", "x", "answer", [])
    thinned = len(fleet.asked)
    fleet.asked = []
    Judges(fleet, ledger).judge("part", "x", "answer", [], everyone=True)
    assert thinned < 8 and len(fleet.asked) == 8


def test_trust_is_the_low_end_of_the_record_and_limits_learn(tmp_path):
    """Intention: nothing measured is trust 0; the limit starts at two and follows passes."""
    ledger = make_ledger(tmp_path)
    assert trust.of(ledger, JUDGED, "new") == 0.0 and limits.limit(ledger, "part") == 2
    for tries in (3, 4, 3, 4):
        limits.took(ledger, "part", tries)
    assert limits.limit(ledger, "part") >= 4


def test_the_ladder_goes_code_then_smallest_model_first_and_steps_over_the_certainly_worse(tmp_path):
    """Intention: automations, then bigger and bigger — and down to where work was done well."""
    class F:
        def names(self, kind=""):
            return ["big-9b", "tiny-1b", "mid-3b"]
    rungs = ladder.rungs(F(), "build", with_code=True)
    # Intention (Andrew, 2026-10-29: the models are nannies the Eye replaces; BUILD_LOG 931): the Eye's makers are
    # the smallest rungs, before every model.
    assert rungs == ["code", "eye:parts", "eye:master", "tiny-1b", "mid-3b", "big-9b"]
    assert ladder.rungs(F(), "build", with_code=True, with_eye=False) == ["code", "tiny-1b", "mid-3b", "big-9b"]
    # Unproven, the Eye is never stepped over; certainly worse than a model, it is.
    ledger0 = make_ledger(tmp_path / "fresh")
    assert ladder.climbable(ledger0, "part", rungs)[:3] == ["code", "eye:parts", "eye:master"]
    ledger = make_ledger(tmp_path)
    for _ in range(6):
        ledger.add("rung", "tiny-1b", "part", 0.0)
        ledger.add("rung", "mid-3b", "part", 1.0)
        ledger.add("rung", "eye:parts", "part", 0.0)
    assert "tiny-1b" not in ladder.climbable(ledger, "part", rungs)
    assert "eye:parts" not in ladder.climbable(ledger, "part", rungs) and "eye:master" in ladder.climbable(ledger, "part", rungs)


def test_a_model_that_fires_before_a_part_s_passes_is_joined_to_it(tmp_path):
    """Intention: more than half of the part's runs, at the low bound, and it is joined."""
    ledger = make_ledger(tmp_path)
    for _ in range(12):
        fires_before.record(ledger, "make: part", ["tiny-1b"], True, ["tiny-1b", "big-7b"])
    assert fires_before.joined(ledger, "make: part", ["tiny-1b", "big-7b"]) == ["tiny-1b"]


def test_the_action_cycle_goes_in_order(tmp_path):
    """Intention: queued work, random research, general training, self-improvement, again."""
    from warp2.work.phases import Phases
    phases = Phases(tmp_path)
    assert [phases.next() for _ in range(6)] == ["work", "research", "wiring", "training", "improve", "work"]
    assert Phases(tmp_path).next() == "research"


def test_a_weak_spot_becomes_a_project_through_the_stage(tmp_path):
    """Intention: proposed, judged by every model, and opened with its areas."""
    from warp2.make.self_improve import step
    from warp2.store.projects import Projects

    class Proposer(Fleet):
        def ask(self, model, prompt):
            if "Propose one project" in prompt:
                return json.dumps({"project": "header_help", "for": "help files carry their header",
                                   "areas": [{"name": "header_writer", "for": "write the header"}]})
            return super().ask(model, prompt)

    fleet = Proposer()
    cycle, store = _cycle(tmp_path, fleet)
    try:
        store.assert_fact("clause:carries_its_header", "has", attr="fired", value="5")
        projects = Projects(store, tmp_path / "tree")
        said = {}
        for _ in range(12):
            said = step(cycle.root, cycle.state, store, fleet, cycle.worker, cycle.needs, projects)
            if said.get("did") == "project opened":
                break
        assert said["did"] == "project opened" and "header_help" in projects.names()
    finally:
        store.close()


def test_a_research_finding_is_reviewed_as_an_action_task(tmp_path):
    """Intention: an answered question's finding is judged and tagged, and marked reviewed."""
    from warp2.make.research_review import REVIEWED, step
    from warp2.research.need import Needs
    fleet = Fleet()
    cycle, store = _cycle(tmp_path, fleet)
    try:
        need = Needs(store).raise_need("projects/demo/hold.py", "what is the usual way to keep a floor on a number")["need"]
        store.assert_fact(need, "has", attr="state", value="answered")
        store.assert_fact("finding:one", "derives", need)
        store.assert_fact("finding:one", "has", attr="summary", value="use max(floor, value)")
        said = {}
        for _ in range(10):
            said = step(cycle.root, cycle.state, store, fleet, cycle.worker, cycle.needs, seed=1)
            if said.get("did") in ("passed", "ended"):
                break
        assert said["did"] == "passed"
        assert store.current(subject=need, attr=REVIEWED)[0]["value"] == "passed"
    finally:
        store.close()


def test_the_kg_is_wired_by_a_plan_every_model_judges(tmp_path):
    """Intention: the least connected concept is wired to the ones it shares words with; every judge asked."""
    from warp2.make.kg_wiring import WIRED, step

    class Wirer(Fleet):
        def ask(self, model, prompt):
            if "barely connected" in prompt:
                return json.dumps([{"subject": "priority queue", "relation": "supports",
                                    "object": "shortest path queue", "why": "it orders the frontier"}])
            return super().ask(model, prompt)

    fleet = Wirer()
    cycle, store = _cycle(tmp_path, fleet)
    try:
        for cid, name in (("concept:priority_queue", "priority queue"),
                          ("concept:shortest_path_queue", "shortest path queue"),
                          ("concept:heap", "heap")):
            store.assert_fact(cid, "has", attr="name", value=name)
        store.assert_fact("concept:heap", "supports", "concept:shortest_path_queue")
        said = {}
        for _ in range(12):
            said = step(cycle.root, cycle.state, store, fleet, cycle.worker, cycle.needs)
            if said.get("did") in ("wired", "not wired"):
                break
        assert said["did"] == "wired" and said["facts"] == 1
        assert store.current(subject="concept:priority_queue", relation="supports")
        assert store.current(subject="concept:priority_queue", attr=WIRED)
        judged = [a for a in fleet.asked if a[1].startswith("You are judging")]
        assert {m for m, _ in judged} >= {"tiny-1b", "big-7b"}
    finally:
        store.close()


def test_a_judge_says_whether_it_is_right_and_which_items_are_wrong(tmp_path):
    """Intention: a high score that most judges call wrong does not pass; a wrong item is named."""
    class Callers(Scorers):
        def ask(self, model, prompt):
            self.asked.append(model)
            return json.dumps({"score": 0.9, "right": model != "a", "wrong_items": [2],
                               "why": "x", "tags": [{"name": "t", "weight": 1}]})
    verdict = Judges(Callers({"a": 0, "b": 0, "c": 0}), make_ledger(tmp_path)).judge("x", "y", "z", [])
    assert verdict["passed"] and verdict["wrong_items"] == [2] and 0.6 < verdict["right"] < 0.7

    class Naysayers(Scorers):
        def ask(self, model, prompt):
            return json.dumps({"score": 0.9, "right": False, "why": "x", "tags": []})
    assert not Judges(Naysayers({"a": 0, "b": 0}), make_ledger(tmp_path)).judge("x", "y", "z", [])["passed"]


def test_what_was_made_is_tagged_later_by_every_model_that_had_not(tmp_path):
    """Intention: the newest passed thing not tagged by everyone is tagged by the rest; then nothing is left."""
    from warp2.make.tag_catchup import late, turn
    from warp2.make.tests.test_make_cycle import ITEM, SLICED

    class Three(Fleet):
        def names(self, kind=""):
            return ["tiny-1b", "big-7b", "mid-3b"]

    fleet = Three()
    cycle, store = _cycle(tmp_path, fleet)
    try:
        for _ in range(8):
            cycle(ITEM, SLICED)
        ledger = make_ledger(tmp_path / "state")
        said = turn(tmp_path / "state", fleet, ledger)
        assert said["did"] == "tagged" and said["answered"] >= 1
        while said["did"] == "tagged":
            said = turn(tmp_path / "state", fleet, ledger)
        assert said["did"] == "nothing" and late(tmp_path / "state")
    finally:
        store.close()


def test_what_needs_training_most_is_ranked_and_the_models_practise_it(tmp_path):
    """Intention: a weak level ranks high; the weakest model is asked again and every model judges it."""
    from warp2.make.practice import models as practise
    from warp2.make.tests.test_make_cycle import ITEM, SLICED
    from warp2.make.training_needs import needs, steps_first
    fleet = Fleet()
    cycle, store = _cycle(tmp_path, fleet)
    try:
        for _ in range(8):
            cycle(ITEM, SLICED)
        ledger = make_ledger(tmp_path / "state")
        ranked = needs(tmp_path / "state", store, fleet, ledger)
        assert ranked[0]["need"] >= ranked[-1]["need"] and "practice_what_is_weakest" in steps_first(ranked)
        said = practise(tmp_path / "state", fleet, ledger, "task")
        assert said["did"] == "practised" and said["who"] in ("tiny-1b", "big-7b")
    finally:
        store.close()


def test_the_eye_is_asked_first_and_the_nannies_only_when_it_cannot_answer(tmp_path, monkeypatch):
    """Andrew (2026-10-29): "The other models are meant to be nannies that eventually get replaced by the eye
    itself." (BUILD_LOG 931): with a usable answer from the Eye's part, the models' maker IS the Eye and no model is
    asked to make; without one, the models make as before and the Eye's answer still stands beside for judging."""
    from warp2.make import eye_makers, stage
    from warp2.make.tests.test_make_cycle import ITEM, SLICED
    asked_eye = []

    def eye_answers(state_dir, job_row, node, which, joined=()):
        asked_eye.append(which)
        return ("def hold(n):\n    return max(1, n)\n", "") if which == eye_makers.EYE_PARTS else ("", "no master")
    monkeypatch.setattr(eye_makers, "answer", eye_answers)
    monkeypatch.setattr(stage.levels, "usable", lambda job, node, answer: "")
    fleet = Fleet()
    cycle, store = _cycle(tmp_path, fleet)
    try:
        for _ in range(5):
            said = cycle(ITEM, SLICED)
            if str(said.get("said", "")).startswith("make:"):
                break
        job = cycle.book.get(ITEM["item"])
        node = job.nodes[job.row["root"]]
        assert node["answers"]["models"]["by"] == eye_makers.EYE_PARTS, "the Eye's part was the models' rung"
        assert not any("You are judging" not in p and "write" in p.lower() for _m, p in fleet.asked), \
            "no model was asked to make"
        assert node["rung"] == 0, "the models' ladder did not climb for the Eye's rung"
    finally:
        store.close()
