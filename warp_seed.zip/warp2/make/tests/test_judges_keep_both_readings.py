# WARP2/warp2/make/tests/test_judges_keep_both_readings.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_judges_keep_both_readings.py
#  Used by   : pytest (and WARP2/CHECK_FIXES.bat).
#  Uses      : warp2/make/judges.py (Judges), warp2/make/ledger.py (make_ledger),
#              warp2/train/outputs.py (Outputs — the record of everything).
#  Description:
#    When a judge's verdict is read both from its token chances and from
#    its text on the same call, both readings are kept: in the verdict
#    ("readings") and in that judge's graded line in outputs.jsonl. A judge
#    read one way only keeps the one reading.
#  User intention (relay muse-23, under Andrew's item f): record which path
#    each verdict used, and keep the paired readings so how far the two
#    paths agree is measured, not argued, before anyone merges them.
# ============================================================================
from __future__ import annotations

import json

from warp2.make.judges import Judges
from warp2.make.ledger import make_ledger
from warp2.train.outputs import Outputs


class Panel:
    """Intention: stand-in judges with a set text score (None = unreadable) and a set chance (None = none)."""

    def __init__(self, texts, chances, state_dir):
        self.texts, self.chances = texts, chances
        self.outputs = Outputs(state_dir)

    def names(self, kind=""):
        """Intention: every stand-in judge, by name."""
        return sorted(self.texts)

    def ask(self, model, prompt):
        """Intention: a readable verdict at the set score, or words no one can read."""
        score = self.texts[model]
        if score is None:
            return "I am not sure."
        return json.dumps({"score": score, "right": score > 0.5, "why": "x", "tags": []})

    def chance(self, model, prompt):
        """Intention: the set chance of yes, or None for a model without token chances."""
        return self.chances.get(model)


def _judge_lines(state_dir):
    """Intention: every judge's graded line in the record, by the order written."""
    path = next(state_dir.rglob("outputs.jsonl"))
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    return [r for r in rows if r.get("e") == "graded" and str(r.get("kind", "")).startswith("judge:")]


def test_both_readings_are_in_the_verdict(tmp_path):
    """Intention: the fix — text 0.9 and chance 0.2 on the same call are both kept; the chance still decides."""
    panel = Panel({"a": 0.9, "b": 0.8, "c": None}, {"a": 0.2, "b": None, "c": 0.7}, tmp_path)
    verdict = Judges(panel, make_ledger(tmp_path)).judge("part", "x", "answer", [])
    assert verdict["readings"] == {"a": {"options": 0.2, "text": 0.9},
                                   "b": {"text": 0.8},
                                   "c": {"options": 0.7}}
    assert verdict["by"]["a"] == 0.2


def test_both_readings_are_in_each_judges_graded_line(tmp_path):
    """Intention: the paired record stands in outputs.jsonl, one judge's line at a time."""
    panel = Panel({"a": 0.9, "b": 0.8}, {"a": 0.2, "b": None}, tmp_path)
    Judges(panel, make_ledger(tmp_path)).judge("part", "x", "answer", [])
    lines = _judge_lines(tmp_path)
    assert {"options": 0.2, "text": 0.9} in [r.get("readings") for r in lines]
    assert {"text": 0.8} in [r.get("readings") for r in lines]


def test_a_grade_without_readings_writes_none(tmp_path):
    """Intention: every other grader is unchanged — no readings field unless given."""
    out = Outputs(tmp_path)
    out.graded_answer("m", "an answer", passed=True, score=1.0, how="check")
    path = next(tmp_path.rglob("outputs.jsonl"))
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert all("readings" not in r for r in rows)
