# WARP2/warp2/make/tests/test_trust_is_read_where_it_is_written.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_trust_is_read_where_it_is_written.py
#  Used by   : pytest.
#  Uses      : warp2/make/judges.py (Judges.pool), warp2/make/step_trust.py,
#              warp2/make/ledger.py.
#  Description:
#    "Most trusted first" reads each judge's trust at the level it is being
#    asked to judge — where trust is written — not at "*", which nothing
#    writes (so the order was alphabetical).
#  User intention (Andrew, 2026-09-25): each judge "weighted by their
#    competence in said thing". 2026-10-09, "ok lets get it done" — fix 5.5
#    of claude/warp2_fix_plan_2026_10_09.md (check D9).
# ============================================================================
from __future__ import annotations

from types import SimpleNamespace

from warp2.make.judges import Judges
from warp2.make.ledger import make_ledger
from warp2.make.step_trust import STEP_JUDGED


def test_the_judge_trusted_at_this_level_goes_first(tmp_path):
    """Intention: "zed" has earned trust at plan; "abe" has none — "zed" is asked first."""
    ledger = make_ledger(tmp_path)
    for _ in range(6):
        ledger.add(STEP_JUDGED, "zed", "plan", 1.0)
    fleet = SimpleNamespace(names=lambda: ["abe", "zed"])
    assert Judges(fleet, ledger).pool("", "plan") == ["zed", "abe"]
