# WARP2/warp2/make/tests/test_every_model_plays_a_role_until_measured.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_every_model_plays_a_role_until_measured.py
#  Used by   : pytest.
#  Uses      : warp2/make/agents/who.py (who, played), warp2/make/ledger.py.
#  Description:
#    A role goes to every model until each has a record in it; then to the
#    one whose record could be the best (its mean plus one standard error),
#    so a model only loses turns once it is surely worse.
#  User intention (Andrew, 2026-09-24): "tempered by how well things are
#    doing." 2026-10-09, "ok lets get it done" — fix 5.5 of
#    claude/warp2_fix_plan_2026_10_09.md (check D10: one model took a role
#    for good once its trust was above nought). Method: explore before
#    exploit (Graves et al. 2017, Exp3.S).
# ============================================================================
from __future__ import annotations

from types import SimpleNamespace

from warp2.make.agents.who import played, who
from warp2.make.ledger import make_ledger


def test_a_new_model_gets_turns_after_one_has_earned_trust(tmp_path):
    """Intention: "abe" has a good record; "new" has never played — "new" still gets the role."""
    ledger = make_ledger(tmp_path)
    for _ in range(5):
        played(ledger, "research", "abe", 0.9)
    fleet = SimpleNamespace(names=lambda: ["abe", "new"])
    chosen = {who(fleet, ledger, "research", turn=f"t{i}") for i in range(6)}
    assert "new" in chosen


def test_a_model_surely_worse_stops_getting_the_role(tmp_path):
    """Intention: measured enough, the better one plays."""
    ledger = make_ledger(tmp_path)
    for _ in range(8):
        played(ledger, "research", "abe", 0.9)
        played(ledger, "research", "bob", 0.1)
    fleet = SimpleNamespace(names=lambda: ["abe", "bob"])
    assert who(fleet, ledger, "research") == "abe"
