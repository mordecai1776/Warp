# WARP2/warp2/make/tests/test_practice_moves_on_from_what_is_right.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_practice_moves_on_from_what_is_right.py
#  Used by   : pytest.
#  Uses      : warp2/make/practice.py (eye, turn), warp2/make/ledger.py;
#              projects/behemoth_eye/eye/warp_eye.py (EyeBook, stubbed).
#  Description:
#    When the Eye already gets every piece of a level right there is nothing
#    to practise there: the turn says so and goes on to the next need,
#    instead of "practising" the same right answers turn after turn.
#  User intention (Andrew, 2026-09-24): practise what needs it most. 2026-10-09,
#    "ok lets get it done" — fix 4.8 of claude/warp2_fix_plan_2026_10_09.md
#    (live: eye:parts at plan, 1 of 1 right, picked six times).
# ============================================================================
from __future__ import annotations

import warp2.make.practice as practice


class _Book:
    """Intention: an Eye part that answers every piece right."""

    def __init__(self, *a, **k):
        pass

    def tasks(self):
        return ["make: plan"]

    def read(self, task, tags):
        return [{"lib1": 0.9, "lib2": 0.1} for _ in tags]


def test_all_right_is_nothing_to_practise_and_the_next_need_goes(tmp_path, monkeypatch):
    """Intention: the next need (the models at plan) is practised instead."""
    import projects.behemoth_eye.eye.warp_eye as warp_eye
    import warp2.make.eye_makers as makers
    import warp2.make.training_needs as training_needs
    from warp2.make.ledger import make_ledger
    monkeypatch.setattr(warp_eye, "EyeBook", _Book)
    monkeypatch.setattr(makers, "part_name", lambda level: "make: plan")
    monkeypatch.setattr(practice, "_passed_at", lambda state, level: [{"library_id": "lib1", "eye_tags": {"a": 1.0}}])
    monkeypatch.setattr(practice, "models", lambda *a: {"did": "practised", "who": "a model", "level": "plan"})
    monkeypatch.setattr(training_needs, "needs", lambda *a: [
        {"kind": "eye", "maker": "eye:parts", "level": "plan", "need": 0.9, "area": "eye:parts at plan"},
        {"kind": "models", "maker": "models", "level": "plan", "need": 0.5, "area": "models at plan"}])
    said = practice.turn(tmp_path, None, None, None, make_ledger(tmp_path))
    assert said["area"] == "models at plan"
