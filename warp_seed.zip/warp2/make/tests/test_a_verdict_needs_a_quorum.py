# WARP2/warp2/make/tests/test_a_verdict_needs_a_quorum.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_a_verdict_needs_a_quorum.py
#  Used by   : pytest.
#  Uses      : warp2/make/judges.py (Judges), warp2/make/ledger.py (make_ledger).
#  Description:
#    A make-cycle verdict passes only when the judges heard hold more than
#    half of the panel's weight: not on one judge of many, not on the Eye's
#    votes alone.
#  User intention (Andrew, 2026-09-23): the gate must "kick out the bad,
#    let in the good" — a verdict nobody really gave is neither.
# ============================================================================
from __future__ import annotations

import json

from warp2.make.judges import Judges
from warp2.make.ledger import make_ledger


class Panel:
    """Intention: stand-in judges; a judge set to None answers with nothing readable."""

    def __init__(self, scores):
        self.scores = scores

    def names(self, kind=""):
        """Intention: every stand-in judge, by name."""
        return sorted(self.scores)

    def ask(self, model, prompt):
        """Intention: a readable verdict at the set score, or words no one can read."""
        score = self.scores[model]
        if score is None:
            return "I am not sure."
        return json.dumps({"score": score, "right": score > 0.5, "why": "x"})


class EyeOnly(Judges):
    """Intention: the Eye votes yes on everything, as a stand-in for its parts and master."""

    def eye_votes(self, level, seen, answer, maker):
        """Intention: two Eye voters, both sure it is right."""
        return {"eye:parts": 0.95, "eye:master": 0.95}


def test_one_judge_of_three_cannot_pass_work(tmp_path):
    """Intention: the fix — two judges said nothing readable, so no verdict was given."""
    verdict = Judges(Panel({"a": 0.9, "b": None, "c": None}), make_ledger(tmp_path)).judge(
        "part", "x", "answer", [])
    assert not verdict["quorum"] and not verdict["passed"]


def test_the_eye_alone_cannot_pass_work_the_models_could_not_judge(tmp_path):
    """Intention: the fix — the Eye's two votes against three silent judges is not most of the panel."""
    verdict = EyeOnly(Panel({"a": None, "b": None, "c": None}), make_ledger(tmp_path)).judge(
        "part", "x", "answer", [])
    assert not verdict["quorum"] and not verdict["passed"]


def test_most_of_the_panel_heard_still_passes(tmp_path):
    """Intention: what was right before stays right — two of three heard and agreeing passes."""
    verdict = Judges(Panel({"a": 0.9, "b": 0.9, "c": None}), make_ledger(tmp_path)).judge(
        "part", "x", "answer", [])
    assert verdict["quorum"] and verdict["passed"]


def test_the_eye_and_one_judge_together_are_a_quorum(tmp_path):
    """Intention: the Eye is a judge like any other; with a judge beside it, most of the panel spoke."""
    verdict = EyeOnly(Panel({"a": 0.9, "b": None}), make_ledger(tmp_path)).judge(
        "part", "x", "answer", [])
    assert verdict["quorum"] and verdict["passed"]
