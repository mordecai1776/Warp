# WARP2/warp2/make/tests/test_a_build_can_finish.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_a_build_can_finish.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/make/cycle.py (MakeCycle, whole_stage), warp2/make/job.py,
#              warp2/work/loop.py (Loop.carried_on; read as text for make_cycle).
#  Description:
#    The build lane can finish a build (BUILD_LOG 1119): a turn takes the
#    rest of the node's stage until the node waits, and no more than a
#    stage's own steps; without whole_stage it is one step, as before; the
#    stop ends it; and the loop carries a started job on while it can move,
#    letting go of one that waits, ended, or was handed over.
#  User intention (Andrew, 2026-11-02 23:07): "Ok let's get the build lane
#    going then." (2026-09-24: "It is fine if it is really slow we are
#    reaching for quality not speed.")
# ============================================================================
"""Tests that a started build moves a stage a turn and is carried on until it must wait."""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from warp2.make import cycle as cyc
from warp2.make.job import WAITING, Job


class _Worker:
    """Intention: what the cycle asks of the worker — the file an item makes."""

    parts = True

    def _target_file(self, item, sliced):
        return "projects/x/thing.py"


def _cycle(tmp_path, monkeypatch, waits_at: int):
    """Intention: a cycle whose steps are counted, the node waiting once it reaches `waits_at`."""
    taken = []

    def step(ctx, job, node):
        node["step"] += 1
        taken.append(node["step"])
        if node["step"] >= waits_at:
            node["status"] = WAITING
            node["why"] = "waiting on 1 research question(s)"
        return f"step {node['step']}"

    monkeypatch.setattr(cyc.stage, "step", step)
    monkeypatch.setattr(cyc.stage, "wake", lambda ctx, job: 0)
    make = cyc.MakeCycle(tmp_path, tmp_path, None, None, _Worker(), None)
    return make, taken


def test_without_whole_stage_a_turn_is_one_step(tmp_path, monkeypatch):
    """Intention: a cycle made elsewhere (tests, make_eye) is unchanged."""
    make, taken = _cycle(tmp_path, monkeypatch, waits_at=3)
    said = make({"item": "work:build:projects/x/thing.py", "kind": "build", "target": "projects/x/thing.py"}, {})
    assert taken == [1] and said["model"] == ""


def test_a_turn_takes_the_stage_until_the_node_waits(tmp_path, monkeypatch):
    """Intention: research, Socratic, wait — three steps in one turn, then it stops on the wait."""
    make, taken = _cycle(tmp_path, monkeypatch, waits_at=3)
    make.whole_stage = True
    said = make({"item": "work:build:projects/x/thing.py", "kind": "build", "target": "projects/x/thing.py"}, {})
    assert taken == [1, 2, 3] and said["steps"] == 3 and "step 1 | " in said["said"]
    job = make.book.get("work:build:projects/x/thing.py")
    assert job.movable() is None and job.waiting()


def test_a_turn_is_never_more_than_a_stage(tmp_path, monkeypatch):
    """Intention: a node that never waits still hands control back after the stage's own steps."""
    make, taken = _cycle(tmp_path, monkeypatch, waits_at=10 ** 6)
    make.whole_stage = True
    make({"item": "work:build:projects/x/thing.py", "kind": "build", "target": "projects/x/thing.py"}, {})
    assert len(taken) == len(cyc.stage.STEPS)


def test_the_stop_ends_the_turn(tmp_path, monkeypatch):
    """Intention: with the stop raised, only the step already begun is taken."""
    make, taken = _cycle(tmp_path, monkeypatch, waits_at=10 ** 6)
    make.whole_stage, make.stop = True, SimpleNamespace(raised=lambda: True)
    make({"item": "work:build:projects/x/thing.py", "kind": "build", "target": "projects/x/thing.py"}, {})
    assert taken == [1]


def _loop(open_rows, job, can=True):
    """Intention: a stand-in loop with a queue, a make cycle holding one job, and can_do."""
    book = SimpleNamespace(get=lambda key: job if job is not None and key == job.row["item"] else None)
    return SimpleNamespace(_making="work:build:a.py", queue=SimpleNamespace(open_items=lambda: open_rows),
                           make_cycle=lambda: SimpleNamespace(book=book), can_do=lambda item: can)


def test_the_loop_carries_a_started_build_on_until_it_must_wait():
    """Intention: the open unit of a job that can move is next; a waiting, ended or vanished one lets go."""
    from warp2.work.loop import Loop
    item = {"item": "work:build:a.py", "kind": "build"}
    job = Job.start(item, "a.py")
    looped = _loop([item], job)
    assert Loop.carried_on(looped) is item and looped._making == "work:build:a.py"
    for node in job.nodes.values():
        node["status"] = WAITING
    looped = _loop([item], job)
    assert Loop.carried_on(looped) is None and looped._making == ""
    assert Loop.carried_on(_loop([], Job.start(item, "a.py"))) is None
    handed = Job.start(item, "a.py")
    handed.row["state"] = "handed"
    assert Loop.carried_on(_loop([item], handed)) is None
    assert Loop.carried_on(_loop([item], Job.start(item, "a.py"), can=False)) is None


def test_the_loop_s_cycle_takes_whole_stages_and_carries_on():
    """Intention: the loop sets whole_stage and its stop, asks carried_on first, and records the job it is making."""
    text = (Path(__file__).resolve().parents[2] / "work" / "loop.py").read_text(encoding="utf-8")
    assert "held.whole_stage, held.stop = True, self.pathway.stop" in text
    assert "item = self.carried_on() or self.queue.next(can_do=self.can_do)" in text
    assert 'self._making = "" if value.get("files") else str(item["item"])' in text
