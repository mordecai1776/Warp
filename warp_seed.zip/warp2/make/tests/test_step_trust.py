# WARP2/warp2/make/tests/test_step_trust.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_step_trust.py
#  Used by   : pytest.
#  Uses      : warp2/make/step_trust.py, warp2/make/scoring.py,
#              warp2/work/research_lift.py, warp2/make/book.py, warp2/make/job.py,
#              warp2/chat_learning/ledger.py.
#  Description:
#    Judges earn trust at each step (against the others, never themselves),
#    which lifts them only half way; a judge that writes Python is read; and a
#    research question make jobs wait on is lifted by how many wait.
#  User intention (Andrew, 2026-10-08): chose "More research turns" and
#    "Earn trust at each step".
# ============================================================================
from __future__ import annotations

from types import SimpleNamespace

from warp2.chat_learning.ledger import Ledger
from warp2.make import step_trust
from warp2.make.scoring import read


def test_a_judge_is_scored_against_the_others_not_itself():
    """Intention: three agree it passes, one says no — the three earn, the one does not."""
    ledger = Ledger()
    verdicts = {"models": {"by": {"a": 0.9, "b": 0.8, "c": 0.85, "d": 0.1}}}
    assert step_trust.record(ledger, "task", verdicts) == 4
    assert ledger.mean(step_trust.STEP_JUDGED, "a", "task")[0] > 0.8
    assert ledger.mean(step_trust.STEP_JUDGED, "d", "task")[0] < 0.2
    assert step_trust.record(ledger, "task", {"one": {"by": {"a": 0.9}}}) == 0


def test_step_trust_lifts_only_half_way():
    """Intention: a long perfect step record gives under one half; the final evaluation can give more."""
    ledger = Ledger()
    for _ in range(50):
        step_trust.record(ledger, "task", {"m": {"by": {"a": 1.0, "b": 1.0}}})
    assert 0.4 < step_trust.of(ledger, "a", "task") <= 0.5
    for _ in range(50):
        ledger.add("judged", "a", "task", 1.0)
    assert step_trust.of(ledger, "a", "task") > 0.9


def test_a_judge_that_writes_python_is_read():
    """Intention: `True` instead of `true` no longer makes a verdict unread."""
    got = read('{"score": 0.7, "right": True, "wrong_items": [2], "why": "x", "tags": []}')
    assert got is not None and got["score"] == 0.7 and got["right"] is True


def test_questions_jobs_wait_on_are_lifted_by_how_many_wait(tmp_path):
    """Intention: two jobs waiting on one question triple its rank (up to the top); an unwaited one stays."""
    from warp2.make.book import JobBook as Book
    from warp2.make.job import Job
    from warp2.work.research_lift import rerank, waiting_on
    state = tmp_path / "state"
    book = Book(state)
    for item in ("work:build:a.py", "work:build:b.py"):
        job = Job.start({"item": item, "kind": "build"}, "", level="task", what=item)
        root = job.nodes[job.row["root"]]
        root["needs"] = ["need:shared"] + (["need:only-a"] if item.endswith("a.py") else [])
        book.put(job)
    waiting = waiting_on(state)
    assert waiting == {"need:shared": 2, "need:only-a": 1}
    written = {}
    store = SimpleNamespace(assert_fact=lambda s, r, attr, value: written.__setitem__(s, float(value)),
                            current=lambda **k: [])
    items = [{"item": "research:1", "kind": "research", "target": "need:shared", "rank": 0.0},
             {"item": "research:2", "kind": "research", "target": "need:other", "rank": 0.0}]
    queue = SimpleNamespace(open_items=lambda: items)
    rerank(store, queue, 1.0, waiting)
    assert written["research:1"] > written["research:2"]
    assert written["research:1"] == min(1.0, 3 * written["research:2"])
