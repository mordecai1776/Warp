# WARP2/warp2/make/tests/test_kg_wiring_counts_degrees_in_one_query.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_kg_wiring_counts_degrees_in_one_query.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/make/kg_wiring.py (_degrees), warp2/store/store.py
#              (Store.degrees, Store.pairs).
#  Description:
#    The wiring stage's "how connected is each concept" is counted by the
#    store in one grouped query, not by pulling every pair of seven relations
#    into Python. Seen 2026-11-06 23:50 UTC (state/diagnostics/stuck_stacks.txt):
#    the runner wrote nothing for 122 s while kg_wiring._degrees sat in
#    store.pairs -> projection.rows. The counts must stay exactly what the old
#    loop gave: both ends counted, only "concept:" ends, ended facts left out.
#  User intention (Andrew, 2026-09-24): "we need to add a stage that just works
#    on wiring the kg it should have its plan tagged by all of the models."
#    (Andrew, 2026-10-16: builders may change the code on their own.)
# ============================================================================
from __future__ import annotations

from warp2.make import kg_wiring
from warp2.store.store import Store


def _store(tmp_path):
    """Intention: a small real store in a scratch folder."""
    return Store(tmp_path / "store", run="degrees", view_path=tmp_path / "view.sqlite3")


def _old_count(store) -> dict:
    """Intention: the count the old loop made, kept here as the measure of the new one."""
    degree: dict = {}
    for relation in kg_wiring.RELATIONS + ("derives",):
        for a, b in store.pairs(relation):
            for end in (a, b):
                if str(end).startswith("concept:"):
                    degree[end] = degree.get(end, 0) + 1
    return degree


def _filled(tmp_path):
    """Intention: concepts joined by several relations, one non-concept end, one ended fact."""
    store = _store(tmp_path)
    store.assert_fact("concept:a", "contains", "concept:b")
    store.assert_fact("concept:a", "supports", "concept:c")
    store.assert_fact("concept:c", "derives", "concept:a")
    store.assert_fact("concept:b", "depends_on", "thing:x")
    gone = store.assert_fact("concept:b", "defines", "concept:c")
    store.invalidate(gone, "test: an ended fact is not counted")
    return store


def test_the_store_counts_degrees_as_the_old_loop_did(tmp_path):
    """Intention: same numbers as the old per-pair loop, for every concept."""
    store = _filled(tmp_path)
    got = store.degrees(kg_wiring.RELATIONS + ("derives",), "concept:")
    assert got == _old_count(store)
    assert got == {"concept:a": 3, "concept:b": 2, "concept:c": 2}


def test_wiring_reads_degrees_without_pulling_every_pair(tmp_path):
    """Intention: the wiring stage asks the store for counts once and never walks the pairs itself."""
    store = _filled(tmp_path)
    want = _old_count(store)

    def no_pairs(relation):
        raise AssertionError(f"pairs({relation!r}) pulled into Python")

    store.pairs = no_pairs
    assert kg_wiring._degrees(store) == want
