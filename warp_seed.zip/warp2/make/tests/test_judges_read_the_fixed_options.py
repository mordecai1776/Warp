# WARP2/warp2/make/tests/test_judges_read_the_fixed_options.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_judges_read_the_fixed_options.py
#  Used by   : pytest (and WARP2/CHECK_FIXES.bat).
#  Uses      : warp2/make/judges.py (Judges), warp2/make/ledger.py (make_ledger),
#              warp2/models/yes_no.py (chance), warp2/models/fleet.py (Fleet.chance),
#              warp2/models/roster.py (_isolated_chance), warp2/store/{store,tagnet}.py.
#  Description:
#    A judge's score is read from its chance of "yes" on one fixed question
#    when its model can give token chances, so a judge whose text cannot be
#    read still gives a verdict; a judge without token chances is read from
#    its text as before; every verdict says which path it used.
#  User intention (Andrew, 2026-10-16, item f): "JUDGES BY FIXED-OPTION
#    SCORING" — an unreadable verdict cannot happen; keep the text path only
#    where logprobs are not available, and record which path each used.
# ============================================================================
from __future__ import annotations

import json

from warp2.make.judges import Judges
from warp2.make.ledger import make_ledger


class Panel:
    """Intention: stand-in judges whose text can be set unreadable and whose chances can be set or absent."""

    def __init__(self, texts, chances=None):
        self.texts, self.chances, self.asked = texts, chances, []

    def names(self, kind=""):
        """Intention: every stand-in judge, by name."""
        return sorted(self.texts)

    def ask(self, model, prompt):
        """Intention: a readable verdict at the set score, or words no one can read."""
        score = self.texts[model]
        if score is None:
            return "I am not sure."
        return json.dumps({"score": score, "right": score > 0.5, "why": "x",
                           "tags": [{"name": "clear", "weight": 0.5}]})


class WithChances(Panel):
    """Intention: the same panel where models can answer the yes/no question as a chance."""

    def chance(self, model, prompt):
        """Intention: the set chance (None for no token chances); "boom" stands for a call that failed."""
        self.asked.append(prompt)
        found = self.chances.get(model)
        if found == "boom":
            raise RuntimeError("the child died")
        return found


def test_an_unreadable_text_is_still_a_verdict_by_its_chances(tmp_path):
    """Intention: the fix — all three texts unreadable, the chances say yes, so the work is judged and passes."""
    panel = WithChances({"a": None, "b": None, "c": None}, {"a": 0.9, "b": 0.8, "c": 0.85})
    verdict = Judges(panel, make_ledger(tmp_path)).judge("part", "x", "answer", [])
    assert verdict["unread"] == {}
    assert verdict["paths"] == {"a": "options", "b": "options", "c": "options"}
    assert verdict["quorum"] and verdict["passed"]
    assert all("Answer with one word: yes or no." in p for p in panel.asked)


def test_the_chances_decide_over_the_text(tmp_path):
    """Intention: the text says 0.9 but the chance of yes is 0.1 — the fixed options decide; the tags still come from the text."""
    panel = WithChances({"a": 0.9, "b": 0.9}, {"a": 0.1, "b": 0.2})
    verdict = Judges(panel, make_ledger(tmp_path)).judge("part", "x", "answer", [])
    assert verdict["by"] == {"a": 0.1, "b": 0.2}
    assert not verdict["passed"]
    assert verdict["tags"]["a"] and verdict["why"]["a"] == "x"


def test_without_token_chances_the_text_is_read_and_says_so(tmp_path):
    """Intention: a fleet with no chances, a model that gave none, or a failed call — read by text, recorded as text."""
    plain = Judges(Panel({"a": 0.9, "b": 0.9}), make_ledger(tmp_path)).judge("part", "x", "answer", [])
    assert plain["paths"] == {"a": "text", "b": "text"} and plain["passed"]
    mixed = Judges(WithChances({"a": 0.9, "b": 0.9, "c": None}, {"a": None, "b": "boom", "c": 0.7}),
                   make_ledger(tmp_path / "m")).judge("part", "x", "answer", [])
    assert mixed["paths"] == {"a": "text", "b": "text", "c": "options"}
    assert mixed["unread"] == {} and mixed["passed"]


def test_yes_is_read_from_the_first_word_token():
    """Intention: the chance of yes over yes and no where the answer is decided; None with no token chances."""
    from math import log
    from warp2.models.yes_no import chance
    first = [{"token": " Yes", "logprob": log(0.6),
              "top_logprobs": [{"token": "Yes", "logprob": log(0.6)}, {"token": " no", "logprob": log(0.2)},
                               {"token": "Maybe", "logprob": log(0.2)}]}]
    assert abs(chance(first) - 0.75) < 1e-6
    assert abs(chance([{"token": "\n", "logprob": 0.0}, {"token": "no", "logprob": log(0.9)}]) - 0.1) < 1e-6
    assert chance([]) is None and chance(None) is None
    assert chance([{"token": "Perhaps", "logprob": 0.0}]) is None


def test_the_fleet_gives_a_chance_only_for_a_model_that_has_one(tmp_path):
    """Intention: Fleet.chance reads the model's own chance reader, kept between 0 and 1; None without one."""
    from warp2.models.fleet import Fleet
    from warp2.store.store import Store
    from warp2.store.tagnet import TagNet
    fleet = Fleet(TagNet(Store(tmp_path / "state", run="fleet", view_path=tmp_path / "view.sqlite3")))
    fleet.enlist("plain:1b", lambda p: "text")
    fleet.enlist("sure:1b", lambda p: "text", chance=lambda p: 1.4)
    assert fleet.chance("plain:1b", "q") is None
    assert fleet.chance("sure-1b", "q") == 1.0


def test_the_roster_reads_the_child_chance_or_none(monkeypatch):
    """Intention: the watched child's {"chance"} becomes a number; anything else becomes None (text path)."""
    from warp2.models import roster
    said = {"text": json.dumps({"chance": 0.42, "said": "Yes"})}
    seen = {}

    def fake_isolated(entry, name, stop, patience=None, chance=False):
        """Intention: stand-in for the child; remembers that --chance was asked for."""
        seen["chance"] = chance
        return lambda prompt: said["text"]
    monkeypatch.setattr(roster, "_isolated", fake_isolated)
    ask = roster._isolated_chance({"path": "x"}, "m", None)
    assert ask("q") == 0.42 and seen["chance"] is True
    said["text"] = json.dumps({"chance": None})
    assert ask("q") is None
    said["text"] = "not json"
    assert ask("q") is None
