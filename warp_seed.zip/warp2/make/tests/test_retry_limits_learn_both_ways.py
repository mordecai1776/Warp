# WARP2/warp2/make/tests/test_retry_limits_learn_both_ways.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_retry_limits_learn_both_ways.py
#  Used by   : pytest.
#  Uses      : warp2/make/limits.py (limit, took, missed), warp2/make/ledger.py.
#  Description:
#    The tries a stage gets grow when a rung runs out of tries without a pass
#    and shrink as passes come quickly — smoothly, from what happened. One
#    first-try pass no longer locks the limit at one.
#  User intention (Andrew, 2026-09-24): "it retries (this is none to a set
#    self-adjusted limit.)" 2026-10-09, "ok lets get it done" — fix 5.2 of
#    claude/warp2_fix_plan_2026_10_09.md (check D4). Method: RFC 6298 —
#    a first measure's spread is half of it; a time-out doubles.
# ============================================================================
from __future__ import annotations

from warp2.make import limits
from warp2.make.ledger import make_ledger


def test_one_quick_pass_does_not_lock_the_limit_at_one(tmp_path):
    """Intention: check D4 — after one first-try pass, every node got one try for ever."""
    ledger = make_ledger(tmp_path)
    assert limits.limit(ledger, "part") == 2
    limits.took(ledger, "part", 1)
    assert limits.limit(ledger, "part") >= 2


def test_running_out_raises_the_limit_and_quick_passes_lower_it(tmp_path):
    """Intention: a rung that ran out says more were needed; many quick passes bring it back down."""
    ledger = make_ledger(tmp_path)
    limits.took(ledger, "part", 1)
    before = limits.limit(ledger, "part")
    limits.missed(ledger, "part", before)
    raised = limits.limit(ledger, "part")
    assert raised > before
    for _ in range(30):
        limits.took(ledger, "part", 1)
    assert limits.limit(ledger, "part") < raised
