# WARP2/warp2/make/tests/test_judges_are_counted_once.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/tests/test_judges_are_counted_once.py
#  Used by   : pytest.
#  Uses      : warp2/make/final_eval.py (after_settling), warp2/make/job.py,
#              warp2/make/ledger.py.
#  Description:
#    Each judge's verdict, and each role played, is counted once — against the
#    first outcome after it — however many times the job settles.
#  User intention (Andrew): trust earned, not inflated. 2026-10-09, "ok lets
#    get it done" — fix 5.5 of claude/warp2_fix_plan_2026_10_09.md (check
#    D11: judges were counted again every time a job settled).
# ============================================================================
from __future__ import annotations

from types import SimpleNamespace

from warp2.make.agents.who import ROLE
from warp2.make.final_eval import after_settling
from warp2.make.job import PART, Job, new_node
from warp2.make.ledger import JUDGED, make_ledger


def test_a_job_settled_twice_counts_its_judges_once(tmp_path):
    """Intention: settled "not done", made again, settled again — the old verdict is not counted twice."""
    ledger = make_ledger(tmp_path)
    job = Job.start({"item": "x"}, "pkg/thing.py")
    part = job.add(new_node(PART, "the part `a`", job.row["root"], {"name": "a", "research_by": "abe"}))
    part["verdicts"] = {"models": {"by": {"zed": 0.9}, "tags": {}, "rights": {}}}
    ctx = SimpleNamespace(ledger=ledger)
    after_settling(ctx, job, 0.0)
    after_settling(ctx, job, 1.0)
    assert ledger.mean(JUDGED, "zed", "part")[1] == 1
    assert ledger.mean(ROLE + "research", "abe", "*")[1] == 1
