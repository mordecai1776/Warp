# WARP2/warp2/make/eye_lessons.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/make/eye_lessons.py
#  Used by   : warp2/work/side/make_eye.py (the general training phase).
#  Uses      : warp2/make/{lessons,library,eye_makers}.py,
#              projects/behemoth_eye/eye/warp_eye.py (EyeBook),
#              projects/behemoth_eye/pairs/fronts.py (VECTOR).
#  Description:
#    The Eye taught from every stage that passed: its part for that level
#    (`make: <level>`) learns which passed answer this work called for, and
#    its master learns the same through the part — so the parts and the
#    master both carry every level of making. The weight of a lesson is the
#    score it passed with. Stages that failed teach nothing as an answer —
#    but every stage, passed or failed, teaches a judgement part per level
#    (`judge: <level>`) whether work like it passed.
#    Each judgement part's guesses on the new stages are counted before and
#    after it is taught, side by side in the step's one result row.
#    KEPT AS IT GOES (2026-11-08, BUILD_LOG 1453): the Eye is saved after
#    each level is taught, when a save is due by its own measured cost
#    (eye/save_pace.py), so a turn stopped part way keeps what it had taught.
#    The lessons are marked read only after the last save, so what was not
#    yet taught is taught again next time, never skipped.
#    The judge's guess on new stages goes into the skills table
#    (warp2/makers/skills.py, BUILD_LOG 1466), so practice can find it.
#  User intention (Andrew, 2026-09-24): "after every time it should train on
#    what it has done no matter what" and every task by "the eyes small parts
#    and ... the eye master".
# ============================================================================
from __future__ import annotations

from warp2.make.eye_makers import part_name, part_reading
from warp2.make.lessons import Lessons
from warp2.make.library import Library

LEARNER = "eye"

# Intention: the reader for the Eye's judgement parts, and what they tell apart.
JUDGE = "eye:judge"
VERDICTS = ("passed", "failed")


def judge_name(level: str) -> str:
    """Intention: the Eye's part that learns whether work at a level passed."""
    return f"judge: {level}"


def _judged_by_level(rows: list) -> dict:
    """Every stage the Eye can read, passed or failed, grouped by level as (inputs, labels, weights).

    Intention: A FAIL IS KEPT AS A FAIL. The weight is how far the stage's
    score sat from the middle — a clear pass or a clear fail says more than
    one the judges were split on — and never less than a sliver, so nothing
    it was shown counts for nothing.
    """
    out: dict = {}
    for row in rows:
        if not row.get("eye_tags"):
            continue
        passed = str(row.get("passed")).lower() == "true" or row.get("passed") is True
        try:
            score = float(row.get("score") or 0.0)
        except (TypeError, ValueError):
            score = 0.0
        got = out.setdefault(row["level"], ([], [], []))
        got[0].append(row["eye_tags"])
        got[1].append(VERDICTS[0] if passed else VERDICTS[1])
        got[2].append(max(abs(score - 0.5) * 2.0, 1.0 / (len(rows) + 1)))
    return out


def teach(state_dir) -> dict:
    """Every unread passed lesson taught to the Eye's parts, then the master taught everything again.

    Intention: TWO PASSES (Andrew, 2026-09-24: "the eye should make a model
    for ever part and use the smaller parts of everything then go back and do
    everything again with the updated combined master and train it all again
    in that form"). First each level's part learns its new lessons. Then the
    master — which reads the work together with what each part now says about
    it — is taught every passed lesson there has ever been, again, in that form.
    """
    lessons = Lessons(state_dir)
    unread = lessons.unread(LEARNER)
    fresh = _by_level([r for r in unread if _teachable(r)])
    # Intention: AND EVERY STAGE, PASSED OR FAILED, AS A JUDGEMENT (Andrew,
    # 2026-09-25: "the fails can be just as important as the pass"). A part
    # per level (`judge: <level>`) learns whether work like this passed —
    # the master with it — so a failure teaches the Eye what failing looks
    # like. Its own reader, so the stages already read are taught this too.
    judging_rows = lessons.unread(JUDGE)
    judging = _judged_by_level(judging_rows)
    if not fresh and not judging:
        lessons.read(LEARNER, len(unread))
        lessons.read(JUDGE, len(judging_rows))
        return {"read": len(unread), "taught": {}, "master": 0, "judged": {}, "judge_guesses": {}}
    from projects.behemoth_eye.eye.warp_eye import EyeBook
    from projects.behemoth_eye.pairs.fronts import VECTOR
    book = EyeBook(state_dir)
    judged, guesses = {}, {}
    for level, (inputs, labels, weights) in sorted(judging.items()):
        # Intention (BUILD_LOG 917; Muse-804, 2026-10-29): THE JUDGE'S GUESSES,
        # BEFORE AND AFTER, IN ONE ROW. Before it is taught, the judgement
        # part guesses pass/fail on these new stages — an honest guess, on
        # work it has not been taught. After, the same stages again. So
        # whether teaching moved its guesses toward what really happened is
        # read from this one row, without joining two records.
        before = _guesses_right(book, judge_name(level), inputs, labels)
        # Intention (Andrew, 2026-11-08 20:44: "general practice"; BUILD_LOG 1466): the guess on work it was not
        # taught is the judge's honest score, so it goes into the skills table, where practice finds it.
        if before and before["of"]:
            from warp2.makers.skills import note_skill
            note_skill(state_dir, judge_name(level), "judge", before["right"] / before["of"],
                       f"guessed {before['right']} of {before['of']} new stages right")
        book.learn(judge_name(level), inputs, labels, list(VERDICTS), VECTOR, weights=weights)
        judged[level] = dict((v, labels.count(v)) for v in VERDICTS)
        guesses[level] = {"before": before, "after": _guesses_right(book, judge_name(level), inputs, labels)}
        # Intention (Andrew, 2026-11-08 20:24: "Make sure when it stops training that it keeps the training it had
        # already done"; BUILD_LOG 1453): kept after each level when a save is due by its measured cost.
        book.save()
    lessons.read(JUDGE, len(judging_rows))
    if not fresh:
        book.save()
        lessons.read(LEARNER, len(unread))
        return {"read": len(unread), "taught": {}, "master": 0, "judged": judged, "judge_guesses": guesses}
    library = Library(state_dir)
    taught = {}
    for level, (inputs, labels, weights) in sorted(fresh.items()):
        book.learn(part_name(level), inputs, labels, library.ids(level), VECTOR, weights=weights,
                   everything=False)
        taught[level] = len(labels)
        # Intention (BUILD_LOG 1453): kept after each level when a save is due.
        book.save()
    master_inputs, master_labels = [], []
    for level, (inputs, labels, weights) in sorted(_by_level([r for r in lessons.rows() if _teachable(r)]).items()):
        # Intention: A LEVEL WITH NO PART YET IS TAUGHT, NOT A STOP (Andrew,
        # 2026-10-29: "The fact that it hasn't proven something shouldn't be
        # a barrier"). Lessons already read can sit in the record for a level
        # whose part the Eye does not hold (a new or rebuilt Eye); reading it
        # raised KeyError and the whole step failed. Its part learns that
        # level's whole history first, then it is read like the rest.
        if part_name(level) not in book.tasks():
            book.learn(part_name(level), inputs, labels, library.ids(level), VECTOR, weights=weights,
                       everything=False)
            taught[level] = taught.get(level, 0) + len(labels)
        readings = book.read(part_name(level), inputs)
        master_inputs += [tags + part_reading(reading) for tags, reading in zip(inputs, readings)]
        master_labels += [f"{part_name(level)}: {label}" for label in labels]
    book.pair(book.everything_name(VECTOR), [], VECTOR).learn(master_inputs, master_labels)
    book.save()
    lessons.read(LEARNER, len(unread))
    return {"read": len(unread), "taught": taught, "master": len(master_labels), "judged": judged,
            "judge_guesses": guesses}


def _guesses_right(book, part: str, inputs: list, labels: list) -> dict | None:
    """How many stages the judgement part guesses right: {"right", "of"}; None when it has no such part yet.

    Intention: a guess is "passed" when the part leans to passed over failed
    (the same lean eye_judge.passed_share reads); a stage it says neither on
    is not counted, so "of" is how many it actually guessed.
    """
    # Intention: a book that cannot say which parts it holds cannot be asked
    # for a guess either; that is "no reading", never a failed step.
    tasks = getattr(book, "tasks", None)
    if tasks is None or part not in tasks():
        return None
    right = guessed = 0
    for reading, label in zip(book.read(part, inputs), labels):
        yes, no = reading.get(VERDICTS[0]), reading.get(VERDICTS[1])
        if yes is None or no is None or (yes + no) <= 0:
            continue
        guessed += 1
        right += int((VERDICTS[0] if yes >= no else VERDICTS[1]) == label)
    return {"right": right, "of": guessed}


def _teachable(row: dict) -> bool:
    """Intention: a lesson that passed, with the answer it passed with and what the Eye read."""
    return bool(row.get("passed") and row.get("library_id") and row.get("eye_tags"))


def _by_level(rows: list) -> dict:
    """Intention: lessons grouped by level as (inputs, labels, weights)."""
    out: dict = {}
    for row in rows:
        got = out.setdefault(row["level"], ([], [], []))
        got[0].append(row["eye_tags"])
        got[1].append(row["library_id"])
        got[2].append(max(0.0, float(row.get("score") or 0.0)))
    return out
