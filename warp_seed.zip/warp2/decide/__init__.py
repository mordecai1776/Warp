# WARP2/warp2/decide/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/__init__.py
#  Used by   : warp2/work/loop.py (Loop.decisions), warp2/run.py (`decisions`).
#  Uses      : warp2/decide/registry.py.
#  Description:
#    Decision models: action models that never use text. Every choice WARP
#    makes from a fixed list gets its own small model, built from the Eye's
#    own unit, that answers with a probability for each choice. It learns
#    from how each choice turned out, its probabilities are checked against
#    the record, and it is only used once it beats the rule it shadows.
#  User intention (Andrew, 2026-09-18):
#    "there should be a system to make and use action models that never use
#    text." And 2026-09-12: the system should make its own model for a new
#    task that goes straight into the Eye; it should only graduate when it can
#    do the work, and if it promotes something it should use it.
# ============================================================================
from warp2.decide.registry import Decisions

__all__ = ["Decisions"]
