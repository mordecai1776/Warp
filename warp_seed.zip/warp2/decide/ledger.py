# WARP2/warp2/decide/ledger.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/ledger.py
#  Used by   : warp2/decide/decider.py, warp2/decide/gate_features.py (seeding).
#  Uses      : warp2/util.py; stdlib json.
#  Description:
#    One file per decision point: every time it was asked (the features and
#    what each side said) and, later, how it turned out. Append only.
#  User intention (Andrew, 2026-09-18):
#    "a system to make and use action models that never use text." A model
#    that learns from what happened needs what happened written down.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.util import now_iso


class DecisionLedger:
    """Asked and settled rows for one decision point.

    Intention: two events per decision, joined by id. A decision that never
    settles teaches nothing, and is never counted as right or wrong.
    """

    def __init__(self, state, point: str) -> None:
        """Intention: state/decisions/<point>.jsonl."""
        self.path = Path(state) / "decisions" / f"{point}.jsonl"

    def exists(self) -> bool:
        """Intention: a point with no file yet may be seeded from history."""
        return self.path.is_file()

    def asked(self, row_id: str, features: dict, rule: dict, model: dict) -> None:
        """Intention: what was known and what each side said, before the outcome."""
        self._add({"event": "asked", "id": row_id, "features": features,
                   "rule": rule, "model": model})

    def ruled(self, row_id: str, rule: dict) -> None:
        """Intention: the bigger rung's answer, when it came after the ask."""
        self._add({"event": "ruled", "id": row_id, "rule": rule})

    def settled(self, row_id: str, outcome: str) -> None:
        """Intention: which choice turned out to be right."""
        self._add({"event": "settled", "id": row_id, "outcome": str(outcome)})

    def history(self) -> list:
        """Every settled decision, in the order it was asked.

        Intention: the order matters — each is scored on what the model knew
        BEFORE it, which is what makes the comparison honest.
        """
        asked, order, outcome = {}, [], {}
        for row in self._rows():
            if row.get("event") == "asked":
                asked[row["id"]] = row
                order.append(row["id"])
            elif row.get("event") == "settled":
                outcome[row["id"]] = row.get("outcome")
            elif row.get("event") == "ruled" and row.get("id") in asked:
                asked[row["id"]] = {**asked[row["id"]], "rule": row.get("rule") or {}}
        return [{**asked[i], "outcome": outcome[i]} for i in order if i in outcome]

    def _add(self, row: dict) -> None:
        """Intention: one line, appended."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({**row, "at": now_iso()}, default=str) + "\n")

    def _rows(self) -> list:
        """Intention: a torn line is skipped, never fatal."""
        if not self.path.is_file():
            return []
        out = []
        for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
        return out
