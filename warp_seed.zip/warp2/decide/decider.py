# WARP2/warp2/decide/decider.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/decider.py
#  Used by   : warp2/decide/registry.py (one per decision point),
#              warp2/decide/ladder.py (the rungs above and below it).
#  Uses      : warp2/decide/{model,calibration,standing,ledger}.py.
#  Description:
#    One decision point: asked with the tags that describe the case and the
#    rule's own answer; answers with calibrated probabilities and whether it
#    has graduated. Settled later with what actually happened, which it
#    learns from. Rebuilt from its ledger at start — or, when the saved Eye
#    already holds its part taught on the ledger's first rows, carried on
#    from there with only the newer rows.
#  User intention (Andrew, 2026-09-18):
#    "a system to make and use action models that never use text." Shadow
#    until it can do the work; used once it has shown it can.
# ============================================================================
from __future__ import annotations

import hashlib
import uuid

from warp2.decide.calibration import Calibration
from warp2.decide.ledger import DecisionLedger
from warp2.decide.model import DecisionModel
from warp2.decide.standing import Standing


class Decider:
    """The action model, its calibration, its standing, and its record."""

    def __init__(self, state, point: str, choices) -> None:
        """Intention: built from nothing, then taught everything the ledger holds."""
        self.point = str(point)
        self.choices = tuple(choices)
        self.state = state
        self.ledger = DecisionLedger(state, self.point)
        self.replay()

    def replay(self) -> None:
        """Rebuild the model from every settled decision, in order — or carry on from the saved part.

        Intention: the same steps the live decider took, so the rebuilt model
        is the model — and every decision is scored before it is learned from.
        (2026-10-03, planned in BUILD_LOG 216) Every start replayed all 568
        settled decisions, one at a time, each going over the part's whole
        kept set again — many minutes before the loop did any work. Beside
        its part the decider now keeps which rows it was taught (their count
        and a fingerprint of their ids, in order) with its calibration and
        standing; when the ledger still begins with exactly those rows, the
        saved part and those counts ARE the replay's result up to there, and
        only the rows after them are learned. Anything else rebuilds as before.
        """
        rows = self.ledger.history()
        keys = [str(row.get("id", "")) for row in rows]
        self.open = {}
        self.model = DecisionModel(self.point, self.choices, state=self.state, fresh=False)
        kept = self.model.kept()
        start = int(kept.get("count", 0) or 0)
        if start and start <= len(keys) and kept.get("digest") == _digest(keys[:start]):
            self.calibration = {c: _calibration(kept.get("calibration", {}).get(c)) for c in self.choices}
            self.standing = _standing(kept.get("standing"))
            self.model.taught = int(kept.get("taught", 0) or 0)
            self._keys = list(keys[:start])
        else:
            self.model = DecisionModel(self.point, self.choices, state=self.state)
            self.calibration = {c: Calibration() for c in self.choices}
            self.standing = Standing()
            self._keys, start = [], 0
        for key, row in zip(keys[start:], rows[start:]):
            self._learn(row["features"], row.get("rule") or {}, row["outcome"], key=key)
        self._mark()

    def ask(self, features: dict, rule: dict) -> dict:
        """What the model says, calibrated, and whether it should be used.

        Intention: always recorded, used only when graduated. `rule` is the
        probability per choice the current way of deciding gives.
        """
        raw = self.model.probabilities(features)
        calibrated = self._calibrated(raw)
        row_id = uuid.uuid4().hex[:16]
        self.open[row_id] = (features, rule)
        self.ledger.asked(row_id, features, rule, {"raw": raw, "calibrated": calibrated})
        graduated = self.model.ready and self.standing.graduated()
        pick = max(calibrated, key=calibrated.get)
        return {"id": row_id, "probabilities": calibrated, "choice": pick,
                "graduated": graduated, "takes_over": self.model.ready and self.standing.takes_over(),
                "standing": self.standing.says()}

    def peek(self, features: dict) -> dict:
        """What the model says, calibrated, WITHOUT opening a decision.

        Intention: for a bigger thing that only wants to lean on the small
        one's opinion — ranking candidates, say — where no single outcome will
        come back to settle it. Nothing is recorded, so nothing is left open.
        """
        calibrated = self._calibrated(self.model.probabilities(features))
        return {"probabilities": calibrated,
                "graduated": self.model.ready and self.standing.graduated()}

    def settle(self, row_id: str, outcome: str, rule: dict | None = None) -> None:
        """What happened; the model, its calibration and its standing all learn.

        Intention: `rule` may be given here instead of at `ask`, for a bigger
        rung that is only asked after the small one has answered.
        """
        if row_id not in self.open or outcome not in self.choices:
            return
        features, asked_rule = self.open.pop(row_id)
        rule = rule if rule is not None else asked_rule
        if rule and not asked_rule:
            self.ledger.ruled(row_id, rule)
        self.ledger.settled(row_id, outcome)
        self._learn(features, rule, outcome, live=True, key=row_id)
        self._mark()

    def _calibrated(self, raw: dict) -> dict:
        """Intention: each choice through its own calibration, then summing to one."""
        cal = {c: self.calibration[c](raw[c]) for c in self.choices}
        total = sum(cal.values()) or 1.0
        return {c: v / total for c, v in cal.items()}

    def _learn(self, features: dict, rule: dict, outcome: str, live: bool = False, key: str = "") -> None:
        """Intention: score first, then learn — so the record stays held-out.

        `live` is an outcome settled now rather than replayed from the ledger;
        `key` is its ledger row, remembered in the order it was learned.
        """
        self._keys = getattr(self, "_keys", [])
        self._keys.append(str(key))
        raw = self.model.probabilities(features)
        said = self._calibrated(raw)
        # Intention: compared only where the bigger side answered too. Once
        # the smaller one has taken over, the bigger one is asked less, and a
        # case it was not asked about proves nothing either way.
        if rule:
            rule_p = float(rule.get(outcome, 0.0))
            self.standing.add(said.get(outcome, 0.0), rule_p, True)
            self.standing.hit(max(said, key=said.get) == outcome,
                              max(rule, key=rule.get) == outcome)
        # Intention: (2026-10-24) every decision, rule or not, is also scored
        # against how often its outcome has happened so far (Standing).
        self.standing.against_base(outcome, said.get(outcome, 0.0), len(self.choices))
        for choice in self.choices:
            self.calibration[choice].learn(raw[choice], choice == outcome)
        self.model.learn(features, outcome, live=live)

    def _mark(self) -> None:
        """Intention: beside the part, the rows learned (in order) and the counts that go with them (see `replay`)."""
        self.model.mark({"count": len(self._keys), "digest": _digest(self._keys),
                         "taught": int(self.model.taught),
                         "calibration": {c: {"said": list(k.said), "true": list(k.true)}
                                         for c, k in self.calibration.items()},
                         "standing": dict(vars(self.standing))})

    def says(self) -> dict:
        """Intention: what `run decisions` prints for this point."""
        return {"point": self.point, "choices": list(self.choices), "ready": self.model.ready,
                **self.standing.says(),
                "calibration": {c: self.calibration[c].table() for c in self.choices[:1]}}


def _digest(keys: list) -> str:
    """Intention: one short fingerprint of an ordered list of ledger row ids."""
    return hashlib.sha256("\n".join(keys).encode("utf-8")).hexdigest()[:24]


def _calibration(kept) -> Calibration:
    """Intention: a calibration back as it was kept (a fresh one when nothing was)."""
    made = Calibration()
    if kept:
        made.said = [int(v) for v in kept.get("said", made.said)]
        made.true = [int(v) for v in kept.get("true", made.true)]
    return made


def _standing(kept) -> Standing:
    """Intention: a standing back as it was kept (a fresh one when nothing was)."""
    made = Standing()
    for name, value in dict(kept or {}).items():
        if hasattr(made, name):
            setattr(made, name, value)
    return made
