# WARP2/warp2/decide/turn_kind.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/turn_kind.py
#  Used by   : warp2/ask/talk.py.
#  Uses      : stdlib re.
#  Description:
#    The decision "what kind of turn is this": a picture, a clip, a project,
#    a comment on something, an intention, or just talk. The tags are the
#    words he used — no sentence is read, only which words are there.
#  User intention (Andrew, 2026-09-18):
#    "make everything automations, if not action models, if not those bigger
#    models." The window's keyword rules are the automation; this is the
#    action model under the local language model.
# ============================================================================
from __future__ import annotations

import re

POINT = "turn_kind"
CHOICES = ("image", "video", "project", "comment", "intention", "talk")

# Intention: words that carry no kind at all; they would only add noise.
_QUIET = frozenset("a an the of to and or is it i me my you your this that in on for with".split())
# Intention: the words a request opens with, dropped to leave the subject.
_ASKING = re.compile(r"^(?:(?:can|could|would|will)\s+you\s+|please\s+|i\s+want\s+|i'd\s+like\s+)*"
                     r"(?:make|draw|show|create|generate|give|render|paint|animate)?\s*(?:me\s+)?"
                     r"(?:a|an|some)?\s*(?:picture|image|photo|drawing|video|clip|animation)?\s*(?:of\s+)?",
                     re.IGNORECASE)


def features(said: str) -> dict:
    """Intention: one tag per word he used, plus how long the turn was."""
    words = [w for w in re.findall(r"[a-z']+", str(said or "").lower()) if w not in _QUIET]
    tags = {f"word:{w}": 1.0 for w in words}
    tags[f"words:{min(len(words), 12) // 3}"] = 1.0
    tags[f"asks:{'yes' if str(said).rstrip().endswith('?') else 'no'}"] = 1.0
    return tags


def subject(said: str) -> str:
    """Intention: what the picture or clip is of — his words, less the asking."""
    left = _ASKING.sub("", str(said or "").strip(), count=1).strip(" .!?")
    return left or str(said or "").strip()
