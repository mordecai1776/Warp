# WARP2/warp2/decide/tests/test_who_writes_sees_history.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/tests/test_who_writes_sees_history.py
#  Used by   : pytest, or the plain runner (no fixtures needed).
#  Uses      : warp2/decide/gate_features.py (before_writing, features),
#              warp2/work/loop.py (Loop._likeliest_accepted).
#  Description:
#    The "who writes" ranking asks the gate_accepts model before any file
#    exists. It now gets the case's cockpit history as the same kg tags the
#    gate decision gets after writing; with no history, the tags are as before.
#  User intention (Andrew, 2026-10-16):
#    "every model starts new each time it's run; the cockpit gives the history"
# ============================================================================
from __future__ import annotations

from warp2.decide.gate_features import before_writing, cockpit_tags, features


def test_no_history_leaves_the_ranking_tags_as_they_were():
    """Intention: a ranking with no slice is tagged exactly as before."""
    plain = before_writing("build", "projects/a/x.py", "m1")
    assert plain == {"kind:build": 1.0, "project:a": 1.0, "folder:projects/a": 1.0, "model:m1": 1.0}
    assert before_writing("build", "projects/a/x.py", "m1", history={}) == plain


def test_the_ranking_gets_the_same_history_tags_as_the_gate():
    """Intention: before and after writing, the case's history reads the same."""
    history = {"a": 0.6, "b": 0.3, "c": 0.1}
    ranked = before_writing("build", "projects/a/x.py", "m1", history=history)
    gated = features("build", "projects/a/x.py", "x = 1\n", 0.5, model="m1", history=history)
    kg = cockpit_tags(history)
    assert kg and all(ranked.get(t) == 1.0 for t in kg)
    assert all(gated.get(t) == 1.0 for t in kg)


class _Point:
    """Intention: a graduated decision point that records the tags it is asked about."""

    def __init__(self):
        self.seen = []

    def peek(self, tags):
        self.seen.append(dict(tags))
        good = 0.9 if tags.get("model:m2") else 0.4
        return {"graduated": True, "probabilities": {"accept": good, "refuse": 1 - good}}


class _Decisions:
    def __init__(self, point):
        self.point = point

    def get(self, name, choices):
        return self.point


def test_the_loop_hands_the_history_to_the_ranking():
    """Intention: _likeliest_accepted passes the case's history to every peek."""
    from warp2.work.loop import Loop
    point = _Point()
    fake = type("L", (), {"decisions": _Decisions(point)})()
    picked = Loop._likeliest_accepted(fake, "build", "projects/a/x.py", ["m1", "m2"],
                                      history={"a": 1.0})
    assert picked == "m2"
    assert len(point.seen) == 2 and all("kg:a" in tags for tags in point.seen)
