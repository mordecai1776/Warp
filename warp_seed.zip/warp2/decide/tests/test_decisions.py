# WARP2/warp2/decide/tests/test_decisions.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/tests/test_decisions.py
#  Used by   : pytest.
#  Uses      : warp2/decide/{registry,decider,calibration,standing,gate_features}.py.
#  Description:
#    A decision model is made when first asked, learns from outcomes, is
#    scored only on decisions it had not learned from, graduates only when it
#    beats the rule by more than its noise, and is rebuilt the same from its
#    ledger. Seeding reads the journals' file writes.
#  User intention (Andrew, 2026-09-18):
#    "a system to make and use action models that never use text."
# ============================================================================
from __future__ import annotations

import json
import random

from warp2.decide import Decisions
from warp2.decide.calibration import Calibration
from warp2.decide.gate_features import features, seed
from warp2.decide.standing import Standing


def _case(good: bool) -> dict:
    """Intention: two kinds of case the model can learn to tell apart."""
    return {"kind:build": 1.0, f"parses:{'yes' if good else 'no'}": 1.0}


def test_a_new_decision_gets_its_own_model(tmp_path):
    """Intention: asked once, it exists, with a ledger of its own."""
    point = Decisions(tmp_path).get("route_turn", ("image", "project", "comment"))
    got = point.ask({"words:picture": 1.0}, {"image": 0.5, "project": 0.25, "comment": 0.25})
    assert set(got["probabilities"]) == {"image", "project", "comment"}
    assert abs(sum(got["probabilities"].values()) - 1.0) < 1e-9
    assert got["graduated"] is False
    assert (tmp_path / "decisions" / "route_turn.jsonl").is_file()


def test_it_learns_beats_a_useless_rule_and_graduates(tmp_path):
    """Intention: the rule says 50/50 every time; the model can learn better, and does."""
    point = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    rng = random.Random(7)
    for _ in range(150):
        good = rng.random() < 0.5
        got = point.ask(_case(good), {"yes": 0.5, "no": 0.5})
        point.settle(got["id"], "yes" if good else "no")
    said = point.says()
    assert said["model_brier"] < said["rule_brier"]
    assert said["graduated"] is True
    assert point.ask(_case(True), {"yes": 0.5, "no": 0.5})["choice"] == "yes"


def test_it_does_not_graduate_against_a_rule_that_is_already_right(tmp_path):
    """Intention: only graduate when it can do the work BETTER than what decides now."""
    point = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    rng = random.Random(3)
    for _ in range(60):
        good = rng.random() < 0.5
        got = point.ask(_case(good), {"yes": 1.0 if good else 0.0, "no": 0.0 if good else 1.0})
        point.settle(got["id"], "yes" if good else "no")
    assert point.says()["graduated"] is False


def test_it_is_rebuilt_the_same_from_its_ledger(tmp_path):
    """Intention: a restart does not forget, and does not change its mind."""
    point = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    for good in [True, False] * 20:
        got = point.ask(_case(good), {"yes": 0.5, "no": 0.5})
        point.settle(got["id"], "yes" if good else "no")
    again = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    assert again.says() == point.says()
    assert again.ask(_case(True), {"yes": 0.5, "no": 0.5})["probabilities"] == \
        point.ask(_case(True), {"yes": 0.5, "no": 0.5})["probabilities"]


def test_calibration_follows_the_record():
    """Intention: a band that says 90% and comes true 40% of the time is pulled toward 40%."""
    cal = Calibration()
    for n in range(50):
        cal.learn(0.95, n % 5 < 2)
    assert abs(cal(0.95) - 0.4) < 0.1


def test_a_lucky_few_decisions_do_not_graduate():
    """Intention: two decisions are never enough, however good they look."""
    stand = Standing()
    stand.add(1.0, 0.5, True)
    assert stand.graduated() is False


def test_the_gate_point_is_seeded_from_the_journals(tmp_path):
    """Intention: it starts from every write the machine already made."""
    journals = tmp_path / "journals"
    journals.mkdir()
    rows = [{"verb": "write_file", "outcome": "refused", "target": "projects/p/a.py", "score": 900,
             "work_kind": "build", "content": "def f(:\n", "ts": "2026-09-17T01:00:00",
             "error": "that python will not parse"},
            {"verb": "write_file", "outcome": "ok", "target": "projects/p/a.py", "score": 900,
             "work_kind": "build", "content": "# a\ndef f():\n    return 1\n", "ts": "2026-09-17T02:00:00"}]
    (journals / "continuous.jsonl").write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")
    assert seed(tmp_path) == 2
    point = Decisions(tmp_path).get("gate_accepts", ("accept", "refuse"))
    assert point.says()["decisions"] == 2


def test_the_same_file_gives_the_same_tags_live_and_seeded():
    """Intention: history must mean what the live tags mean."""
    tags = features("build", "projects/p/a.py", "# a\ndef f():\n    return 1\n", 0.9, 1, "problem:x", "")
    assert tags["project:p"] == 1.0 and tags["parses:yes"] == 1.0 and tags["refused_before:1"] == 1.0
    assert "said_sure:9of10" in tags


def test_a_restart_carries_on_from_the_saved_part_without_learning_it_all_again(tmp_path, monkeypatch):
    """Intention (2026-10-03): the part already taught the ledger's rows is kept; only newer rows are learned at start."""
    from warp2.decide.model import DecisionModel
    point = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    for good in [True, False] * 10:
        got = point.ask(_case(good), {"yes": 0.5, "no": 0.5})
        point.settle(got["id"], "yes" if good else "no")
    learned = []
    real = DecisionModel.learn
    monkeypatch.setattr(DecisionModel, "learn", lambda self, *a, **k: learned.append(1) or real(self, *a, **k))
    again = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    assert learned == [] and again.says() == point.says()
    assert again.ask(_case(True), {"yes": 0.5, "no": 0.5})["probabilities"] == \
        point.ask(_case(True), {"yes": 0.5, "no": 0.5})["probabilities"]


def test_a_ledger_that_no_longer_begins_the_same_is_rebuilt_from_all_of_it(tmp_path):
    """Intention: when the rows the part was taught are not the ledger's first rows any more, it starts over from all of them."""
    point = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    for good in [True, False] * 5:
        got = point.ask(_case(good), {"yes": 0.5, "no": 0.5})
        point.settle(got["id"], "yes" if good else "no")
    ledger = tmp_path / "decisions" / "will_pass.jsonl"
    lines = ledger.read_text(encoding="utf-8").splitlines()
    ledger.write_text("\n".join(lines[2:]) + "\n", encoding="utf-8")
    again = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    assert again.model.kept()["count"] == 9 and again.model.taught == 9
