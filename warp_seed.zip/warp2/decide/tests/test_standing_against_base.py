# WARP2/warp2/decide/tests/test_standing_against_base.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/tests/test_standing_against_base.py
#  Used by   : pytest (and CHECK_FIXES.bat).
#  Uses      : warp2/decide/{standing,registry}.py.
#  Description:
#    A decision model is also scored against the plainest guess — how often
#    each outcome has happened so far — not only against the rule it
#    shadows. A model that only beats a bad rule does not show as skilled,
#    and a model whose edge has faded shows it in its recent temperature.
#  User intention (Andrew, 2026-10-16 and 2026-10-23):
#    temperatures, not bars; "get the eye to work inside the warp and improve
#    while it's working inside the warp" — measured, or the failure point.
# ============================================================================
from __future__ import annotations

from warp2.decide import Decisions
from warp2.decide.standing import Standing


def test_a_model_no_better_than_the_outcome_share_does_not_beat_the_base():
    """Intention: outcomes 70/30; a model that only says the share seen so far is the base, not skill."""
    stand = Standing()
    seen = {"yes": 0, "no": 0}
    for i in range(200):
        outcome = "yes" if i % 10 < 7 else "no"
        share = (seen[outcome] + 1.0) / (sum(seen.values()) + 2)
        stand.against_base(outcome, share, 2)
        seen[outcome] += 1
    said = stand.says()
    assert said["base_decisions"] == 200
    assert said["beats_base"] is False
    assert abs(said["base_brier"] - said["model_brier_on_base_rows"]) < 0.01


def test_a_model_that_knows_beats_the_base_and_a_faded_one_shows_it_recently():
    """Intention: right with 0.9 for 150 decisions beats the base; then even-odds guesses pull recent skill below zero."""
    stand = Standing()
    for i in range(150):
        stand.against_base("yes" if i % 2 else "no", 0.9, 2)
    assert stand.beats_base() is True and stand.recent_skill > 0
    for i in range(100):
        stand.against_base("yes" if i % 2 else "no", 0.1, 2)
    assert stand.recent_skill < 0


def test_the_decider_reports_the_base_candle_and_keeps_it_over_a_restart(tmp_path):
    """Intention: every settled decision is scored against the base, and the counts come back after a restart."""
    point = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    for i in range(12):
        got = point.ask({"tag:%d" % (i % 3): 1.0}, {"yes": 0.5, "no": 0.5})
        point.settle(got["id"], "yes" if i % 3 else "no")
    said = point.says()
    assert said["base_decisions"] == 12 and "recent_skill" in said
    again = Decisions(tmp_path).get("will_pass", ("yes", "no"))
    assert again.says()["base_decisions"] == 12
