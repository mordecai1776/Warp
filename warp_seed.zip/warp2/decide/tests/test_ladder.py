# WARP2/warp2/decide/tests/test_ladder.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/tests/test_ladder.py
#  Used by   : pytest.
#  Uses      : warp2/decide/{ladder,turn_kind,registry,gate_features}.py,
#              warp2/ask/talk.py, warp2/models/worker.py,
#              warp2/gate/{mend,import_table}.py.
#  Description:
#    The smallest proven rung answers: an automation first, the action model
#    once its record says it is not worse than the bigger model, the bigger
#    model otherwise. The bigger model's answers are what the small one is
#    measured against. The worker leans on the gate_accepts model to pick who
#    writes; accepted files teach the import mend.
#  User intention (Andrew, 2026-09-18):
#    "It should use the smallest and simplest forms of what it has. Then the
#    bigger things should use the smaller things."
# ============================================================================
from __future__ import annotations

import random
from pathlib import Path

from warp2.ask.talk import Talk
from warp2.decide import Decisions
from warp2.decide.ladder import ACTION_MODEL, AUTOMATION, Ladder
from warp2.decide.turn_kind import CHOICES, POINT, features, subject
from warp2.gate.import_table import ImportTable, import_lines
from warp2.gate.mend import Mend
from warp2.models.worker import Worker


class _Knowing:
    """Intention: a store that knows nothing, so only the rungs answer."""

    def say(self, words):
        return ""

    def find(self, words):
        return ""

    def overview(self):
        return {"projects": [], "open_work": 0}


def _train(ladder, rounds, bigger_right=0.7, seed=5):
    """Intention: two kinds of case; the bigger rung is right only some of the time."""
    rng = random.Random(seed)
    for _ in range(rounds):
        picture = rng.random() < 0.5
        truth = "image" if picture else "talk"
        got = ladder.climb({"word:picture" if picture else "word:hello": 1.0})
        if got["rung"] is None:
            wrong = "talk" if picture else "image"
            ladder.bigger_said(got["id"], truth if rng.random() < bigger_right else wrong)
        ladder.settle(got["id"], truth)


def test_an_automation_that_answers_is_used_and_the_model_learns_beside_it(tmp_path):
    """Intention: the smallest rung first; the action model still gets the lesson."""
    ladder = Ladder(Decisions(tmp_path).get(POINT, CHOICES))
    got = ladder.climb(features("make a picture of a fox"), automation="image")
    assert got["rung"] == AUTOMATION and got["choice"] == "image"
    ladder.settle(got["id"], "image")
    assert ladder.decider.says()["decisions"] == 1


def test_the_bigger_rung_is_asked_until_the_small_one_has_proven_itself(tmp_path):
    """Intention: at first nothing is proven, so the answer is 'ask the bigger one'."""
    ladder = Ladder(Decisions(tmp_path).get(POINT, CHOICES))
    assert ladder.climb({"word:picture": 1.0})["rung"] is None


def test_the_action_model_takes_over_once_it_is_not_worse(tmp_path):
    """Intention: a bigger rung right 70% of the time is overtaken by a small one right nearly always."""
    ladder = Ladder(Decisions(tmp_path).get(POINT, CHOICES))
    _train(ladder, 150)
    said = ladder.decider.says()
    assert said["takes_over"] is True, said
    got = ladder.climb({"word:picture": 1.0})
    assert got["rung"] == ACTION_MODEL and got["choice"] == "image"


def test_it_never_takes_over_from_a_bigger_rung_that_is_always_right(tmp_path):
    """Intention: 'not worse' is measured; a perfect bigger rung keeps the job."""
    ladder = Ladder(Decisions(tmp_path).get(POINT, CHOICES))
    _train(ladder, 60, bigger_right=1.0)
    assert ladder.decider.says()["takes_over"] is False


def test_the_subject_is_his_words_less_the_asking():
    """Intention: 'can you make me a picture of a red fox' is a picture of a red fox."""
    assert subject("can you make me a picture of a red fox") == "a red fox"
    assert features("what is this?")["asks:yes"] == 1.0


def test_talk_settles_each_turn_by_what_he_did_with_it(tmp_path):
    """Intention: a refused or ignored offer was talk; a taken one was that kind."""
    decisions = Decisions(tmp_path)
    talk = Talk(_Knowing(), ask=lambda prompt: "hello", decisions=decisions)
    answer = talk.reply("just saying hi")
    assert answer["proposes"] is None and talk.turn_open
    talk.reply("and again")
    point = decisions.get(POINT, CHOICES)
    assert point.says()["decisions"] == 1  # the first turn, settled as talk, compared to the model's "talk"
    talk.turn_heard("talk")
    assert talk.turn_open is None


def test_talk_uses_the_action_model_without_the_language_model(tmp_path):
    """Intention: once proven, a picture is offered even with no language model at all."""
    decisions = Decisions(tmp_path)
    _train(Ladder(decisions.get(POINT, CHOICES)), 150)
    talk = Talk(_Knowing(), ask=None, decisions=decisions)
    answer = talk.reply("picture")
    assert answer["rung"] == ACTION_MODEL
    assert answer["proposes"]["kind"] == "image"
    assert answer["proposes"]["about"] == "project:centering_image"


class _Fleet:
    """Intention: two models the fleet would let try; it would pick the first."""

    def choose(self, kind, stream=""):
        return "big"

    def eligible(self, kind):
        return ["big", "small"]


def test_the_worker_takes_the_action_models_pick_among_the_eligible():
    """Intention: the bigger thing uses the smaller thing — and only among who may try."""
    worker = Worker(_Fleet())
    assert worker._smaller_says("build", "x.py", "big") == "big"
    worker.rank = lambda kind, target, names: "small" if "small" in names else ""
    assert worker._smaller_says("build", "x.py", "big") == "small"
    worker.rank = lambda kind, target, names: ""
    assert worker._smaller_says("build", "x.py", "big") == "big"


def test_accepted_files_teach_the_import_mend(tmp_path):
    """Intention: a name always brought in one way is mended that way; two ways, not at all."""
    table = ImportTable(tmp_path)
    assert import_lines("from warp2.store.store import Store as S\nimport numpy as np\nfrom . import x\n") == {
        "S": "from warp2.store.store import Store as S", "np": "import numpy as np"}
    table.learn("from warp2.store.store import Store\n")
    assert ImportTable(tmp_path).line_for("Store") == "from warp2.store.store import Store"
    root = tmp_path / "tree"
    (root / "warp2").mkdir(parents=True)
    said = "uses names it never imports or defines: Store"
    mended = Mend(root, table).mend("warp2/new.py", "x = Store()\n", said)
    assert mended["content"].startswith("from warp2.store.store import Store\n")
    table.learn("from somewhere.other import Store\n")
    assert table.line_for("Store") == ""
    assert Mend(root, table).mend("warp2/new.py", "x = Store()\n", said) is None
