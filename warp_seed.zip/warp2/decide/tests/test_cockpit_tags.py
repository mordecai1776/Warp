# WARP2/warp2/decide/tests/test_cockpit_tags.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/tests/test_cockpit_tags.py
#  Used by   : pytest, or the plain runner (no fixtures needed).
#  Uses      : warp2/decide/gate_features.py (features, cockpit_tags),
#              warp2/work/loop.py (Loop._history_of).
#  Description:
#    The gate-acceptance decision gets the case's history from the cockpit:
#    the few tags that brought most of the narrowed KG view, with their share
#    in steps, and how many tags it came from. No history leaves the tags as
#    they were, so the seeded history still means what the live tags mean.
#  User intention (Andrew, 2026-10-16):
#    "every model starts new each time it's run; the cockpit gives the history"
# ============================================================================
from __future__ import annotations

from warp2.decide.gate_features import HISTORY_TAGS, cockpit_tags, features


def test_no_history_leaves_the_tags_as_they_were():
    """Intention: a write with no slice is tagged exactly as before."""
    plain = features("build", "projects/a/x.py", "# h\nx = 1\n", 0.5)
    assert features("build", "projects/a/x.py", "# h\nx = 1\n", 0.5, history={}) == plain
    assert not any(t.startswith("kg") for t in plain)


def test_the_largest_shares_become_tags():
    """Intention: the few tags that brought most of the context, with their share in steps."""
    history = {f"t{i}": float(i + 1) for i in range(8)}
    total = sum(history.values())
    history = {k: v / total for k, v in history.items()}
    tags = features("build", "projects/a/x.py", "x = 1\n", 0.5, history=history)
    named = sorted(t for t in tags if t.startswith("kg:"))
    assert named == sorted(f"kg:t{i}" for i in range(8 - HISTORY_TAGS, 8))
    assert "kg_sources:8" in tags
    assert sum(t.startswith("kg_share:t7:") for t in tags) == 1


def test_empty_and_zero_shares_give_nothing():
    """Intention: a share of nothing is no history."""
    assert cockpit_tags(None) == {}
    assert cockpit_tags({"a": 0.0, "": 1.0}) == {}


def test_the_loop_reads_the_slice_the_doer_saw():
    """Intention: the loop hands over the same shares the helped record reads."""
    from warp2.work.loop import Loop
    sliced = {"items": [{"via": "a", "weight": 3.0}, {"via": "b", "weight": 1.0}, {"weight": 5.0}]}
    assert Loop._history_of(sliced) == {"a": 0.75, "b": 0.25}
    assert Loop._history_of(None) == {} and Loop._history_of({"items": []}) == {}
