# WARP2/warp2/decide/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/tests/__init__.py
#  Used by   : pytest (marks the decision-model tests as a package).
#  Uses      : nothing.
#  Description:
#    Package marker for the decision-model tests.
#  User intention (Andrew, 2026-09-18):
#    "a system to make and use action models that never use text."
# ============================================================================
