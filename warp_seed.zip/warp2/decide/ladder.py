# WARP2/warp2/decide/ladder.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/ladder.py
#  Used by   : warp2/ask/talk.py (the turn_kind decision),
#              warp2/work/loop.py (which model is asked to write).
#  Uses      : warp2/decide/decider.py (through what it is handed).
#  Description:
#    The three rungs of one decision, smallest first: an automation (a fixed
#    rule), an action model (a small learned model that never reads text),
#    and a bigger model. The smallest rung that answers AND has proven itself
#    decides; a bigger rung is asked only when the smaller ones cannot.
#    Whatever the bigger rung says is kept as what the smaller one is
#    measured against, so every time the big one is asked, the small one
#    gets closer to not needing it.
#  User intention (Andrew, 2026-09-18):
#    "The warp should continually trying to make everything automations, if
#    not action models, if not those bigger models. It should use the
#    smallest and simplest forms of what it has. Then the bigger things
#    should use the smaller things."
# ============================================================================
from __future__ import annotations

AUTOMATION = "automation"
ACTION_MODEL = "action model"
BIGGER = "bigger model"


class Ladder:
    """One decision, answered by the smallest rung that can.

    Intention: the ladder never decides how good a rung is by a setting. The
    action model is used only when its record says it is not worse than the
    bigger rung (Standing.takes_over), and only for a case it is at least as
    sure about as the bigger rung has been right. Below that, it steps aside.
    """

    def __init__(self, decider) -> None:
        """Intention: one decider is one decision point; the ladder is its use."""
        self.decider = decider
        self.open: dict = {}

    def climb(self, features: dict, automation: str | None = None) -> dict:
        """The smallest rung's answer, or a note that the bigger rung is needed.

        Intention: an automation that answers is used, and the action model
        is still asked beside it so it learns what the automation knows.
        Without one, the action model decides if it has earned it; otherwise
        the answer comes back with rung None, and the caller asks the bigger
        rung and hands its answer to `bigger_said`.
        """
        rule = {automation: 1.0} if automation in self.decider.choices else {}
        got = self.decider.ask(features, rule)
        self.open[got["id"]] = bool(rule)
        if rule:
            return {**got, "rung": AUTOMATION, "choice": automation}
        if got["takes_over"] and self._sure_enough(got):
            return {**got, "rung": ACTION_MODEL}
        return {**got, "rung": None}

    def bigger_said(self, row_id: str, choice: str) -> None:
        """Intention: the bigger rung's answer, kept until the outcome is known."""
        if row_id in self.open and not self.open[row_id] and choice in self.decider.choices:
            self.open[row_id] = {choice: 1.0}

    def settle(self, row_id: str, outcome: str) -> None:
        """Intention: what really happened; the action model learns from it."""
        if row_id not in self.open:
            return
        said = self.open.pop(row_id)
        self.decider.settle(row_id, outcome, rule=said if isinstance(said, dict) else None)

    def _sure_enough(self, got: dict) -> bool:
        """Intention: as sure of this case as the bigger rung has been right."""
        bigger_right = float(got["standing"].get("rule_right", 1.0))
        return max(got["probabilities"].values()) >= bigger_right
