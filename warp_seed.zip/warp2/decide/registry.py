# WARP2/warp2/decide/registry.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/registry.py
#  Used by   : warp2/decide/__init__.py, warp2/work/loop.py, warp2/run.py,
#              warp2/ask/window.py (handed to Talk).
#  Uses      : warp2/decide/decider.py, warp2/decide/gate_features.py (seeding).
#  Description:
#    Every decision point, made the first time it is asked for. A point that
#    has a way to learn from past runs is seeded from them once.
#  User intention (Andrew, 2026-09-12 / 2026-09-18):
#    The system should make its own model for a new task. A new kind of
#    decision gets its own model the moment it is first asked about.
# ============================================================================
from __future__ import annotations

from pathlib import Path

from warp2.decide.decider import Decider

# Intention: points that can learn from the record the machine already kept,
# and the function that turns that record into their ledger. Seeding runs
# once — when the point's ledger does not exist yet.
SEEDERS = {"gate_accepts": "warp2.decide.gate_features:seed"}


class Decisions:
    """The decision points of one machine."""

    def __init__(self, state) -> None:
        """Intention: made lazily; nothing is built until a point is asked for."""
        self.state = Path(state)
        self.points: dict = {}

    def get(self, point: str, choices) -> Decider:
        """Intention: the point's decider, made (and seeded) the first time."""
        if point not in self.points:
            seeder = SEEDERS.get(point)
            ledger_file = self.state / "decisions" / f"{point}.jsonl"
            if seeder and not ledger_file.is_file():
                module, name = seeder.split(":")
                import importlib
                getattr(importlib.import_module(module), name)(self.state)
            self.points[point] = Decider(self.state, point, choices)
        return self.points[point]

    def known(self) -> list:
        """Intention: every point that has a ledger, asked for this run or not."""
        home = self.state / "decisions"
        return sorted(p.stem for p in home.glob("*.jsonl")) if home.is_dir() else []
