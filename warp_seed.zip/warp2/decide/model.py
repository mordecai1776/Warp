# WARP2/warp2/decide/model.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/model.py
#  Used by   : warp2/decide/decider.py.
#  Uses      : projects/behemoth_eye/eye/warp_eye.py (EyeBook — the WARP's one
#              Eye; each decision is a part of it), projects/behemoth_eye/
#              pairs/fronts.py (VECTOR). Features go to the Eye as tag-tokens;
#              a proven action of the Eye (WarpEye.proven, act) decides.
#  Description:
#    The action model for one decision: a part of the WARP's one Eye whose
#    classes are the choices — named tags in, a probability per choice out.
#    No text anywhere.
#  User intention (Andrew, 2026-09-18):
#    "a system to make and use action models that never use text."
#    And 2026-09-19: "everywhere the eye trains or is use it should be replaced
#    for now in the warp"; then: "get the eye in place of the pop network in
#    all places where the master is the entire eye and all the rest are just
#    parts."
# ============================================================================
from __future__ import annotations


def _pair(point: str, choices, state=None, fresh: bool = True):
    """The decision's part of the WARP's Eye, or None when the Eye cannot be imported.

    Intention: nothing is substituted when it is missing — the decider then
    only records, and the rule keeps deciding. A formula wearing the model's
    name is the pretending the Weigher was written to end.
    """
    try:
        from projects.behemoth_eye.eye.warp_eye import EyeBook
        from projects.behemoth_eye.pairs.fronts import VECTOR
    except Exception:
        return None
    # Intention: FRESH — a decision is rebuilt from its ledger every time it
    # is made (decider.py: "the rebuilt model is the model"), so its part of
    # the Eye starts again and is taught the ledger in order. (2026-10-03)
    # With `fresh` False the part is kept as the saved Eye holds it, for a
    # decider that has checked the part was taught the ledger's first rows
    # (decider.py `replay`).
    return EyeBook(state).pair(f"decide: {point}", list(choices), VECTOR, fresh=bool(fresh))


class DecisionModel:
    """Probabilities over a fixed list of choices, learned from outcomes."""

    def __init__(self, point: str, choices, state=None, fresh: bool = True) -> None:
        """Intention: one pair for the whole decision; its classes are the choices.

        `state` is the folder whose Eye it is part of; live outcomes also
        teach the Eye as a whole.
        """
        self.point = str(point)
        self.choices = tuple(choices)
        self.pair = _pair(self.point, self.choices, state, fresh)
        self.state = state
        self.taught = 0

    def kept(self) -> dict:
        """Intention: what the decider wrote beside its part in the Eye (`mark`) — saved with the Eye, so it always says what the saved part was taught."""
        if not self.ready or not hasattr(self.pair, "warp"):
            return {}
        return dict(self.pair.warp.parts.get(self.pair.name, {}).get("replayed") or {})

    def mark(self, kept: dict) -> None:
        """Intention: write beside the part which ledger rows it has been taught, and the decider's counts that go with them."""
        if self.ready and hasattr(self.pair, "warp") and self.pair.name in self.pair.warp.parts:
            self.pair.warp.parts[self.pair.name]["replayed"] = dict(kept)

    @property
    def ready(self) -> bool:
        """Intention: whether there is a model here at all."""
        return self.pair is not None

    def probabilities(self, features: dict) -> dict:
        """One probability per choice, summing to one.

        Intention: the part's answer — each choice's concept in the Eye. An
        untaught model says every choice equally, because a fresh network's
        answers are its starting values, not knowledge.
        """
        acted = self._eye_acts(features)
        if acted is not None:
            return acted
        if not self.ready or not self.taught:
            return {c: 1.0 / len(self.choices) for c in self.choices}
        # Intention: tags are tokens — the features go to the Eye as
        # tag-tokens (each name on its own place), not hashed into a vector.
        return self.pair.read([dict(features)])[0]

    def _eye_acts(self, features: dict):
        """The Eye's own action for this decision, once it has proven it — or None.

        Intention: an action the Eye was given on a person's yes answers
        beside the WARP on every piece; once its answers have matched what
        the WARP did better than a constant guess would (WarpEye.proven),
        the Eye acts: the choice its action takes gets the share its answers
        have matched at, and the other choices share the rest. Before then,
        and wherever the Eye cannot be reached, the decision is the part's
        as it always was.
        """
        if self.state is None or not self.ready:
            return None
        try:
            from projects.behemoth_eye.eye.warp_eye import WarpEye
            warp = WarpEye.for_state(self.state)
        except Exception:
            return None
        names = {f"{self.pair.name}: {c}": c for c in self.choices}
        trace = warp.route(f"decision:{self.pair.name}", dict(features), list(names), allowed=list(names))
        chosen = trace["scores"]
        if not chosen:
            return None
        best = max(chosen, key=chosen.get)
        count = warp.answers[best]
        rate = count["same"] / count["times"]
        rest = (1.0 - rate) / max(len(self.choices) - 1, 1)
        return {c: (rate if n == best else rest) for n, c in names.items()}

    def compare_internal_model(self, features: dict, context: dict = None) -> dict | None:
        """Route this decision through `WarpEye.run_internal_model` and compare with its `EyePart` adapter."""
        if self.state is None or not self.ready:
            return None
        try:
            from projects.behemoth_eye.eye.warp_eye import WarpEye
            warp = WarpEye.for_state(self.state)
        except Exception:
            return None
        names = [f"{self.pair.name}: {c}" for c in self.choices]
        return warp.run_internal_model(dict(features), context=context, task=self.pair.name,
                                       actions=names, allowed=names)

    def learn(self, features: dict, outcome: str, live: bool = False) -> None:
        """The choice that turned out right is what the part is taught.

        Intention: `live` is a decision settled now, which the Eye as a whole
        also sees (the master is the entire Eye). A replay of the record is
        not live, so the whole Eye is not taught the same outcome again on
        every start. The Eye is saved by the WARP's Eye step, not per decision.
        """
        if not self.ready or outcome not in self.choices:
            return
        tags = [dict(features)]
        self.pair.learn(tags, [outcome])
        self.taught += 1
        if live and self.state is not None:
            from projects.behemoth_eye.eye.warp_eye import EyeBook
            from projects.behemoth_eye.pairs.fronts import VECTOR
            book = EyeBook(self.state)
            # Intention: what the WARP did, named with its part, so the Eye
            # can tell which of its answers keep being followed by it.
            book.pair(book.everything_name(VECTOR), [], VECTOR).learn(tags, [f"{self.pair.name}: {outcome}"])
