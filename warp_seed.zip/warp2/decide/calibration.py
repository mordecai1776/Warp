# WARP2/warp2/decide/calibration.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/calibration.py
#  Used by   : warp2/decide/decider.py.
#  Uses      : nothing outside the standard library.
#  Description:
#    What a model's probability has actually meant so far. Each raw answer
#    falls in one of ten bands; the band remembers how often it came true.
#    The calibrated answer leans on that record as it grows.
#  User intention (Andrew):
#    Everything scored must be trainable, with one universal confidence.
#    Measured 2026-09-18: WARP said it was 80-99% sure of 294 file writes and
#    47% were accepted. A confidence nobody checks against the record is a
#    guess with a number on it.
# ============================================================================
from __future__ import annotations

# Intention: how many observations the raw answer counts for inside a band.
# Three, the same prior the tag network uses: two lucky outcomes cannot
# overrule the model, and a real record soon does.
PRIOR = 3.0
BANDS = 10


class Calibration:
    """Raw probability in, what that probability has meant so far out."""

    def __init__(self) -> None:
        """Intention: per band, how often it was said and how often it came true."""
        self.said = [0] * BANDS
        self.true = [0] * BANDS

    @staticmethod
    def band(p: float) -> int:
        """Intention: 0.0-0.1 is band 0, ... 0.9-1.0 is band 9."""
        return min(BANDS - 1, max(0, int(float(p) * BANDS)))

    def __call__(self, p: float) -> float:
        """The calibrated probability.

        Intention: smooth — the raw answer counts as PRIOR observations, and
        every real outcome in its band outvotes it a little more.
        """
        b = self.band(p)
        return (self.true[b] + PRIOR * float(p)) / (self.said[b] + PRIOR)

    def learn(self, p: float, happened: bool) -> None:
        """Intention: one more outcome in the band that raw answer fell in."""
        b = self.band(p)
        self.said[b] += 1
        self.true[b] += 1 if happened else 0

    def table(self) -> list:
        """Intention: the reliability table a person reads: said vs came true."""
        return [{"band": f"{b / BANDS:.1f}-{(b + 1) / BANDS:.1f}", "said": self.said[b],
                 "came_true": round(self.true[b] / self.said[b], 3) if self.said[b] else None}
                for b in range(BANDS)]
