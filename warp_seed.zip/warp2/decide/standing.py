# WARP2/warp2/decide/standing.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/standing.py
#  Used by   : warp2/decide/decider.py.
#  Uses      : stdlib math.
#  Description:
#    Whether a decision model has earned its place: its probability is scored
#    against the rule it shadows on every decision, BEFORE it learned from
#    that decision, and it graduates only when it is better by more than its
#    own noise. (2026-10-24) It is also scored against the plainest guess —
#    how often each outcome has happened so far — as the drift candle, with a
#    running recent temperature, so a model that only beats a bad rule shows.
#  User intention (Andrew, 2026-09-12):
#    "It should only graduate when it can do the work." And: "if it promotes
#    something it should use it."
# ============================================================================
from __future__ import annotations

import math


class Standing:
    """The running comparison of model against rule, by Brier score.

    Intention: every decision is scored before the model sees its outcome, so
    the whole record is held-out data — nothing it trained on is ever used to
    judge it. Graduation is when the mean gain is more than two standard
    errors above nothing: no fixed count of trials, and a lucky streak on a
    handful of decisions does not pass.
    """

    def __init__(self) -> None:
        """Intention: count, sum and sum of squares of the gain; and both scores."""
        # Intention: and how often each side's top choice was the right one,
        # for the ladder's question "is the smaller one as good".
        self.model_hits = 0
        self.rule_hits = 0
        self.n = 0
        self.gain = 0.0
        self.gain_sq = 0.0
        self.model_brier = 0.0
        self.rule_brier = 0.0
        # Intention: (2026-10-24, BUILD_LOG 516) the base-rate candle. The rule
        # it shadows scored Brier 0.57 on the gate — worse than a coin — so
        # "better than the rule" proved little. These count each outcome seen
        # so far, and score the model against that plain frequency on the
        # same decisions, before either learns from it.
        self.base_seen = {}
        self.base_n = 0
        self.base_brier = 0.0
        self.base_model_brier = 0.0
        self.base_gain = 0.0
        self.base_gain_sq = 0.0
        self.recent_skill = 0.0

    def add(self, model_p: float, rule_p: float, happened: bool) -> None:
        """Intention: one decision. Gain is how much closer the model was than the rule."""
        y = 1.0 if happened else 0.0
        m, r = (model_p - y) ** 2, (rule_p - y) ** 2
        self.n += 1
        self.model_brier += m
        self.rule_brier += r
        self.gain += r - m
        self.gain_sq += (r - m) ** 2

    def against_base(self, outcome: str, model_p: float, choices: int) -> None:
        """One decision scored against how often its outcome has happened so far.

        Intention: the base guess is the outcome's past share (one added to
        each of the `choices`, so the first guess is even), taken BEFORE this
        outcome is counted — the same held-out order as `add`. `recent_skill`
        is a running mean of the gain that forgets old decisions (about the
        last twenty weigh most), so a model whose edge faded shows it now,
        not only in the all-time sum.
        """
        k = max(2, int(choices))
        base_p = (self.base_seen.get(outcome, 0) + 1.0) / (self.base_n + k)
        m, b = (model_p - 1.0) ** 2, (base_p - 1.0) ** 2
        self.base_n += 1
        self.base_seen[outcome] = self.base_seen.get(outcome, 0) + 1
        self.base_brier += b
        self.base_model_brier += m
        self.base_gain += b - m
        self.base_gain_sq += (b - m) ** 2
        self.recent_skill += 0.05 * ((b - m) - self.recent_skill)

    def beats_base(self) -> bool:
        """Intention: better than the plain frequency by more than two standard errors."""
        if self.base_n < 2:
            return False
        mean = self.base_gain / self.base_n
        var = max(0.0, self.base_gain_sq / self.base_n - mean * mean) * self.base_n / (self.base_n - 1)
        return mean > 0 and mean > 2.0 * math.sqrt(var / self.base_n)

    def hit(self, model_right: bool, rule_right: bool) -> None:
        """Intention: one more decision where each side's top choice was right or not."""
        self.model_hits += 1 if model_right else 0
        self.rule_hits += 1 if rule_right else 0

    def takes_over(self) -> bool:
        """Whether the smaller model is proven AS GOOD AS the bigger thing it shadows.

        Intention: Andrew, 2026-09-18 — "use the smallest and simplest forms
        of what it has." A smaller rung takes over when the low end of its
        accuracy (two standard errors down, Wilson) still reaches the bigger
        rung's measured accuracy. It does not have to be better, only proven
        not worse; a few lucky decisions cannot pass, because the low end
        rises only as the record grows.
        """
        if self.n < 1:
            return False
        z, n = 2.0, float(self.n)
        p = self.model_hits / n
        low = (p + z * z / (2 * n) - z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / (1 + z * z / n)
        return low >= self.rule_hits / n

    def graduated(self) -> bool:
        """Intention: better than the rule by more than two standard errors."""
        if self.n < 2:
            return False
        mean = self.gain / self.n
        var = max(0.0, self.gain_sq / self.n - mean * mean) * self.n / (self.n - 1)
        return mean > 0 and mean > 2.0 * math.sqrt(var / self.n)

    def says(self) -> dict:
        """Intention: the numbers a person reads."""
        if not self.n and not self.base_n:
            return {"decisions": 0, "graduated": False}
        if not self.n:
            return {"decisions": 0, "graduated": False, **self._base_says()}
        return {**self._base_says(), "decisions": self.n, "model_brier": round(self.model_brier / self.n, 4),
                "rule_brier": round(self.rule_brier / self.n, 4), "graduated": self.graduated(),
                "model_right": round(self.model_hits / self.n, 3),
                "rule_right": round(self.rule_hits / self.n, 3), "takes_over": self.takes_over()}

    def _base_says(self) -> dict:
        """Intention: the base-rate candle's numbers, only once it has scored something."""
        if not self.base_n:
            return {}
        return {"base_decisions": self.base_n,
                "base_brier": round(self.base_brier / self.base_n, 4),
                "model_brier_on_base_rows": round(self.base_model_brier / self.base_n, 4),
                "beats_base": self.beats_base(), "recent_skill": round(self.recent_skill, 4)}
