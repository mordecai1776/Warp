# WARP2/warp2/decide/gate_features.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/decide/gate_features.py
#  Used by   : warp2/work/loop.py (put_down: the tags for "will the gate accept
#              this file"; and `before_writing` to rank who writes, both
#              with the case's cockpit history),
#              warp2/decide/registry.py (seed, once).
#  Uses      : warp2/decide/ledger.py, warp2/store/problem_web.py (what kind
#              of problem the last refusal was), stdlib ast/json. Live, the
#              cockpit's narrowed KG view arrives from warp2/work/loop.py.
#  Description:
#    The tags that describe one file about to be written — what kind of work,
#    which project and folder, the shape of the code, how sure the old score
#    was, how often this file was refused before and for what — built the
#    same way live and from the journal, so the history the model is seeded
#    with means what the live tags mean.
#  User intention (Andrew, 2026-09-18):
#    First decision model: "will the gate accept this?" Measured that day:
#    WARP scored 294 writes at 800-999 out of 1000 and 47% were accepted.
# ============================================================================
from __future__ import annotations

import ast
import json
import posixpath
import uuid
from pathlib import Path

POINT = "gate_accepts"
CHOICES = ("accept", "refuse")


def _step(value: float, steps: int = 10) -> str:
    """Intention: a number as one of a few names, the Weigher's own reading."""
    return f"{max(0, min(steps, int(round(float(value) * steps))))}of{steps}"


def features(kind: str, target: str, content: str, said_sure: float,
             refused_before: int = 0, last_problem: str = "", model: str = "",
             history: dict | None = None) -> dict:
    """The tags for one file about to be written.

    Intention: `history` is the cockpit's narrowed KG view for this case, as
    each tag's share of the context it brought (warp2/store/helped.py
    shares_of) — Andrew, 2026-10-16: "every model starts new each time it's
    run; the cockpit gives the history". With none, the tags are as before.
    """
    target = str(target).replace("\\", "/")
    parts = target.split("/")
    try:
        tree = ast.parse(content or "")
        parses = True
    except SyntaxError:
        tree, parses = None, False
    defs = sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
               for n in ast.walk(tree)) if tree is not None else 0
    imports = sum(isinstance(n, (ast.Import, ast.ImportFrom)) for n in ast.walk(tree)) if tree is not None else 0
    tags = {
        f"kind:{kind or 'none'}": 1.0,
        f"project:{parts[1] if len(parts) > 2 and parts[0] == 'projects' else parts[0]}": 1.0,
        f"folder:{posixpath.dirname(target) or 'none'}": 1.0,
        f"parses:{'yes' if parses else 'no'}": 1.0,
        f"header:{'yes' if (content or '').lstrip().startswith('#') else 'no'}": 1.0,
        f"size:{_step(min(1.0, len(content or '') / 20000.0))}": 1.0,
        f"defs:{_step(min(1.0, defs / 20.0))}": 1.0,
        f"imports:{_step(min(1.0, imports / 15.0))}": 1.0,
        f"said_sure:{_step(said_sure)}": 1.0,
        f"refused_before:{min(int(refused_before), 3)}": 1.0,
        f"last_problem:{last_problem or 'none'}": 1.0,
    }
    if model:
        tags[f"model:{model}"] = 1.0
    tags.update(cockpit_tags(history))
    return tags


HISTORY_TAGS = 5


def cockpit_tags(history: dict | None) -> dict:
    """The case's history from the cockpit, as a few tags.

    Intention: the tags that brought the most of this case's context, each as
    "kg:<tag>" with its share named in steps (the Weigher's own reading), and
    how many tags the context came from. Kept to the few largest so the
    decision reads the case, not every word of the graph. No history, no tags.
    """
    shares = {str(k): float(v) for k, v in (history or {}).items() if str(k) and float(v or 0) > 0}
    if not shares:
        return {}
    top = sorted(shares.items(), key=lambda kv: (-kv[1], kv[0]))[:HISTORY_TAGS]
    tags = {f"kg:{name}": 1.0 for name, _ in top}
    tags.update({f"kg_share:{name}:{_step(share, 4)}": 1.0 for name, share in top})
    tags[f"kg_sources:{min(len(shares), 10)}"] = 1.0
    return tags


def before_writing(kind: str, target: str, model: str,
                   history: dict | None = None) -> dict:
    """The tags known before any file is written: the work, where, who, and
    the case's history from the cockpit.

    Intention: used to ask which model is likeliest to be accepted, before
    one is asked to write. Tags that need the content are left out rather
    than guessed, so no model is ranked on a file that does not exist yet.
    The history is the same narrowed KG view the doer is shown (Andrew,
    2026-10-16: "the cockpit gives the history"); with none, the tags are as
    before, and they match what features() adds for the same case.
    """
    target = str(target).replace("\\", "/")
    parts = target.split("/")
    tags = {f"kind:{kind or 'none'}": 1.0,
            f"project:{parts[1] if len(parts) > 2 and parts[0] == 'projects' else parts[0]}": 1.0,
            f"folder:{posixpath.dirname(target) or 'none'}": 1.0,
            f"model:{model}": 1.0}
    tags.update(cockpit_tags(history))
    return tags


def _classifier():
    """Intention: one problem web for many complaints; none if it cannot load."""
    try:
        from warp2.store.problem_web import ProblemWeb
        web = ProblemWeb()
        return lambda text: web.classify(text).get("node_id", "") if text else ""
    except Exception:
        return lambda text: ""


def seed(state) -> int:
    """Teach the new decision point from every file write the journals hold.

    Intention: the machine already wrote down every write, what it was, how
    sure it said it was, and whether the gate took it. That IS the record the
    model should start from — Andrew, 2026-09-13: trained "on all of the times
    that anything has tried". Run once, when the point has no ledger yet.
    """
    from warp2.decide.ledger import DecisionLedger
    home = Path(state) / "journals"
    files = sorted(home.glob("*.jsonl")) + sorted((home / "archive").glob("*.jsonl"))
    rows = []
    for path in files:
        try:
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
                try:
                    entry = json.loads(line)
                except ValueError:
                    continue
                if entry.get("verb") == "write_file" and entry.get("outcome") in ("ok", "refused"):
                    rows.append(entry)
        except OSError:
            continue
    rows.sort(key=lambda e: str(e.get("ts") or ""))
    ledger, classify = DecisionLedger(state, POINT), _classifier()
    refused, last = {}, {}
    for entry in rows:
        target = str(entry.get("target") or "")
        sure = max(0.0, min(1.0, float(entry.get("score") or 0) / 1000.0))
        tags = features(str(entry.get("work_kind") or ""), target, str(entry.get("content") or ""),
                        sure, refused.get(target, 0), last.get(target, ""))
        row_id = uuid.uuid4().hex[:16]
        ledger.asked(row_id, tags, {"accept": sure, "refuse": 1.0 - sure}, {"seeded": True})
        ok = entry.get("outcome") == "ok"
        ledger.settled(row_id, "accept" if ok else "refuse")
        if not ok:
            refused[target] = refused.get(target, 0) + 1
            last[target] = classify(str(entry.get("error") or ""))
    return len(rows)
