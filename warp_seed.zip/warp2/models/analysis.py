# WARP2/warp2/models/analysis.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/models/analysis.py
#  Used by   : warp2/train/ (targeted remediation), warp2/models/fleet.py;
#              the observer GUI and the loop.
#  Uses      : warp2/store/store.py (receipts and facts), warp2/util.py; the
#              training_round facts warp2/train/runner.py writes.
#  Description:
#    Model Analysis: behavioral fingerprinting, performance inflection point
#    detection, causal attribution to training events, and prescriptive
#    remediation paths.
#  User intention (Andrew, 2026-09-15):
#    "Model analsis. We have enough data to clasify models in a number of
#    ways from their actions and define points where they change and trace
#    back that change to the training of individual things. This will go with
#    the weighting of training to define what a model lacks and give some path
#    through previous action to get there or at least a educated guess of
#    sorts."
# ============================================================================
from __future__ import annotations

import json
from typing import Any
from warp2.util import now_iso


class ModelFingerprint:
    """Empirical competence card computed from actual execution receipts.

    Intention: classifies a model's strengths, syntax pass rates, gate
    compliance, and signature failure patterns from production evidence.
    """

    def __init__(self, model: str, total_trials: int = 0,
                 success_rate: float = 0.0, syntax_rate: float = 0.0,
                 gate_pass_rate: float = 0.0,
                 signature_flaws: list[str] | None = None):
        """Intention: keep one model's trial count, pass rates and common flaws."""
        self.model = str(model).strip()
        self.total_trials = int(total_trials)
        self.success_rate = float(success_rate)
        self.syntax_rate = float(syntax_rate)
        self.gate_pass_rate = float(gate_pass_rate)
        self.signature_flaws = list(signature_flaws or [])

    def as_dict(self) -> dict[str, Any]:
        """Dictionary representation of the fingerprint."""
        return {
            "model": self.model,
            "total_trials": self.total_trials,
            "success_rate": round(self.success_rate, 3),
            "syntax_rate": round(self.syntax_rate, 3),
            "gate_pass_rate": round(self.gate_pass_rate, 3),
            "signature_flaws": list(self.signature_flaws),
        }

    def __repr__(self) -> str:
        """Intention: a short readable form for logs and debugging."""
        return f"<ModelFingerprint {self.model} trials={self.total_trials} success={self.success_rate:.1%}>"


class InflectionPoint:
    """A detected step-change in model capability over time.

    Intention: captures the exact point where a model shifted from failing
    to passing (or regressing) on a capability.
    """

    def __init__(self, model: str, timestamp: str, metric: str,
                 before_rate: float, after_rate: float,
                 training_event: dict[str, Any] | None = None):
        """Intention: keep one change in a model's rate, before and after, and the training event linked to it."""
        self.model = str(model).strip()
        self.timestamp = str(timestamp)
        self.metric = str(metric)
        self.before_rate = float(before_rate)
        self.after_rate = float(after_rate)
        self.delta = round(self.after_rate - self.before_rate, 3)
        self.training_event = dict(training_event or {})

    def as_dict(self) -> dict[str, Any]:
        """Dictionary representation of the inflection point."""
        return {
            "model": self.model,
            "timestamp": self.timestamp,
            "metric": self.metric,
            "before_rate": round(self.before_rate, 3),
            "after_rate": round(self.after_rate, 3),
            "delta": self.delta,
            "training_event": dict(self.training_event),
        }

    def __repr__(self) -> str:
        """Intention: a short readable form for logs and debugging."""
        sign = "+" if self.delta >= 0 else ""
        return f"<InflectionPoint {self.model} {self.metric} {sign}{self.delta:.1%} at {self.timestamp}>"


class ModelAnalyzer:
    """Diagnostic and causal attribution engine for model fleet.

    Intention: classifies models, pinpoints inflection points, traces them
    back to training rounds, and prescribes remediation training batches.
    """

    def __init__(self, store: Any = None):
        """Intention: keep the store, and an in-memory trial list used when there is no store."""
        self.store = store
        self._memory_trials: dict[str, list[dict[str, Any]]] = {}

    def record_trial(self, model: str, outcome: str, syntax_ok: bool = True,
                     gate_accepted: bool = True, failure_type: str = "",
                     task_kind: str = "code", score: float = 1.0,
                     details: dict[str, Any] | None = None) -> str:
        """Store one evaluation receipt fact in the append-only store."""
        import uuid
        trial_id = f"trial_{now_iso().replace(':', '_')}_{uuid.uuid4().hex[:8]}"
        payload = {
            "model": model,
            "outcome": outcome,
            "syntax_error": not syntax_ok,
            "gate_accepted": gate_accepted,
            "failure_type": failure_type,
            "task_kind": task_kind,
            "score": score,
            "details": details or {},
            "ts": now_iso(),
        }
        self._memory_trials.setdefault(model, []).append(payload)
        if self.store is not None:
            return self.store.assert_fact(
                subject=f"eval:{model}",
                relation="supports",
                obj=f"trial:{trial_id}",
                value=json.dumps(payload),
            )
        return trial_id

    def fingerprint(self, model: str, receipts: list[dict[str, Any]] | None = None) -> ModelFingerprint:
        """Derive an empirical competence fingerprint for a model.

        Intention: extracts concrete pass rates and signature flaws from receipts.
        """
        records = receipts
        if records is None and self.store is not None:
            records = []
            for fact in self.store.current(subject=f"eval:{model}"):
                val = fact.get("value")
                if isinstance(val, str):
                    try:
                        val = json.loads(val)
                    except Exception:
                        val = {}
                if isinstance(val, dict):
                    records.append(val)
        elif records is None:
            records = list(self._memory_trials.get(model, []))

        if not records:
            return ModelFingerprint(model=model)

        total = len(records)
        ok_count = sum(1 for r in records if r.get("outcome") in ("ok", "passed", "pass"))
        syntax_ok = sum(1 for r in records if not r.get("syntax_error"))
        gate_ok = sum(1 for r in records if r.get("gate_accepted") or r.get("outcome") == "ok")

        flaw_counts: dict[str, int] = {}
        for r in records:
            flaw = r.get("failure_type") or r.get("error_kind")
            if flaw and r.get("outcome") not in ("ok", "passed", "pass"):
                flaw_counts[str(flaw)] = flaw_counts.get(str(flaw), 0) + 1

        # Signature flaws: flaws occurring in at least 15% of failures
        signature = [f for f, count in sorted(flaw_counts.items(), key=lambda x: -x[1]) if count >= 1]

        return ModelFingerprint(
            model=model,
            total_trials=total,
            success_rate=ok_count / total if total else 0.0,
            syntax_rate=syntax_ok / total if total else 0.0,
            gate_pass_rate=gate_ok / total if total else 0.0,
            signature_flaws=signature[:5],
        )

    def detect_inflections(self, model: str, records: list[dict[str, Any]],
                           window_size: int = 5, min_delta: float = 0.25) -> list[InflectionPoint]:
        """Detect sudden capability shifts in chronological records.

        Intention: finds when a model jumped or dropped significantly on a metric.
        """
        if len(records) < window_size * 2:
            return []

        # Sort chronologically
        sorted_records = sorted(records, key=lambda r: str(r.get("ts", "")))
        inflections: list[InflectionPoint] = []

        for i in range(window_size, len(sorted_records) - window_size + 1):
            before_window = sorted_records[i - window_size:i]
            after_window = sorted_records[i:i + window_size]

            before_ok = sum(1 for r in before_window if r.get("outcome") in ("ok", "passed", "pass"))
            after_ok = sum(1 for r in after_window if r.get("outcome") in ("ok", "passed", "pass"))

            before_rate = before_ok / window_size
            after_rate = after_ok / window_size
            delta = after_rate - before_rate

            if abs(delta) >= min_delta:
                ts = sorted_records[i].get("ts", now_iso())
                inflection = InflectionPoint(
                    model=model,
                    timestamp=ts,
                    metric="task_success",
                    before_rate=before_rate,
                    after_rate=after_rate,
                )
                if self.store is not None:
                    inflection.training_event = self.trace_to_training(inflection)
                inflections.append(inflection)
                break  # Record primary inflection in this sequence

        return inflections

    def trace_to_training(self, inflection: InflectionPoint) -> dict[str, Any]:
        """Trace an inflection point back to the training round that caused it.

        Intention: links behavioral step-changes to specific checkpoint promotions.
        """
        if self.store is None:
            return {"training_round": "unknown", "reason": "no store connected"}

        # Intention: READ WHAT THE TRAINER WRITES. This asked for a
        # `checkpoint` attribute that nothing in the tree ever wrote, so every
        # inflection read "unrecorded" (found 2026-09-18 by listing attributes
        # that are read and never written). The trainer writes one subject per
        # round — `training_round:<skill>:<n>` — with its `model`, `promotion`
        # and `at` (warp2/train/runner.py `note_round`). The latest round
        # before the change wins, this model's own first.
        candidate_round, same_model = None, False
        for fact in self.store.current(relation="has", attr="round"):
            subject = str(fact.get("subject") or "")
            when = str(fact.get("valid_from", ""))
            if not subject.startswith("training_round:") or when > inflection.timestamp:
                continue
            model = self._value_of(subject, "model")
            mine = bool(model) and model == inflection.model
            if candidate_round and (same_model and not mine):
                continue
            if candidate_round and mine == same_model and when <= candidate_round["trained_at"]:
                continue
            candidate_round, same_model = {
                "training_round": subject,
                "checkpoint": self._value_of(subject, "promotion"),
                "trained_at": when,
                "trained_model": model,
                "target_model": inflection.model,
                "causal_link": "preceded_inflection",
            }, mine

        # Intention: a checkpoint stated outright (`checkpoint` on a `train:`
        # subject) still counts, when no round was written — the older shape.
        if candidate_round is None:
            for fact in self.store.current(relation="has", attr="checkpoint"):
                when = str(fact.get("valid_from", ""))
                if when <= inflection.timestamp and (
                        candidate_round is None or when > candidate_round["trained_at"]):
                    candidate_round = {"training_round": str(fact.get("subject") or ""),
                                       "checkpoint": fact.get("value"), "trained_at": when,
                                       "target_model": inflection.model,
                                       "causal_link": "preceded_inflection"}

        return candidate_round or {
            "training_round": "unrecorded",
            "reason": "no training round preceded inflection",
        }

    def _value_of(self, subject: str, attr: str) -> str:
        """Intention: one recorded value of a training round, or ""."""
        facts = self.store.current(subject=subject, attr=attr)
        return str(facts[0].get("value") or "") if facts else ""

    def prescribe_remediation(self, model: str,
                              fingerprint: ModelFingerprint | None = None) -> list[dict[str, Any]]:
        """Prescribe a targeted training path based on model flaws.

        Intention: calculates the exact remediation batch needed to patch
        flaws rather than repeating untargeted whole-corpus training.
        """
        fp = fingerprint or self.fingerprint(model)
        prescriptions: list[dict[str, Any]] = []

        from warp2.store.problem_web import ProblemWeb
        web = ProblemWeb(store=self.store)

        for flaw in fp.signature_flaws:
            classification = web.classify(flaw)
            batch = classification.get("remediation_batch") or f"batch:targeted_{flaw}"
            severity = classification.get("severity", "medium")
            multiplier = 2.0 if severity == "critical" else 1.8 if severity == "high" else 1.2
            prescriptions.append({
                "flaw": flaw,
                "problem_node": classification.get("node_id"),
                "problem_path": classification.get("path"),
                "prescribed_batch": batch,
                "focus": classification.get("description") or f"remediation of {flaw} via near-miss mistake replay",
                "severity": severity,
                "weight_multiplier": multiplier,
                "target_model": model,
            })

        if not prescriptions:
            prescriptions.append({
                "flaw": "none",
                "prescribed_batch": "batch:general_maintenance",
                "focus": "general replay buffer maintenance to prevent drift",
                "weight_multiplier": 1.0,
                "target_model": model,
            })

        return prescriptions
