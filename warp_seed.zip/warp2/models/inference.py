# WARP2/warp2/models/inference.py
# Pathway   : WARP2/warp2/models/inference.py
# Used by   : models/roster.py through the watched command backend;
#             models/backends.py reads its ABSENT exit code.
# Uses      : models/backends.py, models/airllm.py, models/still_here.py,
#             models/yes_no.py (--chance: a yes/no answer read from token chances),
#             room/ollama_room.py (room made for the model first - BUILD_LOG 1481);
#             stdlib JSON and argparse.
# Description: Model loading and generation in an interruptible child process.
# User intention (Andrew): model work cannot hold the entire warp or outrun ALL_STOP.
#   2026-11-09 17:45: "adapt this to ... all of the models with a splitting the way air llm does" - an Ollama model
#   is loaded only when the room has space for it, and kept after only while it still has (BUILD_LOG 1481).
from __future__ import annotations

import argparse
import contextlib
import json
import sys

# Intention: THE EXIT CODE FOR "THE MODEL'S SERVER IS NOT THERE". A refused
# connection means nobody was asked, which is a different fact from a model
# that answered badly or too slowly, and the parent can only tell them apart
# if this process says so in a way that is not a sentence to parse. Read by
# warp2/models/backends.py `command_model`.
ABSENT = 3


def main() -> int:
    """Load and ask one model under the parent's deadline and stop ownership."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", required=True)
    parser.add_argument("--name", default="")
    parser.add_argument("--how", default="direct")
    parser.add_argument("--tokens", type=int, default=1024)
    parser.add_argument("--adapter", default="")
    # Intention: the model's own window, from its roster entry, not one number for all.
    parser.add_argument("--ctx", type=int, default=0)
    # Intention: how often to say "still here" (the parent's beat pace).
    parser.add_argument("--beat", type=float, default=0.0)
    # Intention (item f, 2026-10-17): ask a yes/no question and answer with the
    # chance of "yes" read from the token chances, not with text to parse.
    parser.add_argument("--chance", action="store_true")
    args = parser.parse_args()
    try:
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # Intention: a stdin that cannot be reconfigured is read as it is; nothing is lost.
        pass
    prompt = sys.stdin.read()
    # Stdout carries one JSON envelope. Library diagnostics may use stderr.
    # Intention: NO CLOCK ON THE ANSWER, A CHECK THAT IT IS STILL RUNNING
    # (Andrew, 2026-09-24). While the model works this says "still here" on
    # stderr; the parent ends this child only when those lines stop.
    from warp2.models.still_here import StillHere, server_answers
    beat = args.beat if args.beat > 0 else 2.0
    alive = server_answers(args.path, beat) if args.how == "ollama" else None
    still = StillHere(beat, alive=alive).start()
    try:
        with contextlib.redirect_stdout(sys.stderr):
            text = _answer(args, prompt)
    except _Absent as exc:
        print(f"model server not there: {exc}", file=sys.stderr)
        return ABSENT
    finally:
        still.stop()
    print("WARP2_ANSWER=" + json.dumps(text, ensure_ascii=True), flush=True)
    return 0


class _Absent(Exception):
    """Intention: the model's server refused the connection — nobody was asked."""


def _answer(args, prompt: str) -> str:
    """The model's answer, however it is reached."""
    if args.how == "ollama":
        return _ollama_chance(args, prompt) if getattr(args, "chance", False) else _ollama(args, prompt)
    if getattr(args, "chance", False):
        # Intention: only Ollama gives token chances here; None says "use the text path".
        return json.dumps({"chance": None, "said": ""})
    if args.how == "airllm":
        return _airllm(args, prompt)
    from warp2.models.backends import direct_model
    # Intention: watched — this child beats (still_here.py) and its parent ends it only on silence.
    return direct_model(args.path, args.name, max_tokens=args.tokens, adapter_path=args.adapter,
                        watched=True)(prompt)


def _ollama(args, prompt: str) -> str:
    """Ask Ollama and read its answer as it streams in."""
    options = {"num_predict": args.tokens, "temperature": 0.1}
    if args.ctx > 0:
        options["num_ctx"] = args.ctx
    pieces, _ = _ollama_stream(args, prompt, options, {})
    return "".join(pieces)


def _ollama_chance(args, prompt: str) -> str:
    """A yes/no question to Ollama, answered as {"chance", "said"} in JSON text.

    Intention (item f, 2026-10-17): a few tokens only, at temperature 0, with
    the token chances asked for; the chance of "yes" is read from them
    (warp2/models/yes_no.py). None when the service gave no token chances.
    """
    from warp2.models.yes_no import chance
    options = {"num_predict": 4, "temperature": 0}
    if args.ctx > 0:
        options["num_ctx"] = args.ctx
    pieces, logprobs = _ollama_stream(args, prompt, options, {"logprobs": True, "top_logprobs": 10})
    return json.dumps({"chance": chance(logprobs), "said": "".join(pieces)})


def _ollama_stream(args, prompt: str, options: dict, extra: dict) -> tuple:
    """The answer's pieces and its token chances, read as Ollama streams them.

    Intention: streamed, with no socket clock. A big model loading onto the
    card, or a long answer being written, takes as long as it takes; whether
    Ollama is still there is the beat's question, not a timeout's.
    """
    import urllib.error
    import urllib.request
    from warp2.room.ollama_room import OllamaRoom
    keep = OllamaRoom().make_room_for(args.name)["keep_alive"]
    request = urllib.request.Request(args.path, headers={"Content-Type": "application/json"},
        data=json.dumps({"model": args.name, "stream": True, "think": False,
            "messages": [{"role": "user", "content": prompt}],
            "options": options, **({} if keep is None else {"keep_alive": keep}), **extra}).encode("utf-8"))
    try:
        response = urllib.request.urlopen(request)
    except urllib.error.URLError as exc:
        # Intention: refused or unresolvable — the server is not running.
        if isinstance(exc.reason, (ConnectionError, OSError)) and not isinstance(
                exc.reason, TimeoutError):
            raise _Absent(str(exc.reason)) from exc
        raise
    pieces, logprobs = [], []
    with response:
        for raw in response:
            if not raw.strip():
                continue
            chunk = json.loads(raw)
            if chunk.get("error"):
                raise RuntimeError(chunk["error"])
            pieces.append((chunk.get("message") or {}).get("content", ""))
            logprobs.extend(chunk.get("logprobs") or [])
            if chunk.get("done"):
                break
    return pieces, logprobs


def _airllm(args, prompt: str) -> str:
    """Intention: the low-memory engine, loaded and asked once."""
    from warp2.models.airllm import AirLLMEngine
    engine = AirLLMEngine(args.path)
    loaded = engine.load()
    if loaded["status"] != "ready":
        raise RuntimeError(str(loaded))
    answer = engine.generate(prompt, max_tokens=args.tokens)
    if answer["status"] != "ok":
        raise RuntimeError(str(answer))
    return answer["output"]


if __name__ == "__main__":
    raise SystemExit(main())
