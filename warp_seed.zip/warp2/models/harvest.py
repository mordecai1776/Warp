# WARP2/warp2/models/harvest.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/models/harvest.py
#  Used by   : warp2/run.py (`harvest`). NOT by a trainer — there is no trainer
#              here, and this file is the reason.
#  Uses      : warp2/store/store.py, warp2/store/formed.py (the served size),
#              warp2/util.py, warp2/settings.py.
#  Description:
#    What there is to learn from, and whether there is enough of it. It gathers
#    proven work into examples and REFUSES to produce a dataset when what it
#    found would teach the wrong thing.
#  User intention (Andrew):
#    The models are on his machine and they should get better at the work by
#    doing it.
#  WHY THERE IS NO TRAINER HERE. WARP trained extensively — 2.0 GB of LoRA
#    adapters across three models, up to epoch 107, one preserved as
#    `build.diverged_20260814`. It trained them on 402 rows that were **82%
#    examples of failing**, with **20 rows out of 402** actually bound to a
#    verified artifact, and its final harvest recorded `{"failed": 132,
#    "passed": 1}` while marking four skills "ready". And it trained on prompts
#    averaging 164 characters to serve inputs averaging 74,000 — a 450x
#    mismatch nothing ever measured. Fine-tuning is commodity machinery; the
#    scarce thing is proven work. So this file measures the scarce thing and
#    says no, which is what would have stopped every one of those runs.
# ============================================================================
from __future__ import annotations

from warp2.settings import fraction, number
from warp2.store.formed import BUDGET
from warp2.util import now_iso

# The least share of what a dataset teaches the model to copy that must be of
# work that PASSED before the dataset is worth making. WARP's was 17.9% — a faithful mirror of its gate's 15.8%
# acceptance — and at that share a model learns what this gate rejects rather
# than what good work looks like.
LEAST_POSITIVE = fraction("WARP2_HARVEST_LEAST_POSITIVE", 0.5, minimum=0.01)

# And the fewest proven examples there is any point in having. Twenty is what
# WARP had; it is not a training set.
LEAST_PROVEN = number("WARP2_HARVEST_LEAST_PROVEN", 50, minimum=1)

# How far the prompt a model is trained on may sit from the input it is served
# before the two are not about the same task. Four times, either way.
SAME_TASK_WITHIN = fraction("WARP2_HARVEST_SAME_TASK_WITHIN", 4.0, minimum=1.0)

PROVEN = "proven"
ATTEMPTED = "attempted"


class Harvest:
    """What there is to learn from — and, so far, why there is not enough."""

    def __init__(self, store, served: int = 0) -> None:
        """Intention: `served` is what the loop actually hands a model, so the
        train/serve comparison is against a real number from this tree rather
        than against a constant somebody wrote down once."""
        self.store = store
        self.served = int(served)

    def gather(self) -> dict:
        """Everything the record can offer as an example, sorted by what it is.

        Intention: PROVEN MEANS HASH-BOUND, and nothing else counts as proven.
        `verified_bytes` names which bytes passed which test, so an example is
        either tied to a receipt anyone can re-check or it is an attempt. WARP
        called 402 rows a training set when 20 of them were tied to anything.
        """
        proven, attempted = [], []
        for fact in self.store.current(attr="verified_bytes"):
            artifact = fact["subject"]
            proven.append({
                "artifact": artifact, "kind": PROVEN,
                "proves": str(fact["value"]),
                "by": self._text(artifact, "verified_by"),
                "at": self._text(artifact, "verified_at"),
                "asked": self._asked(artifact),
            })
        done_subjects = {s["subject"] for s in self.store.current(attr="state")
                         if s.get("value") == "done"}
        for fact in self.store.current(attr="outcome_note"):
            if fact["subject"] in done_subjects:
                continue
            attempted.append({"artifact": fact["subject"], "kind": ATTEMPTED,
                              "said": str(fact["value"]),
                              "asked": self._asked(fact["subject"])})
        return {"proven": proven, "attempted": attempted}

    def weigh(self, taught_attempts: int = 0) -> dict:
        """Whether what is there is worth training on — and it usually is not.

        Intention: THE HARVEST MUST BE ABLE TO REFUSE. WARP's marked four
        skills "ready" on the day it harvested one passing example, because
        ready meant "has some rows". A harvest that cannot say *there is not
        enough here* is one that will always say yes, and 2.0 GB of adapters is
        what that costs.
        """
        found = self.gather()
        proven, attempted = found["proven"], found["attempted"]
        total = len(proven) + len(attempted)
        share = (len(proven) / total) if total else 0.0
        # Intention: THE SHARE THAT MATTERS IS OF WHAT THE MODEL IS TAUGHT TO
        # COPY, not of everything ever tried (Andrew, 2026-09-24: "train on the
        # accepted ones, weighted"). WARP's harm was failures taught AS GOOD
        # WORK. The dataset here is built from proven work only
        # (warp2/train/dataset.py `_verified_examples`), each weighted by the
        # refinery, so refused attempts are never in it — they stay what the
        # gate tells the model on its next try. Asking the share of ALL work
        # blocked every round while 36% passed: the model could not improve
        # until it improved. `taught_attempts` is how many unproven rows a
        # dataset WOULD copy; the rule still bites the moment that is not 0.
        taught = len(proven) + max(0, int(taught_attempts))
        taught_share = (len(proven) / taught) if taught else 0.0

        reasons = []
        if len(proven) < int(LEAST_PROVEN):
            reasons.append(f"only {len(proven)} proven example(s); "
                           f"{int(LEAST_PROVEN)} is the fewest worth having")
        if taught and taught_share < float(LEAST_POSITIVE):
            reasons.append(f"{taught_share:.1%} of what it would copy passed — under "
                           f"{float(LEAST_POSITIVE):.0%} a model learns what "
                           f"this gate rejects, not what good work looks like")
        sizes = self.sizes(proven)
        if sizes["gap"] and sizes["gap"] > float(SAME_TASK_WITHIN):
            reasons.append(f"the examples average {sizes['harvested']} characters "
                           f"and the loop serves {sizes['served']} — {sizes['gap']}x "
                           f"apart, so they are not about the same task")

        return {
            "proven": len(proven), "attempted": len(attempted), "total": total,
            "share_proven": round(share, 4), "share_taught": round(taught_share, 4),
            "sizes": sizes,
            "enough": not reasons, "because": reasons, "at": now_iso(),
            "says": ("there is enough proven work here to learn from"
                     if not reasons else
                     "NOT ENOUGH TO LEARN FROM: " + "; ".join(reasons)),
        }

    def sizes(self, proven=None) -> dict:
        """What an example looks like next to what the loop actually serves.

        Intention: WARP fine-tuned on prompts averaging 164 characters and
        served inputs averaging 74,000 — a **450x** mismatch that no surface
        ever computed, and that makes 2.0 GB of adapters irrelevant whatever
        the data was. It is one comparison and it costs nothing.
        """
        rows = self.gather()["proven"] if proven is None else proven
        lengths = [len(one["asked"]) for one in rows if one["asked"]]
        harvested = int(sum(lengths) / len(lengths)) if lengths else 0
        gap = 0.0
        if harvested and self.served:
            gap = round(max(harvested, self.served) / max(1, min(harvested, self.served)), 1)
        return {"examples": len(lengths), "harvested": harvested,
                "served": self.served, "gap": gap}

    def dataset(self) -> dict:
        """The examples, if there are enough. Otherwise the reason there are not.

        Intention: it returns the refusal in the same shape as the answer, so a
        caller cannot get a dataset by not reading the verdict. WARP's harvest
        wrote `train.jsonl` regardless and let a downstream run decide, and the
        downstream run always decided yes.
        """
        verdict = self.weigh()
        if not verdict["enough"]:
            return {**verdict, "rows": []}
        found = self.gather()
        rows = [{"asked": one["asked"], "artifact": one["artifact"],
                 "proves": one["proves"], "weight": 1.0}
                for one in found["proven"]]
        # Intention: the attempts are KEPT and weighted against, not discarded.
        # They are real evidence of what does not work — they simply may not be
        # the bulk of what a model is shown, which is the whole finding above.
        rows += [{"asked": one["asked"], "artifact": one["artifact"],
                  "said": one["said"], "weight": -1.0}
                 for one in found["attempted"]]
        return {**verdict, "rows": rows}

    # -- the small parts -----------------------------------------------------

    # Intention: what the work was actually asked for, which is the prompt half
    # of an example. Read from the unit that produced the artifact rather than
    # reconstructed, because a prompt nobody actually sent is not evidence.
    def _asked(self, artifact: str) -> str:
        for relation in ("derives",):
            for fact in self.store.current(relation=relation, obj=artifact):
                asked = self._text(fact["subject"], "asked_for")
                if asked:
                    return asked
        asked = self._text(artifact, "asked_for")
        if asked:
            return asked
        test = self._text(artifact, "verified_by")
        if test:
            from pathlib import Path
            from warp2.gate.contracts import obligations
            told = obligations("test", {"artifact_module": Path(artifact).stem})
            return (f"write the test that shows the artifact works: {artifact}\n\n"
                    f"target file: {test}\n\n"
                    f"obligations:\n{told}")
        return ""

    def _text(self, subject: str, attr: str) -> str:
        """Intention: the newest value of one fact as text, or "" when there is none."""
        found = self.store.current(subject=subject, attr=attr)
        return str(found[-1]["value"]) if found else ""
