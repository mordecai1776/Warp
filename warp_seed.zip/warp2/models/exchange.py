# WARP2/warp2/models/exchange.py
# Pathway   : WARP2/warp2/models/exchange.py
# Used by   : roster external backend; external MCP/CLI; loop guidance ingestion.
# Uses      : atomic writes, cross-process locks, the stop flag; stdlib JSON/time.
# Description: local durable work envelopes for tool-hosted outside models.
# User intention: a larger model can work or guide without being installed locally.
from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path

from warp2.record.locks import Lock
from warp2.util import atomic_write_bytes, now_iso, sha256_hex


def _name(value):
    """Only opaque identifiers, never a caller-supplied filesystem path."""
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", value):
        raise ValueError("identifier must contain 1..80 letters, digits, underscores or hyphens")
    return value


def _read(path):
    """Bound mailbox input before decoding it."""
    with Path(path).open("rb") as handle:
        raw = handle.read(262145)
    if len(raw) > 262144:
        raise ValueError("mailbox envelope too large")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("mailbox envelope must be an object")
    return value


def _save(path, value):
    """An envelope appears whole, even when another process is polling."""
    raw = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")
    if len(raw) > 262144:
        raise ValueError("mailbox envelope too large")
    atomic_write_bytes(Path(path), raw)


class Exchange:
    """Local account trust boundary; no network listener or graph write access."""

    def __init__(self, state, participant):
        """Intention: keep the participant's name and its own folder under state/external."""
        self.participant = _name(participant)
        self.home = Path(state).resolve() / "external" / self.participant

    def heartbeat(self, seconds=3600):
        """Announce a listening tool host for the given duration (default 1 hour)."""
        value = {"participant": self.participant, "until": time.time() + float(seconds)}
        with Lock(self.home / "presence.json"):
            _save(self.home / "presence.json", value)
        return value

    def unattended(self, present):
        """Withdraw an unanswered lease without erasing a newer listener's heartbeat."""
        path = self.home / "presence.json"
        with Lock(path):
            try:
                current = _read(path)
            except (OSError, ValueError):
                return
            if current == present:
                _save(path, {**current, "until": 0,
                             "reason": "the last handoff expired without an answer"})

    def ask(self, prompt, seconds=180, stop=None):
        """Wait only for an attended, bounded job; never accept late results."""
        from warp2.models.backends import Unreachable
        try:
            present = _read(self.home / "presence.json")
        except (OSError, ValueError):
            present = {}
        if float(present.get("until", 0)) <= time.time():
            raise Unreachable(f"external participant {self.participant} is offline")
        if not 0 < float(seconds) <= 600:
            raise ValueError("external deadline must be from 0 to 600 seconds")
        job = uuid.uuid4().hex
        path = self.home / "jobs" / f"{job}.json"
        body = {"id": job, "participant": self.participant, "prompt": str(prompt),
                "digest": sha256_hex(str(prompt).encode()), "state": "waiting",
                "created": now_iso(), "expires": time.time() + float(seconds)}
        _save(path, body)
        deadline = time.monotonic() + float(seconds)
        while True:
            with Lock(path):
                current = _read(path)
                halted = stop is not None and stop.raised()
                if halted or time.monotonic() >= deadline:
                    current["state"] = "cancelled" if halted else "expired"
                    _save(path, current)
                    if not halted:
                        self.unattended(present)
                    raise Unreachable(f"external job {job} {current['state']}")
                if current["state"] == "answered":
                    answer = current["answer"]
                    current["state"] = "consumed"
                    _save(path, current)
                    return answer
            time.sleep(0.1)

    def jobs(self):
        """Poll and renew presence; expose only this participant's waiting work."""
        self.heartbeat()
        found = []
        for path in sorted((self.home / "jobs").glob("*.json"), reverse=True):
            row = _read(path)
            if row.get("state") == "waiting" and row.get("expires", 0) > time.time():
                found.append(row)
                if len(found) == 5:
                    break
        return {"participant": self.participant, "jobs": found}

    def submit(self, job, digest, answer):
        """One idempotent answer bound to the exact prompt and unexpired job."""
        if not isinstance(answer, str) or not answer.strip() or len(answer.encode()) > 64000:
            raise ValueError("answer must contain 1..64000 bytes")
        path = self.home / "jobs" / f"{_name(job)}.json"
        with Lock(path):
            row = _read(path)
            if row.get("digest") != digest or row.get("participant") != self.participant:
                raise ValueError("job identity mismatch")
            if row.get("state") in ("answered", "consumed") and row.get("answer") == answer:
                return {"id": job, "state": row["state"]}
            if row.get("state") != "waiting" or row["expires"] <= time.time():
                raise ValueError("job is no longer accepting answers")
            row.update(state="answered", answer=answer, answered_at=now_iso())
            _save(path, row)
        return {"id": job, "state": "answered"}

    def guide(self, focus, text):
        """Stage advisory text; the loop records it before showing it to workers."""
        if not isinstance(focus, str) or not 1 <= len(focus) <= 1000:
            raise ValueError("an exact focus subject is required")
        if not isinstance(text, str) or not text.strip() or len(text.encode()) > 8000:
            raise ValueError("guidance must contain 1..8000 bytes")
        identity = sha256_hex(json.dumps([self.participant, focus, text]).encode())[:32]
        body = {"id": identity, "participant": self.participant, "focus": focus,
                "text": text, "created": now_iso(), "status": "advisory"}
        path = self.home / "guidance" / f"{identity}.json"
        with Lock(path):
            if not path.exists():
                _save(path, body)
        return {"id": identity, "state": "staged", "authority": "advisory"}


def take_guidance(machine, state):
    """Loop-owned ingestion; advice is never a completion or a command."""
    count = 0
    for path in sorted((Path(state) / "external").glob("*/guidance/*.json")):
        if path.with_suffix(".receipt").exists():
            continue
        row = _read(path)
        expected = sha256_hex(json.dumps([row["participant"], row["focus"], row["text"]]).encode())[:32]
        if row["id"] != expected or path.stem != expected or path.parent.parent.name != row["participant"]:
            raise ValueError("guidance identity mismatch")
        subject = f"guidance:{row['id']}"
        for attr, value in (("kind", "external_guidance"), ("author", row["participant"]),
                            ("authority", "advisory"), ("summary", row["text"]),
                            ("created", row["created"])):
            previous = machine.store.current(subject=subject, attr=attr)
            if not previous:
                machine.store.assert_fact(subject, "has", attr=attr, value=value)
        if not machine.store.current(subject=subject, relation="derives", obj=row["focus"]):
            machine.store.assert_fact(subject, "derives", row["focus"])
        _save(path.with_suffix(".receipt"), {"subject": subject, "recorded": now_iso()})
        count += 1
        if count >= 10:
            break
    return {"recorded": count}


def guidance_for(store, focus):
    """Bounded advisory context with authorship and no execution privileges."""
    lines = []
    for fact in store.current(relation="derives", obj=focus):
        subject = fact["subject"]
        if not subject.startswith("guidance:"):
            continue
        rows = store.current(subject=subject)
        attrs = {r["attr"]: r for r in rows if r.get("attr")}
        if "summary" in attrs:
            author = attrs.get("author", {}).get("value", "unknown")
            text = str(store.payload(attrs["summary"]) or "")[:2000]
            lines.append(f"{subject} by {author}: {text}")
        if len(lines) >= 3:
            break
    return "\n".join(lines)
