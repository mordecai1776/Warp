# WARP2/warp2/models/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/models/__init__.py
#  Used by   : the loop, which takes its worker from here.
#  Uses      : nothing at import time, by design.
#  Description:
#    What actually does the work. Which model is chosen, what it is told, what
#    is done with what it says, and how its standing changes afterwards.
#  User intention (Andrew):
#    The tag network's weights are the scoreboard, and the same mechanism picks
#    a model — "find the best by use", "well use and how well it did".
# ============================================================================
