# WARP2/warp2/models/backends.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/models/backends.py
#  Used by   : whoever assembles the fleet on a machine that has models —
#              the launcher (piece 8), and Andrew by hand.
#  Uses      : warp2/settings.py, warp2/record/children.py, warp2/models/inference.py
#              (its ABSENT exit code only), warp2/room/split_load.py (where a
#              direct model's layers go), a Patience (warp2/models/patience.py)
#              handed in by the roster; stdlib json, socket, urllib. NOTHING ELSE — a
#              backend that needs a library the machine does not have is a
#              backend that cannot be tried.
#  Description:
#    How to reach a model that actually exists. One shape — a callable that
#    takes a prompt and returns text — and two ways of producing one.
#  User intention (Andrew):
#    The models run locally. Nothing here may assume a network beyond the
#    machine itself, and nothing here may be required for the rest to be
#    testable — which is why every one of these is optional and injected.
#    2026-11-09 17:45 / 18:37 (BUILD_LOG 1482): a direct model is loaded to fit
#    what the machine has free - card, memory, or a layer at a time from disk
#    ("splitting the way air llm does").
# ============================================================================
from __future__ import annotations

import json
import socket
import time
from pathlib import Path
import urllib.error
import urllib.request

from warp2.models.inference import ABSENT as ABSENT_EXIT
from warp2.record import children
from warp2.record.children import run_watched
from warp2.settings import fraction, number

# How long one answer may take before the attempt is abandoned. WARP's biggest
# model failed 97.3% of its attempts and its recorded complaint was a deadline
# overrun of 1,176 seconds — a number that large is not a timeout, it is a
# decision to wait forever with extra steps.
ASK_SECONDS = fraction("WARP2_MODEL_ASK_SECONDS", 180.0, minimum=1.0)

# The most a model may produce in one answer. A file is a file; an answer ten
# times that size is a model that has not stopped.
MAX_CHARS = number("WARP2_MODEL_MAX_CHARS", 24000, minimum=200)

# How strongly a local model is pushed away from repeating itself. 1.0 is no
# push at all. Intention: a setting to be measured on the held-out benchmark
# (warp2/train/held_out.py), not a guess — the 1.15 that was here, with a ban on
# repeating any three tokens, was measured to garble the names code must repeat.
REPEAT_PENALTY = fraction("WARP2_MODEL_REPEAT_PENALTY", 1.0, minimum=1.0)


# Where trained LoRA checkpoints live. `Path("state")` was read here for
# months; a relative path resolves against the WORKING DIRECTORY, so a run
# started from anywhere but the tree found no checkpoints and attached no
# adapter WITHOUT SAYING SO. The tree knows where it is — this file is
# warp2/models/backends.py, so the root is two folders up.
TREE = Path(__file__).resolve().parents[2]


def adapter_is_loadable(adapter: str) -> bool:
    """Whether a folder actually holds an adapter PEFT can read.

    Intention: WARP once shipped a LoRA equip path that never worked because
    it looked for `adapter_weights.pt` while the trainer wrote `adapter.pt`.
    The check is by NAME, and the names are the ones PEFT itself writes.

    BOTH HALVES ARE REQUIRED. `any` of the three used to pass a folder holding
    a configuration and no weights, and with a failed attach now raising, that
    reading turns a half-written folder into a model that cannot be asked at
    all. A configuration says what the adapter WOULD be; the weights are the
    adapter.
    """
    home = Path(adapter)
    if not (home / "adapter_config.json").is_file():
        return False
    return any((home / leaf).is_file()
               for leaf in ("adapter_model.safetensors", "adapter_model.bin"))


def newest_adapter(model_name: str, base: Path | None = None) -> str:
    """The newest folder here that really holds an adapter, or "" if none does.

    Intention: ASK THE QUESTION THAT MATTERS, NOT THE ONE ABOUT NAMES. Globbing
    `checkpoint-*` was wrong on the real tree and wrong in two ways at once.
    MEASURED on Andrew's disk 2026-09-11, state/checkpoints/qwen3-1.7b:

        adapter-1788983013074830200/   adapter_config.json + adapter_model.safetensors
        checkpoint-0001/               checkpoint.json only
        checkpoint-0003/               checkpoint.json only

    `finetune.py` writes the trained adapter to `adapter-<time_ns>/`, while
    `lora.py`'s CheckpointManager writes `checkpoint-<epoch>/checkpoint.json`
    and nothing else. So the glob returned `checkpoint-0003`, which holds no
    weights, and the caller raised `Unreachable` — a model that used to answer
    untrained stopped loading at all, while the 6.4 MB adapter that WAS trained
    sat one folder away and was never looked at. A lexical sort would also have
    picked the wrong one the moment the epoch numbers outgrew their padding.

    So no prefix is matched and no name is ordered. Every folder is asked
    whether it holds an adapter, and the newest of the ones that say yes is
    the answer. A new writer with a new naming scheme needs no change here.
    """
    home = (Path(base) if base is not None else TREE) / "state" / "checkpoints" / str(model_name)
    if not home.is_dir():
        return ""
    holders = [found for found in home.iterdir()
               if found.is_dir() and adapter_is_loadable(str(found))]
    if not holders:
        return ""
    # Intention: NEWEST BY ITS WEIGHTS, NOT BY ITS FOLDER. MEASURED
    # 2026-09-23: `checkpoint-0003` held a copy of the 09-13 adapter, and the
    # CheckpointManager rewrote its checkpoint.json at 01:47 — which made the
    # FOLDER the newest, so a ten-day-old adapter was picked over the one
    # trained that hour. The weights file's own time is when they were made.
    def made_at(found: Path) -> float:
        for leaf in ("adapter_model.safetensors", "adapter_model.bin"):
            if (found / leaf).is_file():
                return (found / leaf).stat().st_mtime
        return found.stat().st_mtime
    return str(max(holders, key=made_at))


class Unreachable(RuntimeError):
    """The model could not be asked. Not the same as an answer we disliked.

    Intention: the fleet scores "did not answer" differently from "answered
    badly", and it can only do that if the two are distinguishable here. A
    backend that returns "" on a connection failure has told the scoreboard
    that the model produced an empty file, which is a different fact.

    `reached` says whether anything was there at all. False is a server that
    is not running — nobody was asked, and the work must not be charged an
    attempt for it (found 2026-09-18: with Ollama down, a dry run sank two
    build units in two passes). A timeout is `reached`: the model was there.
    """

    def __init__(self, message: str = "", reached: bool = True) -> None:
        """Intention: `reached` defaults to True — only a known absence says otherwise."""
        super().__init__(message)
        self.reached = bool(reached)


def http_model(url: str, name: str, key: str = "", timeout: float = 0.0):
    """A model behind an OpenAI-shaped HTTP endpoint on this machine.

    Intention: this is the shape llama.cpp's server, Ollama and LM Studio all
    speak, so one adapter reaches every local runner Andrew is likely to have
    without a library any of them requires. Written with urllib on purpose —
    the fleet must not fail to start because a package is missing.
    """
    seconds = float(timeout or ASK_SECONDS)

    def ask(prompt: str) -> str:
        """Intention: send one prompt to the chat endpoint and return the reply text; a failure says if the server was reached."""
        body = json.dumps({
            "model": name,
            "messages": [{"role": "user", "content": str(prompt)}],
            "stream": False,
        }).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if key:
            headers["Authorization"] = f"Bearer {key}"
        request = urllib.request.Request(url, data=body, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=seconds) as answer:
                payload = json.loads(_read_by(answer, seconds).decode("utf-8", "replace"))
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            reason = getattr(exc, "reason", exc)
            absent = isinstance(reason, ConnectionError) or (
                isinstance(reason, OSError) and not isinstance(reason, TimeoutError)
                and not isinstance(exc, TimeoutError))
            # Intention: on Windows a closed port does not refuse, it times out
            # while the connect is retried. A timeout only means the model was
            # reached if something is listening there at all.
            if not absent and isinstance(reason, TimeoutError):
                absent = not _listening(url, seconds)
            raise Unreachable(f"{name} at {url}: {type(exc).__name__}",
                              reached=not absent) from exc
        except ValueError as exc:
            raise Unreachable(f"{name} returned something that is not JSON") from exc
        return _first_text(payload)[:int(MAX_CHARS)]

    return ask


def _listening(url: str, seconds: float) -> bool:
    """Whether anything takes a connection at the url's host and port.

    Intention: tells "the model is slow" (reached, charge the wait) from
    "there is no model" (absent, leave the work open) when both look like
    a timeout.
    """
    from urllib.parse import urlsplit
    where = urlsplit(url)
    port = where.port or (443 if where.scheme == "https" else 80)
    try:
        with socket.create_connection((where.hostname or "127.0.0.1", port), timeout=seconds):
            return True
    except OSError:
        return False


# How much of one answer to take off the socket at a time. Big enough that a
# whole ordinary answer is one or two reads, small enough that the clock below
# is looked at often.
BITE = number("WARP2_MODEL_READ_BYTES", 65536, minimum=1024)


def _read_by(answer, seconds: float) -> bytes:
    """Read the whole answer, and give up if the whole answer takes too long.

    Intention: `urlopen(..., timeout=seconds)` bounds ONE socket operation, not
    the exchange. A server that keeps sending something — headers, a trickle of
    body, a keep-alive — resets that clock on every read, so `read()` has no
    total bound at all. MEASURED on Andrew's record 2026-09-12: `do_work` has a
    median of 0.44 s and a worst case of 6,774 s — an hour and fifty-three
    minutes for a call whose own limit is one hundred and eighty seconds. That
    is a whole afternoon of a run spent on one answer nobody was waiting for.

    So the deadline is checked between reads. The bound is the same number the
    caller already asked for; what changes is that it now means what it says.
    """
    ends = time.monotonic() + max(1.0, float(seconds))
    taken, held = [], 0
    while True:
        piece = answer.read(int(BITE))
        if not piece:
            return b"".join(taken)
        taken.append(piece)
        held += len(piece)
        # Intention: A RUNAWAY ANSWER IS ALSO AN ENDING. `MAX_CHARS` used to be
        # applied after the whole thing had been decoded, which is no help
        # against a model that never stops — the memory is already spent.
        if held > int(MAX_CHARS) * 4:
            return b"".join(taken)
        if time.monotonic() > ends:
            raise TimeoutError(f"no complete answer within {float(seconds):.0f}s")


# Where a local runner usually listens. Ollama, llama.cpp's server and LM
# Studio all answer on one of these, and asking is cheaper than making a person
# find out which one they installed.
LIKELY = (
    "http://127.0.0.1:11434/v1",   # Ollama
    "http://127.0.0.1:8080/v1",    # llama.cpp server
    "http://127.0.0.1:1234/v1",    # LM Studio
    "http://127.0.0.1:8000/v1",    # vLLM and friends
)

_LOADED_DIRECT_MODELS: dict[str, tuple] = {}


def direct_model(model_path: str, name: str = "", timeout: float = 0.0, max_tokens: int = 512, adapter_path: str = "",
                 bare: bool = False, watched: bool = False):
    """Direct PyTorch / Transformers model inference running directly on this machine.

    Intention: BOUNDED, LIKE EVERY OTHER BACKEND. `http_model` and
    `command_model` both open with `seconds = float(timeout or ASK_SECONDS)`;
    this one took `timeout` and dropped it on the floor, so `model.generate`
    ran with no time bound at all. Every model in Andrew's roster is `direct`,
    which means the 180-second bound this file declares — and the note above it
    about a deadline overrun being "a decision to wait forever with extra
    steps" — had never applied to a single call he ever made.

    MEASURED 2026-09-05: the loop began a `do_work` at 01:30:18 and was still
    inside it 67 minutes later, holding the machine. Nothing could interrupt
    it: the worker owns a live fleet so it cannot be pickled into a supervised
    child, which is where the parent-enforced deadline lives, and ALL_STOP is
    read between passes. An unbounded call in the one step that cannot be
    isolated is a machine that stops when a model does.

    `bare` is the model with NO adapter at all — what the check after a
    training round compares the trained model against (warp2/train/
    candidate_check.py). Without it the newest adapter on disk is always
    attached, so "the base" could not be asked for.

    KNOWN AND NOT COVERED HERE: loading the weights is still unbounded. A
    `max_time` bounds generation, not `from_pretrained`, and nothing in this
    process can interrupt that. A model that hangs while loading still hangs
    the loop — worth saying out loud rather than implying this closes it.
    """
    import os as _os
    from pathlib import Path as _Path
    path = str(model_path)
    model_name = name or _Path(path).name
    # Intention: NO CLOCK WHEN SOMETHING IS WATCHING (Andrew, 2026-09-24:
    # "there should not be a time out, just a check to make sure it is still
    # running"). `watched` is a caller in its own child whose parent ends it
    # only when it goes silent — the inference child and the training check
    # both beat while they work — so a long answer is written in full. Found
    # 2026-09-24: every benchmark job stopped at exactly 180 s, cut off in the
    # middle of a ~3,900-token answer, so the check scored where the clock
    # stopped the model, not what it could write. In this process, with
    # nothing watching, the bound stays: nothing else could interrupt it.
    seconds = 0.0 if watched else float(timeout or ASK_SECONDS)

    def ask(prompt: str) -> str:
        """Intention: answer one prompt with the model loaded in this process (and its adapter, if any)."""
        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as exc:
            raise Unreachable(f"PyTorch / Transformers not available for direct model {model_name}: {exc}") from exc

        try:
            if path not in _LOADED_DIRECT_MODELS:
                tokenizer = AutoTokenizer.from_pretrained(path, trust_remote_code=True)
                # Intention (BUILD_LOG 1482): THE LAYERS GO WHERE THERE IS ROOM. On the card when it fits there,
                # split between the card and memory when it fits both, and the rest read from disk one layer at a
                # time when it fits neither (warp2/room/split_load.py) - so a model bigger than the machine answers.
                from warp2.room.split_load import placement
                load_as = "bfloat16" if torch.cuda.is_available() else "float32"
                placed = placement(path, load_as, _Path(path).parent / "warp2_offload")
                model = AutoModelForCausalLM.from_pretrained(
                    path,
                    torch_dtype=getattr(torch, load_as),
                    low_cpu_mem_usage=True,
                    trust_remote_code=True,
                    **placed["kwargs"],
                )
                if not placed["kwargs"]:
                    model.to("cpu")

                # Attach what this model was trained into, if anything was.
                # Intention: an adapter that was ASKED FOR and cannot be
                # attached is a failure that must be said out loud — the
                # model would otherwise answer as its untrained self and
                # nothing anywhere would show the training was not used.
                target_adapter = "" if bare else (adapter_path or newest_adapter(model_name))
                if target_adapter:
                    if not adapter_is_loadable(target_adapter):
                        raise Unreachable(
                            f"{model_name}: {target_adapter} holds no adapter PEFT can read")
                    try:
                        from peft import PeftModel
                    except ImportError as exc:
                        raise Unreachable(
                            f"{model_name}: an adapter is trained at {target_adapter} "
                            f"but peft is not installed: {exc}") from exc
                    model = PeftModel.from_pretrained(model, str(target_adapter))

                model.eval()
                _LOADED_DIRECT_MODELS[path] = (tokenizer, model)
            else:
                tokenizer, model = _LOADED_DIRECT_MODELS[path]

            inputs = tokenizer(str(prompt), return_tensors="pt")
            device = next(model.parameters()).device
            inputs = {k: v.to(device) for k, v in inputs.items()}
            prompt_len = inputs["input_ids"].shape[1]

            # Intention: THE BOUND, ASKED FOR IN WHICHEVER WAY THIS INSTALL
            # UNDERSTANDS. `max_time` is a generation setting in current
            # transformers; older ones carry the same idea as a stopping
            # criterion. Both are checked for rather than assumed, because a
            # backend that raises on an unknown keyword would take every model
            # on the machine down with it — and this file's own rule is that a
            # backend must not need a library the machine may not have.
            bounded = dict(inputs)
            how = _bounded_by_time(seconds)
            with torch.no_grad():
                out = model.generate(
                    **bounded,
                    max_new_tokens=max_tokens,
                    pad_token_id=tokenizer.eos_token_id,
                    # Intention: NO BAN ON REPEATING. MEASURED 2026-09-23 on the
                    # held-out benchmark: with `no_repeat_ngram_size=3` and a 1.15
                    # repetition penalty, qwen3-1.7b wrote `conficiency` for
                    # `confidence`, `teaehers` for `teachers`, `warp2.asks` for
                    # `warp2.ask` — code must repeat its names (the import, then
                    # the use), and a rule against repeating any three tokens
                    # forces a misspelling the second time. The penalty is a
                    # named setting, neutral by default, so it can be measured
                    # rather than guessed; runaway output is bounded by time.
                    repetition_penalty=float(REPEAT_PENALTY),
                    do_sample=False,
                    **how,
                )
            generated_tokens = out[0][prompt_len:]
            text = tokenizer.decode(generated_tokens, skip_special_tokens=True)
            return text[:int(MAX_CHARS)]
        except Exception as exc:
            raise Unreachable(f"{model_name} direct inference failed: {type(exc).__name__}: {exc}") from exc

    return ask


# Intention: how to say "stop after this long" to the transformers version that
# is actually installed, and nothing if it cannot be said. Returned as kwargs so
# the call site stays one call rather than two branches of the same generate.
# A bound that cannot be expressed is reported by returning nothing, not by
# pretending: the docstring above says loading is unbounded for the same reason.
def _bounded_by_time(seconds: float) -> dict:
    if seconds <= 0:
        return {}
    try:
        from transformers import GenerationConfig
        if hasattr(GenerationConfig(), "max_time"):
            return {"max_time": float(seconds)}
    except Exception:  # Intention: an older transformers without max_time is normal; the stopping-criteria way just below is tried next.
        pass
    try:
        from transformers import MaxTimeCriteria, StoppingCriteriaList
        return {"stopping_criteria": StoppingCriteriaList(
            [MaxTimeCriteria(max_time=float(seconds))])}
    except Exception:
        return {}


def discover(bases=(), timeout: float = 3.0) -> list:
    """Ask the usual local addresses and weight stores what models they have.

    Intention: a person should not have to know which port their runner chose
    or search their disk. Each address is asked once, briefly, and local weight
    directories are discovered automatically.
    """
    import os as _os
    from pathlib import Path as _Path
    found = []

    # 1. HTTP Endpoints
    for base in (bases or LIKELY):
        url = str(base).rstrip("/") + "/models"
        try:
            with urllib.request.urlopen(url, timeout=float(timeout)) as answer:
                payload = json.loads(answer.read().decode("utf-8", "replace"))
        except (urllib.error.URLError, OSError, TimeoutError, ValueError):
            continue
        for name in _model_names(payload):
            found.append({"name": name, "how": "http",
                          "url": str(base).rstrip("/") + "/chat/completions"})

    # 2. Local Weights in %LOCALAPPDATA%/hf_dl (only when scanning all defaults)
    if not bases:
        local_app = _os.environ.get("LOCALAPPDATA", "")
        if local_app:
            hf_dir = _Path(local_app) / "hf_dl"
            if hf_dir.is_dir():
                for d in sorted(hf_dir.iterdir()):
                    if d.is_dir() and not d.name.startswith("_"):
                        if (d / "config.json").is_file():
                            found.append({
                                "name": d.name,
                                "how": "direct",
                                "path": str(d),
                                "kinds": ["build", "test", "revise", "connect"]
                            })
                        else:
                            ggufs = list(d.glob("*.gguf"))
                            if ggufs:
                                found.append({
                                    "name": d.name,
                                    "how": "direct",
                                    "path": str(d),
                                    "file": ggufs[0].name,
                                    "kinds": ["build", "test", "revise", "connect"]
                                })
    return found


# Intention: the same forgiveness as reading an answer. Runners disagree about
# whether the list is under "data" or "models" and about whether an entry is a
# string or an object with an id.
def _model_names(payload: object) -> list:
    rows = []
    if isinstance(payload, dict):
        rows = payload.get("data") or payload.get("models") or []
    elif isinstance(payload, list):
        rows = payload
    names = []
    for row in rows:
        if isinstance(row, str):
            names.append(row)
        elif isinstance(row, dict):
            name = row.get("id") or row.get("name") or row.get("model")
            if isinstance(name, str):
                names.append(name)
    return names


def command_model(argv, name: str = "", timeout: float = 0.0, stop=None, patience=None):
    """A model reached by running a command and writing the prompt to it.

    Intention: the fall-back that always works. A runner with no server, a
    script Andrew wrote, or `llama-cli` reads the prompt on standard input and
    writes the answer out, and that is enough to be a model as far as
    everything else here is concerned.
    """
    seconds = float(timeout or ASK_SECONDS)
    command = [str(part) for part in argv]

    def ask(prompt: str) -> str:
        """Intention: answer one prompt by running the model command as a watched child process."""
        # Intention: through the watched runner, so ALL_STOP reaches a model
        # that is mid-answer and takes anything it started with it. A model
        # that cannot be interrupted is a model that decides how long the stop
        # takes.
        # Intention: WITH PATIENCE, NO CLOCK ON THE ANSWER (Andrew,
        # 2026-09-24). The child says "still here" while the model works; it
        # is ended only when that stops, or at the far outer bound — and each
        # time either ends it, the model gets twice the room next time.
        who = name or command[0]
        if patience is not None:
            done = run_watched(command, patience.call_budget(who), stop=stop, text=str(prompt),
                               quiet_seconds=patience.silence_budget(who),
                               # A model may keep emitting heartbeat dots while
                               # never producing an answer. Give it the normal
                               # adaptive silence window, but do not let
                               # heartbeat-only output hold the whole loop.
                               meaningful_quiet_seconds=patience.silence_budget(who))
        else:
            done = run_watched(command, seconds, stop=stop, text=str(prompt))
        if done["how"] == children.UNREACHABLE:
            raise Unreachable(f"{who}: {done['said']}", reached=False)
        if done["how"] == children.TIMED_OUT:
            if patience is None:
                raise Unreachable(f"{who} did not answer in {seconds:.0f}s")
            if ("said nothing for" in (done["said"] or "")
                    or "no meaningful output for" in (done["said"] or "")):
                patience.went_silent(who)
                # Intention: reached=False — the work was not judged, so the
                # unit stays open and uncharged and is tried again with more room.
                raise Unreachable(f"{who} stopped running (silent past "
                                  f"{patience.silence_budget(who) / 2:.0f}s); its next allowance is "
                                  f"{patience.silence_budget(who):.0f}s", reached=False)
            patience.ran_out(who)
            raise Unreachable(f"{who} was still working at its {patience.call_budget(who):.0f}s "
                              "model-call safety limit; the work stays open", reached=False)
        if done["how"] == children.HALTED:
            raise Unreachable(f"{name or command[0]} was halted by ALL_STOP")
        if done["code"] != 0:
            # Intention: the "still here" beats are not the reason it failed.
            tail = [line for line in (done["said"] or "").strip().splitlines()
                    if line.strip() != "."]
            # Intention: exit code 3 is the inference child's own word for
            # "the model's server is not there" (warp2/models/inference.py).
            raise Unreachable(f"{name or command[0]} exited {done['code']}: "
                              f"{tail[-1] if tail else 'no message'}",
                              reached=done["code"] != ABSENT_EXIT)
        if patience is not None:
            patience.answered(who)
        # Intention: the beats were for the watcher, not part of what it said.
        said = "\n".join(line for line in (done["said"] or "").splitlines() if line.strip() != ".")
        return said[:int(MAX_CHARS)]

    return ask


# Intention: every local runner wraps its text in a slightly different envelope
# and they all change. One reader that looks in the known places and gives up
# honestly beats a parser per runner that has to be maintained per runner.
def _first_text(payload: object) -> str:
    if isinstance(payload, str):
        return payload
    if not isinstance(payload, dict):
        return ""
    for path in (("choices", 0, "message", "content"),
                 ("choices", 0, "text"),
                 ("message", "content"),
                 ("response",),
                 ("content",)):
        found = payload
        for step in path:
            if isinstance(step, int) and isinstance(found, list) and len(found) > step:
                found = found[step]
            elif isinstance(step, str) and isinstance(found, dict) and step in found:
                found = found[step]
            else:
                found = None
                break
        if isinstance(found, str) and found.strip():
            return found
    return ""
