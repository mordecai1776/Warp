# WARP2/warp2/models/backup.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/models/backup.py
#  Used by   : warp2/train/original_form.py (called by warp2/train/runner.py
#              before and after every training round).
#  Uses      : (stdlib) hashlib, json, os, pathlib; warp2.util.
#  Description:
#    Original-form weight manifest preservation for internal models. Before a
#    model specializes or mutates, its original form is fingerprinted (SHA-256
#    streamed + size) to enable drift detection and guaranteed recovery.
#  User intention (Andrew 2026-07-17):
#    "They should have a back up of their original form and that needs to
#    work with the hydrated forms but that is it."
# ============================================================================
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from warp2.util import atomic_write_bytes, canonical, now_iso

_WEIGHT_EXTS = (".safetensors", ".gguf", ".bin", ".pt")


def manifest_of(
    model_dir: Path | str,
    *,
    max_hash_bytes: int = 64 * 1024 * 1024,
) -> list[dict[str, Any]]:
    """Hash every weight file (streamed).

    Files above max_hash_bytes get a head+tail+size fingerprint — collision-evident
    without spending minutes re-reading 50+ GB weight packs on every routine check.
    """
    model_dir = Path(model_dir)
    out: list[dict[str, Any]] = []
    if not model_dir.is_dir():
        return out

    for p in sorted(model_dir.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in _WEIGHT_EXTS:
            continue
        size = p.stat().st_size
        h = hashlib.sha256()
        with p.open("rb") as fh:
            if size <= max_hash_bytes:
                for chunk in iter(lambda: fh.read(1 << 22), b""):
                    h.update(chunk)
                mode = "full"
            else:
                h.update(fh.read(1 << 22))
                fh.seek(max(0, size - (1 << 22)))
                h.update(fh.read(1 << 22))
                h.update(str(size).encode())
                mode = "head_tail_size"
        rel_path = str(p.relative_to(model_dir)).replace("\\", "/")
        out.append({
            "path": rel_path,
            "bytes": size,
            "sha256": h.hexdigest(),
            "hash_mode": mode,
        })
    return out


def ensure_original_backup(
    state_dir: str | Path,
    model_id: str,
    model_dir: str | Path,
) -> dict[str, Any]:
    """Capture and record the model's original form manifest if not already recorded."""
    state_dir = Path(state_dir)
    model_dir = Path(model_dir)
    backup_file = state_dir / "models_backup" / f"{model_id}.manifest.json"

    if backup_file.is_file():
        try:
            return json.loads(backup_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass

    manifest = manifest_of(model_dir)
    record = {
        "model_id": model_id,
        "recorded_at": now_iso(),
        "model_dir": str(model_dir),
        "files_count": len(manifest),
        "total_bytes": sum(f.get("bytes", 0) for f in manifest),
        "manifest": manifest,
    }
    atomic_write_bytes(backup_file, canonical(record).encode("utf-8"))
    return record


def verify_original(
    state_dir: str | Path,
    model_id: str,
    model_dir: str | Path,
) -> dict[str, Any]:
    """Compare current weight directory against recorded original manifest."""
    state_dir = Path(state_dir)
    model_dir = Path(model_dir)
    backup_file = state_dir / "models_backup" / f"{model_id}.manifest.json"

    if not backup_file.is_file():
        return {"status": "no_backup", "model_id": model_id, "drifted": True}

    try:
        backup = json.loads(backup_file.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"status": "corrupt_backup", "model_id": model_id, "drifted": True}

    original_manifest = {f["path"]: f for f in backup.get("manifest", [])}
    current_manifest = {f["path"]: f for f in manifest_of(model_dir)}

    missing = [p for p in original_manifest if p not in current_manifest]
    added = [p for p in current_manifest if p not in original_manifest]
    changed = [
        p for p in original_manifest
        if p in current_manifest and original_manifest[p]["sha256"] != current_manifest[p]["sha256"]
    ]

    is_drifted = bool(missing or changed)
    return {
        "status": "drifted" if is_drifted else "intact",
        "model_id": model_id,
        "drifted": is_drifted,
        "missing_files": missing,
        "added_files": added,
        "changed_files": changed,
        "verified_at": now_iso(),
    }
