# WARP2/warp2/models/free_card.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/models/free_card.py
#  Used by   : warp2/train/runner.py (before a training round),
#              warp2/train/candidate_check.py (before a check child loads a model).
#  Uses      : projects/behemoth_eye/eye/warp_eye.py (its open-Eye registry, only if
#              it is already loaded); torch (only to let the card's cache go); stdlib
#              gc, json, sys, urllib.
#  Description:
#    Asks Ollama to put down every model it is holding on the graphics card,
#    so a training round or a check that needs the whole card gets it. Ollama
#    keeps a model loaded for a while after its last answer; that is right for
#    work that asks again soon, and wrong for the one step that needs the card
#    to itself. Nothing is lost — the next ask loads the model again.
#  User intention (Andrew):
#    2026-09-24: the training round ran out of card memory ("CUDA error: out of
#    memory") right after a 9B model had answered, and "we need to get the
#    models working" — each step must be able to use the machine it runs on.
# ============================================================================
from __future__ import annotations

import json
import urllib.request

# Intention: where Ollama listens on this machine, as every roster entry says.
OLLAMA = "http://127.0.0.1:11434"


def _call(path: str, body: dict | None = None, seconds: float = 10.0):
    """Intention: one small request to Ollama; None when it is not there."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    request = urllib.request.Request(OLLAMA + path, data=data,
                                     headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=seconds) as answer:
            return json.loads(answer.read() or b"{}")
    except Exception:
        return None


def free_the_card() -> list:
    """Everything this machine holds on the card, put down. Returns what was put down.

    Intention: `keep_alive: 0` is Ollama's own way to say "put it down". A
    machine with no Ollama running has nothing to free, and that is not an
    error. And THE EYE IN THIS PROCESS goes too (found 2026-09-24: with the
    Eye's ~2 GB on the card, the training check ran qwen3-1.7b at 12 minutes a
    job, most of it off the card). It is saved after every turn, so it is only
    closed here, and opened again from disk the next time anything asks.
    """
    loaded = _call("/api/ps") or {}
    names = [str(m.get("name") or m.get("model")) for m in loaded.get("models", []) if isinstance(m, dict)]
    for name in names:
        _call("/api/generate", {"model": name, "keep_alive": 0})
    if _put_down_the_eye():
        names.append("the Eye (this process)")
    return names


def _put_down_the_eye(save: bool = True) -> bool:
    """Intention: every Eye this process has open, closed, and the card's cache let go; whether any was.

    Intention (Andrew, 2026-11-01, "fix everything that is wrong"): LETTING GO NEVER LOSES WORK. An Eye whose save
    the pace held back (`unsaved`) is saved first, as WarpEye.forget does; before, it was dropped and the lessons
    since its last save were lost. `save=False` only drops (after a child process saved the newer copy).
    """
    import sys
    module = sys.modules.get("projects.behemoth_eye.eye.warp_eye")
    if module is None:
        return False
    opened = module._registry()
    had = bool(opened)
    for held in list(opened.values()):
        if save and getattr(held, "unsaved", False):
            try:
                held.save(force=True)
            except Exception as exc:  # noqa: BLE001 — a failed save is on the record; the card is still let go
                from warp2.record.swallowed import noted
                noted("warp2/models/free_card.py:_put_down_the_eye", exc)
    opened.clear()
    import gc
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:  # Intention: emptying the CUDA cache is best-effort cleanup; with no torch or no card there is nothing to empty, and the Eyes are already let go.
        pass
    return had
