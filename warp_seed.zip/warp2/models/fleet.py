# WARP2/warp2/models/fleet.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/models/fleet.py
#  Used by   : warp2/models/worker.py, which asks it who should do this;
#              warp2/parts/reliable_size.py (answer_room — how much a model
#              says it can write).
#  Uses      : warp2/train/outputs.py (every answer kept — `outputs`, set by
#              warp2/models/roster.py),
#              warp2/store/tagnet.py (the weights are the SAME mechanism the
#              tag network uses), warp2/record/deadline.py (cost is measured
#              seconds), warp2/settings.py, warp2/tags/lookups.py (scoped delivery).
#  Description:
#    The models available, their standing per kind of work, the choice between
#    them, and HOW MUCH PROMPT EACH ONE CAN BE GIVEN. A model is a named way of
#    producing an answer, judged by what it has actually produced.
#  User intention (Andrew, 2026-08-27):
#    "add weights to tagnet configurations that way it can find the best by
#    use" — "well use and how well it did". A model is a configuration of the
#    same kind, so it gets the same scoreboard rather than a second one.
# ============================================================================
from __future__ import annotations

from warp2.settings import fraction, number
from warp2.record.swallowed import noted

# How slow an answer may be, as a multiple of the fleet's own measured typical
# answer, before slowness counts against a model's standing. WARP's biggest
# model failed 97.3% of 110 attempts and 98 of its recorded complaints were
# deadline overruns: on that hardware a big model did not answer worse, it
# mostly did not answer.
SLOW_AT = fraction("WARP2_FLEET_SLOW_AT", 3.0, minimum=1.0)

# What one answer is worth to a model's standing, before the gate has said
# anything about it. Answering at all is a small credit; the gate's verdict is
# what actually moves the weight.
ANSWERED = number("WARP2_FLEET_ANSWERED", 250, minimum=0)

# Intention: HOW MANY CHARACTERS ONE TOKEN IS WORTH, for the one place that has
# to bound a prompt and has no tokenizer to ask. English and Python both run
# nearer 4, so 3 under-fills the window — which is the safe direction: too
# little context costs an answer, too much costs a forward pass that nothing in
# this process can interrupt. A setting, because it is a property of the
# tokenizer somebody is actually running and not a fact about the world.
CHARS_PER_TOKEN = number("WARP2_MODEL_CHARS_PER_TOKEN", 3, minimum=1)

# Intention: what to leave for the answer when a roster entry does not say. The
# direct backend's own default is 512 new tokens, so that is the number, kept
# here rather than imported so a model that declares `max_tokens` still wins.
ANSWER_TOKENS = number("WARP2_MODEL_ANSWER_TOKENS", 512, minimum=64)

# How often a model that is not yet proven at a kind of work gets the turn
# anyway. Intention: THE DEADLOCK THE OLD TREE ACTUALLY HIT, WRITTEN DOWN. Its
# harvest could only train a skill once the model already succeeded at it, so
# `test`, `build` and `revise` sat UNPROVEN with 35 harvested rows going
# unused. Preferring the proven and never yielding is the same trap one level
# up: nothing unproven is ever tried, so nothing unproven is ever proven. One
# turn in five is enough to climb and small enough not to cost the work.
LEARNER_TURN_EVERY = number("WARP2_LEARNER_TURN_EVERY", 5, minimum=2)


class Fleet:
    """Who is available, how each has done, and who should do this one.

    Intention: THE CHOICE IS MADE BEFORE GENERATING, NOT AFTER. The 2026
    cascade work found that a lightweight pre-generation router beat the
    cascade itself on four of five datasets — cascades are limited by what
    generating costs at all, not by routing signal. And WARP's own ladder was
    ordered by SIZE, which moved the error rate 1.3 points from 1.5B to 7B and
    put its worst model at the top.
    """

    def __init__(self, tagnet, deadlines=None, proving=None) -> None:
        """Intention: keep the tag network, deadlines and proving record; backends and health start empty."""
        self.tagnet = tagnet
        self.deadlines = deadlines
        # Intention: THE MASTERY LADDER, READ RATHER THAN ONLY WRITTEN. The
        # weights below rank models against each other; this says whether one
        # has shown it can do this kind of work AT ALL, against a skill the
        # bible describes. WARP declared a decay rate and never read it, and
        # kept 15 proven recipes at zero uses for five weeks — a measure
        # nothing consults is a measure that is not being taken. Duck-typed on
        # purpose: `can_work` and `standing`, and no import.
        self.proving = proving
        self._backends: dict = {}
        # Intention: THE RECORD OF EVERYTHING (warp2/train/outputs.py, Andrew
        # 2026-09-25: "Everything every model does should be kept as
        # training"). Set by warp2/models/roster.py when the state is known;
        # None keeps a fleet with no state exactly as it was.
        self.outputs = None
        self._health: dict[str, dict] = {}

    # -- who is here ---------------------------------------------------------

    def enlist(self, name: str, ask, kinds=(), note: str = "",
               context_budget: int = 0, answer_tokens: int = 0, chance=None) -> dict:
        """Add a model: a name and a callable that answers.

        Intention: `ask(prompt) -> str` and nothing more. Whether that is a
        local server, a subprocess, or a person is not this file's business —
        which is also the only way any of this can be tested somewhere that has
        no model at all.

        `context_budget` and `answer_tokens` are what the ROSTER already says
        about this model — the numbers Andrew wrote next to it. They were read
        by the cockpit's display and by nothing else. See `room_for_prompt`.

        `chance(prompt) -> float | None` (item f, 2026-10-17) answers a yes/no
        question as the chance of "yes" from the token chances; a model
        without one is asked in text only.
        """
        self._backends[str(name)] = {"ask": ask, "kinds": tuple(kinds), "note": note,
                                     "chance": chance,
                                     "context_budget": int(context_budget or 0),
                                     "answer_tokens": int(answer_tokens or 0)}
        for purpose in (_purpose(kind) for kind in (kinds or ("",))):
            self.tagnet.register(str(name))
            self.tagnet.store.assert_fact(f"config:{name}", "has",
                                          attr="is", value="model")
            if purpose:
                self.tagnet.store.assert_fact(f"config:{name}", "has",
                                              attr="does", value=purpose)
        return {"model": str(name), "kinds": tuple(kinds)}

    def room_for_prompt(self, name: str) -> int:
        """How many CHARACTERS of prompt this model can be given, or 0.

        Intention: THE NUMBER WAS ALREADY WRITTEN DOWN. Every model in Andrew's
        roster declares a `context_budget`, and until now `warp2/ui/observer.py`
        printed it and nothing else in the tree read it. Both models he
        actually runs declare 8192 with `max_tokens` 3072 — so 5,120 tokens of
        prompt — while `build_context` handed the worker 101,975 BYTES on
        2026-09-11, six or seven times over.

        That is what an unreturning `do_work` looks like from the outside: the
        generation is bounded by `max_time`, but `max_time` is checked BETWEEN
        TOKENS, so it never sees the first forward pass over the prompt. A
        prompt far past the window is a prefill nothing in this process can
        interrupt. The 16:54 run went silent inside exactly that and never
        came back.

        Characters, not tokens, because the bound has to be applied where the
        text is assembled and no tokenizer is reachable there. `CHARS_PER_TOKEN`
        is deliberately low — under-estimating the ratio under-fills the window,
        which is the safe direction.

        0 means the model declares nothing, and then nothing is imposed: a
        bound invented for a model that never asked for one is a number
        somebody will have to fight later.
        """
        entry = self._backends.get(str(name))
        if entry is None:
            return 0
        window = int(entry.get("context_budget") or 0)
        if window <= 0:
            return 0
        # Intention: the answer has to fit in the window too. What the model
        # says it will write is subtracted before what it is given to read.
        answer = int(entry.get("answer_tokens") or 0) or int(ANSWER_TOKENS)
        room = window - answer
        return max(0, room) * int(CHARS_PER_TOKEN)

    def answer_room(self, name: str) -> int:
        """How many CHARACTERS of answer this model says it can write, or 0.

        Intention: the other half of `room_for_prompt`. The roster's
        `max_tokens` is where a model's answer is cut; an answer asked to be
        longer than that comes back cut off (measured 2026-09-23: a 68,841
        character file asked back whole came back as 11,889 characters of its
        opening comment and no code). 0 means the model declares nothing.
        """
        entry = self._backends.get(str(name))
        if entry is None:
            return 0
        return max(0, int(entry.get("answer_tokens") or 0)) * int(CHARS_PER_TOKEN)

    def names(self, kind: str = "") -> list:
        """Intention: the names of models that will take this kind of work, or all of them when no kind is given."""
        # Intention: a model that declares no kinds is willing to try anything.
        # Declaring some is a narrowing, never a widening.
        out = []
        kind = asked_as(kind)
        for name, entry in sorted(self._backends.items()):
            if kind and entry["kinds"] and kind not in entry["kinds"]:
                continue
            out.append(name)
        return out

    # -- the choice ----------------------------------------------------------

    def choose(self, kind: str, stream: str = "") -> str:
        """Who should do this one, by weight, for this kind of work.

        Intention: KIND OF WORK IS A PURPOSE, and purposes are separate
        scoreboards already. The model that writes a good test is not
        necessarily the one that repairs an artifact, and a single ranking
        would average those into a number that describes neither.
        """
        available = self.eligible(kind)
        if not available:
            return ""
        picked = self.tagnet.choose(purpose=_purpose(kind), stream=stream)
        if picked is not None and picked.name in available:
            return picked.name
        # Intention: the tag network ranks every configuration it knows,
        # including readings that are not models and models that cannot do this
        # kind. When its pick is not eligible, the fall-back is the best
        # ELIGIBLE one by the same weights — never a different mechanism.
        return max(available, key=lambda name: (
            self.tagnet.weight(name, _purpose(kind)), name))

    def likely(self, kind: str) -> str:
        """Who would most likely get this kind of work, without drawing.

        Intention: the context is built before the worker picks its model, and
        the context reading is learned per model. So the loop asks who is
        likeliest — the best eligible by weight, the same fall-back rule
        `choose` uses — without spending a draw, which would change who is
        actually picked. Added 2026-09-18 with the lens fold.
        """
        available = self.eligible(kind)
        if not available:
            return ""
        return max(available, key=lambda name: (
            self.tagnet.weight(name, _purpose(kind)), name))

    def eligible(self, kind: str) -> list:
        """Who may be given this kind of work on this turn.

        Intention: PREFER THE PROVEN, BUT NEVER SHUT THE DOOR. When some model
        has shown it can do this kind and others have not, the proven ones take
        the turn — except every fifth, which goes to the learners, because a
        model that is never tried can never be proven and that is exactly how
        the old tree deadlocked. The turn is counted from the record, not from
        a coin, so two readings of the same state agree.

        When nobody is proven, or everybody is, this changes nothing: the
        weights below decide, as they did before.
        """
        available = self.names(kind)
        # Circuit breaker: keep a failing model from monopolising the fleet,
        # while retaining one probe turn so recovery remains possible.
        healthy = []
        for name in available:
            row = self._health.get(name, {})
            if row.get("state") == "open" and int(row.get("probes", 0)) % 5:
                continue
            healthy.append(name)
        if healthy:
            available = healthy
        # Intention: NEVER ASSIGN COMPLEX WORK TO REPEATEDLY FAILING MODELS.
        # A model with 5+ attempts and performance < 200 (scale 1..1000) is held
        # back from turns when capable peers exist in the fleet.
        if len(available) > 1 and hasattr(self.tagnet, "performance"):
            purpose = _purpose(kind)
            capable = [name for name in available
                       if self.tagnet.trials(name, purpose) < 5
                       or self.tagnet.performance(name, purpose) > 300]
            if capable:
                available = capable
        if self.proving is None or len(available) < 2:
            return available
        kind = asked_as(kind)
        able = [name for name in available if self.proving.can_work(name, kind)]
        if not able or len(able) == len(available):
            return available
        learners = [name for name in available if name not in able]
        tried = sum(int(self.proving.standing(name, kind).get("attempts", 0))
                    for name in available)
        return learners if tried % int(LEARNER_TURN_EVERY) == 0 else able

    def second(self, kind: str, after: str) -> str:
        """The one other model worth trying when the first is refused.

        Intention: TWO RUNGS, AND NO MORE. Optimised longer cascades gave "no
        practically meaningful held-out gains" over a two-model pair, and
        WARP's ladder — ordered by size, four rungs deep — moved its error rate
        by 1.3 points across the whole climb.
        """
        # Intention: the second rung is drawn from everyone who can do this
        # kind, not from this turn's eligible set. The first choice already
        # spent the preference; the fall-back exists precisely for when it was
        # wrong, and narrowing it again would leave a refused learner with
        # nobody to hand the work to.
        rest = [name for name in self.names(kind) if name != after]
        if not rest:
            return ""
        return max(rest, key=lambda name: (self.tagnet.weight(name, _purpose(kind)), name))

    def health(self) -> list[dict]:
        """Current circuit state for every enlisted model, for the cockpit."""
        return [{"model": name,
                 "state": str(self._health.get(name, {}).get("state", "healthy")),
                 "failures": int(self._health.get(name, {}).get("failures", 0)),
                 "probes": int(self._health.get(name, {}).get("probes", 0))}
                for name in self.names()]

    def ask(self, name: str, prompt: str) -> str:
        """Intention: ask one model by name (allowing small spelling differences), keep the answer, and return it."""
        sname = str(name)
        entry = self._entry(sname)
        said = entry["ask"](prompt)
        # Intention: observe answered model deliveries only in Loop's explicit
        # scope; ordinary reads/diagnostics never enroll or write lookup state.
        from warp2.tags.lookups import model_returned
        try:
            model_returned(sname, prompt)
        except Exception as exc:
            noted("warp2/models/fleet.py:Fleet.ask.lookup", exc)
        # Intention: KEPT THE MOMENT IT IS GIVEN, whatever it turns out to be.
        # Keeping must never be what stops an answer reaching its caller.
        if self.outputs is not None:
            try:
                self.outputs.keep(sname, prompt, said)
            except Exception as exc:
                noted("warp2/models/fleet.py:Fleet.ask", exc)
        return said

    def chance(self, name: str, prompt: str) -> float | None:
        """The chance a model gives "yes" to a yes/no question, or None when it cannot say one.

        Intention (item f, 2026-10-17): JUDGES BY FIXED-OPTION SCORING. A
        verdict read from token chances cannot be unreadable. None means this
        model has no token chances here (or gave none), and the caller keeps
        its text path and records that it did.
        """
        reader = self._entry(str(name)).get("chance")
        if reader is None:
            return None
        found = reader(prompt)
        return None if found is None else max(0.0, min(1.0, float(found)))

    def _entry(self, sname: str) -> dict:
        """Intention: one model's entry by name, allowing small spelling differences; KeyError when none."""
        entry = self._backends.get(sname)
        if entry is None:
            # Try common model name alias mappings (e.g. dash vs colon, or base tag)
            alt1 = sname.replace("-", ":") if "-" in sname else sname.replace(":", "-")
            entry = self._backends.get(alt1)
            if entry is None:
                for k, v in self._backends.items():
                    if k.replace("-", ":") == sname.replace("-", ":") or k.split("/")[-1] == sname.split("/")[-1]:
                        entry = v
                        break
        if entry is None:
            raise KeyError(f"no model named {sname!r}")
        return entry

    # -- the standing --------------------------------------------------------

    def record(self, name: str, kind: str, answered: bool, accepted: bool | None,
               seconds: float = 0.0) -> dict:
        """Fold one attempt into this model's standing for this kind of work.

        Intention: three things decide it, and SLOWNESS IS ONE OF THEM. An
        answer that never arrives is not a neutral event — it is the whole of
        what went wrong with WARP's biggest model, and a scoreboard that only
        reads the gate's verdict would rank a model that times out as untried
        rather than as unusable.
        """
        purpose = _purpose(kind)
        # Keep model health in the same KG/tag evidence stream as the rest of
        # the allocator. This is an observation, not a second scoreboard: the
        # existing tagnet standing remains authoritative for selection while
        # these facts expose latency and usable-answer health to later circuit
        # breakers and portfolio allocation.
        try:
            self.tagnet.store.assert_fact(
                f"model:{name}", "has", attr="health_observation",
                value={"purpose": purpose, "answered": bool(answered),
                       "accepted": accepted, "seconds": round(float(seconds), 4)})
        except Exception as exc:
            noted("warp2/models/fleet.py:Fleet.record", exc)
        health = self._health.setdefault(str(name), {"failures": 0, "probes": 0, "state": "healthy"})
        if answered and accepted:
            health.update({"failures": 0, "state": "healthy"})
        elif not answered or accepted is False:
            health["failures"] = int(health.get("failures", 0)) + 1
            health["probes"] = int(health.get("probes", 0)) + 1
            if health["failures"] >= 3:
                health["state"] = "open"
        if not answered:
            return self.tagnet.record_use(name, returned=0, purpose=purpose)
        rank = 1
        worked = accepted
        if accepted is None:
            # Nothing judged it yet. Answering is worth a little and no more.
            return self.tagnet.record(name, int(ANSWERED), purpose=purpose)
        if seconds and self._is_slow(seconds):
            # Intention: a right answer that arrives too late to use is scored
            # as a right answer that came third, not as a wrong one. It IS
            # worth less; it is not worthless.
            rank = 3
        return self.tagnet.record_use(name, returned=1, chosen_rank=rank,
                                      worked=bool(worked), purpose=purpose)

    # Intention: slow COMPARED TO WHAT THIS FLEET ACTUALLY DOES, measured from
    # the record rather than set as a constant. A number written by somebody on
    # one machine is wrong on every other one.
    def _is_slow(self, seconds: float) -> bool:
        if self.deadlines is None:
            return False
        cost = self.deadlines.cost("ask_model")
        if cost.get("basis") == "unmeasured":
            return False
        return float(seconds) > float(cost["seconds"]) * float(SLOW_AT)

    def standing(self, kind: str = "") -> list:
        """Every model's weight for this kind of work, best first."""
        purpose = _purpose(kind)
        rows = [{"model": name,
                 "weight": self.tagnet.weight(name, purpose),
                 "trials": self.tagnet.trials(name, purpose),
                 "performance": self.tagnet.performance(name, purpose)}
                for name in self.names(kind)]
        rows.sort(key=lambda row: (-row["weight"], row["model"]))
        return rows


# Intention: A KIND OF WORK THE ROSTER DOES NOT NAME, DONE AS ONE IT DOES.
# Paying a file's owed rule (`update`, warp2/gate/owed.py) is a revision by
# every measure a model is chosen on; the roster Andrew writes names `revise`,
# so an update is chosen, weighed and scored as one.
# An improvement of the warp itself (warp2/improve/, Andrew 2026-09-25) is a
# revision too — of a warp part instead of a project's.
ASKS_AS = {"update": "revise", "update_test": "test", "split": "revise", "improve": "revise"}


def asked_as(kind: str) -> str:
    """Intention: the kind a model is chosen and scored for."""
    return ASKS_AS.get(str(kind or ""), str(kind or ""))


# Intention: one place the purpose name is formed, so a kind of work and its
# scoreboard can never drift apart by a spelling.
def _purpose(kind: str) -> str:
    kind = asked_as(kind)
    return f"work:{kind}" if kind else "work"
