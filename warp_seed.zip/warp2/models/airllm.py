# WARP2/warp2/models/airllm.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/models/airllm.py
#  Used by   : warp2/models/worker.py, warp2/models/fleet.py, warp2/run.py
#  Uses      : (stdlib) json, logging, os, pathlib, time; torch/airllm (optional)
#  Description:
#    Layer-by-layer sequential transformer execution for running large models on
#    limited VRAM (e.g. 15x VRAM reduction at ~0.14 tok/s). Honors Andrew's trade:
#    correctness over speed, making latency honest and parent-bounded.
#  User intention (Andrew 2026-08-16):
#    "There is an open source python library that allows the use of bigger models
#    run on smaller computers and we need to use it... so we can start to use bigger
#    models." And: "taking a longer time is fine, the correct results are what we
#    are looking for, not for it to be fast."
# ============================================================================
from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger(__name__)

AIRLLM_ESTIMATED_TOKENS_PER_SEC = 0.145
AIRLLM_RESIDENT_LAYER_VRAM_MB = 548


def airllm_available() -> bool:
    """Check whether torch and airllm packages are importable."""
    try:
        import torch  # noqa: F401
        import airllm  # noqa: F401
        return True
    except ImportError:
        return False


class AirLLMEngine:
    """Layer-by-layer sequential inference manager."""

    def __init__(self, model_path: Path | str, is_4bit: bool = False) -> None:
        """Intention: keep the model path and 4-bit choice; the model itself is loaded later, when first needed."""
        self.model_path = Path(model_path)
        self.is_4bit = bool(is_4bit)
        self._model = None

    def load(self) -> dict[str, Any]:
        """Prepare AirLLM layer-by-layer model handle."""
        if not airllm_available():
            return {
                "status": "unavailable",
                "reason": "torch/airllm not installed in current environment",
                "model_path": str(self.model_path),
                "resident_vram_mb": AIRLLM_RESIDENT_LAYER_VRAM_MB,
            }
        # In an environment with AirLLM:
        try:
            from airllm import AutoModel
            self._model = AutoModel.from_pretrained(
                str(self.model_path),
                compression="4bit" if self.is_4bit else None,
            )
            return {
                "status": "ready",
                "model_path": str(self.model_path),
                "resident_vram_mb": AIRLLM_RESIDENT_LAYER_VRAM_MB,
                "is_4bit": self.is_4bit,
            }
        except Exception as exc:
            log.warning("AirLLM loading failed for %s: %s", self.model_path, exc)
            return {
                "status": "error",
                "error": f"{type(exc).__name__}: {exc}",
                "model_path": str(self.model_path),
                # Intention: capacity is a property of the execution strategy,
                # not evidence that this checkpoint loaded. Callers size the
                # route from this field in every outcome; omitting it only when
                # the optional package was installed but rejected the model
                # made the same machine-dependent call shape raise KeyError.
                "resident_vram_mb": AIRLLM_RESIDENT_LAYER_VRAM_MB,
                "is_4bit": self.is_4bit,
            }

    def generate(
        self,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.2,
    ) -> dict[str, Any]:
        """Run generation through layer-by-layer execution."""
        start_time = time.monotonic()
        if not airllm_available() or self._model is None:
            # Clean fallback when dependencies are not present
            return {
                "status": "unavailable",
                "output": "",
                "reason": "AirLLM has no loaded model",
                "duration_seconds": time.monotonic() - start_time,
                "tokens_generated": 0,
                "airllm": True,
            }

        try:
            input_tokens = self._model.tokenizer(
                [prompt],
                return_tensors="pt",
                truncation=True,
                max_length=2048,
            )
            generation_output = self._model.generate(
                input_tokens["input_ids"].cuda(),
                max_new_tokens=max_tokens,
                use_cache=True,
                return_dict_in_generate=True,
            )
            output_text = self._model.tokenizer.decode(
                generation_output.sequences[0],
                skip_special_tokens=True,
            )
            dur = time.monotonic() - start_time
            return {
                "status": "ok",
                "output": output_text,
                "duration_seconds": dur,
                "tokens_generated": len(generation_output.sequences[0]),
                "airllm": True,
            }
        except Exception as exc:
            return {
                "status": "error",
                "error": f"{type(exc).__name__}: {exc}",
                "duration_seconds": time.monotonic() - start_time,
            }
