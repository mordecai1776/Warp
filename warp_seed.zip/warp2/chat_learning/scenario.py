# WARP2/warp2/chat_learning/scenario.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/scenario.py
#  Used by   : warp2/chat_learning/{simulate,learning}.py; tests.
#  Uses      : warp2/chat_learning/asking.py; (stdlib) dataclasses.
#  Description:
#    A scenario the models act out: what it is about, what the person says
#    first, how many answers it runs for, the real conversation when it came
#    from data (its person-side lines are used as they were, and its own
#    answers join the others to be tagged), where it came from, and what it
#    is meant to teach. A scenario is made from a dataset's conversation,
#    from a real chat turn, or by a model asked to open a conversation on a
#    topic and say how many answers back and forth it would take.
#  User intention (Andrew, 2026-09-20): "a simulation with the other models
#    ... to simulated scenarios".
# ============================================================================
"""What the models act out."""
from __future__ import annotations

from dataclasses import dataclass, field

from warp2.chat_learning.asking import ask, json_in


@dataclass
class Scenario:
    """One scenario.

    Intention: `reference` is the real conversation ([{role, content}]) when
    there is one; `turns` is how many answers it runs for; `teaches` are the
    things it is meant to teach (tag names), when known.
    """

    topic: str
    opening: str
    turns: int
    source: str
    reference: list = field(default_factory=list)
    teaches: list = field(default_factory=list)


def from_conversation(messages: list, source: str, teaches=()) -> Scenario:
    """Intention: a real conversation as a scenario — as many answers as it had, its first person line as the opening."""
    said = [m for m in messages if str(m.get("content", "")).strip()]
    first = next((m for m in said if m.get("role") == "user"), said[0] if said else {"content": ""})
    answers = sum(1 for m in said if m.get("role") == "assistant")
    return Scenario(topic=str(first["content"])[:80], opening=str(first["content"]),
                    turns=max(answers, 1), source=str(source), reference=list(said), teaches=list(teaches))


def generated(fleet, model: str, topic: str, teaches=()) -> Scenario | None:
    """Intention: a model opens a conversation on a topic and says how many answers it would take; None when it cannot."""
    said = ask(fleet, model, (
        f"Write the first thing a person would say to start a conversation about: {topic}. "
        "Also say how many replies back and forth it would take to settle it. "
        'Answer only with JSON: {"opening": "...", "turns": n}.'))
    found = json_in(said, "{", "}")
    if not isinstance(found, dict) or not str(found.get("opening", "")).strip():
        return None
    try:
        turns = max(1, int(found.get("turns", 1)))
    except (TypeError, ValueError):
        turns = 1
    return Scenario(topic=str(topic), opening=str(found["opening"]).strip(), turns=turns,
                    source=f"model:{model}", teaches=list(teaches))
