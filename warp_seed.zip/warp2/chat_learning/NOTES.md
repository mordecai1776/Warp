# WARP2/warp2/chat_learning/NOTES.md

# The chat's learning — what is built, and what is left

Started 2026-09-20 (#115). Andrew: "Lets make the learning system for the chat.
We need to make a simulation with the other models for it. It needs to follow
the pattern we have and have all of them tag the responses of each other to
simulated scenarios we can have them all learn off of this and form the
previous response part from this. We also need to update the chat on all of
this and at this point we need to start looking up datasets. This means we
need to build in the current active from datasets and compress the rest. There
should be a system for all of this that takes in their scores from what they
are meant to teach and gives the best to convey a said thing."

His answers the same day:
- the Eye goes in the chat's loop;
- datasets come from the Hugging Face hub, web research and local files;
- the rest is compressed as dehydrated tags.

## Built

| Part | File | What it does |
|---|---|---|
| Scenarios | `scenario.py` | From a dataset's conversation, a real chat turn, or a model asked to open one (and say how many answers it takes). |
| Simulation | `simulate.py` | The person's lines come from the data when it has them, or from one model. At every answer every model answers, and the data's own answer joins them. Each answer is tagged by every other model. The answer that best conveys what is being taught goes on. |
| Tagging | `tagging.py` | Tags are formed tags `{name, says, why, weight}`, with weight from -1 to 1. A tag is agreed when the taggers who gave it hold more than half the trust. Its weight is the trust-weighted mean over all taggers. |
| Teaching ledger | `ledger.py` | Exact running means of three scores: teaching (from the tensegrity map, per answer and tag), conveying (agreed weight), and tagging (a tagger's match with agreement, which becomes its trust). `conveys` values how well an answer conveys a thing, and the best answer is chosen by it. |
| The Eye's lessons | `lessons.py` | The Eye sees each turn as continuing chat input, with the previous response beside it (`Eye.see(alongside=...)`). Every agreed tag is taught from every answer's words alone. A tag with no concept gets a synthetic pair of its name. |
| Datasets | `datasets.py` | Hub search (most downloaded first) and viewer rows, a page at a time. Also hub datasets the web names, and local .jsonl/.json files. Common row shapes become conversations. |
| Shelf | `shelf.py` | Rows in use are kept whole. The rest are dehydrated tags (SHA-256 plus gzip), restored exactly. |
| Real chat turns | `turns.py`, `warp2/ask/talk.py` | Every chat turn is kept as one line. The next learning turn acts it out again: every model answers what Andrew said, beside the answer he got. |
| The turn | `learning.py`, `warp2/work/side/chat.py` | Real turns first, then one scenario chosen for the tag the Eye answers worst. It comes from rows in use, then matching dehydrated rows, then datasets looked up, then a model. A row stays in use while a tag it taught is still not answered right. |

Measured on this machine: the hub search and viewer work without any library.
HuggingFaceH4/ultrachat_200k rows read as 8- and 12-turn conversations.

## Added (#116)
- **The Eye speaks.** `WarpEye.learn_to_say` / `say`: a say pair chooses
  one word at a time, reading three things:
  - the Eye's quiet look at the prompt, with the words so far as previous
    actions;
  - the prompt's tokens;
  - the words said.

  In each learning turn it is taught the answer that went on at every step.
  Answers it cannot say yet are taught together until it says them right.
  Measured: two prompts' answers ("hello, friend!", "it is noon.") are said
  word for word within about 40 passes.
- **The Eye answers beside the models** in every simulation once it can
  speak. It is tagged like them, so it earns its own conveying scores.
- **The live chat's speaker** (`speaker.py`, wired through
  `warp2/ask/window.py` and `talk.py`). What Andrew said is read by the Eye
  for the tags the chat has been taught. The speaker with the best ledger
  record for those tags answers: a model, or the Eye in its own words. With
  no record, the first model answers, as before. There is one speaker a
  turn, chosen from the record, not by asking everyone.
- **Datasets by meaning.** A model gives the search words for a weak tag,
  once, and they are kept (`queries.json`). Rows are marked with the tags
  they actually taught.
- **A quiet look** (`Eye.see(quiet=True)`). Acting and speaking read the
  Eye without making or changing anything. Before, every word spoken made
  new found pairs.

## Added (#117)
- **What the Eye cannot say yet is saved.** It is kept as prompts (tags)
  and words in `speaking.json`. What the Eye reads for them is worked out
  afresh each time, because what it knows moves on.
- **Answers put together from parts.** The say pair now reads three
  things:
  - the concepts the prompt carries (how strongly the Eye finds each
    concept its answers were taught to convey);
  - the prompt's tokens;
  - the words just said, the last strongest and each one before it half
    as strong.

  So the next word follows the words just said, parts of different answers
  can follow on from each other, and a new prompt carrying the same
  concepts leads to the same kind of answer. An older say pair that read
  differently is remade, with a receipt.
- **The viewer page adapts.** It starts at one row and doubles while pages
  hold no conversation (up to the viewer's own most, 100), then goes back
  to one.
- **One model is enough.** It answers, and it tags the data's answers and
  the Eye's (never its own).

## Added (#118)
- **Every fifth scenario is held back.** The models and the Eye act it
  out and are scored under "held", and nothing is taught from it. It is
  the same rule every pair follows. The Eye's held score is what it does
  on what it was never taught, including answers put together from parts.
- **The live chat judges the Eye on that.** It speaks only where its
  held-back score beats the models' records. Each model is judged on all
  it has conveyed.
- **Standing** (`state/chat_learning/standing.json`, `Ledger.standing`):
  every maker's mean conveying and mean held score, with counts. The chat
  step says the Eye's held score each turn.
- **Tagging costs less, with the same agreement.** Taggers are asked most
  trusted first, and asking stops once the rest could not change which
  tags are agreed (`tagging.settled`). The weights of agreed tags are then
  read from the taggers asked.

## Added (#119) — choices at a known point of certainty
Andrew: "you cant ever know what is best ever on anything. You have to make a
choice at a known point of certainty. That was what the entire tensegrity
system was meant to provide and in the view of the absolute add that way of
thinking to the situation."

- `certainty.py`: a record's true value lies within one standard error of
  its mean. This is the same point the Eye uses to prove an action
  (`WarpEye.proven`). A record seen fewer than twice could be anything.
- The ledger keeps each record's spread (`Ledger.bounds`).
- **The simulation asks models until the choice is certain enough.** The
  data's and the Eye's answers come first. Then the model that could give
  the most is asked, and asking stops once no model not yet asked could
  beat the best answer found, even at the high bound of its record. A
  model with no record is always asked. Every step says who was not asked
  (`unasked`).
- **The live chat's speaker** takes the first model's place only when it
  is certainly best: its low bound is at least every other speaker's high
  bound. The Eye is judged on its held-back scores.

## What is still open
- The held measure and the records' spreads need a real run to read.
