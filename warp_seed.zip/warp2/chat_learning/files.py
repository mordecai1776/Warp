# WARP2/warp2/chat_learning/files.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/files.py
#  Used by   : chat-learning ledgers, shelves, and durable model state.
#  Uses      : stdlib JSON, os, time, pathlib; warp2.util atomic writes.
#  Description:
#    Read validated state and persist it atomically, quarantining corruption.
#  User intention: saved learning state must survive interruption without
#    silently accepting malformed or partial files.
# ============================================================================
"""Validated, atomic files for chat-learning state."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path


def read_json(path, default, expected=None):
    """Read one JSON value; quarantine malformed or wrongly-shaped state."""
    path = Path(path)
    if not path.is_file():
        return default
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if expected is not None and not isinstance(value, expected):
            raise TypeError(f"expected {expected}, found {type(value).__name__}")
        return value
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        quarantine = path.with_name(f"{path.name}.corrupt-{time.strftime('%Y%m%d-%H%M%S')}")
        try:
            os.replace(path, quarantine)
        except OSError:
            pass
        return default


def write_json(path, value, *, indent=None, sort_keys=False) -> None:
    """Write one JSON value whole and atomically."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=indent, sort_keys=sort_keys),
                         encoding="utf-8")
    os.replace(temporary, path)
