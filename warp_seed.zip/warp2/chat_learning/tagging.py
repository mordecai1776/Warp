# WARP2/warp2/chat_learning/tagging.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tagging.py
#  Used by   : warp2/chat_learning/{simulate,learning}.py; tests.
#  Uses      : warp2/chat_learning/{asking,ledger,files}.py.
#  Description:
#    Every model tags every other model's answer. A tag is WARP2's formed
#    tag — {name, says, why, weight, holds} — with a weight from -1 to 1
#    (below nought: the answer fails at it). What an answer is, is what the
#    taggers agree on: a tag is agreed when the taggers who gave it hold
#    more than half of all the taggers' trust (the ledger's reliability of
#    each); its weight is the trust-weighted mean over every tagger, a
#    tagger who did not give it counting nought. How far each tagger's own
#    tags matched the agreed ones (their overlap over their union) is what
#    its trust is learned from. Taggers are asked most trusted first, and
#    asking stops once the rest could not change what is agreed.
#    (2026-11-02, BUILD_LOG 1118) A tagger that gives no tags earns no
#    trust: silence had matched an empty agreement as a perfect 1.0, so the
#    two models that never tag (moondream, qwen3:4b) became the most
#    trusted, were asked first, and settled every reply as having no agreed
#    tag — 0 tags taught, turn after turn. The trust earned under that rule
#    is forgotten once (TrustReset). And every tagger is shown the names
#    already in use, so the same thing is named the same way.
#  User intention (Andrew, 2026-09-20): "have all of them tag the responses
#    of each other". "tags are tokens".
# ============================================================================
"""Models tagging each other's answers, and what they agree on."""
from __future__ import annotations

from warp2.chat_learning.asking import ask, json_in

PROMPT = (
    "Here is a conversation so far:\n{context}\n\n"
    "This is the next reply, given by one speaker:\n{reply}\n\n"
    "Tag the reply. Answer only with a JSON list of tags, each "
    '{{"name": "a short concept the reply is or does", "says": "what in the reply shows it", '
    '"why": "why it matters here", "weight": a number from -1 to 1, below 0 when the reply fails at it}}.')


def parse_tags(text: str) -> list:
    """Intention: the formed tags a model gave — names trimmed and lowered, weights kept inside -1..1; anything else dropped."""
    found = json_in(text)
    out, seen = [], set()
    for item in found if isinstance(found, list) else []:
        if not isinstance(item, dict):
            continue
        name = " ".join(str(item.get("name", "")).lower().split())
        if not name or name in seen:
            continue
        try:
            weight = max(-1.0, min(1.0, float(item.get("weight", 1.0))))
        except (TypeError, ValueError):
            weight = 1.0
        seen.add(name)
        out.append({"name": name, "says": str(item.get("says", "")), "why": str(item.get("why", "")),
                    "weight": weight, "holds": []})
    return out


def context_of(turns: list) -> str:
    """Intention: the conversation so far as plain lines, speaker role first."""
    return "\n".join(f"{t['role']}: {t['text']}" for t in turns) or "(nothing yet)"


def settled(by: dict, trust: dict, waiting: float) -> bool:
    """Whether the taggers not yet asked could still change what is agreed.

    Intention: with `waiting` trust not yet asked, a tag already given by
    more than half of all the trust stays agreed whatever they say; a tag
    that could not reach half even if they all gave it never will; and no
    tag they alone might give can reach half unless they hold more than
    half. When every tag is one or the other, what is agreed is decided.
    """
    total = sum(trust.get(m, 1.0) for m in by) + waiting
    if waiting > total / 2.0:
        return False
    given: dict = {}
    for model, tags in by.items():
        for tag in tags:
            given[tag["name"]] = given.get(tag["name"], 0.0) + trust.get(model, 1.0)
    return all(support > total / 2.0 or support + waiting <= total / 2.0 for support in given.values())


def named_already(known) -> str:
    """The line that shows a tagger the names already in use, or "" when there are none.

    Intention (BUILD_LOG 1118): agreement needs the same name from more than
    half the trust, and free-chosen names almost never coincide ("greeting",
    "greets", "salutation"). Shown the names in use, a tagger reuses one
    when it fits and makes a new one only when none does.
    """
    names = sorted({str(n) for n in known or () if str(n).strip()})
    if not names:
        return ""
    return ("\nNames already in use — reuse one exactly when it fits, make a new one only when none fits: "
            + ", ".join(names))


def tag_reply(fleet, taggers: list, turns: list, reply: str, trust: dict = None, known=()) -> dict:
    """Every tagger's tags for one reply, by tagger — asked most trusted first, until what is agreed is decided.

    Intention: all of them tag, until more asking could not change which
    tags are agreed (`settled`); the rest are then not asked, which is
    where most of the tagging's cost goes. The weights of agreed tags are
    read from the taggers asked. `known` is the names already in use.
    """
    trust = trust or {}
    prompt = PROMPT.format(context=context_of(turns), reply=reply) + named_already(known)
    order = sorted(taggers, key=lambda m: (-trust.get(m, 1.0), m))
    by: dict = {}
    for at, model in enumerate(order):
        by[model] = parse_tags(ask(fleet, model, prompt))
        waiting = sum(trust.get(m, 1.0) for m in order[at + 1:])
        if waiting and settled(by, trust, waiting):
            break
    return by


def agree(by: dict, trust: dict) -> list:
    """The tags the taggers agree on, as formed tags with their agreed weight and who gave them.

    Intention: support is the share of all trust held by the taggers who
    gave a tag; more than half is agreement. The weight is the
    trust-weighted mean over every tagger (absent ones count nought). The
    words kept are those of the most trusted tagger who gave it.
    """
    total = sum(trust.get(m, 1.0) for m in by) or 1.0
    names: dict = {}
    for model, tags in by.items():
        for tag in tags:
            names.setdefault(tag["name"], []).append((model, tag))
    agreed = []
    for name, given in sorted(names.items()):
        support = sum(trust.get(m, 1.0) for m, _ in given) / total
        if support <= 0.5:
            continue
        weight = sum(trust.get(m, 1.0) * t["weight"] for m, t in given) / total
        words = max(given, key=lambda g: trust.get(g[0], 1.0))[1]
        agreed.append({"name": name, "says": words["says"], "why": words["why"], "weight": weight,
                       "holds": [], "given_by": sorted(m for m, _ in given)})
    return agreed


def matched(tags: list, agreed: list) -> float:
    """How far one tagger's tags matched the agreed ones — their overlap over their union.

    Intention (BUILD_LOG 1118): a tagger that gave no tags did not tag, so
    it matched nothing — 0, even when nothing was agreed. It was 1 when both
    were empty, and silence became the most trusted word.
    """
    mine, all_of = {t["name"] for t in tags}, {t["name"] for t in agreed}
    if not mine:
        return 0.0
    return len(mine & all_of) / len(mine | all_of)


class TrustReset:
    """The tagging trust earned while silence counted as agreement, forgotten once.

    Intention (BUILD_LOG 1118): those records say who stayed silent, not who
    tags well; kept, the silent models would hold the most trust for
    hundreds of turns more. A mark beside the ledger says it was done.
    """

    def __init__(self, home, ledger) -> None:
        """Intention: the chat's own folder (for the mark) and its ledger."""
        from pathlib import Path
        self.mark = Path(home) / "tagging_rule.json"
        self.ledger = ledger

    def once(self) -> int:
        """Intention: the tagging records dropped and the mark written, the first time only; how many were dropped."""
        if self.mark.is_file():
            return 0
        from warp2.chat_learning.files import write_json
        from warp2.chat_learning.ledger import TAGGING
        dropped = self.ledger.forget(TAGGING)
        self.ledger.save()
        write_json(self.mark, {"rule": "a tagger that gives no tags earns no trust", "build_log": 1118,
                               "dropped": dropped})
        return dropped
