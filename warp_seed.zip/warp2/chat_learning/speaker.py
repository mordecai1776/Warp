# WARP2/warp2/chat_learning/speaker.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/speaker.py
#  Used by   : warp2/ask/window.py (the chat's `ask`), warp2/ask/talk.py
#              (`speak`); tests.
#  Uses      : warp2/chat_learning/{ledger,certainty}.py, projects/behemoth_eye/eye/
#              warp_eye.py (WarpEye: readings, can_say, say),
#              projects/behemoth_eye/eye/heads (WEB).
#  Description:
#    Who speaks in the chat: the one that best conveys what was said. What
#    Andrew said is read by the Eye, and each tag the chat has been taught
#    that the Eye finds in it counts by how strongly the Eye finds it.
#    Every speaker is valued by the teaching ledger: each model by what it
#    has taught and conveyed of those tags (ledger.conveys), the Eye by
#    what it conveyed on scenarios held back from its teaching
#    (ledger.held) — what it does on what it never learned; the best
#    speaks. With nothing yet to tell them
#    apart, each is valued by all it has conveyed, and the first model
#    speaks when there is no record at all — as the chat always did. The
#    Eye's own words are used only when it is chosen, and a model answers
#    if it has nothing to say. One speaker a turn: the choice is made from
#    the record, not by asking everyone.
#  User intention (Andrew, 2026-09-20): "gives the best to convey a said
#    thing"; the Eye in the chat's loop.
# ============================================================================
"""The chat's speaker: whoever best conveys what was said."""
from __future__ import annotations

from warp2.chat_learning.ledger import CONVEYING, HELD, Ledger

EYE = "eye"


class ChatSpeaker:
    """The models and the Eye, and the ledger that chooses between them."""

    def __init__(self, fleet, state) -> None:
        """Intention: the chat's own ledger and the WARP's one Eye."""
        from pathlib import Path
        self.fleet, self.state = fleet, state
        self.ledger = Ledger(Path(state) / "chat_learning")
        self.last = ""

    def _warp(self):
        """Intention: the WARP's one Eye for this state folder."""
        from projects.behemoth_eye.eye.warp_eye import WarpEye
        return WarpEye.for_state(self.state)

    def _eye_can_say(self) -> bool:
        """Fast durable check without loading the 55-layer PyTorch network.

        Speaking is durable only when both its manifest and weights exist.
        ``now.json`` is a transient UI snapshot and must not be used as the
        authority for a capability that has to survive a restart.
        """
        if not self.state:
            return False
        from pathlib import Path
        home = Path(self.state) / "models" / "eye"
        manifest = home / "speaking.json"
        weights = home / "speaker.pt"
        if not manifest.is_file() or not weights.is_file():
            return False
        try:
            import json
            data = json.loads(manifest.read_text(encoding="utf-8"))
            return bool(int(data.get("longest", 0)))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return False

    def makers(self) -> list:
        """Intention: every model, and the Eye once it can speak."""
        makers = [f"model:{m}" for m in (self.fleet.names() if self.fleet is not None else [])]
        if self._eye_can_say():
            makers.append(EYE)
        return makers

    def _in_play(self, said: str) -> dict:
        """Intention: the taught tags the Eye finds in what was said, by how strongly (only those it finds)."""
        taught_things = self.ledger.things(CONVEYING) | self.ledger.things(HELD)
        if not taught_things or not str(said or "").strip():
            return {}
        if not self._eye_can_say():
            return {}
        from projects.behemoth_eye.eye.heads import WEB
        warp = self._warp()
        things = [t for t in taught_things if t in warp.eye.concepts.pairs]
        if not things:
            return {}
        strengths, _ = warp.eye.readings(warp.piece(str(said), WEB), things)
        return {t: v for t, v in strengths.items() if v > 0.0}

    def choose(self, said: str) -> str:
        """The speaker certainly best at conveying what was said; the first model while none is certain.

        Intention: each speaker's record for the tags in play is how low and
        how high it may truly be (one standard error, certainty.py) — the
        Eye's from the held-back scenarios (what it does on what it was
        never taught), each model's from all it has conveyed. A speaker
        speaks in place of the first model only when its low bound is at
        least every other speaker's high bound. A speaker with too little
        record could be anything, so nothing is certain while one has none.
        """
        from warp2.chat_learning.certainty import certain_best
        makers = self.makers()
        if not makers:
            return ""
        in_play = self._in_play(said)
        things = in_play or {t: 1.0 for t in self.ledger.things(CONVEYING) | self.ledger.things(HELD)}
        if not things:
            return makers[0]
        options = {}
        for maker in makers:
            kind = HELD if maker == EYE else CONVEYING
            low = high = mean = 0.0
            for t, w in things.items():
                lo, hi = self.ledger.bounds(kind, maker, t)
                low, high, mean = low + w * lo, high + w * hi, mean + w * self.ledger.mean(kind, maker, t)[0]
            options[maker] = (low, mean, high)
        return certain_best(options) or makers[0]

    def speak(self, prompt: str, said: str = "") -> str:
        """Intention: the chosen speaker's answer — the Eye's words, or the model's; a model answers when the Eye has none."""
        from projects.behemoth_eye.eye.heads import WEB
        maker = self.choose(said)
        self.last = maker
        if maker == EYE:
            warp = self._warp()
            text = warp.say(warp.piece([{"name": "user", "weight": 1.0, "says": str(said), "holds": []}], WEB))
            if text:
                return text
            maker = next((m for m in self.makers() if m != EYE), "")
            self.last = maker
        if not maker:
            return ""
        return str(self.fleet.ask(maker[len("model:"):], prompt) or "")

    def __call__(self, prompt: str) -> str:
        """Intention: the chat's `ask(prompt)`, for a caller that does not give what was said."""
        return self.speak(prompt, "")
