# WARP2/warp2/chat_learning/datasets.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/datasets.py
#  Used by   : warp2/chat_learning/learning.py; tests.
#  Uses      : (stdlib) json, pathlib, re, time, urllib. Web research's fetcher
#              (warp2/research/look.py web_fetcher) is given by the caller.
#  Description:
#    Finding datasets and reading their conversations, from three places:
#      * the Hugging Face hub — its search, most downloaded first, and the
#        dataset viewer's rows, read a page at a time (no library needed);
#      * the web — what research finds, with every Hugging Face dataset it
#        names;
#      * local files — .jsonl and .json under state/datasets/local.
#    Every row is turned into a conversation ([{role, content}]) from the
#    shapes datasets usually have: messages or conversations (role and
#    content, or from and value), a dialog of alternating lines, prompt and
#    response, instruction and output, question and answer. A row that is
#    none of these is left alone.
#    How pages are fetched (`get`) and how the web is searched (`look`) are
#    given by the caller, so all of it runs without a network in tests.
#    A row that asks about a picture is marked (about_a_picture, BUILD_LOG
#    1118): the chat's models never see the picture.
#    A page has a whole-call time and size (WHOLE_SECONDS, MOST_BYTES), not
#    only a per-read timeout, so one slow page cannot hold the loop.
#  User intention (Andrew, 2026-09-20): "at this point we need to start
#    looking up datasets" — the Hugging Face hub, web research and local
#    files.
# ============================================================================
"""Finding datasets, and their rows as conversations."""
from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path

HUB = "https://huggingface.co/api/datasets"
VIEWER = "https://datasets-server.huggingface.co"
NAMED = re.compile(r"huggingface\.co/datasets/([\w.-]+/[\w.-]+)")


# Intention: A WHOLE PAGE HAS A WHOLE-CALL TIME AND SIZE. urlopen's timeout is per
# socket read, so a slow page that trickles in (a hub viewer page of a dataset
# whose rows are huge lists) never trips it: on 2026-11-02 one try_eye_on_tasks
# sat 1412 s inside these reads (3.7x its usual), holding the whole loop. A page
# not had within WHOLE_SECONDS, or bigger than MOST_BYTES, is a page that cannot
# be had (None), the same answer as any other failed read.
WHOLE_SECONDS = 90.0
MOST_BYTES = 64 * 1024 * 1024
CHUNK = 256 * 1024


def read_whole(answer, deadline: float, most: int, clock=time.monotonic):
    """Intention: an answer's body, chunk by chunk, or None when it runs past its deadline or its size."""
    parts, size = [], 0
    while True:
        if clock() > deadline:
            return None
        # Intention: read1 gives what has come so far (read would wait to fill a whole CHUNK).
        chunk = answer.read1(CHUNK) if hasattr(answer, "read1") else answer.read(CHUNK)
        if not chunk:
            return b"".join(parts)
        size += len(chunk)
        if size > most:
            return None
        parts.append(chunk)


class NotReached(RuntimeError):
    """Intention (2026-11-07): the hub was not reached at all (no network, no name, timed out) - which says nothing
    about the dataset asked for. The hub's own "no" (an HTTP error) is still None."""

    def __init__(self, url: str, why: str) -> None:
        """Intention: the address and the reason, kept on the error for the caller to say."""
        super().__init__(f"{url}: not reached ({why})")
        self.url, self.why = url, why


def get_json(url: str, timeout: float = 20.0, whole: float = WHOLE_SECONDS, most: int = MOST_BYTES):
    """Intention: one page as JSON; None when the hub answered no (an HTTP error), or the body took longer than
    `whole` seconds in all, was bigger than `most` bytes, or was not JSON. NotReached when the hub was not reached."""
    deadline = time.monotonic() + float(whole)
    req = urllib.request.Request(url, headers={"User-Agent": "WARP2/2.0 (compatible; research-agent)"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as answer:
            body = read_whole(answer, deadline, int(most))
    except urllib.error.HTTPError:
        return None
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        raise NotReached(url, f"{type(exc).__name__}: {exc}") from exc
    try:
        return None if body is None else json.loads(body.decode("utf-8"))
    except ValueError:
        return None


def hub_search(words: str, get=get_json) -> list:
    """Intention: the hub's datasets for these words, most downloaded first."""
    query = urllib.parse.urlencode({"search": words, "sort": "downloads", "direction": "-1", "limit": "20"})
    found = get(f"{HUB}?{query}") or []
    return [d["id"] for d in found if isinstance(d, dict) and d.get("id")]


def hub_rows(dataset: str, offset: int, length: int, get=get_json) -> list:
    """Intention: a page of a hub dataset's rows, from its first split the viewer can read; [] when it cannot."""
    splits = get(f"{VIEWER}/splits?" + urllib.parse.urlencode({"dataset": dataset})) or {}
    for split in splits.get("splits", []) if isinstance(splits, dict) else []:
        page = get(f"{VIEWER}/rows?" + urllib.parse.urlencode(
            {"dataset": dataset, "config": split["config"], "split": split["split"],
             "offset": str(int(offset)), "length": str(int(length))}))
        if isinstance(page, dict) and page.get("rows"):
            return [r["row"] for r in page["rows"]]
    return []


def web_named(words: str, look) -> list:
    """Intention: every hub dataset the web's pages about these words name."""
    names = []
    for page in (look(f"{words} dataset") if look is not None else []) or []:
        for found in NAMED.findall(f"{page.get('url', '')} {page.get('text', '')}"):
            if found not in names:
                names.append(found)
    return names


def local_rows(folder) -> list:
    """Intention: every row of every .jsonl and .json file in a folder, with the file it came from."""
    rows = []
    for path in sorted(Path(folder).rglob("*")) if Path(folder).is_dir() else []:
        if path.suffix == ".jsonl":
            rows += [(str(path), json.loads(line)) for line in path.read_text(encoding="utf-8").splitlines()
                     if line.strip()]
        elif path.suffix == ".json":
            data = json.loads(path.read_text(encoding="utf-8"))
            rows += [(str(path), r) for r in (data if isinstance(data, list) else [data])]
    return rows


def _turn(item) -> dict | None:
    """Intention: one message as {role, content}, whatever its keys were."""
    if not isinstance(item, dict):
        return None
    role = str(item.get("role") or item.get("from") or item.get("speaker") or "").lower()
    text = item.get("content", item.get("value", item.get("text")))
    if text is None:
        return None
    role = "assistant" if role in ("assistant", "gpt", "bot", "model", "system_reply") else "user"
    return {"role": role, "content": str(text)}


PICTURE_KEYS = ("image", "images", "picture", "img", "photo")


def about_a_picture(row) -> bool:
    """Whether a row asks about a picture — a picture field that holds something.

    Intention (BUILD_LOG 1118): measured 2026-11-02, 1,327 of the chat's
    1,356 rows were the Blender steps' "what is in this picture" rows from
    state/datasets/local, with the picture left behind; a model asked them
    sees only the words, so they are no conversation the chat can learn.
    """
    return isinstance(row, dict) and any(row.get(key) not in (None, "", [], {}) for key in PICTURE_KEYS)


def conversation_of(row) -> list:
    """Intention: a row as a conversation, from the shapes datasets usually have; [] when it is none of them."""
    if not isinstance(row, dict):
        return []
    for key in ("messages", "conversations", "conversation", "dialogue_turns"):
        if isinstance(row.get(key), list):
            turns = [t for t in (_turn(i) for i in row[key]) if t]
            if turns:
                return turns
    for key in ("dialog", "dialogue", "utterances"):
        if isinstance(row.get(key), list) and all(isinstance(x, str) for x in row[key]):
            return [{"role": "user" if i % 2 == 0 else "assistant", "content": x} for i, x in enumerate(row[key])]
    for asked, answered in (("prompt", "response"), ("prompt", "chosen"), ("instruction", "output"),
                            ("question", "answer"), ("input", "output")):
        if isinstance(row.get(asked), str) and isinstance(row.get(answered), str):
            return [{"role": "user", "content": row[asked]}, {"role": "assistant", "content": row[answered]}]
    return []
