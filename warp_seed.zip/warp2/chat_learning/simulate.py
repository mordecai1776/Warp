# WARP2/warp2/chat_learning/simulate.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/simulate.py
#  Used by   : warp2/chat_learning/learning.py; tests.
#  Uses      : warp2/chat_learning/{asking,tagging,ledger,certainty}.py.
#  Description:
#    The models act out one scenario. The person's side is the real
#    conversation's own lines when there is one, else one model plays the
#    person (a different one each scenario) and may end it by saying
#    [end]. At every answer, every model answers; a real conversation's
#    own answer joins them. Every answer is tagged by every model that did
#    not give it, and what they agree on is what it is. The conversation
#    The Eye answers too, once it can speak, and is tagged like the others.
#    The conversation goes on with the answer that best conveys what the scenario is meant
#    to teach (or, when that is not known, what the answers were agreed to
#    be): its own agreed weight for each thing, plus what its maker has
#    taught and conveyed of it before (the ledger). It runs for the
#    scenario's number of answers, or until the person ends it.
#  User intention (Andrew, 2026-09-20): "a simulation with the other models
#    ... have all of them tag the responses of each other to simulated
#    scenarios". "gives the best to convey a said thing".
# ============================================================================
"""The models acting out a scenario, answering and tagging each other."""
from __future__ import annotations

import hashlib
import math

from warp2.chat_learning.asking import ask, one_line
from warp2.chat_learning.certainty import could_beat
from warp2.chat_learning.ledger import CONVEYING, TEACHING
from warp2.chat_learning.tagging import agree, context_of, tag_reply

ANSWER = ("You are the assistant in this conversation. Reply to the last thing the person said, "
          "and say only your reply.\n\n{context}\n\nassistant:")
PERSON = ("You are the person in this conversation, which is about: {topic}. Say your next line "
          "and only that, or say [end] if you are done.\n\n{context}\n\nperson:")


def _person(models: list, source: str) -> str:
    """Intention: which model plays the person — fixed by the scenario's source, so it varies from scenario to scenario."""
    return models[int(hashlib.sha256(source.encode("utf-8")).hexdigest(), 16) % len(models)]


def _value(candidate: dict, things: list, ledger) -> float:
    """Intention: how well an answer conveys the things — its agreed weight for each, plus its maker's record for each."""
    weights = {t["name"]: t["weight"] for t in candidate["agreed"]}
    return sum(ledger.conveys(candidate["speaker"], t, weights.get(t, 0.0)) for t in things)


def _tag(fleet, candidate: dict, models: list, turns: list, ledger) -> None:
    """Intention: one answer tagged by every model that did not give it, and what they agree on; the taggers are
    shown the names already agreed on and taught (BUILD_LOG 1118), so they reuse them."""
    taggers = [m for m in models if f"model:{m}" != candidate["speaker"]]
    trust = {m: ledger.trust(m) for m in taggers}
    known = ledger.things(TEACHING) | ledger.things(CONVEYING)
    candidate["by"] = tag_reply(fleet, taggers, turns, candidate["text"], trust, known=known)
    candidate["agreed"] = agree(candidate["by"], trust)


def _things(scenario, candidates: dict) -> list:
    """Intention: what the answers are judged on — what the scenario teaches, else what the answers so far were agreed to be."""
    return list(scenario.teaches) or sorted({t["name"] for c in candidates.values() for t in c["agreed"]})


def _could_give(model: str, things: list, ledger) -> float:
    """How well a model not yet asked could truly convey the things, at the high bound of its record.

    Intention: the most its answer might be worth, at one standard error
    above what it has conveyed; a model with too little record for the
    things could give anything, so it is never ruled out.
    """
    if not things:
        return math.inf
    maker = f"model:{model}"
    return sum(ledger.bounds(CONVEYING, maker, t)[1] + ledger.weighed(TEACHING, maker, t)
               + ledger.weighed(CONVEYING, maker, t) for t in things)


def _out_of_turn() -> bool:
    """Whether the turn this conversation runs inside is spent (eye/turn_clock.py) — False when there is no turn.

    Intention (2026-10-31, Remy for Andrew: "fix everything that is wrong"): the models were asked with no clock
    looked at, so one train_chat turn ran two hours against a usual twenty minutes (stuck_stacks, that night: inside
    converse -> _answers -> ask). The conversation keeps what it already has and stops asking once the turn is spent.
    """
    try:
        from projects.behemoth_eye.eye.turn_clock import over
        return bool(over(None))
    except Exception:  # noqa: BLE001 — no clock is no limit, as before
        return False


def _answers(fleet, scenario, models: list, ledger, eye, turns: list, at: int, answers: list) -> tuple:
    """Every answer needed at one step, until the best is certain enough.

    Intention: the data's own answer and the Eye's come first (they cost
    no model); then models are asked, the one that could give the most
    first, each answer tagged as it comes; asking stops once no model not
    yet asked could beat the best answer found, even at the high bound of
    its record (certainty.py). What is best is never known — the choice is
    made at a known point of certainty. A model with no record is always
    asked, so every model earns a record.
    """
    candidates = {}
    if at < len(answers):
        candidates["data"] = {"speaker": scenario.source, "text": str(answers[at])}
    spoken = eye(turns) if eye is not None else ""
    if spoken:
        candidates["eye"] = {"speaker": "eye", "text": spoken}
    for c in candidates.values():
        _tag(fleet, c, models, turns, ledger)
    untried = list(models)
    while untried:
        things = _things(scenario, candidates)
        found = max((_value(c, things, ledger) for c in candidates.values()), default=-math.inf)
        could = {m: _could_give(m, things, ledger) for m in untried}
        if candidates and not could_beat(found, list(could.values())):
            break
        # Intention (BUILD_LOG 1120): the turn's end stops the asking only once one model has been asked beside the
        # data — one answer alone teaches nothing (a tag is taught from answers that have it against ones that do
        # not). Measured 2026-11-03: with every model tagging, tagging the data's answer spent the asking share, and
        # three turns running heard one answer and taught 0 tags. One model, not all: the turn still ends.
        if candidates and len(untried) < len(models) and _out_of_turn():
            break
        model = max(sorted(untried), key=lambda m: could[m])
        untried.remove(model)
        text = one_line(ask(fleet, model, ANSWER.format(context=context_of(turns))))
        if text:
            candidates[f"model:{model}"] = {"speaker": f"model:{model}", "text": text}
            _tag(fleet, candidates[f"model:{model}"], models, turns, ledger)
    return candidates, untried


def converse(fleet, scenario, models: list, ledger, eye=None) -> dict:
    """Intention: the conversation as it went, and every answer given at every step with its tags; `eye(turns)` is the Eye's own answer, when it can speak."""
    persons = [m["content"] for m in scenario.reference if m.get("role") == "user"]
    answers = [m["content"] for m in scenario.reference if m.get("role") == "assistant"]
    person = _person(models, scenario.source)
    turns = [{"role": "user", "text": scenario.opening,
              "speaker": scenario.source if persons else f"model:{person}"}]
    steps = []
    for at in range(scenario.turns):
        candidates, unasked = _answers(fleet, scenario, models, ledger, eye, turns, at, answers)
        if not candidates:
            break
        things = _things(scenario, candidates)
        chosen = max(sorted(candidates), key=lambda cid: _value(candidates[cid], things, ledger))
        steps.append({"context": [dict(t) for t in turns], "candidates": candidates, "chosen": chosen,
                      "things": things, "unasked": unasked})
        turns.append({"role": "assistant", "text": candidates[chosen]["text"],
                      "speaker": candidates[chosen]["speaker"]})
        if at + 1 >= scenario.turns or _out_of_turn():
            break
        if at + 1 < len(persons):
            line, speaker = persons[at + 1], scenario.source
        else:
            line = one_line(ask(fleet, person, PERSON.format(topic=scenario.topic, context=context_of(turns))))
            speaker = f"model:{person}"
        if not line or "[end]" in line.lower():
            break
        turns.append({"role": "user", "text": line, "speaker": speaker})
    return {"turns": turns, "steps": steps}
