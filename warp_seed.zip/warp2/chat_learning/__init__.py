# WARP2/warp2/chat_learning/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/__init__.py
#  Used by   : warp2/work/side/chat.py (ChatStep), warp2/ask/talk.py
#              (ChatTurns), warp2/ask/window.py (ChatSpeaker);
#              warp2/chat_learning/tests.
#  Uses      : warp2/chat_learning/{asking,scenario,simulate,tagging,ledger,
#              shelf,datasets,turns,lessons,learning,speaker}.py.
#  Description:
#    How the Eye learns to chat. The WARP's models act out scenarios —
#    from datasets, from real chat turns, or made up by a model — and every
#    model answers each turn. Every model tags every other's answer (tags
#    are tokens: {name, says, why, weight}); the tags most of them agree on
#    are what an answer is. The Eye sees each turn with the previous
#    response beside it and is taught the agreed tags by tensegrity; how
#    well each answer taught each tag is kept in a teaching ledger, which
#    also says which model tags reliably and which answer conveys a thing
#    best — and the best answer is the one the conversation goes on with.
#    The Eye is taught to say the answers that went on, answers beside the
#    models once it can, and in the live chat whoever best conveys what
#    was said speaks (speaker.py).
#    Datasets are found on the Hugging Face hub, on the web, and in local
#    files; the rows in use are kept whole and the rest are dehydrated.
#  User intention (Andrew, 2026-09-20): "Lets make the learning system for
#    the chat. We need to make a simulation with the other models for it. It
#    needs to follow the pattern we have and have all of them tag the
#    responses of each other to simulated scenarios we can have them all
#    learn off of this and form the previous response part from this. We
#    also need to update the chat on all of this and at this point we need
#    to start looking up datasets. This means we need to build in the
#    current active from datasets and compress the rest. There should be a
#    system for all of this that takes in their scores from what they are
#    meant to teach and gives the best to convey a said thing."
# ============================================================================
"""The chat's learning system."""
