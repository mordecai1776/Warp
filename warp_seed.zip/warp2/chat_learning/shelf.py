# WARP2/warp2/chat_learning/shelf.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/shelf.py
#  Used by   : warp2/chat_learning/learning.py; tests.
#  Uses      : (stdlib) base64, gzip, hashlib, json, os, pathlib.
#  Description:
#    The dataset shelf: the rows in use are kept whole, and the rest are
#    dehydrated. A row is active while it is being taught from; everything
#    else becomes a dehydrated tag — {name: "row:<id>", says: its first
#    words, why: where it came from, weight, sha: the SHA-256 of the row,
#    packed: the row itself, gzip-compressed} — so nothing is lost and
#    nothing sits in the way: a dehydrated row comes back exactly when it
#    is wanted again (checked against its SHA). A row is known once, by
#    its SHA, however many times it is found.
#    Kept in state/chat_learning/active.json and dehydrated.jsonl.
#  User intention (Andrew, 2026-09-20): "build in the current active from
#    datasets and compress the rest" — as dehydrated tags.
# ============================================================================
"""Rows in use kept whole; the rest dehydrated, restorable exactly."""
from __future__ import annotations

import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
from warp2.chat_learning.files import read_json


def _canonical(row) -> bytes:
    """Intention: a row as the same bytes every time."""
    return json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def row_sha(row) -> str:
    """Intention: a row's identity — the SHA-256 of its canonical bytes."""
    return hashlib.sha256(_canonical(row)).hexdigest()


def dehydrate(row, source: str, weight: float = 1.0, teaches=()) -> dict:
    """Intention: one row as a dehydrated tag — small, exact, and restorable."""
    raw = _canonical(row)
    sha = hashlib.sha256(raw).hexdigest()
    words = " ".join(str(row)[:120].split())
    return {"name": f"row:{sha[:16]}", "says": words, "why": f"from {source}", "weight": float(weight),
            "holds": [], "sha": sha, "source": str(source), "teaches": list(teaches),
            "packed": base64.b64encode(gzip.compress(raw)).decode("ascii")}


def hydrate(tag: dict):
    """Intention: the row back exactly; a row that does not match its SHA is refused, never half-trusted."""
    raw = gzip.decompress(base64.b64decode(tag["packed"]))
    if hashlib.sha256(raw).hexdigest() != tag["sha"]:
        raise ValueError(f"{tag['name']} does not match its SHA-256")
    return json.loads(raw.decode("utf-8"))


class Shelf:
    """Active rows by id, and the dehydrated rest."""

    def __init__(self, home) -> None:
        """Intention: read from its files when it has them."""
        self.home = Path(home)
        self.active: dict = {}
        self.dry: dict = {}
        if (self.home / "active.json").is_file():
            self.active = read_json(self.home / "active.json", {}, dict)
        if (self.home / "dehydrated.jsonl").is_file():
            path = self.home / "dehydrated.jsonl"
            try:
                for line in path.read_text(encoding="utf-8").splitlines():
                    if line.strip():
                        tag = json.loads(line)
                        if isinstance(tag, dict) and tag.get("sha"):
                            self.dry[tag["sha"]] = tag
            except (OSError, ValueError, json.JSONDecodeError):
                # Preserve the unreadable source for diagnosis; an empty dry
                # shelf is safer than accepting partially decoded rows.
                import time
                try:
                    os.replace(path, path.with_name(f"{path.name}.corrupt-{time.strftime('%Y%m%d-%H%M%S')}"))
                except OSError:
                    pass
                self.dry = {}

    def known(self, sha: str) -> bool:
        """Intention: whether a row is on the shelf, whole or dry."""
        return sha in self.active or sha in self.dry

    def add(self, row, source: str, active: bool, teaches=()) -> str:
        """Intention: a new row, whole when it is to be used now and dehydrated otherwise; a row already here is left as it is."""
        sha = row_sha(row)
        if self.known(sha):
            return sha
        if active:
            self.active[sha] = {"row": row, "source": str(source), "teaches": list(teaches)}
        else:
            self.dry[sha] = dehydrate(row, source, teaches=teaches)
        return sha

    def wet(self, sha: str) -> dict:
        """Intention: a dehydrated row made active again, exactly as it was."""
        if sha in self.dry:
            tag = self.dry.pop(sha)
            self.active[sha] = {"row": hydrate(tag), "source": tag["source"], "teaches": tag["teaches"]}
        return self.active[sha]

    def dry_out(self, sha: str, weight: float = 1.0) -> None:
        """Intention: an active row no longer in use, dehydrated."""
        if sha in self.active:
            item = self.active.pop(sha)
            self.dry[sha] = dehydrate(item["row"], item["source"], weight, item["teaches"])

    def matching(self, words: str) -> list:
        """Intention: the dehydrated rows whose first words or teachings hold every one of these words."""
        wanted = [w for w in str(words).lower().split() if w]
        return [sha for sha, tag in self.dry.items()
                if all(w in (tag["says"] + " " + " ".join(tag["teaches"])).lower() for w in wanted)]

    def save(self) -> None:
        """Intention: both files written whole, under temporary names moved into place."""
        self.home.mkdir(parents=True, exist_ok=True)
        for name, text in (("active.json", json.dumps(self.active, ensure_ascii=False)),
                           ("dehydrated.jsonl", "".join(json.dumps(t, ensure_ascii=False) + "\n"
                                                        for t in self.dry.values()))):
            temporary = self.home / (name + ".tmp")
            temporary.write_text(text, encoding="utf-8")
            os.replace(temporary, self.home / name)
