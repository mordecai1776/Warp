# WARP2/warp2/chat_learning/certainty.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/certainty.py
#  Used by   : warp2/chat_learning/{ledger,simulate,speaker}.py; tests.
#  Uses      : (stdlib) math.
#  Description:
#    Choosing at a known point of certainty. What is best can never be
#    known; a choice is made when it is certain enough. The point is the
#    one used across the Eye: one standard error — a record's mean, less
#    and plus its standard error, is how low and how high it may truly be.
#    A record seen fewer than twice has no known spread, so it could be
#    anything (from minus to plus infinity) and is never ruled out.
#      * `bounds` — how low and how high a record may truly be;
#      * `certain_best` — the option whose low bound is at least every
#        other option's high bound, or None when no option is certainly
#        best;
#      * `could_beat` — whether anything not yet tried could still beat
#        what has been found.
#    Tensegrity makes its choices the same way: it measures until the
#    pattern is clear, then keeps what it measured best.
#  User intention (Andrew, 2026-09-20): "you cant ever know what is best
#    ever on anything. You have to make a choice at a known point of
#    certainty. That was what the entire tensegrity system was meant to
#    provide and in the view of the absolute add that way of thinking to
#    the situation."
# ============================================================================
"""Choices made at a known point of certainty."""
from __future__ import annotations

import math


def bounds(mean: float, square: float, count: int) -> tuple:
    """Intention: (low, high) — the mean less and plus one standard error; unbounded below two measures."""
    if count < 2:
        return (-math.inf, math.inf)
    error = math.sqrt(max(square, 0.0) / (count - 1) / count)
    return (mean - error, mean + error)


def certain_best(options: dict):
    """Intention: the option (by its (low, mean, high)) certainly best — its low at least every other's high — or None."""
    if not options:
        return None
    best = max(sorted(options), key=lambda k: options[k][1])
    if all(options[best][0] >= high for k, (_, _, high) in options.items() if k != best):
        return best
    return None


def could_beat(found: float, untried_highs: list) -> bool:
    """Intention: whether anything not tried could still be better than what was found (its high bound above it)."""
    return any(high > found for high in untried_highs)
