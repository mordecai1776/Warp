# WARP2/warp2/chat_learning/learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/learning.py
#  Used by   : warp2/work/side/chat.py (ChatStep); tests.
#  Uses      : warp2/chat_learning/{scenario,simulate,lessons,ledger,shelf,
#              datasets,turns,lesson_share,tagging}.py (tagging: TrustReset); projects/behemoth_eye/eye/warp_eye.py
#              (through the WarpEye it is given); (stdlib) json, pathlib.
#  Description:
#    One turn of the chat's learning:
#      1. every real chat turn waiting is acted out again: every model
#         answers what Andrew said, beside the answer he was given, and
#         all of it is tagged and learned from;
#      2. one scenario is acted out, chosen for what most needs teaching —
#         the tag the Eye answers worst — from the rows in use first, then
#         dehydrated rows that match, then datasets looked up — by the
#         search words a model gave for the tag, asked once — (local files,
#         the Hugging Face hub, what the web names), then made up by a
#         model; a dataset's first usable row is used and the rest of the
#         page is dehydrated;
#      3. the Eye sees it, is taught every agreed tag and to say the answers
#         that went on (lessons.py), and the ledger takes every score; the
#         Eye answers beside the models once it can speak;
#      4. a row stays in use while any tag it taught is still not answered
#         right; otherwise it is dehydrated;
#      5. every fifth scenario is permanently held back: acted out and
#         scored with the Eye answering, nothing taught; its identity is
#         saved so later turns cannot select it as training data. How every
#         maker stands is written to standing.json.
#    How far each hub dataset has been read is kept, so the next page is
#    new; a page is one row, doubling while pages hold no conversation.
#    With one model, it tags the data's and the Eye's answers (never its
#    own); with none, nothing runs.
#    (2026-11-02, BUILD_LOG 1118) A row about a picture is never a
#    conversation here (datasets.about_a_picture), and the tagging trust
#    earned while silence counted as agreement is forgotten once.
#  User intention (Andrew, 2026-09-20): the chat's learning — "a simulation
#    with the other models", "start looking up datasets", "build in the
#    current active from datasets and compress the rest", "gives the best
#    to convey a said thing".
# ============================================================================
"""One turn of the chat's learning."""
from __future__ import annotations

import json
from pathlib import Path

from warp2.chat_learning import datasets
from warp2.chat_learning.lessons import said, score, score_held, see, speak, teach
from warp2.chat_learning.lesson_share import LessonShare
from warp2.chat_learning.ledger import TEACHING, Ledger
from warp2.chat_learning.scenario import from_conversation, generated
from warp2.chat_learning.shelf import Shelf, row_sha
from warp2.chat_learning.simulate import converse
from warp2.chat_learning.tagging import TrustReset
from warp2.chat_learning.turns import ChatTurns
from warp2.chat_learning.files import read_json, write_json

# Intention: the most rows the dataset viewer gives at once (its own limit,
# not ours). How many are asked for starts at one and doubles each time a
# page held no conversation, back to one when it did (`page`).
VIEWER_MOST = 100

# Intention: every fifth scenario is held back permanently — acted out and
# scored, the Eye answering, but nothing taught from it. Its identity is
# saved across turns, so it cannot later become training data.
HOLD_EVERY = 5

# Intention: what a conversation is about when nothing is known yet to be
# weak — the words datasets are looked up by, and the topic a model is
# asked to open.
OPENING = "conversation"


class ChatLearning:
    """The ledger, the shelf, and how far each dataset has been read."""

    def __init__(self, state, fleet, warp, look=None, get=datasets.get_json, seconds: float = 0.0) -> None:
        """Everything kept under state/chat_learning; `look` searches the web, `get` fetches pages.

        Intention (2026-10-15, fix 7.5): `seconds` is how long this turn's
        teaching may take (0: no limit); the step gives its share of time.
        """
        self.state, self.fleet, self.warp, self.look, self.get = Path(state), fleet, warp, look, get
        self.seconds = float(seconds or 0.0)
        self.home = self.state / "chat_learning"
        self.ledger = Ledger(self.home)
        # Intention (BUILD_LOG 1118): the trust earned while silence counted as agreement is forgotten, once.
        TrustReset(self.home, self.ledger).once()
        self.shelf = Shelf(self.home)
        held_path = self.home / "held_out.json"
        self.held_out = set(read_json(held_path, [], list))
        split_path = self.home / "scenario_splits.json"
        if split_path.is_file():
            loaded = read_json(split_path, {}, dict)
            self.scenario_splits = {str(k): bool(v) for k, v in loaded.items()}
        else:
            # Existing shelf rows may already have trained the Eye. Treat
            # them as training history when introducing the permanent split.
            self.scenario_splits = {f"row:{sha}": False for sha in
                                    (*self.shelf.active.keys(), *self.shelf.dry.keys())}
        where = self.home / "read_at.json"
        self.read_at = read_json(where, {}, dict)

    @staticmethod
    def _talk(row) -> list:
        """Intention (BUILD_LOG 1118): a row as a conversation the chat can learn — none for a row about a picture
        (datasets.about_a_picture), whose picture the models never see."""
        return [] if datasets.about_a_picture(row) else datasets.conversation_of(row)

    @staticmethod
    def _scenario_key(scenario) -> str:
        """Stable identity for a scenario, independent of which dataset copy supplied it."""
        return row_sha({"topic": scenario.topic, "opening": scenario.opening, "turns": scenario.turns,
                        "reference": scenario.reference})

    def _save_held_out(self) -> None:
        """Persist permanent evaluation scenarios so a held example never becomes training data later."""
        self.home.mkdir(parents=True, exist_ok=True)
        write_json(self.home / "held_out.json", sorted(self.held_out))

    def _save_splits(self) -> None:
        """Persist each scenario's first-use train/holdout assignment."""
        self.home.mkdir(parents=True, exist_ok=True)
        write_json(self.home / "scenario_splits.json", self.scenario_splits, sort_keys=True)

    def _held_for(self, scenario, row_sha_hint: str | None = None, count: int = 0) -> bool:
        """Assign a scenario once, before its first training or held-out pass."""
        key = f"scenario:{self._scenario_key(scenario)}"
        row_key = f"row:{row_sha_hint}" if row_sha_hint else ""
        if key in self.scenario_splits:
            return bool(self.scenario_splits[key])
        if row_key and row_key in self.scenario_splits:
            held = bool(self.scenario_splits[row_key])
        else:
            held = bool(count and count % HOLD_EVERY == 0)
        self.scenario_splits[key] = held
        if row_key:
            self.scenario_splits[row_key] = held
        self._save_splits()
        return held

    def want(self) -> str:
        """Intention: the tag the Eye answers worst of all the tags it has been taught in chat; "" when none yet."""
        taught = [t for t in self.ledger.things(TEACHING) if t in self.warp.eye.knowledge]
        if not taught:
            return ""
        return min(taught, key=lambda t: (self.warp.eye.knowledge[t].get("right_after", 0.0), t))

    def _from_active(self, want: str):
        """Intention: a row in use that teaches what is wanted (any, when nothing is)."""
        for sha, item in self.shelf.active.items():
            messages = self._talk(item["row"])
            if messages and (not want or want in item["teaches"]):
                scenario = from_conversation(messages, f"dataset:{item['source']}", [want] if want else [])
                if self._scenario_key(scenario) not in self.held_out:
                    return scenario, sha
        return None, None

    def _from_dry(self, want: str):
        """Intention: a dehydrated row that matches what is wanted, made active again."""
        for sha in self.shelf.matching(want) if want else []:
            item = self.shelf.wet(sha)
            messages = self._talk(item["row"])
            if messages:
                scenario = from_conversation(messages, f"dataset:{item['source']}", [want])
                if self._scenario_key(scenario) not in self.held_out:
                    return scenario, sha
                self.shelf.dry_out(sha)
        return None, None

    def _pages(self, words: str):
        """Intention: pages of rows for these words, cheapest first — local files, then the hub, then what the web names; each hub page is a new one."""
        yield datasets.local_rows(self.state / "datasets" / "local")
        for name in datasets.hub_search(words, self.get) + datasets.web_named(words, self.look):
            at = int(self.read_at.get(name, 0))
            size = int(self.read_at.get(f"{name}#page", 1))
            page = datasets.hub_rows(name, at, size, self.get)
            self.read_at[name] = at + len(page)
            usable = any(self._talk(r) for r in page)
            self.read_at[f"{name}#page"] = 1 if usable else min(size * 2, VIEWER_MOST)
            yield [(f"hf:{name}#{at + i}", row) for i, row in enumerate(page)]

    def _found(self, words: str, want: str = ""):
        """Rows looked up for these words, until a new one is a conversation.

        Intention: the first new row that is a conversation is used and kept
        whole; every other new row on its page is dehydrated; rows already
        on the shelf are left as they are.
        """
        for page in self._pages(words):
            chosen = None
            for source, row in page:
                if self.shelf.known(row_sha(row)):
                    continue
                messages = self._talk(row)
                scenario = (from_conversation(messages, f"dataset:{source}", [want] if want else [])
                            if messages else None)
                usable = scenario is not None and self._scenario_key(scenario) not in self.held_out
                sha = self.shelf.add(row, source, active=chosen is None and usable,
                                     teaches=[want] if want else [])
                if chosen is None and usable:
                    chosen = (scenario, sha)
            if chosen is not None:
                return chosen
        return None, None

    def query(self, want: str, models: list) -> str:
        """What to look datasets up by, for a tag: a model's search words for it, asked once and kept.

        Intention: a tag's name is a word; what it means is what the models
        said of it when they agreed on it. One model is asked for the words a
        dataset teaching it would be found by; with no answer, the tag's own
        name is used.
        """
        if not want:
            return OPENING
        where = self.home / "queries.json"
        known = read_json(where, {}, dict)
        if want not in known:
            from warp2.chat_learning.asking import ask, one_line
            words = one_line(ask(self.fleet, models[len(known) % len(models)], (
                f"Give 2 to 5 search words for finding a dataset of conversations that teach "
                f"'{want}'. Answer with only the words.")))
            known[want] = words or want
            write_json(where, known)
        return known[want]

    def scenario(self, models: list):
        """Intention: the scenario for this turn, and the shelf row it came from (None when it did not)."""
        want = self.want()
        for choose in (self._from_active, self._from_dry):
            found, sha = choose(want)
            if found is not None:
                return found, sha
        found, sha = self._found(self.query(want, models), want)
        if found is not None:
            return found, sha
        maker = models[len(self.ledger.scores) % len(models)]
        scenario = generated(self.fleet, maker, want or "an everyday question someone might ask",
                             [want] if want else [])
        if scenario is not None and self._scenario_key(scenario) in self.held_out:
            return None, None
        return scenario, None

    def _act(self, scenario, models: list, held: bool = False) -> dict:
        """Intention: one scenario acted out, seen, taught from and scored — or, held back, only scored."""
        if held:
            simulation = converse(self.fleet, scenario, models, self.ledger, self._eye_answer)
            score_held(simulation, self.ledger)
            return {"source": scenario.source, "held": True, "taught": [],
                    "answers": sum(len(s["candidates"]) for s in simulation["steps"]),
                    "eye_answered": sum(1 for s in simulation["steps"] if "eye" in s["candidates"])}
        # Intention (BUILD_LOG 1113; Andrew, 2026-10-16: "get everything in working order"): the asking runs in its
        # own part of what is left of the turn and the rest is kept for the lessons (lesson_share.py), so the say
        # lesson no longer starts after the turn is spent. A scenario held back has no lessons and keeps the turn.
        share = LessonShare(self.home)
        own = getattr(getattr(self.warp, "eye", None), "clock", None)
        # Intention (BUILD_LOG 1115, Muse-1092): the lessons claim for the rows this scenario can give (its turns,
        # each answered by the models and by the data or the Eye), then the rows it gave are filed with their cost.
        with share.asking(own, rows=int(getattr(scenario, "turns", 0) or 0) * (len(models) + 1)):
            simulation = converse(self.fleet, scenario, models, self.ledger, self._eye_answer)
        share.rows(sum(len(s["candidates"]) for s in simulation["steps"]))
        with share.lessons(own):
            seen = see(self.warp, simulation)
            taught = teach(self.warp, simulation, self.ledger, seconds=self.seconds)
            words = speak(self.warp, simulation)
        score(simulation, self.ledger)
        return {"source": scenario.source, "answers": sum(len(s["candidates"]) for s in simulation["steps"]),
                "turns": seen, "taught": taught, "words_taught": words,
                "eye_answered": sum(1 for s in simulation["steps"] if "eye" in s["candidates"])}

    def _eye_answer(self, turns: list) -> str:
        """Intention: what the Eye says after the conversation so far, once it can speak."""
        from projects.behemoth_eye.eye.heads import WEB
        if not self.warp.can_say():
            return ""
        return self.warp.say(self.warp.piece([tag for turn in turns for tag in said(turn)], WEB))

    def turn(self) -> dict:
        """Intention: real chat turns, then one scenario; the ledger, the shelf and how far datasets were read, kept."""
        models = list(self.fleet.names()) if self.fleet is not None else []
        if not models:
            return {"why": "the models answer and tag; this needs at least one"}
        done = []
        turns = ChatTurns(self.state)
        heard = turns.claim_one()
        if heard is not None:
            real = from_conversation([{"role": "user", "content": heard["said"]},
                                      {"role": "assistant", "content": heard["answered"]}], "chat")
            try:
                done.append(self._act(real, models))
            except Exception:
                # Intention (2026-10-09, fix 6.4, check E6): the turn waits
                # behind the others instead of being first again for ever, and
                # the error goes on to the step's record.
                turns.to_back(heard)
                raise
            # Intention: queued chat is learned one durable unit per pass.
            # Dataset/model scenarios wait until the real-chat backlog drains,
            # so a backlog cannot turn one pass into an unbounded batch.
            self.ledger.save()
            self.shelf.save()
            self.home.mkdir(parents=True, exist_ok=True)
            write_json(self.home / "read_at.json", self.read_at)
            standing = self.ledger.standing()
            write_json(self.home / "standing.json", standing, indent=1)
            return {"acted": done, "chat_turn": heard, "active_rows": len(self.shelf.active),
                    "dehydrated_rows": len(self.shelf.dry), "standing": standing}
        scenario, sha = self.scenario(models)
        if scenario is not None:
            count = int(self.read_at.get("(scenarios)", 0)) + 1
            self.read_at["(scenarios)"] = count
            held = self._held_for(scenario, sha, count)
            if held:
                self.held_out.add(self._scenario_key(scenario))
                self._save_held_out()
            acted = self._act(scenario, models, held=held)
            done.append(acted)
            if sha is not None and sha in self.shelf.active:
                # Intention: a row is marked with the tags it actually taught,
                # which is what it is found by when a tag is weak again.
                item = self.shelf.active[sha]
                item["teaches"] = sorted(set(item["teaches"]) | {t["tag"] for t in acted["taught"]})
                weak = [t for t in acted["taught"] if t["right_after"] < 1.0]
                if not weak:
                    self.shelf.dry_out(sha)
        self.ledger.save()
        self.shelf.save()
        self._save_held_out()
        write_json(self.home / "read_at.json", self.read_at)
        standing = self.ledger.standing()
        write_json(self.home / "standing.json", standing, indent=1)
        return {"acted": done, "active_rows": len(self.shelf.active), "dehydrated_rows": len(self.shelf.dry),
                "standing": standing}
