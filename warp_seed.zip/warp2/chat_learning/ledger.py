# WARP2/warp2/chat_learning/ledger.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/ledger.py
#  Used by   : warp2/chat_learning/{simulate,learning,tagging}.py; tests.
#  Uses      : (stdlib) json, os, pathlib.
#  Description:
#    The teaching ledger: the scores of everything that teaches, by what it
#    is meant to teach. Three kinds of score are kept, each as an exact
#    running mean and its count:
#      * teaching — how much an answer (or a dataset row) lowered the rest
#        of its set's loss when the Eye was taught one tag from it (from
#        the tensegrity map), kept for whoever made it;
#      * conveying — the agreed weight a speaker's answer earned for a thing
#        it was meant to convey;
#      * tagging — how far a model's tags matched what the taggers agreed;
#      * held — the agreed weight an answer earned on a scenario held back
#        (nothing was taught from it), so for the Eye it is what it does
#        on what it has never been taught — its real measure.
#    From these it values how well an answer conveys a thing (`conveys`):
#    its own agreed weight for it, plus what its maker has taught and
#    conveyed of it before, each counted by how much it has been seen (a
#    mean seen n times counts n/(n+1)) — the best answer is the one with
#    the highest value (simulate.py). It also gives each tagger's trust.
#    Each record also keeps its spread (Welford's sum of squares), so how
#    low and how high it may truly be is known (`bounds`, certainty.py).
#    Records of one kind can be forgotten whole (forget, BUILD_LOG 1118).
#    Kept whole in state/chat_learning/ledger.json.
#  User intention (Andrew, 2026-09-20): "There should be a system for all of
#    this that takes in their scores from what they are meant to teach and
#    gives the best to convey a said thing."
# ============================================================================
"""Scores by what each source is meant to teach, and the best to convey a thing."""
from __future__ import annotations

import json
import os
from pathlib import Path
from warp2.chat_learning.files import read_json

TEACHING, CONVEYING, TAGGING, HELD = "teaching", "conveying", "tagging", "held"


class Ledger:
    """Running means of every source's scores, by kind and thing."""

    def __init__(self, home=None) -> None:
        """Intention: read from its file when it has one."""
        self.path = Path(home) / "ledger.json" if home is not None else None
        self.scores: dict = {}
        if self.path is not None and self.path.is_file():
            self.scores = read_json(self.path, {}, dict)

    @staticmethod
    def _key(kind: str, source: str, thing: str) -> str:
        """Intention: one line of the ledger."""
        return f"{kind}|{source}|{thing}"

    def add(self, kind: str, source: str, thing: str, value: float) -> None:
        """Intention: one more measure, folded into the running mean exactly."""
        row = self.scores.setdefault(self._key(kind, source, thing), {"mean": 0.0, "count": 0})
        before = row["mean"]
        row["count"] += 1
        row["mean"] += (float(value) - before) / row["count"]
        row["square"] = row.get("square", 0.0) + (float(value) - before) * (float(value) - row["mean"])

    def mean(self, kind: str, source: str, thing: str) -> tuple:
        """Intention: (mean, count) — (0, 0) for what was never measured."""
        row = self.scores.get(self._key(kind, source, thing))
        return (row["mean"], row["count"]) if row else (0.0, 0)

    def bounds(self, kind: str, source: str, thing: str) -> tuple:
        """Intention: how low and how high a record may truly be, at one standard error (certainty.py)."""
        from warp2.chat_learning.certainty import bounds
        row = self.scores.get(self._key(kind, source, thing))
        return bounds(row["mean"], row.get("square", 0.0), row["count"]) if row else bounds(0.0, 0.0, 0)

    def weighed(self, kind: str, source: str, thing: str) -> float:
        """Intention: a mean counted by how much it was seen — n/(n+1) of it, so one lucky measure counts half."""
        mean, count = self.mean(kind, source, thing)
        return mean * count / (count + 1.0)

    def trust(self, model: str) -> float:
        """Intention: how much a tagger's word counts — its tags' match with agreement, weighed by how often it has tagged; one until it has."""
        mean, count = self.mean(TAGGING, model, "*")
        return (mean * count + 1.0) / (count + 1.0)

    def conveys(self, maker: str, thing: str, weight: float) -> float:
        """How well an answer conveys a thing.

        Intention: its own agreed weight for the thing, plus what its maker
        has taught and conveyed of the thing before, each weighed by how
        much it has been seen — the value the best answer is chosen by.
        """
        return float(weight) + self.weighed(TEACHING, maker, thing) + self.weighed(CONVEYING, maker, thing)

    def held(self, maker: str, thing: str, weight: float) -> float:
        """Intention: how well an answer conveys a thing, judged on what was held back — its weight plus its maker's held record, weighed by how much."""
        return float(weight) + self.weighed(HELD, maker, thing)

    def standing(self) -> dict:
        """Intention: for every maker, its mean conveying and its mean on held-back scenarios over every thing it was scored on, with how many — how the Eye stands against the models."""
        rows: dict = {}
        for key, row in self.scores.items():
            kind, source, _ = key.split("|", 2)
            if kind in (CONVEYING, HELD):
                slot = rows.setdefault(source, {CONVEYING: [0.0, 0], HELD: [0.0, 0]})[kind]
                slot[0] += row["mean"] * row["count"]
                slot[1] += row["count"]
        return {m: {k: {"mean": (v[0] / v[1]) if v[1] else None, "count": v[1]} for k, v in r.items()}
                for m, r in sorted(rows.items())}

    def things(self, kind: str = TEACHING) -> set:
        """Intention: every thing anything has been scored on."""
        return {key.split("|", 2)[2] for key in self.scores if key.startswith(kind + "|")}

    def forget(self, kind: str) -> int:
        """Intention (BUILD_LOG 1118): every record of one kind dropped; how many. For records earned under a
        rule found wrong (tagging.py TrustReset)."""
        gone = [key for key in self.scores if key.startswith(kind + "|")]
        for key in gone:
            del self.scores[key]
        return len(gone)

    def save(self) -> None:
        """Intention: written whole under a temporary name and moved into place."""
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(self.path.name + ".tmp")
        temporary.write_text(json.dumps(self.scores, ensure_ascii=False), encoding="utf-8")
        os.replace(temporary, self.path)
