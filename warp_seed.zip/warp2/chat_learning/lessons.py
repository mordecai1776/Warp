# WARP2/warp2/chat_learning/lessons.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/lessons.py
#  Used by   : warp2/chat_learning/learning.py; tests.
#  Uses      : projects/behemoth_eye/eye/warp_eye.py (WarpEye: the Eye, its
#              pieces; learn_to_say; the Eye's train_set and block_set),
#              projects/behemoth_eye/eye/heads (WEB; web.TOKEN),
#              projects/behemoth_eye/eye/tensegrity/trainable.py
#              (TrainingBudgetExpired), warp2/chat_learning/{ledger,tagging}.py.
#  Description:
#    The Eye learning from one acted-out conversation.
#      1. It sees the conversation as it went, one turn at a time, as one
#         continuing source (chat is continual input): each turn is a web —
#         who said it, what they said (its words are tokens), and the tags
#         the models agreed it is — with the previous response beside it,
#         so the previous response part is formed from the conversation
#         itself.
#      2. Every tag agreed on any answer is taught from every answer given
#         at every step: the answers it was agreed on are what it is, the
#         others what it is not. An answer is taught from its words alone,
#         never its tags, so what is learned is what the words show. A tag
#         the Eye has no concept for gets a synthetic pair of its name (a
#         token given with no concept). Teaching is tensegrity's, in the
#         time the turn was given; a tag out of time is taught as one
#         weighted block (fix 7.5).
#      3. It is taught to say the answer that went on at each step, after
#         the conversation before it (`speak`) — the Eye's own voice, which
#         then answers beside the models and is tagged like them.
#      4. The ledger keeps, for whoever gave each answer, how much it taught
#         each tag (from the map) and how strongly it conveyed it, and for
#         each tagger how well its tags matched what was agreed.
#  User intention (Andrew, 2026-09-20): "we can have them all learn off of
#    this and form the previous response part from this".
# ============================================================================
"""What the Eye learns from a conversation the models acted out."""
from __future__ import annotations

from warp2.chat_learning.ledger import CONVEYING, TAGGING, TEACHING
from warp2.chat_learning.tagging import matched

PREVIOUS = "previous response"


def said(turn: dict, agreed: list = ()) -> list:
    """Intention: one turn as tags for the web: who said it, what they said, and (when seen, not taught) what it was agreed to be."""
    return [{"name": str(turn["role"]), "weight": 1.0, "says": str(turn["text"]),
             "why": f"said by {turn.get('speaker', '')}",
             "holds": [{"name": t["name"], "weight": float(t["weight"]), "holds": []} for t in agreed]}]


def see(warp, simulation: dict) -> int:
    """Intention: the conversation as it went, as one continuing source, each turn with the previous response beside it."""
    from projects.behemoth_eye.eye.heads import WEB
    agreed_at = {}
    for step in simulation["steps"]:
        agreed_at[len(step["context"])] = step["candidates"][step["chosen"]]["agreed"]
    warp.eye.new_instance()
    warp.eye.new_source()
    previous = None
    for at, turn in enumerate(simulation["turns"]):
        piece = warp.piece(said(turn, agreed_at.get(at, [])), WEB)
        warp.eye.see(piece, continuing=True, alongside={PREVIOUS: previous} if previous is not None else None)
        previous = piece
    return len(simulation["turns"])


def _now() -> float:
    """Intention: the clock teaching is timed by, one place so a test can set it."""
    import time
    return time.monotonic()


def _taught_one(eye, name: str, pieces: list, made: int, limit: int, left: float | None) -> dict:
    """One tag taught: its map in the time left, or one weighted block when there is none or it runs out.

    Intention (2026-10-15, fix 7.5, as check C6 for the Eye's raw training):
    `left` None is no limit (the map, as before); 0 or less starts no map.
    """
    from projects.behemoth_eye.eye.tensegrity.trainable import TrainingBudgetExpired
    if left is not None and left <= 0.0:
        return eye.block_set(name, pieces, made=made)
    try:
        return eye.train_set(name, pieces, made=made, limit=limit, seconds=left or 0.0)
    except TrainingBudgetExpired:
        return eye.block_set(name, pieces, made=made)


def teach(warp, simulation: dict, ledger, made: int = 1, limit: int = 1, seconds: float = 0.0) -> list:
    """Every agreed tag taught from every answer given, and what each answer taught kept in the ledger.

    Intention (2026-10-15, fix 7.5): THE TURN'S TIME. `seconds` > 0 is how
    long this teaching may take; each tag's map is given what is left, and a
    tag out of time is taught as one weighted block (the Eye's `block_set`),
    so the turn still teaches every tag and hands back on time. 0 is no
    limit. Measured: one chat turn's maps ran over 10 minutes in the runner.
    Intention (fix 7.7): the ledger keeps how much an answer taught only when
    the map measured it — a block measures no answer's share.
    """
    from projects.behemoth_eye.eye.heads import WEB
    eye = warp.eye
    ends = _now() + float(seconds) if seconds and seconds > 0 else None
    answers = []
    for step in simulation["steps"]:
        for c in step["candidates"].values():
            piece = warp.piece(said({"role": "assistant", "text": c["text"], "speaker": c["speaker"]}), WEB)
            answers.append((piece, {t["name"]: t["weight"] for t in c["agreed"]}, c["speaker"]))
    taught = []
    for name in sorted({n for _, weights, _ in answers for n in weights}):
        pieces = [(piece, weights.get(name, 0.0) > 0.0) for piece, weights, _ in answers]
        if all(is_it for _, is_it in pieces) or not any(is_it for _, is_it in pieces):
            continue
        name = eye.named(name)
        if name not in eye.concepts.pairs:
            pair = eye.concepts.add_synthetic(name, "the models' agreement")
            eye.concept_activation.join(pair.name)
            eye.growth.record("synthetic", pair.name, "a tag the models agreed on, with no concept")
        knowledge = _taught_one(eye, name, pieces, made, limit, None if ends is None else ends - _now())
        for (_, is_it), (_, _, speaker), measured in zip(pieces, answers, knowledge["pieces"]):
            if is_it and "teaches" in measured:
                ledger.add(TEACHING, speaker, name, measured["teaches"])
        taught.append({"tag": name, "answers": len(pieces), "right_before": knowledge["right_before"],
                       "right_after": knowledge["right_after"]})
    return taught


def speak(warp, simulation: dict) -> int:
    """The Eye taught to say each answer that went on, after the conversation before it.

    Intention: the answer the models agreed conveyed best is what the Eye
    learns to say (WarpEye.learn_to_say), word by word, with the
    conversation so far as what it answers — so it learns to speak from the
    best of what every model said.
    """
    from projects.behemoth_eye.eye.heads import WEB
    from projects.behemoth_eye.eye.heads.web import TOKEN
    taught = 0
    for step in simulation["steps"]:
        prompt = warp.piece([tag for turn in step["context"] for tag in said(turn)], WEB)
        chosen = step["candidates"][step["chosen"]]
        conveys = [t["name"] for t in chosen["agreed"] if t["weight"] > 0.0]
        taught += warp.learn_to_say(prompt, TOKEN.findall(chosen["text"]), conveys)
    return taught


def score_held(simulation: dict, ledger) -> None:
    """Intention: a held-back scenario's answers scored under "held" only — nothing is taught from it, so the Eye's score there is what it does on what it was never taught."""
    from warp2.chat_learning.ledger import HELD
    for step in simulation["steps"]:
        for c in step["candidates"].values():
            for tag in c["agreed"]:
                ledger.add(HELD, c["speaker"], tag["name"], tag["weight"])


def score(simulation: dict, ledger) -> None:
    """Intention: how strongly each answer conveyed each agreed tag, and how well each tagger's tags matched agreement."""
    for step in simulation["steps"]:
        for c in step["candidates"].values():
            for tag in c["agreed"]:
                ledger.add(CONVEYING, c["speaker"], tag["name"], tag["weight"])
            for model, tags in c["by"].items():
                ledger.add(TAGGING, model, "*", matched(tags, c["agreed"]))
