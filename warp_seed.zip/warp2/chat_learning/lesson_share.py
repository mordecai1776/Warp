# WARP2/warp2/chat_learning/lesson_share.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/lesson_share.py
#  Used by   : warp2/chat_learning/learning.py (ChatLearning._act);
#              warp2/chat_learning/tests/test_the_say_lesson_keeps_its_share.py.
#  Uses      : projects/behemoth_eye/eye/turn_clock.py (the turn's one clock),
#              projects/behemoth_eye/eye/turn_split.py (a turn split by
#              measured pace), warp2/chat_learning/files.py; (stdlib) time,
#              contextlib, pathlib.
#  Description:
#    A chat turn has two parts: asking the models (the conversation, its
#    answers and their tags) and the lessons (the Eye sees it, is taught the
#    agreed tags, and learns to say the answers). Before this, the asking ran
#    until the turn's clock was spent, so the lessons began with no time
#    left: the say lesson got one step, never more (BUILD_LOG 1102 did
#    nothing live). Now the asking runs inside its own part of what is left
#    of the turn, and the rest is kept for the lessons. The parts are split
#    by what each part took last time (turn_split.split); with nothing
#    measured yet, each gets half. What each part took is kept in
#    state/chat_learning/lesson_pace.json.
#    BUILD_LOG 1115 (Muse-1092): the lessons' claim is what finishing this
#    set takes - the rows expected this turn times the latest cost of one
#    row, never less than one row - not just what the last set took, so a
#    small set that finished early does not shrink the share a bigger set
#    needs next. Rows, cost per row and both claims are filed each turn.
#    BUILD_LOG 1117 (Muse-1093, Antigravity-306): starting a lesson costs a
#    fixed setup before the first row (measured 2.5-5 s on the RTX 5060), so
#    the claim is setup + rows x cost per row, with the setup its own field.
#    The setup starts at the measured upper end (5 s) and is replaced by the
#    straight line through the two newest turns that ran to their end with
#    different row counts. A turn cut short by the clock is filed as not
#    full and moves neither the line nor the cost per row. Rows given over
#    rows expected is filed as a reading beside the claim, never inside it.
#  User intention (Andrew, 2026-10-16: "get everything in working order";
#    2026-09-24: "if a limit really has to exist, make it adaptive";
#    2026-10-02: "long waits for a possible failure are not acceptable -
#    split work into more small directed parts"). Found 2026-11-03 from
#    late_train_chat_1793673029.txt: the whole 12-minute turn went to asking
#    and tagging; the say lesson came after the turn was spent.
# ============================================================================
"""The share of a chat turn kept for its lessons."""
from __future__ import annotations

import time
from contextlib import contextmanager
from pathlib import Path

from warp2.chat_learning.files import read_json, write_json

# Intention: where what each part of the last turn took is kept, under state/chat_learning.
PACE = "lesson_pace.json"
# Intention (Antigravity-306): seconds a lesson takes before its first row, measured 2.5-5 s on the RTX 5060; the
# upper end, so a small set never under-claims, until two full turns measure it (BUILD_LOG 1117).
SETUP_GUESS = 5.0
# Intention: how many full turns' (rows, seconds) points are kept for the line; only the newest two are used.
KEEP_POINTS = 8


def _positive(value) -> float | None:
    """Intention: a measured number above nought, or None (a bool, a missing or a bad value is not a measure)."""
    if isinstance(value, (int, float)) and not isinstance(value, bool) and value == value and value > 0.0:
        return float(value)
    return None


def line(points: list) -> tuple[float, float] | None:
    """(cost per row, setup) from the newest point and the newest earlier point with a different row count.

    Intention (Muse-1093): the straight line through two full turns of different sizes measures the setup apart from
    the cost of a row. None when there are not two such points, or the line is not sensible (cost per row not above
    nought, or setup below nought) - then the claim keeps its upper bound rather than trusting noise.
    """
    good = [(int(p[0]), float(p[1])) for p in points
            if isinstance(p, (list, tuple)) and len(p) == 2 and _positive(p[0]) and _positive(p[1])]
    if len(good) < 2:
        return None
    n2, t2 = good[-1]
    for n1, t1 in reversed(good[:-1]):
        if n1 != n2:
            per_row = (t2 - t1) / (n2 - n1)
            setup = t2 - n2 * per_row
            return (per_row, setup) if per_row > 0.0 and setup >= 0.0 else None
    return None


def _now() -> float:
    """Intention: the clock the parts are measured by, one place so a test can set it."""
    return time.monotonic()


def _left(own=None) -> float | None:
    """Seconds left in the turn: the sooner of the process's turn (turn_clock.current) and `own` (the Eye's clock).

    Intention: the chat step opens its turn on the Eye (warp2/work/side/chat.py `warp.eye.within`), and the side
    steps' door may open one for the process; the lessons read both (warp_eye `_turn_over`), so both are read here.
    None when neither has an end — no limit, as before.
    """
    from projects.behemoth_eye.eye.turn_clock import current
    lefts = [c.left() for c in (current(), own) if c is not None and getattr(c, "deadline", None) is not None]
    return min(lefts) if lefts else None


class LessonShare:
    """Intention: what the asking and the lessons of the last chat turn took, and the asking's part of this one."""

    def __init__(self, home) -> None:
        """Intention: the measured parts, read from state/chat_learning/lesson_pace.json (empty when none yet)."""
        self.path = Path(home) / PACE
        self.took = read_json(self.path, {}, dict)

    def lessons_claim(self, rows: int | None = None) -> float | None:
        """Seconds the lessons claim for `rows` expected rows; None when nothing is measured yet.

        Intention (Muse-1092, BUILD_LOG 1115): what finishing this set takes - `rows` times the latest cost of one
        row (`per_row`), floored at one row - so the claim follows the size of the set in hand, not how soon the
        last, perhaps smaller, set was done. BUILD_LOG 1117 (Muse-1093): plus the setup a lesson pays before its
        first row (`setup`). Before a cost per row is measured, or with no rows given, it is what the lessons took
        last time, as before.
        """
        per_row = _positive(self.took.get("per_row"))
        if rows and per_row is not None:
            return self.setup() + max(1, int(rows)) * per_row
        return self.took.get("lessons")

    def setup(self) -> float:
        """Intention (BUILD_LOG 1117): the measured setup when the line has given one, else the start guess."""
        value = self.took.get("setup")
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value == value and value >= 0.0:
            return float(value)
        return SETUP_GUESS

    def asking_part(self, left: float | None, rows: int | None = None) -> float | None:
        """The asking's seconds of `left`; None is no limit (no turn, as before). `rows`: rows the lessons expect.

        Intention: split by what each part claims (the asking: what it took last time; the lessons: lessons_claim),
        so neither is set by hand; with nothing measured yet, half each (turn_split.split's rule for unmeasured
        claims). Both claims are filed, beside what each then took.
        """
        from projects.behemoth_eye.eye.turn_split import split
        if left is None:
            return None
        claims = {"asking": self.took.get("asking"), "lessons": self.lessons_claim(rows)}
        self.took["claims"] = dict(claims)
        self.took["expected_rows"] = rows
        return split(left, claims)["asking"]

    def rows(self, count: int) -> None:
        """Intention: the rows the lessons are about to learn (answers given this turn); their cost is filed after."""
        self.took["rows"] = max(0, int(count))

    @contextmanager
    def asking(self, own=None, rows: int | None = None):
        """Intention: the asking runs inside its own part of the turn (`own` is the Eye's clock; `rows` the rows the
        lessons expect); what it took is measured."""
        from projects.behemoth_eye.eye.turn_clock import turn
        started = _now()
        part = self.asking_part(_left(own), rows)
        try:
            if part is None:
                yield None
            else:
                # Intention: at least a sliver, so a part of nought is not read as "no limit" by TurnClock.
                with turn(max(part, 1e-3)) as clock:
                    yield clock
        finally:
            self.took["asking"] = _now() - started

    @contextmanager
    def lessons(self, own=None):
        """Intention: the lessons run on the rest of the turn; what they took, and the seconds left when they began
        (`left_at_start`; nought means the asking spent the turn), are kept with what the asking took."""
        started = _now()
        self.took["left_at_start"] = _left(own)
        try:
            yield
        finally:
            self.took["lessons"] = _now() - started
            self._measure(_left(own))
            write_json(self.path, self.took, indent=1)

    def _measure(self, left_at_end: float | None) -> None:
        """Intention (BUILD_LOG 1115, 1117): file what this turn's lessons say about the next turn's claim.

        A turn is full when the lessons began with time left and ended with time left (None is no limit). Only a
        full turn adds its (rows, seconds) point and moves the cost per row and the setup, so an early stop does not
        bend the line (Muse-1093). Before the line exists, the cost per row is the seconds over the rows, setup
        included - an upper bound. Rows given over rows expected (`ratio`) is a reading only.
        """
        took = self.took
        rows = int(took.get("rows") or 0)
        expected = int(took.get("expected_rows") or 0)
        took["ratio"] = rows / expected if expected > 0 else None
        start = took.get("left_at_start")
        full = (start is None or start > 0.0) and (left_at_end is None or left_at_end > 0.0)
        took["full"] = bool(full)
        if not full or rows <= 0:
            return
        points = [p for p in took.get("points") or [] if isinstance(p, (list, tuple)) and len(p) == 2]
        took["points"] = (points + [[rows, took["lessons"]]])[-KEEP_POINTS:]
        found = line(took["points"])
        if found is None:
            took["per_row"] = took["lessons"] / rows
            took["setup_from"] = "guess"
        else:
            took["per_row"], took["setup"] = found
            took["setup_from"] = "line"
