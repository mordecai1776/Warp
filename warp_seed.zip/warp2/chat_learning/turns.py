# WARP2/warp2/chat_learning/turns.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/turns.py
#  Used by   : warp2/ask/talk.py (every chat turn is kept),
#              warp2/chat_learning/learning.py (and taught); tests.
#  Uses      : (stdlib) json, os, pathlib.
#  Description:
#    Real chat turns, waiting to be learned from. Each turn of the WARP's
#    chat — what Andrew said and what was answered — is added at once
#    (cheap: one line), and the chat's learning takes them all and clears
#    them, so a turn is learned from once and nothing piles up.
#    Kept in state/chat_learning/turns.jsonl. A line that is not a whole turn
#    is set aside in turns.set_aside.jsonl, kept whole; a turn whose learning
#    fails waits behind the others (fix 6.4, check E6).
#  User intention (Andrew, 2026-09-20): "update the chat on all of this" —
#    the Eye in the chat's loop.
# ============================================================================
"""Real chat turns, kept until they are learned from."""
from __future__ import annotations

import json
import os
from pathlib import Path


class ChatTurns:
    """The chat turns not yet learned from."""

    def __init__(self, state) -> None:
        """Intention: beside the rest of the chat's learning."""
        self.path = Path(state) / "chat_learning" / "turns.jsonl"

    def add(self, said: str, answered: str, thread: str = "") -> None:
        """Intention: one turn, added as one line."""
        if not str(said or "").strip() or not str(answered or "").strip():
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as out:
            out.write(json.dumps({"said": str(said), "answered": str(answered), "thread": str(thread)},
                                 ensure_ascii=False) + "\n")

    def take(self) -> list:
        """Intention: every waiting turn, and the file cleared, so each is learned from once."""
        moved = self.path.with_name(self.path.name + ".taking")
        turns = []
        # Intention: turns taken by a run that stopped before it cleared them
        # are taken first, so none is lost and none is taken twice.
        for source in (moved, self.path):
            if not source.is_file():
                continue
            if source == self.path:
                os.replace(self.path, moved)
            turns += [json.loads(line) for line in moved.read_text(encoding="utf-8").splitlines()
                      if line.strip()]
            moved.unlink()
        return turns

    @property
    def _taking(self) -> Path:
        """Intention: where turns wait while they are being learned from."""
        return self.path.with_name(self.path.name + ".taking")

    @property
    def set_aside_path(self) -> Path:
        """Intention: where lines that are not a whole turn are kept, beside the turns."""
        return self.path.with_name("turns.set_aside.jsonl")

    @staticmethod
    def _readable(line: str) -> dict | None:
        """Intention: the line as a turn (a dict with words said and answered), or None when it is not one."""
        try:
            turn = json.loads(line)
        except ValueError:
            return None
        if not isinstance(turn, dict) or not isinstance(turn.get("said"), str) \
                or not isinstance(turn.get("answered"), str):
            return None
        return turn

    def _set_aside(self, lines: list) -> None:
        """Intention: lines that are not a turn kept whole in their own file — never deleted, never in the way."""
        if not lines:
            return
        with self.set_aside_path.open("a", encoding="utf-8") as out:
            out.write("".join(line + "\n" for line in lines))

    def _write_taking(self, lines: list) -> None:
        """Intention: the waiting turns written whole (temporary file, then moved into place), or the file gone when none wait."""
        text = "\n".join(lines).strip()
        if not text:
            if self._taking.is_file():
                self._taking.unlink()
            return
        temporary = self._taking.with_name(self._taking.name + ".tmp")
        temporary.write_text(text + "\n", encoding="utf-8")
        os.replace(temporary, self._taking)

    def _waiting_lines(self) -> list:
        """Intention: the lines waiting in `.taking` (the turns file moved there first if needed)."""
        if not self._taking.is_file() and self.path.is_file():
            os.replace(self.path, self._taking)
        if not self._taking.is_file():
            return []
        return [line for line in self._taking.read_text(encoding="utf-8").splitlines() if line.strip()]

    def claim_one(self) -> dict | None:
        """The first whole turn waiting, left durably in `.taking` until its learning is saved; None when none waits.

        Intention (2026-10-09, fix 6.4, check E6): ONE BAD LINE NO LONGER
        BLOCKS THE REST. A line cut short by a crash mid-append (or one that is
        not a whole turn) raised on every claim, so chat learning stopped for
        ever. Lines before the first whole turn that are not turns are set
        aside, whole, in their own file, and the turn after them is taken.
        """
        lines = self._waiting_lines()
        bad = []
        for at, line in enumerate(lines):
            turn = self._readable(line)
            if turn is None:
                bad.append(line)
                continue
            if bad:
                self._set_aside(bad)
                self._write_taking(lines[at:])
            return turn
        self._set_aside(bad)
        self._write_taking([])
        return None

    def _without(self, lines: list, claimed: dict) -> tuple:
        """Intention: the lines with the first one holding the claimed turn taken out, and that line ("" when not found)."""
        for index, line in enumerate(lines):
            if self._readable(line) == claimed:
                return lines[:index] + lines[index + 1:], line
        return lines, ""

    def complete(self, claimed: dict) -> None:
        """Intention: remove the claimed turn only after its learned state was saved."""
        if not self._taking.is_file():
            return
        lines = self._taking.read_text(encoding="utf-8").splitlines()
        rest, found = self._without(lines, claimed)
        if found:
            self._write_taking(rest)

    def to_back(self, claimed: dict) -> None:
        """The claimed turn moved behind every other waiting turn.

        Intention (2026-10-09, fix 6.4, check E6): a turn whose learning fails
        stayed first, so it was claimed and failed on every pass and no other
        turn was learned from. It now waits behind the others and is tried
        again after them; nothing is dropped.
        """
        if not self._taking.is_file():
            return
        lines = self._taking.read_text(encoding="utf-8").splitlines()
        rest, found = self._without(lines, claimed)
        if found:
            self._write_taking(rest + [found])
