# WARP2/warp2/chat_learning/tests/test_the_say_lesson_keeps_its_share.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/test_the_say_lesson_keeps_its_share.py
#  Used by   : pytest; WARP2/CHECK_FIXES.bat.
#  Uses      : warp2/chat_learning/{learning,lesson_share}.py,
#              projects/behemoth_eye/eye/turn_clock.py.
#  Description:
#    BUILD_LOG 1113: a chat turn's asking runs in its own part of the turn and
#    the rest is kept for the lessons, so the say lesson does not start after
#    the turn is spent. Fails on the old code: the stand-in asking runs until
#    the turn is over, and the say lesson then starts with no time left.
#  User intention (Andrew, 2026-10-16: "get everything in working order";
#    2026-09-24: "if a limit really has to exist, make it adaptive").
# ============================================================================
from __future__ import annotations

import time

from projects.behemoth_eye.eye.turn_clock import TurnClock, over, turn
from warp2.chat_learning import learning as chat
from warp2.chat_learning.lesson_share import LessonShare
from warp2.chat_learning.scenario import Scenario


def _asking_until_spent(fleet, scenario, models, ledger, eye=None):
    """Intention: a conversation that keeps asking until the turn is over, as live (simulate._out_of_turn)."""
    while not over(None):
        time.sleep(0.005)
    return {"turns": [], "steps": []}


def _scenario():
    """Intention: any scenario; the stand-ins never read it."""
    return Scenario(source="test", opening="hello", topic="greeting", turns=1, reference=[], teaches=[])


def test_the_say_lesson_starts_with_time_left(tmp_path, monkeypatch):
    """Intention: with the asking taking all it is given, the lessons still start inside the turn."""
    at_lesson = {}

    def speak(warp, simulation):
        """Intention: the say lesson notes whether the turn was already over when it began."""
        at_lesson["over"] = over(getattr(warp.eye, "clock", None))
        return 0

    monkeypatch.setattr(chat, "converse", _asking_until_spent)
    monkeypatch.setattr(chat, "see", lambda warp, simulation: 0)
    monkeypatch.setattr(chat, "teach", lambda warp, simulation, ledger, seconds=0.0: [])
    monkeypatch.setattr(chat, "speak", speak)
    monkeypatch.setattr(chat, "score", lambda simulation, ledger: None)
    eye = type("Eye", (), {"clock": TurnClock(0.6)})()
    warp = type("Warp", (), {"eye": eye})()
    learning = chat.ChatLearning(tmp_path, None, warp, seconds=0.6)
    with turn(0.6):
        learning._act(_scenario(), ["m"])
    assert at_lesson["over"] is False
    took = LessonShare(tmp_path / "chat_learning").took
    assert took["asking"] > 0.0 and "lessons" in took and took["left_at_start"] > 0.0


def test_the_parts_follow_what_each_took(tmp_path):
    """Intention: half each with nothing measured; then in proportion to what each part took last time."""
    share = LessonShare(tmp_path)
    assert abs(share.asking_part(10.0) - 5.0) < 1e-9
    share.took = {"asking": 3.0, "lessons": 1.0}
    assert abs(share.asking_part(8.0) - 6.0) < 1e-9


def test_no_turn_is_no_limit(tmp_path):
    """Intention: outside a turn the asking is not limited, as before."""
    share = LessonShare(tmp_path)
    with share.asking() as clock:
        assert clock is None
