# WARP3/warp2/chat_learning/tests/test_held_scenarios_get_a_turn.py
#
# Pathway   : warp2/chat_learning/tests/test_held_scenarios_get_a_turn.py
# Used by   : pytest; CHECK_FIXES.bat.
# Uses      : chat_learning learning, scenario; test_chat_learning's fake fleet.
# Description: Repeated training cannot consume the held-back evaluation turn.
# User intention: Andrew, 2026-11-18: fix the missing capability score.
from types import SimpleNamespace

from warp2.chat_learning.learning import ChatLearning, HOLD_EVERY
from warp2.chat_learning.scenario import from_conversation
from warp2.chat_learning.tests.test_chat_learning import _Fleet


def _ready(tmp_path):
    """Intention: a training row still active beside a permanently held, dry row."""
    made = ChatLearning(tmp_path, _Fleet(), SimpleNamespace(eye=SimpleNamespace(knowledge={})))
    train = {"dialog": ["training question", "hello training"]}
    held = {"dialog": ["unseen question", "hello unseen"]}
    train_sha = made.shelf.add(train, "train", active=True)
    held_sha = made.shelf.add(held, "held", active=False)
    training = from_conversation(made._talk(train), "dataset:train")
    testing = from_conversation(made._talk(held), "dataset:held")
    assert not made._held_for(training, train_sha, 1)
    assert made._held_for(testing, held_sha, HOLD_EVERY)
    made.held_out.add(made._scenario_key(testing))
    made.read_at["(scenarios)"] = HOLD_EVERY - 1
    return made, testing, train_sha


def test_repeated_training_cannot_starve_the_held_turn(tmp_path, monkeypatch):
    """Intention: an actual simulation scores the Eye on a held row, without any teaching."""
    made, testing, train_sha = _ready(tmp_path)
    monkeypatch.setattr(made, "_eye_answer", lambda turns: "hello friend")
    selected, _ = made.scenario(list(made.fleet.names()))
    assert made._scenario_key(selected) == made._scenario_key(testing)
    said = made.turn()
    assert said["acted"][0].get("held") is True
    assert said["acted"][0]["taught"] == []
    assert said["standing"]["eye"]["held"]["count"] > 0
    assert said["standing"]["eye"]["held"]["mean"] > 0
    assert said["acted"][0]["evaluation"]["mean"] > 0
    assert train_sha in made.shelf.active
    assert made.scenario_splits[f"scenario:{made._scenario_key(testing)}"] is True


def test_training_turn_still_uses_training_row(tmp_path):
    """Intention: evaluation never flips a trained scenario into the held set."""
    made, testing, train_sha = _ready(tmp_path)
    made.read_at["(scenarios)"] = HOLD_EVERY
    scenario, sha = made.scenario(list(made.fleet.names()))
    assert sha == train_sha
    assert made._scenario_key(scenario) != made._scenario_key(testing)
    assert not made._held_for(scenario, sha, HOLD_EVERY * 2)


def test_generated_holdout_survives_restart(tmp_path):
    """Intention: generated evaluation scenarios have recoverable content, not only a hash."""
    made, testing, _ = _ready(tmp_path)
    made._keep_evaluation(testing)
    made._save_held_out()
    again = ChatLearning(tmp_path, _Fleet(), object())
    scenario, sha = again._held_scenario(HOLD_EVERY * 2)
    assert again._scenario_key(scenario) == again._scenario_key(testing)
    assert sha is None


def test_unanswered_evaluation_is_unknown_not_zero(tmp_path, monkeypatch):
    """Intention: peer scores cannot impersonate an Eye capability measurement."""
    made, testing, _ = _ready(tmp_path)
    monkeypatch.setattr(made, "_eye_answer", lambda turns: "")
    result = made._act(testing, list(made.fleet.names()), held=True)
    assert result["evaluation"]["mean"] is None
    assert result["evaluation"]["count"] == 0
    assert result["evaluation"]["why"] == "the Eye gave no answer"


def test_existing_training_split_overrules_a_stale_held_list(tmp_path):
    """Intention: conflicting provenance must never let a trained scenario into evaluation."""
    made, testing, _ = _ready(tmp_path)
    made._keep_evaluation(testing)
    made.scenario_splits[f"scenario:{made._scenario_key(testing)}"] = False
    assert made._held_scenario(HOLD_EVERY) == (None, None)
