# WARP2/warp2/chat_learning/tests/test_silence_earns_no_trust.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/test_silence_earns_no_trust.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/chat_learning/{tagging,ledger,datasets,simulate,learning}.py.
#  Description:
#    The chat's tagging can agree again (BUILD_LOG 1118): a tagger that gives
#    no tags earns no trust, even when nothing was agreed; the trust earned
#    under the old rule is forgotten once and only once; taggers are shown
#    the names already in use; a row about a picture is no conversation for
#    the chat; and with a silent model and two that tag alike, the reply
#    gets an agreed tag.
#  User intention (Andrew, 2026-11-02): "make sure they have proper datasets
#    and that they are given proper leaning methods and test".
# ============================================================================
"""Tests that silent taggers earn no trust, names are shared, and picture rows stay out of the chat."""
from __future__ import annotations

from warp2.chat_learning import datasets
from warp2.chat_learning.ledger import CONVEYING, TAGGING, TEACHING, Ledger
from warp2.chat_learning.simulate import _tag
from warp2.chat_learning.tagging import TrustReset, agree, matched, named_already, tag_reply


def test_a_tagger_that_gives_no_tags_matches_nothing():
    """Intention: silence is 0 whether or not anything was agreed; a real match is still its overlap."""
    assert matched([], []) == 0.0 and matched([], [{"name": "x"}]) == 0.0
    assert matched([{"name": "x"}], [{"name": "x"}]) == 1.0
    assert matched([{"name": "x"}, {"name": "y"}], [{"name": "x"}]) == 0.5


def test_the_old_trust_is_forgotten_once(tmp_path):
    """Intention: tagging records dropped, the rest kept, the mark written; a second call drops nothing."""
    ledger = Ledger(tmp_path)
    ledger.add(TAGGING, "moondream", "*", 1.0)
    ledger.add(TEACHING, "model:a", "greeting", 0.5)
    assert TrustReset(tmp_path, ledger).once() == 1
    again = Ledger(tmp_path)
    assert again.mean(TAGGING, "moondream", "*") == (0.0, 0) and again.mean(TEACHING, "model:a", "greeting")[1] == 1
    again.add(TAGGING, "moondream", "*", 0.0)
    assert TrustReset(tmp_path, again).once() == 0 and again.mean(TAGGING, "moondream", "*")[1] == 1


class _Fleet:
    """Intention: a silent model and two that tag the same; it keeps the prompts it was given."""

    def __init__(self):
        self.prompts = []

    def ask(self, model, prompt):
        self.prompts.append(prompt)
        return "[]" if model == "silent" else '[{"name": "greeting", "weight": 0.8}]'


def test_a_silent_tagger_no_longer_settles_every_reply(tmp_path):
    """Intention: trusted at its old height, silence once settled the reply with nothing agreed; at no trust, the two
    that tag alike agree."""
    fleet = _Fleet()
    old = {"silent": 0.97, "a": 0.1, "b": 0.1}
    by = tag_reply(fleet, ["silent", "a", "b"], [{"role": "user", "text": "hi"}], "hello", old)
    assert agree(by, old) == [], "the old rule: silence, most trusted, outweighs both"
    ledger = Ledger(tmp_path)
    for _ in range(3):
        ledger.add(TAGGING, "silent", "*", matched([], []))
    candidate = {"speaker": "model:c", "text": "hello"}
    _tag(fleet, candidate, ["silent", "a", "b"], [{"role": "user", "text": "hi"}], ledger)
    assert [t["name"] for t in candidate["agreed"]] == ["greeting"]


def test_taggers_are_shown_the_names_in_use(tmp_path):
    """Intention: the names taught and conveyed go into the tagging prompt; none, no line."""
    assert named_already([]) == ""
    ledger = Ledger(tmp_path)
    ledger.add(TEACHING, "model:a", "greeting", 0.5)
    ledger.add(CONVEYING, "model:a", "clarification", 0.5)
    fleet = _Fleet()
    _tag(fleet, {"speaker": "model:c", "text": "hello"}, ["a"], [{"role": "user", "text": "hi"}], ledger)
    assert "Tag the reply" in fleet.prompts[0] and "clarification, greeting" in fleet.prompts[0]


def test_a_row_about_a_picture_is_no_conversation_for_the_chat():
    """Intention: the Blender rows (a picture field) are marked; a plain question and answer is not."""
    blender = {"question": "what is in this picture", "answer": "a orange glossy torus", "image": {"src": "x.png"}}
    assert datasets.about_a_picture(blender) is True
    assert datasets.about_a_picture({"question": "why?", "answer": "because", "image": ""}) is False
    from warp2.chat_learning.learning import ChatLearning
    assert ChatLearning._talk(blender) == []
    assert ChatLearning._talk({"question": "why?", "answer": "because"})[1]["content"] == "because"


def test_a_spent_turn_still_asks_one_model_beside_the_data(monkeypatch):
    """Intention (BUILD_LOG 1120): out of turn from the start, the data's answer still gets one model's beside it —
    a lesson needs two answers — and only one."""
    from warp2.chat_learning import simulate
    from warp2.chat_learning.scenario import from_conversation
    monkeypatch.setattr(simulate, "_out_of_turn", lambda: True)
    asked = []

    class _Answering(_Fleet):
        def ask(self, model, prompt):
            if "You are the assistant" in prompt:
                asked.append(model)
                return "hello there"
            return super().ask(model, prompt)

    scenario = from_conversation([{"role": "user", "content": "hi"}, {"role": "assistant", "content": "hello"}],
                                 "dataset:x")
    went = simulate.converse(_Answering(), scenario, ["a", "b", "c"], Ledger())
    candidates = went["steps"][0]["candidates"]
    assert "data" in candidates and len(asked) == 1 and len(candidates) == 2
