# WARP2/warp2/chat_learning/tests/test_a_slow_page_has_a_whole_call_time.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/test_a_slow_page_has_a_whole_call_time.py
#  Used by   : pytest.
#  Uses      : warp2/chat_learning/datasets.py (get_json); stdlib http.server,
#              threading, time.
#  Description:
#    A page that trickles in (each piece inside the per-read timeout, the
#    whole far past it) is given up at its whole-call time, not waited out;
#    a page bigger than its size is given up too; a normal page still reads.
#    Found 2026-11-02: try_eye_on_tasks sat 1412 s (3.7x its usual) in these
#    reads of a hub viewer page, holding the whole loop (BUILD_LOG 1100).
#  User intention (Andrew, 2026-10-16): get everything in working order; a
#    step should take minutes, and when it slows, find out why.
# ============================================================================
from __future__ import annotations

import http.server
import threading
import time

import pytest

from warp2.chat_learning import datasets


class _Pages(http.server.BaseHTTPRequestHandler):
    """A local server: /slow trickles a JSON page for about 6 s; /big is 2 MB; /ok is small."""

    def do_GET(self):
        """Intention: answer each test path the way its case needs."""
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        try:
            if self.path == "/slow":
                self.wfile.write(b'{"rows": [')
                for i in range(30):
                    self.wfile.write(b"%d," % i)
                    self.wfile.flush()
                    time.sleep(0.2)
                self.wfile.write(b"0]}")
            elif self.path == "/big":
                self.wfile.write(b'{"x": "' + b"a" * (2 * 1024 * 1024) + b'"}')
            else:
                self.wfile.write(b'{"ok": true}')
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def log_message(self, *args):
        """Intention: keep the test output quiet."""


@pytest.fixture
def base():
    """Intention: a local page server for one test, closed after it."""
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Pages)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{server.server_address[1]}"
    server.shutdown()
    server.server_close()


def test_a_page_that_trickles_past_its_whole_time_is_given_up(base):
    """Each piece comes well inside the 5 s per-read timeout; the whole takes ~6 s; the call gives up near 1 s."""
    started = time.monotonic()
    got = datasets.get_json(f"{base}/slow", timeout=5.0, whole=1.0)
    took = time.monotonic() - started
    assert got is None
    assert took < 3.0, f"waited {took:.1f} s for a page whose whole time was 1 s"


def test_a_page_bigger_than_its_size_is_given_up(base):
    """A 2 MB page with a 1 MB size is not read whole."""
    assert datasets.get_json(f"{base}/big", timeout=5.0, most=1024 * 1024) is None


def test_a_normal_page_still_reads(base):
    """A small page inside its time and size reads as before."""
    assert datasets.get_json(f"{base}/ok", timeout=5.0) == {"ok": True}
