# WARP2/warp2/chat_learning/tests/test_a_bad_chat_turn_is_set_aside.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/test_a_bad_chat_turn_is_set_aside.py
#  Used by   : pytest.
#  Uses      : warp2/chat_learning/{turns,learning}.py.
#  Description:
#    Fix 6.4 (check E6). One bad saved chat turn no longer blocks chat
#    learning for ever: a line that cannot be read as a turn is set aside,
#    whole, in its own file, and the next turn is taken; a turn whose
#    learning fails goes to the back of the queue, so the others are learned,
#    and its error is still raised for the record.
#  User intention (Andrew, 2026-09-20): the chat's real turns are learned
#    from. Never throw things away: a set-aside line is kept, not deleted.
# ============================================================================
from __future__ import annotations

import pytest

from warp2.chat_learning.learning import ChatLearning
from warp2.chat_learning.turns import ChatTurns


def _turns(tmp_path, *lines) -> ChatTurns:
    """Intention: a turns file holding exactly these lines."""
    turns = ChatTurns(tmp_path)
    turns.path.parent.mkdir(parents=True, exist_ok=True)
    turns.path.write_text("".join(line + "\n" for line in lines), encoding="utf-8")
    return turns


def test_a_line_cut_short_is_set_aside_and_the_next_turn_taken(tmp_path):
    """Intention (E6): a line cut short by a crash mid-append made every claim raise."""
    turns = _turns(tmp_path, '{"said": "hi", "answ')
    turns.add("what is 2+2", "4")
    assert turns.claim_one() == {"said": "what is 2+2", "answered": "4", "thread": ""}
    kept = turns.set_aside_path.read_text(encoding="utf-8").splitlines()
    assert kept == ['{"said": "hi", "answ']


def test_a_line_that_is_not_a_whole_turn_is_set_aside(tmp_path):
    """Intention: JSON that is not a turn (no said, no answered) would fail
    later at the same place every time; it is set aside too."""
    turns = _turns(tmp_path, '{"said": "only half"}', '[1, 2]',
                   '{"said": "hello", "answered": "hi", "thread": "t"}')
    assert turns.claim_one()["said"] == "hello"
    assert len(turns.set_aside_path.read_text(encoding="utf-8").splitlines()) == 2


def test_a_turn_put_back_goes_after_the_others(tmp_path):
    """Intention: a turn whose learning failed waits behind the rest."""
    turns = ChatTurns(tmp_path)
    turns.add("first", "a")
    turns.add("second", "b")
    first = turns.claim_one()
    turns.to_back(first)
    assert turns.claim_one()["said"] == "second"
    turns.complete(turns.claim_one())
    assert turns.claim_one()["said"] == "first"


class _Fleet:
    """Intention: one model, so the chat's learning runs."""

    def names(self, kind: str = "") -> list:
        return ["m"]


def test_a_turn_whose_learning_fails_goes_to_the_back_and_the_error_is_raised(tmp_path, monkeypatch):
    """Intention: the failing turn does not stay first for ever, and the
    failure is not hidden — the step's record still sees it."""
    turns = ChatTurns(tmp_path)
    turns.add("breaks", "x")
    turns.add("works", "y")

    def act(self, scenario, models):
        """Intention: learning that fails on one turn only."""
        if "breaks" in str(scenario):
            raise ValueError("this turn cannot be learned")
        return {"taught": []}

    monkeypatch.setattr(ChatLearning, "_act", act)
    learning = ChatLearning(tmp_path, _Fleet(), None, None)
    with pytest.raises(ValueError):
        learning.turn()
    assert ChatTurns(tmp_path).claim_one()["said"] == "works"
