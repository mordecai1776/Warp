# WARP2/warp2/chat_learning/tests/test_chat_teaching_has_its_turns_time.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/test_chat_teaching_has_its_turns_time.py
#  Used by   : pytest.
#  Uses      : warp2/chat_learning/{lessons,learning,ledger}.py,
#              warp2/work/side/chat.py (ChatStep), projects/behemoth_eye/eye/
#              tensegrity/trainable.py (TrainingBudgetExpired).
#  Description:
#    Fix 7.5 (and check C6 for the chat): the chat's teaching has the time its
#    turn was given. Each agreed tag's tensegrity map gets what is left; a tag
#    out of time is taught as one weighted block. The ledger keeps how much an
#    answer taught only when the map measured it. A stand-in Eye records what
#    it was asked, so these run in a moment.
#  User intention (Andrew, 2026-09-20): "we just need to have it go on for
#    less time" (the Eye's turns); fix plan 7.5: the slow chat-learning test
#    (over 10 minutes) — found to be the chat teaching with no time limit.
# ============================================================================
from __future__ import annotations

import time

from projects.behemoth_eye.eye.tensegrity.trainable import TrainingBudgetExpired
from warp2.chat_learning import lessons
from warp2.chat_learning.ledger import TEACHING, Ledger


class _Pairs(dict):
    """Intention: the Eye's concept pairs, as far as teach reads and adds them."""

    def add_synthetic(self, name, why):
        self[name] = type("Pair", (), {"name": name, "kind": "synthetic"})()
        return self[name]


class _Eye:
    """Intention: an Eye that says what it was asked; its map runs out of time when told to."""

    def __init__(self, map_takes: float) -> None:
        self.map_takes, self.calls = map_takes, []
        self.concepts = type("C", (), {"pairs": _Pairs()})()
        self.concepts.add_synthetic = self.concepts.pairs.add_synthetic
        self.concept_activation = type("A", (), {"join": lambda self, n: None})()
        self.growth = type("G", (), {"record": lambda self, *a: None})()

    def named(self, name):
        return name

    def train_set(self, name, pieces, made=0, limit=0, seconds=0.0):
        """Intention: the map, which runs out of time when it needs more than it was given."""
        self.calls.append(("map", name, seconds))
        if seconds and seconds < self.map_takes:
            raise TrainingBudgetExpired("out of time")
        return {"right_before": 0.5, "right_after": 0.75,
                "pieces": [{"teaches": 0.2} for _ in pieces]}

    def block_set(self, name, pieces, made=0):
        """Intention: the weighted block, which measures no answer's teaching."""
        self.calls.append(("block", name))
        return {"right_before": 0.5, "right_after": 0.6, "pieces": [{"loss": 0.3} for _ in pieces]}


class _Warp:
    """Intention: the WarpEye as teach reads it."""

    def __init__(self, eye) -> None:
        self.eye = eye

    def piece(self, tags, head):
        return tags


def _simulation():
    """Intention: two answers at one step, one agreed a greeting, one not."""
    def answer(text, speaker, greeting):
        return {"text": text, "speaker": speaker,
                "agreed": [{"name": "greeting", "weight": 1.0}] if greeting else [{"name": "question", "weight": 1.0}]}
    return {"steps": [{"candidates": {"model:a": answer("hello there", "a", True),
                                      "model:b": answer("what time is it", "b", False)}}]}


def test_with_time_the_map_teaches_and_the_ledger_keeps_it():
    """Intention: the map is given the time left, and what each answer taught is kept."""
    eye, ledger = _Eye(map_takes=0.0), Ledger()
    taught = lessons.teach(_Warp(eye), _simulation(), ledger, seconds=60.0)
    assert {t["tag"] for t in taught} == {"greeting", "question"}
    assert all(kind == "map" and 0.0 < seconds <= 60.0 for kind, _, seconds in eye.calls)
    assert ledger.things(TEACHING) >= {"greeting"}


def test_out_of_time_a_tag_is_taught_as_a_block_and_nothing_unmeasured_is_kept():
    """Intention: the map out of time teaches the set as one block; the
    ledger gets no "how much it taught", because nothing measured it."""
    eye, ledger = _Eye(map_takes=1e9), Ledger()
    taught = lessons.teach(_Warp(eye), _simulation(), ledger, seconds=0.5)
    assert {t["tag"] for t in taught} == {"greeting", "question"}
    assert [c[0] for c in eye.calls].count("block") == 2
    assert ledger.things(TEACHING) == set()


def test_a_tag_after_the_time_is_spent_goes_straight_to_a_block(monkeypatch):
    """Intention: once the turn's time is gone, no map is started at all."""
    eye, ledger = _Eye(map_takes=0.0), Ledger()
    clock = iter([0.0, 10.0, 10.0, 10.0, 10.0, 10.0])
    monkeypatch.setattr(lessons, "_now", lambda: next(clock))
    lessons.teach(_Warp(eye), _simulation(), ledger, seconds=5.0)
    assert [c[0] for c in eye.calls] == ["block", "block"]


def test_no_time_given_is_no_limit():
    """Intention: a call that gives no time (0) keeps the old way: the map, unbounded."""
    eye = _Eye(map_takes=1e9)
    lessons.teach(_Warp(eye), _simulation(), Ledger())
    assert [c[0] for c in eye.calls] == ["map", "map"] and all(c[2] == 0.0 for c in eye.calls)


def test_the_chat_step_gives_the_turn_its_share_of_time(tmp_path, monkeypatch):
    """Intention: the chat's turn is its share of the time since its last
    turn, as the Eye's is (warp2/work/side/eye.py `_earned`)."""
    from warp2.work.side.chat import ChatStep
    step = ChatStep(type("S", (), {"state": tmp_path})())
    step._since = time.monotonic() - 100.0
    step.share = 0.25
    assert 24.0 <= step._earned() <= 26.0
