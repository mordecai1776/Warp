# WARP2/warp2/chat_learning/tests/test_the_lessons_claim_what_finishing_takes.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/test_the_lessons_claim_what_finishing_takes.py
#  Used by   : CHECK_FIXES.bat; pytest.
#  Uses      : warp2/chat_learning/lesson_share.py, warp2/chat_learning/learning.py,
#              warp2/chat_learning/scenario.py, projects/behemoth_eye/eye/turn_clock.py.
#  Description:
#    BUILD_LOG 1115 (Muse-1092): the lessons' share of a chat turn is claimed
#    by what finishing this set takes - rows expected times the latest cost of
#    one row, at least one row - so a small set that finished early does not
#    starve a bigger set on the next turn. Rows, cost per row and claims are
#    filed in lesson_pace.json.
#    BUILD_LOG 1117: the claims here set setup 0, so they test rows x cost
#    alone; the setup has its own test (test_a_lesson_claims_its_setup.py).
#  User intention (Andrew, 2026-10-16: "get everything in working order";
#    2026-09-24: "if a limit really has to exist, make it adaptive").
# ============================================================================
from __future__ import annotations

from projects.behemoth_eye.eye.turn_clock import TurnClock, turn
from warp2.chat_learning import learning as chat
from warp2.chat_learning.lesson_share import LessonShare
from warp2.chat_learning.scenario import Scenario


def test_a_bigger_set_claims_more_than_the_small_set_took(tmp_path):
    """Intention: lessons that took 1 s for 2 rows claim 9 s for 18 rows, so the asking gets half of 10 s, not 9."""
    share = LessonShare(tmp_path)
    share.took = {"asking": 9.0, "lessons": 1.0, "per_row": 0.5, "setup": 0.0}
    assert abs(share.asking_part(10.0, rows=18) - 5.0) < 1e-9
    assert share.took["claims"] == {"asking": 9.0, "lessons": 9.0}


def test_the_claim_is_never_less_than_one_row(tmp_path):
    """Intention: a one-row set still claims one full row's cost; with no rows known, what the lessons took."""
    share = LessonShare(tmp_path)
    share.took = {"asking": 2.0, "lessons": 6.0, "per_row": 3.0, "setup": 0.0}
    assert share.lessons_claim(1) == 3.0
    assert share.lessons_claim(None) == 6.0


def test_a_turn_files_its_rows_and_their_cost(tmp_path, monkeypatch):
    """Intention: after a turn, lesson_pace.json holds the rows learned, the cost of one row and the claims made."""
    steps = [{"candidates": {"a": {}, "b": {}}}, {"candidates": {"a": {}}}]
    monkeypatch.setattr(chat, "converse", lambda *a, **k: {"turns": [], "steps": steps})
    monkeypatch.setattr(chat, "see", lambda warp, simulation: 0)
    monkeypatch.setattr(chat, "teach", lambda warp, simulation, ledger, seconds=0.0: [])
    monkeypatch.setattr(chat, "speak", lambda warp, simulation: 0)
    monkeypatch.setattr(chat, "score", lambda simulation, ledger: None)
    eye = type("Eye", (), {"clock": TurnClock(5.0)})()
    warp = type("Warp", (), {"eye": eye})()
    learning = chat.ChatLearning(tmp_path, None, warp, seconds=5.0)
    scenario = Scenario(source="test", opening="hi", topic="greeting", turns=2, reference=[], teaches=[])
    with turn(5.0):
        learning._act(scenario, ["m1", "m2"])
    took = LessonShare(tmp_path / "chat_learning").took
    assert took["rows"] == 3 and took["expected_rows"] == 6
    assert took["per_row"] == took["lessons"] / 3
    assert set(took["claims"]) == {"asking", "lessons"}
