# WARP2/warp2/chat_learning/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/__init__.py
#  Used by   : pytest (marks the chat-learning tests as a package).
#  Uses      : nothing.
#  Description:
#    Package marker for the chat-learning tests.
#  User intention (Andrew, 2026-09-20): the chat's learning system, checked
#    by running it.
# ============================================================================
