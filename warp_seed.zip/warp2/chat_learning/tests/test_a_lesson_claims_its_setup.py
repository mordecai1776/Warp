# WARP2/warp2/chat_learning/tests/test_a_lesson_claims_its_setup.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/test_a_lesson_claims_its_setup.py
#  Used by   : CHECK_FIXES.bat; pytest.
#  Uses      : warp2/chat_learning/lesson_share.py,
#              projects/behemoth_eye/eye/turn_clock.py.
#  Description:
#    BUILD_LOG 1117 (Muse-1093, Antigravity-306): a lesson pays a fixed setup
#    before its first row, so its claim is setup + rows x cost per row. The
#    setup is its own field in lesson_pace.json: 5 s until the line through
#    two full turns of different sizes measures it. A turn cut short by the
#    clock moves neither the line nor the cost per row. Rows given over rows
#    expected is filed as a reading only.
#  User intention (Andrew, 2026-10-16: "get everything in working order";
#    2026-09-24: "if a limit really has to exist, make it adaptive").
# ============================================================================
from __future__ import annotations

from warp2.chat_learning import lesson_share as ls
from warp2.chat_learning.lesson_share import SETUP_GUESS, LessonShare, line


def test_a_one_row_set_claims_the_setup_too(tmp_path):
    """Intention: at 0.8 s a row, one row claims the 5 s setup plus 0.8 s, not 0.8 s alone."""
    share = LessonShare(tmp_path)
    share.took = {"asking": 2.0, "lessons": 0.8, "per_row": 0.8}
    assert abs(share.lessons_claim(1) - (SETUP_GUESS + 0.8)) < 1e-9


def test_two_full_turns_measure_the_setup(tmp_path, monkeypatch):
    """Intention: 4 rows in 7 s and 10 rows in 13 s give 1 s a row and a 3 s setup, filed apart."""
    share = LessonShare(tmp_path)
    clock = iter([0.0, 7.0])
    monkeypatch.setattr(ls, "_now", lambda: next(clock))
    share.rows(4)
    with share.lessons():
        pass
    assert share.took["full"] and share.took["setup_from"] == "guess" and share.took["per_row"] == 7.0 / 4
    share = LessonShare(tmp_path)
    clock = iter([0.0, 13.0])
    share.rows(10)
    with share.lessons():
        pass
    took = LessonShare(tmp_path).took
    assert abs(took["per_row"] - 1.0) < 1e-9 and abs(took["setup"] - 3.0) < 1e-9 and took["setup_from"] == "line"
    assert abs(LessonShare(tmp_path).lessons_claim(5) - 8.0) < 1e-9


def test_a_cut_turn_does_not_bend_the_line(tmp_path, monkeypatch):
    """Intention: a turn that began with no time left is filed as not full; its points and cost per row stay."""
    share = LessonShare(tmp_path)
    share.took = {"points": [[4, 7.0]], "per_row": 1.75}
    clock = iter([0.0, 1.0])
    monkeypatch.setattr(ls, "_now", lambda: next(clock))
    monkeypatch.setattr(ls, "_left", lambda own=None: 0.0)
    share.rows(10)
    share.took["expected_rows"] = 20
    with share.lessons():
        pass
    took = LessonShare(tmp_path).took
    assert took["full"] is False and took["points"] == [[4, 7.0]] and took["per_row"] == 1.75
    assert took["ratio"] == 0.5


def test_a_line_that_makes_no_sense_is_not_trusted():
    """Intention: a bigger set that took less time, or a setup below nought, gives no line."""
    assert line([[4, 7.0], [10, 5.0]]) is None
    assert line([[4, 1.0], [10, 10.0]]) is None
    assert line([[4, 7.0], [4, 8.0]]) is None
    per_row, setup = line([[4, 7.0], [10, 13.0], [10, 14.0]])
    assert abs(per_row - 7.0 / 6.0) < 1e-9 and abs(setup - (14.0 - 10 * 7.0 / 6.0)) < 1e-9
