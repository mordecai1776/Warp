# WARP2/warp2/chat_learning/tests/test_chat_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/tests/test_chat_learning.py
#  Used by   : pytest.
#  Uses      : warp2/chat_learning/*, warp2/ask/talk.py (the turn kept),
#              projects/behemoth_eye/eye/warp_eye.py.
#  Description:
#    The chat's learning, checked by running it with models that always
#    answer the same way: tags parsed and agreed by trust; the ledger's
#    running means and its best to convey; the shelf keeping rows in use
#    whole and the rest dehydrated, restored exactly; dataset rows read
#    from the shapes datasets have, and the hub read through a fake page
#    fetcher; the models acting out a scenario and the best answer going
#    on; the Eye seeing it with the previous response beside it and being
#    taught the agreed tags; real chat turns kept and learned from once.
#  User intention (Andrew, 2026-09-20): the chat's learning system.
# ============================================================================
from __future__ import annotations

import json
import re

from warp2.chat_learning import datasets
from warp2.chat_learning.ledger import CONVEYING, TAGGING, TEACHING, Ledger
from warp2.chat_learning.learning import ChatLearning
from warp2.chat_learning.scenario import Scenario, from_conversation, generated
from warp2.chat_learning.shelf import Shelf, dehydrate, hydrate
from warp2.chat_learning.simulate import converse
from warp2.chat_learning.tagging import agree, matched, parse_tags
from warp2.chat_learning.turns import ChatTurns

ANSWERS = {"a": "hello friend", "b": "go away", "c": "hello there"}


class _Fleet:
    """Intention: three models that always answer, tag and open the same way."""

    def names(self, kind: str = "") -> list:
        return sorted(ANSWERS)

    def ask(self, name: str, prompt: str) -> str:
        if "Tag the reply" in prompt:
            reply = re.search(r"given by one speaker:\n(.*?)\n\n", prompt, re.S).group(1)
            if "hello" in reply:
                return 'Tags: [{"name": "Greeting", "says": "hello", "why": "it greets", "weight": 0.9}]'
            return '[{"name": "greeting", "weight": -0.6}, {"name": "rude", "weight": 0.8}]'
        if "You are the assistant" in prompt:
            return "assistant: " + ANSWERS[name]
        if "You are the person" in prompt:
            return "[end]"
        if "Write the first thing" in prompt:
            return 'Sure: {"opening": "hi", "turns": 1}'
        return ""


def test_tags_are_parsed_and_agreed_by_trust():
    tags = parse_tags('x [{"name": " Big  Cat ", "weight": 3}, {"name": "big cat"}, "no", {"weight": 1}] y')
    assert tags == [{"name": "big cat", "says": "", "why": "", "weight": 1.0, "holds": []}]
    by = {"a": [{"name": "x", "says": "", "why": "", "weight": 1.0}], "b": [], "c": [{"name": "x", "says": "s",
                                                                                       "why": "", "weight": 0.5}]}
    agreed = agree(by, {"a": 1.0, "b": 1.0, "c": 1.0})
    assert [t["name"] for t in agreed] == ["x"] and abs(agreed[0]["weight"] - 0.5) < 1e-9
    assert agree(by, {"a": 1.0, "b": 5.0, "c": 1.0}) == []
    assert matched(by["a"], agreed) == 1.0 and matched([], agreed) == 0.0


def test_the_ledger_keeps_exact_means_and_gives_the_best_to_convey(tmp_path):
    ledger = Ledger(tmp_path)
    for v in (1.0, 0.0, 0.5):
        ledger.add(TEACHING, "model:a", "greeting", v)
    assert ledger.mean(TEACHING, "model:a", "greeting") == (0.5, 3)
    ledger.add(CONVEYING, "model:b", "greeting", -1.0)
    assert ledger.conveys("model:a", "greeting", 0.2) > ledger.conveys("model:b", "greeting", 0.2)
    assert ledger.trust("new") == 1.0
    ledger.add(TAGGING, "c", "*", 0.0)
    assert ledger.trust("c") == 0.5
    ledger.save()
    assert Ledger(tmp_path).mean(TEACHING, "model:a", "greeting") == (0.5, 3)


def test_rows_in_use_are_whole_and_the_rest_dehydrated_and_restored_exactly(tmp_path):
    row = {"messages": [{"role": "user", "content": "hi"}, {"role": "assistant", "content": "hello"}]}
    tag = dehydrate(row, "hf:x#0", teaches=["greeting"])
    assert tag["name"].startswith("row:") and hydrate(tag) == row
    shelf = Shelf(tmp_path)
    used = shelf.add(row, "hf:x#0", active=True)
    rest = shelf.add({"dialog": ["hey", "yo"]}, "hf:x#1", active=False, teaches=["greeting"])
    assert used in shelf.active and rest in shelf.dry and shelf.add(row, "again", active=False) == used
    shelf.dry_out(used)
    shelf.save()
    again = Shelf(tmp_path)
    assert again.active == {} and set(again.dry) == {used, rest}
    assert again.matching("greeting") == [rest]
    assert again.wet(used)["row"] == row


def test_dataset_rows_become_conversations_and_the_hub_is_read_a_page_at_a_time():
    assert datasets.conversation_of({"conversations": [{"from": "human", "value": "a"},
                                                       {"from": "gpt", "value": "b"}]}) == [
        {"role": "user", "content": "a"}, {"role": "assistant", "content": "b"}]
    assert datasets.conversation_of({"dialog": ["a", "b"]})[1]["role"] == "assistant"
    assert datasets.conversation_of({"instruction": "a", "output": "b"})[0]["content"] == "a"
    assert datasets.conversation_of({"nothing": 1}) == []
    pages = {
        "search": [{"id": "x/chat"}, {"id": "y/other"}],
        "splits": {"splits": [{"config": "default", "split": "train"}]},
        "rows": {"rows": [{"row": {"dialog": ["hi", "hello"]}}]},
    }

    def get(url):
        return pages["search"] if "api/datasets" in url else pages["splits"] if "/splits" in url else pages["rows"]
    assert datasets.hub_search("chat", get) == ["x/chat", "y/other"]
    assert datasets.hub_rows("x/chat", 0, 10, get) == [{"dialog": ["hi", "hello"]}]
    look = lambda q: [{"url": "https://huggingface.co/datasets/z/talk", "text": "see huggingface.co/datasets/w/q"}]
    assert datasets.web_named("chat", look) == ["z/talk", "w/q"]


def test_the_models_act_out_a_scenario_and_the_best_answer_goes_on(tmp_path):
    fleet = _Fleet()
    assert generated(fleet, "a", "greetings").opening == "hi"
    scenario = from_conversation([{"role": "user", "content": "hi"}, {"role": "assistant", "content": "hey"}],
                                 "dataset:test", ["greeting"])
    ledger = Ledger(tmp_path)
    acted = converse(fleet, scenario, fleet.names(), ledger)
    step = acted["steps"][0]
    assert set(step["candidates"]) == {"model:a", "model:b", "model:c", "data"}
    assert set(step["candidates"]["model:a"]["by"]) == {"b", "c"}
    assert step["chosen"] in ("model:a", "model:c")
    assert acted["turns"][-1]["role"] == "assistant" and "hello" in acted["turns"][-1]["text"]


def test_a_turn_of_learning_teaches_the_eye_and_keeps_every_score(tmp_path):
    from projects.behemoth_eye.eye.warp_eye import WarpEye
    state = tmp_path / "state"
    warp = WarpEye.for_state(state)
    (state / "datasets" / "local").mkdir(parents=True)
    (state / "datasets" / "local" / "talk.jsonl").write_text(
        json.dumps({"dialog": ["hi", "hello friend"]}) + "\n" + json.dumps({"dialog": ["hey", "hello"]}) + "\n",
        encoding="utf-8")
    ChatTurns(state).add("good morning", "hello, good morning")
    # Intention (2026-10-15, fix 7.5): the turn is given no time to teach, so
    # every tag is taught as one weighted block — the turn ran over 10 minutes
    # with every tag's full map. What a map measures each answer taught (the
    # TEACHING ledger) is tested in test_chat_teaching_has_its_turns_time.py.
    learning = ChatLearning(state, _Fleet(), warp, get=lambda url: None, seconds=1e-9)
    said = learning.turn()
    assert len(said["acted"]) == 1 and said["acted"][0]["source"] == "chat"
    taught = [t["tag"] for a in said["acted"] for t in a["taught"]]
    assert "greeting" in taught and "greeting" in warp.eye.concepts.pairs
    assert warp.eye.concepts.pairs["greeting"].kind == "synthetic"
    assert learning.ledger.things(TEACHING) == set()
    assert said["active_rows"] + said["dehydrated_rows"] == 0
    assert ChatTurns(state).claim_one() == said["chat_turn"]
    ChatTurns(state).complete(said["chat_turn"])
    assert ChatTurns(state).claim_one() is None
    next_turn = learning.turn()
    assert len(next_turn["acted"]) == 1 and next_turn["acted"][0]["source"].startswith("dataset:")
    assert next_turn["active_rows"] + next_turn["dehydrated_rows"] == 2
    assert ChatLearning(state, None, warp).turn()["why"].startswith("the models answer")
    WarpEye.forget(state)


def test_every_chat_turn_is_kept_for_the_eye(tmp_path):
    from warp2.ask.talk import Talk

    class _Knowing:
        state = str(tmp_path)
        store = None

        def answer(self, said):
            return {"grounds": "", "facts": []}
    talk = Talk.__new__(Talk)
    talk.state = None
    talk.knowing = _Knowing()
    talk._keep_for_the_eye("hello", {"said": "hi there"})
    talk._keep_for_the_eye("reset", {"said": "Conversation reset.", "reset": True})
    assert ChatTurns(tmp_path).take() == [{"said": "hello", "answered": "hi there", "thread": ""}]


def test_a_claimed_chat_turn_remains_queued_until_completion(tmp_path):
    turns = ChatTurns(tmp_path)
    turns.add("first", "answer one")
    turns.add("second", "answer two")
    claimed = turns.claim_one()
    assert claimed == {"said": "first", "answered": "answer one", "thread": ""}
    assert turns.claim_one() == claimed
    turns.complete(claimed)
    assert turns.claim_one() == {"said": "second", "answered": "answer two", "thread": ""}


def test_the_eye_learns_to_speak_answers_beside_the_models_and_speaks_when_it_conveys_best(tmp_path):
    from projects.behemoth_eye.eye.warp_eye import WarpEye
    from warp2.chat_learning.ledger import CONVEYING
    from warp2.chat_learning.speaker import EYE, ChatSpeaker
    state = tmp_path / "state"
    warp = WarpEye.for_state(state)
    learning = ChatLearning(state, _Fleet(), warp, get=lambda url: None)
    first = learning.turn()
    assert first["acted"][0]["words_taught"] > 0 and warp.can_say()
    assert learning.query("greeting", ["a", "b"]) == learning.query("greeting", ["b", "a"])
    second = learning.turn()
    assert second["acted"][0]["eye_answered"] >= 1
    assert any(k.startswith(f"{CONVEYING}|eye|") for k in learning.ledger.scores)
    speaker = ChatSpeaker(_Fleet(), state)
    assert EYE in speaker.makers()
    models = {f"{CONVEYING}|model:{m}|greeting": {"mean": 0.2, "count": 9, "square": 0.08} for m in "abc"}
    speaker.ledger.scores = {**models, f"{CONVEYING}|eye|greeting": {"mean": 5.0, "count": 9, "square": 0.0}}
    assert speaker.choose("hi") == "model:a", "the Eye is judged on what it was held back from"
    speaker.ledger.scores = {**models, "held|eye|greeting": {"mean": 5.0, "count": 1}}
    assert speaker.choose("hi") == "model:a", "one held score is not certainty"
    speaker.ledger.scores = {**models, "held|eye|greeting": {"mean": 5.0, "count": 9, "square": 0.8}}
    assert speaker.choose("hi") == EYE
    assert isinstance(speaker.speak("prompt", "hi"), str) and speaker.last in (EYE, "model:a")
    speaker.ledger.scores = {}
    assert speaker.choose("hi") == "model:a"
    WarpEye.forget(state)


def test_one_model_is_enough_and_a_page_grows_while_it_holds_no_conversation(tmp_path):
    from projects.behemoth_eye.eye.warp_eye import WarpEye

    class _One(_Fleet):
        def names(self, kind: str = "") -> list:
            return ["a"]
    state = tmp_path / "state"
    asked = []

    def get(url):
        asked.append(url)
        if "api/datasets" in url:
            return [{"id": "x/chat"}]
        if "/splits" in url:
            return {"splits": [{"config": "default", "split": "train"}]}
        return {"rows": [{"row": {"text": "not a conversation"}}]}
    learning = ChatLearning(state, _One(), WarpEye.for_state(state), get=get)
    learning.turn()
    learning.turn()
    sizes = [re.search(r"length=(\d+)", u).group(1) for u in asked if "/rows" in u]
    assert sizes[:2] == ["1", "2"]
    WarpEye.forget(state)


def test_tagging_stops_once_the_rest_could_not_change_what_is_agreed():
    from warp2.chat_learning.tagging import settled, tag_reply
    by = {"a": [{"name": "x", "weight": 1.0}], "b": [{"name": "x", "weight": 1.0}]}
    assert settled(by, {}, 1.0)
    assert not settled({"a": [{"name": "x", "weight": 1.0}]}, {}, 2.0)
    asked = []

    class _Counting(_Fleet):
        def ask(self, name, prompt):
            asked.append(name)
            return super().ask(name, prompt)
    said = tag_reply(_Counting(), ["a", "b", "c"], [{"role": "user", "text": "hi"}], "hello friend")
    assert len(asked) == 2 and set(said) == {"a", "b"}


def test_every_fifth_scenario_is_held_back_and_the_standing_is_kept(tmp_path):
    from projects.behemoth_eye.eye.warp_eye import WarpEye
    from warp2.chat_learning import learning as chat
    from warp2.chat_learning.ledger import HELD
    state = tmp_path / "state"
    warp = WarpEye.for_state(state)
    made = ChatLearning(state, _Fleet(), warp, get=lambda url: None)
    made.read_at["(scenarios)"] = chat.HOLD_EVERY - 1
    said = made.turn()
    assert said["acted"][-1]["held"] and said["acted"][-1]["taught"] == []
    assert any(k.startswith(f"{HELD}|") for k in made.ledger.scores)
    assert (state / "chat_learning" / "standing.json").is_file() and "model:a" in said["standing"]
    WarpEye.forget(state)


def test_scenario_split_is_permanent_across_restart_and_corrupt_state_is_quarantined(tmp_path):
    state = tmp_path / "state"
    scenario = Scenario(topic="topic", opening="hello", turns=1, source="dataset:test",
                        reference=[{"role": "user", "content": "hello"}], teaches=[])
    first = ChatLearning(state, _Fleet(), object(), get=lambda url: None)
    assert first._held_for(scenario, "row-one", count=5)
    again = ChatLearning(state, _Fleet(), object(), get=lambda url: None)
    assert again._held_for(scenario, "row-one", count=6), "a scenario must never flip sides"
    assert again.scenario_splits["row:row-one"] is True

    split = state / "chat_learning" / "scenario_splits.json"
    split.write_text("{torn", encoding="utf-8")
    recovered = ChatLearning(state, _Fleet(), object(), get=lambda url: None)
    assert isinstance(recovered.scenario_splits, dict)
    assert list(split.parent.glob("scenario_splits.json.corrupt-*"))


def test_choices_are_made_at_a_known_point_of_certainty(tmp_path):
    import math
    from warp2.chat_learning.certainty import bounds, certain_best, could_beat
    assert bounds(1.0, 0.0, 1) == (-math.inf, math.inf)
    low, high = bounds(1.0, 4.0, 5)
    assert abs((high - low) / 2 - math.sqrt(4.0 / 4 / 5)) < 1e-12
    assert certain_best({"a": (0.9, 1.0, 1.1), "b": (0.0, 0.5, 0.8)}) == "a"
    assert certain_best({"a": (0.7, 1.0, 1.1), "b": (0.0, 0.5, 0.8)}) is None
    assert could_beat(1.0, [0.5, math.inf]) and not could_beat(1.0, [0.5, 1.0])
    ledger = Ledger(tmp_path)
    for v in (1.0, 2.0, 3.0):
        ledger.add(TEACHING, "m", "t", v)
    low, high = ledger.bounds(TEACHING, "m", "t")
    assert abs(low - (2.0 - math.sqrt(1.0 / 3))) < 1e-9


def test_models_are_asked_until_none_could_beat_the_best(tmp_path):
    ledger = Ledger(tmp_path)
    for m, v in (("a", 1.0), ("b", -1.0), ("c", 1.0)):
        for _ in range(4):
            ledger.add(CONVEYING, f"model:{m}", "greeting", v + (0.01 if _ % 2 else -0.01))
    scenario = Scenario(topic="hi", opening="hi", turns=1, source="model:x", teaches=["greeting"])
    step = converse(_Fleet(), scenario, ["a", "b", "c"], ledger)["steps"][0]
    assert "b" in step["unasked"] and "model:b" not in step["candidates"]
