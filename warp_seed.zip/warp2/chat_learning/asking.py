# WARP3/warp2/chat_learning/asking.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/chat_learning/asking.py
#  Used by   : warp2/chat_learning/{scenario,simulate,tagging}.py,
#              warp2/wise_men/rounds.py (ask_why).
#  Uses      : (stdlib) json, re.
#  Description:
#    Asking one model one thing, and reading JSON out of what it said. A
#    model that fails or says nothing gives "" — one model's trouble never
#    stops the others. JSON is read from the first opening bracket to its
#    last closing one, since models wrap it in words. ask_why also gives
#    the reason a model said nothing (2026-11-20). ask_why_id also gives
#    the id of the house attempt, to join the house's line (BUILD_LOG 2250).
#  User intention (Andrew, 2026-09-20): the simulation is run by "the other
#    models".
# ============================================================================
"""One question to one model, and JSON out of its answer."""
from __future__ import annotations

import json
import re

# Intention (2026-11-20): how long a reason for a silent model may be; it goes
# into the talk log, so one short line.
REASON_CHARS = 160


def ask(fleet, model: str, prompt: str) -> str:
    """Intention: what the model said, or "" when it could not answer."""
    try:
        return str(fleet.ask(model, prompt) or "").strip()
    except Exception:
        return ""


def ask_why(fleet, model: str, prompt: str) -> tuple:
    """Intention: what the model said and, when it said nothing, why — so a stage
    that hears no one can say what went wrong instead of only "no model answered".

    Intention (2026-11-20, Claude hourly): 3 wise men sat at "answer" from
    2026-11-18 16:08 on, four turns of about six minutes each, every model
    giving "" and the cause thrown away by `ask`. The reason is kept short
    (one line, at most 160 characters) because it goes into the talk log.
    """
    text, why, _ = ask_why_id(fleet, model, prompt)
    return text, why


def ask_why_id(fleet, model: str, prompt: str) -> tuple:
    """Intention (BUILD_LOG 2250): what ask_why gives, and the id of the house attempt it was ("" when none).

    The id comes from the error when the ask failed (.request_id, carried up by the roster) and from the fleet
    when it answered (Fleet.request_id_of); a fleet or model with no ids gives "". It is the same id the house
    keeps on its residency line, so the asker's record joins that line by the id alone (Codex 613/615).
    """
    try:
        text = str(fleet.ask(model, prompt) or "").strip()
    except Exception as exc:
        why = one_line(f"{type(exc).__name__}: {exc}")[:REASON_CHARS] or type(exc).__name__
        return "", why, str(getattr(exc, "request_id", "") or "")
    return text, ("" if text else "said nothing"), _sent_id(fleet, model)


def _sent_id(fleet, model: str) -> str:
    """Intention (BUILD_LOG 2250): the fleet's id for the model's last attempt; "" when the fleet keeps none."""
    read = getattr(fleet, "request_id_of", None)
    if read is None:
        return ""
    try:
        return str(read(model) or "")
    except Exception:  # fault: ok - a missing id must never cost the answer
        return ""


def json_in(text: str, opening: str = "[", closing: str = "]"):
    """Intention: the JSON between the first `opening` and the last `closing`, or None."""
    text = str(text or "")
    start, end = text.find(opening), text.rfind(closing)
    if start < 0 or end <= start:
        return None
    try:
        return json.loads(text[start:end + 1])
    except ValueError:
        return None


def one_line(text: str) -> str:
    """Intention: a model's line without a speaker label or wrapping quotes."""
    text = re.sub(r"^\s*(user|assistant|person|me|you)\s*:\s*", "", str(text or "").strip(), flags=re.IGNORECASE)
    return text.strip().strip('"').strip()
