# WARP2/warp2/chat_learning/asking.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/chat_learning/asking.py
#  Used by   : warp2/chat_learning/{scenario,simulate,tagging}.py.
#  Uses      : (stdlib) json, re.
#  Description:
#    Asking one model one thing, and reading JSON out of what it said. A
#    model that fails or says nothing gives "" — one model's trouble never
#    stops the others. JSON is read from the first opening bracket to its
#    last closing one, since models wrap it in words.
#  User intention (Andrew, 2026-09-20): the simulation is run by "the other
#    models".
# ============================================================================
"""One question to one model, and JSON out of its answer."""
from __future__ import annotations

import json
import re


def ask(fleet, model: str, prompt: str) -> str:
    """Intention: what the model said, or "" when it could not answer."""
    try:
        return str(fleet.ask(model, prompt) or "").strip()
    except Exception:
        return ""


def json_in(text: str, opening: str = "[", closing: str = "]"):
    """Intention: the JSON between the first `opening` and the last `closing`, or None."""
    text = str(text or "")
    start, end = text.find(opening), text.rfind(closing)
    if start < 0 or end <= start:
        return None
    try:
        return json.loads(text[start:end + 1])
    except ValueError:
        return None


def one_line(text: str) -> str:
    """Intention: a model's line without a speaker label or wrapping quotes."""
    text = re.sub(r"^\s*(user|assistant|person|me|you)\s*:\s*", "", str(text or "").strip(), flags=re.IGNORECASE)
    return text.strip().strip('"').strip()
