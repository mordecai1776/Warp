# WARP2/warp2/graph_play/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/graph_play/__init__.py
#  Used by   : warp2/work/side/graph_play.py (EvolveOnGraphStep).
#  Uses      : graph_play/sides.py, shapes.py, play.py, paper.py.
#  Description:
#    The knowledge graph playing against itself, as "Evolve on Graph"
#    (arXiv 2610.35598) does: questions made from the graph's own shapes,
#    each with its complete answer set from running it on the graph; one
#    model writes the question, the models answer it from the graph, each
#    answer scored against the set; the question weighed by how mixed the
#    scores are (the edge of what they can do); all of it training blocks.
#    And the graph's public and private sides, for when others add to it.
#  User intention (Andrew, 2026-10-28 19:28-19:45): "there's a new paper ...
#    where they use something similar to what we were trying to do with the
#    knowledge graph and creating the question answer system"; "Evolve on
#    graph ... Add to the knowledge graph ... try to add that in too" (asked:
#    all of it; both — the method in, and the paper as facts); "We also need
#    to have a public and private side of the kg for when we start to add
#    others"; (20:41) "just get it all in there". BUILD_LOG 894.
# ============================================================================
"""The knowledge graph's self-play (Evolve on Graph), its public and private sides, and the paper as facts."""
from .paper import PaperFacts
from .play import GraphRound
from .shapes import Shape, Shapes
from .sides import Sides

__all__ = ["PaperFacts", "GraphRound", "Shape", "Shapes", "Sides"]
