# WARP3/warp2/graph_play/tests/test_each_play_ask_keeps_its_request_id.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/graph_play/tests/test_each_play_ask_keeps_its_request_id.py
#  Used by   : run_tests.py, CHECK_FIXES.bat.
#  Uses      : warp2/graph_play/play.py (GraphRound, asked); pytest.
#  Description:
#    BUILD_LOG 2328: a graph-play round keeps one line per ask it made - role,
#    model, the house request id, seconds and characters heard - so a long
#    house answer joins its parent round by the id alone (Codex 649). What is
#    asked, of whom, and the scores are unchanged.
# ============================================================================
"""Each graph-play ask is kept with its house request id."""
import json

from warp2.graph_play.play import GraphRound, asked
from warp2.graph_play.shapes import Shape
from warp2.graph_play.tests.test_graph_play import _Fleet, _graph


class _IdFleet(_Fleet):
    """Intention: the test fleet, also saying the house id of each model's last ask, as the real fleet does."""

    def __init__(self, question):
        super().__init__(question)
        self.count = 0

    def ask(self, model, prompt):
        self.count += 1
        return super().ask(model, prompt)

    def request_id_of(self, model):
        return f"id-{self.count}-{model}"


class _Broken:
    """Intention: a fleet whose ask fails."""

    def ask(self, model, prompt):
        raise TimeoutError("house too slow")


def test_a_played_round_keeps_each_ask_with_its_id(tmp_path, monkeypatch):
    """Intention: one propose line and five solve lines, each with the id the house gave."""
    play = GraphRound(tmp_path / "state", _graph(tmp_path), _IdFleet("Which files does eye contain?"), None, seed=1)
    monkeypatch.setattr(play, "kind", lambda: "chain 1")
    monkeypatch.setattr(play.shapes, "sample", lambda kind: Shape("chain 1", ["module:eye"], [("contains", "out")],
                                                                  [], ["file:eye_head", "file:eye_lens", "file:eye_loops"]))
    got = play.turn()
    assert got["did"] == "played" and len(got["scores"]) == 5
    roles = [a["role"] for a in got["asks"]]
    assert roles == ["propose"] + ["solve"] * 5
    assert got["asks"][0]["request_id"] == "id-1-" + got["by"]
    assert all(a["request_id"] and a["seconds"] >= 0 and a["chars"] > 0 for a in got["asks"])
    kept = json.loads((tmp_path / "state" / "graph_play" / "rounds.jsonl").read_text(encoding="utf-8").splitlines()[-1])
    assert kept["asks"] == got["asks"]


def test_a_failed_ask_says_why_and_gives_nothing():
    """Intention: as `ask` did, a failed ask gives "" - and now its line says why."""
    asks = []
    assert asked(_Broken(), "m1", "Write ONE question", "propose", asks) == ""
    assert asks[0]["chars"] == 0 and "TimeoutError" in asks[0]["why"] and asks[0]["request_id"] == ""
