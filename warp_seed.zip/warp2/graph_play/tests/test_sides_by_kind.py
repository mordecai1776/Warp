# WARP2/warp2/graph_play/tests/test_sides_by_kind.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/graph_play/tests/test_sides_by_kind.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/graph_play/sides.py (kind_of, side_by_kind, Sides),
#              warp2/store/store.py (Store).
#  Description:
#    The graph's sides by kind (BUILD_LOG 1155): world knowledge, research,
#    concepts, webs, the Eye's knowledge, web pages and the warp's own code
#    are public with nothing said; his projects, the archive, the state, the
#    design words, things he asked, work on his projects, and any kind not
#    named are his; what is said for a thing wins; a fact is public only when
#    both its ends are.
#  User intention (Andrew, 2026-11-03 22:17): "The kg should have been
#    separated out into public and private parts"; asked and answered: "Sort
#    by kind".
# ============================================================================
"""Tests that a thing with no side said is on the side its kind puts it."""
from __future__ import annotations

from warp2.graph_play.sides import PUBLIC, Sides, kind_of, private, side_by_kind


def test_world_knowledge_and_the_warps_code_are_public():
    """Intention: the measured big kinds, a web page, and a file in warp2/."""
    for thing in ("webtag:meaning:000547c39693", "phrase:00-00", "concept:cat", "finding:001b", "skill:x",
                  "eye:activation:true image", "https://example.org/a", "warp2/work/loop.py::Loop.run"):
        assert side_by_kind(thing) == PUBLIC, thing


def test_his_life_and_any_unnamed_kind_are_his():
    """Intention: his projects, archive, state, design words, asks, work on his projects, and a kind nobody named."""
    for thing in ("projects/centering_image/gui.py", "archive/2026-09-19_x/run.py", "state/builders/last_good",
                  "design/tests", "asked:comment:2026", "work:build:projects/a.py", "conversation:2026-09-08:x",
                  "intention:eye_attention", "something_new:x", "0d3aaf3deceda4aa"):
        assert side_by_kind(thing) == private("andrew"), thing


def test_a_path_is_known_by_its_first_folder_and_a_name_by_the_word_before_the_colon():
    """Intention: the two shapes subjects have."""
    assert kind_of("warp2/x.py::f") == ("warp2", True)
    assert kind_of("work:build:projects/a.py") == ("work", False)
    assert kind_of("https://x.org/a:b") == ("https", False)


class _Store:
    """Intention: a stand-in store holding side facts said for some things."""

    def __init__(self, said):
        self.said = said

    def current(self, subject=None, attr=None, limit=None):
        if attr == "side" and subject in self.said:
            return [{"value": self.said[subject], "key": "k"}]
        return []


def test_what_is_said_wins_and_a_fact_needs_both_ends():
    """Intention: a concept said private stays private; a link from a public thing to his file is not public."""
    sides = Sides(_Store({"concept:secret": private("andrew"), "projects/p.py": "public"}))
    assert sides.side_of("concept:secret") == private("andrew") and sides.side_of("projects/p.py") == PUBLIC
    assert sides.sees_fact("someone", {"subject": "concept:cat", "object": "finding:1"}) is True
    assert sides.sees_fact("someone", {"subject": "concept:cat", "object": "projects/centering_image/gui.py"}) is False
    assert sides.sees_fact("andrew", {"subject": "concept:cat", "object": "projects/centering_image/gui.py"}) is True
