# WARP2/warp2/graph_play/tests/test_graph_play.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/graph_play/tests/test_graph_play.py
#  Used by   : CHECK_FIXES.bat, pytest.
#  Uses      : warp2/graph_play/ (Sides, Shapes, GraphRound, PaperFacts),
#              warp2/store/store.py (a store in a test folder).
#  Description:
#    The graph playing against itself (BUILD_LOG 894): shapes sampled on the
#    graph give their complete answer sets; a question naming a hidden thing
#    is thrown out; answers are scored by F1 on the set and the question's
#    reward is highest when the scores are mixed; a round writes its
#    question and answers as weighted blocks and is kept; the paper is in
#    the graph, on the public side; the private sides: another's private
#    things are not seen, the public ones are, and what is already in the
#    graph stays the owner's.
#  User intention (Andrew, 2026-10-28): "Evolve on graph ... Add to the
#    knowledge graph ... try to add that in too"; "a public and private side
#    of the kg for when we start to add others". These fail on the old code
#    (no graph_play).
# ============================================================================
"""Tests for the graph's self-play, the paper as facts, and the graph's sides."""
from __future__ import annotations

import json

from warp2.graph_play import GraphRound, PaperFacts, Shapes, Sides
from warp2.graph_play.paper import PAPER
from warp2.graph_play.play import f1, reward
from warp2.graph_play.shapes import Shape
from warp2.graph_play.sides import PUBLIC, private
from warp2.store.store import Store


def _graph(tmp_path):
    """Intention: a small graph — modules that contain files that define things."""
    store = Store(tmp_path / "state", run="t", stamp={"code": "t"})
    for m in ("eye", "ask"):
        store.assert_fact(f"module:{m}", "has", attr="name", value=m)
    for module, files in (("eye", ("lens", "head", "loops")), ("ask", ("judge", "lens"))):
        for f in files:
            store.assert_fact(f"module:{module}", "contains", f"file:{module}_{f}")
            store.assert_fact(f"file:{module}_{f}", "has", attr="name", value=f"{module} {f}")
            store.assert_fact(f"file:{module}_{f}", "defines", f"thing:{f}")
    return store


def test_a_shape_run_on_the_graph_gives_its_whole_answer_set(tmp_path):
    """Intention: chains and joins are answered completely by running them on the graph."""
    shapes = Shapes(_graph(tmp_path), seed=0)
    assert shapes.run(Shape("chain 1", ["module:eye"], [("contains", "out")])) == ["file:eye_head", "file:eye_lens", "file:eye_loops"]
    assert shapes.run(Shape("chain 2", ["module:ask"], [("contains", "out"), ("defines", "out")])) == ["thing:judge", "thing:lens"]
    # Intention: what both modules' files define — a chain then a join.
    both = shapes.run(Shape("chain then join", ["module:eye", "file:ask_lens"],
                            [("contains", "out"), ("defines", "out"), ("defines", "out")], ["x"]))
    assert both == ["thing:lens"]
    one = shapes.sample("chain 2")
    assert one is not None and 0 < len(one.answers) and one.answers == shapes.run(one)


def test_answers_are_scored_on_the_set_and_mixed_scores_reward_most():
    """Intention: F1 against the full set; the reward is highest for half right, half wrong."""
    assert f1(["eye lens", "Eye_Head"], ["eye lens", "eye head", "eye loops"]) == 0.8
    assert f1([], ["a"]) == 0.0
    assert reward([1, 1, 0, 0, 1]) > reward([1, 1, 1, 1, 1]) and reward([1, 1, 0, 0, 1]) > reward([0, 0, 0, 0, 0])


class _Fleet:
    """Intention: models that write a question and answer the eye's files, some right and some not."""

    def __init__(self, question):
        self.question, self.n = question, 0

    def names(self):
        return ["m1", "m2"]

    def ask(self, model, prompt):
        if prompt.startswith("Write ONE question"):
            return self.question
        self.n += 1
        return json.dumps(["eye lens", "eye head", "eye loops"] if self.n % 2 else ["eye lens"])


class _Blocks:
    """Intention: an ingestor that keeps the blocks."""

    def __init__(self):
        self.blocks = []

    def record_block(self, block):
        self.blocks.append(block)
        return block.block_id


def test_a_round_writes_its_question_and_answers_as_weighted_blocks(tmp_path, monkeypatch):
    """Intention: one round — the shape, the question, five scored answers, the reward, the blocks, kept."""
    store, blocks = _graph(tmp_path), _Blocks()
    play = GraphRound(tmp_path / "state", store, _Fleet("Which files does eye contain?"), blocks, seed=1)
    monkeypatch.setattr(play, "kind", lambda: "chain 1")
    monkeypatch.setattr(play.shapes, "sample", lambda kind: Shape("chain 1", ["module:eye"], [("contains", "out")],
                                                                  [], ["file:eye_head", "file:eye_lens", "file:eye_loops"]))
    got = play.turn()
    assert got["did"] == "played" and len(got["scores"]) == 5 and got["scores"][0] == 1.0 and 0 < got["scores"][1] < 1
    assert len(blocks.blocks) == 6 and blocks.blocks[0].weight == max(0.05, got["reward"])
    assert (tmp_path / "state" / "graph_play" / "rounds.jsonl").read_text(encoding="utf-8").count("\n") == 1


def test_a_question_that_names_a_hidden_thing_is_thrown_out(tmp_path, monkeypatch):
    """Intention: naming an answer gives it away."""
    play = GraphRound(tmp_path / "state", _graph(tmp_path), _Fleet("Does eye contain eye lens?"), None, seed=1)
    monkeypatch.setattr(play, "kind", lambda: "chain 1")
    monkeypatch.setattr(play.shapes, "sample", lambda kind: Shape("chain 1", ["module:eye"], [("contains", "out")],
                                                                  [], ["file:eye_lens"]))
    assert play.turn()["did"] == "question thrown out"


def test_the_paper_is_in_the_graph_on_the_public_side(tmp_path):
    """Intention: the paper, its methods and findings are facts, public; writing it twice adds nothing new."""
    store = Store(tmp_path / "state", run="t", stamp={"code": "t"})
    PaperFacts(store).put()
    PaperFacts(store).put()
    defined = {f["object"] for f in store.current(subject=PAPER, relation="defines")}
    assert {"method:svts", "method:variance_reward", "method:proposer_solver_self_play"} <= defined
    assert Sides(store).side_of(PAPER) == PUBLIC and Sides(store).side_of("method:svts") == PUBLIC


def test_a_private_side_is_seen_only_by_its_owner_and_the_public_by_all(tmp_path):
    """Intention: what is in the graph stays the owner's; another's private facts are theirs; public ones are seen."""
    store = _graph(tmp_path)
    sides = Sides(store)
    assert sides.side_of("module:eye") == private("andrew")
    sides.add("sam", "thing:sams_idea", "depends_on", "thing:sams_other")
    sides.add("sam", "thing:sams_shared", "supports", "thing:lens", public=True)
    fresh = Sides(store)
    assert fresh.side_of("thing:sams_idea") == private("sam") and fresh.side_of("thing:sams_shared") == PUBLIC
    secret = {"subject": "thing:sams_idea", "object": "thing:sams_other"}
    assert fresh.sees_fact("sam", secret) and not fresh.sees_fact("andrew", secret)
    assert not fresh.can_see("sam", "module:eye") and fresh.can_see("andrew", "module:eye")
    assert fresh.can_see("andrew", "thing:sams_shared")
    assert all(not a.startswith("thing:sams") for a in Shapes(store, "andrew").run(
        Shape("chain 1", ["thing:sams_idea"], [("depends_on", "out")])))
