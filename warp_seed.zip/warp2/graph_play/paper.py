# WARP2/warp2/graph_play/paper.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/graph_play/paper.py
#  Used by   : warp2/work/side/graph_play.py (put in once, before the first
#              round), graph_play/tests/test_graph_play.py.
#  Uses      : warp2/store/store.py (assert_fact, as_source),
#              warp2/tags/grounding.py (JUDGED), graph_play/sides.py.
#  Description:
#    The "Evolve on Graph" paper put into the knowledge graph as facts:
#    the paper and what it is (title, authors, date, link), the methods it
#    defines (the shapes with full answer sets, the proposer and solver
#    playing, the reward at the edge of ability, the curriculum), what its
#    results support, and where it falls short — on the public side (it is
#    published), graded "judged" (read and summarised, not proven here).
#    Writing it twice changes nothing (the store keeps one row per fact).
#  User intention (Andrew, 2026-10-28 19:28): "Evolve on graph. There's a
#    little bit in that paper that I want you to read. Add to the knowledge
#    graph." (asked: all of it; both.) BUILD_LOG 894.
# ============================================================================
"""The Evolve on Graph paper, as facts in the graph."""
from __future__ import annotations

from warp2.graph_play.sides import PUBLIC, Sides

PAPER = "paper:evolve_on_graph"
# Intention: what the paper is.
ABOUT = {"name": "Evolve on Graph: Self-Evolving Knowledge Graph Reasoning without Question Annotations",
         "arxiv": "2610.35598", "date": "2026-10-26", "link": "https://arxiv.org/abs/2610.35598",
         "code": "https://github.com/Szy5/EoG",
         "authors": "Zongyuan Sun, Shuai Zhao, Ke Shu, Ziyue Zhu, Shangyang Wu, Yuanlin Lin, Tao Wang, Shiyue Li, "
                    "Yingjun Du, Anh Tuan Luu, Haoran Luo"}
# Intention: the methods it defines — each a thing with its name and what it is.
METHODS = {
    "method:svts": ("symbolically verifiable topology synthesis",
                    "shapes (1-3 link chains, a two-anchor join, nested mixes) sampled on the graph and run as logic "
                    "queries for their complete answer sets; empty, huge or unnamed sets dropped"),
    "method:proposer_solver_self_play": ("proposer and solver self-play",
                                         "one model writes a question from a shape (middle and answers hidden) and "
                                         "answers it on the graph; checked for format, leaks and the answer set"),
    "method:variance_reward": ("boundary-aware reward",
                               "the proposer rewarded by a Gaussian of the variance of the solver's five F1 scores: "
                               "questions some tries get right and some wrong"),
    "method:graph_curriculum": ("boundary-aware graph curriculum",
                                "harder shapes come in by themselves as the solver improves; no fixed schedule"),
}
# Intention: what its results support, and its limits.
FINDINGS = {
    "finding:eog_beats_annotation_free": "+7.46 Hit@1 and +12.05 F1 over the best annotation-free method on five "
                                          "public sets (Qwen-2.5-7B)",
    "finding:eog_industry_graph": "84.8% Hit@1 against 67.0% for ToG on an industrial car-design graph",
    "finding:shapes_beat_random_walks": "on CWQ 50.58 with shapes against 35.93 with random walks",
    "finding:variance_beats_adversarial": "on CWQ 50.58 with the variance reward against 42.59 adversarial",
}
LIMITS = ("needs a graph that can run queries", "a one-try check throws out some good questions",
          "no cost figures", "the test sets are still labelled")


class PaperFacts:
    """Intention: the paper written into the graph, on the public side."""

    def __init__(self, store) -> None:
        """Intention: the store it goes in."""
        self.store = store

    def put(self) -> int:
        """Intention: every fact of the paper written (graded "judged"); how many."""
        from warp2.tags.grounding import JUDGED
        speaking = self.store.as_source(JUDGED) if hasattr(self.store, "as_source") else None
        if speaking is not None:
            with speaking:
                return self._put()
        return self._put()

    def _put(self) -> int:
        """Intention: the facts, and every thing in them put on the public side."""
        sides, count = Sides(self.store), 0
        def fact(*args, **kwargs):
            """Intention: one fact into the store, counted."""
            nonlocal count
            self.store.assert_fact(*args, **kwargs)
            count += 1
        for attr, value in ABOUT.items():
            fact(PAPER, "has", attr=attr, value=value)
        for thing, (name, what) in METHODS.items():
            fact(thing, "has", attr="name", value=name)
            fact(thing, "has", attr="what", value=what)
            fact(PAPER, "defines", thing)
        for thing, said in FINDINGS.items():
            fact(thing, "has", attr="name", value=said)
            fact(PAPER, "supports", thing)
        for i, limit in enumerate(LIMITS):
            fact(PAPER, "has", attr=f"limit {i + 1}", value=limit)
        fact("method:svts", "depends_on", "method:proposer_solver_self_play")
        fact("method:graph_curriculum", "depends_on", "method:variance_reward")
        for thing in [PAPER, *METHODS, *FINDINGS]:
            sides.put(thing, PUBLIC)
        return count
