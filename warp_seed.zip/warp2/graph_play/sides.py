# WARP2/warp2/graph_play/sides.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/graph_play/sides.py
#  Used by   : graph_play/shapes.py (reads only what the reader may see),
#              graph_play/paper.py, graph_play/tests/test_graph_play.py,
#              warp2/share/ (what leaves this machine is read through it).
#  Uses      : warp2/store/store.py (the one door: assert_fact, current).
#  Description:
#    The graph's public and private sides. Each thing in the graph (a
#    subject) is on one side, said by an attribute fact "side": "public", or
#    "private:<owner>". A thing that says nothing is on the side its kind
#    puts it (BUILD_LOG 1155, Andrew 2026-11-03 "Sort by kind"): world
#    knowledge, proofs, skills, research, concepts, webs and the warp's own
#    code public; everything else — his projects, files, chats, pictures,
#    design words, and any kind not named — the warp owner's own (private). Someone
#    added later puts their facts through `add`: their things on their own
#    private side unless they say public. A reader sees the public side and
#    their own private side, never another's; a fact is seen only when both
#    its ends are.
#  User intention (Andrew, 2026-10-28 19:45): "We also need to have a public
#    and private side of the kg for when we start to add others."
#    BUILD_LOG 894.
# ============================================================================
"""The graph's public side and each one's private side."""
from __future__ import annotations

# Intention: the warp's owner — whose side everything already in the graph is on.
OWNER = "andrew"
PUBLIC = "public"
# Intention: the attribute a thing's side is said by.
SIDE = "side"

# Intention (Andrew, 2026-11-03, asked and answered — "Sort by kind": world knowledge, proofs, skills, research,
# concepts and webs public; anything from his life — his chats, his pictures, his files, people, the household, his
# design words — private; BUILD_LOG 1155): the kinds of thing that are public when nothing says otherwise. A kind not
# named here is private — a new kind stays his until someone says it is public. Measured 2026-11-03, the graph's
# kinds by count: webtag 4.34M, phrase 1.41M, point 644k, tag 446k, eye 205k, block 124k, web pages 52k, need 33k,
# finding 24k, skill 16k, concept 16k, shape 8k, ... (state/control/commands/out/kg-kinds2.txt).
PUBLIC_KINDS = frozenset({
    "webtag", "phrase", "point", "tag", "eye", "block", "http", "https", "need", "finding", "skill", "concept",
    "shape", "learned", "question", "recipe", "procedural", "dataset", "proof", "observation", "motif", "problem",
    "task", "clause", "method", "web", "model", "cycle", "training_round", "training", "paper", "part", "research",
    "proposal", "helped", "watch", "capability", "component", "store", "warp2",
})
# Intention (BUILD_LOG 1155): the folders whose files are public — the warp's own code, which every seed carries
# already. His projects, the archive, the state, the design words and every other folder are his.
PUBLIC_FOLDERS = frozenset({"warp2"})


def kind_of(subject: str) -> tuple[str, bool]:
    """Intention: a thing's kind and whether it is a file — the folder a path starts in, else the word before ':'."""
    text = str(subject)
    if text.startswith(("http://", "https://")):
        return text.split(":", 1)[0], False
    colon, slash = text.find(":"), min([i for i in (text.find("/"), text.find("\\")) if i >= 0], default=-1)
    if slash >= 0 and (colon < 0 or slash < colon):
        return text[:slash], True
    return (text[:colon] if colon > 0 else ""), False


def side_by_kind(subject: str, owner: str = OWNER) -> str:
    """Intention (BUILD_LOG 1155): the side a thing is on when nothing says — public for a public kind or folder,
    else the owner's private side."""
    kind, is_file = kind_of(subject)
    public = (kind in PUBLIC_FOLDERS) if is_file else (kind in PUBLIC_KINDS)
    return PUBLIC if public else private(owner)


def private(owner: str) -> str:
    """Intention: the name of one owner's private side."""
    return f"private:{str(owner).strip().lower() or OWNER}"


class Sides:
    """Intention: which side each thing is on, who may see it, and adding facts on a side."""

    def __init__(self, store, owner: str = OWNER) -> None:
        """Intention: the store, and whose graph it is."""
        self.store, self.owner = store, str(owner).strip().lower() or OWNER
        self._known: dict = {}

    def side_of(self, subject: str) -> str:
        """Intention: the side a thing is on — what it says, else its owner's private side."""
        subject = str(subject)
        if subject not in self._known:
            said = [f for f in self.store.current(subject=subject, attr=SIDE)]
            # Intention (BUILD_LOG 1155): what is said for a thing wins; with nothing said, its kind decides.
            self._known[subject] = str(said[-1]["value"]).strip('"') if said else side_by_kind(subject, self.owner)
        return self._known[subject]

    def can_see(self, reader: str, subject: str) -> bool:
        """Intention: the public side, and the reader's own private side."""
        side = self.side_of(subject)
        return side == PUBLIC or side == private(reader)

    def sees_fact(self, reader: str, fact: dict) -> bool:
        """Intention: a fact is seen only when both its ends are (an attribute has one end)."""
        if not self.can_see(reader, fact.get("subject", "")):
            return False
        return not fact.get("object") or self.can_see(reader, fact["object"])

    def put(self, subject: str, side: str) -> None:
        """Intention: a thing put on a side (public, or someone's private side)."""
        side = PUBLIC if side == PUBLIC else (side if str(side).startswith("private:") else private(side))
        if self.side_of(subject) != side or not self.store.current(subject=str(subject), attr=SIDE):
            for old in self.store.current(subject=str(subject), attr=SIDE):
                self.store.invalidate(old["key"], "moved to another side")
            self.store.assert_fact(str(subject), "has", attr=SIDE, value=side)
        self._known[str(subject)] = side

    def add(self, by: str, subject: str, relation: str, obj: str | None = None, attr: str | None = None,
            value=None, public: bool = False) -> str:
        """Intention: a fact from someone — its new things on their side (public when they say so), who told it kept."""
        side = PUBLIC if public else private(by)
        for end in (subject, obj):
            if end and not self.store.current(subject=str(end), attr=SIDE) and not self._others_have(end):
                self.put(end, side)
        key = self.store.assert_fact(subject, relation, obj, attr=attr, value=value)
        self.store.assert_fact(subject, "has", attr="told_by", value=str(by))
        return key

    def _others_have(self, subject: str) -> bool:
        """Intention: whether the thing is already in the graph (then its side is left as it is)."""
        return bool(self.store.current(subject=str(subject), limit=1))
