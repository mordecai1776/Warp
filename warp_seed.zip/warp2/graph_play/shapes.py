# WARP2/warp2/graph_play/shapes.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/graph_play/shapes.py
#  Used by   : graph_play/play.py, graph_play/tests/test_graph_play.py.
#  Uses      : warp2/store/store.py (current: what is true now),
#              graph_play/sides.py; stdlib random.
#  Description:
#    Questions from the graph's own shapes (the paper's "symbolically
#    verifiable topology synthesis"). A shape is sampled on facts that are
#    true now and that the reader may see: a chain of one, two or three
#    links from an anchor; a join (what two anchors both lead to); or a
#    chain that ends in a join. The shape is then run on the graph as a
#    query from its anchors, and its COMPLETE answer set kept — so every
#    answer can be checked, with no person and no vote. A shape whose set
#    is empty, too big, or has no names is dropped.
#  User intention (Andrew, 2026-10-28): "Evolve on graph ... try to add that
#    in too" (asked: all of it). BUILD_LOG 894.
# ============================================================================
"""Shapes sampled on the graph, each run on it for its full answer set."""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from warp2.graph_play.sides import OWNER, Sides

# Intention: the shapes, simplest first (as the paper's: chains of 1-3 links, a two-anchor join, a chain into a join).
CHAINS = ("chain 1", "chain 2", "chain 3")
KINDS = (*CHAINS, "join", "chain then join")
# Intention: an answer set bigger than this is not a question worth asking.
MOST_ANSWERS = 12
# Intention: how many facts are looked over when starting a shape, and how many times one is tried.
LOOK_OVER, TRIES = 400, 40
# Intention: the relations a shape walks (the attribute "has" is not a link).
LINKS = ("supports", "derives", "depends_on", "contradicts", "invalidates", "triggers", "updates", "contains", "defines")


@dataclass
class Shape:
    """Intention: one shape — its kind, its anchors, its links in order, the middles (hidden), and its full answers."""

    kind: str
    anchors: list
    links: list
    middles: list = field(default_factory=list)
    answers: list = field(default_factory=list)

    def hops(self) -> int:
        """Intention: how many links it walks."""
        return len(self.links)

    def kept(self) -> dict:
        """Intention: plain data."""
        return {"kind": self.kind, "anchors": list(self.anchors), "links": [list(l) for l in self.links],
                "middles": list(self.middles), "answers": list(self.answers)}


class Shapes:
    """Intention: sampling shapes on what a reader may see, and running them for their answers."""

    def __init__(self, store, reader: str = OWNER, seed: int | None = None) -> None:
        """Intention: the store, whose view it is, and the draws."""
        self.store, self.reader = store, str(reader)
        self.sides = Sides(store)
        self.rng = random.Random(seed)

    def name(self, thing: str) -> str:
        """Intention: a thing's name — its "name" attribute, else itself without its prefix."""
        said = self.store.current(subject=str(thing), attr="name", limit=1)
        if said:
            return str(said[0]["value"]).strip('"')
        text = str(thing)
        return text.split(":", 1)[1].replace("_", " ") if ":" in text else text

    def _out(self, thing: str, relation: str | None = None) -> list:
        """Intention: the links out of a thing the reader may see."""
        return [f for f in self.store.current(subject=str(thing), relation=relation)
                if f["relation"] in LINKS and f.get("object") and self.sides.sees_fact(self.reader, f)]

    def _in(self, thing: str, relation: str) -> list:
        """Intention: the links into a thing the reader may see."""
        return [f for f in self.store.current(obj=str(thing), relation=relation)
                if self.sides.sees_fact(self.reader, f)]

    def run(self, shape: Shape) -> list:
        """Intention: the shape run on the graph from its anchors — its complete answer set (sorted)."""
        if shape.kind in CHAINS:
            return sorted(self._walk({shape.anchors[0]}, shape.links))
        if shape.kind == "join":
            (a, ra), (b, rb) = (shape.anchors[0], shape.links[0][0]), (shape.anchors[1], shape.links[1][0])
            return sorted(self._walk({a}, [(ra, "out")]) & self._walk({b}, [(rb, "out")]))
        first = self._walk({shape.anchors[0]}, shape.links[:2])
        return sorted(first & self._walk({shape.anchors[1]}, shape.links[2:]))

    def _walk(self, start: set, links: list) -> set:
        """Intention: every thing reached from the start by the links in order."""
        now = set(start)
        for relation, _ in links:
            now = {f["object"] for thing in now for f in self._out(thing, relation)}
            if not now:
                break
        return now

    def sample(self, kind: str) -> Shape | None:
        """Intention: one shape of this kind whose answer set is not empty, not too big and all named — or None."""
        facts = [f for f in self.store.current(limit=LOOK_OVER * 4) if f["relation"] in LINKS and f.get("object")]
        facts = [f for f in facts if self.sides.sees_fact(self.reader, f)]
        if not facts:
            return None
        for _ in range(TRIES):
            shape = self._one(kind, self.rng.choice(facts))
            if shape is None:
                continue
            shape.answers = self.run(shape)
            if 0 < len(shape.answers) <= MOST_ANSWERS and all(self.name(a) for a in shape.answers):
                return shape
        return None

    def _one(self, kind: str, start: dict) -> Shape | None:
        """Intention: a shape grown from one fact."""
        hops = {"chain 1": 1, "chain 2": 2, "chain 3": 3}.get(kind)
        if hops:
            links, here, middles = [(start["relation"], "out")], start["object"], []
            for _ in range(hops - 1):
                ahead = self._out(here)
                if not ahead:
                    return None
                step = self.rng.choice(ahead)
                middles.append(here)
                links.append((step["relation"], "out"))
                here = step["object"]
            return Shape(kind, [start["subject"]], links, middles)
        if kind == "join":
            others = [f for f in self._in(start["object"], start["relation"]) if f["subject"] != start["subject"]]
            others += [f for r in LINKS for f in self._in(start["object"], r) if f["subject"] != start["subject"]][:20]
            if not others:
                return None
            other = self.rng.choice(others)
            return Shape(kind, [start["subject"], other["subject"]], [(start["relation"], "out"), (other["relation"], "out")])
        ahead = self._out(start["object"])
        if not ahead:
            return None
        step = self.rng.choice(ahead)
        into = [f for r in LINKS for f in self._in(step["object"], r) if f["subject"] not in (start["object"], start["subject"])][:20]
        if not into:
            return None
        other = self.rng.choice(into)
        return Shape(kind, [start["subject"], other["subject"]],
                     [(start["relation"], "out"), (step["relation"], "out"), (other["relation"], "out")], [start["object"]])
