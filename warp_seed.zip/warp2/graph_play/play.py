# WARP2/warp2/graph_play/play.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/graph_play/play.py
#  Used by   : warp2/work/side/graph_play.py (EvolveOnGraphStep),
#              graph_play/tests/test_graph_play.py.
#  Uses      : graph_play/shapes.py, warp2/chat_learning/asking.py (ask,
#              json_in), warp2/train/training_blocks.py (TrainingBlock),
#              warp2/chat_learning/files.py; stdlib json, math, random.
#  Description:
#    One round of the graph playing against itself (Evolve on Graph,
#    arXiv 2610.35598):
#      1. a shape is sampled — its kind picked by how well each kind has
#         been at the edge of the answerers' ability (the curriculum: kinds
#         whose questions got mixed scores come up more; harder ones join as
#         the easy ones stop being mixed);
#      2. a model (the proposer, in turn) writes one question from it —
#         the anchors' names and the links, the middles and answers hidden;
#         a question that names a hidden thing, or is not a question, is
#         thrown out;
#      3. the models (the solver) answer it TRIES times from the facts
#         round its anchors (what the graph shows them); each answer is
#         scored by F1 against the shape's complete answer set;
#      4. the question's reward is a bell curve of how spread its scores
#         are — highest when some answers were right and some wrong;
#      5. the question (weighted by its reward) and every answer (weighted
#         by its score, the right ones most) become training blocks — the
#         warp's way of learning from a reward — and the round is kept.
#  User intention (Andrew, 2026-10-28): "Evolve on graph ... try to add that
#    in too" (asked: all of it); "just get it all in there". BUILD_LOG 894.
# ============================================================================
"""One self-play round on the graph: a shape, a question, answers scored on the graph, all of it training."""
from __future__ import annotations

import json
import math
import random
from pathlib import Path

from warp2.graph_play.shapes import CHAINS, KINDS, Shapes
from warp2.graph_play.sides import OWNER

# Intention: how many times the question is answered (the paper's five tries).
TRIES = 5
# Intention: the bell curve the reward is — its middle (the spread of half right, half wrong) and width.
MIDDLE, WIDTH = 0.2, 0.08
# Intention: how many facts round the anchors the answerers are shown (the most).
SHOWN = 60
# Intention: how many past rounds each kind's curriculum is read from (the newest).
RECENT = 20

PROPOSE = ("Write ONE question for this pattern in a knowledge graph. Use the start names exactly. Do not name "
           "or hint at the hidden things. Say only the question.\nPattern: {pattern}")
SOLVE = ("Answer from these knowledge-graph facts only.\nFacts:\n{facts}\n\nQuestion: {question}\n"
         "Reply with a JSON list of every answer's name, and nothing else.")


def f1(said, answers) -> float:
    """Intention: how right an answer is against the full set — each name matched as plain lower-case words."""
    plain = lambda s: " ".join(str(s).lower().replace("_", " ").split())  # noqa: E731
    said, answers = {plain(s) for s in said if plain(s)}, {plain(a) for a in answers}
    hit = len(said & answers)
    if not said or not answers or not hit:
        return 0.0
    precision, recall = hit / len(said), hit / len(answers)
    return 2.0 * precision * recall / (precision + recall)


def reward(scores) -> float:
    """Intention: the question's reward — a bell curve of its scores' spread (variance), at most 1."""
    if not scores:
        return 0.0
    mean = sum(scores) / len(scores)
    spread = sum((s - mean) ** 2 for s in scores) / len(scores)
    return math.exp(-((spread - MIDDLE) ** 2) / (2.0 * WIDTH ** 2))


class GraphRound:
    """Intention: one self-play round over the graph, and what has been kept of the rounds before."""

    def __init__(self, state, store, fleet, ingestor=None, reader: str = OWNER, seed: int | None = None) -> None:
        """Intention: where rounds are kept, the graph, the models, where blocks go, and whose view it plays on."""
        self.home = Path(state) / "graph_play"
        self.store, self.fleet, self.ingestor = store, fleet, ingestor
        self.shapes = Shapes(store, reader, seed)
        self.rng = random.Random(seed)

    def _rounds(self) -> list:
        """Intention: the rounds kept so far."""
        path = self.home / "rounds.jsonl"
        if not path.is_file():
            return []
        out = []
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
        return out

    def kind(self) -> str:
        """Intention: the shape kind to try — each weighed by its recent mean reward (a kind never tried counts
        high, so every kind is tried)."""
        rounds = self._rounds()
        weights = []
        for kind in KINDS:
            had = [r["reward"] for r in rounds if r.get("shape", {}).get("kind") == kind][-RECENT:]
            weights.append(0.1 + (sum(had) / len(had) if had else 1.0))
        return self.rng.choices(KINDS, weights=weights)[0]

    def pattern(self, shape) -> str:
        """Intention: the shape as words — the anchors named, the links said, the hidden things as "something"."""
        name = self.shapes.name
        if shape.kind in CHAINS:
            path = " -> ".join(f"[{r}] something" for r, _ in shape.links)
            return f"start at '{name(shape.anchors[0])}', follow {path}; the answers are every thing at the end"
        if shape.kind == "join":
            return (f"the things that '{name(shape.anchors[0])}' [{shape.links[0][0]}] and that "
                    f"'{name(shape.anchors[1])}' [{shape.links[1][0]}] — both")
        return (f"start at '{name(shape.anchors[0])}', follow [{shape.links[0][0]}] something -> [{shape.links[1][0]}] "
                f"something; of those, the ones that '{name(shape.anchors[1])}' also [{shape.links[2][0]}]")

    def leaks(self, question: str, shape) -> bool:
        """Intention: whether the question names a hidden middle or an answer (or is not a question)."""
        text = " ".join(str(question).lower().replace("_", " ").split())
        if not text.endswith("?") or len(text) < 8:
            return True
        hidden = [self.shapes.name(t) for t in list(shape.middles) + list(shape.answers)]
        anchors = {self.shapes.name(a).lower() for a in shape.anchors}
        return any(h and h.lower() not in anchors and h.lower() in text for h in hidden)

    def facts(self, shape) -> list:
        """Intention: what the answerers are shown — the facts round the anchors, as far out as the shape goes."""
        seen, out = set(), []
        for anchor in shape.anchors:
            for fact in self.store.related(anchor, depth=shape.hops()):
                key = (fact["subject"], fact["relation"], fact["object"])
                if key in seen or not self.shapes.sides.sees_fact(self.shapes.reader, fact):
                    continue
                seen.add(key)
                out.append(f"'{self.shapes.name(fact['subject'])}' {fact['relation']} '{self.shapes.name(fact['object'])}'")
        self.rng.shuffle(out)
        return out[:SHOWN]

    def turn(self) -> dict:
        """Intention: one round — or why none ran."""
        from warp2.chat_learning.asking import ask, json_in
        models = sorted(self.fleet.names()) if self.fleet is not None else []
        if not models:
            return {"did": "no models to play"}
        kind = self.kind()
        shape = self.shapes.sample(kind)
        if shape is None:
            return {"did": "no shape", "kind": kind}
        rounds = self._rounds()
        proposer = models[len(rounds) % len(models)]
        question = ask(self.fleet, proposer, PROPOSE.format(pattern=self.pattern(shape))).strip().splitlines()
        question = question[0].strip() if question else ""
        if self.leaks(question, shape):
            return self._keep({"did": "question thrown out", "shape": shape.kept(), "by": proposer,
                               "question": question, "reward": 0.0, "scores": []})
        shown = "\n".join(self.facts(shape))
        names = [self.shapes.name(a) for a in shape.answers]
        tries = []
        for i in range(TRIES):
            solver = models[(len(rounds) + 1 + i) % len(models)]
            heard = ask(self.fleet, solver, SOLVE.format(facts=shown, question=question))
            said = json_in(heard)
            said = [str(s) for s in said] if isinstance(said, list) else []
            tries.append({"by": solver, "said": said, "score": round(f1(said, names), 4), "words": heard})
        scores = [t["score"] for t in tries]
        record = {"did": "played", "shape": shape.kept(), "answers": names, "by": proposer, "question": question,
                  "scores": scores, "reward": round(reward(scores), 4),
                  "tries": [{k: t[k] for k in ("by", "said", "score")} for t in tries]}
        record["blocks"] = self._blocks(record, tries)
        return self._keep(record)

    def _blocks(self, record: dict, tries: list) -> list:
        """Intention: the question (weighted by its reward) and each answer (by its score) as training blocks."""
        if self.ingestor is None:
            return []
        from warp2.train.training_blocks import TrainingBlock
        from warp2.util import now_iso, sha256_hex
        made = []
        def block(kind, intent, words, by, weight, extra):
            """Intention: one training block from this round, recorded and kept in `made`."""
            bid = sha256_hex(f"graph:{kind}:{by}:{intent}:{words}:{now_iso()}".encode("utf-8"))[:16]
            made.append(self.ingestor.record_block(TrainingBlock(
                block_id=bid, domain="chat", subject=f"graph_play:{kind}", intent=intent,
                positive={"gold_behavior": words, "by": by, **extra}, negative={},
                weight=max(0.05, min(1.0, float(weight))), features={"reward": float(record["reward"])},
                provenance={"source": "evolve on graph", "by": by}, modality="text", modalities=["text"],
                modality_payload={"text": words})))
        block("question", PROPOSE.format(pattern=self.pattern(_back(record["shape"]))), record["question"],
              record["by"], record["reward"], {"scores": record["scores"]})
        for t in tries:
            block("answer", record["question"], json.dumps(t["said"]), t["by"], t["score"],
                  {"right": record["answers"], "score": t["score"]})
        return made

    def _keep(self, record: dict) -> dict:
        """Intention: the round added to rounds.jsonl (nothing is thrown away)."""
        self.home.mkdir(parents=True, exist_ok=True)
        with (self.home / "rounds.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        return record


def _back(kept: dict):
    """Intention: a kept shape back as a Shape."""
    from warp2.graph_play.shapes import Shape
    return Shape(kept["kind"], list(kept["anchors"]), [tuple(l) for l in kept["links"]], list(kept.get("middles", [])),
                 list(kept.get("answers", [])))
