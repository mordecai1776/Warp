# WARP2/warp2/builders/triage.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/triage.py
#  Used by   : warp2/control/preflight.py (when the gate fails),
#              warp2/builders/tests/.
#  Uses      : warp2/integrity/source_watch.py (SourceWatch — what changed
#              since the last good start), warp2/builders/entries.py (who
#              named the changed files), warp2/builders/scores.py,
#              warp2/builders/ability.py, warp2/builders/last_good.py;
#              docs/BUILD_LOG.md (an entry by the gate); (stdlib) json,
#              shutil, time.
#  Description:
#    When the start gate fails, the changes since the last good start are
#    set aside builder by builder — the lowest-scoring builder's first — and
#    the gate tried again, until it passes or nothing is left to set aside.
#    A set-aside file is moved to archive/set_aside_by_gate/<when>/<builder>/
#    (nothing is deleted) and its last good copy put back; a file that was
#    never kept good is left where it is (it cannot be put back). Who changed
#    a file is the newest entry since the last good start that names it;
#    a file no entry names is "unknown". Every set-aside is written to
#    state/builders/set_aside.jsonl and to the build log, by the gate, so the
#    builder sees what to prove again.
#  User intention (Andrew, 2026-10-31): "reduce ability based of of said
#    scores"; (2026-09-25) "they just have to prove the new parts in a
#    project first ... proven changes are swapped in at restart". BUILD_LOG
#    1004.
# ============================================================================
"""When the start fails: set aside the lowest-scoring builder's changes first, and try the gate again."""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

from warp2.builders.ability import Ability
from warp2.builders.entries import LogEntries
from warp2.builders.last_good import LastGood
from warp2.builders.scores import UNKNOWN, Scores

LOG = "docs/BUILD_LOG.md"
THE_GATE = "the gate"


class Attribution:
    """Intention: who changed each file since the last good start, by the entries that name it."""

    def __init__(self, root, state) -> None:
        """Intention: the tree and the state folder that holds the last good start's entry number."""
        self.root, self.state = Path(root), Path(state)

    def last_entry(self) -> int:
        """Intention: the highest entry number at the last good start (written by the source check); 0 when unknown."""
        try:
            return int(json.loads((self.state / "builders" / "last_sitting.json").read_text(encoding="utf-8"))["entry"])
        except (OSError, ValueError, KeyError, TypeError):
            return 0

    def of(self, files) -> dict:
        """Intention: {file: author} — the newest entry since the last good start naming the file, else "unknown"."""
        since = LogEntries(self.root).since(self.last_entry())
        out = {}
        for rel in files:
            author = UNKNOWN
            for entry in since:
                if rel in entry.files(self.root):
                    author = entry.author
            out[rel] = author
        return out


class Triage:
    """Intention: the failed start, set right by setting aside the least-trusted changes first."""

    def __init__(self, root, state) -> None:
        """Intention: the tree and its state folder."""
        self.root, self.state = Path(root), Path(state)
        self.good = LastGood(root, state)
        self.home = self.state / "builders"

    def run(self, gate) -> dict:
        """Intention: `gate()` says whether the start gate passes now. Builders' changes are set aside lowest score
        first, the gate tried after each; the report says what was set aside and whether the gate passed."""
        from warp2.integrity.source_watch import SourceWatch
        seen = SourceWatch(self.root, self.state).changed()
        files = list(seen.get("files", []))
        report = {"changed": files, "set_aside": [], "passed": False, "skipped": []}
        if not files:
            return report
        who = Attribution(self.root, self.state).of(files)
        scores = Scores(self.root, self.state).read().get("builders", {})
        ability = Ability({a: r.get("score", 0.0) for a, r in scores.items()})
        stamp = time.strftime("%Y-%m-%d_%H%M%S")
        for author in ability.order(who.values()):
            mine = [rel for rel, by in who.items() if by == author]
            moved = []
            for rel in mine:
                if self.good.has(rel) or not self._existed_before(rel):
                    self._set_aside(rel, author, stamp)
                    moved.append(rel)
                else:
                    report["skipped"].append({"file": rel, "by": author, "why": "no good copy kept yet"})
            if not moved:
                continue
            report["set_aside"].append({"by": author, "score": ability.score(author), "files": moved})
            self._record(report["set_aside"][-1], stamp)
            if gate():
                report["passed"] = True
                break
        self._log(report, stamp)
        return report

    def _existed_before(self, rel: str) -> bool:
        """Intention: whether the file was in the tree at the last good start (a new file can be set aside whole)."""
        try:
            before = json.loads((self.state / "locks" / "source_seen.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return True
        return rel in before

    def _set_aside(self, rel: str, author: str, stamp: str) -> None:
        """Intention: the changed file moved to the archive (kept), and its good copy put back when there is one."""
        source = self.root / rel
        aside = self.root / "archive" / "set_aside_by_gate" / stamp / author.replace(" ", "_") / rel
        aside.parent.mkdir(parents=True, exist_ok=True)
        if source.is_file():
            shutil.move(str(source), str(aside))
        self.good.restore(rel)

    def _record(self, row: dict, stamp: str) -> None:
        """Intention: one line per set-aside, where the builders and the scores can read it."""
        self.home.mkdir(parents=True, exist_ok=True)
        with (self.home / "set_aside.jsonl").open("a", encoding="utf-8") as out:
            out.write(json.dumps(dict(row, at=stamp)) + "\n")

    def _log(self, report: dict, stamp: str) -> None:
        """Intention: the build log says what the gate did, so the builder sees what to prove again."""
        if not report["set_aside"]:
            return
        number = max([e.number for e in LogEntries(self.root).all()] or [0]) + 1
        lines = [f"\n## {number}. The start gate failed; changes set aside, lowest-scoring builder first - "
                 f"{time.strftime('%Y-%m-%d')} ({THE_GATE})\n"]
        lines.append("Why: the prestart regression gate failed on the tree as it stood (state/diagnostics/tests.out.txt). "
                     "The changes since the last good start were set aside builder by builder, lowest score first "
                     "(warp2/builders/), each put back to its last good copy, and the gate tried again.\n")
        for row in report["set_aside"]:
            lines.append(f"- {row['by']} (score {row['score']:+.3f}): " + ", ".join(f"`{f}`" for f in row["files"])
                         + f" -> archive/set_aside_by_gate/{stamp}/")
        lines.append(f"- gate after: {'passed' if report['passed'] else 'still failing'}."
                     + (" A set-aside change is not lost: prove it (its tests pass in the shadow tree) and put it back."))
        for skip in report["skipped"]:
            lines.append(f"- left in place ({skip['why']}): `{skip['file']}` ({skip['by']})")
        with (self.root / LOG).open("a", encoding="utf-8") as log:
            log.write("\n".join(lines) + "\n")
