# WARP2/warp2/builders/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/__init__.py
#  Used by   : warp2/control/preflight.py, warp2/integrity/source_watch.py.
#  Uses      : (nothing — a package marker).
#  Description:
#    The builders that change WARP2 — Codex, Antigravity, Grok, Muse, the
#    hourly Claude run, Claude — scored by what the record says of their
#    changes, and given ability by their score: the gate proves a low-scoring
#    builder's changes first and sets them aside when the start fails.
#  User intention (Andrew, 2026-10-31): "We need to start giving scores for
#    the hourly models that make changes and reduce ability based of of said
#    scores." BUILD_LOG 1005.
# ============================================================================
"""The builders that change WARP2: their scores from the record, and the ability their scores give them."""
