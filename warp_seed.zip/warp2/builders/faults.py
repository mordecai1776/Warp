# WARP2/warp2/builders/faults.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/faults.py
#  Used by   : design/tests/test_no_new_faults.py (every worker's CHECK_FIXES run and the start gate),
#              warp2/improve/proof.py (a candidate file with more faults than the live one is not proven),
#              `python -m warp2.builders.faults` (the report; --rebase writes the baseline).
#  Uses      : design/plans/faults_baseline.json (the faults known on 2026-11-07, by file and kind);
#              (stdlib) ast, json, pathlib, re, sys.
#  Description:
#    The faults every worker keeps making, found by reading the code (design/plans/AUDIT_2026-11-07.md):
#      except_default   - an error caught and a default returned or assigned in its place, with nothing said
#      shape_default    - a wrong shape or a missing measure quietly replaced by a number ("x if isinstance(..) else 0",
#                         '.get("loss", 0.0)')
#      set_number       - a cap or count standing in for a measurement (MOST_X = 8, [:50], range(100), limit=500)
#      kept_file        - a kept JSON file read with json.loads(read_text) or written with write_text(json.dumps)
#                         instead of warp2/record/kept_file.py (only a missing file is a fresh start; writes whole)
#    A fault is counted by file and kind. The baseline holds what was there on the day this was written; a NEW
#    fault anywhere (a file or kind not in the baseline, or more of a kind in a file than the baseline has) fails
#    the design test, so no worker can add one; a fault taken out lowers the count, and --rebase records that.
#    A line that is one of these on purpose carries "# fault: ok <why>" and is not counted - the reason is read
#    by whoever looks next.
#  User intention (Andrew, 2026-11-06 15:34): "make sure there's no more bullshit ... like that in there";
#    2026-11-07 04:01: "set the automation for Claude to look for errors like these and other common errors that
#    are being made within the construction of the warp ... make sure that all of the automations follow that."
# ============================================================================
"""The faults every worker keeps making, counted; a new one fails the gate."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOTS = ("warp2", "projects/behemoth_eye")
SKIP_PARTS = {"tests", "archive", "__pycache__", "state", "docs", "design"}
BASELINE = Path("design/plans/faults_baseline.json")
OK_MARK = "# fault: ok"

DEFAULT = r"(None|0|0\.0|1\.0|\{\}|\[\]|\"\"|''|False|True|dict\(\)|list\(\))"
MEASURES = r"(loss|score|right|accuracy|error|gap|off_m|harm|weight|share)"
KINDS = {
    "shape_default": [
        re.compile(r"isinstance\([^)]*\)\s*else\s*" + DEFAULT + r"\b"),
        re.compile(r"\.get\(\s*[\"']" + MEASURES + r"[\"']\s*,\s*-?\d+(\.\d+)?\s*\)"),
    ],
    "set_number": [
        re.compile(r"^\s*(MOST|MAX|MIN|LIMIT|FEWEST|CAP|KEEP|TOP)[A-Z_]*\s*=\s*\d"),
        re.compile(r"\[\s*:\s*\d{2,}\s*\]|\[\s*-\s*\d{2,}\s*:\s*\]"),
        re.compile(r"\brange\(\s*\d{2,}\s*\)"),
        re.compile(r"\blimit\s*=\s*\d{2,}\b"),
    ],
    "kept_file": [
        re.compile(r"json\.loads\([^\n]*\.read_text\("),
        re.compile(r"\.write_text\(\s*json\.dumps\("),
    ],
}
EXCEPT = re.compile(r"^\s*except\b[^:]*:\s*(#.*)?$")
RETURNS_DEFAULT = re.compile(r"^\s*(return\s+" + DEFAULT + r"\s*$|[A-Za-z_][\w.\[\]\"']*\s*=\s*" + DEFAULT + r"\s*$)")
SAYS = re.compile(r"\b(raise|logging|warning|noted\(|print\(|\.append\(|said\[|error|why)\b")


def _lines(path: Path) -> list:
    """Intention: the file's lines, whatever its encoding did."""
    return path.read_text(encoding="utf-8", errors="replace").splitlines()


def _in_string_or_comment(line: str) -> bool:
    """Intention: a comment or docstring line is words about code, not code."""
    s = line.strip()
    return s.startswith("#") or s.startswith('"""') or s.startswith("'''")


def faults_in(path: Path) -> list:
    """Intention: [(kind, line number, the line)] for one file; a line marked "# fault: ok <why>" is not one."""
    return faults_in_text(_lines(path))


def faults_in_text(lines: list) -> list:
    """Intention: the same reading on lines already in hand (a candidate file the improve lane has not written yet)."""
    out = []
    for i, line in enumerate(lines):
        if OK_MARK in line or _in_string_or_comment(line):
            continue
        for kind, patterns in KINDS.items():
            if kind == "set_number" and ("hexdigest(" in line or "uuid" in line):
                continue  # a cut of a hash is an id, not a cap
            if any(p.search(line) for p in patterns):
                out.append((kind, i + 1, line.strip()[:140]))
        if EXCEPT.match(line):
            depth = len(line) - len(line.lstrip())
            body = []
            for after in lines[i + 1:i + 4]:
                if after.strip() and len(after) - len(after.lstrip()) <= depth:
                    break  # the except body ended
                body.append(after)
            if body and RETURNS_DEFAULT.match(body[0]) and not any(SAYS.search(b) for b in body) \
                    and not any(OK_MARK in b for b in body):
                out.append(("except_default", i + 1, (line.strip() + " ... " + body[0].strip())[:140]))
    return out


def tree_faults(root: Path) -> dict:
    """Intention: {relative path: [(kind, line, text)]} over the tree's own code (tests, archives, state left out)."""
    found = {}
    for top in ROOTS:
        for path in sorted((root / top).rglob("*.py")):
            if SKIP_PARTS & set(path.relative_to(root).parts):
                continue
            got = faults_in(path)
            if got:
                found[path.relative_to(root).as_posix()] = got
    return found


def counted(found: dict) -> dict:
    """Intention: {path: {kind: count}}."""
    out = {}
    for path, rows in found.items():
        for kind, _, _ in rows:
            out.setdefault(path, {})[kind] = out.setdefault(path, {}).get(kind, 0) + 1
    return out


def new_against(found: dict, baseline: dict) -> list:
    """Intention: every fault beyond the baseline - (path, kind, now, allowed, the lines) - worst first."""
    now = counted(found)
    out = []
    for path, kinds in now.items():
        for kind, count in kinds.items():
            allowed = int(baseline.get(path, {}).get(kind, 0))
            if count > allowed:
                lines = [f"{line}: {text}" for k, line, text in found[path] if k == kind]
                out.append((path, kind, count, allowed, lines))
    out.sort(key=lambda row: -(row[2] - row[3]))
    return out


def read_baseline(root: Path) -> dict:
    """Intention: the baseline as kept; none kept is an empty one (every fault is then new)."""
    path = root / BASELINE
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}


def write_baseline(root: Path, found: dict) -> Path:
    """Intention: the counts as they stand, written whole under a temporary name."""
    import os
    path = root / BASELINE
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(counted(found), indent=1, sort_keys=True), encoding="utf-8")
    os.replace(temporary, path)
    return path


def report(root: Path) -> str:
    """Intention: the whole picture in plain words: totals by kind, the worst files, what is new."""
    found = tree_faults(root)
    by_kind = {}
    for rows in found.values():
        for kind, _, _ in rows:
            by_kind[kind] = by_kind.get(kind, 0) + 1
    lines = [f"faults in the tree: {sum(by_kind.values())}  " + "  ".join(f"{k} {v}" for k, v in sorted(by_kind.items()))]
    worst = sorted(found.items(), key=lambda kv: -len(kv[1]))[:12]
    lines += [f"  {len(rows):4d}  {path}" for path, rows in worst]
    new = new_against(found, read_baseline(root))
    lines.append(f"new against the baseline: {sum(n - a for _, _, n, a, _ in new)}")
    for path, kind, now, allowed, texts in new:
        lines.append(f"  {path} {kind}: {now} (baseline {allowed})")
        lines += [f"      {t}" for t in texts[:6]]
    return "\n".join(lines)


def main(argv: list) -> int:
    """Intention: the report; --rebase writes the baseline from what is there now."""
    root = Path(argv[1]) if len(argv) > 1 and not argv[1].startswith("--") else Path(__file__).resolve().parents[2]
    if "--rebase" in argv:
        path = write_baseline(root, tree_faults(root))
        print("baseline written:", path)
    print(report(root))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
