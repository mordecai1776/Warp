# WARP2/warp2/builders/last_good.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/last_good.py
#  Used by   : warp2/integrity/source_watch.py (kept after every start the
#              gate let through), warp2/builders/triage.py (restored when a
#              start fails), warp2/builders/tests/.
#  Uses      : warp2/util.py (atomic_write_bytes); (stdlib) pathlib, shutil.
#  Description:
#    A copy of each watched source file as it was the last time the gate let
#    the warp start — the tree that is known to run. One copy per file, under
#    state/builders/last_good/<path>, refreshed for the files that changed at
#    every good start; bounded by the tree's own size. When a start fails, a
#    set-aside change is put back to this.
#  User intention (Andrew, 2026-09-25): "proven changes are swapped in at
#    restart, never under a running warp"; (2026-10-31) "reduce ability based
#    of of said scores". BUILD_LOG 1005.
# ============================================================================
"""The watched source as it was at the last start the gate let through."""
from __future__ import annotations

from pathlib import Path


class LastGood:
    """Intention: the known-to-run copy of each watched file."""

    def __init__(self, root, state) -> None:
        """Intention: the tree and where its good copies are kept."""
        self.root, self.home = Path(root), Path(state) / "builders" / "last_good"

    def path_of(self, rel: str) -> Path:
        """Intention: where a file's good copy lives."""
        return self.home / rel

    def has(self, rel: str) -> bool:
        """Intention: whether a good copy of this file is kept."""
        return self.path_of(rel).is_file()

    def keep(self, rels) -> int:
        """Intention: these files, as they are now, kept as the good copies (the gate just let them run). How many."""
        from warp2.util import atomic_write_bytes
        kept = 0
        for rel in rels:
            source = self.root / rel
            if not source.is_file():
                continue
            target = self.path_of(rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            atomic_write_bytes(target, source.read_bytes())
            kept += 1
        return kept

    def restore(self, rel: str) -> bool:
        """Intention: the file put back to its good copy; False when none is kept."""
        from warp2.util import atomic_write_bytes
        good = self.path_of(rel)
        if not good.is_file():
            return False
        target = self.root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_bytes(target, good.read_bytes())
        return True
