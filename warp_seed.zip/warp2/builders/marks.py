# WARP2/warp2/builders/marks.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/marks.py
#  Used by   : warp2/builders/scores.py, warp2/builders/tests/.
#  Uses      : warp2/builders/entries.py; state/receipts/receipts.jsonl and
#              state/deadlines.json (read); (stdlib) json, re, datetime.
#  Description:
#    What the record says against a builder's entries — marks, each a thing
#    that can be read off the record, never an opinion:
#      * UNDONE — a later entry says this build was reverted, taken out or
#        found not to be Andrew's;
#      * FALSE HEALTH — the entry says the machine was healthy or advancing
#        at a time when, by the receipts, a step had been open longer than
#        it had ever taken to finish (state/deadlines.json `max`) with
#        nothing out — motion reported as progress;
#      * UNLOGGED — source changed with no entry naming it (recorded by the
#        source watch as it finds it; the builder is "unknown").
#  User intention (Andrew, 2026-10-31): "giving scores for the hourly models
#    that make changes and reduce ability based of of said scores". Measured
#    2026-10-30: ten hourly entries called a seven-hour step with no result
#    "continuous Eye pipeline execution" and "sustained supervisor health".
#    BUILD_LOG 1005.
# ============================================================================
"""Marks against a builder's entries, each read off the record."""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

from warp2.builders.entries import Entry

UNDONE, FALSE_HEALTH, UNLOGGED = "undone", "false_health", "unlogged"
# Intention: a later entry saying an earlier build was undone — the word near the number, either order.
UNDOING = r"(?:revert(?:ed|s)?|taken (?:back )?out|took out|removed|undone|undid|rolled back|not Andrew's|was not his|backed out)"
NUMBER = r"(?:BUILD_LOG|Build|build|entry|#)\s*(\d{1,4})\b"
UNDONE_AFTER = re.compile(UNDOING + r"[^.\n]{0,160}?" + NUMBER)
UNDONE_BEFORE = re.compile(NUMBER + r"[^.\n]{0,160}?" + UNDOING)
# Intention: how far back in the receipts an entry's time is read (a step open longer than this is seen anyway).
LOOK_BACK = timedelta(days=2)
# Intention: a receipt's time, however the writer spaced the json.
TS = re.compile(r'"ts":\s*"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})')


class Undone:
    """Intention: which entries later entries say were undone, and by which."""

    def of(self, entries: list) -> dict:
        """Intention: {number undone: number that undid it}."""
        out = {}
        for later in entries:
            text = later.title + "\n" + later.body
            for pattern in (UNDONE_AFTER, UNDONE_BEFORE):
                for match in pattern.finditer(text):
                    number = int(match.group(1))
                    if number < later.number:
                        out.setdefault(number, later.number)
        return out


class OpenSteps:
    """Intention: the steps open past their own measured time at a moment, from the receipts."""

    def __init__(self, state) -> None:
        """Intention: the receipts lane and the measured step times of this state folder."""
        self.state = Path(state)
        self.allowance = self._allowances()
        self.rows = None

    def _allowances(self) -> dict:
        """Intention: the longest each step has ever taken to finish, in seconds (state/deadlines.json `max`) — a
        step open longer than it has ever taken is the clear case, and the number is the step's own, never a set one."""
        try:
            kept = json.loads((self.state / "deadlines.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return {verb: float(v.get("max", 0.0)) for verb, v in kept.items()
                if isinstance(v, dict) and v.get("n") and float(v.get("max", 0.0)) > 0.0}

    def _load(self, since: datetime) -> list:
        """Intention: the receipt rows from `since` on — kind, key, verb, time — read once."""
        path = self.state / "receipts" / "receipts.jsonl"
        rows = []
        if not path.is_file():
            return rows
        floor = since.isoformat()[:19]
        with path.open("r", encoding="utf-8", errors="replace") as lane:
            for line in lane:
                stamp = TS.search(line)
                if stamp is None or stamp.group(1) < floor:
                    continue
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                when = _when(row.get("ts"))
                if when is not None:
                    rows.append((when, row.get("kind"), row.get("key"), row.get("verb")))
        return rows

    def overdue_at(self, moment: datetime) -> list:
        """Intention: the verbs of steps that, at `moment`, had been open past their own measured time with no receipt."""
        if self.rows is None:
            self.rows = self._load(moment - LOOK_BACK)
        opened, closed = {}, set()
        for when, kind, key, verb in self.rows:
            if when > moment:
                break
            if kind == "intent":
                opened[key] = (when, verb)
            elif kind in ("receipt", "abandoned"):
                closed.add(key)
        out = []
        for key, (when, verb) in opened.items():
            if key in closed or verb not in self.allowance:
                continue
            if (moment - when).total_seconds() > self.allowance[verb]:
                out.append(verb)
        return out


class Marks:
    """Intention: every mark against every entry, read off the record."""

    def __init__(self, root, state) -> None:
        """Intention: the tree and its state folder."""
        self.root, self.state = Path(root), Path(state)

    def of(self, entries: list) -> dict:
        """Intention: {entry number: [(mark, why)]} for the entries that have any."""
        out: dict = {}
        for number, by in Undone().of(entries).items():
            out.setdefault(number, []).append((UNDONE, f"undone by {by}"))
        steps = OpenSteps(self.state)
        for entry in entries:
            moment = entry.written_at()
            if moment is None or not entry.claims_health():
                continue
            overdue = steps.overdue_at(moment)
            if overdue:
                out.setdefault(entry.number, []).append(
                    (FALSE_HEALTH, f"said healthy at {moment.isoformat()[:16]}Z while {', '.join(sorted(set(overdue)))} "
                                   f"had been open longer than it has ever taken, with nothing out"))
        return out


def _when(ts) -> datetime | None:
    """Intention: a receipt's time as UTC, or None."""
    if not isinstance(ts, str):
        return None
    try:
        when = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except ValueError:
        return None
    return when if when.tzinfo else when.replace(tzinfo=timezone.utc)
