# WARP2/warp2/builders/tests/test_builders_are_scored_and_set_aside_by_score.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/tests/test_builders_are_scored_and_set_aside_by_score.py
#  Used by   : pytest.
#  Uses      : warp2/builders/ (entries, marks, scores, ability, last_good, triage),
#              warp2/integrity/source_watch.py.
#  Description:
#    The record scores the builders and the gate acts on the scores: the log
#    is read into entries with authors and files; a later entry undoing an
#    earlier one, and a health claim made while a step was open longer than
#    it had ever taken, are marks; the score is the share held less the
#    share marked, weighed by evidence; the ability is a gradient; and a
#    failed gate sets aside the lowest-scoring builder's changes first,
#    puts their good copies back, keeps the set-aside files, and logs it.
#  User intention (Andrew, 2026-10-31): "We need to start giving scores for
#    the hourly models that make changes and reduce ability based of of said
#    scores." BUILD_LOG 1005.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.builders.ability import Ability
from warp2.builders.entries import LogEntries
from warp2.builders.last_good import LastGood
from warp2.builders.marks import FALSE_HEALTH, UNDONE, Marks
from warp2.builders.scores import Score, Scores
from warp2.builders.triage import Triage

LOG = """# log

## 10. Codex adds a rule - 2026-10-29 (Codex)

Changed `warp2/a.py`.

## 11. Health report - 2026-10-30 (Antigravity)

- Timestamp: 2026-10-30 21:15:00 CDT. Supervisor healthy, pipeline advancing. Touched `warp2/b.py`.

## 12. Rule from 10 was not Andrew's; reverted - 2026-10-30 (Claude)

Build 10 reverted: the rule was Codex's own. Changed `warp2/a.py`.
"""


def _tree(tmp_path: Path) -> tuple:
    root, state = tmp_path / "WARP2", tmp_path / "WARP2" / "state"
    (root / "docs").mkdir(parents=True)
    (root / "warp2").mkdir()
    (root / "docs" / "BUILD_LOG.md").write_text(LOG, encoding="utf-8")
    (root / "warp2" / "a.py").write_text("A = 2\n", encoding="utf-8")
    (root / "warp2" / "b.py").write_text("B = 2\n", encoding="utf-8")
    (state / "receipts").mkdir(parents=True)
    # Intention: a train_eye intent opened at 19:58Z and never closed; the step has never taken more than 6774 s.
    rows = [{"ts": "2026-10-30T19:58:56+00:00", "kind": "intent", "key": "k1", "verb": "train_eye"},
            {"ts": "2026-10-30T20:00:00+00:00", "kind": "intent", "key": "k2", "verb": "settle_ready"},
            {"ts": "2026-10-30T20:00:01+00:00", "kind": "receipt", "key": "k2", "verb": "settle_ready"}]
    (state / "receipts" / "receipts.jsonl").write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")
    (state / "deadlines.json").write_text(json.dumps({"train_eye": {"n": 5, "mean": 900.0, "spread": 300.0, "max": 6774.0},
                                                      "settle_ready": {"n": 9, "mean": 1.0, "spread": 1.0, "max": 20.0}}),
                                          encoding="utf-8")
    return root, state


def test_the_log_is_read_as_entries_with_authors_and_files(tmp_path):
    root, _ = _tree(tmp_path)
    entries = LogEntries(root).all()
    assert [e.number for e in entries] == [10, 11, 12]
    assert [e.author for e in entries] == ["Codex", "Antigravity", "Claude"]
    assert entries[1].files(root) == ["warp2/b.py"] and entries[1].claims_health()
    assert entries[1].written_at().isoformat() == "2026-10-31T02:15:00+00:00"
    assert entries[0].written_at() is None


def test_an_undone_build_and_a_false_health_claim_are_marks_read_off_the_record(tmp_path):
    root, state = _tree(tmp_path)
    marks = Marks(root, state).of(LogEntries(root).all())
    assert [m for m, _ in marks[10]] == [UNDONE] and "12" in marks[10][0][1]
    assert [m for m, _ in marks[11]] == [FALSE_HEALTH] and "train_eye" in marks[11][0][1]
    assert 12 not in marks


def test_the_score_is_the_share_held_less_the_share_marked_weighed_by_evidence(tmp_path):
    assert Score.of(0, 0) == 0.0
    assert Score.of(1, 0) == 0.5 and Score.of(1, 1) == -0.5
    assert Score.of(9, 0) == 0.9 and Score.of(10, 5) == 0.0 and Score.of(4, 4) == -0.8
    root, state = _tree(tmp_path)
    scores = Scores(root, state).refresh()["builders"]
    assert scores["Codex"]["score"] == -0.5 and scores["Antigravity"]["score"] == -0.5 and scores["Claude"]["score"] == 0.5
    assert (state / "builders" / "scores.json").is_file() and (state / "builders" / "scores.jsonl").is_file()


def test_ability_is_a_gradient_and_orders_the_least_trusted_first():
    ability = Ability({"Codex": -0.5, "Claude": 0.5, "Muse": 0.9})
    assert ability.proof_share("Codex") == 0.75 and ability.proof_share("Claude") == 0.25
    assert ability.proof_share("Muse") == 0.05 and ability.proof_share("never seen") == 0.5
    assert ability.order(["Claude", "Muse", "Codex", "never seen"]) == ["Codex", "never seen", "Claude", "Muse"]


def test_a_failed_gate_sets_aside_the_lowest_scoring_builders_changes_first_and_puts_the_good_copies_back(tmp_path):
    root, state = _tree(tmp_path)
    from warp2.integrity.source_watch import SourceWatch
    watch = SourceWatch(root, state)
    # Intention: the last good start — both files kept, the fingerprint remembered, the log at entry 10.
    (root / "docs" / "BUILD_LOG.md").write_text(LOG.split("## 11.")[0], encoding="utf-8")
    (root / "warp2" / "a.py").write_text("A = 1\n", encoding="utf-8")
    (root / "warp2" / "b.py").write_text("B = 1\n", encoding="utf-8")
    LastGood(root, state).keep(["warp2/a.py", "warp2/b.py"])
    watch.remember(watch.now())
    (state / "builders").mkdir(parents=True, exist_ok=True)
    (state / "builders" / "last_sitting.json").write_text(json.dumps({"entry": 10}), encoding="utf-8")
    # Intention: then the changes — Antigravity's b.py (entry 11) and Claude's a.py (entry 12) — and the scores.
    (root / "docs" / "BUILD_LOG.md").write_text(LOG, encoding="utf-8")
    (root / "warp2" / "a.py").write_text("A = 2\n", encoding="utf-8")
    (root / "warp2" / "b.py").write_text("B = 2  # broken\n", encoding="utf-8")
    Scores(root, state).refresh()
    gates = []

    def gate() -> bool:
        gates.append(1)
        return "broken" not in (root / "warp2" / "b.py").read_text(encoding="utf-8")
    report = Triage(root, state).run(gate)
    assert report["passed"] is True and len(gates) == 1
    assert [row["by"] for row in report["set_aside"]] == ["Antigravity"]
    assert (root / "warp2" / "b.py").read_text(encoding="utf-8") == "B = 1\n", "the good copy is back"
    assert (root / "warp2" / "a.py").read_text(encoding="utf-8") == "A = 2\n", "the better-scored builder's change stays"
    aside = list((root / "archive" / "set_aside_by_gate").rglob("b.py"))
    assert len(aside) == 1 and "broken" in aside[0].read_text(encoding="utf-8"), "nothing is deleted"
    log = (root / "docs" / "BUILD_LOG.md").read_text(encoding="utf-8")
    assert "## 13. The start gate failed" in log and "(the gate)" in log and "Antigravity" in log
    assert (state / "builders" / "set_aside.jsonl").is_file()


def test_a_changed_file_with_no_good_copy_is_left_in_place(tmp_path):
    root, state = _tree(tmp_path)
    from warp2.integrity.source_watch import SourceWatch
    watch = SourceWatch(root, state)
    watch.remember(watch.now())
    (root / "warp2" / "b.py").write_text("B = 3\n", encoding="utf-8")
    report = Triage(root, state).run(lambda: False)
    assert report["passed"] is False and report["set_aside"] == []
    assert report["skipped"] and report["skipped"][0]["file"] == "warp2/b.py"
    assert (root / "warp2" / "b.py").read_text(encoding="utf-8") == "B = 3\n"
