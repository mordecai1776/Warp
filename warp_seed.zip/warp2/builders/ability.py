# WARP2/warp2/builders/ability.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/ability.py
#  Used by   : warp2/builders/triage.py, warp2/builders/tests/.
#  Uses      : (nothing but the scores handed in).
#  Description:
#    What a builder's score lets it do, as a gradient and never a band: the
#    share of its changes the gate proves first is (1 - score) / 2 — a
#    builder at 1 is taken on its word, one at -1 has every change proven
#    before the tree takes it — and when the start fails, the changes set
#    aside first are the lowest-scoring builder's. Nothing is forbidden; a
#    builder earns its way back by entries that hold.
#  User intention (Andrew, 2026-10-31): "reduce ability based of of said
#    scores"; (2026-09-25) "the models must be able to improve ALL parts of
#    the warp itself ... they just have to prove the new parts in a project
#    first"; (2026-09-23) "the parts/size system should be smooth (gradient,
#    not a hard switch)". BUILD_LOG 1005.
# ============================================================================
"""What a builder's score lets it do: how much of its work is proven first, and who is set aside first."""
from __future__ import annotations


class Ability:
    """Intention: the gradient from score to ability."""

    def __init__(self, scores: dict) -> None:
        """Intention: {author: score} as the scores file holds them."""
        self.scores = {a: float(s) for a, s in (scores or {}).items()}

    def score(self, author: str) -> float:
        """Intention: a builder's score; one never seen is at nought, like a first entry."""
        return self.scores.get(author, 0.0)

    def proof_share(self, author: str) -> float:
        """Intention: the share of a builder's changes the gate proves before the tree takes them — (1 - score) / 2."""
        return round(min(1.0, max(0.0, (1.0 - self.score(author)) / 2.0)), 4)

    def order(self, authors) -> list:
        """Intention: the builders lowest score first — the order their changes are set aside in when the start fails."""
        return sorted(set(authors), key=lambda a: (self.score(a), a))
