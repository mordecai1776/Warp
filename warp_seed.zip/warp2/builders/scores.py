# WARP2/warp2/builders/scores.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/scores.py
#  Used by   : warp2/builders/triage.py, warp2/integrity/source_watch.py
#              (refreshed every sitting), warp2/builders/tests/.
#  Uses      : warp2/builders/entries.py, warp2/builders/marks.py,
#              warp2/util.py (atomic_write_bytes); (stdlib) json, time.
#  Description:
#    Each builder's score from the record: of its entries, how many held
#    (no mark against them) and how many were marked — the score is the
#    share held less the share marked, in -1..1, weighed by how much
#    evidence there is (n of n + 1, so one entry is a whisper and a hundred
#    is a voice). Written to state/builders/scores.json each sitting, with a
#    line of history, so the builders and Andrew can read it, and the relay
#    can carry it. Unlogged changes count against "unknown".
#  User intention (Andrew, 2026-10-31): "giving scores for the hourly models
#    that make changes and reduce ability based of of said scores"; (2026-09-23)
#    the gate measured "against the crowd of models that do not change, acting
#    as a standard candle". BUILD_LOG 1005.
# ============================================================================
"""Each builder's score, from what the record says of its entries."""
from __future__ import annotations

import json
import time
from pathlib import Path

from warp2.builders.entries import LogEntries
from warp2.builders.marks import UNLOGGED, Marks

UNKNOWN = "unknown"


class Score:
    """Intention: one builder's standing — the arithmetic, in the open."""

    @staticmethod
    def of(entries: int, marked: int) -> float:
        """Intention: (held - marked) / entries, weighed by entries / (entries + 1); nought with no entries."""
        n = int(entries)
        if n <= 0:
            return 0.0
        held = max(0, n - int(marked))
        return round(((held - int(marked)) / n) * (n / (n + 1.0)), 4)


class Scores:
    """Intention: every builder's score, from the log and the marks, kept where all can read it."""

    def __init__(self, root, state) -> None:
        """Intention: the tree, its state folder, and where the scores are kept."""
        self.root, self.state = Path(root), Path(state)
        self.home = self.state / "builders"
        self.file = self.home / "scores.json"

    def read(self) -> dict:
        """Intention: the last written scores, or nothing."""
        try:
            return json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def unlogged(self) -> int:
        """Intention: how many unlogged source changes the source watch has recorded (marks against "unknown")."""
        path = self.home / "unlogged.jsonl"
        try:
            return sum(1 for line in path.read_text(encoding="utf-8").splitlines() if line.strip())
        except OSError:
            return 0

    def refresh(self) -> dict:
        """Intention: the scores worked out afresh from the whole log and record, written, and handed back."""
        entries = LogEntries(self.root).all()
        marks = Marks(self.root, self.state).of(entries)
        by: dict = {}
        for entry in entries:
            row = by.setdefault(entry.author, {"entries": 0, "held": 0, "marks": {}, "marked": []})
            row["entries"] += 1
            mine = marks.get(entry.number, [])
            if mine:
                row["marked"].append(entry.number)
                for kind, _ in mine:
                    row["marks"][kind] = row["marks"].get(kind, 0) + 1
            else:
                row["held"] += 1
        unlogged = self.unlogged()
        if unlogged:
            row = by.setdefault(UNKNOWN, {"entries": 0, "held": 0, "marks": {}, "marked": []})
            row["entries"] += unlogged
            row["marks"][UNLOGGED] = unlogged
        for author, row in by.items():
            row["score"] = Score.of(row["entries"], len(row["marked"]) + row["marks"].get(UNLOGGED, 0))
            row["marked"] = row["marked"][-20:]
        out = {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "builders": by,
               "why": {str(n): [f"{k}: {w}" for k, w in ms] for n, ms in sorted(marks.items())[-40:]}}
        self._write(out)
        return out

    def _write(self, out: dict) -> None:
        """Intention: the scores file and one line of history, atomically."""
        from warp2.util import atomic_write_bytes
        self.home.mkdir(parents=True, exist_ok=True)
        atomic_write_bytes(self.file, json.dumps(out, indent=1).encode("utf-8"))
        line = {"at": out["at"], "scores": {a: r["score"] for a, r in out["builders"].items()}}
        with (self.home / "scores.jsonl").open("a", encoding="utf-8") as history:
            history.write(json.dumps(line) + "\n")
