# WARP2/warp2/builders/entries.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/builders/entries.py
#  Used by   : warp2/builders/marks.py, warp2/builders/scores.py,
#              warp2/builders/triage.py, warp2/builders/tests/.
#  Uses      : docs/BUILD_LOG.md (read); (stdlib) re, datetime, pathlib.
#  Description:
#    The build log read as what it is: one entry per build, each with its
#    number, its author (the name in brackets at the end of its heading;
#    "Claude" when the heading names none, as the early entries were all
#    Claude's), its date, the files it names, and the time its body says it
#    was written. The record of who changed what, as the builders themselves
#    wrote it.
#  User intention (Andrew, 2026-10-31): "giving scores for the hourly models
#    that make changes". BUILD_LOG 1005.
# ============================================================================
"""The build log's entries: number, author, date, files named, time written."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

LOG = "docs/BUILD_LOG.md"
# Intention: "## 997. Title - 2026-10-30 (Antigravity)" — the number, the title, the date, the author.
HEADING = re.compile(r"^## (\d+)\.\s+(.*?)\s*(?:[-–—]\s*)?(\d{4}-\d{2}-\d{2})?\s*(?:\(([^()]+)\))?\s*$")
# Intention: a path the entry names — a file of the tree, in backticks or bare.
PATH = re.compile(r"`?((?:warp2|projects|design|docs|eye)/[A-Za-z0-9_./-]+\.(?:py|md|bat|json))`?")
# Intention: the Eye's files are often named from their own package ("eye/errors/makers.py").
EYE_HOME = "projects/behemoth_eye/"
# Intention: a time the body gives for itself, with its zone — "2026-10-30 22:15:00 CDT", "03:15:00 UTC".
WHEN = re.compile(r"(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}(?::\d{2})?)\s*(CDT|CST|UTC)")
ZONES = {"CDT": -5, "CST": -6, "UTC": 0}
DEFAULT_AUTHOR = "Claude"


@dataclass
class Entry:
    """Intention: one build as the log tells it."""

    number: int
    title: str
    author: str
    date: str
    body: str = ""
    line: int = 0

    def files(self, root: Path | None = None) -> list:
        """Intention: the tree files this entry names (only those that exist, when a root is given)."""
        names = []
        for match in PATH.finditer(self.title + "\n" + self.body):
            rel = match.group(1).rstrip(".")
            if rel.startswith("eye/"):
                rel = EYE_HOME + rel
            if rel not in names and (root is None or (Path(root) / rel).exists()):
                names.append(rel)
        return names

    def written_at(self) -> datetime | None:
        """Intention: when the body says it was written (UTC), or None when it does not say."""
        match = WHEN.search(self.body)
        if not match:
            return None
        day, clock, zone = match.groups()
        clock = clock if clock.count(":") == 2 else clock + ":00"
        when = datetime.strptime(f"{day} {clock}", "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        return when - timedelta(hours=ZONES[zone])

    def claims_health(self) -> bool:
        """Intention: whether the entry says the machine was healthy or advancing — the claim the record is checked against."""
        text = (self.title + " " + self.body).lower()
        return any(word in text for word in ("healthy", "health ", "continuous", "advanc", "throughput", "clean matrix"))


class LogEntries:
    """Intention: the whole log, entry by entry, oldest first."""

    def __init__(self, root) -> None:
        """Intention: `root` is WARP2/."""
        self.path = Path(root) / LOG

    def all(self) -> list:
        """Intention: every entry with its body; an unnumbered or unreadable heading is no entry."""
        try:
            lines = self.path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return []
        out, current = [], None
        for i, line in enumerate(lines, 1):
            if line.startswith("## "):
                match = HEADING.match(line)
                current = None
                if match:
                    number, title, date, author = match.groups()
                    current = Entry(int(number), title.strip(), (author or DEFAULT_AUTHOR).strip(),
                                    date or "", "", i)
                    out.append(current)
                continue
            if current is not None:
                current.body += line + "\n"
        return out

    def since(self, number: int) -> list:
        """Intention: the entries after a given number."""
        return [e for e in self.all() if e.number > int(number)]
