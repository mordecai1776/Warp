# WARP3/warp2/equation_book/rules/shift.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/shift.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/{rule,price}.py; numpy.
#  Description:
#    THE SHIFT. The digits put in another order before anything else is made of
#    them: reversed, one in k first (each lane together), the two halves woven, or
#    sorted with the order kept. It gains nothing alone - what follows it does -
#    so the search prices it by the chain made after it. Every shift is undone
#    exactly from its settings (and, for sorted, the kept order).
#  User intention (Andrew, 2026-11-16 16:34): "the ability to shift one number into another
#    number in any way ... allows for any number that we have to be shifted into one
#    we dont"; 16:31: a shift at the beginning and a shift after; 01:25: advantage
#    shuffles that lead to known ways to make things better.
# ============================================================================
"""The digits put in another order first - reversed, lanes, woven, or sorted with the order kept."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.price import steps_price
from warp2.equation_book.rules.rule import Fit, Rule

REVERSED, LANES, WOVEN, SORTED = 0, 1, 2, 3
LANE_COUNTS = (2, 3, 4, 8)                  # Intention: one in k first, for these k (and the row widths found)
GAIN = 0.9                                  # Intention: at the beginning a shift is offered when its quick price is this much lower
GAIN_AFTER = 0.5                            # Intention: after other rules (on a result) only a strong gain is followed - every shift
                                            # offered there makes the search make a whole further chain


def _order(kind: int, k: int, n: int) -> np.ndarray:
    """Intention: where each digit of the shifted list comes from, for the shifts made by a rule alone."""
    at = np.arange(n)
    if kind == REVERSED:
        return at[::-1]
    if kind == LANES:
        return np.concatenate([at[lane::k] for lane in range(k)])
    half = (n + 1) // 2                     # WOVEN: the two halves taking turns
    out = np.empty(n, dtype=np.int64)
    out[0::2] = at[:half]
    out[1::2] = at[half:]
    return out


class Shift(Rule):
    """Intention: Andrew's shift - the digits in another order, so what follows finds like digits together."""
    ident = 13
    name = "shift"
    opens = True
    rank = 3

    def fit(self, x, hints):
        """Intention: the shift with the lowest quick price, offered only when clearly below the list as it stands."""
        n = x.size
        if n < 16:
            return None
        ways = [(REVERSED, 0), (WOVEN, 0)] + [(LANES, k) for k in sorted(set(LANE_COUNTS) | {p for p in hints.periods if 1 < p < n // 2})]
        best = None
        for kind, k in ways:
            price = steps_price(x[_order(kind, k, n)])
            if best is None or price < best[0]:
                best = (price, kind, k)
        order = np.argsort(x, kind="stable")
        sorted_price = steps_price(x[order]) + n * max(1, int(n - 1).bit_length())
        plain = steps_price(x)
        gain = GAIN if hints.width else GAIN_AFTER
        if sorted_price < best[0] and sorted_price < gain * plain:
            return Fit([SORTED, 0], [x[order], order.astype(np.int64)], follow=0)
        if best[0] >= gain * plain:
            return None
        _, kind, k = best
        return Fit([kind, k], [x[_order(kind, k, n)]], follow=0)

    def rebuild(self, settings, parts):
        """Intention: every digit put back where the shift took it from."""
        kind, k = settings
        shifted = parts[0]
        order = parts[1] if kind == SORTED else _order(kind, k, shifted.size)
        out = np.empty(shifted.size, dtype=np.int64)
        out[order] = shifted
        return out
