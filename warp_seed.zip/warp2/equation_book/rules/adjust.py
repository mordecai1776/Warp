# WARP3/warp2/equation_book/rules/adjust.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/adjust.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/{rule,price}.py; numpy.
#  Description:
#    ADJUSTMENTS BY PATTERN. A repeating run of amounts (its length a row width
#    found from the digits, or 2 to 8) is taken off the digits; kept are the
#    amounts (the pattern) and what is left. Adjustments by signature - single
#    digits put right - are what the Mostly rule keeps of what is left after.
#  User intention (Andrew, 2026-11-16 16:31): "adjustments that can be done by pattern or
#    by signature"; 16:42: "the adjustments need to be able to happen before and after
#    the shifts" - as a rule of the book it can stand before or after a shift.
# ============================================================================
"""A repeating pattern of amounts taken off the digits; the pattern and what is left are kept."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.price import price_of
from warp2.equation_book.rules.rule import Fit, Rule

LENGTHS = (2, 3, 4, 5, 6, 7, 8)


class Adjust(Rule):
    """Intention: adjustments by pattern - the same few amounts taking turns down the list."""
    ident = 14
    name = "adjust"

    def fit(self, x, hints):
        """Intention: for each pattern length the middle digit of every place of the pattern is the amount; the
        length whose leftover has the lowest quick price is kept, if it is below the list as it stands."""
        n = x.size
        if n < 16:
            return None
        plain = price_of(x)
        best = None
        for length in sorted(set(LENGTHS) | {p for p in hints.periods if 1 < p <= 64}):
            if length * 4 > n:
                continue
            amounts = [int(np.partition(x[place::length], x[place::length].size // 2)[x[place::length].size // 2]) for place in range(length)]
            with np.errstate(over="ignore"):
                left = x - np.resize(np.array(amounts, dtype=np.int64), n)
            price = price_of(left) + 64 * length
            if best is None or price < best[0]:
                best = (price, amounts, left)
        if best is None or best[0] >= plain:
            return None
        _, amounts, left = best
        return Fit(amounts, [left], follow=0)

    def rebuild(self, settings, parts):
        """Intention: the amounts put back on, taking turns."""
        left = parts[0]
        with np.errstate(over="ignore"):
            return left + np.resize(np.array(settings, dtype=np.int64), left.size)
