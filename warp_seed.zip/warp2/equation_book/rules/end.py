# WARP3/warp2/equation_book/rules/end.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/end.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/{rule,earlier}.py; numpy.
#  Description:
#    END TRANSFORMS: the earlier-digit rule's OUTPUT is transformed at the
#    end, and then compared with the digit - if it equals the digit it fits,
#    if it comes near the difference is kept.
#      Negated - each digit from MINUS the one p before (a run that flips sign
#                every step costs almost nothing).
#      Masked  - each digit from the one p before XOR a mask, the mask being
#                the commonest XOR between digits p apart (a run that flips
#                the same bits every step costs almost nothing).
#    Both rebuild a row of p at a time with every row at once: an alternating
#    running sum; a running XOR with the mask on every other row.
#  User intention (Andrew, 2026-11-14 16:16): "Another thing is
#    transformations after equations. So we can sit there and have equations
#    done and then have them transformed at the end. And if that equals out
#    to the number, then it fits."
# ============================================================================
"""End transforms on the earlier-digit rule: its output negated, or XOR a mask, before it is compared."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.earlier import cheapest, rows_of
from warp2.equation_book.rules.rule import Fit, Rule


def _negated(x: np.ndarray, p: int) -> np.ndarray:
    """Intention: the first p digits as they are, then each digit's difference from minus the one p before."""
    left = x.copy()
    left[p:] = x[p:] + x[:-p]
    return left


def _signs(rows: int) -> np.ndarray:
    """Intention: +1 on even rows, -1 on odd rows, as a column to multiply rows by."""
    return np.where(np.arange(rows) % 2 == 0, 1, -1).astype(np.int64)[:, None]


class Negated(Rule):
    """Intention: each digit as minus the one p places before plus a difference."""
    ident = 4
    name = "negated"

    def fit(self, x, hints):
        """Intention: the cheapest distance p for the negated earlier digit, and the differences."""
        got = cheapest(x, hints.periods, _negated)
        if got is None:
            return None
        _, p, left = got
        return Fit([p], [left], follow=0)

    def rebuild(self, settings, parts):
        """Intention: row j is the alternating sum of rows 0..j - (-1)^j times the running sum of (-1)^k row k."""
        (p,), left = settings, parts[0]
        rows = rows_of(left, p)
        sign = _signs(rows.shape[0])
        return (sign * np.cumsum(sign * rows, axis=0)).reshape(-1)[:left.size]


class Masked(Rule):
    """Intention: each digit as the one p places before XOR a fixed mask, XOR what is kept."""
    ident = 5
    name = "masked"

    def fit(self, x, hints):
        """Intention: for each distance p, the commonest XOR between digits p apart is the mask; the cheapest p wins."""
        masks = {}

        def masked(values, p):
            """Intention: the leftover for distance p with its own mask (None when the commonest XOR is nought)."""
            between = values[p:] ^ values[:-p]
            found, counts = np.unique(between, return_counts=True)
            mask = found[np.argmax(counts)]
            if mask == 0:
                return None
            masks[p] = int(mask)
            left = values.copy()
            left[p:] = between ^ mask
            return left
        got = cheapest(x, hints.periods, masked)
        if got is None:
            return None
        _, p, left = got
        return Fit([p, masks[p]], [left], follow=0)

    def rebuild(self, settings, parts):
        """Intention: a running XOR down the columns, and the mask on every other row (it cancels in pairs)."""
        p, mask = settings
        left = parts[0]
        acc = np.bitwise_xor.accumulate(rows_of(left, p), axis=0)
        odd = (np.arange(acc.shape[0]) % 2 == 1)[:, None]
        return np.where(odd, acc ^ np.int64(mask), acc).reshape(-1)[:left.size]
