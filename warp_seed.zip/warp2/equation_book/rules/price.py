# WARP3/warp2/equation_book/rules/price.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/price.py
#  Used by   : warp2/equation_book/rules/{shift,adjust,insert,maths,division}.py.
#  Uses      : numpy.
#  Description:
#    QUICK PRICES AND WRAPPING the column rules share: the bits the widest of some
#    digits needs (a quick price for choosing among ways before the search prices
#    the winner exactly), and a whole number brought into the file's 64 bits.
#  User intention (Andrew, 2026-11-16 16:59): "lets get all of this going in the warp and
#    include everything"; 17:08: "add in all of it to compression by formula".
# ============================================================================
"""Quick prices and 64-bit wrapping shared by the column rules."""
from __future__ import annotations

import numpy as np

_WRAP = 1 << 64
_HALF = 1 << 63


def width_of(digits: np.ndarray) -> int:
    """Intention: the bits the widest of these digits needs with its sign - a quick price for choosing a way."""
    if digits.size == 0:
        return 0
    lo, hi = int(digits.min()), int(digits.max())
    return max(hi.bit_length(), (-lo - 1).bit_length() if lo < 0 else 0) + (1 if lo < 0 else 0)


def price_of(digits: np.ndarray) -> int:
    """Intention: a quick price of a whole list - every digit at the widest one's width."""
    return width_of(digits) * digits.size


def steps_price(digits: np.ndarray) -> int:
    """Intention: a quick price of a list by the steps between neighbours - low when like digits lie together."""
    if digits.size < 2:
        return price_of(digits)
    with np.errstate(over="ignore"):
        return price_of(digits[1:] - digits[:-1])


def wrapped(value: int) -> int:
    """Intention: a whole number brought into the file's 64-bit range the way numpy's own sums wrap."""
    return (value + _HALF) % _WRAP - _HALF
