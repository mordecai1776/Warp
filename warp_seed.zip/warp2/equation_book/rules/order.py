# WARP3/warp2/equation_book/rules/order.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/order.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/rule.py; numpy.
#  Description:
#    FLOAT ORDER - another way of writing the same digit. When a digit is 16,
#    32 or 64 bits wide it may be a floating-point number; its bits are
#    rewritten as a whole number that keeps the float's order (negative
#    floats flipped below the positive ones), every bit kept. Nothing is
#    gained by this alone - what it opens is that floats near each other
#    become whole numbers near each other, so the earlier-digit rules after
#    it leave small differences. The search prices it by what can follow.
#  User intention (Andrew, 2026-11-14 16:11): "We also don't need to be
#    limited to standard numbers or representations".
# ============================================================================
"""Float order: a float's bits rewritten as a whole number that keeps the float's order."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.rules.rule import Fit, Rule

# Intention: the widths floating-point numbers come in (half, single, double).
FLOAT_WIDTHS = (16, 32, 64)


def _parts_of(width: int) -> tuple:
    """Intention: (the sign bit, the mask of the digit's bits) for a digit `width` bits wide, as unsigned numbers."""
    sign = np.uint64(1) << np.uint64(width - 1)
    mask = np.uint64(0xFFFFFFFFFFFFFFFF) if width == 64 else (np.uint64(1) << np.uint64(width)) - np.uint64(1)
    return sign, mask


class FloatOrder(Rule):
    """Intention: the digits as floats' order-keeping whole numbers."""
    ident = 9
    name = "float_order"
    opens = True
    rank = 2

    def fit(self, x, hints):
        """Intention: only for digits as wide as a float; positives get the sign bit set, negatives are flipped."""
        if hints.width not in FLOAT_WIDTHS or x.size < 2:
            return None
        sign, mask = _parts_of(hints.width)
        u = x.view(np.uint64)
        ordered = np.where(u & sign, (~u) & mask, u | sign)
        return Fit([hints.width], [(ordered ^ sign).view(np.int64) if hints.width == 64
                                   else (ordered.astype(np.int64) - np.int64(int(sign)))], follow=0)

    def rebuild(self, settings, parts):
        """Intention: the order-keeping numbers back to the floats' own bits."""
        (width,), held = settings, parts[0]
        sign, mask = _parts_of(width)
        ordered = (held.view(np.uint64) ^ sign) if width == 64 else (held + np.int64(int(sign))).view(np.uint64)
        return np.where(ordered & sign, ordered ^ sign, (~ordered) & mask).view(np.int64)
