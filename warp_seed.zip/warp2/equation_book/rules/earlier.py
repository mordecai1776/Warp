# WARP3/warp2/equation_book/rules/earlier.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/earlier.py
#  Used by   : warp2/equation_book/rules/{vocabulary,end}.py.
#  Uses      : warp2/equation_book/rules/rule.py, warp2/equation_book/
#              packed.py (size_of); numpy.
#  Description:
#    EACH DIGIT FROM THE ONE p PLACES BEFORE. p = 1 is the digit before (a
#    difference; applied again, any polynomial); p = a row's width is the
#    digit above; p = a block's length is the same place one block before.
#    Two ways to take the earlier digit away: subtract it (Earlier), or XOR
#    it (XorEarlier - arithmetic that is not standard, no carries). The
#    distances p tried are the ones at which the digits repeat most (Hints),
#    each priced exactly; the cheapest is kept. Rebuilt a row of p at a
#    time, every row at once (a running sum, or a running XOR, down the
#    columns).
#  User intention (Andrew, 2026-11-14 15:42): "use the shape of equations and
#    shift them to where we need them"; 16:11: "We also don't need to be
#    limited to standard numbers or representations or standard laws of
#    mathematics."
# ============================================================================
"""Each digit from the one p places before - by subtraction or by XOR."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.packed import size_of
from warp2.equation_book.rules.rule import Fit, Rule


def rows_of(values: np.ndarray, p: int) -> np.ndarray:
    """Intention: the digits as rows of p (the last row filled with noughts), so each column is one place's run."""
    m = -(-values.size // p) * p
    out = np.zeros(m, dtype=np.int64)
    out[:values.size] = values
    return out.reshape(-1, p)


def cheapest(x: np.ndarray, periods: list, leftover) -> tuple:
    """(size, p, leftover) for the cheapest distance p, or None when no p fits.

    Intention: the distances come strongest first (after 1); each is priced exactly, and the trying stops at the
    first one that does not beat the cheapest so far (Andrew 15:52: "keep track of the cheapest to a known point")
    - so a list that offers many distances costs only as many tries as keep gaining.
    """
    best = None
    for p in periods:
        if p >= x.size:
            continue
        left = leftover(x, p)
        if left is None:
            continue
        size = size_of(left)
        if best is not None and size >= best[0]:
            break
        best = (size, p, left)
    return best


def _subtracted(x: np.ndarray, p: int) -> np.ndarray:
    """Intention: the first p digits as they are, then each digit less the one p before."""
    left = x.copy()
    left[p:] = x[p:] - x[:-p]
    return left


def _xored(x: np.ndarray, p: int) -> np.ndarray:
    """Intention: the first p digits as they are, then each digit XOR the one p before."""
    left = x.copy()
    left[p:] = x[p:] ^ x[:-p]
    return left


class Earlier(Rule):
    """Intention: each digit as the one p places before plus a difference."""
    ident = 2
    name = "earlier"

    def fit(self, x, hints):
        """Intention: the cheapest distance p, and every digit's difference from the one p before."""
        got = cheapest(x, hints.periods, _subtracted)
        if got is None:
            return None
        _, p, left = got
        return Fit([p], [left], follow=0)

    def rebuild(self, settings, parts):
        """Intention: a running sum down each place's column."""
        (p,), left = settings, parts[0]
        return np.cumsum(rows_of(left, p), axis=0).reshape(-1)[:left.size]


class XorEarlier(Rule):
    """Intention: each digit as the one p places before XOR what is kept (no carries)."""
    ident = 3
    name = "xor_earlier"

    def fit(self, x, hints):
        """Intention: the cheapest distance p, and every digit XOR the one p before."""
        got = cheapest(x, hints.periods, _xored)
        if got is None:
            return None
        _, p, left = got
        return Fit([p], [left], follow=0)

    def rebuild(self, settings, parts):
        """Intention: a running XOR down each place's column."""
        (p,), left = settings, parts[0]
        return np.bitwise_xor.accumulate(rows_of(left, p), axis=0).reshape(-1)[:left.size]
