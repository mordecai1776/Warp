# WARP3/warp2/equation_book/rules/pattern.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/rules/pattern.py
#  Used by   : warp2/equation_book/rules/vocabulary.py.
#  Uses      : warp2/equation_book/rules/rule.py; numpy.
#  Description:
#    THE ADD-AND-SUBTRACT PATTERN. Each digit is made from the three digits
#    before it, each of them added, subtracted or left out, and which of those
#    26 ways is used follows a repeating pattern down the list (its length
#    found from the digits, 1 to 4). Kept are the pattern (the signature) and
#    what is left after it (the part a further rule may make); the first
#    three digits stand in what is left as the starters.
#  User intention (Andrew, 2026-11-16 15:55): "the pattern of add and subtract
#    as a signature or repeating pattern was what I said at the start";
#    16:07: at least three columns, any combination of them, in a repeating
#    pattern or by signature; 16:59: "lets get all of this going in the warp
#    and include everything".
# ============================================================================
"""Each digit from the three before it, added, subtracted or left out by a repeating pattern."""
from __future__ import annotations

import itertools

import numpy as np

from warp2.equation_book.rules.rule import Fit, Rule

BACK = 3                                    # Intention: three columns at the least (Andrew 16:07)
WAYS = tuple(way for way in itertools.product((-1, 0, 1), repeat=BACK) if any(way))
LONGEST = 4                                 # Intention: pattern lengths tried; the cheapest is kept
_WRAP = 1 << 64
_HALF = 1 << 63


def _made(x: np.ndarray, way: tuple) -> np.ndarray:
    """Intention: what one way makes at every place from the three real digits before it (wrapping like the file)."""
    out = np.zeros(x.size, dtype=np.int64)
    with np.errstate(over="ignore"):
        for back, sign in enumerate(way, start=1):
            if sign:
                out[BACK:] += np.int64(sign) * x[BACK - back:x.size - back]
    return out


def _width(left: np.ndarray) -> int:
    """Intention: the bits the widest of these leftovers needs with its sign - a quick price for choosing a way."""
    if left.size == 0:
        return 0
    lo, hi = int(left.min()), int(left.max())
    return max(hi.bit_length(), (-lo - 1).bit_length() if lo < 0 else 0) + (1 if lo < 0 else 0)


def _wrapped(value: int) -> int:
    """Intention: a whole number brought into the file's 64-bit range the way numpy's own sums wrap."""
    return (value + _HALF) % _WRAP - _HALF


class Pattern(Rule):
    """Intention: Andrew's add-and-subtract pattern - the signature is which boxes are added or subtracted at each
    step, repeating; the starters and the adjustments are what is left."""
    ident = 12
    name = "pattern"

    def fit(self, x, hints):
        """Intention: for every pattern length, the cheapest way at each place of the pattern (the places do not
        lean on each other, since each digit is made from the real digits before it); the cheapest length is kept."""
        n = x.size
        if n < 4 * BACK:
            return None
        with np.errstate(over="ignore"):
            lefts = [x - _made(x, way) for way in WAYS]
        plain = _width(x[BACK:]) * (n - BACK)
        best = None
        for length in range(1, LONGEST + 1):
            total, ways = 0, []
            for place in range(length):
                at = np.arange(BACK + (place - BACK) % length, n, length)
                widths = [_width(left[at]) for left in lefts]
                way = int(np.argmin(widths))
                ways.append(way)
                total += widths[way] * at.size
            total += 8 * length
            if best is None or total < best[0]:
                best = (total, ways)
        if best is None or best[0] >= plain:
            return None
        ways = best[1]
        left = x.copy()
        for place, way in enumerate(ways):
            at = np.arange(BACK + (place - BACK) % len(ways), n, len(ways))
            left[at] = lefts[way][at]
        return Fit([len(ways)] + ways, [left], follow=0)

    def rebuild(self, settings, parts):
        """Intention: the starters as they stand, then each digit = what is left there + the three before it by the
        pattern's way for that place."""
        length, ways, left = settings[0], settings[1:], parts[0]
        out = [int(v) for v in left[:BACK]]
        for i in range(BACK, left.size):
            way = WAYS[ways[i % length]]
            out.append(_wrapped(int(left[i]) + sum(sign * out[i - back] for back, sign in enumerate(way, start=1) if sign)))
        return np.array(out, dtype=np.int64)
