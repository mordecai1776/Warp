# WARP3/warp2/equation_book/keep.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/keep.py
#  Used by   : warp2/corpus/levels.py (keep_values / values_back - the
#              corpus's fourth way, BUILD_LOG 1650c); the doors still to be
#              wired: files kept as one number (keep_bytes / bytes_back, for
#              the books of held things); tests.
#  Uses      : warp2/equation_book/{bits,digits,search,written}.py; numpy.
#  Description:
#    THE DOORS. keep_bytes: a file's binary is taken as one number; the
#    number is written in each natural base 2^w (w = 1, 2, 4 ... 64 bits a
#    digit) and the cheapest chain of rules is found for its digits in each;
#    the base and chain that come out smallest are written as binary - or
#    the file itself, as it is, when nothing is smaller (the plain fallback:
#    never more than the file and a few bytes of heading). keep_values: the
#    same for a list of whole numbers (each a 64-bit digit). Whatever is
#    written is read back and compared before it is given out - if it does
#    not come back the same, it is an error, never a guess.
#    File layout: "EQB" and a version byte; a kind byte (0 the file as it
#    is, 1 a file as one number, 2 a list of numbers); for 0 the length and
#    the bytes; for 1 the length and the width w; then the chain (written.py).
#    Space is what chooses. The time to rebuild is the other thing Andrew
#    counts; it weighs in when a caller says how often a value is read
#    (step 3) - until then every rule here rebuilds a whole row at a time.
#  User intention (Andrew, 2026-11-14 17:06): "for storage we should store
#    the file as a binary"; 17:08: "the binary as a number"; 15:59: "The only
#    things that matter are storage space and time to generate from storage."
# ============================================================================
"""The doors: a file (as one number) or a list of numbers kept as its cheapest recipe, read back exactly."""
from __future__ import annotations

import numpy as np

from warp2.equation_book.bits import put, take
from warp2.equation_book.digits import NATURAL, bytes_of, digits_of
from warp2.equation_book.search import best_chain
from warp2.equation_book.written import read_chain, write_chain

MAGIC = b"EQB\x01"
AS_IT_IS, AS_ONE_NUMBER, AS_NUMBERS = 0, 1, 2


def keep_bytes(raw: bytes) -> bytes:
    """A file kept as the cheapest recipe for the one number its binary is, or as it is when nothing is smaller.

    Intention: every natural digit width is tried, because which base makes the number cheapest depends on what
    the file holds (bytes, pairs of bytes, floats...).
    """
    raw = bytes(raw)
    plain = MAGIC + bytes([AS_IT_IS]) + put([len(raw)]) + raw
    best = None
    for width in NATURAL:
        size, chain, left = best_chain(digits_of(raw, width), width)
        if best is None or size < best[0]:
            best = (size, width, chain, left)
    _, width, chain, left = best
    kept = MAGIC + bytes([AS_ONE_NUMBER]) + put([len(raw), width]) + write_chain(chain, left)
    if len(kept) >= len(plain):
        kept = plain
    if bytes_back(kept) != raw:
        raise ValueError("the equation book did not give the file back the same - nothing kept")
    return kept


def bytes_back(kept: bytes) -> bytes:
    """Intention: the file back from what keep_bytes wrote, exactly."""
    view = memoryview(kept)
    if bytes(view[:len(MAGIC)]) != MAGIC:
        raise ValueError("not kept by the equation book")
    kind, at = view[len(MAGIC)], len(MAGIC) + 1
    length, at = take(view, at)
    if kind == AS_IT_IS:
        return bytes(view[at:at + length])
    if kind != AS_ONE_NUMBER:
        raise ValueError("kept by the equation book as numbers, not as a file")
    width, at = take(view, at)
    digits, _ = read_chain(kept, at)
    return bytes_of(digits, width, length)


def keep_values(values) -> bytes:
    """Intention: a list of whole numbers kept as their cheapest recipe (each number one 64-bit digit), read back
    and compared before it is given out."""
    x = np.asarray(values, dtype=np.int64).ravel()
    _, chain, left = best_chain(x, 64)
    kept = MAGIC + bytes([AS_NUMBERS]) + write_chain(chain, left)
    if not np.array_equal(values_back(kept), x):
        raise ValueError("the equation book did not give the numbers back the same - nothing kept")
    return kept


def values_back(kept: bytes) -> np.ndarray:
    """Intention: the list of whole numbers back from what keep_values wrote, exactly."""
    view = memoryview(kept)
    if bytes(view[:len(MAGIC)]) != MAGIC or view[len(MAGIC)] != AS_NUMBERS:
        raise ValueError("not a list of numbers kept by the equation book")
    digits, _ = read_chain(kept, len(MAGIC) + 1)
    return digits
