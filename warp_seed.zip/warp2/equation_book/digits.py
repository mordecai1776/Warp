# WARP3/warp2/equation_book/digits.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/digits.py
#  Used by   : warp2/equation_book/keep.py; tests.
#  Uses      : numpy.
#  Description:
#    A FILE'S BINARY AS ONE NUMBER, WRITTEN IN BASE 2^w. The file's bits, the
#    first byte's highest bit first, are one whole number. Written in base
#    2^w its digits are the bits taken w at a time, the most significant
#    first (with nought bits in front to fill the first digit). w = 8 gives
#    the file's bytes, w = 16 its bytes in pairs, and so on; any w from 1 to
#    64 can be asked for. Back: the digits give the number, and the file's
#    length in bytes (kept beside it) says how many leading noughts the file
#    had, so the same bytes come back.
#  User intention (Andrew, 2026-11-14 17:06): "for storage we should store
#    the file as a binary"; 17:08: "the binary as a number".
# ============================================================================
"""A file's bytes as one number's digits in base 2^w, and back."""
from __future__ import annotations

import numpy as np

# Intention: the base-2^w widths a computer's own numbers come in - a file's
# values most often line up with one of these. Other widths can be asked for.
NATURAL = (1, 2, 4, 8, 16, 32, 64)
# Intention: the widths numpy reads as whole big-endian numbers at once; any other width goes bit by bit.
WHOLE_BYTES = (8, 16, 32, 64)


def digits_of(raw: bytes, width: int) -> np.ndarray:
    """The number held in `raw`, as its digits in base 2^width, most significant first (int64 holding the digit's bits).

    Intention: whole bytes are read as big-endian numbers at once; other widths go bit column by bit column, so
    the memory needed is the file's bits once, not a number per bit.
    """
    data = np.frombuffer(raw, dtype=np.uint8)
    if data.size == 0:
        return np.zeros(0, dtype=np.int64)
    if width in WHOLE_BYTES:
        size = width // 8
        front = (-data.size) % size
        whole = np.concatenate([np.zeros(front, dtype=np.uint8), data])
        return whole.view(">u%d" % size).astype(np.uint64).view(np.int64) if size > 1 else whole.astype(np.int64)
    bits = np.unpackbits(data)
    front = (-bits.size) % width
    bits = np.concatenate([np.zeros(front, dtype=np.uint8), bits]).reshape(-1, width)
    out = np.zeros(bits.shape[0], dtype=np.uint64)
    for column in range(width):
        out = (out << np.uint64(1)) | bits[:, column].astype(np.uint64)
    return out.view(np.int64)


def bytes_of(digits: np.ndarray, width: int, length: int) -> bytes:
    """The file of `length` bytes whose number has these digits in base 2^width.

    Intention: the exact inverse of digits_of - the nought bits put in front to fill the first digit are taken
    off again.
    """
    d = np.asarray(digits, dtype=np.int64).view(np.uint64)
    if length == 0:
        return b""
    if width in WHOLE_BYTES:
        size = width // 8
        raw = d.astype(">u%d" % size).tobytes() if size > 1 else d.astype(np.uint8).tobytes()
        return raw[len(raw) - length:]
    bits = np.zeros((d.size, width), dtype=np.uint8)
    for column in range(width):
        bits[:, column] = ((d >> np.uint64(width - 1 - column)) & np.uint64(1)).astype(np.uint8)
    flat = bits.reshape(-1)
    return np.packbits(flat[flat.size - 8 * length:]).tobytes()
