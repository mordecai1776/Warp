# WARP3/warp2/equation_book/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/tests/__init__.py
#  Used by   : pytest (the package of the equation book's tests).
#  Uses      : nothing.
#  Description:
#    The tests of the equation book: every file and every list of numbers
#    comes back bit for bit, a file made by a rule is kept as that rule, and
#    every rule rebuilds exactly what it fitted.
#  User intention (Andrew, 2026-11-14 17:06): "for storage we should store the
#    file as a binary"; 17:08 "the binary as a number". BUILD_LOG 1647c.
# ============================================================================
