# WARP3/warp2/equation_book/tests/test_the_equation_book_gives_every_file_back_bit_for_bit.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/equation_book/tests/test_the_equation_book_gives_every_file_back_bit_for_bit.py
#  Used by   : the test suite.
#  Uses      : warp2/equation_book/{bits,digits,packed,keep}.py; numpy;
#              (stdlib) random.
#  Description:
#    Every file comes back the same, bit for bit - empty, one byte, leading
#    nought bytes, random, any digit width; every list of numbers too, the
#    int64 extremes included; and nothing is ever kept bigger than the file
#    and a few bytes of heading. The binary pieces read back: numbers of any
#    size seven bits a byte, bits counted exactly, packed lists priced exactly.
#  User intention (Andrew, 2026-11-14 17:06): "for storage we should store
#    the file as a binary"; 17:08 "the binary as a number".
# ============================================================================
from __future__ import annotations

import random

import numpy as np

from warp2.equation_book import bits, digits, keep, packed


def _random_bytes(seed, n):
    """Intention: n random bytes, the same every run."""
    return random.Random(seed).randbytes(n)


def test_files_come_back_the_same():
    for raw in (b"", b"\x00", b"\x07", b"\x00\x00\x00\x05abc", _random_bytes(1, 3000), bytes(5000)):
        assert keep.bytes_back(keep.keep_bytes(raw)) == raw


def test_a_file_as_one_number_comes_back_in_every_digit_width():
    raw = b"\x00\x00\x01" + _random_bytes(2, 501)
    for width in list(range(1, 65)):
        assert digits.bytes_of(digits.digits_of(raw, width), width, len(raw)) == raw, width


def test_lists_of_numbers_come_back_the_same():
    rng = np.random.default_rng(3)
    for values in (np.zeros(0, dtype=np.int64), np.array([7]), np.array([-(2**63), 2**63 - 1, 0, -1]),
                   rng.integers(-10**12, 10**12, 5000), np.arange(0, 6_000_000, 60) + 10**15):
        assert np.array_equal(keep.values_back(keep.keep_values(values)), np.asarray(values, dtype=np.int64))


def test_nothing_is_kept_bigger_than_the_file_and_its_heading():
    raw = _random_bytes(4, 20_000)
    kept = keep.keep_bytes(raw)
    assert len(kept) <= len(raw) + len(keep.MAGIC) + 1 + len(bits.put([len(raw)]))


def test_numbers_of_any_size_are_written_seven_bits_a_byte():
    numbers = [0, 1, 127, 128, 2**63, 2**64 - 1, 2**70 + 5]
    raw = bits.put(numbers)
    at, got = 0, []
    for _ in numbers:
        value, at = bits.take(memoryview(raw), at)
        got.append(value)
    assert got == numbers and at == len(raw)


def test_the_bits_each_number_needs_are_counted_exactly():
    rng = np.random.default_rng(5)
    u = np.concatenate([rng.integers(0, 2**63, 3000, dtype=np.uint64) * np.uint64(2) + np.uint64(1),
                        np.array([0, 1, 2**53 - 1, 2**53, 2**53 + 1, 2**63, 2**64 - 1], dtype=np.uint64)])
    assert bits.widths(u).tolist() == [int(x).bit_length() for x in u.tolist()]


def test_a_packed_list_reads_back_and_is_priced_exactly():
    rng = np.random.default_rng(6)
    for values in (np.zeros(0, dtype=np.int64), np.array([-3]), rng.integers(-500, 500, 7777),
                   np.array([-(2**63), 2**63 - 1]), rng.integers(0, 3, 4096)):
        raw = packed.pack(values)
        back, end = packed.unpack(raw)
        assert np.array_equal(back, values) and end == len(raw) == packed.size_of(values)
