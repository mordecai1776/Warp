# WARP2/warp2/makers/code_loop.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/code_loop.py
#  Used by   : warp2/work/side/make_code.py (one task worked a turn),
#              warp2/makers/practise_skill.py (a code skill practised again),
#              warp2/makers/tests/test_code_is_fetched_written_tested_and_rewritten.py.
#  Uses      : warp2/makers/{sandbox,retrain,skills,code_tasks}.py.
#  Description:
#    WRITE, TEST, FIX. A model is shown a task (what to write, the functions
#    and the names of their arguments, and one case of each function) and
#    writes it; the code runs against every case in the sandbox; the cases it
#    failed, and why, go back to the model with its code, and it fixes it.
#    That repeats while it still passes more cases each time - by at least one
#    case, the finest step the cases can show (retrain.UntilRight) - and stops
#    when every case passes or a round passes no more than the best before.
#    The best code is kept (state/code/solutions/<task>.json, with its share
#    passed and every round's share) and only replaced by code that passes
#    more; a task worked again starts from its best. Its share passed goes
#    into the skills table as "code: <task>" (a temperature, 0..1).
#  User intention (Andrew, 2026-11-08 20:44): "As far as code goes, it should
#    be looking for new types of code"; 2026-11-08 "if it does the task wrong
#    then it trains until it gets it right". (BUILD_LOG 1466.)
# ============================================================================
"""Write a task's code, run its tests, fix what failed, while it keeps passing more."""
from __future__ import annotations

import time

from warp2.makers.code_tasks import Shelf
from warp2.makers.sandbox import Sandbox, code_of, runnable


def signatures(cases: list) -> dict:
    """Intention: {function: its argument names} as the cases call it."""
    out: dict = {}
    for call in runnable(cases):
        names = out.setdefault(call["function"], [])
        for key in call["input"]:
            if key not in names:
                names.append(key)
    return out


def _call(case: dict) -> str:
    """Intention: one case as a line of Python - the call and what it must give back."""
    args = ", ".join(f"{k}={v!r}" for k, v in case["input"].items())
    want = case["expected"]
    if isinstance(want, dict) and set(want) == {"error"}:
        return f"{case['function']}({args})  # must raise an exception: {want['error']}"
    return f"{case['function']}({args}) == {want!r}"


class CodeLoop:
    """One task written, tested and fixed while it keeps passing more cases."""

    def __init__(self, state, ask, slug: str, sandbox: Sandbox | None = None) -> None:
        """Intention: the task (from the task shelf), how a model is asked, and where code is run."""
        self.state = state
        self.ask = ask
        self.slug = slug
        self.task = Shelf(state, "tasks").get(slug)
        self.solutions = Shelf(state, "solutions")
        self.sandbox = sandbox or Sandbox()
        self.calls = runnable(self.task.get("cases") or [])

    def first_prompt(self) -> str:
        """Intention: the task, the functions with their arguments, and one case of each."""
        shown, lines = set(), []
        for call in self.calls:
            if call["function"] not in shown:
                shown.add(call["function"])
                lines.append(_call(call))
        sigs = "\n".join(f"def {f}({', '.join(a)}): ..." for f, a in signatures(self.task["cases"]).items())
        return (f"Write Python for this task.\n\n{self.task.get('description', '')}\n\n"
                f"Write these functions; they are called with these argument names:\n{sigs}\n\n"
                "For example, these must hold:\n" + "\n".join(lines)
                + "\n\nUse only the Python standard library. Answer with the code only, in one ```python block.")

    def fix_prompt(self, code: str, tested: dict) -> str:
        """Intention: the code, and the cases it failed with why, one per function at most."""
        failed, shown = [], set()
        for result, call in zip(tested["results"], self.calls):
            if not result["passed"] and call["function"] not in shown:
                shown.add(call["function"])
                failed.append(f"{_call(call)}\n    but it {result['why']}")
        why = "\n".join(failed) or tested.get("why", "it did not run")
        return (f"{self.first_prompt()}\n\nThis code was written:\n```python\n{code}```\n"
                f"It passed {tested['passed']} of {tested['of']} cases. These failed:\n{why}\n\n"
                "Fix it. Answer with the whole fixed code only, in one ```python block.")

    def run(self) -> dict:
        """Intention: write (or start from the best kept), test, fix while it passes more; the best kept and noted."""
        if not self.calls:
            return {"task": self.slug, "did": "nothing", "why": "the task has no cases that can be run as calls"}
        from warp2.makers.retrain import UntilRight
        kept = self.solutions.get(self.slug)
        now = {"code": kept.get("code", ""), "tested": None}
        best = {"code": kept.get("code", ""), "share": float(kept.get("share") or 0.0), "tested": None}

        def teach() -> None:
            """Intention: the model writes the code, or fixes the last code from what failed."""
            prompt = self.fix_prompt(now["code"], now["tested"]) if now["code"] and now["tested"] \
                else self.first_prompt()
            now["code"] = code_of(self.ask(prompt))

        def check() -> float:
            """Intention: the share of cases the code passes now; the best code remembered."""
            now["tested"] = self.sandbox.run(now["code"], self.task["cases"]) if now["code"].strip() else \
                {"passed": 0, "of": len(self.calls), "share": 0.0, "results": [], "why": "no code yet"}
            if best["tested"] is None or now["tested"]["share"] > best["share"]:
                best.update(code=now["code"], share=now["tested"]["share"], tested=now["tested"])
            return now["tested"]["share"]

        if not now["code"]:
            teach()
        got = UntilRight(teach, check, len(self.calls)).run()
        tested = best["tested"] or now["tested"]
        if best["code"] and (best["share"] > float(kept.get("share") or -1.0) or not kept):
            self.solutions.put(self.slug, {"code": best["code"], "share": best["share"],
                                           "passed": tested["passed"] if tested else 0, "of": len(self.calls),
                                           "checks": [round(c, 4) for c in got["checks"]], "at": time.time()})
        from warp2.makers.skills import note_skill
        note_skill(self.state, f"code: {self.slug}", "code", best["share"],
                   f"{got['rounds']} rounds, {got['why']}")
        return {"task": self.slug, "did": "practised", "right": round(best["share"], 4), "of": len(self.calls),
                "checks": [round(c, 4) for c in got["checks"]], "why": got["why"]}
