# WARP2/warp2/makers/code_tasks.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/code_tasks.py
#  Used by   : warp2/work/side/make_code.py (one task and one example looked
#              for a turn), warp2/makers/{code_loop,code_ways,code_choice}.py,
#              warp2/makers/tests/test_code_is_fetched_written_tested_and_rewritten.py.
#  Uses      : projects/game_builder/fetch_copy.py (Asker - the one place
#              that talks to the network, so a test hands in its own),
#              warp2/record/kept_file.py; stdlib json, re, time, urllib.parse.
#  Description:
#    CODING TASKS, AND EXAMPLES OF CODE, FOUND AND KEPT WITH THEIR LICENCE.
#      tasks    - Exercism's problem-specifications (MIT licence): each
#                 exercise's description and its canonical test cases. One
#                 new exercise is taken a turn, the next one not yet kept, and
#                 kept as state/code/tasks/<slug>.json: what to write, the
#                 cases it must pass (a newer case that re-implements an older
#                 one replaces it), and where it came from - repository,
#                 licence, author, address.
#      examples - Rosetta Code (GNU Free Documentation Licence 1.3): one
#                 programming task's page a turn, its Python solutions taken
#                 out and kept as state/code/examples/<slug>.json - many ways
#                 of writing one thing, for the warp to read and learn ways
#                 from (code_ways.py).
#    The list of what can be taken is read once and kept
#    (state/code/listing_<source>.json); it is read again when everything on
#    it has been taken. A look that fails is said and kept, and the next turn
#    looks again.
#  User intention (Andrew, 2026-11-08 20:44): "As far as code goes, it should
#    be looking for new types of code ... It should also be looking for
#    examples as well, the same as games." Standing: the fetcher records
#    source, licence and author. (BUILD_LOG 1466.)
# ============================================================================
"""Coding tasks with tests (Exercism) and examples of code (Rosetta Code), kept with their licence."""
from __future__ import annotations

import json
import re
import time
import urllib.parse
from pathlib import Path

from warp2.record.kept_file import read_kept, write_kept

# Intention: where Exercism's problem specifications are, and the licence the repository is under.
EXERCISM = {"repo": "exercism/problem-specifications", "licence": "MIT", "author": "Exercism contributors",
            "list": "https://api.github.com/repos/exercism/problem-specifications/contents/exercises",
            "raw": "https://raw.githubusercontent.com/exercism/problem-specifications/main/exercises/{slug}/{file}",
            "page": "https://github.com/exercism/problem-specifications/tree/main/exercises/{slug}"}

# Intention: where Rosetta Code's tasks are listed and read, and the licence its pages are under.
ROSETTA = {"licence": "GFDL-1.3", "author": "Rosetta Code contributors",
           "list": "https://rosettacode.org/w/api.php?action=query&list=categorymembers"
                   "&cmtitle=Category:Programming_Tasks&cmlimit=500&format=json",
           "raw": "https://rosettacode.org/w/index.php?title={title}&action=raw",
           "page": "https://rosettacode.org/wiki/{title}"}


def slug_of(name: str) -> str:
    """Intention: a task's name as a file name."""
    return re.sub(r"[^a-z0-9]+", "_", str(name).lower()).strip("_") or "task"


def leaf_cases(data: dict) -> list:
    """Intention: every test case in a canonical-data file, groups opened; a case that re-implements another replaces it."""
    out, dropped = [], set()

    def walk(node: dict) -> None:
        """Intention: a group's cases, and the groups inside it, in order."""
        for case in node.get("cases") or []:
            if "cases" in case:
                walk(case)
            elif "property" in case:
                if case.get("reimplements"):
                    dropped.add(case["reimplements"])
                out.append(case)
    walk(data)
    return [c for c in out if c.get("uuid") not in dropped]


class Shelf:
    """state/code/<kind>/<slug>.json: what was taken, one file each."""

    def __init__(self, state, kind: str) -> None:
        """Intention: tasks and examples each on their own shelf."""
        self.home = Path(state) / "code" / kind

    def get(self, slug: str) -> dict:
        """Intention: one kept thing; {} when it is not kept."""
        return read_kept(self.home / f"{slug}.json", {})

    def put(self, slug: str, kept: dict) -> dict:
        """Intention: one thing written whole."""
        write_kept(self.home / f"{slug}.json", kept, indent=1)
        return kept

    def slugs(self) -> list:
        """Intention: every slug kept, in name order."""
        return sorted(p.stem for p in self.home.glob("*.json")) if self.home.is_dir() else []

    def all(self) -> dict:
        """Intention: {slug: kept} for everything on the shelf."""
        return {s: self.get(s) for s in self.slugs()}


class Listing:
    """What one source offers, read once and kept, read again when all of it is taken."""

    def __init__(self, state, source: str) -> None:
        """Intention: the kept list for one source."""
        self.path = Path(state) / "code" / f"listing_{source}.json"

    def names(self, read) -> list:
        """Intention: the kept list, or a fresh one from `read()` when none is kept."""
        kept = read_kept(self.path, {})
        if kept.get("names"):
            return list(kept["names"])
        names = list(read())
        write_kept(self.path, {"names": names, "at": time.time()}, indent=1)
        return names

    def forget(self) -> None:
        """Intention: the next look reads the list again."""
        write_kept(self.path, {"names": [], "at": time.time()}, indent=1)


class ExercismTasks:
    """One new Exercism exercise a turn, with its description and its test cases."""

    def __init__(self, state, asker) -> None:
        """Intention: the task shelf, and how the network is asked."""
        self.shelf = Shelf(state, "tasks")
        self.listing = Listing(state, "exercism")
        self.asker = asker

    def _names(self) -> list:
        """Intention: every exercise folder in the repository."""
        return sorted(e["name"] for e in self.asker.json(EXERCISM["list"]) if e.get("type") == "dir")

    def one(self) -> dict:
        """Intention: the next exercise not yet taken, kept with its cases and licence; what happened, said plainly."""
        tried = read_kept(self.shelf.home.parent / "tasks_without_cases.json", {"names": []})
        names = self.listing.names(self._names)
        waiting = [n for n in names if slug_of(n) not in self.shelf.slugs() and n not in tried["names"]]
        if not waiting:
            self.listing.forget()
            return {"took": "", "said": "every exercise listed is taken; the list is read again next time"}
        name = waiting[0]
        try:
            data = json.loads(self.asker.text(EXERCISM["raw"].format(slug=name, file="canonical-data.json")))
        except OSError as exc:
            # Intention: an exercise with no test file (one retired) is passed by for good, not asked for every turn;
            # a network that is down is said, and the same exercise is asked for next time.
            if "404" not in str(exc):
                raise
            data = {}
        cases = leaf_cases(data)
        if not any(isinstance(c.get("input"), dict) and "expected" in c for c in cases):
            tried["names"].append(name)
            write_kept(self.shelf.home.parent / "tasks_without_cases.json", tried, indent=1)
            return {"took": "", "said": f"{name} has no cases that can be run as calls"}
        description = self.asker.text(EXERCISM["raw"].format(slug=name, file="description.md"))
        self.shelf.put(slug_of(name), {
            "name": name, "description": description.strip(), "cases": cases, "source": "exercism",
            "repo": EXERCISM["repo"], "licence": EXERCISM["licence"], "author": EXERCISM["author"],
            "url": EXERCISM["page"].format(slug=name), "fetched": time.time()})
        return {"took": name, "cases": len(cases), "licence": EXERCISM["licence"]}


def python_blocks(wikitext: str) -> list:
    """Intention: every Python solution on a Rosetta Code page - the code blocks under its ==Python== heading."""
    match = re.search(r"^==\s*\{\{header\|Python\}\}\s*==\s*$(.*?)(?=^==[^=]|\Z)", wikitext, flags=re.M | re.S)
    if not match:
        return []
    found = re.findall(r"<(?:syntaxhighlight|lang|source)[^>]*?(?:python|Python)[^>]*>(.*?)"
                       r"</(?:syntaxhighlight|lang|source)>", match.group(1), flags=re.S)
    return [block.strip() + "\n" for block in found if block.strip()]


class RosettaExamples:
    """One Rosetta Code task a turn, its Python solutions kept as examples of ways to write it."""

    def __init__(self, state, asker) -> None:
        """Intention: the examples shelf, and how the network is asked."""
        self.shelf = Shelf(state, "examples")
        self.listing = Listing(state, "rosetta")
        self.asker = asker

    def _names(self) -> list:
        """Intention: every programming task Rosetta Code lists."""
        said = self.asker.json(ROSETTA["list"])
        return sorted(m["title"] for m in (said.get("query") or {}).get("categorymembers") or [] if m.get("title"))

    def one(self) -> dict:
        """Intention: the next task not yet looked at, its Python solutions kept with the licence; what happened."""
        names = self.listing.names(self._names)
        waiting = [n for n in names if slug_of(n) not in self.shelf.slugs()]
        if not waiting:
            self.listing.forget()
            return {"took": "", "said": "every task listed is looked at; the list is read again next time"}
        title = waiting[0]
        quoted = urllib.parse.quote(title.replace(" ", "_"))
        blocks = python_blocks(self.asker.text(ROSETTA["raw"].format(title=quoted)))
        self.shelf.put(slug_of(title), {
            "name": title, "code": blocks, "source": "rosetta", "licence": ROSETTA["licence"],
            "author": ROSETTA["author"], "url": ROSETTA["page"].format(title=quoted), "fetched": time.time()})
        return {"took": title, "ways": len(blocks), "licence": ROSETTA["licence"]}


def fetch_one_of_each(state, asker=None) -> dict:
    """Intention: one task and one example looked for; each says what happened, and one failing does not stop the other."""
    if asker is None:
        from projects.game_builder.fetch_copy import Asker
        asker = Asker()
    out = {}
    for name, source in (("task", ExercismTasks(state, asker)), ("example", RosettaExamples(state, asker))):
        try:
            out[name] = source.one()
        except (OSError, ValueError, KeyError, TypeError) as exc:
            out[name] = {"took": "", "said": f"the look could not be read: {type(exc).__name__}: {exc}"}
    return out
