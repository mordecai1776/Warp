# WARP2/warp2/makers/code_ways.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/code_ways.py
#  Used by   : warp2/work/side/make_code.py (one new way tried a turn),
#              warp2/makers/tests/test_code_is_fetched_written_tested_and_rewritten.py.
#  Uses      : warp2/makers/{sandbox,code_tasks}.py; stdlib ast, time.
#  Description:
#    THE SAME TASK, WRITTEN OTHER WAYS. Code is read (by its syntax tree, not
#    by a model) for the ways it is written:
#      loop          - a for or while loop;
#      recursion     - a function that calls itself;
#      comprehension - a list, set or dict comprehension, or a generator;
#      functional    - map, filter, reduce, or a lambda;
#      class         - a class of its own.
#    A task solved in full has its ways filled from its solution. Each turn,
#    one task with a way not yet filled gets that way: the model is shown the
#    passing code, and, when one of the examples (Rosetta Code, code_tasks.py)
#    is written that way, that example too, and asked to write the task that
#    way. The new code is kept (state/code/ways/<task>.json) only when it
#    passes every case AND it is really written that way - read again by its
#    syntax tree - so the cells fill only with code that works.
#    The examples are read the same way, so what ways the seen code uses is
#    counted too (`seen_ways`).
#  User intention (Andrew, 2026-11-08 20:44): "It should look at the codes it
#    has seen and try to figure out different ways to write different types
#    of codes." (BUILD_LOG 1466; research: MAP-Elites style cells kept only
#    when they work.)
# ============================================================================
"""The ways code is written, read by its syntax tree, and a task written a way it has not been yet."""
from __future__ import annotations

import ast
import time

from warp2.makers.code_tasks import Shelf
from warp2.makers.sandbox import Sandbox, code_of

# Intention: the ways a piece of code can be written, in the order they are tried.
WAYS = ("loop", "recursion", "comprehension", "functional", "class")

# Intention: what each way means, as the model is told it.
SAID = {"loop": "with a for or while loop", "recursion": "with a function that calls itself (recursion)",
        "comprehension": "with list, set or dict comprehensions or generator expressions",
        "functional": "in a functional style, with map, filter, functools.reduce or lambda",
        "class": "with a class that holds the work, called from the functions"}


def ways_of(code: str) -> set:
    """Intention: the ways this code is written, read from its syntax tree; none when it does not parse."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return set()
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.For, ast.While, ast.AsyncFor)):
            found.add("loop")
        elif isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            found.add("comprehension")
        elif isinstance(node, ast.Lambda):
            found.add("functional")
        elif isinstance(node, ast.ClassDef):
            found.add("class")
        elif isinstance(node, ast.Call):
            name = node.func.attr if isinstance(node.func, ast.Attribute) else getattr(node.func, "id", "")
            if name in ("map", "filter", "reduce"):
                found.add("functional")
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for inner in ast.walk(node):
                if isinstance(inner, ast.Call) and getattr(inner.func, "id", "") == node.name:
                    found.add("recursion")
    return found


def seen_ways(state) -> dict:
    """Intention: {way: how many example solutions are written that way} over every example kept."""
    counts = {w: 0 for w in WAYS}
    for kept in Shelf(state, "examples").all().values():
        for block in kept.get("code") or []:
            for way in ways_of(block):
                counts[way] += 1
    return counts


def example_of(state, way: str) -> dict:
    """Intention: one example written that way - the shortest, so it fits beside the task; {} when there is none."""
    best = {}
    for kept in Shelf(state, "examples").all().values():
        for block in kept.get("code") or []:
            if way in ways_of(block) and (not best or len(block) < len(best["code"])):
                best = {"task": kept.get("name", ""), "code": block, "url": kept.get("url", "")}
    return best


class Ways:
    """state/code/ways/<task>.json: {way: code that passes every case and is written that way}."""

    def __init__(self, state) -> None:
        """Intention: the ways live beside the solutions."""
        self.state = state
        self.shelf = Shelf(state, "ways")

    def filled(self, slug: str) -> dict:
        """Intention: the ways a task is written so far - its full solution's ways first, then those added."""
        kept = dict(self.shelf.get(slug))
        solution = Shelf(self.state, "solutions").get(slug)
        if solution.get("code") and float(solution.get("share") or 0.0) >= 1.0:
            for way in ways_of(solution["code"]):
                kept.setdefault(way, {"code": solution["code"], "from": "its solution"})
        return kept

    def next(self) -> tuple:
        """(task, way): among tasks solved in full, the empty way tried fewest times, on the task with fewest ways; ("", "").

        Intention: a way the model could not write is not asked for every turn - every other empty way comes first.
        """
        tried = Shelf(self.state, "ways_tried")
        best = None
        for slug, solution in Shelf(self.state, "solutions").all().items():
            if float(solution.get("share") or 0.0) < 1.0:
                continue
            filled = self.filled(slug)
            misses = tried.get(slug)
            for way in WAYS:
                if way not in filled:
                    rank = (int(misses.get(way) or 0), len(filled), slug, WAYS.index(way))
                    if best is None or rank < best[0]:
                        best = (rank, slug, way)
        return (best[1], best[2]) if best else ("", "")

    def try_one(self, ask, sandbox: Sandbox | None = None) -> dict:
        """Intention: one task written one new way; kept only when it passes every case and is written that way."""
        slug, way = self.next()
        if not slug:
            return {"way": "", "said": "no task solved in full has a way left to try"}
        task = Shelf(self.state, "tasks").get(slug)
        solution = Shelf(self.state, "solutions").get(slug)
        seen = example_of(self.state, way)
        shown = (f"\n\nHere is other code written that way ({seen['task']}, from Rosetta Code):\n"
                 f"```python\n{seen['code']}```") if seen else ""
        said = ask(f"This code passes every test of the task below:\n```python\n{solution['code']}```\n\n"
                   f"Task: {task.get('description', '')}{shown}\n\nWrite the same functions again, with the same "
                   f"names and arguments, {SAID[way]}. Answer with the code only, in one ```python block.")
        code = code_of(said)
        tested = (sandbox or Sandbox()).run(code, task.get("cases") or [])
        really = way in ways_of(code)
        if tested["share"] >= 1.0 and really:
            kept = dict(self.shelf.get(slug))
            kept[way] = {"code": code, "at": time.time(), "example": seen.get("url", "")}
            self.shelf.put(slug, kept)
            return {"task": slug, "way": way, "kept": True, "ways": sorted(self.filled(slug))}
        tried = Shelf(self.state, "ways_tried")
        misses = dict(tried.get(slug))
        misses[way] = int(misses.get(way) or 0) + 1
        tried.put(slug, misses)
        why = "it is not written that way" if tested["share"] >= 1.0 else f"it passed {tested['passed']} of {tested['of']}"
        return {"task": slug, "way": way, "kept": False, "why": why}
