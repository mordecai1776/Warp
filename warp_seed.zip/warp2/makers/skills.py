# WARP2/warp2/makers/skills.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/skills.py
#  Used by   : warp2/make/training_needs.py (each skill is a need, ranked with
#              the rest), warp2/make/practice.py (practice goes to the top
#              one), warp2/work/side/{games,make_code,pairs}.py and
#              warp2/make/eye_lessons.py (they write their scores here),
#              warp2/makers/tests/test_skills_and_practice.py.
#  Uses      : stdlib json, math, time, pathlib.
#  Description:
#    ONE SKILLS TABLE. Every part that is trained writes how it did as a
#    graded score from 0 to 1 (a temperature, never pass/fail): the Eye's
#    block domains, its judgement part at each level, each game, each coding
#    task. One line a score, in state/practice/skills.jsonl, never rewritten.
#    WHERE PRACTICE GOES (research: Matiisen 2017, MAGELLAN 2025, Prioritized
#    Level Replay - design/research/GAMES_CODE_PRACTICE_SURVEY_2026-11-08.md):
#    to a skill with room left that is still moving, and to one not tried for
#    a while. For each skill:
#      level    - the mean of its newer half of scores (its one score when it
#                 has one);
#      progress - how far the newer half moved from the older half, against
#                 how sure that move is (its own standard error): move /
#                 (move + error), 0..1, so a move inside the noise counts for
#                 little and no number is set by hand;
#      stale    - the time since it was last tried, against the table's own
#                 usual gap between tries: since / (since + usual gap), 0..1;
#      need     - room left (1 - level) times the larger of progress and
#                 stale. A skill mastered has no need; one stuck where it is
#                 waits until it is stale, then gets a turn to show it moved.
#  User intention (Andrew, 2026-11-08 20:44): practice "would be general
#    practice"; 20:41 "What can we do about the rest of the training that is
#    lacking"; standing: "temperatures, not solid bars", "most of what it does
#    should be training until it becomes more competent" (BUILD_LOG 1466).
# ============================================================================
"""Every trained part's graded score in one table, and where practice should go next."""
from __future__ import annotations

import json
import math
import time
from pathlib import Path


class SkillBook:
    """state/practice/skills.jsonl: one line per score, appended, never rewritten."""

    def __init__(self, state) -> None:
        """Intention: the table lives with the warp's state, beside the rest of practice."""
        self.path = Path(state) / "practice" / "skills.jsonl"

    def add(self, skill: str, kind: str, score: float, why: str = "", at: float | None = None) -> dict:
        """Intention: one graded score written, kept to 0..1; the row handed back."""
        row = {"skill": str(skill), "kind": str(kind), "score": max(0.0, min(1.0, float(score))),
               "at": time.time() if at is None else float(at), "why": str(why)}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as out:
            out.write(json.dumps(row) + "\n")
        return row

    def rows(self) -> list:
        """Intention: every score, oldest first; a torn last line (a write cut off) is passed over and said once."""
        if not self.path.is_file():
            return []
        out = []
        with self.path.open(encoding="utf-8") as lines:
            for line in lines:
                if not line.strip():
                    continue
                try:
                    out.append(json.loads(line))
                except ValueError as exc:
                    from warp2.record.swallowed import noted
                    noted("warp2/makers/skills.py:SkillBook.rows", exc)
        return out

    def by_skill(self) -> dict:
        """Intention: {skill: [rows, oldest first]}."""
        out: dict = {}
        for row in self.rows():
            out.setdefault(row["skill"], []).append(row)
        return out


def _mean(values: list) -> float:
    """Intention: the plain mean of a non-empty list."""
    return sum(values) / len(values)


def _spread(values: list) -> float:
    """Intention: the sample variance; 0 for fewer than two."""
    if len(values) < 2:
        return 0.0
    m = _mean(values)
    return sum((v - m) ** 2 for v in values) / (len(values) - 1)


class Standing:
    """Where one skill stands: its level, how it moves, how long since it was tried, and its need."""

    @staticmethod
    def progress(scores: list):
        """How surely the newer half of the scores moved from the older half, 0..1; None with fewer than two.

        Intention: the move against its own standard error - a move inside the noise counts for little, a clear one
        for nearly all; both halves are the skill's own scores, so nothing is set by hand.
        """
        if len(scores) < 2:
            return None
        half = len(scores) // 2
        older, newer = scores[:half], scores[half:]
        move = abs(_mean(newer) - _mean(older))
        error = math.sqrt(_spread(older) / len(older) + _spread(newer) / len(newer))
        if move + error <= 0.0:
            return 0.0
        return move / (move + error)

    @staticmethod
    def level(scores: list) -> float:
        """Intention: where the skill is now - the mean of its newer half (its one score when it has one)."""
        return _mean(scores[len(scores) // 2:])

    @staticmethod
    def stale(last_at: float, now: float, usual_gap: float) -> float:
        """Intention: since / (since + the table's usual gap between tries), 0..1; with no usual gap known, the most."""
        since = max(0.0, now - last_at)
        if usual_gap <= 0.0:
            return 1.0
        return since / (since + usual_gap)

    @staticmethod
    def of(rows: list, now: float, usual_gap: float) -> dict:
        """Intention: one skill's standing from its rows, oldest first."""
        scores = [float(r["score"]) for r in rows]
        level = Standing.level(scores)
        moving = Standing.progress(scores)
        stale = Standing.stale(float(rows[-1]["at"]), now, usual_gap)
        drive = max(moving if moving is not None else 0.0, stale)
        return {"skill": rows[-1]["skill"], "kind": rows[-1]["kind"], "level": round(level, 4),
                "progress": None if moving is None else round(moving, 4), "stale": round(stale, 4),
                "tries": len(scores), "need": round((1.0 - level) * drive, 4), "last": rows[-1].get("why", "")}


def usual_gap(by_skill: dict) -> float:
    """Intention: the mean time between two tries of the same skill, over the whole table; 0 when none was tried twice."""
    gaps = []
    for rows in by_skill.values():
        times = [float(r["at"]) for r in rows]
        gaps += [b - a for a, b in zip(times, times[1:])]
    return _mean(gaps) if gaps else 0.0


def ranked(state, now: float | None = None) -> list:
    """Intention: every skill's standing, the biggest need first."""
    book = SkillBook(state).by_skill()
    when = time.time() if now is None else float(now)
    gap = usual_gap(book)
    rows = [Standing.of(rows, when, gap) for rows in book.values() if rows]
    return sorted(rows, key=lambda r: (-r["need"], r["skill"]))


def note_skill(state, skill: str, kind: str, score, why: str = "") -> dict | None:
    """Intention: one score into the table from any part; nothing written when there is no score to write."""
    if isinstance(score, bool) or not isinstance(score, (int, float)) or score != score:
        return None
    return SkillBook(state).add(skill, kind, float(score), why)
