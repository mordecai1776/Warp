# WARP2/warp2/makers/practise_skill.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/practise_skill.py
#  Used by   : warp2/make/practice.py (turn: a skill from the skills table is
#              the biggest need), warp2/makers/tests/test_skills_and_practice.py.
#  Uses      : warp2/makers/{skills,asker,code_loop}.py,
#              projects/game_builder/{cards,commission,game_spec}.py,
#              projects/game_player/coded_arena.py (as a child process),
#              warp2/work/side/game_work.py (Measures), warp2/record/children.py.
#  Description:
#    GENERAL PRACTICE ON A SKILL FROM THE SKILLS TABLE, by its kind:
#      play  - a coded game the player does worst at is played again, in its
#              own process, for one turn's time; how it went is noted;
#      game  - a made game that measures low is put back into the build work
#              with what was measured and which parts were weakest, so the
#              builder makes it better; only once each time the game's file
#              changes, so the builder has its turn before it is asked again;
#      code  - a coding task not yet passed in full is worked again from its
#              best code (code_loop.py).
#    The Eye's judgement part is practised in a child process instead
#    (warp2/makers/judge_replay.py, from warp2/work/side/practice.py); the
#    Eye's block domains are practised by their own step (train_pairs).
#  User intention (Andrew, 2026-11-08 20:44): "As far as practice, it was
#    meant to practice on, well, I guess it would be general practice."
#    (BUILD_LOG 1466.)
# ============================================================================
"""Practice on one skill from the skills table, by its kind."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

# Intention: the kinds practised here, in the runner, and the kinds practised elsewhere.
HERE = ("play", "game", "code")
IN_CHILD = ("judge",)


def _name(skill: str) -> str:
    """Intention: what a skill is about, without its kind - "code: two_fer" -> "two_fer"."""
    return str(skill).split(":", 1)[-1].strip()


def play(root, state, slug: str, stop=None) -> dict:
    """Intention: the game played again for one turn's time, in its own process; how it went noted."""
    from projects.game_player.coded_arena import ANSWER
    from warp2.makers.skills import note_skill
    from warp2.record.children import FINISHED, run_watched
    from warp2.work.side.games import TURN_SECONDS
    command = [sys.executable, "-m", "projects.game_player.coded_arena", "--root", str(root), "--state", str(state),
               "--seconds", str(int(TURN_SECONDS)), "--game", slug]
    done = run_watched(command, seconds=float(TURN_SECONDS) * 3 + 60, stop=stop, cwd=str(root))
    if done["how"] != FINISHED or done["code"] != 0:
        return {"did": "nothing", "why": f"the game ended {done['how']}"}
    said = {}
    for line in reversed(str(done["said"]).splitlines()):
        if line.startswith(ANSWER):
            said = json.loads(line[len(ANSWER):])
            break
    if said.get("status") != "played":
        return {"did": "nothing", "why": str(said.get("status") or "the game gave no answer")}
    episodes = max(1, int(said.get("episodes", 1)))
    note_skill(state, f"play: {slug}", "play", said["won"] / episodes, f"practised: won {said['won']} of {episodes}")
    return {"did": "practised", "who": "the player", "game": slug, "won": said["won"], "of": episodes}


def game(root, state, projects, slug: str) -> dict:
    """Intention: a game that measures low put back into the build work with its measure, once per change of its file."""
    from projects.game_builder.cards import CardShelf
    from projects.game_builder.commission import PROJECT, artifact_of, intention_of
    from projects.game_builder.game_spec import SpecShelf, spec_text
    from warp2.work.side.game_work import Measures
    if projects is None:
        return {"did": "nothing", "why": "no project board to put the work on"}
    measures = Measures(state)
    measured = measures.get(slug)
    card = next((c for c in CardShelf(state).all() if c.slug == slug), None)
    if card is None or not measured.get("parts"):
        return {"did": "nothing", "why": f"{slug} has no card or no measure"}
    if float(measured.get("asked_better_at") or 0.0) >= float(measured.get("file_time") or 0.0) > 0.0:
        return {"did": "nothing", "why": f"{slug} is waiting for the builder since it was asked to be better"}
    parts = {k: v for k, v in measured["parts"].items() if isinstance(v, (int, float))}
    weakest = sorted(parts, key=lambda k: parts[k])[:max(1, len(parts) // 2)]
    lines = [intention_of(card, spec_text(SpecShelf(state).get(slug))), "",
             f"The game as made was measured by playing it: measure {measured.get('measure')}; "
             + ", ".join(f"{k} {v}" for k, v in parts.items()) + ".",
             "Make it better where it measured weakest: " + ", ".join(weakest) + ". Keep everything that works."]
    if measured.get("errors"):
        lines.append("Errors seen while it was played: " + "; ".join(measured["errors"][:3]))
    projects.add_area(PROJECT, f"game {card.name}", "\n".join(lines), artifact=artifact_of(card))
    measures.put(slug, dict(measured, asked_better_at=time.time()))
    return {"did": "practised", "who": "the game builder", "game": slug, "weakest": weakest}


def code(state, ask, slug: str, stop=None) -> dict:
    """Intention: a coding task worked again from its best code."""
    from warp2.makers.code_loop import CodeLoop
    from warp2.makers.sandbox import Sandbox
    if ask is None:
        return {"did": "nothing", "why": "no model takes build work"}
    got = CodeLoop(state, ask, slug, Sandbox(stop=stop)).run()
    return dict(got, who="the models", task=slug)


def practise(row: dict, root, state, loop) -> dict:
    """Intention: one skill practised by its kind; what happened, said plainly."""
    from warp2.makers.asker import model_asker
    kind, slug = row["skill_kind"], _name(row["skill"])
    stop = getattr(getattr(loop, "pathway", None), "stop", None)
    if kind == "play":
        return play(root or Path(state).parent, state, slug, stop)
    if kind == "game":
        return game(root or Path(state).parent, state, getattr(loop, "projects", None), slug)
    if kind == "code":
        return code(state, model_asker(loop, "build"), slug, stop)
    return {"did": "nothing", "why": f"a {kind} skill is practised elsewhere"}
