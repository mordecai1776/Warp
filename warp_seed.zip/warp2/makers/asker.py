# WARP2/warp2/makers/asker.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/asker.py
#  Used by   : warp2/work/side/{games,game_work,make_code}.py,
#              warp2/makers/practise_skill.py, the tests beside them.
#  Uses      : the loop's fleet (warp2/models/fleet.py: names, choose, ask).
#  Description:
#    HOW A MAKER ASKS A MODEL. `ask(prompt) -> text`, one model the fleet
#    chooses for that kind of work each time it is asked ("build" for writing
#    code and reading games, as models.json names the kinds). No fleet, or no
#    model willing to take that kind of work, is None - the maker then does
#    what it can without a model and says so.
#  User intention (Andrew, 2026-11-08 23:40): "Build the whole system."
#    (BUILD_LOG 1466.)
# ============================================================================
"""One way for every maker to ask the fleet's chosen model."""
from __future__ import annotations


def model_asker(loop, kind: str):
    """Intention: `ask(prompt) -> text` from the loop's fleet for this kind of work; None when no model takes it."""
    fleet = getattr(loop, "fleet", None)
    if fleet is None or not fleet.names(kind):
        return None

    def ask(prompt: str) -> str:
        """Intention: the model the fleet chooses for this kind of work, asked once; "" when none is chosen."""
        name = fleet.choose(kind)
        return str(fleet.ask(name, prompt) or "") if name else ""
    return ask
