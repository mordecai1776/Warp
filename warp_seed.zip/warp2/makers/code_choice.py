# WARP2/warp2/makers/code_choice.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/code_choice.py
#  Used by   : warp2/work/side/make_code.py (which task is worked this turn),
#              warp2/makers/tests/test_code_is_fetched_written_tested_and_rewritten.py.
#  Uses      : warp2/makers/{code_tasks,skills}.py; stdlib re.
#  Description:
#    WHICH CODING TASK NEXT: what is new, and what is still being learned
#    (research: OMNI / learning progress - design/research/
#    GAMES_CODE_PRACTICE_SURVEY_2026-11-08.md). For each task kept:
#      novelty - 1 - its largest overlap of description words with any task
#                already tried (Jaccard), so a new kind of task counts more
#                than one like those done;
#      worth   - a task never tried is worth trying (1); one tried is worth
#                its need in the skills table (room left times how it moves or
#                how long since it was tried, skills.py);
#      score   - worth times novelty; the highest is worked. A task solved in
#                full has no need, so it is not worked again for itself.
#  User intention (Andrew, 2026-11-08 20:44): "it should be looking for new
#    types of code." (BUILD_LOG 1466.)
# ============================================================================
"""The coding task to work next: new, and still being learned."""
from __future__ import annotations

import re

from warp2.makers.code_tasks import Shelf


def words(text: str) -> set:
    """Intention: what a task is about, as a set of its words."""
    return set(re.findall(r"[a-z]{4,}", str(text).lower()))


def novelty(mine: set, others: list) -> float:
    """Intention: 1 - the largest share of words shared with any other; 1 when there is no other."""
    best = 0.0
    for theirs in others:
        both = mine | theirs
        if both and theirs is not mine:
            best = max(best, len(mine & theirs) / len(both))
    return 1.0 - best


def ranked(state, now: float | None = None) -> list:
    """Intention: every task with its novelty, worth and score, the highest score first."""
    from warp2.makers.skills import ranked as skills_ranked
    needs = {row["skill"]: row["need"] for row in skills_ranked(state, now)}
    tasks = Shelf(state, "tasks").all()
    told = {slug: words(t.get("description", "") + " " + t.get("name", "")) for slug, t in tasks.items()}
    tried = [w for slug, w in told.items() if f"code: {slug}" in needs]
    rows = []
    for slug in tasks:
        others = [w for w in tried if w is not told[slug]]
        new = novelty(told[slug], others)
        worth = needs.get(f"code: {slug}", 1.0)
        rows.append({"task": slug, "novelty": round(new, 4), "worth": round(float(worth), 4),
                     "score": round(new * float(worth), 4)})
    return sorted(rows, key=lambda r: (-r["score"], r["task"]))


def next_task(state, now: float | None = None) -> str:
    """Intention: the task to work this turn; "" when no task is worth working."""
    rows = ranked(state, now)
    return rows[0]["task"] if rows and rows[0]["score"] > 0.0 else ""
