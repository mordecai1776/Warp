# WARP2/warp2/makers/sandbox.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/sandbox.py
#  Used by   : warp2/makers/{code_loop,code_ways}.py,
#              warp2/makers/tests/test_code_is_fetched_written_tested_and_rewritten.py.
#  Uses      : warp2/record/{children,kept_file}.py (run_watched, write_kept); stdlib json, re, sys,
#              tempfile, pathlib.
#  Description:
#    CODE A MODEL WROTE, RUN ON ITS OWN. The code and its test cases go into a
#    fresh folder of their own, and a separate Python runs them there:
#      - isolated (`python -I`): no user site, no environment paths, and the
#        current folder is not put first, so nothing of the warp is imported;
#      - no network: before the code is loaded, every socket and connection
#        call is made to fail, so the code cannot reach out;
#      - a deadline, from a setting: a loop that never ends is ended, and the
#        stop ends it too;
#      - each case on its own: one case that raises does not hide the others.
#    A case is a function call: `property` names the function (written the
#    Python way, snake_case), `input` its arguments by name, and `expected`
#    what it must give back - or {"error": ...}, which means it must raise.
#    What comes back is every case's pass or fail and why, and the share
#    passed - a graded score, never only pass/fail.
#  User intention (Andrew, 2026-11-08 20:44): "As far as code goes, it should
#    be looking for new types of code." Standing: generated code runs in a
#    separate process with a time limit and no network. (BUILD_LOG 1466.)
# ============================================================================
"""A model's code and its test cases, run in a separate isolated Python with a deadline and no network."""
from __future__ import annotations

import json
import re
import sys
import tempfile
from pathlib import Path

from warp2.record.kept_file import write_kept
from warp2.settings import number

# Intention: how long one run of a solution's tests may take. A setting: it is Andrew's to say how much of the
# machine a test may take; a run that needs longer is a solution that loops.
TEST_SECONDS = number("WARP2_CODE_TEST_SECONDS", 20, minimum=1)

# Intention: the one line the runner answers on, so anything the code prints cannot be taken for the answer.
ANSWER = "WARP2_TESTED="

# Intention: the runner, written beside the code. It shuts the network, loads the code, and runs each case.
RUNNER = r'''
import json, socket, sys
def _no_network(*a, **k):
    raise OSError("no network in the sandbox")
socket.socket = _no_network
socket.create_connection = _no_network
socket.getaddrinfo = _no_network
cases = json.load(open("cases.json", encoding="utf-8"))
out = []
try:
    space = {"__name__": "solution"}
    exec(compile(open("solution.py", encoding="utf-8").read(), "solution.py", "exec"), space)
except BaseException as exc:
    print("%s%s" % (ANSWER, json.dumps({"loaded": False, "why": "%s: %s" % (type(exc).__name__, exc)})))
    sys.exit(0)
def same(a, b):
    return json.loads(json.dumps(a, default=str)) == json.loads(json.dumps(b, default=str))
for case in cases:
    name = case["function"]
    want = case["expected"]
    raises = isinstance(want, dict) and set(want) == {"error"}
    try:
        got = space[name](**case["input"])
    except BaseException as exc:
        out.append({"passed": raises, "why": "" if raises else "raised %s: %s" % (type(exc).__name__, exc)})
        continue
    if raises:
        out.append({"passed": False, "why": "gave %r where it should raise" % (got,)})
    else:
        ok = same(got, want)
        out.append({"passed": ok, "why": "" if ok else "gave %r, wanted %r" % (got, want)})
print("%s%s" % (ANSWER, json.dumps({"loaded": True, "cases": out})))
'''


def last_line(said) -> str:
    """Intention: the last thing a run said - its last line that is not blank; "" when it said nothing."""
    lines = [line for line in str(said or "").splitlines() if line.strip()]
    return lines[-1] if lines else ""


def snake(name: str) -> str:
    """Intention: a property as Python names it - "isPangram" -> "is_pangram"."""
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", str(name))
    return re.sub(r"[^A-Za-z0-9_]+", "_", spaced).strip("_").lower() or "solve"


def runnable(cases: list) -> list:
    """Intention: the cases as calls - function name, arguments by name, and what must come back."""
    out = []
    for case in cases:
        if isinstance(case.get("input"), dict) and "expected" in case and case.get("property"):
            out.append({"function": snake(case["property"]), "input": case["input"], "expected": case["expected"],
                        "about": str(case.get("description", ""))})
    return out


def code_of(said: str) -> str:
    """Intention: the Python a model gave - its last fenced block, or the whole answer when there is no fence."""
    blocks = re.findall(r"```(?:python|py)?\s*\n(.*?)```", str(said), flags=re.S)
    return (blocks[-1] if blocks else str(said)).strip() + "\n"


class Sandbox:
    """A solution and its cases run in a separate isolated Python, with a deadline and no network."""

    def __init__(self, seconds: float = 0.0, stop=None) -> None:
        """Intention: the deadline (the setting when none is given) and the stop."""
        self.seconds = float(seconds) or float(TEST_SECONDS)
        self.stop = stop

    def run(self, code: str, cases: list) -> dict:
        """Intention: {"passed", "of", "share", "results", "why"} - every case's result, and the share that passed."""
        calls = runnable(cases)
        if not calls:
            return {"passed": 0, "of": 0, "share": 0.0, "results": [], "why": "no case can be run as a call"}
        from warp2.record.children import FINISHED, run_watched
        with tempfile.TemporaryDirectory(prefix="warp2_sandbox_") as home:
            folder = Path(home)
            (folder / "solution.py").write_text(code, encoding="utf-8")
            write_kept(folder / "cases.json", calls)
            (folder / "runner.py").write_text(f"ANSWER = {ANSWER!r}\n" + RUNNER, encoding="utf-8")
            done = run_watched([sys.executable, "-I", "runner.py"], seconds=self.seconds, stop=self.stop, cwd=home)
        if done["how"] != FINISHED:
            return self._none(calls, f"the run ended {done['how']}")
        got = None
        for line in reversed(str(done["said"]).splitlines()):
            if line.startswith(ANSWER):
                got = json.loads(line[len(ANSWER):])
                break
        if got is None:
            return self._none(calls, "the run gave no answer: " + last_line(done["said"]))
        if not got.get("loaded"):
            return self._none(calls, "the code did not load: " + str(got.get("why", "")))
        results = [dict(r, about=c["about"], function=c["function"]) for r, c in zip(got["cases"], calls)]
        passed = sum(1 for r in results if r["passed"])
        return {"passed": passed, "of": len(results), "share": passed / len(results), "results": results, "why": ""}

    @staticmethod
    def _none(calls: list, why: str) -> dict:
        """Intention: a run that gave no results - none passed, and why."""
        return {"passed": 0, "of": len(calls), "share": 0.0, "results": [], "why": why}
