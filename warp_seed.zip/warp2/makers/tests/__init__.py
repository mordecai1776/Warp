# WARP2/warp2/makers/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/tests/__init__.py
#  Used by   : pytest, to import the tests in this directory as a package.
#  Uses      : nothing.
#  Description:
#    Makes the makers' tests a package, as the other test folders are, so two
#    test files with one name in different folders never clash.
#  User intention (Andrew, 2026-11-08 23:40): "Build the whole system."
#    (BUILD_LOG 1466.)
# ============================================================================
