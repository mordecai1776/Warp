# WARP2/warp2/makers/tests/test_code_is_fetched_written_tested_and_rewritten.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/tests/test_code_is_fetched_written_tested_and_rewritten.py
#  Used by   : pytest.
#  Uses      : warp2/makers/{code_tasks,sandbox,code_loop,code_ways,code_choice}.py.
#  Description:
#    Coding tasks and examples are found and kept with their licence; code a
#    model wrote runs apart, with a deadline and no network, each case on its
#    own; a task is written and fixed while it passes more; a solved task is
#    written another way and kept only when it passes and really is that way;
#    the next task is the newest one still being learned.
#  User intention (Andrew, 2026-11-08 20:44): code "should be looking for new
#    types of code ... different ways to write different types of codes ...
#    looking for examples as well." (BUILD_LOG 1466.)
# ============================================================================
from __future__ import annotations

import json

from warp2.makers.code_choice import next_task, ranked
from warp2.makers.code_loop import CodeLoop, signatures
from warp2.makers.code_tasks import ExercismTasks, RosettaExamples, Shelf, leaf_cases, python_blocks
from warp2.makers.code_ways import Ways, seen_ways, ways_of
from warp2.makers.sandbox import Sandbox, code_of, snake
from warp2.makers.skills import note_skill

CANONICAL = {"cases": [
    {"uuid": "a", "description": "no name", "property": "twoFer", "input": {"name": None}, "expected": "One for you"},
    {"description": "a group", "cases": [
        {"uuid": "b", "description": "old", "property": "twoFer", "input": {"name": "Al"}, "expected": "x"},
        {"uuid": "c", "reimplements": "b", "description": "Al", "property": "twoFer", "input": {"name": "Al"},
         "expected": "One for Al"}]}]}

PAGE = """=={{header|Perl}}==
<syntaxhighlight lang="perl">print 1</syntaxhighlight>
=={{header|Python}}==
===Iterative===
<syntaxhighlight lang="python">
def fact(n):
    out = 1
    for i in range(2, n + 1):
        out *= i
    return out
</syntaxhighlight>
===Recursive===
<syntaxhighlight lang="python">def fact(n):
    return 1 if n < 2 else n * fact(n - 1)
</syntaxhighlight>
=={{header|Ruby}}==
<syntaxhighlight lang="ruby">puts 1</syntaxhighlight>
"""


class _Net:
    """Intention: the sources as the test says they are."""

    def __init__(self, answers):
        self.answers = answers

    def json(self, url):
        return json.loads(self.text(url))

    def text(self, url):
        for key, said in self.answers.items():
            if key in url:
                return said if isinstance(said, str) else json.dumps(said)
        raise OSError(f"HTTP Error 404: nothing at {url}")


def test_a_task_is_kept_with_its_cases_and_licence_and_a_retired_one_is_passed_by(tmp_path):
    """Intention: the newer case replaces the one it re-implements; source, licence and author are kept."""
    assert [c["uuid"] for c in leaf_cases(CANONICAL)] == ["a", "c"]
    net = _Net({"contents/exercises": [{"name": "gone", "type": "dir"}, {"name": "two-fer", "type": "dir"},
                                       {"name": "README.md", "type": "file"}],
                "two-fer/canonical-data.json": CANONICAL, "two-fer/description.md": "Say one for you."})
    tasks = ExercismTasks(tmp_path, net)
    assert tasks.one()["said"] == "gone has no cases that can be run as calls"
    took = tasks.one()
    assert took == {"took": "two-fer", "cases": 2, "licence": "MIT"}
    kept = Shelf(tmp_path, "tasks").get("two_fer")
    assert kept["licence"] == "MIT" and kept["author"] == "Exercism contributors" and "two-fer" in kept["url"]
    assert "read again" in tasks.one()["said"]


def test_examples_are_the_python_solutions_on_a_page(tmp_path):
    """Intention: only the code under the Python heading, every way it is written, kept with the licence."""
    assert len(python_blocks(PAGE)) == 2 and python_blocks("no python here") == []
    net = _Net({"api.php": {"query": {"categorymembers": [{"title": "Factorial"}]}}, "Factorial&action=raw": PAGE})
    took = RosettaExamples(tmp_path, net).one()
    assert took == {"took": "Factorial", "ways": 2, "licence": "GFDL-1.3"}
    assert seen_ways(tmp_path)["loop"] == 1 and seen_ways(tmp_path)["recursion"] == 1


TASK = {"name": "two-fer", "description": "One for X, one for me.", "cases": [
    {"property": "twoFer", "input": {"name": "Al"}, "expected": "One for Al, one for me."},
    {"property": "twoFer", "input": {"name": "Bo"}, "expected": "One for Bo, one for me."},
    {"property": "twoFer", "input": {"name": ""}, "expected": {"error": "no name"}}]}

RIGHT = '''def two_fer(name):
    if not name:
        raise ValueError("no name")
    return "One for %s, one for me." % name
'''


def test_code_runs_apart_each_case_on_its_own_with_a_deadline_and_no_network():
    """Intention: a share passed, never only pass/fail; a loop is ended; the network is shut."""
    box = Sandbox(seconds=5)
    assert snake("isPangram") == "is_pangram" and code_of("say\n```python\nx = 1\n```\n") == "x = 1\n"
    got = box.run(RIGHT, TASK["cases"])
    assert got["share"] == 1.0 and got["of"] == 3
    half = box.run("def two_fer(name):\n    return 'One for Al, one for me.'\n", TASK["cases"])
    assert half["passed"] == 1 and "wanted" in half["results"][1]["why"]
    assert "did not load" in box.run("def two_fer(:\n", TASK["cases"])["why"]
    assert box.run("while True:\n    pass\n", TASK["cases"])["why"].startswith("the run ended")
    reach = [{"property": "reach", "input": {}, "expected": {"error": "no network"}}]
    shut = box.run("import socket\ndef reach():\n    return socket.create_connection(('example.com', 80))\n", reach)
    assert shut["share"] == 1.0


def test_a_task_is_written_and_fixed_while_it_passes_more(tmp_path):
    """Intention: the failures go back to the model; the best code is kept; the score is noted as a skill."""
    Shelf(tmp_path, "tasks").put("two_fer", TASK)
    assert signatures(TASK["cases"]) == {"two_fer": ["name"]}
    asked = []
    answers = iter(["```python\ndef two_fer(name):\n    return 'One for %s, one for me.' % name\n```",
                    f"```python\n{RIGHT}```"])

    def ask(prompt):
        asked.append(prompt)
        return next(answers)
    got = CodeLoop(tmp_path, ask, "two_fer", Sandbox(seconds=5)).run()
    assert got["right"] == 1.0 and got["why"] == "right" and got["checks"][0] < 1.0
    assert "should raise" in asked[1] and "passed 2 of 3" in asked[1]
    assert Shelf(tmp_path, "solutions").get("two_fer")["share"] == 1.0


def test_a_solved_task_is_written_another_way_and_kept_only_when_it_is(tmp_path):
    """Intention: the new way must pass every case AND read as that way by its syntax tree."""
    assert ways_of(RIGHT) == set() and "recursion" in ways_of("def f(n):\n    return f(n - 1)\n")
    assert ways_of("def f(x):\n    return list(map(lambda v: v, x))\n") == {"functional"}
    Shelf(tmp_path, "tasks").put("two_fer", TASK)
    Shelf(tmp_path, "solutions").put("two_fer", {"code": RIGHT, "share": 1.0})
    ways = Ways(tmp_path)
    assert ways.next() == ("two_fer", "loop")
    looped = ("```python\ndef two_fer(name):\n    if not name:\n        raise ValueError('no name')\n"
              "    out = ''\n    for part in ('One for ', name, ', one for me.'):\n        out += part\n"
              "    return out\n```")
    assert ways.try_one(lambda p: looped, Sandbox(seconds=5))["kept"] is True
    not_really = ways.try_one(lambda p: f"```python\n{RIGHT}```", Sandbox(seconds=5))
    assert not_really == {"task": "two_fer", "way": "recursion", "kept": False, "why": "it is not written that way"}
    assert ways.next() == ("two_fer", "comprehension")


def test_the_next_task_is_new_and_still_being_learned(tmp_path):
    """Intention: an untried task unlike those tried comes first; one solved in full is not worked again."""
    shelf = Shelf(tmp_path, "tasks")
    shelf.put("leap", {"name": "leap", "description": "Leap years in the calendar."})
    shelf.put("leap_again", {"name": "leap again", "description": "Leap years in the calendar again."})
    shelf.put("anagram", {"name": "anagram", "description": "Words made from other letters."})
    note_skill(tmp_path, "code: leap", "code", 1.0)
    rows = {r["task"]: r for r in ranked(tmp_path)}
    assert rows["leap"]["score"] == 0.0 and rows["anagram"]["novelty"] > rows["leap_again"]["novelty"]
    assert next_task(tmp_path) == "anagram"
