# WARP2/warp2/makers/tests/test_skills_and_practice.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/tests/test_skills_and_practice.py
#  Used by   : pytest.
#  Uses      : warp2/makers/{skills,retrain,practise_skill}.py,
#              warp2/make/{training_needs,practice}.py,
#              warp2/work/side/{practice,practice_child,game_work}.py.
#  Description:
#    The skills table ranks where practice goes by room left, movement and
#    time since tried; retraining stops when it stops getting better; every
#    skill is a training need; and general practice takes a skill by its kind.
#  User intention (Andrew, 2026-11-08 20:44): practice "would be general
#    practice"; 23:40 "Build the whole system." (BUILD_LOG 1466.)
# ============================================================================
from __future__ import annotations

from warp2.makers.retrain import UntilRight
from warp2.makers.skills import SkillBook, Standing, note_skill, ranked, usual_gap


def test_a_score_is_kept_as_a_temperature_and_a_torn_line_is_passed_over(tmp_path):
    """Intention: scores are kept to 0..1, one line each; a cut-off line does not lose the rest."""
    book = SkillBook(tmp_path)
    book.add("code: a", "code", 1.7, at=1.0)
    book.add("code: a", "code", -2, at=2.0)
    with book.path.open("a", encoding="utf-8") as out:
        out.write('{"skill": "torn"')
    assert [r["score"] for r in book.rows()] == [1.0, 0.0]
    assert note_skill(tmp_path, "x", "code", None) is None and note_skill(tmp_path, "x", "code", True) is None


def test_progress_is_a_move_against_its_own_noise():
    """Intention: a clear move counts for nearly all; a move inside the noise for little; one score for nothing yet."""
    assert Standing.progress([0.5]) is None
    clear = Standing.progress([0.1, 0.1, 0.1, 0.9, 0.9, 0.9])
    noisy = Standing.progress([0.1, 0.9, 0.2, 0.8, 0.3, 0.7])
    assert clear > 0.9 and noisy < clear
    assert Standing.level([0.1, 0.1, 0.9, 0.9]) == 0.9


def test_practice_goes_to_room_left_that_moves_or_was_left_longest(tmp_path):
    """Intention: a mastered skill has no need; a stuck one waits until stale; a moving one is first."""
    book = SkillBook(tmp_path)
    for at, score in enumerate((0.2, 0.2, 0.6, 0.6)):
        book.add("moving", "code", score, at=float(at))
    for at, score in enumerate((1.0, 1.0)):
        book.add("mastered", "code", score, at=float(at))
    for at, score in enumerate((0.3, 0.3, 0.3, 0.3)):
        book.add("stuck", "code", score, at=float(at))
    gap = usual_gap(book.by_skill())
    assert gap == 1.0
    rows = {r["skill"]: r for r in ranked(tmp_path, now=4.0)}
    assert rows["mastered"]["need"] == 0.0
    assert rows["moving"]["need"] > rows["stuck"]["need"]
    later = {r["skill"]: r for r in ranked(tmp_path, now=400.0)}
    assert later["stuck"]["need"] > rows["stuck"]["need"]


def test_retraining_stops_when_it_stops_getting_better():
    """Intention: teach and check while the check rises by at least one item; right ends it too."""
    said = iter([0.25, 0.5, 0.5])
    got = UntilRight(lambda: None, lambda: next(said), 4).run()
    assert got["why"] == "stopped getting better" and got["best"] == 0.5 and got["rounds"] == 2
    right = iter([0.5, 1.0])
    assert UntilRight(lambda: None, lambda: next(right), 2).run()["why"] == "right"


def test_every_skill_is_a_training_need_with_the_steps_that_answer_it(tmp_path):
    """Intention: the skills table's rows are needs, kind "skill:<kind>", ordered with the rest."""
    from warp2.make.ledger import make_ledger
    from warp2.make.training_needs import STEPS_FOR, needs, steps_first
    note_skill(tmp_path, "code: two_fer", "code", 0.25)
    rows = [r for r in needs(tmp_path, None, None, make_ledger(tmp_path)) if r["kind"].startswith("skill:")]
    assert rows and rows[0]["skill"] == "code: two_fer" and rows[0]["skill_kind"] == "code"
    assert "make_code" in steps_first(rows) and "skill:judge" in STEPS_FOR and "skill:blocks" in STEPS_FOR


class _Fleet:
    """Intention: one model, which answers what the test scripts."""

    def __init__(self, answers):
        self.answers = list(answers)

    def names(self, kind=""):
        return ["m"]

    def choose(self, kind, stream=""):
        return "m"

    def ask(self, name, prompt):
        return self.answers.pop(0) if self.answers else ""


def test_general_practice_works_a_code_skill_again_from_its_best(tmp_path):
    """Intention: when a coding task is the biggest need, practice writes it again until it passes."""
    from warp2.make.ledger import make_ledger
    from warp2.make.practice import turn
    from warp2.makers.code_tasks import Shelf
    Shelf(tmp_path, "tasks").put("double", {"name": "double", "description": "Double a number.",
                                            "cases": [{"property": "double", "input": {"n": 2}, "expected": 4},
                                                      {"property": "double", "input": {"n": 5}, "expected": 10}]})
    note_skill(tmp_path, "code: double", "code", 0.0)
    loop = type("L", (), {})()
    loop.fleet = _Fleet(["```python\ndef double(n):\n    return n * 2\n```"])
    said = turn(tmp_path, None, loop.fleet, None, make_ledger(tmp_path), root=tmp_path, loop=loop)
    assert said["did"] == "practised" and said["task"] == "double" and said["right"] == 1.0
    assert Shelf(tmp_path, "solutions").get("double")["share"] == 1.0


def test_a_game_that_measures_low_goes_back_to_the_builder_once_per_change(tmp_path):
    """Intention: the measure and its weakest parts go into the build work; not again until the game changes."""
    from projects.game_builder.cards import CardShelf, GameCard
    from warp2.makers.practise_skill import game
    from warp2.work.side.game_work import Measures
    CardShelf(tmp_path).put(GameCard(name="Snake", description="Eat and grow."))
    Measures(tmp_path).put("snake", {"measure": 0.4, "file_time": 10.0, "errors": [],
                                     "parts": {"runs": 1.0, "actions": 0.2, "things": None, "skill": 0.1,
                                               "variety": 0.3}})

    class _Board:
        def __init__(self):
            self.added = []

        def add_area(self, project, area, intention, artifact=""):
            self.added.append((area, intention, artifact))
            return {"artifact": artifact}

    board = _Board()
    first = game(tmp_path, tmp_path, board, "snake")
    assert first["did"] == "practised" and first["weakest"] == ["skill", "actions"]
    assert "Make it better where it measured weakest: skill, actions" in board.added[0][1]
    assert game(tmp_path, tmp_path, board, "snake")["did"] == "nothing" and len(board.added) == 1


def test_the_judge_level_is_found_when_the_judge_leads(tmp_path):
    """Intention: the judgement part named in the skills table is mapped back to its level for the child."""
    from warp2.make.ledger import make_ledger
    from warp2.make.lessons import Lessons
    from warp2.work.side.practice_child import JudgeLevel
    Lessons(tmp_path).add({"item": "i", "node": "n", "level": "draft", "what": "w", "eye_tags": ["a"],
                           "passed": False, "score": 0.1})
    note_skill(tmp_path, "judge: draft", "judge", 0.2)
    assert JudgeLevel.leading(tmp_path, None, None, make_ledger(tmp_path)) == "draft"
    SkillBook(tmp_path).add("code: x", "code", 0.0, at=0.0)
    assert JudgeLevel.leading(tmp_path, None, None, make_ledger(tmp_path)) == ""
