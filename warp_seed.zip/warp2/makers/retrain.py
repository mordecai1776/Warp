# WARP2/warp2/makers/retrain.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/retrain.py
#  Used by   : warp2/makers/judge_replay.py, warp2/makers/code_loop.py,
#              warp2/makers/tests/test_retrain_until_right.py.
#  Uses      : nothing outside the standard library.
#  Description:
#    TEACH, CHECK, AGAIN - WHILE IT STILL GETS BETTER. A miss goes back in and
#    is taught again, then checked again; this repeats until it is right, or
#    until a round no longer makes it better. "Better" is by more than the
#    check can tell apart: a share over n items moves in steps of 1/n, so a
#    rise smaller than one item is no rise. So the number of rounds is never
#    set by hand, and it cannot go on for ever (each counted rise is at least
#    one item, and a share cannot pass all of them). What it says: each
#    round's check, the best, how many rounds, and why it stopped - "right",
#    or "stopped getting better", which is the sign to try another model.
#  User intention (Andrew, retraining rule): "when a mistake is made, it goes
#    into the training weighted to where it needs to be. The training runs,
#    the task is done again, and that repeats up to a limit. Then it changes
#    models or makes something usable." (BUILD_LOG 1466.)
# ============================================================================
"""Teach and check again while the check still rises by more than it can tell apart."""
from __future__ import annotations


class UntilRight:
    """One retraining: `teach()` then `check()` (a share, 0..1, over `items` things), repeated while it rises."""

    def __init__(self, teach, check, items: int) -> None:
        """Intention: what teaches, what checks, and how many things the check counts (its resolution is 1/items)."""
        self.teach = teach
        self.check = check
        self.items = max(1, int(items))

    def run(self, first: float | None = None) -> dict:
        """Intention: rounds while the check rises by at least one item; {"checks", "best", "rounds", "why"}."""
        step = 1.0 / self.items
        best = float(self.check()) if first is None else float(first)
        checks = [best]
        while best < 1.0:
            self.teach()
            now = float(self.check())
            checks.append(now)
            if now < best + step:
                return {"checks": checks, "best": best, "rounds": len(checks) - 1, "why": "stopped getting better"}
            best = now
        return {"checks": checks, "best": best, "rounds": len(checks) - 1, "why": "right"}
