# WARP2/warp2/makers/judge_replay.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/judge_replay.py
#  Used by   : warp2/work/side/practice.py (PracticeStep.child, when the top
#              need is a judge level), warp2/makers/tests/test_retrain_until_right.py.
#  Uses      : warp2/make/{lessons,eye_lessons}.py (every stage at a level, as
#              the judgement part learns them), projects/behemoth_eye/eye/
#              warp_eye.py (EyeBook), projects/behemoth_eye/pairs/fronts.py
#              (VECTOR), warp2/makers/{retrain,skills}.py.
#  Description:
#    THE JUDGE'S MISSES, TAUGHT UNTIL RIGHT. The Eye's judgement part at a
#    level (`judge: <level>`) was taught each new stage once - one "task"
#    stage a turn, wrong before and wrong after, for days. Here it is taught
#    every stage there has ever been at that level, passed and failed, weighted
#    as teach_eye_what_was_made weighs them, and checked on all of them; again
#    while its share right still rises by at least one stage (retrain.py).
#    The Eye is saved, and the share right goes into the skills table as
#    "judge: <level>". Run in a child process: plain values only cross.
#  User intention (Andrew, retraining rule: "when a mistake is made, it goes
#    into the training weighted to where it needs to be ... that repeats up to
#    a limit"); 2026-11-08 20:44 "Go ahead and follow the fixes" (BUILD_LOG 1466).
# ============================================================================
"""The Eye's judgement part at one level, retaught on every stage until its guesses stop getting better."""
from __future__ import annotations


class JudgeReplayInChild:
    """Intention: a level and the state folder only - plain values, so it crosses into a spawned child."""

    def __init__(self, state, level: str) -> None:
        """Intention: where the Eye and the lessons are, and which level's judge to teach."""
        self.state = str(state)
        self.level = str(level)

    def __call__(self) -> dict:
        """Intention: every stage at the level taught and checked until right or no better; said and noted."""
        from warp2.make.eye_lessons import VERDICTS, _guesses_right, _judged_by_level, judge_name
        from warp2.make.lessons import Lessons
        from warp2.makers.retrain import UntilRight
        from warp2.makers.skills import note_skill
        rows = [r for r in Lessons(self.state).rows() if str(r.get("level")) == self.level]
        grouped = _judged_by_level(rows).get(self.level)
        if not grouped or not grouped[0]:
            return {"did": "nothing", "why": f"no stage at {self.level} the Eye can read", "in_child": True}
        inputs, labels, weights = grouped
        from projects.behemoth_eye.eye.warp_eye import EyeBook
        from projects.behemoth_eye.pairs.fronts import VECTOR
        book = EyeBook(self.state)
        part = judge_name(self.level)

        def teach() -> None:
            """Intention: every stage at the level, once more, weighted by how clear its verdict was."""
            book.learn(part, inputs, labels, list(VERDICTS), VECTOR, weights=weights)

        def check() -> float:
            """Intention: the share of the stages the judge now guesses right; nothing guessed is none right."""
            said = _guesses_right(book, part, inputs, labels)
            return (said["right"] / len(labels)) if said else 0.0

        if part not in book.tasks():
            teach()
        got = UntilRight(teach, check, len(labels)).run()
        book.save()
        note_skill(self.state, part, "judge", got["best"], f"{got['rounds']} rounds, {got['why']}")
        return {"did": "practised", "who": "the Eye's judge", "level": self.level, "stages": len(labels),
                "right": round(got["best"], 4), "checks": [round(c, 4) for c in got["checks"]],
                "why": got["why"], "in_child": True}
