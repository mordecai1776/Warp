# WARP2/warp2/makers/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/makers/__init__.py
#  Used by   : warp2/work/side/{games,make_code,practice}.py,
#              warp2/make/{practice,training_needs}.py, the tests beside it.
#  Uses      : nothing at import (each part is imported where it is used).
#  Description:
#    THE MAKERS: one loop used three times (games, code, practice). An
#    archive of what was made; a pick of what to try next by what is new and
#    still being learned; it is made as code; it is checked by running it;
#    its graded score (0..1, a temperature) goes into one skills table that
#    every part writes to; and a miss is trained again until it is right, up
#    to the point it stops getting better. The parts:
#      skills.py      - the skills table, and where practice should go next;
#      retrain.py     - teach, check, again, while it still gets better;
#      judge_replay.py- the Eye's judgement part retaught on every stage at a
#                       level, until its guesses stop getting better;
#      sandbox.py     - code run on its own, with a deadline, its tests read;
#      code_tasks.py  - coding tasks with tests (Exercism) and many ways of
#                       writing one task (Rosetta Code), kept with their licence;
#      code_loop.py   - write, test, fix, while the failures keep falling;
#      code_ways.py   - the same task written other ways, each still passing;
#      code_choice.py - which coding task next.
#    The game parts live beside the game builder (projects/game_builder/
#    {fetch_copy,game_spec,game_measure,game_choice}.py).
#  User intention (Andrew, 2026-11-08 20:44): "games should be trying to make
#    games and play games ... look for new games that it wants to make, look
#    for files they can find of those games, and try to make those games
#    either as good as it is seen or better ... As far as practice ... general
#    practice ... As far as code goes, it should be looking for new types of
#    code. It should look at the codes it has seen and try to figure out
#    different ways to write different types of codes. It should also be
#    looking for examples as well, the same as games." 23:40: "Build the whole
#    system. Whether it is good or not, it'll be determined by time, events,
#    and reality." (BUILD_LOG 1466; plan design/plans/GAMES_CODE_PRACTICE.md.)
# ============================================================================
"""Games, code and general practice: one loop, used three times."""
