# WARP2/warp2/ask/request_folder.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/request_folder.py
#  Used by   : warp2/ask/taking.py (writes requests and feedback in),
#              warp2/work/side/asked.py (the loop takes them out),
#              warp2/ask/image_asks.py (the window reads where each ask stands).
#  Uses      : warp2/util.py; stdlib json.
#  Description:
#    A project's request folder: one JSON file per request, and a `.ack` file
#    beside it once the request is handled. The same file shape
#    projects/centering_image/spaces.py uses (`send`, `pending`,
#    `acknowledge`), so either side can read what the other wrote.
#  User intention (Andrew, 2026-09-18):
#    "detach the immediate change that image user stuff works and place that
#    into something that adds to the work instead of acting like a trigger."
#    This is the "something": a click writes here, and the loop does the work.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.util import atomic_write_bytes, now_iso


class RequestFolder:
    """Requests waiting for a project, and what became of each.

    Intention: a request is never rewritten. Whether it is handled is decided
    by the `.ack` beside it, so what a person asked for can never be changed
    by the thing that answered it.
    """

    def __init__(self, folder) -> None:
        """Intention: the folder the project reads, e.g. state/centering_image/inbox."""
        self.folder = Path(folder)

    def add(self, name: str, body: dict) -> Path:
        """Intention: one file per request, named by the ask it came from."""
        self.folder.mkdir(parents=True, exist_ok=True)
        path = self.folder / f"{name}.json"
        atomic_write_bytes(path, json.dumps({**body, "id": name}, ensure_ascii=False).encode("utf-8"))
        return path

    def waiting(self, kind: str = "") -> list:
        """Every request not yet handled, oldest first, as (path, body)."""
        out = []
        for path in sorted(self.folder.glob("*.json")):
            if path.with_suffix(".ack").exists():
                continue
            body = _read(path)
            if body is not None and (not kind or body.get("kind") == kind):
                out.append((path, body))
        return out

    def handled(self, path, result: dict) -> None:
        """Intention: say what became of it, beside it, never over it."""
        atomic_write_bytes(Path(path).with_suffix(".ack"),
                           json.dumps({"at": now_iso(), "result": result},
                                      ensure_ascii=False, default=str).encode("utf-8"))

    def answer(self, name: str) -> dict | None:
        """Intention: what became of one request, or None while it waits."""
        return _read(self.folder / f"{name}.ack")


# Intention: a torn or half-synced file is read as missing, never as an error
# that stops a pass or a window refresh.
def _read(path) -> dict | None:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
