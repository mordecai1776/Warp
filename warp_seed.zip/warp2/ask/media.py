# WARP2/warp2/ask/media.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/media.py
#  Used by   : warp2/ask/window.py (Action Centre — keep_image when a picture
#              is confirmed), warp2/ask/talk.py.
#  Uses      : projects/centering_image/{generator,image_search}.py,
#              projects/behemoth_eye/eye/warp_pictures.py (EyePictures — the
#              WARP's one Eye), warp2/ask/picture_size.py (the size asked for),
#              PIL (Pillow), numpy, hashlib, json, time, re.
#              warp2/tags/media/pictures.py (is_there, bytes_of, where_file_is - asked of the small form; BUILD_LOG 1597c);
#  Description:
#    Project-backed media generation for still images and animated videos.
#    Generates visual representations using the WARP's one Eye and
#    real-world visual search, with cataloging and interactive model training.
#  User intention (Andrew, 2026-09-07):
#    "we can add some functions for image and video generation to the user interface"
#    "make some more things to support created images"
#    "it should do it automaticaly it should always be proactive like that"
#    "The image should say what it is trying to make and look for more suporting images each time it retrains"
#    "It should also always say what it is trying to make"
#    "It should also show refrence images that it finds to varifay what the image is"
# ============================================================================
from __future__ import annotations

import hashlib
import json
import re
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from warp2.record.swallowed import noted
from warp2.tags.media import pictures


def _load_banner_fonts():
    """Load clear TrueType fonts for image target banners with graceful fallback.

    Intention: Legible typography so anyone viewing the image can read what
    subject the Eye model is attempting to synthesize.
    """
    from PIL import ImageFont
    for name in ("arialbd.ttf", "segoeuib.ttf", "calibrib.ttf", "arial.ttf", "segoeui.ttf"):
        try:
            return ImageFont.truetype(name, 15), ImageFont.truetype(name, 11)
        except Exception:
            continue
    try:
        f = ImageFont.load_default()
        return f, f
    except Exception:
        return None, None




def extract_visual_subject(text: str) -> str:
    """Normalize and resolve prompt text into a concrete visual subject.

    User intention (Andrew, 2026-09-07):
    "make an image of something form the real workld you know."
    Resolves conversational phrasing, directives, and typos to concrete subjects
    that Wikimedia Commons and the Eye model can visualize.
    """
    from warp2.ask.picture_size import without_size
    # Intention (2026-10-03): a size asked for is not part of what to draw.
    raw = without_size(str(text or "")).strip().lower()
    for prefix in (
        "make an image of", "make a picture of", "make image of", "make a video of",
        "draw me an image of", "draw me a picture of", "draw me a", "draw me an",
        "draw me", "draw a", "draw an", "draw", "generate an image of",
        "generate a picture of", "generate", "show me a", "show me an",
        "show me", "picture of", "image of",
    ):
        if raw.startswith(prefix):
            raw = raw[len(prefix):].strip()
            break

    raw = raw.strip(".?!,;: ")

    # Handle "something from the real world" variations (including typos like form/workld)
    if re.search(r"something\s+(?:form|from)\s+(?:the\s+)?(?:real\s+)?(?:workld|world)", raw):
        return "planet earth"

    cleaned = re.sub(r"^(?:a|an|the)\s+", "", raw).strip()
    return cleaned or "planet earth"


# Where the image model keeps its note. A new name again (2026-09-19): the
# stand-in picture pairs' note (picture_pairs.json) is archived with them and
# never read as if it were this; the Eye itself is saved under models/eye.
IMAGE_CHECKPOINT = "picture_eye.json"


def get_or_load_eye_model(root_dir: Path, state_dir: Path, side: int = 0):
    """The image model: the WARP's one Eye — subjects are its concepts, drawing is its painter.

    User intention (Andrew, 2026-09-19): "get the eye in place of the pop
    network in all places where the master is the entire eye and all the
    rest are just parts"; pictures drawn "coarse to fine by looks".

    Intention: the stand-in picture pairs are archived, not hidden. What
    stands here now is projects/behemoth_eye/eye/warp_pictures.py, imported
    by the same name the rest of the WARP uses for the Eye, so there is one
    Eye in this process. A note that will not load is an error the caller
    sees, not a silent fresh start.

    `side` is the size pictures are drawn at; nought keeps the model's own.
    """
    root = Path(root_dir)
    if not (root / "projects" / "behemoth_eye" / "eye").is_dir():
        root = Path(__file__).resolve().parents[2]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from projects.behemoth_eye.eye.warp_pictures import DRAWN, EyePictures
    note = Path(state_dir) / "models" / IMAGE_CHECKPOINT
    if note.is_file():
        return EyePictures.load(note)
    return EyePictures(state_dir, longest=int(side) if 0 < int(side) <= 2048 else DRAWN)


def record_image_catalog(state_dir: Path, entry: dict) -> None:
    """Record metadata for a generated image in state/images/catalog.jsonl.

    User intention (Andrew, 2026-09-07):
    "make some more things to support created images"
    """
    cat_file = Path(state_dir) / "images" / "catalog.jsonl"
    cat_file.parent.mkdir(parents=True, exist_ok=True)
    with cat_file.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(entry, ensure_ascii=False) + "\n")


def list_created_images(state_dir: Path, limit: int = 30) -> list[dict]:
    """Retrieve cataloged images, newest first.

    User intention (Andrew, 2026-09-07):
    "make some more things to support created images"
    """
    cat_file = Path(state_dir) / "images" / "catalog.jsonl"
    results = []
    if cat_file.is_file():
        for line in cat_file.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if line:
                try:
                    results.append(json.loads(line))
                except Exception:
                    continue
    if not results:
        img_dir = Path(state_dir) / "images"
        if img_dir.is_dir():
            for p in sorted(img_dir.glob("*.png"), reverse=True):
                if p.name != "catalog.jsonl":
                    subject = p.stem
                    meta_file = p.with_suffix(".source.json")
                    if meta_file.is_file():
                        try:
                            meta = json.loads(meta_file.read_text(encoding="utf-8"))
                            subject = meta.get("query") or meta.get("title") or subject
                        except Exception as exc:
                            noted("warp2/ask/media.py:list_created_images", exc)
                    results.append({
                        "id": p.stem,
                        "subject": subject,
                        "image_path": str(p.resolve()),
                        "time": "",
                    })
    return list(reversed(results))[:limit] if results else []


def train_on_image(root_dir: Path, state_dir: Path, image_path: str, score: float = 1.0,
                   subject: str = "") -> dict:
    """Teach the subject's concept in the Eye a picture a person judged: yes, or no.

    User intention (Andrew, 2026-09-07):
    "we need to have a evolveing system of what it can and cant do... make some more things to support created images."
    And 2026-09-19: the Eye in place of the pop networks.
    """
    ci_path = Path(root_dir) / "projects" / "centering_image"
    if str(ci_path) not in sys.path:
        sys.path.insert(0, str(ci_path))
    from generator import form_tag

    model = get_or_load_eye_model(root_dir, state_dir)
    img_file = Path(image_path)
    if not pictures.is_there(img_file):
        return {"error": "Image file not found"}

    # Intention: THE SUBJECT THE PERSON JUDGED IS THE ONE TRAINED. The click
    # carries it. Only when it is missing is the catalog searched, and the
    # catalog holds the last 100 made pictures, so a confirmed reference
    # picture was trained under "visual subject" instead of what it shows.
    stated = str(subject or "").strip()
    subject = stated or "visual subject"
    catalog = [] if stated else list_created_images(state_dir, limit=100)
    for item in catalog:
        if item.get("image_path") == str(img_file.resolve()) or item.get("reference_path") == str(img_file.resolve()):
            subject = item.get("subject", subject)
            break

    tag = form_tag(subject)
    example = {
        "tag": tag,
        "kind": "generated",
        "image_path": str(img_file.resolve()),
        "sample": {"pixels": []},
        "score": max(-1.0, min(1.0, float(score))),
    }

    try:
        result = model.train_example(example, weight=1.0)
        models_dir = Path(state_dir) / "models"
        models_dir.mkdir(parents=True, exist_ok=True)
        model.save(models_dir / IMAGE_CHECKPOINT)
        result.update({"subject": subject, "score": score, "saved": True})
        return result
    except Exception as exc:
        return {"error": str(exc)}




def make_project_image(root_dir: Path, state_dir: Path, subject: str,
                       mistakes=None, rounds: int = 0,
                       until_it_passes: bool = True, at_a_time: int = 0,
                       on_progress=None, is_user_ask: bool = True,
                       resume=None, one_part: bool = False, on_part=None, size=None, **kwargs) -> dict:
    """Make the picture, and keep going until a reader says it is the one.

    User intention (Andrew, 2026-09-07):
    "it should do it automaticaly it should always be proactive like that"
    And 2026-09-12: "it should just keep retraining with new internet data and
    retraining until it gives one that the reader says is what was asked for."
    And 2026-09-26: "lets have it make a thing to do that is done until it passes
    when the user ask for it and have it get back to the user when it is done."
    And 2026-09-27: "when a user ask for something it should not let it go until
    it can produce it at a 100 from the reader"

    THIS USED TO GENERATE ONCE. One image, one reading, and whatever came out
    went to the person — if the readers said it was not the subject, the answer
    was still that image, with a note. Now it is a round: generate, read, and
    if it is wrong go and get reference data for the parts the readers said
    were missing, train on it, and go again. See warp2/ask/until.py.

    `mistakes` is optional because the window that calls this has no store of
    its own, and opening a second one would put a second writer on the fact
    lane. Handed one, every failed picture is counted into the same tally that
    decides how much of the machine's time goes to training; handed none, the
    loop still runs and simply is not counted.
    """
    from warp2.ask.visual import VisualLearning
    clean_subject = extract_visual_subject(subject)
    trained_refs = 0
    pretraining_warnings = []
    learning = VisualLearning(root_dir, state_dir)
    existing_refs = learning.references(clean_subject)
    # User intention (Andrew, 2026-09-28):
    # "whenever it tryies to learn something new it should always get or make as many datasets with said thing
    # and then learn all concepts in that dataset and refine it down to what is needed to learn as it learns it"
    # Intention (2026-10-02): in the middle of a round taken a part at a time,
    # the gathering and pre-teaching below is not repeated every part.
    mid_round = bool(one_part and (resume or {}).get("part_state"))
    if (not existing_refs or len(existing_refs) < 12) and not mid_round:
        try:
            from warp2.train.dataset_curator import DatasetCurator
            curator = DatasetCurator(root_dir, state_dir)
            manifests = curator.discover_and_create_needed([clean_subject], min_samples=15)
            for m in manifests:
                samples = list(m.get("train_samples") or []) + list(m.get("test_samples") or [])
                curator.ingest_into_visual_learning(samples, clean_subject)
            existing_refs = learning.references(clean_subject)
        except Exception as exc:
            pretraining_warnings.append({"stage": "dataset_discovery", "error": str(exc)})

        # Intention (2026-10-09, fix 3.5, check B6): only usable references are
        # taught as the subject, each at the score it was given.
        from warp2.ask.reference import taught_score
        teachable = [dict(r, reader_score=taught_score(r)) for r in existing_refs
                     if taught_score(r) is not None]
        # Learn all concepts in that dataset via CentroidClusterTrainingEngine
        if teachable:
            try:
                from warp2.train.centroid_cluster_training import CentroidClusterTrainingEngine
                c_engine = CentroidClusterTrainingEngine(state_dir=state_dir, root_dir=root_dir)
                dataset_items = [
                    {
                        "id": r["id"],
                        "data": r["path"],
                        "image_path": r["path"],
                        "certainty": r["reader_score"],
                        "label": clean_subject,
                        "concept_scores": r.get("concept_scores", {}),
                        "tags": r.get("tags", []),
                    }
                    for r in teachable
                ]
                c_engine.process_dataset(label=clean_subject, dataset=dataset_items)
            except Exception as exc:
                pretraining_warnings.append({"stage": "dataset_concepts", "error": str(exc)})

            # Pre-train the Eye model on these verified references across all concepts
            try:
                from generator import form_tag
                from warp2.ask.reference import Worth
                model = get_or_load_eye_model(root_dir, state_dir)
                tag = form_tag(clean_subject)
                for r in teachable[:12]:
                    ref_ex = {
                        "tag": tag,
                        "kind": "reference",
                        "image_path": r["path"],
                        "score": r["reader_score"],
                        "tags": r.get("tags", [clean_subject]),
                        "concept_scores": r.get("concept_scores", {}),
                        "concept_tags": r.get("concept_tags", []),
                        "attached_datasets": r.get("attached_datasets", []),
                        "preemptive_concepts": r.get("preemptive_concepts", []),
                    }
                    model.train_example(ref_ex, weight=float(Worth().weigh(r)["weight"]))
                    trained_refs += 1
                if trained_refs > 0:
                    models_dir = Path(state_dir) / "models"
                    models_dir.mkdir(parents=True, exist_ok=True)
                    model.save(models_dir / IMAGE_CHECKPOINT)
            except Exception as exc:
                pretraining_warnings.append({"stage": "eye_reference_training", "error": str(exc)})

    from warp2.ask.until import Until
    learning = VisualLearning(root_dir, state_dir)
    went = Until(learning, mistakes=mistakes, rounds=rounds,
                 until_it_passes=until_it_passes, is_user_ask=is_user_ask, each=on_progress,
                 one_part=one_part, each_part=on_part, size=size).make(
                     clean_subject, resume=resume, at_a_time=at_a_time)
    # Intention: THE ROUNDS ARE HANDED BACK WITH THE PICTURE. A person who is
    # given the fourth-best image needs to be able to see that there were four,
    # what the readers said each time, and what was still missing at the end.
    # Intention (2026-10-09, fix 3.1, check B8): THE ROUND'S VERDICT IS THE
    # VERDICT. This used to judge the picture again with another rule, so it
    # could hand back approved=False with status "approved". The picture round
    # (warp2/ask/picture_round.py) applies the one pass rule; it is passed on.
    is_approved = bool(went.get("approved", False))

    result = dict(went.get("best") or {})
    result.update(image_path=went.get("image_path", ""), subject=clean_subject,
                  approved=is_approved, evidence=went.get("evidence"),
                  status="approved" if is_approved else went.get("how", "retrying_for_competence"),
                  said=went.get("said", ""), missing=went.get("missing", []),
                  rounds=went.get("rounds", 0), tried=went.get("tried", []),
                  resume=went.get("resume"),
                  pretraining_warnings=pretraining_warnings)
    result["proactive"] = True
    # Intention (fix 3.1, check B8): only real updates are counted; a round
    # that trained nothing says 0, never a made-up count.
    if trained_refs > 0:
        result["trained_refs"] = max(result.get("trained_refs", 0), trained_refs)
        result["updates"] = max(result.get("updates", 0), trained_refs)
    result.setdefault("updates", 0)
    result["references"] = result.get("references") or [r.get("path") for r in existing_refs if r.get("path")] or []
    if result.get('image_path'):
        record_image_catalog(state_dir, result)

    # When 100% is produced from the reader, execute centroid cluster expansion on all data for this subject!
    if is_approved:
        try:
            from warp2.train.centroid_cluster_training import CentroidClusterTrainingEngine
            c_engine = CentroidClusterTrainingEngine(state_dir=state_dir)
            refs = result.get("reference_reviews") or []
            data = [{"id": f"{clean_subject}_approved", "data": result.get("image_path", ""), "certainty": 1.0, "label": clean_subject}]
            for idx, r in enumerate(refs):
                p = r.get("path") or f"ref_{idx}"
                data.append({
                    "id": f"{clean_subject}_ref_{idx}",
                    "data": str(p),
                    "certainty": float(r.get("reader_score", 0.8)),
                    "label": clean_subject,
                })
            c_engine.process_dataset(label=clean_subject, dataset=data)
        except Exception as exc:
            noted("warp2/ask/media.py:make_project_image", exc)

    return result


def train_eye_until_pass(root_dir: Path, state_dir: Path, subject: str,
                         target_score: float = 0.85, max_rounds: int = 25,
                         on_progress=None, is_video: bool = False) -> dict:
    """Continuously retrain the Eye in-place on subject references until passing reader score.

    User intention (Andrew, 2026-09-22):
    "train a the eye right there for said image or video where it just retrains until it passes."
    """
    from warp2.ask.eye_trainer import EyePersistentTrainer
    trainer = EyePersistentTrainer(root_dir, state_dir, default_target=target_score)
    return trainer.train_until_pass(
        subject=subject,
        target_score=target_score,
        max_rounds=max_rounds,
        on_progress=on_progress,
        is_video=is_video,
    )


def confirm_and_store_image(root_dir: Path, state_dir: Path, image_path: str | Path,
                            train: bool = True, confirmed_by: str = "user", subject: str = "") -> dict:
    """Explicitly approve an image, store it to the catalog, and (by default) train on it.

    User intention (Andrew, 2026-09-08):
    "when I conferm a image it needs to get stored and go away"
    And 2026-09-18: a click adds to the work instead of acting like a trigger.
    The window passes `train=False`: it stores now, and the training is left
    to the loop, which learns from the feedback on its own turn
    (warp2/work/side/asked.py).
    """
    from warp2.ask.visual import VisualLearning
    p = Path(image_path)
    if not pictures.is_there(p):
        return {"error": "Image file not found"}

    # 1. Approve in VisualLearning
    learning = VisualLearning(root_dir, state_dir)
    attempt = learning.approve_attempt(p, confirmed_by=confirmed_by, subject=subject)

    subj = subject or attempt.get("subject", p.stem)
    if subj == "user_confirmed":
        subj = p.stem

    # 2. Record it in the catalog with accurate attribution
    entry = {
        "image_path": str(p.resolve()),
        "subject": subj,
        "status": "approved",
        "approved": True,
        "confirmed_by": str(confirmed_by or "user"),
    }
    record_image_catalog(state_dir, entry)

    # 3. Train positive feedback on the model, and SAY SO IF IT DID NOT HAPPEN
    # rather than taking the store down with it.
    if not train:
        train_res = {"trained": False, "why": "left to the loop"}
    else:
        try:
            train_res = train_on_image(root_dir, state_dir, str(p), score=1.0)
        except Exception as trouble:
            train_res = {"trained": False, "why": str(trouble)}

    # 4. Copy to state/images if not already in state
    try:
        gallery_dir = Path(state_dir) / "images"
        gallery_dir.mkdir(parents=True, exist_ok=True)
        if not str(p.resolve()).startswith(str(gallery_dir.resolve())):
            # Intention (BUILD_LOG 1597c): the gallery's copy is written from the picture's own bytes, asked of the
            # small form, so it is the same whether the picture's file is in the warp or went to deep storage.
            from warp2.util import atomic_write_bytes
            dest = gallery_dir / p.name
            if not dest.is_file():
                atomic_write_bytes(dest, pictures.bytes_of(p))
    except Exception as exc:
        noted("warp2/ask/media.py:confirm_and_store_image", exc)

    return {
        "status": "stored",
        "image_path": str(p.resolve()),
        "subject": entry["subject"],
        "training": train_res,
    }


# Intention (2026-10-09, fix 3.5, check B11): a confirmed reference is stored
# in the gallery AS A REFERENCE — "when I conferm a image it needs to get
# stored and go away" (Andrew, 2026-09-08) — and not approved as a picture
# the Eye made, which confirm_and_store_image does.
def store_reference(state_dir: Path, image_path: str | Path, subject: str = "",
                    confirmed_by: str = "user") -> dict:
    """Catalogue the confirmed reference and copy it into the gallery folder; its catalogue entry."""
    from warp2.util import atomic_write_bytes
    p = Path(image_path)
    if not pictures.is_there(p):
        return {"error": "Image file not found"}
    entry = {"image_path": str(p.resolve()), "subject": subject or p.stem, "kind": "reference",
             "status": "confirmed", "approved": False, "confirmed_by": str(confirmed_by or "user")}
    record_image_catalog(state_dir, entry)
    gallery = Path(state_dir) / "images"
    gallery.mkdir(parents=True, exist_ok=True)
    if not str(p.resolve()).startswith(str(gallery.resolve())) and not (gallery / p.name).is_file():
        atomic_write_bytes(gallery / p.name, pictures.bytes_of(p))
    return entry


def kept_home(state_dir: Path) -> Path:
    """Intention: where confirmed pictures are kept — the set the Eye learns from, off the to-look-at list."""
    return Path(state_dir) / "images" / "kept"


def keep_image(root_dir: Path, state_dir: Path, image_path: str | Path) -> dict:
    """A confirmed picture moved into the kept set, then stored there; what was stored.

    Intention: Andrew, 2026-09-25: "have the image thing close out a image
    and move it when I confirm it." The file is MOVED, not copied, so it
    leaves the pictures still waiting and is one file in one place; it is
    approved and catalogued at its new place, so everything that reads the
    kept set finds it there. A name already in the kept set is never
    written over — the new one takes a longer name.
    """
    import shutil
    p = Path(image_path)
    if not p.is_file():
        return {"error": "Image file not found"}
    home = kept_home(state_dir)
    home.mkdir(parents=True, exist_ok=True)
    dest = home / p.name
    if p.resolve() != dest.resolve():
        if dest.exists():
            dest = home / f"{p.stem}_{hashlib.sha256(p.read_bytes()).hexdigest()[:10]}{p.suffix}"
        if not dest.exists():
            shutil.move(str(p), str(dest))
    return {**confirm_and_store_image(root_dir, state_dir, dest, train=False), "moved_from": str(p)}


def self_confirm_image(root_dir: Path, state_dir: Path, image_path: str | Path,
                       score: float = 1.0, subject: str = "") -> dict:
    """A picture self-confirmed by the system based on reader verification or model confidence.

    Intention: Andrew, 2026-09-27: "the system should have a way to self comferm as well".
    Moves the verified picture into the kept set, marks it with confirmed_by="system",
    and ingests a self_confirmed_image universal training block.
    """
    import shutil
    p = Path(image_path)
    if not p.is_file():
        return {"error": "Image file not found"}
    home = kept_home(state_dir)
    home.mkdir(parents=True, exist_ok=True)
    dest = home / p.name
    if p.resolve() != dest.resolve():
        if dest.exists():
            dest = home / f"{p.stem}_{hashlib.sha256(p.read_bytes()).hexdigest()[:10]}{p.suffix}"
        if not dest.exists():
            shutil.move(str(p), str(dest))

    # Approve in VisualLearning with system attribution
    from warp2.ask.visual import VisualLearning
    learning = VisualLearning(root_dir, state_dir)
    attempt = learning.approve_attempt(dest, confirmed_by="system", subject=subject or dest.stem)
    sub = subject or attempt.get("subject", dest.stem)
    if sub == "user_confirmed":
        sub = dest.stem

    entry = {
        "image_path": str(dest.resolve()),
        "subject": sub,
        "status": "approved",
        "approved": True,
        "confirmed_by": "system",
        "reader_score": float(score),
    }
    record_image_catalog(state_dir, entry)

    # Ingest into universal training blocks
    block_id = ""
    try:
        from warp2.train.training_blocks import TrainingBlockIngestor
        ingestor = TrainingBlockIngestor(state_dir)
        block_id = ingestor.ingest_visual(
            subject=sub,
            status="self_confirmed_image",
            approved=True,
            rounds=1,
            reference_path=str(dest.resolve()),
            reader_score=float(score),
        )
    except Exception as exc:
        noted("warp2/ask/media.py:self_confirm_image", exc)

    return {
        "status": "self_confirmed",
        "image_path": str(dest.resolve()),
        "subject": sub,
        "confirmed_by": "system",
        "training_block_id": block_id,
        "moved_from": str(p),
    }


def self_confirm_reference(root_dir: Path, state_dir: Path, review_or_path: dict | str | Path,
                           score: float | None = None) -> dict:
    """Self-confirm a reference the readers passed, at the score they gave it.

    Intention (2026-10-09, fix 3.5, checks B5, B11): a reference with no
    reader score is not judged and stays for a person (it was confirmed at
    1.0); and a reference is confirmed as a reference — it was also approved
    as a picture the Eye made.
    """
    from warp2.ask.visual import VisualLearning
    learning = VisualLearning(root_dir, state_dir)
    ref_id = ""
    if isinstance(review_or_path, dict):
        review = review_or_path
        p = Path(review.get("path") or review.get("image_path") or "")
        ref_id = review.get("id") or (p.stem if p.is_file() else "")
        sub = review.get("subject") or p.stem
        said = review.get("reader_score")
    else:
        p = Path(review_or_path)
        ref_id = p.stem
        sub = p.stem
        said = score
    if type(said) not in (int, float):
        return {"status": "not_judged", "reference_path": str(p), "subject": sub,
                "said": "no reader score — left for a person"}
    sc = float(said)

    if sub == "user_confirmed":
        sub = p.stem

    row = learning.confirm(ref_id, True, confirmed_by="system") if ref_id else {}
    if p and p.is_file():
        store_reference(state_dir, p, subject=sub, confirmed_by="system")

    block_id = ""
    try:
        from warp2.train.training_blocks import TrainingBlockIngestor
        ingestor = TrainingBlockIngestor(state_dir)
        block_id = ingestor.ingest_visual(
            subject=sub,
            status="self_confirmed_reference",
            approved=True,
            rounds=1,
            reference_path=str(p.resolve()) if p and p.is_file() else "",
            reader_score=sc,
        )
    except Exception as exc:
        noted("warp2/ask/media.py:self_confirm_reference", exc)

    return {
        "status": "self_confirmed",
        "reference_path": str(p.resolve()) if p and p.is_file() else "",
        "subject": sub,
        "confirmed_by": "system",
        "training_block_id": block_id,
        "visual_row": row,
    }


# Intention (2026-10-09, fix 3.5, check B6): a searched reference for a video
# is taught only when the readers passed it, at their score and the weight it
# is worth — every one was taught at weight 1.0, a missing score as 1.0.
def _teach_if_passed(model, tag, tag_name: str, ref: dict, path: Path, eval_res: dict) -> int:
    """Teach the reference when the readers passed it; 1 if taught, else 0."""
    from concept_terms import extract_all_tags
    from warp2.ask.reference import Worth
    if not eval_res.get("passed") or type(eval_res.get("score")) not in (int, float):
        return 0
    ref_ex = {
        "tag": tag, "kind": "reference", "image_path": str(path.resolve()),
        "score": float(eval_res["score"]),
        "tags": eval_res.get("tags") or extract_all_tags(ref, subject=tag_name),
        "concept_scores": eval_res.get("detected_concepts", {}),
        "concept_tags": eval_res.get("concept_tags", []),
        "attached_datasets": eval_res.get("attached_datasets", []),
        "preemptive_concepts": eval_res.get("preemptive_concepts", []),
    }
    worth = Worth().weigh({"reader_score": float(eval_res["score"]), "reader_verdict": "verified"})
    model.train_example(ref_ex, weight=float(worth["weight"]))
    return 1


def make_project_video(root_dir: Path, state_dir: Path, subject: str,
                       frames: int = 16, fps: int = 8) -> dict:
    """Generate an animated video clip proactively conditioned on learned visual data.

    User intention (Andrew, 2026-09-07):
    "it should do it automaticaly it should always be proactive like that"
    Proactively fetches real-world references and conditions the Eye model
    before synthesizing temporal motion frames.
    """
    vid_dir = Path(state_dir) / "videos"
    vid_dir.mkdir(parents=True, exist_ok=True)
    clean_subject = extract_visual_subject(subject)
    tag_name = clean_subject
    ident = hashlib.sha256(f"vid_{tag_name}_{time.time()}".encode("utf-8")).hexdigest()[:12]
    dest = vid_dir / f"{ident}.gif"

    ci_path = Path(root_dir) / "projects" / "centering_image"
    if not ci_path.is_dir():
        ci_path = Path(__file__).resolve().parents[2] / "projects" / "centering_image"
    if str(ci_path) not in sys.path and ci_path.is_dir():
        sys.path.insert(0, str(ci_path))

    try:
        from generator import form_tag
        from image_search import CommonsSearch
        tag = form_tag(tag_name)
        # Intention: 24 was the old pixel grid. The model's own grid is the
        # right answer now — see `get_or_load_eye_model`.
        model = get_or_load_eye_model(root_dir, state_dir)

        # Proactive reference learning for video subject
        trained_refs = 0
        ref_path = None
        try:
            from readers import test_searched_image
            search_tag = {"tag_id": "image:" + hashlib.sha256(tag_name.encode()).hexdigest()[:20], "name": tag_name}
            refs = CommonsSearch(timeout=10, limit=2).fetch(search_tag, Path(state_dir) / "images" / "references")
            for ref in refs:
                if "image_path" in ref and Path(ref["image_path"]).is_file():
                    rp = Path(ref["image_path"])
                    if ref_path is None:
                        ref_path = rp
                    trained_refs += _teach_if_passed(model, tag, tag_name, ref, rp, test_searched_image(rp, tag))
            if trained_refs > 0:
                models_dir = Path(state_dir) / "models"
                models_dir.mkdir(parents=True, exist_ok=True)
                model.save(models_dir / IMAGE_CHECKPOINT)
        except Exception as exc:
            noted("warp2/ask/media.py:make_project_video", exc)

        # Intention: the picture the painter makes, flattened, and how many
        # pixels across it is. This read `model.mean(tag)` and `model.side` —
        # both names belonging to the per-pixel model that is gone. The frames
        # are still that picture with a moving wobble over it.
        side = model.longest
        mean = model.paint(tag, side, side).flatten()

        frame_images = []
        seed = int(time.time() * 1000) % (2**31)
        rng = np.random.default_rng(seed)
        base_grid = rng.uniform(0, 255, (12, 12, 3)).astype("float32")

        num_frames = max(4, min(frames, 32))
        for i in range(num_frames):
            angle = 2.0 * np.pi * i / num_frames
            dx = int(np.sin(angle) * 2.5)
            dy = int(np.cos(angle) * 2.5)
            rolled = np.roll(np.roll(base_grid, dx, axis=0), dy, axis=1)
            noise = np.asarray(
                Image.fromarray(rolled.astype("uint8")).resize((side, side), Image.Resampling.BICUBIC),
                dtype=float,
            )
            noise = (noise.flatten() / 255.0 - 0.5) * 2.0
            sample = np.clip(mean + 0.22 * noise, 0, 1)
            raw_frame = Image.fromarray((sample.reshape(side, side, 3) * 255).astype("uint8"))
            frame_images.append(raw_frame.resize((256, 256), Image.Resampling.BICUBIC))

        duration_ms = int(1000 / max(1, fps))
        frame_images[0].save(dest, save_all=True, append_images=frame_images[1:],
                             duration=duration_ms, loop=0)
        return {
            "video_path": str(dest.resolve()),
            "subject": tag_name,
            "reference_path": str(ref_path.resolve()) if ref_path else None,
            "frames": len(frame_images),
            "fps": fps,
            "trained_refs": trained_refs,
            "updates": model.updates,
        }
    except Exception:
        return {}




def search_and_research_subject(root_dir: Path, state_dir: Path, subject: str,
                                sources: list[str] | None = None,
                                limit: int = 4,
                                orientation: str = "any",
                                min_resolution: int = 0,
                                deduplicate: bool = True) -> dict:
    """Perform multi-source image search, visual attribute research, and duplicate filtering.

    User intention (Andrew, 2026-09-08):
    "and we need more options for image search and research."
    "there needs to be a system to look for ducplicates"
    """
    clean = extract_visual_subject(subject)
    ci_path = Path(root_dir) / "projects" / "centering_image"
    if not ci_path.is_dir():
        ci_path = Path(__file__).resolve().parents[2] / "projects" / "centering_image"
    if str(ci_path) not in sys.path and ci_path.is_dir():
        sys.path.insert(0, str(ci_path))

    from image_search import MultiSourceSearch
    from concept_terms import TermExtractor
    from warp2.ask.dedup import ImageDeduplicator

    tag_id = "research:" + hashlib.sha256(clean.encode()).hexdigest()[:16]
    search_tag = {"tag_id": tag_id, "name": clean}
    dest_dir = Path(state_dir) / "images" / "research"
    dest_dir.mkdir(parents=True, exist_ok=True)

    providers = sources or ["commons", "wikipedia", "openverse"]
    local_dirs = [Path(state_dir) / "images", Path(state_dir) / "images" / "references"]
    searcher = MultiSourceSearch(
        providers=providers,
        timeout=15,
        limit=max(1, min(limit, 20)),
        deduplicate=deduplicate,
        orientation=orientation,
        min_resolution=min_resolution,
        local_dirs=local_dirs,
    )

    results = searcher.fetch(search_tag, dest_dir)
    usable_results = [r for r in results if not r.get("error") and r.get("image_path")]

    from readers import test_searched_image
    from concept_terms import extract_all_tags

    # Check for duplicates against existing stored image library and test each with readers
    dedup = ImageDeduplicator(max_distance=5)
    existing_images = list((Path(state_dir) / "images").glob("*.*"))
    tested_results = []
    all_discovered_tags: list[str] = []
    duplicate_count = 0

    for r in usable_results:
        item = dict(r)
        p = Path(r["image_path"])

        # 1. Test searched image with vision readers
        eval_res = test_searched_image(p, search_tag)
        item["reader_score"] = eval_res.get("score", 0.0)
        item["reader_observation"] = eval_res.get("observation", "")
        # Intention (2026-10-09, fix 3.4): nobody able to look is "not judged" —
        # different from a reader looking and refusing it.
        item["reader_verdict"] = ("verified" if eval_res.get("passed") else
                                  "not_judged" if eval_res.get("judged") is False else "unverified")
        item["readers"] = eval_res.get("readers", [])
        item["reader_quality"] = eval_res.get("quality", {})
        item["concept_scores"] = eval_res.get("detected_concepts", {})
        item["concept_tags"] = eval_res.get("concept_tags", [])
        item["attached_datasets"] = eval_res.get("attached_datasets", [])
        item["preemptive_concepts"] = eval_res.get("preemptive_concepts", [])
        # Intention (2026-10-09, fix 3.5, check B11): the found picture is kept
        # in the picture ledger, pending, with the verdict it was just given —
        # so a person's confirm reaches a real row ("saved for training" was
        # said, and nothing was saved).
        try:
            from warp2.ask.visual import VisualLearning
            item["id"] = VisualLearning(root_dir, state_dir).keep_found(clean, p, ref=r, judged=eval_res)["id"]
        except Exception as trouble:
            item["kept_error"] = str(trouble)

        # 2. Extract as many tags as possible from attribution AND reader observations
        tags = eval_res.get("tags") or extract_all_tags(item, subject=clean)
        if eval_res.get("observation"):
            tags.extend(extract_all_tags(eval_res["observation"], subject=clean))
        tags = sorted(set(tags))
        item["tags"] = tags
        all_discovered_tags.extend(tags)

        # 3. Check for duplicates against existing library
        is_dup, match = dedup.is_duplicate(p, [x for x in existing_images if x.resolve() != p.resolve()])
        if is_dup:
            item["is_duplicate"] = True
            item["duplicate_match"] = match
            duplicate_count += 1
        else:
            item["is_duplicate"] = False

        # 4. Save metadata with tags alongside image
        try:
            meta_path = p.with_suffix(".source.json")
            meta_path.write_text(json.dumps(item, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            noted("warp2/ask/media.py:search_and_research_subject", exc)

        tested_results.append(item)

    all_discovered_tags = sorted(set(all_discovered_tags))
    return {
        "subject": clean,
        "providers_used": providers,
        "total_found": len(usable_results),
        "results": tested_results,
        "duplicates_in_results": duplicate_count,
        "concepts_discovered": all_discovered_tags[:24],
        "all_tags": all_discovered_tags,
        "total_tags_extracted": len(all_discovered_tags),
        "destination": str(dest_dir.resolve()),
    }

