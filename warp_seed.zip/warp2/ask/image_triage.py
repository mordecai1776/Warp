# WARP2/warp2/ask/image_triage.py
# Pathway   : WARP2/warp2/ask/image_triage.py
# Used by   : ask/window.py, run.py, ask/visual.py.
# Uses      : PIL, training_blocks, util.
# Description: Automated triage and hypothesis engine for uncertain ("I don't know") images.
# User intention (Andrew, 2026-09-17):
#   "there needs to be a I dont know button for the images. It should also just add to
#   something and not trigger a training at the moment I click the buttons. There also
#   needs to be something to handel the I dont know images"
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
from warp2.record.swallowed import noted


@dataclass
class UncertainImageEntry:
    """A record of an image marked as uncertain / 'I don't know' awaiting triage."""
    id: str
    path: str
    kind: str = "generated"  # "generated", "reference", "user_upload"
    initial_subject: str = ""
    status: str = "pending_triage"  # "pending_triage", "analyzed", "resolved", "discarded"
    hypotheses: list[dict[str, Any]] = field(default_factory=list)
    reader_scores: dict[str, Any] = field(default_factory=dict)
    features: dict[str, Any] = field(default_factory=dict)
    added_at: float = field(default_factory=time.time)
    resolved_at: float | None = None
    resolved_as: str | None = None
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Intention: the entry as a plain dict, so it can be written as one JSON line."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> UncertainImageEntry:
        """Intention: rebuild an entry from a saved line, skipping keys the entry no longer has."""
        valid_keys = {f for f in cls.__dataclass_fields__}
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered)


class ImageTriageHandler:
    """Manages the lifecycle, automated inspection, and resolution of 'I don't know' images."""

    def __init__(self, state_dir: Path | str) -> None:
        """Intention: set where the uncertain images list lives under state/images; the list is read
        later, on first use.
        """
        self.state_dir = Path(state_dir)
        self.images_dir = self.state_dir / "images"
        self.images_dir.mkdir(parents=True, exist_ok=True)
        self.uncertain_file = self.images_dir / "uncertain.jsonl"
        self._cache: dict[str, UncertainImageEntry] | None = None

    def _load_all(self) -> dict[str, UncertainImageEntry]:
        """Load all uncertain entries from disk."""
        entries: dict[str, UncertainImageEntry] = {}
        if self.uncertain_file.is_file():
            try:
                for line in self.uncertain_file.read_text(encoding="utf-8", errors="replace").splitlines():
                    line = line.strip()
                    if line:
                        try:
                            data = json.loads(line)
                            entry = UncertainImageEntry.from_dict(data)
                            entries[entry.id] = entry
                        except Exception:
                            continue
            except Exception as exc:
                noted("warp2/ask/image_triage.py:ImageTriageHandler._load_all", exc)
        self._cache = entries
        return entries

    def _save_all(self, entries: dict[str, UncertainImageEntry]) -> None:
        """Atomically persist entries back to uncertain.jsonl."""
        tmp = self.uncertain_file.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as stream:
            for entry in entries.values():
                stream.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
        tmp.replace(self.uncertain_file)
        self._cache = entries

    def enqueue_uncertain(
        self,
        path: Path | str,
        initial_subject: str = "",
        kind: str = "generated",
        review_data: dict[str, Any] | None = None,
        notes: str = "",
        reader_scores: dict[str, Any] | None = None,
    ) -> UncertainImageEntry:
        """Enqueue an image marked 'I don't know' without triggering eager training.

        Stores the candidate into state/images/uncertain.jsonl so it can be
        autonomously inspected, disambiguated, and resolved in due course.
        """
        p = Path(path)
        resolved_str = str(p.resolve()) if p.exists() else str(p)
        ident = f"unc_{hashlib.sha256(resolved_str.encode('utf-8')).hexdigest()[:12]}"

        entries = self._load_all()
        if ident in entries:
            entry = entries[ident]
            if initial_subject and not entry.initial_subject:
                entry.initial_subject = initial_subject
            if notes:
                entry.notes = notes
            self._save_all(entries)
            return entry

        scores: dict[str, Any] = {}
        if review_data:
            if "reader_score" in review_data:
                scores["reader_score"] = review_data["reader_score"]
            if "tags" in review_data:
                scores["tags"] = review_data["tags"]
            if "reader_observation" in review_data:
                scores["observation"] = review_data["reader_observation"]
            if "observation" in review_data:
                scores["observation"] = review_data["observation"]
        if reader_scores:
            scores.update(reader_scores)

        entry = UncertainImageEntry(
            id=ident,
            path=resolved_str,
            kind=kind,
            initial_subject=initial_subject,
            status="pending_triage",
            reader_scores=scores,
            notes=notes,
            added_at=time.time(),
        )

        entries[ident] = entry
        self._save_all(entries)
        return entry

    def list_uncertain(self, status: str | None = None) -> list[UncertainImageEntry]:
        """List uncertain images, newest first."""
        entries = self._load_all()
        items = list(entries.values())
        if status:
            items = [item for item in items if item.status == status]
        return sorted(items, key=lambda x: x.added_at, reverse=True)

    def get_uncertain(self, image_id_or_path: str) -> UncertainImageEntry | None:
        """Lookup an uncertain entry by ID or path."""
        entries = self._load_all()
        if image_id_or_path in entries:
            return entries[image_id_or_path]
        for item in entries.values():
            if item.path == image_id_or_path:
                return item
        try:
            res_p = str(Path(image_id_or_path).resolve())
            for item in entries.values():
                if item.path == res_p or Path(item.path).name == Path(image_id_or_path).name:
                    return item
        except Exception:  # Intention: an odd path string that will not resolve is just not a match; None is the right answer.
            pass
        return None

    def analyze_image(
        self,
        entry_or_id: UncertainImageEntry | str,
        root_dir: Path | str | None = None,
    ) -> UncertainImageEntry:
        """Perform multi-perspective analysis on an uncertain image.

        Extracts low-level visual features, analyzes colors/edges, inspects tags,
        and generates ranked concept hypotheses with confidence values.
        """
        entries = self._load_all()
        entry_id = entry_or_id.id if isinstance(entry_or_id, UncertainImageEntry) else entry_or_id
        entry = entries.get(entry_id)
        if not entry:
            entry = self.get_uncertain(entry_id)
        if not entry:
            raise ValueError(f"Uncertain image not found: {entry_id}")

        img_path = Path(entry.path)
        features: dict[str, Any] = {}
        hypotheses: list[dict[str, Any]] = []

        if img_path.is_file():
            try:
                from PIL import Image
                with Image.open(img_path) as img:
                    w, h = img.size
                    aspect = round(w / max(1, h), 2)
                    features["width"] = w
                    features["height"] = h
                    features["aspect_ratio"] = aspect

                    # Sample colors
                    small = img.convert("RGB").resize((16, 16))
                    try:
                        pixels = list(small.getdata())
                    except Exception:
                        pixels = []
                    if pixels:
                        avg_r = sum(p[0] for p in pixels) / len(pixels)
                        avg_g = sum(p[1] for p in pixels) / len(pixels)
                        avg_b = sum(p[2] for p in pixels) / len(pixels)
                        brightness = round((avg_r * 0.299 + avg_g * 0.587 + avg_b * 0.114) / 255.0, 2)
                        features["brightness"] = brightness
                        features["dominant_tint"] = (
                            "warm" if avg_r > avg_b + 20 else ("cool" if avg_b > avg_r + 20 else "neutral")
                        )

                        # Simple edge contrast estimator
                        diffs = []
                        for i in range(len(pixels) - 1):
                            p1, p2 = pixels[i], pixels[i + 1]
                            diffs.append(abs(p1[0] - p2[0]) + abs(p1[1] - p2[1]) + abs(p1[2] - p2[2]))
                        edge_density = round(sum(diffs) / (len(diffs) * 765.0), 3) if diffs else 0.0
                        features["edge_density"] = edge_density
            except Exception as exc:
                features["error"] = str(exc)

        candidates: dict[str, float] = {}

        if entry.initial_subject:
            clean_sub = entry.initial_subject.strip().lower()
            candidates[clean_sub] = 0.65

        tags = entry.reader_scores.get("tags") or []
        for tag in tags:
            tag_str = str(tag).strip().lower()
            if tag_str and len(tag_str) > 2 and tag_str.isalpha():
                candidates[tag_str] = candidates.get(tag_str, 0.4) + 0.15

        obs = entry.reader_scores.get("observation") or ""
        if obs:
            for word in obs.replace(",", " ").replace(".", " ").split():
                clean_w = word.strip().lower()
                if len(clean_w) > 3 and clean_w.isalpha():
                    candidates[clean_w] = candidates.get(clean_w, 0.3) + 0.1

        if not candidates:
            stem = img_path.stem.lower()
            candidates[stem] = 0.5

        sorted_candidates = sorted(candidates.items(), key=lambda x: x[1], reverse=True)[:4]
        for concept, score in sorted_candidates:
            hypotheses.append({
                "concept": concept,
                "confidence": min(0.95, round(score, 2)),
                "rationale": f"Extracted from context & visual cues (score: {score:.2f})"
            })

        entry.features = features
        entry.hypotheses = hypotheses
        entry.status = "analyzed"
        entries[entry.id] = entry
        self._save_all(entries)
        return entry

    def resolve_uncertain(
        self,
        image_id: str,
        resolved_concept: str,
        make_positive: bool = True,
        root_dir: Path | str | None = None,
    ) -> dict[str, Any]:
        """Resolve an uncertain image as a confirmed concept (or negative boundary).

        Decoupled: ingests a UniversalTrainingBlock into the training store for future
        passes rather than executing a blocking training loop right now.
        """
        entries = self._load_all()
        entry = entries.get(image_id)
        if not entry:
            entry = self.get_uncertain(image_id)
        if not entry:
            return {"status": "error", "message": f"Image {image_id} not found"}

        concept = resolved_concept.strip().lower()
        entry.status = "resolved"
        entry.resolved_at = time.time()
        entry.resolved_as = concept

        # Staging into training blocks store without immediate model training
        block_id = ""
        try:
            from warp2.train.training_blocks import TrainingBlockIngestor
            ingestor = TrainingBlockIngestor(self.state_dir)
            block_id = ingestor.ingest_visual(
                subject=concept,
                status="triage_resolved" if make_positive else "triage_negative",
                approved=make_positive,
                rounds=1,
                reference_path=entry.path,
                reader_score=0.85 if make_positive else 0.2,
            )
        except Exception as exc:
            noted("warp2/ask/image_triage.py:ImageTriageHandler.resolve_uncertain", exc)

        self._save_all(entries)
        return {
            "status": "resolved",
            "id": entry.id,
            "resolved_as": concept,
            "make_positive": make_positive,
            "training_block_id": block_id,
        }

    def discard_uncertain(
        self,
        image_id: str,
        reason: str = "discarded_by_user",
        root_dir: Path | str | None = None,
    ) -> dict[str, Any]:
        """Discard an uncertain image, marking it as negative void boundary."""
        entries = self._load_all()
        entry = entries.get(image_id)
        if not entry:
            entry = self.get_uncertain(image_id)
        if not entry:
            return {"status": "error", "message": f"Image {image_id} not found"}

        entry.status = "discarded"
        entry.resolved_at = time.time()
        entry.notes = f"Discarded: {reason}"

        # Ingest as negative boundary
        block_id = ""
        try:
            from warp2.train.training_blocks import TrainingBlockIngestor
            ingestor = TrainingBlockIngestor(self.state_dir)
            block_id = ingestor.ingest_visual(
                subject=entry.initial_subject or "uncertain_void",
                status="triage_discarded",
                approved=False,
                rounds=1,
                reference_path=entry.path,
                reader_score=0.1,
            )
        except Exception as exc:
            noted("warp2/ask/image_triage.py:ImageTriageHandler.discard_uncertain", exc)

        self._save_all(entries)
        return {
            "status": "discarded",
            "id": entry.id,
            "reason": reason,
            "training_block_id": block_id,
        }

    def auto_triage_pending(self, limit: int = 2, root_dir: Path | str | None = None) -> list[dict[str, Any]]:
        """Autonomously analyze pending uncertain images in the background."""
        pending = self.list_uncertain(status="pending_triage")
        results = []
        for item in pending[:limit]:
            try:
                analyzed = self.analyze_image(item, root_dir=root_dir)
                results.append({
                    "id": analyzed.id,
                    "subject": analyzed.initial_subject,
                    "top_hypothesis": analyzed.hypotheses[0] if analyzed.hypotheses else None,
                })
            except Exception as exc:
                results.append({"id": item.id, "error": str(exc)})
        return results
