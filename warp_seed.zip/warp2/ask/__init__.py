# WARP2/warp2/ask/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/__init__.py
#  Used by   : warp2/work/loop.py, warp2/run.py.
#  Uses      : nothing. A package marker holds no logic.
#  Description:
#    The user action centre: where a person asks the warp for something, and
#    where what they asked for is turned into things the warp already knows.
#  User intention (Andrew, 2026-09-07):
#    "The user action center. Where I can ask for an image to be made or a
#    project to be started or comment on one and have changes made. I should
#    also be able to drop in files or images to it. It should be a friendly
#    user interface." And: "the old interface should stay, this should be new
#    and take the parts out of the old that were user input."
#  Shape (his choices, asked and answered 2026-09-07):
#    A Tk window now and a web page later, so neither one owns the asking — the
#    inbox and the taking are here, and a window is only a way to reach them.
#    A request goes into an INBOX THE LOOP READS, never into the store from the
#    window, so there is still one writer to the fact lane.
# ============================================================================
