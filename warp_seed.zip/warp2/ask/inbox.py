# WARP2/warp2/ask/inbox.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/inbox.py
#  Used by   : warp2/ask/window.py (a person puts things in),
#              warp2/ask/taking.py (the loop takes them out).
#  Uses      : warp2/util.py (atomic_write_bytes, now_iso, sha256_hex);
#              stdlib json, pathlib, shutil.
#  Description:
#    What a person asked for, kept on disk until something has done it. One
#    small file per request, written whole, and a file beside it that says how
#    it was handled.
#  User intention (Andrew, 2026-09-07):
#    Asked where a request should go, he chose an inbox the loop reads rather
#    than the window writing to the store. So the window can be closed, or
#    crash, or be replaced by a web page, and nothing that was asked for is
#    lost — and the fact lane still has one writer.
#  Principles: Clean — a request is written whole or not at all, and how it was
#    handled is written beside it rather than over it. Adaptive — the shape
#    borrows from the one this tree already proved: `projects/centering_image/
#    spaces.py` has run an inbox exactly like this since 2026-09-06.
# ============================================================================
from __future__ import annotations

import json
import shutil
from pathlib import Path

from warp2.util import atomic_write_bytes, ensure_dir, now_iso, sha256_hex

# Where the inbox lives under the state folder.
ASKED = "asked"

# What a person can ask for. Intention: a small closed list, because a request
# nothing knows how to take is a request that sits there looking answered. Each
# one is named for what the PERSON is doing, not for what the machine will do
# with it — that mapping is `taking.py`'s job and may change without this list
# changing.
IMAGE = "image"        # make me a picture of this
VIDEO = "video"        # make me a video clip of this
PROJECT = "project"    # start something new
COMMENT = "comment"    # here is what I think about this thing; change it
FILE = "file"          # here is a file, it belongs with this
FEEDBACK = "feedback"  # this picture was right (or wrong); learn from it
REDO = "redo"          # this task is not done; do it again (2026-10-09, check G5)
RESEARCH = "research"  # search for pictures of this and have the readers look (2026-10-09, check B10)
KINDS = (IMAGE, VIDEO, PROJECT, COMMENT, FILE, FEEDBACK, REDO, RESEARCH)


class Inbox:
    """What has been asked for, and what became of it.

    Intention: THE WINDOW IS NOT THE RECORD. A person types something and shuts
    the laptop; the asking has to outlive the window it was typed into, and it
    has to be readable by a loop that starts hours later knowing nothing.
    """

    def __init__(self, state) -> None:
        """Intention: make sure the asked folder and its files folder exist, so an ask can be kept
        before any window reads it.
        """
        self.home = ensure_dir(Path(state) / ASKED)
        self.files = ensure_dir(self.home / "files")

    # -- putting things in ---------------------------------------------------

    # Intention: the id carries the time it was asked, so the inbox reads in
    # order on any filesystem without anything having to sort by mtime — which
    # OneDrive rewrites. A refused kind raises rather than being stored, because
    # a request nothing can take is worse than no request.
    def put(self, kind: str, said: str = "", about: str = "",
            **more) -> dict:
        """Write down one thing a person asked for."""
        if kind not in KINDS:
            raise ValueError(f"nothing knows how to take a {kind!r} request; "
                             f"the kinds are {', '.join(KINDS)}")
        at = now_iso()
        body = {"kind": str(kind), "said": str(said), "about": str(about),
                "asked_at": at}
        body.update({name: value for name, value in more.items()
                     if value not in (None, "")})
        who = sha256_hex(json.dumps(body, sort_keys=True).encode("utf-8"))[:10]
        body["id"] = f"{at.replace(':', '').replace('-', '')[:15]}-{who}"
        # Intention: THE SAME ASK TWICE IN ONE CLOCK TICK IS TWO ASKS (found
        # 2026-10-08 on Windows, where the clock moves in steps of about 16 ms):
        # two identical asks got the same id and the second overwrote the
        # first. A taken name gets a counter, so nothing a person asked is lost.
        base, count = body["id"], 1
        while (self.home / f"{body['id']}.json").exists():
            count += 1
            body["id"] = f"{base}-{count}"
        atomic_write_bytes(self.home / f"{body['id']}.json",
                           json.dumps(body, ensure_ascii=False, indent=2).encode("utf-8"))
        return body

    # Intention: A DROPPED FILE IS COPIED, NOT POINTED AT. The thing a person
    # dragged in may be on a stick, in a downloads folder they empty, or in a
    # sync folder that moves it. What was asked about has to still be there when
    # the loop gets to it, so the bytes come in and the copy is named by what it
    # holds rather than by what it was called.
    def put_file(self, path, said: str = "", about: str = "") -> dict:
        """Take a copy of a file a person dropped in, and ask about it."""
        source = Path(path)
        body = source.read_bytes()
        digest = sha256_hex(body)
        kept = self.files / f"{digest[:16]}{source.suffix.lower()}"
        if not kept.exists():
            shutil.copyfile(source, kept)
        return self.put(FILE, said=said, about=about, name=source.name,
                        kept=str(kept.relative_to(self.home.parent).as_posix()),
                        digest=digest, bytes=len(body))

    # -- taking them out -----------------------------------------------------

    # Intention: waiting means nothing has said what became of it. Decided by
    # whether the answer file is there, not by a flag inside the request — a
    # request is never rewritten after it is written, so what a person asked for
    # cannot be edited by the thing that answers it.
    def waiting(self) -> list:
        """Everything asked for that nothing has handled yet, oldest first."""
        out = []
        for path in sorted(self.home.glob("*.json")):
            if path.name == "waiting.json" or path.with_suffix(".answer").exists():
                continue
            body = _read(path)
            if body:
                out.append(body)
        return out

    # Intention: how it was handled, written beside the request and never over
    # it. A person can read what they asked for and what happened, side by side,
    # a week later.
    def handled(self, request: str, how: str, made: str = "") -> dict:
        """Say what became of one request."""
        answer = {"id": str(request), "how": str(how), "made": str(made),
                  "at": now_iso()}
        atomic_write_bytes(self.home / f"{request}.answer",
                           json.dumps(answer, ensure_ascii=False, indent=2).encode("utf-8"))
        return answer

    # Intention: what the window shows — everything asked, newest first, each
    # with its answer if it has one. One read of a small folder, because this is
    # on a timer in front of a person.
    def recent(self, limit: int = 40) -> list:
        """The last things asked for, newest first, with what became of them."""
        out = []
        for path in sorted(self.home.glob("*.json"), reverse=True)[:int(limit)]:
            if path.name == "waiting.json":
                continue
            body = _read(path)
            if not body:
                continue
            body["answer"] = _read(path.with_suffix(".answer"))
            out.append(body)
        return out


# Intention: a half-written or hand-edited file is skipped, not raised on. This
# folder is in front of a person, and a person will one day open one of these
# in an editor.
def _read(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
