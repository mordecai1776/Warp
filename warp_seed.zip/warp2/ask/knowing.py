# WARP2/warp2/ask/knowing.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/knowing.py
#  Used by   : warp2/ask/talk.py, which answers out of this before it asks a
#              model anything.
#  Uses      : warp2/store/projects.py, warp2/store/store.py (read only),
#              warp2/work/queue.py.
#  Description:
#    What this machine can say about its own work without asking anybody. What
#    projects there are, what is built, what is open, what a thing is for and
#    what was last said about it.
#  User intention (Andrew, 2026-09-07):
#    Asked who should answer when he talks to it, he chose the store first and a
#    model on top: "facts answer the questions facts can answer, so it is never
#    wrong about your own work and never needs a model to be running."
#  Principles: Clean — reads, never writes. Adaptive — everything here is a
#    question the store already answers; nothing is cached, so nothing goes
#    stale.
# ============================================================================
from __future__ import annotations

import re
from warp2.record.swallowed import noted


class Knowing:
    """What the machine knows about its own work.

    Intention: THE PART THAT CANNOT BE WRONG. A model talking about his projects
    from memory will one day tell him a thing is built when it is not. Every
    number here comes from the store or the disk at the moment it is asked.
    """

    def __init__(self, store, projects, queue=None, state=None) -> None:
        """Intention: hold the store, the projects, the work queue and the state folder that every
        answer is read from.
        """
        from pathlib import Path
        self.store = store
        self.projects = projects
        self.queue = queue
        self.state = Path(state) if state is not None else getattr(store, "state", None)

    # Intention: what a person opening the window should see before typing —
    # the shape of everything, small enough to read at a glance.
    def overview(self) -> dict:
        """Every project, what is built, and what is waiting."""
        rows = []
        for name in self.projects.names():
            standing = self.projects.state(name)
            rows.append({"name": name, "areas": standing["areas"],
                         "built": standing["built"],
                         "intention": standing["intention"]})
        open_work = len(self.queue.open_items()) if self.queue else 0
        return {"projects": rows, "open_work": open_work}

    # Intention: THE THING HE IS TALKING ABOUT, found the way a person names it
    # — by a word, not by a subject id. A project by any of its names, or a file
    # by the end of its path, because nobody types the whole path.
    def find(self, words: str) -> str:
        """The subject a person most likely means, or ""."""
        wanted = str(words or "").strip().lower()
        if not wanted:
            return ""
        # Intention: HE CALLS IT WHAT HE CALLS IT. Matching only the whole name
        # meant "what about the eye" found nothing, while `BEHEMOTH_EYE` sat
        # right there — nobody types a project's full name in a sentence. Whole
        # name first, so an exact mention always wins, then any distinctive word
        # of it. Two letters is not distinctive, so short words are skipped.
        parts = []
        for name in self.projects.names():
            slug = self.projects.home(name).name
            if name.lower() in wanted or slug in wanted or slug.replace("_", " ") in wanted:
                return f"project:{slug}"
            parts.append((slug, [word for word in slug.split("_") if len(word) > 2]))
        for slug, words in parts:
            if any(re.search(rf"\b{re.escape(word)}\b", wanted) for word in words):
                return f"project:{slug}"
        best = ""
        for fact in self.store.current(attr="user_intention"):
            subject = str(fact["subject"])
            tail = subject.rsplit("/", 1)[-1].lower()
            if len(tail) > 3 and tail in wanted and len(subject) > len(best):
                best = subject
        return best

    # Intention: everything true of one thing, in the shape a person asks about
    # it. A project is its areas and how far along they are; anything else is
    # what it is for and what was last said about it.
    def about(self, subject: str) -> dict:
        """What is true of one thing right now."""
        subject = str(subject or "")
        if not subject:
            return {}
        if subject.startswith("project:"):
            name = self._named(subject)
            if not name:
                return {}
            standing = self.projects.state(name)
            return {"kind": "project", "subject": subject, "name": name,
                    "intention": standing["intention"],
                    "areas": self.projects.areas(name),
                    "built": standing["built"], "of": standing["areas"]}
        return {"kind": "thing", "subject": subject,
                "intention": self._text(subject, "user_intention"),
                "said": self._text(subject, "user_said"),
                "status": self._text(subject, "status")}

    # Intention: the answer in words, or "" meaning the facts have nothing to
    # say about this and a model may speak instead. Saying "" honestly is what
    # keeps the machine from answering a question it cannot answer.
    def say(self, asked: str) -> str:
        """A plain answer built from facts, or "" if the facts do not have one."""
        clean = str(asked or "").strip().lower()
        if not clean:
            return ""

        # General status query
        if any(w in clean for w in ("how are you doing", "how is the warp doing", "how is the program doing", "is the warp running", "warp status", "what are you doing")):
            try:
                from warp2.ask.doing import Doing
                from pathlib import Path
                st_path = getattr(self.store, "state", None)
                home = Path(st_path).parent if st_path else Path("state")
                return Doing(home).says()
            except Exception as exc:
                noted("warp2/ask/knowing.py:Knowing.say", exc)

        # General projects query
        if any(p in clean for p in ("what projects", "list projects", "all projects", "which projects", "show projects", "what are the projects")):
            names = self.projects.names()
            if names:
                lines = [f"There are {len(names)} active projects:"]
                for name in names:
                    st = self.projects.state(name)
                    intent_part = f" — {st['intention']}" if st.get("intention") else ""
                    lines.append(f"  • {name} ({st['built']}/{st['areas']} parts built){intent_part}")
                return "\n".join(lines)

        # General capabilities query
        if any(c in clean for c in ("what can you do", "capabilities", "what do you do", "help me with", "what are your features")):
            lines = [
                "Here is what the WARP system can do:",
                "  • Play & Create Retro Games: Play or test games like Pac-Man, Frogger, Sokoban, Asteroids, Rogue with real-time controls and control legend in the Game Arena.",
                "  • Image & Video Generation: Generate project media and reference visuals (e.g., type 'make an image of a sunset').",
                "  • Code & Algorithms: Synthesize and prove algorithmic recipes against the formal Gate.",
                "  • Logic & Proofs: Prove reasoning rules and discover automated formal proofs for project components.",
                "  • Model Fleet Diagnostics: Benchmark Ollama and fleet models against syntax and logic test tasks.",
                "  • Project Development: Build, test, and prove components across all 14 active projects.",
            ]
            return "\n".join(lines)

        # System Map / Flowchart query
        if any(m in clean for m in ("system map", "flowchart", "raptor map", "architecture map", "show map", "show flowchart")):
            return (
                "WARP2 RAPTOR System Map:\n"
                "The system map lays out the continuous engine as an authentic RAPTOR flowchart:\n"
                "  • (●) Start Terminal: Pass loop initialization\n"
                "  • [/] Input Block: Visual concept & user asks ingestion\n"
                "  • [■] Stages 1-5: Visual Learning, Eye Games, Code, Logic, and Fleet Model Analysis\n"
                "  • [||] Stage 6 Subroutine: Project Engine building 14 open project areas\n"
                "  • [◇] Decision Gate: Gatekeeper compliance & proof checks\n"
                "  • [■] Stages 7-8: Eye/Master Co-Training & Universal Training Web\n"
                "  • [/] Output Block: Published verified receipts to fact lane\n"
                "  • [◇] Loop Decision: Check ALL_STOP flag -> Loop next pass or halt\n\n"
                "View the visual interactive flowchart in the Cockpit Observer under the 'System Map' tab (`python -m warp2.run cockpit`)."
            )

        # Web findings / latest research query
        if any(w in clean for w in ("what did you find on the web", "what did you learn from the web", "what have you learned", "latest research", "web findings", "what are you researching", "show research", "what did the web find", "research findings")):
            recent = self.latest_findings(limit=3)
            if recent:
                lines = ["Here is what continuous web research has discovered recently:"]
                for item in recent:
                    q_str = f"• Q: \"{item['question']}\"" if item.get("question") else "• Finding:"
                    lines.append(q_str)
                    lines.append(f"  {item['summary']}")
                    if item.get("sources"):
                        lines.append(f"  Sources: {', '.join(item['sources'][:2])}")
                return "\n\n".join(lines)
            return "The web runner is actively exploring the frontier, but hasn't finalized findings for this sitting yet."

        # Explicit web search request
        search_match = re.search(r"(?:search\s+(?:the\s+)?web\s+for|look\s+up\s+(?:on\s+(?:the\s+)?web|online)\s+for|research\s+(?:on\s+(?:the\s+)?web\s+for|online\s+for|about)?)\s+(.+)", clean, re.I)
        if search_match:
            term = search_match.group(1).strip()
            web_res = self.research_on_web(term)
            if web_res.get("found"):
                lines = [f"[Web Research] '{term}':", web_res["summary"]]
                if web_res.get("sources"):
                    lines.append("Sources:\n" + "\n".join(f"  • {src}" for src in web_res["sources"]))
                return "\n\n".join(lines)

        subject = self.find(asked)
        if subject:
            known = self.about(subject)
            if known.get("kind") == "project":
                lines = [f"{known['name']}: {known['built']} of {known['of']} parts built."]
                if known["intention"]:
                    lines.append(f"It is for: {known['intention']}")
                waiting = [row["name"] for row in known["areas"] if not row["built"]]
                if waiting:
                    lines.append("Not built yet: " + ", ".join(waiting) + ".")
                return "\n".join(lines)
            if any(known.get(key) for key in ("intention", "said", "status")):
                lines = [f"{known['subject']}:"]
                if known["intention"]:
                    lines.append(f"  it is for: {known['intention']}")
                if known["said"]:
                    lines.append(f"  you last said: {known['said']}")
                if known["status"]:
                    lines.append(f"  status: {known['status']}")
                return "\n".join(lines)

        # Knowledge Graph & Research Search for conceptual / topical questions
        is_knowledge_query = (
            any(clean.startswith(q_p) for q_p in (
                "what is ", "what are ", "explain ", "tell me about ", "how does ", "how do ",
                "who is ", "where is ", "why ", "define ", "describe ", "what do you know about "
            ))
            or clean.endswith("?")
            or any(t in clean for t in ("concept", "research", "finding", "paper", "algorithm", "theory", "method", "model", "neural", "network"))
        )
        not_mentioned = any(neg in clean for neg in ("nobody mentioned", "nothing mentioned", "not mentioned", "nobody said"))

        if is_knowledge_query and not not_mentioned:
            concepts = self.search_concepts(asked, limit=2)
            research = self.search_research(asked, limit=2)
            if concepts or research:
                lines = ["From the WARP Knowledge Graph & Research:"]
                for c in concepts:
                    lines.append(f"[Concept] {c['name']}:\n   {c['definition']}")
                for r in research:
                    q_text = f" (re: {r['question']})" if r.get('question') else ""
                    src_text = f"\n   Sources: {', '.join(r['sources'][:2])}" if r.get('sources') else ""
                    lines.append(f"[Finding]{q_text}:\n   {r['summary']}{src_text}")
                return "\n\n".join(lines)

            # If it's a direct factual question and not in KG, try live web research
            if any(clean.startswith(q_prefix) for q_prefix in ("what is ", "what are ", "explain ", "tell me about ", "how does ", "who is ", "where is ")) and len(clean.split()) >= 3:
                web_res = self.research_on_web(asked)
                if web_res.get("found"):
                    lines = [f"[Web Research] '{asked}':", web_res["summary"]]
                    if web_res.get("sources"):
                        lines.append("Sources:\n" + "\n".join(f"  * {src}" for src in web_res["sources"][:3]))
                    return "\n\n".join(lines)

        return ""

    def _db(self):
        """Safe access to the projection SQLite db if present."""
        view = getattr(self.store, "view", None)
        return getattr(view, "db", None) if view else None

    def search_research(self, query: str, limit: int = 3) -> list:
        """Search stored findings from web research matching terms."""
        db = self._db()
        if db is None:
            return []
        STOPWORDS = {
            "what", "is", "the", "how", "tell", "about", "for", "and", "can",
            "you", "are", "does", "did", "from", "with", "this", "that", "there",
            "which", "who", "whom", "whose", "why", "when", "where", "have", "has",
            "had", "been", "being", "were", "was", "will", "would", "shall", "should",
            "may", "might", "must", "could", "all", "any", "some", "someone", "something",
            "nobody", "nothing", "anyone", "anything", "mention", "mentioned", "thing",
            "things", "please", "help", "know", "said", "say", "well", "like"
        }
        words = [w for w in re.findall(r"\w+", str(query or "").lower())
                 if len(w) >= 3 and w not in STOPWORDS]
        if not words:
            return []
        try:
            conds = " OR ".join(["f.value LIKE ?" for _ in words])
            params = [f"%{w}%" for w in words]
            sql = f"""
                SELECT DISTINCT f.subject, f.attr, f.value
                FROM fact f
                WHERE f.valid_to IS NULL
                  AND f.subject LIKE 'finding:%'
                  AND f.attr IN ('summary', 'question')
                  AND ({conds})
                LIMIT 15
            """
            rows = db.execute(sql, params).fetchall()
            findings_map = {}
            for r in rows:
                subj = r["subject"]
                findings_map.setdefault(subj, {})[r["attr"]] = r["value"]

            out = []
            for fid, data in list(findings_map.items())[:limit]:
                src_rows = db.execute(
                    "SELECT subject FROM fact WHERE valid_to IS NULL AND relation = 'supports' AND object = ? LIMIT 5",
                    (fid,)
                ).fetchall()
                sources = [dict(sr)["subject"] for sr in src_rows if dict(sr).get("subject")]
                out.append({
                    "finding": fid,
                    "question": data.get("question", ""),
                    "summary": data.get("summary", ""),
                    "sources": sources,
                })
            return out
        except Exception:
            return []

    def search_concepts(self, query: str, limit: int = 3) -> list:
        """Search defined concepts in the Knowledge Graph matching terms."""
        db = self._db()
        if db is None:
            return []
        import re
        STOPWORDS = {
            "what", "is", "the", "how", "tell", "about", "for", "and", "can",
            "you", "are", "does", "did", "from", "with", "this", "that", "there",
            "which", "who", "whom", "whose", "why", "when", "where", "have", "has",
            "had", "been", "being", "were", "was", "will", "would", "shall", "should",
            "may", "might", "must", "could", "all", "any", "some", "someone", "something",
            "nobody", "nothing", "anyone", "anything", "mention", "mentioned", "thing",
            "things", "please", "help", "know", "said", "say", "well", "like"
        }
        words = [w for w in re.findall(r"\w+", str(query or "").lower())
                 if len(w) >= 3 and w not in STOPWORDS]
        if not words:
            return []
        try:
            conds = " OR ".join(["f.value LIKE ?" for _ in words])
            params = [f"%{w}%" for w in words]
            sql = f"""
                SELECT DISTINCT f.subject
                FROM fact f
                WHERE f.valid_to IS NULL
                  AND f.subject LIKE 'concept:%'
                  AND f.attr IN ('definition', 'name')
                  AND ({conds})
                LIMIT 10
            """
            rows = db.execute(sql, params).fetchall()
            out = []
            seen = set()
            for r in rows:
                cid = r["subject"]
                if cid in seen:
                    continue
                seen.add(cid)
                defn_row = db.execute(
                    "SELECT value FROM fact WHERE valid_to IS NULL AND subject = ? AND attr = 'definition' LIMIT 1",
                    (cid,)
                ).fetchone()
                name_row = db.execute(
                    "SELECT value FROM fact WHERE valid_to IS NULL AND subject = ? AND attr = 'name' LIMIT 1",
                    (cid,)
                ).fetchone()
                defn = dict(defn_row)["value"] if defn_row else ""
                name = dict(name_row)["value"] if name_row else cid.replace("concept:", "").replace("_", " ").title()
                if defn or name:
                    out.append({"concept": cid, "name": name, "definition": defn})
                if len(out) >= limit:
                    break
            return out
        except Exception:
            return []

    def latest_findings(self, limit: int = 4) -> list:
        """Return the most recent web research findings from the store."""
        db = self._db()
        if db is None:
            return []
        try:
            rows = db.execute(
                """
                SELECT DISTINCT f.subject
                FROM fact f
                WHERE f.valid_to IS NULL AND f.subject LIKE 'finding:%' AND f.attr = 'summary'
                ORDER BY f.rowid DESC
                LIMIT ?
                """,
                (limit,)
            ).fetchall()
            out = []
            for r in rows:
                fid = r["subject"]
                q_row = db.execute("SELECT value FROM fact WHERE valid_to IS NULL AND subject = ? AND attr = 'question' LIMIT 1", (fid,)).fetchone()
                s_row = db.execute("SELECT value FROM fact WHERE valid_to IS NULL AND subject = ? AND attr = 'summary' LIMIT 1", (fid,)).fetchone()
                src_rows = db.execute("SELECT subject FROM fact WHERE valid_to IS NULL AND relation = 'supports' AND object = ? LIMIT 3", (fid,)).fetchall()
                q = dict(q_row)["value"] if q_row else ""
                s = dict(s_row)["value"] if s_row else ""
                srcs = [dict(sr)["subject"] for sr in src_rows if dict(sr).get("subject")]
                if s:
                    out.append({"finding": fid, "question": q, "summary": s, "sources": srcs})
            return out
        except Exception:
            return []

    def research_on_web(self, query: str, max_sources: int = 3) -> dict:
        """Query live academic and web sources, and record the need in the Knowledge Graph."""
        import re
        q = str(query or "").strip()
        if not q or len(q.split()) < 2:
            return {"found": False}
        try:
            from warp2.research.sources import gather
            from warp2.research.need import Needs
            try:
                Needs(self.store).raise_need(about="chat", question=q, seed="user_asked_in_chat")
            except Exception as exc:
                noted("warp2/ask/knowing.py:Knowing.research_on_web", exc)
            results = gather(q, most=max_sources, seconds=5.0)
            if not results:
                return {"found": False}
            texts = [str(r.get("text") or "").strip() for r in results if r.get("text")]
            urls = [str(r.get("url") or "") for r in results if r.get("url")]
            if not texts:
                return {"found": False}
            summary = texts[0][:500]
            if len(texts[0]) > 500:
                summary += "..."
            return {"found": True, "question": q, "summary": summary, "sources": urls}
        except Exception:
            return {"found": False}

    def _named(self, subject: str) -> str:
        """Intention: the project name whose home folder matches this subject, or "" when none does."""
        slug = subject.split(":", 1)[-1]
        for name in self.projects.names():
            if self.projects.home(name).name == slug:
                return name
        return ""

    def _text(self, subject: str, attr: str) -> str:
        """Intention: the current value of one attribute of a subject from the store, as text, or "" when unset."""
        found = self.store.current(subject=subject, attr=attr)
        return str(found[0]["value"]) if found else ""

