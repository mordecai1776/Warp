# WARP2/warp2/ask/subconcepts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/subconcepts.py
#  Used by   : warp2/ask/picture_round.py (the `parts` part of a picture round).
#  Uses      : models.json (the roster: which local Ollama models are on);
#              warp2/ask/parts.py (NOT_A_PART, FUNCTION_WORDS); warp2/util.py
#              (atomic_write_bytes); warp2/room/ollama_room.py (room made for
#              the model first - BUILD_LOG 1481); (stdlib) json, re, time,
#              urllib, pathlib.
#  Description:
#    The models GUESS at the sub-concepts inside a concept: its types (kinds
#    of cat) and its parts (feet, paw, paw pads, claws), and the parts of
#    those parts. A small local LLM is asked plain "what is it" questions; its
#    answer is read into short names. Every guess is kept, with which model
#    said it and when. A guess is then TRIED by the picture round: added as a
#    trainable concept, given data, trained. A guess that does not work is a
#    normal outcome — it stays on the record as tried.
#  User intention (Andrew, muse-476, 2026-10-23 ~23:31 CDT): "number one is the
#    ability for the models to sit there and guess at sub-concepts that might
#    be in the original concept, like oh types of cats ... and the parts of
#    said concept ... the feet the paw the paw pads the claws all these things
#    should be able to be refined from a simple LLM giving just random
#    statements just what is it questions and even if they don't work the
#    system itself should be in a state to where oh well we tried adding that
#    in and we tried training on that". BUILD_LOG 584.
#    2026-11-09 17:45: "adapt this to ... all of the models with a splitting the
#    way air llm does" - the model is loaded only when the room has space for
#    it, and kept after only while it still has (BUILD_LOG 1481).
#    18:49: "use only internal models" - with "internal_only" in models.json
#    the WARP's own models are asked, each in its own child (BUILD_LOG 1483),
#    or through the WARP's own model house (BUILD_LOG 1484).
# ============================================================================
"""Guessing a concept's types and parts with a small local LLM, kept and tried."""
from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from pathlib import Path


# Intention: how long one question may take. These are one-line answers from
# small models; a model that is not done in this time is not answering.
ASK_SECONDS = 60.0

# Intention: the small models first (Andrew: "a simple LLM"). Names not on the
# roster, or switched off there, are skipped.
PREFERRED = ("qwen3-1.7b", "qwen2.5-coder-1.5b-instruct", "llama3.2:3b", "gemma2:2b", "qwen3:1.7b", "phi4-mini:latest",
             "qwen3:4b")

OLLAMA_CHAT = "http://127.0.0.1:11434/api/chat"

_THINKING = re.compile(r"<think>.*?</think>", re.IGNORECASE | re.DOTALL)
_BULLET = re.compile(r"^\s*(?:[-*•]+|\d+[.):]|[a-z][.)])\s*", re.IGNORECASE)


class Questions:
    """The plain "what is it" questions, one per kind of guess."""

    @staticmethod
    def types(concept: str) -> str:
        """Intention: the kinds a concept breaks into (types of cats)."""
        return (f"Name the different kinds or types of {concept}. "
                f"Answer with only a list, one short name per line, no explanations.")

    @staticmethod
    def parts(concept: str) -> str:
        """Intention: the visible parts a concept is made of (paw, claws)."""
        return (f"Name the visible parts of a {concept} that you could point to in a picture. "
                f"Answer with only a list, one short name per line, no explanations.")


class AnswerNames:
    """Reads a model's answer into short, clean names."""

    def __init__(self) -> None:
        """Intention: the words that are never a sub-concept, from the parts reader."""
        from warp2.ask.parts import FUNCTION_WORDS, NOT_A_PART
        self.never = set(NOT_A_PART) | set(FUNCTION_WORDS)

    def read(self, text: str, concept: str) -> list:
        """Intention: every name of one to four words the answer gives, not the concept itself - no cap on how many
        (Andrew, 2026-11-05 19:11: "There should never be a hard cap anywhere ever")."""
        text = _THINKING.sub(" ", str(text or ""))
        pieces = []
        for line in text.splitlines():
            pieces.extend(part for part in re.split(r"[,;]", line))
        names, own = [], " ".join(concept.lower().split())
        for piece in pieces:
            name = _BULLET.sub("", piece).split(":")[0].split("(")[0]
            name = re.sub(r"[^a-z0-9' -]", " ", name.lower())
            name = " ".join(word for word in name.split() if word)
            words = name.split()
            if not words or len(words) > 4 or len(name) < 3:
                continue
            if name == own or all(word in self.never for word in words):
                continue
            if name not in names:
                names.append(name)
        return names


class LocalAsker:
    """Asks one local model one question; the models come from the roster.

    Intention (BUILD_LOG 1483): with "internal_only" in models.json, the models asked are the WARP's own (direct),
    each answering in its own watched child that loads it to fit the room (warp2/models/roster.py _isolated); Ollama
    is asked only when the roster allows outside models.
    """

    def __init__(self, root, opener=None, inside=None) -> None:
        """Intention: `opener` is urllib's by default; tests give their own, and `inside` how an internal model is asked."""
        self.root = Path(root)
        self.opener = opener or urllib.request.urlopen
        self.inside = inside or (lambda entry, prompt: _ask_inside(entry, prompt, self.root))
        self.entries: dict = {}

    def models(self) -> list:
        """Intention: the switched-on practice models - internal ones only when the roster says so - the small
        preferred ones first."""
        from warp2.models.internal import internal_only
        try:
            written = json.loads((self.root / "models.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        own = internal_only(self.root)
        entries = written.get("models") if isinstance(written, dict) else written
        on = {}
        for entry in entries or ():
            if not isinstance(entry, dict) or entry.get("enabled") is False:
                continue
            if "practice" not in (entry.get("kinds") or ()):
                continue
            how = str(entry.get("how"))
            name = str(entry.get("name") or "")
            if own and how in ("direct", "transformers", "local", "house") and entry.get("path"):
                self.entries[name] = entry
                on[name] = name
            elif not own and how == "ollama":
                on[name] = str(entry.get("ollama_model") or name)
        first = [on[name] for name in PREFERRED if name in on]
        return first + [served for name, served in on.items() if served not in first]

    def ask(self, model: str, prompt: str) -> str:
        """Intention: the model's reply text, or "" when it could not answer."""
        if model in self.entries:
            return self.inside(self.entries[model], prompt)
        from warp2.room.ollama_room import OllamaRoom
        keep = OllamaRoom().make_room_for(model)["keep_alive"]
        body = json.dumps({"model": model, "stream": False, **({} if keep is None else {"keep_alive": keep}),
                           "messages": [{"role": "user", "content": prompt}]}).encode("utf-8")
        request = urllib.request.Request(OLLAMA_CHAT, data=body, headers={"Content-Type": "application/json"})
        try:
            with self.opener(request, timeout=ASK_SECONDS) as answer:
                payload = json.loads(answer.read().decode("utf-8", "replace"))
        except (urllib.error.URLError, OSError, TimeoutError, ValueError):
            return ""
        return str(((payload or {}).get("message") or {}).get("content") or "")


def _ask_inside(entry: dict, prompt: str, root=None) -> str:
    """Intention: one internal model's answer - from the house (BUILD_LOG 1484) or its own watched child; "" when it
    could not answer."""
    try:
        if str(entry.get("how")) == "house":
            from warp2.house.client import HouseClient
            root = Path(root) if root is not None else Path(__file__).resolve().parents[2]
            return HouseClient(root, root / "state").chat(str(entry.get("name") or ""), prompt,
                                                          int(entry.get("max_tokens") or 0))
        from warp2.models.roster import _isolated
        return str(_isolated(entry, str(entry.get("name") or ""), None)(prompt) or "")
    except Exception:  # fault: ok - a model that cannot answer gives no guess; the round goes on to the next model
        return ""


class GuessBook:
    """Every guess kept on disk: what was asked, who said what, and what was tried."""

    def __init__(self, state) -> None:
        """Intention: one file per state folder, beside the taxonomy."""
        self.path = Path(state) / "visual_learning" / "subconcept_guesses.json"
        self.data = self._load()

    def _load(self) -> dict:
        """Intention: the kept guesses, or an empty book."""
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def save(self) -> None:
        """Intention: written whole or not at all."""
        from warp2.util import atomic_write_bytes
        atomic_write_bytes(self.path, json.dumps(self.data, indent=1, ensure_ascii=False).encode("utf-8"))

    def entry(self, concept: str) -> dict:
        """Intention: one concept's page — its types, its parts, the answers behind them, what was tried."""
        key = " ".join(concept.lower().split())
        page = self.data.setdefault(key, {})
        for field, empty in (("types", []), ("parts", []), ("asked", []), ("tried", {})):
            page.setdefault(field, empty)
        return page

    def asked(self, concept: str, kind: str) -> bool:
        """Intention: whether this kind of guess was already made for the concept."""
        return any(row.get("kind") == kind and row.get("names") for row in self.entry(concept)["asked"])

    def keep(self, concept: str, kind: str, model: str, text: str, names: list) -> None:
        """Intention: the answer kept as said, and its names added to the concept's guesses."""
        page = self.entry(concept)
        page["asked"].append({"kind": kind, "model": model, "when": time.time(),
                              "said": str(text)[:2000], "names": list(names)})
        for name in names:
            if name not in page[kind]:
                page[kind].append(name)

    def untried(self, concept: str) -> list:
        """Intention: the concept's guessed sub-concepts not yet tried — a part, then a type, in turn.

        Parts lead (Andrew, muse-471: the image is built up from its pieces —
        whiskers, lines, curves, edges), so a part and its own parts are tried
        early instead of after every breed on the list (measured live
        2026-10-25 round 37: types-first tried three breeds and no part).
        """
        page = self.entry(concept)
        parts = [name for name in page["parts"] if name not in page["tried"]]
        types = [name for name in page["types"] if name not in page["tried"]]
        order = []
        for i in range(max(len(parts), len(types))):
            order.extend(group[i] for group in (parts, types) if i < len(group))
        return order

    def tried(self, concept: str, name: str, outcome: dict) -> None:
        """Intention: a tried guess is kept with what happened, worked or not."""
        self.entry(concept)["tried"][name] = dict(outcome, when=time.time())


class SubconceptGuesser:
    """Asks the small models for a concept's types and parts, and keeps what they said."""

    def __init__(self, root, state, asker=None) -> None:
        """Intention: `asker` is the local one by default; tests give their own."""
        self.asker = asker or LocalAsker(root)
        self.reader = AnswerNames()
        self.book = GuessBook(state)

    def guess(self, concept: str, kinds=("types", "parts"), models_per_question: int = 2) -> dict:
        """Intention: each kind not guessed yet is asked of up to two models; returns the new names by kind."""
        models = self.asker.models()
        new = {kind: [] for kind in kinds}
        for kind in kinds:
            if self.book.asked(concept, kind):
                continue
            question = getattr(Questions, kind)(concept)
            for model in models[:max(1, int(models_per_question))]:
                text = self.asker.ask(model, question)
                names = self.reader.read(text, concept)
                before = set(self.book.entry(concept)[kind])
                self.book.keep(concept, kind, model, text, names)
                new[kind].extend(name for name in names if name not in before and name not in new[kind])
        self.book.save()
        return new

    def full_name(self, concept: str, name: str, kind: str) -> str:
        """Intention: a part is named with its whole ("cat paw"); a type keeps its own name ("tabby cat")."""
        own = " ".join(concept.lower().split())
        if kind == "parts":
            if name.startswith(own):
                return name
            # Intention: "cat paw" + "paw pads" is "cat paw pads", not "cat paw paw pads".
            if name.split()[0] == own.split()[-1]:
                return f"{own} {' '.join(name.split()[1:])}".strip()
            return f"{own} {name}"
        last = own.split()[-1]
        return name if last in name.split() else f"{name} {last}"
