# WARP2/warp2/ask/personality.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/personality.py
#  Used by   : warp2/ask/talk.py, warp2/ask/window.py.
#  Uses      : warp2/util.py (atomic_write_bytes, ensure_dir); stdlib json,
#              pathlib, re.
#  Description:
#    Evolving personality and behavioral adaptation engine that learns from
#    interaction history, user feedback, and explicit directives.
#  User intention (Andrew, 2026-09-07):
#    "We also need a way it should act and a evolving personality system that
#    adapts to the user."
#  Principles: Clean — grounded and strictly truthful. Adaptive — evolves its
#    brevity, tone, and proposal calibration based on how Andrew interacts.
# ============================================================================
from __future__ import annotations

import json
import re
from pathlib import Path

from warp2.util import atomic_write_bytes, ensure_dir


DEFAULT_PERSONA = {
    "persona": "grounded_partner",
    "brevity": 0.8,
    "directness": 0.9,
    "language": "English",
    "invariants": [
        "Never pretend to have performed an action, drawn a picture, or created an artifact that was not actually executed.",
        "Never claim imaginary capabilities. If something is unsupported, state that plainly and propose creating a project for it.",
        "Speak in direct, plain sentences. Never engage in dramatic or fantasy roleplay.",
        "Translate user intent directly into actionable proposals.",
    ],
    "learned_preferences": [
        "Be honest about capabilities at all times.",
        "Turn unsupported requests into concrete project proposals.",
    ],
    "proposals_accepted": 0,
    "proposals_refused": 0,
    "interaction_turns": 0,
}


class Personality:
    """The evolving persona and behavioral posture of the warp."""

    def __init__(self, state) -> None:
        """Intention: set where the persona file lives under state/personality and load it."""
        self.home = ensure_dir(Path(state) / "personality")
        self.file = self.home / "persona.json"
        self.data = self._load()

    def _load(self) -> dict:
        """Intention: read the saved persona, or start from the default one when the file is missing or broken."""
        if self.file.is_file():
            try:
                return json.loads(self.file.read_text(encoding="utf-8"))
            except (ValueError, OSError):
                pass
        return dict(DEFAULT_PERSONA)

    def _save(self) -> None:
        """Intention: write the persona whole, so a crash never leaves half a file."""
        atomic_write_bytes(self.file, json.dumps(self.data, indent=2).encode("utf-8"))

    def guidance(self) -> str:
        """Formatted behavioral instructions for the conversational model."""
        brevity_desc = "very concise, 1-2 short sentences" if self.data.get("brevity", 0.8) > 0.7 else "clear and informative"
        lines = [
            "How you must act:",
            f"  - Style: {brevity_desc}. Direct and respectful.",
        ]
        for inv in self.data.get("invariants", []):
            lines.append(f"  - Invariant: {inv}")
        prefs = self.data.get("learned_preferences", [])
        if prefs:
            lines.append("  - Learned preferences from Andrew:")
            for pref in prefs:
                lines.append(f"    * {pref}")
        lang = self.data.get("language", "English")
        if lang and lang.lower() != "english":
            lines.append(f"  - Language: You MUST communicate with Andrew in {lang}.")
        return "\n".join(lines)

    def observe(self, speaker: str, text: str, action: str = "") -> None:
        """Adapt behavioral traits based on what was said and how proposals fared."""
        text = str(text or "").strip()
        speaker = str(speaker or "").lower()
        changed = False

        if action == "approve":
            self.data["proposals_accepted"] = self.data.get("proposals_accepted", 0) + 1
            changed = True
        elif action == "refuse":
            self.data["proposals_refused"] = self.data.get("proposals_refused", 0) + 1
            changed = True

        if speaker in ("andrew", "you") and text:
            self.data["interaction_turns"] = self.data.get("interaction_turns", 0) + 1
            changed = True

            # Detect explicit behavioral directives
            lower = text.lower()
            if any(k in lower for k in ("be brief", "keep it short", "shorter", "too long")):
                self.data["brevity"] = min(1.0, self.data.get("brevity", 0.8) + 0.1)
            elif any(k in lower for k in ("explain more", "elaborate", "why", "tell me more")):
                self.data["brevity"] = max(0.3, self.data.get("brevity", 0.8) - 0.1)

            # Detect language directives
            m_lang = re.search(r"(?:change\s+(?:the\s+)?language\s+to|speak\s+in|switch\s+(?:the\s+)?language\s+to|talk\s+in)\s+([a-zA-Z]+)", lower)
            if m_lang:
                target_lang = m_lang.group(1).capitalize()
                self.data["language"] = target_lang
                pref = f"Always communicate with Andrew in {target_lang}."
                if pref not in self.data.get("learned_preferences", []):
                    self.data.setdefault("learned_preferences", []).append(pref)
                changed = True

            if "don't make stories" in lower or "stop making stories" in lower or "roleplay" in lower:
                rule = "Never tell fictional stories or roleplay imaginary actions."
                if rule not in self.data.get("learned_preferences", []):
                    self.data.setdefault("learned_preferences", []).append(rule)

            # Auto-adapt brevity based on average input length
            words_count = len(text.split())
            if words_count < 6 and self.data.get("brevity", 0.8) < 0.9:
                self.data["brevity"] = min(1.0, round(self.data["brevity"] + 0.02, 2))

        if changed:
            self._save()
