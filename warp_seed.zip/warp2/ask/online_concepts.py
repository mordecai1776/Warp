# WARP2/warp2/ask/online_concepts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/online_concepts.py
#  Used by   : warp2/ask/tests/test_online_concepts.py, warp2/ask/visual.py
#  Uses      : warp2/ask/visual.py
#  Description:
#    Online concept and image discovery: searches online encyclopedias for
#    real concepts and images.
#  User intention:
#    Not written down in this file yet; noted to ask Andrew (2026-09-18).
# ============================================================================
"""Online concept and image discovery: searches online encyclopedias for real concepts and images."""
from __future__ import annotations

import hashlib
import io
import json
import re
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from PIL import Image

from warp2.ask.visual import DIRECTIONAL_DOMAINS

USER_AGENT = "WARP2EyeResearch/0.2 (local experimental AI visual learner)"


@dataclass
class OnlineConcept:
    """A real-world concept discovered online with description and image source."""
    title: str
    subject: str
    summary: str
    image_url: str | None
    page_url: str
    source: str = "wikipedia"


# Intention: words that join a title together and never name a thing.
_JOINING = frozenset({"the", "and", "for", "from", "with", "into", "onto", "over",
                      "under", "about", "after", "before", "between", "at", "of",
                      "in", "on", "to", "by", "or", "an", "a"})


def _clean_subject_tag(raw: str) -> str:
    """Normalize an encyclopedic title into a clean visual learning subject tag."""
    # Intention: A TITLE WITH A NUMBER IN IT IS AN EVENT, A YEAR OR A LIST,
    # NOT A THING ONE CAN DRAW (found 2026-09-24: "Wrestling at the ... 57 kg"
    # became the subject "wrestling_at", which the Eye practised for seven
    # rounds with nothing to learn from). Such a title gives no subject.
    if re.search(r"\d", str(raw or "")):
        return ""
    # Remove parenthesized qualifiers e.g. "Barn owl (bird)" -> "Barn owl"
    cleaned = re.sub(r"\(.*?\)", "", raw).strip()
    # Remove punctuation
    cleaned = re.sub(r"[^\w\s-]", "", cleaned).strip()
    # Pick the most specific substantive noun or short phrase
    words = cleaned.split()
    if not words:
        return "object"
    # Take last 1 or 2 words (e.g. "Great horned owl" -> "owl")
    last_word = words[-1].lower()
    # Intention: a title cut off on a joining word ("... at the") names nothing.
    if last_word in _JOINING:
        return ""
    if len(last_word) >= 3 and last_word.isalpha():
        return last_word
    # Intention: NO SUBJECT RATHER THAN A HALF-PHRASE. The old fallback glued
    # the first two words together ("wrestling_at"), which names nothing.
    return ""


class OnlineConceptSearcher:
    """Discovers real visual concepts and reference images from online sources."""

    def __init__(self, timeout: int = 6) -> None:
        """Intention: keep how many seconds each online request may take."""
        self.timeout = timeout

    def fetch_random_concepts(self, count: int = 3) -> list[OnlineConcept]:
        """Fetch random real-world encyclopedic concepts with summaries and images."""
        params = {
            "action": "query",
            "format": "json",
            "generator": "random",
            "grnnamespace": "0",
            "grnlimit": max(count * 2, 6),
            "prop": "pageimages|extracts|info",
            "inprop": "url",
            "exintro": "1",
            "explaintext": "1",
            "exsentences": "2",
            "piprop": "thumbnail",
            "pithumbsize": "400",
        }
        url = "https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.load(resp)
        except Exception:
            # Fallback when offline or network unreachable
            return self._fallback_concepts(count)

        pages = data.get("query", {}).get("pages", {})
        results: list[OnlineConcept] = []

        for page in pages.values():
            title = page.get("title", "")
            extract = page.get("extract", "").strip()
            # Skip disambiguation or list pages
            if not title or "disambiguation" in extract.lower() or title.startswith("List of"):
                continue
            if len(extract) < 20:
                continue

            thumb = page.get("thumbnail", {}).get("source")
            page_url = page.get("fullurl") or f"https://en.wikipedia.org/wiki/{urllib.parse.quote(title)}"
            subject = _clean_subject_tag(title)
            if not subject:
                continue

            results.append(
                OnlineConcept(
                    title=title,
                    subject=subject,
                    summary=extract,
                    image_url=thumb,
                    page_url=page_url,
                    source="wikipedia",
                )
            )
            if len(results) >= count:
                break

        if not results:
            return self._fallback_concepts(count)
        return results


    def download_image(self, image_url: str, destination: Path) -> Path | None:
        """Download and store reference image safely as a clean RGB PNG."""
        if not image_url or not image_url.startswith("https://"):
            return None
        destination.mkdir(parents=True, exist_ok=True)
        req = urllib.request.Request(image_url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
            digest = hashlib.sha256(raw).hexdigest()[:16]
            target_file = destination / f"online_{digest}.png"
            # Intention (2026-10-09, fix 3.9, check B12): kept at full size —
            # it was cut to 512 px, and dropped when over 8 MB.
            with Image.open(io.BytesIO(raw)) as img:
                rgb = img.convert("RGBA").convert("RGB") if img.mode == "P" else img.convert("RGB")
                rgb.save(target_file)
            return target_file
        except Exception:
            return None

    def _fallback_concepts(self, count: int, query_hint: str | None = None) -> list[OnlineConcept]:
        """Offline fallback using the local directional domain taxonomy."""
        out: list[OnlineConcept] = []
        if query_hint and query_hint.lower() in DIRECTIONAL_DOMAINS:
            pool = DIRECTIONAL_DOMAINS[query_hint.lower()]
        else:
            pool = [item for sublist in DIRECTIONAL_DOMAINS.values() for item in sublist]

        for idx in range(min(count, len(pool))):
            subj = pool[idx % len(pool)]
            out.append(
                OnlineConcept(
                    title=subj.capitalize(),
                    subject=subj,
                    summary=f"A real-world concept representing {subj} from the multi-domain directional taxonomy.",
                    image_url=None,
                    page_url=f"https://en.wikipedia.org/wiki/{subj}",
                    source="taxonomy_fallback",
                )
            )
        return out
