# WARP2/warp2/ask/picture_datasets.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/picture_datasets.py
#  Used by   : warp2/ask/picture_round.py (the search part pulls a page of a
#              labelled dataset for the subject each round it is not yet
#              approved).
#  Uses      : warp2/ask/hub_pictures.py (the hub), warp2/ask/visual.py
#              (_digest, NORMAL_WEIGHT; the learning's readers),
#              centering_image readers (test_searched_image, for the sample
#              check), warp2/util (atomic_write_bytes); (stdlib) hashlib, json,
#              math, time, pathlib.
#  Description:
#    Labelled pictures of a subject, pulled from datasets on the hub and
#    added as references a round can teach:
#      * the datasets for a subject are those where the subject is a label of
#        its own (hub_pictures.class_of); each is read a page a pull, the
#        pages spread across the whole dataset (next_page) and each read once —
#        a dataset that lists all its cats first still gives cats and dogs
#        together;
#      * a picture the dataset labels as the subject is admitted at once
#        (status confirmed, confirmed by "dataset:<name>") — Andrew,
#        2026-10-03: the label is enough; a picture with another of the
#        dataset's labels is kept too, as a reference of that label (a dog
#        from a cats-and-dogs set is a dog), so every picture pulled is used;
#      * the first new picture of each pull is shown to the vision readers
#        (what else they see in it is kept on it as its other concepts);
#        a dataset whose readers' record, at its high bound (passes over
#        reads plus one standard error), is below one half is not pulled
#        from again — a bad dataset is caught without reading every picture.
#    What was pulled from each dataset and its reader record are kept in
#    state/visual_learning/datasets.json.
#  User intention (Andrew, 2026-10-03): "it should have pulled datasets why has
#    it not"; "Label is enough (Recommended)" — the dataset's label admits a
#    picture, the reader checks a sample to catch a bad dataset; "It should
#    also see if images fit any other labels"; "then lets get them done".
# ============================================================================
"""Labelled pictures of a subject, pulled from hub datasets into the references."""
from __future__ import annotations

import hashlib
import json
import math
import time
from pathlib import Path

from warp2.ask import hub_pictures
from warp2.record.swallowed import noted


# Intention (2026-10-09, fix 3.6): which judge made a dataset's sample reads.
# Reads made by the old judge (a caption's word match, a reader's own written
# number, an outage counted as a fail) do not measure what today's readers
# would say, so they decide nothing; the count starts again under this judge.
JUDGE = "yes-chance 2026-10-09"


def trusted(record: dict) -> bool:
    """Whether a dataset's sample record still lets it be pulled from.

    Intention: the point of certainty used elsewhere in the WARP — a record
    is judged at one standard error; under two reads it could be anything,
    so it is still trusted. Only reads by the current judge count.
    """
    if record.get("judge") != JUDGE:
        return True
    reads, passes = int(record.get("reads", 0)), int(record.get("passes", 0))
    if reads < 2:
        return True
    rate = passes / reads
    high = rate + math.sqrt(max(rate * (1.0 - rate), 0.0) / reads) if 0.0 < rate < 1.0 else rate
    return high >= 0.5


# Intention (2026-10-09, fix 3.6): whether a sample check was made at all — a
# reading that says nobody could look (no reader running, every reader down)
# was not; a plain True/False from a caller's check always was.
def _judged(reading) -> bool:
    """Whether the readers actually looked."""
    return not (isinstance(reading, dict) and reading.get("judged") is False)


# Intention: whether a sample check passed, whichever shape it came in.
def _passed(reading) -> bool:
    """The readers' pass, from a reading dict or a plain bool."""
    return bool(reading.get("passed") if isinstance(reading, dict) else reading)


def clean(name) -> str:
    """Intention: a label name as a subject is written: lower case, its words joined by single spaces."""
    import re
    return " ".join(re.findall(r"[a-z0-9]+", str(name or "").lower()))


def label_name(names: list, label) -> str:
    """Intention: a row's label number as its dataset's label name; "" when the number names nothing."""
    try:
        return clean(names[int(label)])
    except (TypeError, ValueError, IndexError):
        return ""


def pages_in(entry: dict) -> int:
    """Intention: how many pages the dataset's split holds; one past the pages read when its size is not known."""
    rows = int((entry.get("where") or {}).get("rows") or 0)
    if rows <= 0:
        return int(entry.get("pages", 0)) + 1
    return max(1, -(-rows // hub_pictures.PAGE))


def next_page(entry: dict) -> int:
    """The first row of the next page to read: pages spread across the whole dataset, each read once.

    Intention (2026-10-03, measured: both cat datasets list every cat before
    every dog, so reading on from the start gave only cats — no "not a cat"
    pictures): the k-th page read is page (k x step) mod pages, where step
    is the whole number nearest the golden share of the pages that shares no
    factor with their count — so successive pages land far apart, and every
    page is reached once before any comes again. A dataset whose size is
    not known is read on from where it stopped.
    """
    total = pages_in(entry)
    rows = int((entry.get("where") or {}).get("rows") or 0)
    if rows <= 0:
        return int(entry.get("offset", 0))
    import math
    step = max(1, round(total * (math.sqrt(5) - 1) / 2))
    while math.gcd(step, total) != 1:
        step += 1
    return ((int(entry.get("pages", 0)) * step) % total) * hub_pictures.PAGE


def unread_scores_cleared(references: dict) -> int:
    """Intention: a dataset picture not yet read that was given 0.0 for its reader score has the 0.0 taken off (see `_reference`); how many."""
    cleared = 0
    for ref in references.values():
        if (str(ref.get("confirmed_by", "")).startswith("dataset:") and ref.get("reader_verdict") == "unread"
                and ref.get("reader_score") == 0.0):
            ref.pop("reader_score", None)
            cleared += 1
    return cleared


class PictureDatasets:
    """The hub datasets a learning pulls subject pictures from, and where each one stands."""

    def __init__(self, learning, hub=hub_pictures) -> None:
        """Intention: `hub` is injected so tests read no network."""
        self.learning = learning
        self.hub = hub
        self.path = Path(learning.home) / "datasets.json"

    def record(self) -> dict:
        """Intention: {subject: {dataset: {where, offset, pulled, reads, passes, done}}} — a torn file is an empty record."""
        try:
            return dict(json.loads(self.path.read_text(encoding="utf-8")))
        except (OSError, ValueError, TypeError):
            return {}

    def _save(self, record: dict) -> None:
        """Intention: write the datasets record whole, making its folder first."""
        from warp2.util import atomic_write_bytes
        self.path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_bytes(self.path, json.dumps(record, indent=1).encode("utf-8"))

    def _known(self, subject: str, record: dict) -> dict:
        """Intention: the subject's datasets, looked up on the hub the first time (and kept, with those that do not name it)."""
        mine = record.setdefault(subject, {})
        # Intention: a dataset kept before its label names (or its size) were kept looks them up again.
        for name, entry in mine.items():
            if entry.get("where") and ("names" not in entry["where"] or "rows" not in entry["where"]):
                try:
                    entry["where"] = self.hub.class_of(name, subject) or entry["where"]
                except Exception as exc:
                    noted("warp2/ask/picture_datasets.py:PictureDatasets._known", exc)
        if not mine:
            for name in self.hub.datasets_for(subject):
                try:
                    where = self.hub.class_of(name, subject)
                except Exception:
                    where = None
                mine[name] = {"where": where, "offset": 0, "pulled": 0, "reads": 0, "passes": 0,
                              "done": where is None}
        return mine

    def next_dataset(self, subject: str, record: dict) -> str:
        """The least-used unfinished trusted dataset, refreshing the hub when needed."""
        mine = self._known(subject, record)
        open_ = [n for n, d in mine.items() if not d.get("done") and trusted(d)]
        if not open_:
            # A source can become untrusted after its sample check while the
            # subject still needs data.  Keep that source blocked, but ask the
            # hub again so newly published or previously lower-ranked sources
            # can supply the next page.
            for name in self.hub.datasets_for(subject):
                if name in mine:
                    continue
                try:
                    where = self.hub.class_of(name, subject)
                except Exception:
                    where = None
                if where is not None:
                    mine[name] = {"where": where, "offset": 0, "pulled": 0, "reads": 0,
                                  "passes": 0, "done": False}
            open_ = [n for n, d in mine.items() if not d.get("done") and trusted(d)]
        return min(open_, key=lambda n: (mine[n]["pulled"], n)) if open_ else ""

    def pull(self, subject: str, data: dict, round_no: int = 0, check=None) -> dict:
        """One page of the next dataset, its pictures of the subject added to `data`'s references; what happened.

        Intention: `check(path, subject)` is the reader's sample check (it
        returns whether the readers passed it); by default the learning's own
        readers.
        (2026-10-04, review; Andrew: "We should try to get all of them fixed"):
          * the page is CLAIMED under the record's lock before it is read, so
            two lanes pulling at once never read one page twice and another
            never (`_claim`);
          * a picture already kept from the same dataset row (pulled for
            another of its labels) is not downloaded again;
          * the pictures are downloaded side by side (`_fetch_all`), the
            sample check and the references still made one at a time in page
            order;
          * a page that could not be read, or whose every download failed, is
            given back (`_settle`): not counted, never marking the dataset
            done, its failure counted instead.
        """
        claimed = self._claim(subject)
        if claimed is None:
            return {"dataset": "", "added": 0, "why": "no dataset names this subject (or all are read or untrusted)"}
        name, where, offset = claimed
        try:
            page = self.hub.rows(name, where, offset)
        except Exception as exc:
            self._settle(subject, name, offset, [], 0, 0, failed=True)
            return {"dataset": name, "added": 0, "others": {}, "why": f"page not read: {type(exc).__name__}: {exc}"}
        names = where.get("names") or []
        have = {(str((ref.get("source") or {}).get("dataset", "")), int((ref.get("source") or {}).get("row", -1)))
                for ref in data["references"].values() if isinstance(ref, dict)}
        wanted = []
        for row_number, label, address in page:
            mine = label == where["label"]
            named = subject if mine else label_name(names, label)
            if named and (name, int(row_number)) not in have:
                wanted.append((row_number, mine, named, address))
        got = self._fetch_all([address for *_, address in wanted])
        added, others, checked, failed, reads, passes = [], {}, False, 0, 0, 0
        for (row_number, mine, named, address), picture in zip(wanted, got):
            if picture is None:
                failed += 1
                continue
            path = self._kept(picture, address)
            ident = hashlib.sha256((named + path.stem).encode()).hexdigest()
            if ident in data["references"]:
                continue
            reading = None
            if mine and not checked:
                checked = True
                reading = (check or self._check)(path, subject)
                # Intention (2026-10-09, fix 3.6, check B7): a read nobody could
                # make is not a read — an outage never counts against a dataset.
                reads += int(_judged(reading))
                passes += int(_judged(reading) and _passed(reading))
            data["references"][ident] = self._reference(ident, named, path, name, row_number, round_no, names)
            if isinstance(reading, dict):
                self._read_into(data["references"][ident], reading)
            if reading is not None and _judged(reading) and not _passed(reading):
                # Intention (2026-10-09, fix 3.5, check B6): the readers refused
                # it, so it is not taught as the subject — it stayed "confirmed".
                data["references"][ident].update(status="rejected", confirmed_by="reader", weight=0)
            if mine:
                added.append(ident)
            else:
                others[named] = others.get(named, 0) + 1
        nothing = bool(wanted) and failed == len(wanted)
        entry = self._settle(subject, name, offset, page, len(added), reads, passes=passes, failed=nothing)
        said = {"dataset": name, "added": len(added), "others": others, "offset": entry.get("offset", offset),
                "ids": added, "trusted": trusted(entry)}
        if failed:
            said["failed"] = failed
        return said

    def _claim(self, subject: str):
        """(dataset, where, first row) of the next page, counted under the record's lock; None when no dataset is left.

        Intention (2026-10-04, review): the card lane's round and the web
        lane both pull; each read the record, downloaded for minutes, then
        wrote it back, so one page was read twice and the next never.
        """
        from warp2.record.locks import Lock
        with Lock(self.path, forever=True):
            record = self.record()
            name = self.next_dataset(subject, record)
            if not name:
                self._save(record)
                return None
            entry = record[subject][name]
            offset = next_page(entry)
            entry["pages"] = int(entry.get("pages", 0)) + 1
            if int((entry.get("where") or {}).get("rows") or 0) <= 0:
                # Intention: a dataset whose size is not known is read on from
                # where it stopped, so the claim moves that place on a page.
                entry["offset"] = int(offset) + int(getattr(self.hub, "PAGE", hub_pictures.PAGE))
            self._save(record)
            return name, dict(entry["where"]), offset

    def _settle(self, subject: str, name: str, offset: int, page: list, added: int, reads: int,
                passes: int = 0, failed: bool = False) -> dict:
        """What the page gave, written into the record under its lock; the dataset's entry as it now stands.

        Intention (2026-10-04, review): a page that failed (not read, or
        every download failed — the network down, the hub refusing) is given
        back — its count taken off, so it is read again later — and never
        marks the dataset done; the failures are counted. An empty page marks
        the dataset done only when its size is not known (that is its end).
        """
        from warp2.record.locks import Lock
        with Lock(self.path, forever=True):
            record = self.record()
            entry = record.setdefault(subject, {}).setdefault(name, {"where": {}, "offset": 0, "pulled": 0,
                                                                     "reads": 0, "passes": 0, "pages": 1})
            if failed:
                entry["pages"] = max(0, int(entry.get("pages", 0)) - 1)
                entry["failed"] = int(entry.get("failed", 0)) + 1
                step = int(getattr(self.hub, "PAGE", hub_pictures.PAGE))
                if (int((entry.get("where") or {}).get("rows") or 0) <= 0
                        and int(entry.get("offset", 0)) == int(offset) + step):
                    entry["offset"] = int(offset)  # Intention: given back, when nobody has claimed past it since.
            else:
                entry["offset"] = max(int(entry.get("offset", 0)), int(offset) + len(page))
                known = int((entry.get("where") or {}).get("rows") or 0) > 0
                if (not page and not known) or int(entry.get("pages", 0)) >= pages_in(entry):
                    entry["done"] = True
            entry["pulled"] = int(entry.get("pulled", 0)) + int(added)
            if entry.get("judge") != JUDGE:
                entry.update(judge=JUDGE, reads=0, passes=0)
            entry["reads"] = int(entry.get("reads", 0)) + int(reads)
            entry["passes"] = int(entry.get("passes", 0)) + int(passes)
            self._save(record)
            return dict(entry)

    def _fetch_all(self, addresses: list) -> list:
        """Every picture's bytes, downloaded side by side, in the order given; None for one that failed.

        Intention (2026-10-04, review: a page of 100 was downloaded one at a
        time): as many at once as the machine has processors — downloads wait
        on the network, not the processor, so this is a floor that grows with
        the machine, not a count chosen by hand. Files are named by their
        digest and written whole, so side by side is safe.
        """
        if not addresses:
            return []
        import os
        from concurrent.futures import ThreadPoolExecutor

        def one(address):
            """Intention: download one picture; a failed download is None so the others still go on."""
            try:
                return self.hub.fetch(address)
            except Exception:
                return None
        with ThreadPoolExecutor(max_workers=max(1, min(len(addresses), os.cpu_count() or 1))) as pool:
            return list(pool.map(one, addresses))

    def _kept(self, picture: bytes, address: str) -> Path:
        """Intention: the picture's bytes kept once under their own digest, beside the other references."""
        from warp2.util import atomic_write_bytes
        digest = hashlib.sha256(picture).hexdigest()
        suffix = Path(address.split("?", 1)[0]).suffix or ".jpg"
        path = Path(self.learning.home) / "references" / (digest + suffix)
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            atomic_write_bytes(path, picture)
        return path

    def _reference(self, ident: str, subject: str, path: Path, dataset: str, row_number: int, round_no: int,
                   names: list = ()) -> dict:
        """A reference admitted by its dataset's label: confirmed, by the dataset, tagged with its label.

        Intention: the dataset's other label names ride along as what the
        picture was told apart from (`not_labels`), so whoever reads the
        reference can see what the dataset said it is not. It has no reader
        score until a reader reads it (2026-10-03, measured: a score of 0.0
        for "not read" made the picture weigher give dataset pictures a third
        of a web picture's weight — 0.84 against 2.83; with no score the two
        come out even, 1.00 and 1.00).
        """
        from warp2.ask.visual import NORMAL_WEIGHT, _digest
        apart = sorted({clean(n) for n in names if clean(n) and clean(n) != subject})
        return dict(id=ident, subject=subject, path=str(path.resolve()), digest=_digest(path),
                    status="confirmed", confirmed_by=f"dataset:{dataset}", confirmed_at=time.time(),
                    source={"dataset": dataset, "row": int(row_number)}, weight=NORMAL_WEIGHT,
                    found_at=time.time(), round=int(round_no), wanted=[],
                    reader_observation="", reader_verdict="unread", readers=[], tags=[subject],
                    not_labels=apart, concept_scores={}, concept_tags=[], attached_datasets=[dataset],
                    preemptive_concepts=[])

    def _check(self, path: Path, subject: str) -> dict:
        """Intention: the learning's vision readers look at one pulled picture; what they said (passed, what else they saw)."""
        from readers import test_searched_image
        return test_searched_image(path, {"name": subject}, readers=self.learning._readers())

    @staticmethod
    def _read_into(reference: dict, reading: dict) -> None:
        """What the readers saw in a sampled picture, kept on it beside its label.

        Intention (Andrew, 2026-10-03: "It should also see if images fit any
        other labels"): the readers name what else is in the picture (a sofa
        under the cat), and those names are kept as its other concepts with
        the readers' own confidence; its label stays what the dataset said.
        """
        seen = dict(reading.get("detected_concepts") or {})
        reference["concept_scores"] = {str(k): float(v) for k, v in seen.items()}
        reference["concept_tags"] = list(reading.get("concept_tags") or [])
        reference["tags"] = sorted(set(reference.get("tags") or []) | set(reading.get("tags") or []))
        reference["reader_score"] = float(reading.get("score") or 0.0)
        reference["reader_observation"] = str(reading.get("observation") or "")
        reference["reader_verdict"] = ("verified" if reading.get("passed") else
                                       "not_judged" if not _judged(reading) else "unverified")
        reference["readers"] = list(reading.get("readers") or [])
