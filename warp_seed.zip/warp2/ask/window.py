# WARP2/warp2/ask/window.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/window.py
#  Used by   : WARP2.bat, warp2/run.py (`ask`), warp2/ui/observer.py's ASK
#              button, and a person double-clicking it.
#  Uses      : warp2/ask/{thread,talk,knowing,inbox,media,image_asks}.py,
#              warp2/ui/theme.py
#              (the cockpit's colours, read and not edited), warp2/store/store.py
#              (`store_home` — the one definition of where the store lives),
#              warp2/decide (the turn_kind action model, handed to Talk),
#              warp2/chat_learning/speaker.py (who speaks each chat turn),
#              warp2/record/all_stop.py (Stop: flag, then kill);
#              stdlib tkinter.
#              warp2/tags/media/pictures.py (open_picture - a picture is opened
#              from its small form first; BUILD_LOG 1591c);
#              warp2/tags/media/pictures.py (is_there, bytes_of, where_file_is - asked of the small form; BUILD_LOG 1597c);
#  Description:
#    The user action centre: modern AI chat interface with past conversation
#    browsing, project folders, inline image and video generation, and
#    conversational reset.
#  User intention (Andrew, 2026-09-07):
#    "We also need stuff for past conversations and folders for projects. It
#    should look like a normal chat bot interface does these days"
#    "we can add some functions for image and video generation to the user
#    interface"
#    "The conversation should be able to be reset"
#    "it should do it automaticaly it should always be proactive like that"
#    "The image should say what it is trying to make and look for more suporting images each time it retrains"
#    "It should also always say what it is trying to make"
#    "It should also show refrence images that it finds to varifay what the image is"
#    2026-09-18: "detach the immediate change that image user stuff works and
#    place that into something that adds to the work instead of acting like a
#    trigger." Pictures are asked for here and made by the loop; confirming or
#    turning one down adds feedback to the work. Nothing is made or trained in
#    this window.
#  Principles: Clean — this window writes a turn to the conversation and a
#    request to the inbox, and touches the store never. Adaptive — a model
#    talks when one is running and the window works the same when none is.
# ============================================================================
from __future__ import annotations
from warp2.tags.media import pictures
from warp2.tags.media.pictures import open_picture

import json
import functools
import queue
import threading
import time
from pathlib import Path

from warp2.ask.inbox import COMMENT, FEEDBACK, FILE, IMAGE, Inbox, PROJECT, RESEARCH, VIDEO
from warp2.ask.talk import INTENTION, Talk
from warp2.ask.thread import ANDREW, WARP, Thread
from warp2.record.swallowed import noted

# How often the conversation is re-read from disk, in milliseconds. Intention:
# slow on purpose, and the cockpit's own lesson from 2026-09-04 is why — a
# window that reads on a fast timer freezes the thing it is watching.
EVERY = 2000

# Intention: how a practice report written into the conversation before
# 2026-09-18 begins — those are shown in the Confirmations panel, not the chat.
PRACTICE_SAYS = "Centering practice:"


# Intention (Andrew, 2026-09-22): background runner telemetry, step notes and
# system side-work stay out of the chat. Kept at module level so the old window
# and the new one window (warp2/app/pages/chat.py) share one rule.
TELEMETRY_PREFIXES = (
    "Chat: ", "Code: ", "Code Skill: ", "Eye: ", "Eye blocks: ", "Fleet Test: ",
    "Games: ", "Game: ", "Training Web Inflation: ", "Proof Hunter: ",
    "Triage: ", "Logic: ", "Logic Skill: ", "Pairs: ", "Webs: ", "source check",
    "The build log was not updated", "Centering practice: ",
    "I cannot reach what I know yet",
    "📋 Step ", "⚙️ Step ", "✅ Step ", "🛡️ Cellular Self-Healing", "ℹ️ Pass outcome", "✨ Steps completed",
)


def turn_is_shown(turn: dict) -> bool:
    """Intention: True when a turn is part of the talk with Andrew, not side-work."""
    who = turn.get("who") or WARP
    said_text = str(turn.get("said") or "")
    if said_text.startswith(PRACTICE_SAYS):
        return False
    if turn.get("system") or who in ("system", "engine", "runner"):
        return False
    return not (any(said_text.startswith(p) for p in TELEMETRY_PREFIXES)
                or "of my own files changed since the last run" in said_text
                or "The build log was not updated with them" in said_text)


def colours() -> dict:
    """The look, borrowed so the two windows feel like one machine."""
    from warp2.ui import theme
    return {"page": theme.BG_DARK, "panel": theme.BG_CARD, "field": theme.BG_INPUT,
            "ink": theme.FG_PRIMARY, "quiet": theme.FG_SECONDARY,
            "good": theme.ACCENT_GREEN, "warn": theme.ACCENT_YELLOW,
            "blue": theme.ACCENT_BLUE}


# Intention: workers publish UI changes without calling even Tk.after off-thread.
def _on_ui(method):
    """Queue widget operations for the thread that owns the window."""
    @functools.wraps(method)
    def queued(self, *args, **kwargs):
        """Keep every Tk call on its creating thread."""
        if self.root is not None and threading.get_ident() != self._ui_thread:
            self._ui_events.put((method, args, kwargs))
            return None
        return method(self, *args, **kwargs)
    return queued


# How a round's ending reads to a person. One spelling, here.
#
# Intention: the round names its ending in one word for the record; a person
# reading the chat needs to know what to do about it.
ENDINGS = {
    "approved": "a reader says it is what was asked for",
    "no_reader": "nothing was able to look at it",
    "reader_busy": "the reader ran out of time on a busy machine",
    "stopped": "the machine was asked to stop",
    "out_of_rounds": "it used every round and never got there",
    "more_to_do": "it took its turn and will carry on",
}


# Intention (2026-10-09, fix 3.7): how the thread names each kind of ask.
MEDIA_SAID = {IMAGE: "a picture", VIDEO: "a video", RESEARCH: "a search & research"}

class ActionCentre:
    """A conversation with the warp, and the only place a person instructs it.

    Intention: HE TALKS, IT ANSWERS OUT OF WHAT IS TRUE, AND NOTHING IS WRITTEN
    UNTIL HE SAYS YES. Those three are the whole design. The first two make it
    worth opening; the third is what stops a chat window becoming the way a
    model's words end up stored as his.
    """

    def __init__(self, state, talk=None, root_dir=None) -> None:
        """Intention: set up the state, thread, inbox and stop control, and empty slots for every
        widget build() makes later.
        """
        self.state = Path(state)
        self.root_dir = Path(root_dir) if root_dir else Path(".")
        self.thread = Thread(state)
        self.inbox = Inbox(state)
        # Intention: ANDREW KILLED THE PROGRAM SIX TIMES ON 2026-09-12 to stop
        # things — a picture he did not want, a round that was going nowhere,
        # the whole machine. The stop button existed the whole time, on the
        # OTHER window. The control a person needs most cannot live on a window
        # they are not looking at. See warp2/record/stop.py.
        from warp2.record.stop import Halt
        self.halt = Halt(self.state)
        # Intention: what the status line last showed and when the job in
        # flight began. Held from the start, not from `build`, because plenty
        # of this class is used with no window at all — and a status line that
        # raises AttributeError on a headless caller is a status line that
        # makes things worse.
        self._showing = ""
        self._since = None
        self.talk = talk
        self.root = None
        self.said = None
        self.paper = None
        self.note = None
        self.offer = None
        self.offer_words = None
        self.yes = None
        self.no = None
        self.proposal = None
        self._img_refs: list = []
        self._colour: dict = {}
        self.active_project = ""
        self.viewing_archive = ""
        self.font_size: int = 11
        self.theme_name: str = "slate"
        self.language: str = "English"
        self.lbl_action_centre_sub = None
        self.btn_new_chat = None
        self.btn_clear_chat = None
        self.lbl_projects_header = None
        self.lbl_past_chats_header = None
        self.lbl_created_images_header = None
        self.btn_make_image = None
        self.btn_search_research = None
        self.btn_duplicates = None
        self.btn_make_video = None
        self.btn_add_file = None
        self.btn_export_chat = None
        self.btn_send = None
        self.projects_frame = None
        self.chats_frame = None
        self.images_frame = None
        self.active_chat_btn = None
        self.header_title = None
        self.header_sub = None
        self.header_badge = None
        self.search_entry = None
        self._proactive_ticks: int = 0
        self._busy: bool = False
        self._ui_thread = threading.get_ident()
        self._ui_events = queue.Queue()
        self._jobs = queue.Queue()
        self._worker = None
        self._project_names = []

        # Detached Image Generation Queue
        self.image_queue: list[dict] = []
        self._image_queue_worker_running = False
        self.image_queue_entry = None
        self.lbl_queue_header = None
        self.queue_items_frame = None
        self._load_image_queue()

        # Game Arena & Verification Panel (to the right of conversation)
        self.btn_open_games = None
        self.game_panel = None
        self.game_select_var = None
        self.game_dropdown = None
        self.btn_test_game = None
        self.btn_random_game = None
        self.game_status_card = None
        self.lbl_game_title = None
        self.lbl_game_score = None
        self.lbl_game_outcome = None
        self.lbl_chk_player = None
        self.lbl_chk_perimeter = None
        self.lbl_chk_objectives = None
        self.lbl_chk_solvable = None
        self.btn_view_made = None
        self.btn_view_original = None
        self.btn_view_diff = None
        self.game_ascii_display = None
        self.game_history_listbox = None
        self._game_view_mode = "made"
        self._current_made_layout = ""
        self._current_original_layout = ""
        self._current_diff_text = ""
        self._past_game_reports: list[dict] = []
        self.btn_play_game = None
        self.game_controls_legend_frame = None
        self.game_dpad_frame = None
        self._game_play_active: bool = False
        self._active_session = None
        self.lbl_legend_title = None
        self.lbl_legend_controls = None
        self.lbl_legend_symbols = None

        # Dedicated Confirmation & Approvals Space (outside conversation)
        self.right_container = None
        self.confirm_panel = None
        self.confirm_header = None
        self.confirm_badge = None
        self.confirm_cards_frame = None
        self.confirm_empty_lbl = None
        self.image_confirm_cards_frame = None
        self.pending_image_confirmations: dict[str, dict] = {}
        self.right_view_mode: str = "split"
        self.btn_mode_split = None
        self.btn_mode_confirm = None
        self.btn_mode_games = None
        self.btn_mode_map = None
        self.map_panel = None
        self.btn_raptor_map = None
        self._raptor_window = None
        self._confirm_thumbs: list = []

    def _drain_ui(self):
        """Apply bounded batches so progress cannot starve normal window events."""
        # A confirmation can enqueue status, transcript, image-list, and
        # refresh work together.  Processing a hundred callbacks in one Tk
        # turn made the window appear hung while large image cards were being
        # rebuilt.  Keep turns short so paint/input events get scheduled
        # between batches; the queue remains lossless.
        for _ in range(20):
            try:
                method, args, kwargs = self._ui_events.get_nowait()
            except queue.Empty:
                break
            try:
                method(self, *args, **kwargs)
            except Exception as exc:
                self._say(f"display error: {type(exc).__name__}: {exc}")
        self.root.after(50, self._drain_ui)

    def _background(self, work):
        """Run slow work away from Tk and make failures visible to the person."""
        def run():
            """Always release the operation guard, including unexpected failures."""
            try:
                return work()
            except Exception as exc:
                self._say(f"operation failed: {type(exc).__name__}: {exc}")
            finally:
                self._busy = False
        if self.root is None:
            return run()
        if self._worker is None:
            def consume():
                """Own SQLite and model access on one stable background thread."""
                while True:
                    self._jobs.get()()
            self._worker = threading.Thread(target=consume, daemon=True)
            self._worker.start()
        self._jobs.put(run)
        return {"status": "working in background"}

    # -- the window ----------------------------------------------------------

    def build(self, tk, root, colour) -> None:
        """Lay it out. Modern chat bot interface with sidebar, media controls, and game testing arena."""
        self.root = root
        self._ui_thread = threading.get_ident()
        root.after(50, self._drain_ui)
        self._colour = colour
        root.title("Chat — Assistant")
        root.configure(bg=colour["page"])
        root.geometry("1420x820")
        root.minsize(1120, 640)

        # Global Keyboard Shortcuts
        root.bind("<Control-n>", lambda e: self.reset())
        root.bind("<Control-N>", lambda e: self.reset())
        root.bind("<Control-t>", lambda e: self.reset())
        root.bind("<Control-T>", lambda e: self.reset())
        root.bind("<Control-f>", lambda e: self._focus_search())
        root.bind("<Control-F>", lambda e: self._focus_search())
        root.bind("<Control-e>", lambda e: self.export_chat_action())
        root.bind("<Control-E>", lambda e: self.export_chat_action())
        root.bind("<Escape>", lambda e: self._on_escape())

        container = tk.Frame(root, bg=colour["page"])
        container.pack(fill="both", expand=True)

        # Left Sidebar (Width 250px)
        sidebar = tk.Frame(container, bg=colour["panel"], width=250, padx=12, pady=12)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        # Header / Brand
        tk.Label(sidebar, text="Chat", bg=colour["panel"], fg=colour["blue"],
                 font=("Segoe UI", 15, "bold")).pack(anchor="w")
        self.lbl_action_centre_sub = tk.Label(sidebar, text="AI Assistant", bg=colour["panel"], fg=colour["quiet"],
                 font=("Segoe UI", 9))
        self.lbl_action_centre_sub.pack(anchor="w", pady=(0, 6))

        self.lbl_warp_doing = tk.Label(sidebar, text="Warp: —", bg=colour["panel"],
                                       fg=colour["quiet"], font=("Segoe UI", 8),
                                       anchor="w", justify="left", wraplength=226)
        # Detached: do not pack the background engine ticker into the clean sidebar.

        # New Chat and Clear Chat controls
        chat_ctrls = tk.Frame(sidebar, bg=colour["panel"])
        chat_ctrls.pack(fill="x", pady=(0, 10))
        self.btn_new_chat = tk.Button(chat_ctrls, text="+ New Chat", command=self.reset, relief="flat",
                  bg=colour["blue"], fg=colour["page"], padx=8, pady=5,
                  font=("Segoe UI", 9, "bold"), cursor="hand2")
        self.btn_new_chat.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.btn_clear_chat = tk.Button(chat_ctrls, text="Clear", command=self.clear_current_chat, relief="flat",
                  bg=colour["field"], fg=colour["quiet"], padx=8, pady=5,
                  font=("Segoe UI", 9), cursor="hand2")
        self.btn_clear_chat.pack(side="right")

        # Projects Section
        self.lbl_projects_header = tk.Label(sidebar, text="📁 PROJECTS", bg=colour["panel"], fg=colour["ink"],
                 font=("Segoe UI", 9, "bold"))
        self.projects_frame = tk.Frame(sidebar, bg=colour["panel"])
        # Detached from sidebar root to keep sidebar focused on conversation history & gallery

        # Past Conversations Section
        past_header = tk.Frame(sidebar, bg=colour["panel"])
        past_header.pack(fill="x", pady=(4, 2))
        self.lbl_past_chats_header = tk.Label(past_header, text="💬 PAST CHATS", bg=colour["panel"], fg=colour["ink"],
                 font=("Segoe UI", 9, "bold"))
        self.lbl_past_chats_header.pack(side="left")

        search_box = tk.Frame(sidebar, bg=colour["field"])
        search_box.pack(fill="x", pady=(2, 6))

        self.search_entry = tk.Entry(search_box, bg=colour["field"], fg=colour["ink"],
                                     insertbackground=colour["ink"], relief="flat",
                                     font=("Segoe UI", 9))
        self.search_entry.pack(side="left", fill="x", expand=True, padx=(4, 0), pady=2)
        self.search_entry.insert(0, "🔍 Filter chats...")
        self.search_entry.bind("<FocusIn>", self._on_search_focus_in)
        self.search_entry.bind("<FocusOut>", self._on_search_focus_out)
        self.search_entry.bind("<KeyRelease>", lambda e: self._refresh_chats_list())

        def _clear_search():
            """Intention: empty the chat filter box and show every chat again."""
            self.search_entry.delete(0, "end")
            self._refresh_chats_list()

        tk.Button(search_box, text="✕", command=_clear_search, relief="flat",
                  bg=colour["field"], fg=colour["quiet"],
                  activebackground=colour["field"], activeforeground=colour["ink"],
                  font=("Segoe UI", 8), cursor="hand2", padx=4, pady=0).pack(side="right")

        self.chats_frame = tk.Frame(sidebar, bg=colour["panel"])
        self.chats_frame.pack(fill="x", pady=(0, 10))
        self._refresh_chats_list(tk, colour)

        # Image Generation Queue (Available programmatically / on request)
        self.lbl_queue_header = tk.Label(sidebar, text="⏳ IMAGE QUEUE", bg=colour["panel"], fg=colour["ink"],
                 font=("Segoe UI", 9, "bold"))
        queue_input_row = tk.Frame(sidebar, bg=colour["panel"])
        self.image_queue_entry = tk.Entry(queue_input_row, bg=colour["field"], fg=colour["ink"],
                                          insertbackground=colour["ink"], relief="flat",
                                          font=("Segoe UI", 9))
        self.image_queue_entry.insert(0, "Image subject...")
        self.image_queue_entry.bind("<FocusIn>", self._on_queue_entry_focus_in)
        self.image_queue_entry.bind("<FocusOut>", self._on_queue_entry_focus_out)
        self.image_queue_entry.bind("<Return>", lambda e: self.enqueue_from_sidebar())
        self.queue_items_frame = tk.Frame(sidebar, bg=colour["panel"])
        # Detached: image generation is natural through conversation and media bar

        # Created Images Section (Gallery)
        self.lbl_created_images_header = tk.Label(sidebar, text="🖼️ CREATED IMAGES", bg=colour["panel"], fg=colour["ink"],
                 font=("Segoe UI", 9, "bold"))
        self.lbl_created_images_header.pack(anchor="w", pady=(4, 2))
        self.images_frame = tk.Frame(sidebar, bg=colour["panel"])
        self.images_frame.pack(fill="both", expand=True)
        self._refresh_images_list(tk, colour)

        # Right Deck: Detached from chat window. Chat is pure, dedicated conversation.
        self.right_container = tk.Frame(container, bg=colour["panel"], width=400, padx=12, pady=12)
        # Detached: not packed in the chat view to preserve clean ergonomics
        self.right_container.pack_propagate(False)

        # Right Column Mode Selector
        mode_tabs = tk.Frame(self.right_container, bg=colour["panel"])
        mode_tabs.pack(fill="x", pady=(0, 8))
        self.btn_mode_confirm = tk.Button(mode_tabs, text="🖼️ Images (0)",
                                          command=lambda: self._switch_right_view("confirmations"),
                                          relief="flat", bg=colour["field"], fg=colour["quiet"],
                                          font=("Segoe UI", 8, "bold"), padx=6, pady=3, cursor="hand2")
        self.btn_mode_confirm.pack(side="left", padx=(0, 2))
        self.btn_mode_games = tk.Button(mode_tabs, text="🎮 Games",
                                        command=lambda: self._switch_right_view("games"),
                                        relief="flat", bg=colour["field"], fg=colour["quiet"],
                                        font=("Segoe UI", 8, "bold"), padx=6, pady=3, cursor="hand2")
        self.btn_mode_games.pack(side="left", padx=(0, 2))
        self.btn_mode_split = tk.Button(mode_tabs, text="⚏ Split View",
                                        command=lambda: self._switch_right_view("split"),
                                        relief="flat", bg=colour["field"], fg=colour["blue"],
                                        font=("Segoe UI", 8, "bold"), padx=6, pady=3, cursor="hand2")
        self.btn_mode_split.pack(side="left", padx=(0, 2))
        self.btn_mode_triage = tk.Button(mode_tabs, text="❓ Triage (0)",
                                         command=lambda: self._switch_right_view("triage"),
                                         relief="flat", bg=colour["field"], fg=colour["quiet"],
                                         font=("Segoe UI", 8, "bold"), padx=6, pady=3, cursor="hand2")
        self.btn_mode_triage.pack(side="left")
        self.btn_mode_map = tk.Button(mode_tabs, text="🗺️ Map",
                                      command=lambda: self._switch_right_view("map"),
                                      relief="flat", bg=colour["field"], fg=colour["quiet"],
                                      font=("Segoe UI", 8, "bold"), padx=6, pady=3, cursor="hand2")
        self.btn_mode_map.pack(side="left", padx=(2, 0))

        # Dedicated Confirmation & Approvals Panel (outside the conversation)
        self.confirm_panel = tk.Frame(self.right_container, bg=colour["panel"])
        confirm_hdr = tk.Frame(self.confirm_panel, bg=colour["panel"])
        confirm_hdr.pack(fill="x", pady=(0, 4))
        self.confirm_header = tk.Label(confirm_hdr, text="🖼️ IMAGES & CONFIRMATIONS", bg=colour["panel"],
                                       fg=colour["ink"], font=("Segoe UI", 9, "bold"))
        self.confirm_header.pack(side="left")
        self.confirm_badge = tk.Label(confirm_hdr, text="● None", bg=colour["field"],
                                      fg=colour["quiet"], font=("Segoe UI", 8, "bold"), padx=6, pady=1)
        self.confirm_badge.pack(side="right")


        self.confirm_cards_frame = tk.Frame(self.confirm_panel, bg=colour["panel"])
        self.confirm_cards_frame.pack(fill="x", pady=(0, 4))

        # Proposal Confirmation Frame (housed in Confirmation Space, outside main chat)
        self.offer = tk.Frame(self.confirm_cards_frame, bg=colour["field"], padx=10, pady=8)
        self.offer_words = tk.Label(self.offer, text="", bg=colour["field"],
                                    fg=colour["ink"], wraplength=360, justify="left",
                                    font=("Segoe UI", 9))
        self.offer_words.pack(anchor="w", fill="x", expand=True, pady=(0, 6))
        offer_btns = tk.Frame(self.offer, bg=colour["field"])
        offer_btns.pack(fill="x")
        self.no = tk.Button(offer_btns, text="✕ Refuse", command=self.refuse, relief="flat",
                            bg=colour["panel"], fg=colour["ink"], padx=10, pady=2,
                            font=("Segoe UI", 8), cursor="hand2")
        self.no.pack(side="right", padx=(6, 0))
        self.yes = tk.Button(offer_btns, text="✓ Yes, store that", command=self.approve,
                             relief="flat", bg=colour["good"], fg=colour["page"],
                             padx=10, pady=2, font=("Segoe UI", 8, "bold"), cursor="hand2")
        self.yes.pack(side="right")

        # Subframe for Image Confirmation Cards
        self.image_confirm_cards_frame = tk.Frame(self.confirm_cards_frame, bg=colour["panel"])
        self.image_confirm_cards_frame.pack(fill="x")

        # Empty state indicator
        self.confirm_empty_lbl = tk.Label(self.confirm_cards_frame,
                                          text="✨ No pending image reviews — chat is clear.",
                                          bg=colour["panel"], fg=colour["quiet"],
                                          font=("Segoe UI", 8, "italic"), anchor="w")
        self.confirm_empty_lbl.pack(fill="x", pady=4)


        self.confirm_panel.pack(fill="x", pady=(0, 8))

        # Game Testing Arena Panel (housed in right deck below confirmations)
        self.game_panel = tk.Frame(self.right_container, bg=colour["panel"])
        self.game_panel.pack(fill="both", expand=True)
        self._build_game_panel(tk, self.game_panel, colour)

        # Uncertain Images Triage Panel
        self.triage_panel = tk.Frame(self.right_container, bg=colour["panel"])
        self._build_triage_panel(tk, self.triage_panel, colour)

        # RAPTOR System Map Panel
        self.map_panel = tk.Frame(self.right_container, bg=colour["panel"])
        self._build_map_panel(tk, self.map_panel, colour)

        # Center Main Chat Area (fills between sidebar and right deck)
        main_chat = tk.Frame(container, bg=colour["page"])
        main_chat.pack(side="left", fill="both", expand=True)

        # Top Bar
        top = tk.Frame(main_chat, bg=colour["panel"], padx=16, pady=10)
        top.pack(fill="x")
        top_left = tk.Frame(top, bg=colour["panel"])
        top_left.pack(side="left", fill="y")
        self.header_title = tk.Label(top_left, text="Chat", bg=colour["panel"],
                                     fg=colour["blue"], font=("Segoe UI", 13, "bold"))
        self.header_title.pack(anchor="w")
        self.header_sub = tk.Label(top_left, text="Ask anything, brainstorm ideas, or generate images and videos.",
                                   bg=colour["panel"], fg=colour["quiet"], font=("Segoe UI", 9))
        self.header_sub.pack(anchor="w")

        self.header_badge = tk.Label(top, text="● Loading Engine…", bg=colour["field"],
                                     fg=colour["warn"], font=("Segoe UI", 9, "bold"),
                                     padx=10, pady=4)
        self.header_badge.pack(side="right", padx=(0, 4))

        # Intention (Andrew, 2026-09-22): Detach chat header from WARP engine controls.
        # Chat header stays clean and focused on conversation. Engine controls remain
        # available in the More menu and Cockpit.
        self.btn_halt = tk.Button(top, text="■ Stop", command=self.stop_action,
                                  relief="flat", bg=colour["field"], fg=colour["warn"],
                                  activebackground=colour["panel"],
                                  activeforeground=colour["warn"],
                                  padx=12, pady=4, font=("Segoe UI", 9, "bold"),
                                  cursor="hand2")
        # Detached: not packed in conversation header

        self.btn_raptor_map = tk.Button(
            top, text="🗺️ RAPTOR Map", command=self.open_raptor_map_action,
            relief="flat", bg=colour["field"], fg=colour["blue"],
            activebackground=colour["panel"], activeforeground=colour["blue"],
            padx=10, pady=4, font=("Segoe UI", 9, "bold"), cursor="hand2"
        )
        # Detached: not packed in conversation header

        # Paper Transcript with scrollbar
        paper_frame = tk.Frame(main_chat, bg=colour["page"])
        paper_frame.pack(fill="both", expand=True, padx=12, pady=6)
        scrollbar = tk.Scrollbar(paper_frame)
        scrollbar.pack(side="right", fill="y")

        self.paper = tk.Text(paper_frame, wrap="word", bg=colour["page"], fg=colour["ink"],
                             relief="flat", padx=16, pady=10, yscrollcommand=scrollbar.set,
                             font=("Segoe UI", 11), state="disabled")
        self.paper.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=self.paper.yview)

        self.paper.tag_configure(ANDREW, foreground=colour["blue"],
                                 font=("Segoe UI", 11, "bold"), spacing1=8)
        self.paper.tag_configure(WARP, foreground=colour["ink"], spacing3=8)
        self.paper.tag_configure("grounds", foreground=colour["quiet"],
                                 font=("Consolas", 9), spacing3=6)

        # Media Action Bar (Image, Video, Add File, Export Chat)
        media_bar = tk.Frame(main_chat, bg=colour["page"], padx=16, pady=4)
        media_bar.pack(fill="x")
        self.btn_make_image = tk.Button(media_bar, text="🖼️ Queue Image", command=self.generate_image_action,
                  relief="flat", bg=colour["field"], fg=colour["ink"], padx=10, pady=4,
                  font=("Segoe UI", 9, "bold"), cursor="hand2")
        self.btn_make_image.pack(side="left", padx=(0, 6))
        self.btn_search_research = tk.Button(media_bar, text="🔎 Search & Research", command=self.search_research_dialog_action,
                  relief="flat", bg=colour["field"], fg=colour["ink"], padx=10, pady=4,
                  font=("Segoe UI", 9), cursor="hand2")
        self.btn_search_research.pack(side="left", padx=(0, 6))
        self.btn_make_video = tk.Button(media_bar, text="🎥 Make Video", command=self.generate_video_action,
                  relief="flat", bg=colour["field"], fg=colour["ink"], padx=10, pady=4,
                  font=("Segoe UI", 9, "bold"), cursor="hand2")
        self.btn_make_video.pack(side="left", padx=(0, 6))
        self.btn_add_file = tk.Button(media_bar, text="📎 Add File", command=self.add_a_file,
                  relief="flat", bg=colour["field"], fg=colour["ink"], padx=10, pady=4,
                  font=("Segoe UI", 9), cursor="hand2")
        self.btn_add_file.pack(side="left", padx=(0, 6))
        self.btn_open_games = tk.Button(media_bar, text="🎮 Game Arena", command=self.open_games_action,
                  relief="flat", bg=colour["field"], fg=colour["ink"], padx=10, pady=4,
                  font=("Segoe UI", 9, "bold"), cursor="hand2")
        self.btn_open_games.pack(side="left", padx=(0, 6))


        # Intention: FOUR THINGS A PERSON DOES OFTEN, AND A MENU FOR THE REST.
        # This row carried eight controls side by side — make an image, make a
        # video, add a file, search, scan for duplicates, export the chat, and
        # two for the text size — all the same size and all the same colour, so
        # the two that get used every day sat in a wall of six that do not.
        # Housekeeping goes behind one button; nothing is taken away.
        self.more = tk.Menubutton(media_bar, text="⋯ More", relief="flat",
                                  bg=colour["field"], fg=colour["ink"],
                                  activebackground=colour["panel"],
                                  activeforeground=colour["ink"],
                                  padx=10, pady=4, font=("Segoe UI", 9),
                                  cursor="hand2")
        self.more_menu = tk.Menu(self.more, tearoff=0, bg=colour["panel"],
                                 fg=colour["ink"], activebackground=colour["field"],
                                 activeforeground=colour["ink"],
                                 font=("Segoe UI", 9))
        self.more_menu.add_command(label="📥 Export this chat",
                                   command=self.export_chat_action)
        self.more_menu.add_command(label="🔍 Scan for duplicate images",
                                   command=self.scan_duplicates_action)
        self.more_menu.add_separator()
        self.more_menu.add_command(label="■ Stop / Resume Runner",
                                   command=self.stop_action)
        self.more_menu.add_command(label="🗺️ RAPTOR System Map",
                                   command=self.open_raptor_map_action)
        self.more_menu.add_command(label="🛠️ Toggle Developer Tools Panel",
                                   command=self.toggle_tools_panel_action)
        self.more_menu.add_separator()
        self.more_menu.add_command(label="Bigger text",
                                   command=lambda: self.adjust_font_size(1))
        self.more_menu.add_command(label="Smaller text",
                                   command=lambda: self.adjust_font_size(-1))
        self.more.configure(menu=self.more_menu)
        self.more.pack(side="right", padx=(2, 0))


        # Input Row
        row = tk.Frame(main_chat, bg=colour["page"], padx=16, pady=8)
        row.pack(fill="x")
        self.said = tk.Text(row, height=3, wrap="word", bg=colour["field"],
                            fg=colour["ink"], insertbackground=colour["ink"],
                            relief="flat", font=("Segoe UI", 11))
        self.said.pack(side="left", fill="x", expand=True)
        self.said.bind("<Return>", self._on_return)
        try:
            self.said.focus_set()
        except Exception:  # Intention: keyboard focus is a nicety; the entry box still works without it.
            pass

        buttons = tk.Frame(row, bg=colour["page"])
        buttons.pack(side="left", padx=(10, 0))
        self.btn_send = tk.Button(buttons, text="Send", command=self.send, relief="flat",
                  bg=colour["blue"], fg=colour["page"], padx=16, pady=8,
                  font=("Segoe UI", 10, "bold"), cursor="hand2")
        self.btn_send.pack(fill="x")

        self.note = tk.Label(main_chat, text="", bg=colour["page"], fg=colour["quiet"],
                             anchor="w", padx=16, font=("Segoe UI", 9))
        self.note.pack(fill="x", pady=(0, 6))

        # Intention: AND IT SAYS WHERE IT STANDS, ONCE A SECOND, FOR EVER. The
        # badge said "Ready" once when the window opened and never changed
        # again, so a machine thinking for four minutes and a machine that had
        # died looked identical. A person who cannot tell those apart closes
        # the program, which is exactly what happened.
        self._tick()

    # -- sidebar helpers -----------------------------------------------------

    def _get_project_names(self) -> list[str]:
        """Intention: the project names for the side list: the held list, or the folders under projects/."""
        if self._project_names:
            return self._project_names
        proj_dir = self.root_dir / "projects"
        if proj_dir.is_dir():
            return sorted([d.name for d in proj_dir.iterdir() if d.is_dir() and not d.name.startswith((".", "_"))])
        return []

    @_on_ui
    def _refresh_projects_list(self, tk=None, colour=None) -> None:
        """Intention: redraw the side list of projects, one button each that selects that project."""
        if self.projects_frame is None:
            return
        for child in self.projects_frame.winfo_children():
            child.destroy()
        c = colour or self._colour or colours()
        import tkinter as _tk
        for name in self._get_project_names():
            b = _tk.Button(self.projects_frame, text=f"📂 {name}", anchor="w",
                           command=lambda n=name: self.select_project(n),
                           relief="flat", bg=c["panel"], fg=c["ink"],
                           activebackground=c["field"], activeforeground=c["blue"],
                           font=("Segoe UI", 9), padx=6, pady=2, cursor="hand2")
            b.pack(fill="x", pady=1)

    def _on_search_focus_in(self, event=None) -> None:
        """Intention: clear the filter placeholder text when the box gets focus."""
        if self.search_entry and self.search_entry.get() == "🔍 Filter chats...":
            self.search_entry.delete(0, "end")

    def _on_search_focus_out(self, event=None) -> None:
        """Intention: put the filter placeholder text back when the box is left empty."""
        if self.search_entry and not self.search_entry.get().strip():
            self.search_entry.delete(0, "end")
            self.search_entry.insert(0, "🔍 Filter chats...")

    def _focus_search(self, event=None) -> str:
        """Intention: the key shortcut for the chat filter: focus it and clear or select its text."""
        if getattr(self, "search_entry", None):
            self.search_entry.focus_set()
            if self.search_entry.get() == "🔍 Filter chats...":
                self.search_entry.delete(0, "end")
            else:
                self.search_entry.select_range(0, "end")
        return "break"

    def _on_escape(self, event=None) -> str:
        """Back out of whatever is in front of you.

        Intention: AND STOPPING COMES FIRST. Andrew closed the whole program
        six times on 2026-09-12 to get out of jobs he did not want. Escape is
        the key a person already presses to make something stop; when something
        is actually running, that is what it should do.
        """
        if getattr(self, "_game_play_active", False):
            self.stop_interactive_game_action()
            return "break"
        if getattr(self, "_busy", False) and not self.halt.raised():
            self.stop_action()
            return "break"
        if self.proposal:
            self.refuse()
        elif self.said:
            self.said.delete("1.0", "end")
        return "break"

    @_on_ui
    def _refresh_chats_list(self, tk=None, colour=None) -> None:
        """Intention: redraw the chat list: the current chat first, then the archived chats that match the filter."""
        if self.chats_frame is None:
            return
        for child in self.chats_frame.winfo_children():
            child.destroy()
        c = colour or self._colour or colours()
        import tkinter as _tk

        active_is_current = not getattr(self, "viewing_archive", "")
        active_btn = _tk.Button(self.chats_frame, text="● Current Chat", anchor="w",
                                command=self.show_active_chat, relief="flat",
                                bg=c["field"] if active_is_current else c["panel"],
                                fg=c["blue"] if active_is_current else c["quiet"],
                                activebackground=c["field"], activeforeground=c["blue"],
                                font=("Segoe UI", 9, "bold" if active_is_current else "normal"),
                                padx=6, pady=3, cursor="hand2")
        active_btn.pack(fill="x", pady=(0, 4))
        self.active_chat_btn = active_btn

        query = ""
        if getattr(self, "search_entry", None):
            raw = self.search_entry.get().strip()
            if raw and raw != "🔍 Filter chats...":
                query = raw.lower()

        archives = self.thread.list_archives()
        if query:
            archives = [a for a in archives if query in a.get("title", "").lower() or query in a.get("filename", "").lower()]

        for arch in archives[:35]:
            title = arch["title"]
            arch_path = arch["path"]
            is_viewing = getattr(self, "viewing_archive", "") == arch_path
            row = _tk.Frame(self.chats_frame, bg=c["field"] if is_viewing else c["panel"])
            row.pack(fill="x", pady=1)

            b = _tk.Button(row, text=f"💬 {title}", anchor="w",
                           command=lambda p=arch_path: self.show_archive(p),
                           relief="flat",
                           bg=c["field"] if is_viewing else c["panel"],
                           fg=c["blue"] if is_viewing else c["quiet"],
                           activebackground=c["field"], activeforeground=c["ink"],
                           font=("Segoe UI", 9, "bold" if is_viewing else "normal"),
                           padx=4, pady=2, cursor="hand2")
            b.pack(side="left", fill="x", expand=True)

            del_btn = _tk.Button(row, text="🗑️", anchor="center",
                                 command=lambda p=arch_path: self.delete_archive_action(p),
                                 relief="flat",
                                 bg=c["field"] if is_viewing else c["panel"],
                                 fg=c["warn"],
                                 activebackground=c["field"], activeforeground=c["warn"],
                                 font=("Segoe UI", 8), padx=4, pady=2, cursor="hand2")
            del_btn.pack(side="right")

    def delete_archive_action(self, path: str) -> None:
        """Delete an archived past conversation.

        User intention (Andrew, 2026-09-07):
        "just have a way to delete conversations."
        """
        deleted = self.thread.delete_archive(path)
        if deleted:
            if self.viewing_archive == path:
                self.show_active_chat()
            self._refresh_chats_list()
            self._say(f"deleted archive: {Path(path).name}")
        else:
            self._say("could not delete archive")

    def clear_current_chat(self) -> None:
        """Clear and delete the active conversation immediately without archiving.

        User intention (Andrew, 2026-09-07):
        "just have a way to delete conversations."
        """
        self._busy = False
        if self.viewing_archive:
            self.show_active_chat()
        self.thread.delete_current()
        self._last_turn_sig = None
        self.proposal = None
        self._show_proposal(None)
        if self.said:
            self.said.delete("1.0", "end")
        self._img_refs.clear()
        if self.paper:
            self.paper.configure(state="normal")
            self.paper.delete("1.0", "end")
            self._render_empty_starter_cards()
            self.paper.configure(state="disabled")
        self.refresh(force=True)
        self._say("current conversation cleared")

    # -- The image queue is the work ---------------------------------------
    #
    # Intention: ANDREW, 2026-09-18 — "detach the immediate change that image
    # user stuff works and place that into something that adds to the work
    # instead of acting like a trigger." The window used to keep its own queue
    # file and run its own thread that made each picture here, in the window,
    # beside the loop. Now an ask is written to the inbox and nothing else. The
    # loop passes it to the picture project and makes it on its next pass
    # (warp2/work/side/asked.py); this list is read back from those records.

    def _load_image_queue(self) -> list[dict]:
        """Intention: read where every image ask stands; hide the ones cleared from view."""
        from warp2.ask.image_asks import ImageAsks
        hidden = getattr(self, "_hidden_queue_ids", set())
        try:
            rows = ImageAsks(self.state).rows()
        except Exception:
            rows = []
        self.image_queue = [row for row in rows if row.get("id") not in hidden]
        return self.image_queue

    def enqueue_image_action(self, subject: str) -> dict:
        """Add a picture to the work. Nothing is made here."""
        asked = self._ask_for_image(subject)
        if not asked.get("id"):
            return {}
        self._load_image_queue()
        self._refresh_image_queue_ui()
        return next((row for row in self.image_queue if row.get("id") == asked["id"]),
                    {"id": asked["id"], "subject": asked.get("subject", ""), "status": "pending"})

    def _ask_for_image(self, subject: str, inbox_id: str | None = None) -> dict:
        """Write the ask for a picture to the inbox and say so in the thread."""
        return self._ask_for_media(IMAGE, subject, inbox_id)

    def _ask_for_media(self, kind: str, subject: str, inbox_id: str | None = None) -> dict:
        """Write the ask — a picture, a video or a search & research — to the inbox and say so in the thread.

        Intention: THE ONE PLACE THE WINDOW ASKS FOR ONE. Every button and
        typed command comes here, and nothing is made at the click (Andrew,
        2026-09-18; video and search joined on 2026-10-09, fix 3.7).
        `inbox_id` means it was already put in (an approved proposal), so it
        is not asked for twice.
        """
        from warp2.ask.media import extract_visual_subject
        clean = extract_visual_subject(subject)
        if not clean:
            return {}
        if not inbox_id:
            inbox_id = self.inbox.put(kind, said=clean, about="project:centering_image")["id"]
        what = MEDIA_SAID.get(kind, "a picture")
        self.thread.add(WARP, f"Added {what} of '{clean}' to the work. "
                              "The warp makes it on its next pass and shows it here.",
                        subject=clean, stored=inbox_id)
        self._say(f"asked for {what} of '{clean}'")
        self.refresh()
        return {"status": "asked", "id": inbox_id, "subject": clean, "kind": kind}

    def enqueue_from_sidebar(self) -> dict:
        """Take input from the sidebar image queue entry and add to queue."""
        if not self.image_queue_entry:
            return {}
        val = self.image_queue_entry.get().strip()
        if not val or val == "Image subject...":
            return {}
        self.image_queue_entry.delete(0, "end")
        return self.enqueue_image_action(val)

    def open_image_queue_dialog(self) -> dict:
        """Focus the sidebar queue entry or take pending words from chat entry."""
        words = self.said.get("1.0", "end").strip() if self.said else ""
        if words:
            if self.said:
                self.said.delete("1.0", "end")
            return self.enqueue_image_action(words)
        if self.image_queue_entry:
            self.image_queue_entry.focus_set()
            if self.image_queue_entry.get() == "Image subject...":
                self.image_queue_entry.delete(0, "end")
            return {"status": "focused queue entry"}
        return {}

    def _remove_from_queue_action(self, item_id: str) -> bool:
        """Take back an ask the loop has not reached yet."""
        from warp2.ask.image_asks import ImageAsks
        taken_back = ImageAsks(self.state).cancel(item_id)
        self._load_image_queue()
        self._refresh_image_queue_ui()
        return taken_back

    def _clear_completed_queue_action(self) -> None:
        """Intention: hide finished asks from the list; the records stay."""
        done = {it.get("id") for it in self.image_queue if it.get("status") not in ("pending", "rendering")}
        self._hidden_queue_ids = getattr(self, "_hidden_queue_ids", set()) | done
        self._load_image_queue()
        self._refresh_image_queue_ui()

    @_on_ui
    def _refresh_image_queue_ui(self, tk=None, colour=None) -> None:
        """Render the queue items in the sidebar."""
        if getattr(self, "queue_items_frame", None) is None:
            return
        for child in self.queue_items_frame.winfo_children():
            child.destroy()
        import tkinter as _tk
        c = colour or self._colour or colours()

        if not self.image_queue:
            empty_lbl = _tk.Label(self.queue_items_frame, text="Queue is empty",
                                  bg=c["panel"], fg=c["quiet"], font=("Segoe UI", 8, "italic"))
            empty_lbl.pack(anchor="w", pady=2)
            return

        pending = [it for it in self.image_queue if it.get("status") in ("pending", "rendering")]
        completed = [it for it in self.image_queue if it.get("status") not in ("pending", "rendering")]
        show_items = (pending + completed[:3])[:5]

        for it in show_items:
            st = it.get("status", "pending")
            subj = it.get("subject", "image")[:16]
            it_id = it.get("id")

            row = _tk.Frame(self.queue_items_frame, bg=c["field"], padx=4, pady=2)
            row.pack(fill="x", pady=1)

            icon = "⏳" if st == "pending" else ("⚙️" if st == "rendering" else ("✔" if st == "completed" else "✕"))
            icon_col = c["warn"] if st == "pending" else (c["blue"] if st == "rendering" else (c["good"] if st == "completed" else c["ink"]))

            _tk.Label(row, text=icon, bg=c["field"], fg=icon_col,
                      font=("Segoe UI", 8)).pack(side="left", padx=(0, 3))
            img_p = it.get("image_path")
            has_img = bool(img_p and pictures.is_there(img_p))
            lbl_subj = _tk.Label(row, text=subj, bg=c["field"], fg=c["blue"] if has_img else c["ink"],
                                 font=("Segoe UI", 8, "underline" if has_img else "normal"),
                                 cursor="hand2" if has_img else "arrow", anchor="w")
            lbl_subj.pack(side="left", fill="x", expand=True)
            if has_img:
                lbl_subj.bind("<Button-1>", lambda e, p=img_p: self._view_image(p))
                view_btn = _tk.Button(row, text="👁", command=lambda p=img_p: self._view_image(p),
                                      relief="flat", bg=c["field"], fg=c["blue"],
                                      font=("Segoe UI", 8), padx=2, pady=0, cursor="hand2")
                view_btn.pack(side="right", padx=(2, 0))

            if st == "pending":
                del_btn = _tk.Button(row, text="✕", command=lambda i=it_id: self._remove_from_queue_action(i),
                                     relief="flat", bg=c["field"], fg=c["quiet"],
                                     font=("Segoe UI", 7), padx=2, pady=0, cursor="hand2")
                del_btn.pack(side="right")

        if completed:
            _tk.Button(self.queue_items_frame, text="Clear done",
                       command=self._clear_completed_queue_action,
                       relief="flat", bg=c["panel"], fg=c["quiet"],
                       font=("Segoe UI", 7), padx=2, pady=1, cursor="hand2").pack(anchor="e", pady=(2, 0))

    def _on_queue_entry_focus_in(self, event=None) -> None:
        """Intention: clear the image subject placeholder text when the box gets focus."""
        if self.image_queue_entry and self.image_queue_entry.get() == "Image subject...":
            self.image_queue_entry.delete(0, "end")

    def _on_queue_entry_focus_out(self, event=None) -> None:
        """Intention: put the image subject placeholder text back when the box is left empty."""
        if self.image_queue_entry and not self.image_queue_entry.get().strip():
            self.image_queue_entry.insert(0, "Image subject...")

    # -- Game Testing Arena & Canonical Reference Verification --------------

    def _build_game_panel(self, tk, parent, colour) -> None:
        """Construct the Game Testing Arena panel to the right of conversation.

        Allows testing made games against original canonical references,
        inspecting verification checklists and mathematical match scores,
        and comparing Made Game ASCII vs Original Reference layout.
        """
        header = tk.Frame(parent, bg=colour["panel"])
        header.pack(fill="x", pady=(0, 6))
        tk.Label(header, text="🎮 GAME TESTING ARENA", bg=colour["panel"],
                 fg=colour["blue"], font=("Segoe UI", 11, "bold")).pack(anchor="w")
        tk.Label(header, text="Test made games against canonical originals",
                 bg=colour["panel"], fg=colour["quiet"], font=("Segoe UI", 8)).pack(anchor="w")

        sel_row = tk.Frame(parent, bg=colour["panel"])
        sel_row.pack(fill="x", pady=(4, 6))

        # Intention: the games the warp has CODED (Andrew, 2026-09-18: "make it
        # actually able to code games"), named by their files — listed, not
        # imported, so drawing the panel never runs a game.
        catalog_names = self._coded_game_names() or ["(no coded games yet)"]

        self.game_select_var = tk.StringVar(value=catalog_names[0] if catalog_names else "pac-man")
        self.game_dropdown = tk.OptionMenu(sel_row, self.game_select_var, *catalog_names)
        self.game_dropdown.configure(bg=colour["field"], fg=colour["ink"], relief="flat",
                                     font=("Segoe UI", 8), highlightthickness=0)
        self.game_dropdown.pack(side="left", fill="x", expand=True, padx=(0, 4))

        self.btn_play_game = tk.Button(sel_row, text="🎮 Play", command=self.toggle_game_play_mode,
                                       relief="flat", bg=colour["good"], fg=colour["page"],
                                       font=("Segoe UI", 8, "bold"), padx=8, pady=2, cursor="hand2")
        self.btn_play_game.pack(side="right", padx=(2, 0))

        self.btn_test_game = tk.Button(sel_row, text="▶ Test", command=self.test_game_action,
                                       relief="flat", bg=colour["field"], fg=colour["ink"],
                                       font=("Segoe UI", 8), padx=6, pady=2, cursor="hand2")
        self.btn_test_game.pack(side="right", padx=(2, 0))

        self.btn_random_game = tk.Button(sel_row, text="🎲 Random", command=self.test_random_game_action,
                                         relief="flat", bg=colour["field"], fg=colour["ink"],
                                         font=("Segoe UI", 8), padx=6, pady=2, cursor="hand2")
        self.btn_random_game.pack(side="right")

        # Status & Verification Card
        self.game_status_card = tk.Frame(parent, bg=colour["field"], padx=8, pady=6)
        self.game_status_card.pack(fill="x", pady=(0, 6))

        top_status = tk.Frame(self.game_status_card, bg=colour["field"])
        top_status.pack(fill="x")
        self.lbl_game_title = tk.Label(top_status, text="Game: —", bg=colour["field"],
                                       fg=colour["ink"], font=("Segoe UI", 9, "bold"), anchor="w")
        self.lbl_game_title.pack(side="left", fill="x", expand=True)

        self.lbl_game_score = tk.Label(top_status, text="Score: —", bg=colour["field"],
                                       fg=colour["quiet"], font=("Segoe UI", 9, "bold"))
        self.lbl_game_score.pack(side="right")

        self.lbl_game_outcome = tk.Label(self.game_status_card, text="Eye Autonomous Play: Ready",
                                         bg=colour["field"], fg=colour["quiet"],
                                         font=("Segoe UI", 8), anchor="w", justify="left")
        self.lbl_game_outcome.pack(fill="x", pady=(2, 4))

        # Checklist grid
        chk_grid = tk.Frame(self.game_status_card, bg=colour["field"])
        chk_grid.pack(fill="x", pady=(2, 0))

        self.lbl_chk_player = tk.Label(chk_grid, text="👤 Player: —", bg=colour["field"],
                                       fg=colour["quiet"], font=("Segoe UI", 8))
        self.lbl_chk_player.grid(row=0, column=0, sticky="w", padx=2)

        self.lbl_chk_perimeter = tk.Label(chk_grid, text="🔲 Bounds: —", bg=colour["field"],
                                          fg=colour["quiet"], font=("Segoe UI", 8))
        self.lbl_chk_perimeter.grid(row=0, column=1, sticky="w", padx=4)

        self.lbl_chk_objectives = tk.Label(chk_grid, text="🎯 Objectives: —", bg=colour["field"],
                                           fg=colour["quiet"], font=("Segoe UI", 8))
        self.lbl_chk_objectives.grid(row=1, column=0, sticky="w", padx=2)

        self.lbl_chk_solvable = tk.Label(chk_grid, text="🧩 Solvable: —", bg=colour["field"],
                                         fg=colour["quiet"], font=("Segoe UI", 8))
        self.lbl_chk_solvable.grid(row=1, column=1, sticky="w", padx=4)

        # Dedicated Control Legend & Clickable D-pad Frame
        self._build_game_controls_legend_ui(tk, parent, colour)

        # View tabs
        view_tabs = tk.Frame(parent, bg=colour["panel"])
        view_tabs.pack(fill="x", pady=(4, 2))

        self.btn_view_made = tk.Button(view_tabs, text="🎮 Made Game",
                                       command=lambda: self._switch_game_view("made"),
                                       relief="flat", bg=colour["field"], fg=colour["blue"],
                                       font=("Segoe UI", 8, "bold"), padx=6, pady=2, cursor="hand2")
        self.btn_view_made.pack(side="left", padx=(0, 2))

        self.btn_view_original = tk.Button(view_tabs, text="📜 Original",
                                           command=lambda: self._switch_game_view("original"),
                                           relief="flat", bg=colour["field"], fg=colour["quiet"],
                                           font=("Segoe UI", 8), padx=6, pady=2, cursor="hand2")
        self.btn_view_original.pack(side="left", padx=(0, 2))

        self.btn_view_diff = tk.Button(view_tabs, text="🔍 Diff & Rules",
                                       command=lambda: self._switch_game_view("diff"),
                                       relief="flat", bg=colour["field"], fg=colour["quiet"],
                                       font=("Segoe UI", 8), padx=6, pady=2, cursor="hand2")
        self.btn_view_diff.pack(side="left")

        # Layout ASCII Text Area
        ascii_frame = tk.Frame(parent, bg=colour["field"])
        ascii_frame.pack(fill="both", expand=True, pady=(2, 6))

        scroll = tk.Scrollbar(ascii_frame)
        scroll.pack(side="right", fill="y")
        self.game_ascii_display = tk.Text(ascii_frame, bg=colour["field"], fg=colour["ink"],
                                          relief="flat", font=("Consolas", 9),
                                          wrap="none", height=10,
                                          yscrollcommand=scroll.set)
        self.game_ascii_display.pack(side="left", fill="both", expand=True, padx=4, pady=4)
        scroll.config(command=self.game_ascii_display.yview)

        # Past Verifications Section
        tk.Label(parent, text="📊 PAST VERIFICATIONS (click to view):", bg=colour["panel"],
                 fg=colour["quiet"], font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(2, 1))

        hist_frame = tk.Frame(parent, bg=colour["panel"])
        hist_frame.pack(fill="x", pady=(0, 2))
        hist_scroll = tk.Scrollbar(hist_frame)
        hist_scroll.pack(side="right", fill="y")
        self.game_history_listbox = tk.Listbox(hist_frame, bg=colour["field"], fg=colour["ink"],
                                               relief="flat", font=("Segoe UI", 8),
                                               selectbackground=colour["blue"],
                                               selectforeground=colour["page"],
                                               height=4, yscrollcommand=hist_scroll.set)
        self.game_history_listbox.pack(side="left", fill="x", expand=True)
        hist_scroll.config(command=self.game_history_listbox.yview)
        self.game_history_listbox.bind("<<ListboxSelect>>", self._on_select_past_verification)

        self._refresh_game_verifications_list(tk, colour)
        self._load_latest_verification_or_sample()

    def _coded_game_names(self) -> list:
        """Intention: every coded game file's name, without importing any of them."""
        home = Path(self.root_dir) / "projects" / "game_builder" / "games"
        return sorted(p.stem for p in home.glob("*.py") if not p.name.startswith("_")) if home.is_dir() else []

    def test_game_action(self, game_name: str | None = None) -> dict:
        """Have the learning player take a turn at the chosen coded game, and show it.

        Intention: the turn runs in its own process, like the loop's, because
        the game is code a model wrote; the window only reads the answer.
        """
        chosen = game_name or (self.game_select_var.get() if self.game_select_var else "")
        if not chosen or chosen not in self._coded_game_names():
            self._say("no coded game is chosen — the warp has to code one first")
            return {"status": "no coded game"}
        self._say(f"the player is taking a turn at '{chosen}'...")
        if self.lbl_game_title:
            self.lbl_game_title.configure(text=f"Game: {chosen} (testing...)")
        if self.lbl_game_score:
            self.lbl_game_score.configure(text="Score: ...", fg=self._colour.get("warn", "yellow"))

        def _work():
            """Intention: run the player's turn in its own watched process, read its answer, and show the result."""
            import json as _json
            import sys as _sys
            from warp2.record.children import FINISHED, run_watched
            from projects.game_player.coded_arena import ANSWER
            done = run_watched([_sys.executable, "-m", "projects.game_player.coded_arena",
                                "--root", str(self.root_dir), "--state", str(self.state),
                                "--seconds", "5", "--game", chosen],
                               seconds=90, cwd=str(self.root_dir))
            said = next((_json.loads(line[len(ANSWER):]) for line in reversed(str(done["said"]).splitlines())
                         if line.startswith(ANSWER)), {}) if done["how"] == FINISHED else {}
            if said.get("status") != "played":
                self._say(f"'{chosen}' could not be played: {said.get('refused', {}).get(chosen) or said.get('status') or done['how']}")
                return said
            learned = said.get("learned", {})
            display_dict = {
                "game_name": said["game"], "is_correct": True,
                "score": float(learned.get("win_rate", 0.0)), "theme": "coded",
                "won": said["won"] * 2 >= said["episodes"], "steps": said["episodes"],
                "play_score": said["won"], "details": str(learned.get("resources", {})),
                "verification_details": f"won {said['won']} of {said['episodes']} this turn",
                "reference_copy_path": "",
                "created_copy_path": str(Path(self.root_dir) / "projects" / "game_builder" / "games" / f"{chosen}.py"),
                "final_render": said.get("last_frame", ""),
            }
            self._display_game_verification_result(display_dict)
            self._say(f"'{chosen}': won {said['won']} of {said['episodes']}; "
                      f"{round(100 * float(learned.get('win_rate', 0.0)))}% won over {learned.get('episodes', 0)} games")
            return display_dict

        if self.root is None:
            return _work()
        return self._background(_work)

    def test_random_game_action(self) -> dict:
        """Pick a random game from the catalog and test it against its original reference."""
        import random
        names = self._coded_game_names()
        if not names:
            self._say("no coded game yet — the warp has to code one first")
            return {"status": "no coded game"}
        chosen = random.choice(names)
        if self.game_select_var and hasattr(self.game_select_var, "set"):
            self.game_select_var.set(chosen)
        return self.test_game_action(chosen)

    # -- Interactive Playable Games & Control Legend ------------------------

    def _build_game_controls_legend_ui(self, tk, parent, colour) -> None:
        """Construct the dedicated Control Legend and D-pad interface card."""
        self.game_controls_legend_frame = tk.Frame(parent, bg=colour["field"], padx=8, pady=6)

        head_row = tk.Frame(self.game_controls_legend_frame, bg=colour["field"])
        head_row.pack(fill="x", pady=(0, 4))

        self.lbl_legend_title = tk.Label(
            head_row, text="🎮 PLAY MODE — CONTROLS & LEGEND", bg=colour["field"],
            fg=colour["blue"], font=("Segoe UI", 8, "bold"), anchor="w"
        )
        self.lbl_legend_title.pack(side="left", fill="x", expand=True)

        btn_exit = tk.Button(
            head_row, text="✕ Exit", command=self.stop_interactive_game_action,
            relief="flat", bg=colour["field"], fg=colour["warn"],
            font=("Segoe UI", 7, "bold"), padx=5, pady=1, cursor="hand2"
        )
        btn_exit.pack(side="right", padx=(2, 0))

        btn_rst = tk.Button(
            head_row, text="🔄 Reset", command=self.reset_current_game,
            relief="flat", bg=colour["field"], fg=colour["ink"],
            font=("Segoe UI", 7), padx=5, pady=1, cursor="hand2"
        )
        btn_rst.pack(side="right", padx=(2, 0))

        btn_eye = tk.Button(
            head_row, text="👁 Eye Move", command=self.eye_step_game_action,
            relief="flat", bg=colour["field"], fg=colour["good"],
            font=("Segoe UI", 7), padx=5, pady=1, cursor="hand2"
        )
        btn_eye.pack(side="right", padx=(2, 0))

        # Controls mappings label
        self.lbl_legend_controls = tk.Label(
            self.game_controls_legend_frame,
            text="⌨ Controls: [▲ / W] Up   [▼ / S] Down   [◀ / A] Left   [▶ / D] Right\n"
                 "           [Space] Wait   [R] Restart   [P] Eye Step   [Esc] Exit",
            bg=colour["field"], fg=colour["ink"],
            font=("Consolas", 8), justify="left", anchor="w"
        )
        self.lbl_legend_controls.pack(fill="x", pady=(0, 2))

        # Dynamic entity symbols guide label
        self.lbl_legend_symbols = tk.Label(
            self.game_controls_legend_frame,
            text="Symbols: @ Player | # Wall | $ Coin | ^ Hazard | G Goal",
            bg=colour["field"], fg=colour["quiet"],
            font=("Segoe UI", 8), justify="left", anchor="w"
        )
        self.lbl_legend_symbols.pack(fill="x", pady=(0, 4))

        # On-Screen Clickable D-pad Frame
        self.game_dpad_frame = tk.Frame(self.game_controls_legend_frame, bg=colour["field"])
        self.game_dpad_frame.pack(fill="x", pady=(2, 0))

        dpad_center = tk.Frame(self.game_dpad_frame, bg=colour["field"])
        dpad_center.pack(anchor="center")

        btn_up = tk.Button(
            dpad_center, text="▲", width=3, command=lambda: self.send_game_input("UP"),
            relief="flat", bg=colour["panel"], fg=colour["ink"],
            font=("Segoe UI", 8, "bold"), cursor="hand2"
        )
        btn_up.grid(row=0, column=1, padx=2, pady=1)

        btn_left = tk.Button(
            dpad_center, text="◀", width=3, command=lambda: self.send_game_input("LEFT"),
            relief="flat", bg=colour["panel"], fg=colour["ink"],
            font=("Segoe UI", 8, "bold"), cursor="hand2"
        )
        btn_left.grid(row=1, column=0, padx=2, pady=1)

        btn_wait = tk.Button(
            dpad_center, text="⏸", width=3, command=lambda: self.send_game_input("WAIT"),
            relief="flat", bg=colour["panel"], fg=colour["quiet"],
            font=("Segoe UI", 8), cursor="hand2"
        )
        btn_wait.grid(row=1, column=1, padx=2, pady=1)

        btn_right = tk.Button(
            dpad_center, text="▶", width=3, command=lambda: self.send_game_input("RIGHT"),
            relief="flat", bg=colour["panel"], fg=colour["ink"],
            font=("Segoe UI", 8, "bold"), cursor="hand2"
        )
        btn_right.grid(row=1, column=2, padx=2, pady=1)

        btn_down = tk.Button(
            dpad_center, text="▼", width=3, command=lambda: self.send_game_input("DOWN"),
            relief="flat", bg=colour["panel"], fg=colour["ink"],
            font=("Segoe UI", 8, "bold"), cursor="hand2"
        )
        btn_down.grid(row=2, column=1, padx=2, pady=1)

    def _is_text_entry_focused(self) -> bool:
        """Check whether user focus is inside an active text input widget."""
        if self.root is None:
            return False
        try:
            focused = self.root.focus_get()
            text_entries = [
                getattr(self, "said", None),
                getattr(self, "search_entry", None),
                getattr(self, "image_queue_entry", None),
            ]
            return focused in [w for w in text_entries if w is not None]
        except Exception:
            return False

    def _on_game_nav_key(self, direction: str) -> str | None:
        """Handle directional arrow key when game play is active."""
        if getattr(self, "_game_play_active", False) and not self._is_text_entry_focused():
            self.send_game_input(direction)
            return "break"
        return None

    def _on_game_general_key(self, event) -> str | None:
        """Handle keyboard commands (WASD, Space, R, P, Q) during interactive gameplay."""
        if not getattr(self, "_game_play_active", False):
            return None
        if self._is_text_entry_focused():
            return None

        char = (getattr(event, "char", "") or "").lower()
        keysym = (getattr(event, "keysym", "") or "").lower()

        if char in ("w", "a", "s", "d"):
            dir_map = {"w": "UP", "s": "DOWN", "a": "LEFT", "d": "RIGHT"}
            self.send_game_input(dir_map[char])
            return "break"
        elif keysym in ("space",) or char == " ":
            self.send_game_input("WAIT")
            return "break"
        elif char == "r":
            self.reset_current_game()
            return "break"
        elif char == "p":
            self.eye_step_game_action()
            return "break"
        elif char in ("q",):
            self.stop_interactive_game_action()
            return "break"

        return None

    def toggle_game_play_mode(self) -> None:
        """Toggle interactive gameplay mode on or off for the currently selected game."""
        if getattr(self, "_game_play_active", False):
            self.stop_interactive_game_action()
        else:
            chosen = self.game_select_var.get() if self.game_select_var else "pac-man"
            mode = getattr(self, "_game_view_mode", "made")
            if mode not in ("made", "original"):
                mode = "made"
            self.start_interactive_game_action(chosen, mode=mode)

    def start_interactive_game_action(self, game_name: str | None = None, mode: str = "made") -> dict:
        """Launch an interactive, playable session for the chosen game with control legend."""
        chosen = game_name or (self.game_select_var.get() if self.game_select_var else "")
        # Intention: a CODED game, played by hand; a game that has not passed
        # its check is said so, not faked with a template. "original" is still
        # the reference layout of a classic, played by hand.
        if mode == "original":
            from projects.game_player.interactive import PlayableSession
            session = PlayableSession.from_name_or_canonical(chosen, mode="original", state_dir=str(self.state))
        else:
            from projects.game_player.coded_session import CodedSession
            session = CodedSession.open(self.root_dir, self.state, chosen) if chosen else None
        if session is None:
            self._say(f"'{chosen}' is not a coded game that passed its check yet")
            return {"status": "not playable", "game_name": chosen}
        self._active_session = session
        self._game_play_active = True

        self._show_game_play_ui(session)
        self._say(f"started playable game '{session.game_name}' ({mode.upper()}). Controls: Arrow keys / WASD, Space=Wait, R=Reset, Esc=Exit.")
        return {
            "status": "playing",
            "game_name": session.game_name,
            "mode": mode,
            "score": session.score,
            "steps": session.steps,
        }

    @_on_ui
    def _show_game_play_ui(self, session) -> None:
        """Display control legend, D-pad, and refresh active board display."""
        c = self._colour or colours()
        if self.btn_play_game:
            self.btn_play_game.configure(text="⏹ Stop Play", bg=c["warn"], fg=c["page"])

        if self.game_controls_legend_frame:
            try:
                if self.btn_view_made and hasattr(self.btn_view_made, "master") and self.btn_view_made.master:
                    self.game_controls_legend_frame.pack(fill="x", pady=(0, 6), before=self.btn_view_made.master)
                else:
                    self.game_controls_legend_frame.pack(fill="x", pady=(0, 6))
            except Exception:
                try:
                    self.game_controls_legend_frame.pack(fill="x", pady=(0, 6))
                except Exception:  # Intention: the controls legend is only a display aid; the game still plays if it cannot be shown.
                    pass

        if self.lbl_legend_title:
            self.lbl_legend_title.configure(text=f"🎮 PLAYING: {session.game_name.upper()} ({session.mode.upper()})")

        legend_data = session.get_legend()
        if self.lbl_legend_symbols and "symbols" in legend_data:
            sym_items = [f"{k} {v.split(' ')[0]}" for k, v in sorted(legend_data["symbols"].items())]
            self.lbl_legend_symbols.configure(text="Symbols: " + " | ".join(sym_items))

        self._render_active_game_board()

    def send_game_input(self, action_name: str) -> dict:
        """Apply an input move to the active interactive game session."""
        session = getattr(self, "_active_session", None)
        if not session or not getattr(self, "_game_play_active", False):
            return {"status": "no_active_game"}

        outcome = session.apply_action(action_name)
        self._render_active_game_board()
        return {
            "action": action_name,
            "message": outcome.message,
            "score": session.score,
            "steps": session.steps,
            "won": session.won,
            "terminated": session.terminated,
        }

    def eye_step_game_action(self) -> dict:
        """Have the Eye take an optimal auto-step in the active game."""
        session = getattr(self, "_active_session", None)
        if not session or not getattr(self, "_game_play_active", False):
            return {"status": "no_active_game"}

        outcome = session.eye_step()
        self._render_active_game_board()
        return {
            "action": "eye",
            "message": outcome.message,
            "score": session.score,
            "steps": session.steps,
            "won": session.won,
            "terminated": session.terminated,
        }

    def reset_current_game(self) -> None:
        """Restart the active game session to initial state."""
        session = getattr(self, "_active_session", None)
        if session and getattr(self, "_game_play_active", False):
            session.reset()
            self._render_active_game_board()

    @_on_ui
    def stop_interactive_game_action(self) -> None:
        """Exit playable game mode and restore standard review view."""
        self._game_play_active = False
        self._active_session = None
        c = self._colour or colours()

        if self.btn_play_game:
            self.btn_play_game.configure(text="🎮 Play", bg=c["good"], fg=c["page"])

        if self.game_controls_legend_frame:
            try:
                self.game_controls_legend_frame.pack_forget()
            except Exception:  # Intention: hiding a legend that may already be gone; nothing is lost.
                pass

        if self.lbl_game_outcome:
            self.lbl_game_outcome.configure(
                text="Interactive Play session ended. Click '🎮 Play' to play again.",
                fg=c["quiet"]
            )

    @_on_ui
    def _render_active_game_board(self) -> None:
        """Render board, score, and state to the GUI."""
        session = getattr(self, "_active_session", None)
        if not session:
            return

        c = self._colour or colours()
        st_tag = "🎉 WON!" if session.won else ("💥 GAME OVER" if session.terminated else "Playing...")
        st_fg = c["good"] if session.won else (c["warn"] if session.terminated else c["blue"])

        if self.lbl_game_title:
            self.lbl_game_title.configure(text=f"Game: {session.game_name} ({session.mode})")

        if self.lbl_game_score:
            self.lbl_game_score.configure(
                text=f"Score: {session.score:.1f} (Step {session.steps})",
                fg=st_fg
            )

        if self.lbl_game_outcome:
            self.lbl_game_outcome.configure(
                text=f"Status: {st_tag} — {session.last_message}",
                fg=st_fg
            )

        if self.game_ascii_display:
            try:
                self.game_ascii_display.configure(state="normal")
            except Exception:  # Intention: only unlocks the board box for the write below, which says its own failure.
                pass
            try:
                self.game_ascii_display.delete("1.0", "end")
                self.game_ascii_display.insert("1.0", session.state.render_ascii())
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre._render_active_game_board", exc)
            try:
                self.game_ascii_display.configure(state="disabled")
            except Exception:  # Intention: only locks the board box again; the board is already drawn.
                pass

    @_on_ui
    def _display_game_verification_result(self, result_or_report: dict) -> None:
        """Update the Game Arena status card, checks, and ASCII layouts."""
        name = result_or_report.get("game_name", "Game")
        theme_str = f" [{result_or_report.get('theme')}]" if result_or_report.get("theme") else ""
        if self.lbl_game_title:
            self.lbl_game_title.configure(text=f"{name}{theme_str}")

        score_val = result_or_report.get("score", 1.0)
        pct = int(score_val * 100) if score_val <= 1.0 else int(score_val)
        is_pass = result_or_report.get("is_correct", pct >= 80)
        c = self._colour or colours()
        if self.lbl_game_score:
            status_text = "PASS" if is_pass else "REVIEW"
            self.lbl_game_score.configure(
                text=f"{pct}% {status_text}",
                fg=c["good"] if is_pass else c["warn"]
            )

        if self.lbl_game_outcome:
            if "won" in result_or_report:
                won = result_or_report.get("won", False)
                steps = result_or_report.get("steps", 0)
                pscore = result_or_report.get("play_score", 0.0)
                tag = "WON" if won else "LOST"
                self.lbl_game_outcome.configure(
                    text=f"Eye Autonomous Play: {tag} in {steps} steps (score {pscore})",
                    fg=c["good"] if won else c["quiet"]
                )
            else:
                self.lbl_game_outcome.configure(text=result_or_report.get("details", "")[:60], fg=c["quiet"])

        checks = result_or_report.get("checks", {})
        def _chk_icon(key, fallback=True):
            """Intention: a tick or a cross for one check in the game result."""
            val = checks.get(key, fallback)
            return "✔" if val else "✕"

        if self.lbl_chk_player:
            self.lbl_chk_player.configure(text=f"👤 Player: {_chk_icon('player_present')}")
        if self.lbl_chk_perimeter:
            self.lbl_chk_perimeter.configure(text=f"🔲 Bounds: {_chk_icon('perimeter_sealed')}")
        if self.lbl_chk_objectives:
            self.lbl_chk_objectives.configure(text=f"🎯 Objectives: {_chk_icon('objectives_present')}")
        if self.lbl_chk_solvable:
            self.lbl_chk_solvable.configure(text=f"🧩 Solvable: {_chk_icon('solvable_path_exists')}")

        created_p = Path(result_or_report.get("created_copy_path", result_or_report.get("created_copy_file", "")))
        ref_p = Path(result_or_report.get("reference_copy_path", result_or_report.get("reference_file", "")))

        made_layout = result_or_report.get("final_render", "")
        orig_layout = ""

        if created_p.is_file():
            try:
                c_data = json.loads(created_p.read_text(encoding="utf-8"))
                made_layout = c_data.get("ascii_render") or made_layout
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre._display_game_verification_result", exc)

        if ref_p.is_file():
            try:
                r_data = json.loads(ref_p.read_text(encoding="utf-8"))
                orig_layout = r_data.get("canonical_layout") or ""
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre._display_game_verification_result", exc)

        if not orig_layout:
            from projects.game_builder.reference_game import REFERENCE_GAMES_CATALOG
            ref_obj = REFERENCE_GAMES_CATALOG.get(name.lower()) or REFERENCE_GAMES_CATALOG.get(result_or_report.get("slug", ""))
            if ref_obj:
                orig_layout = ref_obj.canonical_layout

        self._current_made_layout = made_layout or "No layout data for made game."
        self._current_original_layout = orig_layout or "No canonical layout found."

        diffs = result_or_report.get("differences", [])
        v_details = result_or_report.get("verification_details", result_or_report.get("details", ""))
        diff_lines = [
            f"=== VERIFICATION COMPARISON: {name} ===",
            f"Score: {pct}% | Result: {'PASS' if is_pass else 'REVIEW'}",
            "",
            "Checks:",
            f" - Player: {_chk_icon('player_present')}",
            f" - Perimeter sealed: {_chk_icon('perimeter_sealed')}",
            f" - Objectives present: {_chk_icon('objectives_present')}",
            f" - Solvable path: {_chk_icon('solvable_path_exists')}",
            f" - Sprites/Theme valid: {_chk_icon('theme_sprites_valid')}",
            "",
            "Details:",
            v_details,
            "",
            "Differences from original specification:" if diffs else "Differences: None (Exact match)"
        ]
        for d in diffs:
            diff_lines.append(f" • {d}")
        self._current_diff_text = "\n".join(diff_lines)

        self._switch_game_view(self._game_view_mode)

    @_on_ui
    def _switch_game_view(self, mode: str) -> None:
        """Switch between Made Game ASCII, Original Reference layout, and Diff/Rules."""
        self._game_view_mode = mode
        c = self._colour or colours()
        if self.btn_view_made:
            self.btn_view_made.configure(
                fg=c["blue"] if mode == "made" else c["quiet"],
                font=("Segoe UI", 8, "bold" if mode == "made" else "normal")
            )
        if self.btn_view_original:
            self.btn_view_original.configure(
                fg=c["blue"] if mode == "original" else c["quiet"],
                font=("Segoe UI", 8, "bold" if mode == "original" else "normal")
            )
        if self.btn_view_diff:
            self.btn_view_diff.configure(
                fg=c["blue"] if mode == "diff" else c["quiet"],
                font=("Segoe UI", 8, "bold" if mode == "diff" else "normal")
            )

        if not self.game_ascii_display:
            return

        text_to_show = ""
        if mode == "made":
            text_to_show = f"--- [MADE GAME LEVEL] ---\n\n{self._current_made_layout}"
        elif mode == "original":
            text_to_show = f"--- [CANONICAL ORIGINAL REFERENCE] ---\n\n{self._current_original_layout}"
        else:
            text_to_show = self._current_diff_text

        self.game_ascii_display.configure(state="normal")
        self.game_ascii_display.delete("1.0", "end")
        self.game_ascii_display.insert("1.0", text_to_show)
        self.game_ascii_display.configure(state="disabled")

    @_on_ui
    def _switch_right_view(self, mode: str) -> None:
        """Switch view modes in the right column: split, confirmations, games, triage, or map."""
        self.right_view_mode = mode
        c = self._colour or colours()
        if self.btn_mode_confirm:
            self.btn_mode_confirm.configure(fg=c["blue"] if mode == "confirmations" else c["quiet"])
        if self.btn_mode_games:
            self.btn_mode_games.configure(fg=c["blue"] if mode == "games" else c["quiet"])
        if self.btn_mode_split:
            self.btn_mode_split.configure(fg=c["blue"] if mode == "split" else c["quiet"])
        if hasattr(self, "btn_mode_triage") and self.btn_mode_triage:
            self.btn_mode_triage.configure(fg=c["blue"] if mode == "triage" else c["quiet"])
        if hasattr(self, "btn_mode_map") and self.btn_mode_map:
            self.btn_mode_map.configure(fg=c["blue"] if mode == "map" else c["quiet"])

        if self.confirm_panel is None or self.game_panel is None:
            return

        self.confirm_panel.pack_forget()
        self.game_panel.pack_forget()
        if hasattr(self, "triage_panel") and self.triage_panel is not None:
            self.triage_panel.pack_forget()
        if hasattr(self, "map_panel") and self.map_panel is not None:
            self.map_panel.pack_forget()

        if mode == "split":
            self.confirm_panel.pack(fill="x", pady=(0, 8))
            self.game_panel.pack(fill="both", expand=True)
        elif mode == "confirmations":
            self.confirm_panel.pack(fill="both", expand=True)
        elif mode == "games":
            self.game_panel.pack(fill="both", expand=True)
        elif mode == "triage":
            if hasattr(self, "triage_panel") and self.triage_panel is not None:
                self.triage_panel.pack(fill="both", expand=True)
                self._refresh_triage_space()
        elif mode == "map":
            if hasattr(self, "map_panel") and self.map_panel is not None:
                self.map_panel.pack(fill="both", expand=True)
                if hasattr(self, "raptor_workspace") and self.raptor_workspace:
                    if hasattr(self.raptor_workspace, "renderer") and self.raptor_workspace.renderer:
                        self.raptor_workspace.renderer.render()

    def _build_map_panel(self, tk, parent, colour) -> None:
        """Construct the embedded RAPTOR Flowchart Environment in the Right Deck."""
        hdr = tk.Frame(parent, bg=colour["panel"])
        hdr.pack(fill="x", pady=(0, 4))
        tk.Label(hdr, text="🗺️ RAPTOR SYSTEM MAP", bg=colour["panel"],
                 fg=colour["blue"], font=("Segoe UI", 9, "bold")).pack(side="left")

        btn_pop = tk.Button(
            hdr, text="↗ Pop Out", command=self.open_raptor_map_action,
            relief="flat", bg=colour["field"], fg=colour["ink"],
            font=("Segoe UI", 8), padx=6, pady=1, cursor="hand2"
        )
        btn_pop.pack(side="right")

        from projects.warp_overview_maps.raptor_workspace import RAPTORWorkspace
        self.raptor_workspace = RAPTORWorkspace(
            parent,
            root_dir=self.root_dir,
            state_dir=self.state,
            theme="classic",
            on_run_click=self.resume_action,
            on_stop_click=self.halt_action,
        )
        self.raptor_workspace.pack(fill="both", expand=True)

    def open_raptor_map_action(self) -> None:
        """Open the authentic RAPTOR Flowchart Environment in a dedicated standalone window."""
        existing = getattr(self, "_raptor_window", None)
        if existing is not None and existing.winfo_exists():
            existing.deiconify()
            existing.lift()
            return
        import tkinter as _tk
        from projects.warp_overview_maps.raptor_workspace import RAPTORWorkspace

        win = _tk.Toplevel(self.root)
        win.title("RAPTOR - [WARP2 Architecture Map]")
        win.geometry("1100x750")
        ws = RAPTORWorkspace(
            win,
            root_dir=self.root_dir,
            state_dir=self.state,
            theme="classic",
            on_run_click=self.resume_action,
            on_stop_click=self.halt_action,
        )
        ws.pack(fill=_tk.BOTH, expand=True)
        self._raptor_window = win
        self._raptor_popup_workspace = ws

    def _build_triage_panel(self, tk, parent, colour) -> None:
        """Construct the Uncertain Images Triage interface panel."""
        hdr = tk.Frame(parent, bg=colour["panel"])
        hdr.pack(fill="x", pady=(0, 4))
        tk.Label(hdr, text="❓ UNCERTAIN IMAGES TRIAGE", bg=colour["panel"],
                 fg=colour["blue"], font=("Segoe UI", 9, "bold")).pack(side="left")
        self.triage_badge = tk.Label(hdr, text="● None", bg=colour["field"],
                                     fg=colour["quiet"], font=("Segoe UI", 8, "bold"), padx=6, pady=1)
        self.triage_badge.pack(side="right")

        tk.Label(parent, text="Automated inspection & concept disambiguation",
                 bg=colour["panel"], fg=colour["quiet"], font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 6))

        # Triage cards container
        self.triage_cards_frame = tk.Frame(parent, bg=colour["panel"])
        self.triage_cards_frame.pack(fill="both", expand=True)

        self.triage_empty_lbl = tk.Label(self.triage_cards_frame,
                                         text="✨ No uncertain images awaiting triage.",
                                         bg=colour["panel"], fg=colour["quiet"],
                                         font=("Segoe UI", 8, "italic"), anchor="w")
        self.triage_empty_lbl.pack(fill="x", pady=4)

    @_on_ui
    def _refresh_triage_space(self) -> None:
        """Update the Uncertain Images Triage space in the Right Deck."""
        if not hasattr(self, "triage_cards_frame") or self.triage_cards_frame is None:
            return

        c = self._colour or colours()
        import tkinter as _tk
        from warp2.ask.image_triage import ImageTriageHandler

        # Clear existing cards
        for ch in list(self.triage_cards_frame.winfo_children()):
            if ch != self.triage_empty_lbl:
                ch.destroy()

        triage = ImageTriageHandler(self.state)
        items = triage.list_uncertain()
        pending = [it for it in items if it.status in ("pending_triage", "analyzed")]

        # Update badge & button text
        if hasattr(self, "triage_badge") and self.triage_badge is not None:
            if pending:
                self.triage_badge.configure(text=f"● {len(pending)} Uncertain", fg=c.get("blue", "#60a5fa"))
            else:
                self.triage_badge.configure(text="● None", fg=c.get("quiet", "#888888"))

        if hasattr(self, "btn_mode_triage") and self.btn_mode_triage is not None:
            self.btn_mode_triage.configure(text=f"❓ Triage ({len(pending)})")

        if not pending:
            if hasattr(self, "triage_empty_lbl") and self.triage_empty_lbl is not None:
                self.triage_empty_lbl.pack(fill="x", pady=4)
            return

        if hasattr(self, "triage_empty_lbl") and self.triage_empty_lbl is not None:
            self.triage_empty_lbl.pack_forget()

        if not hasattr(self, "_triage_thumbs"):
            self._triage_thumbs = []
        self._triage_thumbs.clear()

        for item in pending[:6]:
            p = Path(item.path)
            card = _tk.Frame(self.triage_cards_frame, bg=c["field"], padx=8, pady=8, relief="flat")
            card.pack(fill="x", pady=3)

            # Thumbnail
            if pictures.is_there(p):
                try:
                    from PIL import Image, ImageTk
                    with open_picture(p) as raw:
                        thumb = raw.copy()
                        thumb.thumbnail((50, 50))
                        photo = ImageTk.PhotoImage(thumb, master=self.triage_cards_frame or self.root)
                        self._triage_thumbs.append(photo)
                        img_lbl = _tk.Label(card, image=photo, bg=c["field"], cursor="hand2")
                        img_lbl.pack(side="left", padx=(0, 8))
                        img_lbl.bind("<Button-1>", lambda e, pt=p: self._view_image(pt))
                except Exception as exc:
                    noted("warp2/ask/window.py:ActionCentre._refresh_triage_space", exc)

            info = _tk.Frame(card, bg=c["field"])
            info.pack(side="left", fill="x", expand=True)

            _tk.Label(info, text=f"Initial: {item.initial_subject or p.stem}", bg=c["field"],
                      fg=c["ink"], font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x")

            if item.hypotheses:
                top_hyp = item.hypotheses[0]
                hyp_text = f"Hypothesis: {top_hyp['concept']} ({int(top_hyp['confidence']*100)}%)"
            else:
                hyp_text = "Status: Pending feature analysis"

            _tk.Label(info, text=hyp_text, bg=c["field"], fg=c["blue"],
                      font=("Segoe UI", 8), anchor="w").pack(fill="x")

            btns = _tk.Frame(info, bg=c["field"])
            btns.pack(fill="x", pady=(4, 0))

            if item.hypotheses:
                top_concept = item.hypotheses[0]["concept"]
                _tk.Button(btns, text=f"✓ '{top_concept}'", font=("Segoe UI", 8, "bold"),
                           command=lambda it_id=item.id, c_name=top_concept: self._resolve_triage_action(it_id, c_name),
                           relief="flat", bg=c["panel"], fg=c["good"],
                           cursor="hand2", padx=4, pady=1).pack(side="left", padx=(0, 3))
            else:
                _tk.Button(btns, text="🔍 Analyze", font=("Segoe UI", 8),
                           command=lambda it_id=item.id: self._analyze_triage_action(it_id),
                           relief="flat", bg=c["panel"], fg=c["blue"],
                           cursor="hand2", padx=4, pady=1).pack(side="left", padx=(0, 3))

            _tk.Button(btns, text="🏷️ Tag...", font=("Segoe UI", 8),
                       command=lambda it_id=item.id: self._custom_tag_triage_dialog(it_id),
                       relief="flat", bg=c["panel"], fg=c["ink"],
                       cursor="hand2", padx=4, pady=1).pack(side="left", padx=(0, 3))

            _tk.Button(btns, text="🗑️ Void", font=("Segoe UI", 8),
                       command=lambda it_id=item.id: self._discard_triage_action(it_id),
                       relief="flat", bg=c["panel"], fg=c["warn"],
                       cursor="hand2", padx=4, pady=1).pack(side="left")

    def _resolve_triage_action(self, item_id: str, concept: str, make_positive: bool = True) -> dict:
        """Intention: name an uncertain image as this concept (queued for training) and redraw the triage panel."""
        from warp2.ask.image_triage import ImageTriageHandler
        triage = ImageTriageHandler(self.state)
        res = triage.resolve_uncertain(item_id, concept, make_positive=make_positive, root_dir=self.root_dir)
        self._say(f"resolved uncertain image as '{concept}' (queued for training)")
        self._refresh_triage_space()
        return res

    def _discard_triage_action(self, item_id: str) -> dict:
        """Intention: throw out an uncertain image as a negative example and redraw the triage panel."""
        from warp2.ask.image_triage import ImageTriageHandler
        triage = ImageTriageHandler(self.state)
        res = triage.discard_uncertain(item_id, reason="discarded_by_user", root_dir=self.root_dir)
        self._say(f"discarded uncertain image; marked as negative boundary")
        self._refresh_triage_space()
        return res

    def _analyze_triage_action(self, item_id: str) -> dict:
        """Intention: have the readers look at an uncertain image, say the top guess, and redraw the triage panel."""
        from warp2.ask.image_triage import ImageTriageHandler
        triage = ImageTriageHandler(self.state)
        entry = triage.analyze_image(item_id, root_dir=self.root_dir)
        top = entry.hypotheses[0]["concept"] if entry.hypotheses else "none"
        self._say(f"analyzed uncertain image — top hypothesis: '{top}'")
        self._refresh_triage_space()
        return entry.to_dict()

    def _custom_tag_triage_dialog(self, item_id: str) -> None:
        """Intention: ask the person to type the concept for an uncertain image, then resolve it as that."""
        try:
            from tkinter import simpledialog
            tag = simpledialog.askstring("Resolve Image Concept", "Enter concept or subject for this image:", parent=self.root)
            if tag and tag.strip():
                self._resolve_triage_action(item_id, tag.strip())
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._custom_tag_triage_dialog", exc)

    @_on_ui
    def _refresh_confirmations_space(self) -> None:
        """Update the dedicated Confirmations & Approvals Space."""
        if not hasattr(self, "image_confirm_cards_frame") or self.image_confirm_cards_frame is None:
            return

        c = self._colour or colours()
        import tkinter as _tk

        # Clear existing image confirmation cards
        for ch in list(self.image_confirm_cards_frame.winfo_children()):
            ch.destroy()

        if not hasattr(self, "_confirm_thumbs"):
            self._confirm_thumbs = []
        self._confirm_thumbs.clear()

        # Render cards for each pending image confirmation
        for key, item in list(self.pending_image_confirmations.items()):
            p_str = item.get("path", "")
            p = Path(p_str)
            if not pictures.is_there(p):
                self.pending_image_confirmations.pop(key, None)
                continue

            card = _tk.Frame(self.image_confirm_cards_frame, bg=c["field"], padx=8, pady=8, relief="flat")
            card.pack(fill="x", pady=3)

            img_dims = None
            try:
                from PIL import Image, ImageTk
                with open_picture(p) as raw:
                    img_dims = (raw.width, raw.height)
                    thumb = raw.copy()
                    thumb.thumbnail((56, 56))
                    photo = ImageTk.PhotoImage(thumb, master=self.image_confirm_cards_frame or self.root)
                    self._confirm_thumbs.append(photo)
                    img_lbl = _tk.Label(card, image=photo, bg=c["field"], cursor="hand2")
                    img_lbl.pack(side="left", padx=(0, 8))
                    img_lbl.bind("<Button-1>", lambda e, pt=p: self._view_image(pt))
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre._refresh_confirmations_space", exc)

            info_col = _tk.Frame(card, bg=c["field"])
            info_col.pack(side="left", fill="x", expand=True)

            is_ref = item.get("is_reference")
            rev = item.get("review") or {}
            subj = rev.get("subject") or p.stem

            dims_str = f" • {img_dims[0]}×{img_dims[1]}" if img_dims else ""
            tag_text = f"Reference: {subj}{dims_str}" if is_ref else f"Image: {subj}{dims_str}"
            _tk.Label(info_col, text=tag_text, bg=c["field"], fg=c["ink"],
                      font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x")

            score_str = f"Score: {int(rev.get('reader_score', 0)*100)}%" if rev.get('reader_score') is not None else "Needs review"
            _tk.Label(info_col, text=f"{p.name} • {score_str}", bg=c["field"], fg=c["quiet"],
                      font=("Segoe UI", 8), anchor="w").pack(fill="x")

            btns_row = _tk.Frame(info_col, bg=c["field"])
            btns_row.pack(fill="x", pady=(4, 0))

            if is_ref and rev:
                _tk.Button(btns_row, text="✓ Confirm", font=("Segoe UI", 8, "bold"),
                           command=lambda r=rev: self._confirm_reference_from_panel(r, True),
                           relief="flat", bg=c["panel"], fg=c["good"],
                           activebackground=c["field"], activeforeground=c["good"],
                           cursor="hand2", padx=5, pady=1).pack(side="left", padx=(0, 3))
                _tk.Button(btns_row, text="✕ Reject", font=("Segoe UI", 8),
                           command=lambda r=rev: self._confirm_reference_from_panel(r, False),
                           relief="flat", bg=c["panel"], fg=c["warn"],
                           activebackground=c["field"], activeforeground=c["warn"],
                           cursor="hand2", padx=4, pady=1).pack(side="left", padx=(0, 3))
                _tk.Button(btns_row, text="🤷 I Don't Know", font=("Segoe UI", 8),
                           command=lambda r=rev: self._mark_reference_unknown_from_panel(r),
                           relief="flat", bg=c["panel"], fg=c["blue"],
                           activebackground=c["field"], activeforeground=c["blue"],
                           cursor="hand2", padx=4, pady=1).pack(side="left", padx=(0, 3))
            else:
                _tk.Button(btns_row, text="👍 Confirm & Store", font=("Segoe UI", 8, "bold"),
                           command=lambda pt=p: self._confirm_image_from_panel(pt),
                           relief="flat", bg=c["panel"], fg=c["good"],
                           activebackground=c["field"], activeforeground=c["good"],
                           cursor="hand2", padx=5, pady=1).pack(side="left", padx=(0, 3))
                _tk.Button(btns_row, text="👎 Retrain", font=("Segoe UI", 8),
                           command=lambda pt=p: self._downvote_image_from_panel(pt),
                           relief="flat", bg=c["panel"], fg=c["warn"],
                           activebackground=c["field"], activeforeground=c["warn"],
                           cursor="hand2", padx=4, pady=1).pack(side="left", padx=(0, 3))
                _tk.Button(btns_row, text="🤷 I Don't Know", font=("Segoe UI", 8),
                           command=lambda pt=p: self._mark_image_unknown_from_panel(pt),
                           relief="flat", bg=c["panel"], fg=c["blue"],
                           activebackground=c["field"], activeforeground=c["blue"],
                           cursor="hand2", padx=4, pady=1).pack(side="left", padx=(0, 3))

            _tk.Button(btns_row, text="📁", font=("Segoe UI", 8),
                       command=lambda pt=p: self._open_folder(pt),
                       relief="flat", bg=c["panel"], fg=c["quiet"],
                       cursor="hand2", padx=4, pady=1).pack(side="left")

        # Total pending count
        total_pending = (1 if self.proposal else 0) + len(self.pending_image_confirmations)

        # Update badge
        if hasattr(self, "confirm_badge") and self.confirm_badge is not None:
            if total_pending > 0:
                self.confirm_badge.configure(text=f"● {total_pending} Pending", fg=c.get("good", "#34d399"))
            else:
                self.confirm_badge.configure(text="● None", fg=c.get("quiet", "#888888"))

        if hasattr(self, "btn_mode_confirm") and self.btn_mode_confirm is not None:
            self.btn_mode_confirm.configure(text=f"🖼️ Images ({total_pending})")


        # Empty state label
        if hasattr(self, "confirm_empty_lbl") and self.confirm_empty_lbl is not None:
            if total_pending == 0:
                self.confirm_empty_lbl.pack(fill="x", pady=4)
            else:
                self.confirm_empty_lbl.pack_forget()

        # Update triage tab count
        try:
            from warp2.ask.image_triage import ImageTriageHandler
            u_count = len([it for it in ImageTriageHandler(self.state).list_uncertain() if it.status in ("pending_triage", "analyzed")])
            if hasattr(self, "btn_mode_triage") and self.btn_mode_triage is not None:
                self.btn_mode_triage.configure(text=f"❓ Triage ({u_count})")
            if hasattr(self, "triage_badge") and self.triage_badge is not None:
                if u_count > 0:
                    self.triage_badge.configure(text=f"● {u_count} Uncertain", fg=c.get("blue", "#60a5fa"))
                else:
                    self.triage_badge.configure(text="● None", fg=c.get("quiet", "#888888"))
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._refresh_confirmations_space", exc)

    def _confirm_image_from_panel(self, path: Path | str) -> dict:
        """Intention: the Confirmations panel's yes: take the image off the pending list and confirm it."""
        key1 = str(Path(path).resolve())
        key2 = str(path)
        self.pending_image_confirmations.pop(key1, None)
        self.pending_image_confirmations.pop(key2, None)
        self._refresh_confirmations_space()
        return self._confirm_image_action(path)

    def self_confirm_image_from_panel(self, path: Path | str, score: float = 1.0) -> dict:
        """Self-confirm an image from panel or autonomous pipeline with verified score."""
        key1 = str(Path(path).resolve())
        key2 = str(path)
        self.pending_image_confirmations.pop(key1, None)
        self.pending_image_confirmations.pop(key2, None)
        self._refresh_confirmations_space()
        from warp2.ask.media import self_confirm_image
        res = self_confirm_image(self.root_dir, self.state, path, score=score)
        self._refresh_images_list()
        self._say(f"system self-confirmed image: {Path(path).name}")
        return res

    def _downvote_image_from_panel(self, path: Path | str) -> dict:
        """Intention: the Confirmations panel's no: take the image off the pending list, mark it down and try again."""
        key1 = str(Path(path).resolve())
        key2 = str(path)
        self.pending_image_confirmations.pop(key1, None)
        self.pending_image_confirmations.pop(key2, None)
        self._refresh_confirmations_space()
        return self._downvote_and_retry(path)

    def _mark_image_unknown_from_panel(self, path: Path | str) -> dict:
        """Intention: the panel's do-not-know: take the image off the chat and pending list, and add it to triage."""
        key1 = str(Path(path).resolve())
        key2 = str(path)
        self.pending_image_confirmations.pop(key1, None)
        self.pending_image_confirmations.pop(key2, None)
        self._refresh_confirmations_space()
        try:
            self.thread.remove_image_from_turn(path)
            if self.paper:
                self.refresh(force=True)
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._mark_image_unknown_from_panel", exc)
        from warp2.ask.image_triage import ImageTriageHandler
        triage = ImageTriageHandler(self.state)
        entry = triage.enqueue_uncertain(path, initial_subject=Path(path).stem, kind="generated")
        self._say(f"marked image unknown — added to uncertain triage queue: {Path(path).name}")
        self._refresh_triage_space()
        return entry.to_dict()

    def _confirm_reference_from_panel(self, review: dict, accepted: bool | None) -> dict:
        """Intention: the panel's answer on a reference picture: take it off the pending list and record the answer."""
        p = review.get("path") or review.get("image_path")
        if p:
            self.pending_image_confirmations.pop(str(Path(p).resolve()), None)
            self.pending_image_confirmations.pop(str(p), None)
        self._refresh_confirmations_space()
        return self._confirm_reference(review, accepted)

    def self_confirm_reference_from_panel(self, review: dict) -> dict:
        """Self-confirm a reference image from panel or autonomous pipeline."""
        p = review.get("path") or review.get("image_path")
        if p:
            self.pending_image_confirmations.pop(str(Path(p).resolve()), None)
            self.pending_image_confirmations.pop(str(p), None)
        self._refresh_confirmations_space()
        from warp2.ask.media import self_confirm_reference
        res = self_confirm_reference(self.root_dir, self.state, review)
        self._refresh_images_list()
        self._say(f"system self-confirmed reference: {Path(p).name if p else review.get('id', '')}")
        return res

    def self_confirm_pending(self, threshold: float = 0.70) -> list[dict]:
        """Self-confirm all pending images and references meeting confidence threshold."""
        confirmed = []
        pending = list(self.pending_image_confirmations.items())
        for key, item in pending:
            p = item.get("path")
            if not p or not pictures.is_there(p):
                continue
            is_ref = bool(item.get("is_reference"))
            rev = item.get("review") or {}
            score = rev.get("reader_score")
            if score is not None:
                req_threshold = 1.0 if item.get("is_user_ask") else threshold
                if score >= req_threshold:
                    if is_ref:
                        self.pending_image_confirmations.pop(key, None)
                        res = self.self_confirm_reference_from_panel(rev)
                        confirmed.append({"type": "reference", "path": p, "score": score, "res": res})
                    else:
                        self.pending_image_confirmations.pop(key, None)
                        res = self.self_confirm_image_from_panel(p, score=score)
                        confirmed.append({"type": "image", "path": p, "score": score, "res": res})
            # Intention (2026-10-09, fix 3.5, check B5): a picture no reader
            # scored stays for a person — it was confirmed at a made-up 0.85 or
            # 0.80 under a button that says "reader scores >= 70%".
        if confirmed:
            self._refresh_confirmations_space()
            self._refresh_images_list()
            self._say(f"Self-confirmed {len(confirmed)} image(s) and reference(s)")
        return confirmed

    def _mark_reference_unknown_from_panel(self, review: dict) -> dict:
        """Intention: the panel's do-not-know on a reference: take it off the chat, add it to triage
        and clear its review.
        """
        p = review.get("path") or review.get("image_path")
        if p:
            self.pending_image_confirmations.pop(str(Path(p).resolve()), None)
            self.pending_image_confirmations.pop(str(p), None)
            try:
                self.thread.remove_image_from_turn(p)
                if self.paper:
                    self.refresh(force=True)
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre._mark_reference_unknown_from_panel", exc)
        self._refresh_confirmations_space()
        from warp2.ask.image_triage import ImageTriageHandler
        triage = ImageTriageHandler(self.state)
        entry = triage.enqueue_uncertain(
            p or review.get("id", ""),
            initial_subject=review.get("subject", ""),
            kind="reference",
            review_data=review,
        )
        from warp2.ask.visual import VisualLearning
        try:
            VisualLearning(self.root_dir, self.state).confirm(review.get("id"), None)
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._mark_reference_unknown_from_panel", exc)
        name = Path(p).name if p else review.get("id", "")
        self._say(f"marked reference unknown — added to uncertain triage queue: {name}")
        self._refresh_triage_space()
        return entry.to_dict()

    @_on_ui
    def _refresh_game_verifications_list(self, tk=None, colour=None) -> None:
        """Load recent verifications from disk and display in the history listbox."""
        if getattr(self, "game_history_listbox", None) is None:
            return
        self.game_history_listbox.delete(0, "end")
        self._past_game_reports.clear()

        v_dir = self.state / "games" / "verifications"
        if not v_dir.is_dir():
            return

        files = sorted(v_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:30]
        for f in files:
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                name = data.get("game_name", "Game")
                score = int(data.get("score", 1.0) * 100)
                status = "PASS" if data.get("is_correct", score >= 80) else "REV"
                item_label = f"[{status} {score}%] {name} ({f.name[:18]}...)"
                self.game_history_listbox.insert("end", item_label)
                self._past_game_reports.append(data)
            except Exception:
                continue

    def _on_select_past_verification(self, event=None) -> None:
        """Display verification report selected from past history."""
        if getattr(self, "game_history_listbox", None) is None:
            return
        sel = self.game_history_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx < len(self._past_game_reports):
            report = self._past_game_reports[idx]
            self._display_game_verification_result(report)

    def _load_latest_verification_or_sample(self) -> None:
        """Load the most recent verification report on startup if available."""
        if self._past_game_reports:
            self._display_game_verification_result(self._past_game_reports[0])
        else:
            v_dir = self.state / "games" / "verifications"
            if v_dir.is_dir():
                files = sorted(v_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
                if files:
                    try:
                        data = json.loads(files[0].read_text(encoding="utf-8"))
                        self._display_game_verification_result(data)
                        return
                    except Exception as exc:
                        noted("warp2/ask/window.py:ActionCentre._load_latest_verification_or_sample", exc)
            if self.game_ascii_display:
                self.game_ascii_display.configure(state="normal")
                self.game_ascii_display.delete("1.0", "end")
                self.game_ascii_display.insert("1.0", "No game verifications run yet.\nSelect a game above and click '▶ Test' or '🎲 Random'.")
                self.game_ascii_display.configure(state="disabled")


    @_on_ui
    def _refresh_images_list(self, tk=None, colour=None) -> None:
        """Refresh the sidebar list of recent generated images with thumbnail previews.

        User intention (Andrew, 2026-09-07):
        "make some more things to support created images"
        """
        if getattr(self, "images_frame", None) is None:
            return
        for child in self.images_frame.winfo_children():
            child.destroy()
        c = colour or self._colour or colours()
        import tkinter as _tk
        from warp2.ask.media import list_created_images

        # Quick action: Open images folder
        folder_btn = _tk.Button(self.images_frame, text="📁 Open Images Folder", anchor="w",
                                command=lambda: self._open_folder(self.state / "images"),
                                relief="flat", bg=c["field"], fg=c["blue"],
                                font=("Segoe UI", 8, "bold"), padx=6, pady=2, cursor="hand2")
        folder_btn.pack(fill="x", pady=(0, 2))

        dedup_btn = _tk.Button(self.images_frame, text="🔍 Look for Duplicates", anchor="w",
                               command=self.scan_duplicates_action,
                               relief="flat", bg=c["field"], fg=c["quiet"],
                               font=("Segoe UI", 8), padx=6, pady=2, cursor="hand2")
        dedup_btn.pack(fill="x", pady=(0, 4))

        from warp2.ask.visual import VisualLearning
        learning = VisualLearning(self.root_dir, self.state)
        catalog = list_created_images(self.state, limit=30)
        approved_imgs = [r for r in catalog if learning.approved(r.get('image_path', ''))]
        recent_imgs = (approved_imgs + [r for r in catalog if r not in approved_imgs])[:8]

        if not hasattr(self, "_sidebar_thumbs"):
            self._sidebar_thumbs = []
        self._sidebar_thumbs.clear()

        for entry in recent_imgs:
            subj = entry.get("subject", "image")[:18]
            img_p = entry.get("image_path")
            if not img_p or not pictures.is_there(img_p):
                continue

            try:
                from PIL import Image, ImageTk
                with open_picture(img_p) as raw:
                    dims_str = f"{raw.width}×{raw.height}"
                    thumb_img = raw.copy()
                    thumb_img.thumbnail((24, 24))
                    photo = ImageTk.PhotoImage(thumb_img, master=self.images_frame or self.root)
                    self._sidebar_thumbs.append(photo)

                row = _tk.Frame(self.images_frame, bg=c["panel"])
                row.pack(fill="x", pady=1)

                icon_lbl = _tk.Label(row, image=photo, bg=c["panel"], cursor="hand2")
                icon_lbl.pack(side="left", padx=(2, 4))
                icon_lbl.bind("<Button-1>", lambda e, p=img_p: self._view_image(p))

                btn = _tk.Button(row, text=f"{subj} ({dims_str})", anchor="w",
                                 command=lambda p=img_p: self._view_image(p),
                                 relief="flat", bg=c["panel"], fg=c["ink"],
                                 activebackground=c["field"], activeforeground=c["blue"],
                                 font=("Segoe UI", 8), padx=2, pady=1, cursor="hand2")
                btn.pack(side="left", fill="x", expand=True)
            except Exception:
                btn = _tk.Button(self.images_frame, text=f"🖼️ {subj}", anchor="w",
                                 command=lambda p=img_p: self._view_image(p),
                                 relief="flat", bg=c["panel"], fg=c["ink"],
                                 font=("Segoe UI", 8), padx=6, pady=1, cursor="hand2")
                btn.pack(fill="x", pady=1)

    def _take_image_feed(self, last: int = 20) -> int:
        """Put the machine's newest image reports in the Confirmations panel.

        Intention: Andrew, 2026-09-18 — "the image stuff should not go in the
        conversation unless I have asked for an image in the conversation."
        Practice reports go to the image feed (ask/thread.py `image_feed`);
        this reads its end and puts what still needs his eye in the panel,
        without drawing anything in the chat. Returns how many were added.
        """
        from warp2.ask.thread import image_feed
        before = len(self.pending_image_confirmations)
        for turn in image_feed(self.state).recent(last):
            self._review_from_turn(turn)
        added = len(self.pending_image_confirmations) - before
        if added:
            self._refresh_confirmations_space()
        return added

    def _review_from_turn(self, turn: dict) -> None:
        """Intention: a report's references and picture, into the panel if not yet settled."""
        refs = [Path(p) for p in (turn.get("references") or []) if pictures.is_there(p)]
        image = Path(turn["image"]) if turn.get("image") else None
        if not refs and image is None:
            return
        from warp2.ask.visual import VisualLearning
        learning = VisualLearning(self.root_dir, self.state)
        settled = {str(Path(r["path"]).resolve()).lower() for r in learning.references()
                   if r.get("status") in ("confirmed", "rejected", "unknown")}
        for ref in refs:
            if str(ref.resolve()).lower() in settled:
                continue
            review = next((r for r in turn.get("reference_reviews") or []
                           if Path(r.get("path", "")).name == ref.name), None)
            if review:
                score = review.get("reader_score")
                # Intention (2026-10-09, fix 3.5): the readers must have passed it
                # — a 0.7 with a reader saying the subject is not there was confirmed.
                if review.get("reader_verdict") == "verified" and score is not None and float(score) >= 0.70:
                    try:
                        from warp2.ask.media import self_confirm_reference
                        self_confirm_reference(self.root_dir, self.state, review)
                        continue
                    except Exception as exc:
                        noted("warp2/ask/window.py:ActionCentre._review_from_turn", exc)
                self.pending_image_confirmations.setdefault(
                    str(ref.resolve()), {"path": str(ref), "is_reference": True, "review": review})
        if image is not None and pictures.is_there(image) and not learning.approved(image):
            img_score = (turn.get("evidence") or {}).get("score") if isinstance(turn.get("evidence"), dict) else turn.get("reader_score")
            # User intention (Andrew, 2026-09-27):
            # "when a user ask for something it should not let it go until it can produce it at a 100 from the reader"
            # Intention (2026-10-15, fix 7.7): every reader at 1.0 — the mean
            # alone covers only the readers that answered, so one reader down
            # and the other at 1.0 confirmed the picture.
            from readers import measured_at
            if isinstance(turn.get("evidence"), dict) and measured_at(turn["evidence"], 1.0):
                try:
                    from warp2.ask.media import self_confirm_image
                    self_confirm_image(self.root_dir, self.state, image,
                                       score=float(img_score),
                                       subject=str(turn.get("subject") or ""))
                except Exception:
                    self.pending_image_confirmations.setdefault(
                        str(image.resolve()), {"path": str(image), "is_reference": False, "review": None})
            else:
                self.pending_image_confirmations.setdefault(
                    str(image.resolve()), {"path": str(image), "is_reference": False, "review": None})

    def _view_image(self, path: Path | str):
        """Show one picture large, in its own window, sized to fit the screen.

        Intention: Andrew, 2026-09-18 — "when I click on an image I need to be
        able to see it, in a larger window." Every thumbnail, gallery row and
        Inspect button opens this. It opens at up to 85% of the screen, keeps
        the picture's shape, and follows the window when it is resized. A
        small picture is enlarged with its pixels kept sharp; a large one is
        shrunk smoothly. Escape closes it; the button opens the file in the
        system viewer too.
        """
        p = Path(path)
        if self.root is None or not pictures.is_there(p):
            return None
        import tkinter as _tk
        try:
            from PIL import Image, ImageTk
            with open_picture(p) as raw:
                original = raw.convert("RGBA").copy()
        except Exception as exc:
            self._say(f"could not open {p.name}: {exc}")
            return None
        c = self._colour or colours()
        top = _tk.Toplevel(self.root)
        top.title(f"{p.name} — {original.width}×{original.height} px")
        top.configure(bg=c["page"])
        
        screen_w = max(640, self.root.winfo_screenwidth())
        screen_h = max(480, self.root.winfo_screenheight())
        max_view_w = int(0.85 * screen_w)
        max_view_h = int(0.85 * screen_h)

        # User intention (Andrew, 2026-10-05):
        # "we need the picture it shows be the resolution of what it makes and have it go all the way up to normal resolutions."
        # Open proportionally at native 1:1 resolution when it fits within screen limits,
        # with minimum window dimensions for comfortable button layout.
        init_w = min(original.width, max_view_w)
        init_h = min(original.height, max_view_h)
        top.geometry(f"{max(340, init_w + 20)}x{max(240, init_h + 46)}")

        # Intention: the bar is packed first, at the bottom, so the picture
        # can never squeeze it out of the window.
        bar = _tk.Frame(top, bg=c["page"])
        bar.pack(side="bottom", fill="x")
        picture = _tk.Label(top, bg=c["page"])
        picture.pack(fill="both", expand=True)

        dims_lbl = _tk.Label(bar, text=f"{p.name}  •  {original.width}×{original.height} px",
                             bg=c["page"], fg=c["quiet"], font=("Segoe UI", 9))
        dims_lbl.pack(side="left", padx=8)

        mode_state = {"native": (original.width <= max_view_w and original.height <= max_view_h)}

        def toggle_mode():
            """Intention: switch the image viewer between fit-to-window and 1:1 size, and redraw."""
            mode_state["native"] = not mode_state["native"]
            btn_mode.configure(text="Fit Window" if mode_state["native"] else "1:1 Native")
            draw()

        btn_mode = _tk.Button(bar, text="Fit Window" if mode_state["native"] else "1:1 Native",
                              command=toggle_mode, relief="flat", bg=c["panel"], fg=c["ink"],
                              font=("Segoe UI", 9), cursor="hand2")
        btn_mode.pack(side="right", padx=6, pady=4)

        _tk.Button(bar, text="Open in viewer", command=lambda: self._open_external(p),
                   relief="flat", bg=c["panel"], fg=c["ink"], font=("Segoe UI", 9),
                   cursor="hand2").pack(side="right", padx=6, pady=4)

        def draw(_event=None):
            """Intention: render picture at 1:1 native resolution or fitted to window."""
            room_w, room_h = max(1, picture.winfo_width()), max(1, picture.winfo_height())
            if mode_state["native"]:
                scale = min(1.0, room_w / original.width, room_h / original.height)
            else:
                scale = min(room_w / original.width, room_h / original.height)
            size = (max(1, int(round(original.width * scale))), max(1, int(round(original.height * scale))))
            how = Image.NEAREST if scale >= 1 else Image.LANCZOS
            photo = ImageTk.PhotoImage(original.resize(size, how), master=top)
            picture.configure(image=photo)
            picture.image = photo

        picture.bind("<Configure>", lambda e: top.after_idle(draw))
        top.bind("<Escape>", lambda e: top.destroy())
        top.focus_set()
        return top

    def _open_external(self, path: Path | str) -> None:
        """Open an image, folder, or file in the default system viewer.

        User intention (Andrew, 2026-09-07):
        Allow inspecting created images in high resolution.
        """
        import os
        try:
            os.startfile(str(Path(path).resolve()))
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._open_external", exc)

    def _open_folder(self, path: Path | str) -> None:
        """Open the enclosing folder in Windows File Explorer.

        User intention (Andrew, 2026-09-07):
        Quick access to generated media files on disk.
        """
        import subprocess
        try:
            target = str(Path(path).resolve())
            if Path(target).is_file():
                subprocess.Popen(["explorer", f"/select,{target}"])
            else:
                subprocess.Popen(["explorer", target])
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._open_folder", exc)

    def _confirm_reference(self, review, accepted, button_bar=None):
        """Record explicit reference approval, store the image, remove it from chat, and add it to training.

        User intention (Andrew, 2026-09-08):
        "when I conferm a image it needs to get stored and go away"
        "images still stay in the conversation when I comferm what they are"
        "The images should be removed from the chat"
        "the user interface is not responding" -> runs heavy file I/O in background thread.
        """
        ref_path = review.get("path") or review.get("image_path")
        if ref_path:
            try:
                self.pending_image_confirmations.pop(str(Path(ref_path).resolve()), None)
                self.pending_image_confirmations.pop(str(ref_path), None)
                self._refresh_confirmations_space()
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre._confirm_reference", exc)
        if button_bar is not None:
            try:
                import tkinter as _tk
                for ch in list(button_bar.winfo_children()):
                    ch.destroy()
                c = self._colour or colours()
                if accepted is None:
                    status_text, fg_color = "? Unsure — not used for training", c["quiet"]
                else:
                    status_text = "✓ Stored — added to training" if accepted else "✕ Reference Rejected"
                    fg_color = c["good"] if accepted else c["warn"]
                _tk.Label(button_bar, text=status_text, fg=fg_color,
                          bg=self.paper["bg"] if self.paper else c["panel"],
                          font=("Segoe UI", 8, "bold")).pack(side="left", padx=4)
            except Exception:  # Intention: the button bar may already be gone when the row is redrawn; this label is only a display note.
                pass

        # The visible conversation updates immediately.
        if ref_path:
            try:
                self.thread.remove_image_from_turn(ref_path)
                if self.paper:
                    self.refresh(force=True)
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre._confirm_reference", exc)

        # Intention: Record explicit reference approval, store the image, remove it from chat,
        # and add it to training blocks. Now that the visual-learning ledger keeps samples
        # beside the ledger (2026-09-18), storing is fast and runs directly on the UI thread
        # without Tkinter thread-safety violations or freezes.
        return self._store_reference(review, accepted, ref_path)

    def _store_reference(self, review, accepted, ref_path) -> dict:
        """Intention: the slow half of confirming a reference, on the background worker."""
        # Intention (2026-10-09, fix 3.5, check B11): a confirmed reference is
        # a reference — it is no longer also approved as a picture the Eye made.
        if ref_path and accepted is True:
            from warp2.ask.media import store_reference
            store_reference(self.state, ref_path, subject=review.get("subject", ""))
            self._queue_image_feedback(ref_path, 1.0, subject=review.get("subject", ""))
        from warp2.ask.visual import VisualLearning
        row = VisualLearning(self.root_dir, self.state).confirm(review['id'], accepted)

        self._refresh_images_list()
        name = Path(ref_path).name if ref_path else review.get('id', '')
        outcome = "stored to gallery" if accepted is True else ("marked unknown" if accepted is None else "rejected")
        self._say(f"reference {outcome} & removed from chat: {name}")
        self._say(f"Reference {row.get('status', 'recorded')} for {row.get('subject', review.get('subject', ''))}")
        if self.paper:
            self.refresh(force=True)

        # Ingest into training blocks store for future passes without eager training stall
        if ref_path:
            try:
                from warp2.train.training_blocks import TrainingBlockIngestor
                ingestor = TrainingBlockIngestor(self.state)
                ingestor.ingest_visual(
                    subject=row.get('subject', review.get('subject', '')) or Path(ref_path).stem,
                    status="confirmed" if accepted else "rejected",
                    approved=bool(accepted),
                    rounds=1,
                    reference_path=str(ref_path),
                    reader_score=0.9 if accepted else 0.2,
                )
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre._store_reference", exc)
        return row

    def _confirm_image_action(self, path: Path | str, button_bar=None) -> dict:
        """Explicitly confirm and store an image, saving it to gallery and removing from chat.

        User intention (Andrew, 2026-09-08, 2026-09-17):
        "The images should be removed from the chat"
        "when I conferm a image it needs to get stored and go away"
        "It should also just add to something and not trigger a training at the moment I click the buttons."
        """
        try:
            self.pending_image_confirmations.pop(str(Path(path).resolve()), None)
            self.pending_image_confirmations.pop(str(path), None)
            self._refresh_confirmations_space()
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._confirm_image_action", exc)

        # Close popup preview if open
        if hasattr(self, "_preview_top") and self._preview_top:
            try:
                self._preview_top.destroy()
                self._preview_top = None
            except Exception:  # Intention: closing a preview that may already be closed; nothing is lost.
                pass

        # Handle inline action bar if provided (e.g. from existing turns or tests)
        if button_bar is not None:
            try:
                import tkinter as _tk
                for ch in list(button_bar.winfo_children()):
                    if hasattr(ch, "cget") and ch.cget("text") in ("👍 Confirm & Store", "👍 Good", "👎 Retrain", "🗑️ Remove"):
                        ch.destroy()
                c = self._colour or colours()
                _tk.Label(button_bar, text="✓ Stored to Gallery", fg=c["good"],
                          bg=self.paper["bg"] if self.paper else c["panel"],
                          font=("Segoe UI", 8, "bold")).pack(side="left", padx=4)
            except Exception:  # Intention: the button bar may already be gone when the row is redrawn; this label is only a display note.
                pass

        try:
            self.thread.remove_image_from_turn(path)
            if self.paper and button_bar is None:
                self.refresh(force=True)
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._confirm_image_action", exc)

        # Intention: Storing is decoupled from model training (train=False, 2026-09-17/18)
        # and runs directly on the UI thread, immediately returning the stored entry dictionary
        # and safely updating Tkinter widgets.
        return self._store_confirmed_image(path, button_bar)

    def _store_confirmed_image(self, path, button_bar=None) -> dict:
        """Intention: the slow half of confirming an image, on the background worker."""
        # Intention: MOVED INTO THE KEPT SET, so it closes out of what is
        # waiting (Andrew, 2026-09-25) — and the feedback names where it is now.
        from warp2.ask.media import keep_image
        res = keep_image(self.root_dir, self.state, path)
        self._queue_image_feedback(res.get("image_path") or path, 1.0, subject=res.get("subject", ""))

        self._refresh_images_list()
        self._say(f"image stored to gallery & removed from chat: {Path(path).name}")
        if self.paper and button_bar is None:
            self.refresh(force=True)
        return res

    def _remove_image_action(self, path: Path | str) -> bool:
        """Remove an image from the conversation chat paper, preserving file on disk.

        User intention (Andrew, 2026-09-08):
        "The images should be removed from the chat"
        """
        try:
            self.pending_image_confirmations.pop(str(Path(path).resolve()), None)
            self.pending_image_confirmations.pop(str(path), None)
            self._refresh_confirmations_space()
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._remove_image_action", exc)

        removed = self.thread.remove_image_from_turn(path)
        if self.paper:
            self.refresh(force=True)
        self._say(f"removed image from chat: {Path(path).name}")
        return removed

    def _queue_image_feedback(self, path: Path | str, score: float, subject: str = "") -> str:
        """Add a judgement on a picture to the work. Nothing is trained here.

        Intention: ANDREW, 2026-09-17 — "It should also just add to something
        and not trigger a training at the moment I click the buttons." Two
        records, both cheap: a training block (what the blocks and the Eye
        learn from) and a feedback ask in the inbox, which the loop passes on
        and learns from on its own turn (warp2/work/side/asked.py). Returns the
        block id. A failure to write either is said, not swallowed.
        """
        block_id = ""
        try:
            from warp2.train.training_blocks import TrainingBlockIngestor
            block_id = TrainingBlockIngestor(self.state).ingest_visual(
                subject=subject or Path(path).stem,
                status="confirmed_image" if score > 0 else "downvoted",
                approved=score > 0, rounds=1, reference_path=str(path),
                reader_score=max(0.1, min(1.0, (score + 1.0) / 2.0)))
        except Exception as exc:
            self._say(f"could not record the training block: {exc}")
        try:
            self.inbox.put(FEEDBACK, said=subject or Path(path).stem,
                           about="project:centering_image", path=str(path), score=float(score))
        except Exception as exc:
            self._say(f"could not add the feedback to the work: {exc}")
        return block_id

    def _downvote_and_retry(self, path: Path | str) -> dict:
        """Turn a picture down: learn from it later, and try again later.

        User intention (Andrew, 2026-09-07): "If I down vote an image it should
        train on more data and try again." And 2026-09-17: "It should also just
        add to something and not trigger a training at the moment I click the
        buttons." Both are kept: the downvote is feedback in the work, and a new
        ask for the same subject is put in the work too. The loop does both.
        """
        try:
            self.pending_image_confirmations.pop(str(Path(path).resolve()), None)
            self.pending_image_confirmations.pop(str(path), None)
            self._refresh_confirmations_space()
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._downvote_and_retry", exc)

        try:
            self.thread.remove_image_from_turn(path)
            if self.paper:
                self.refresh(force=True)
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._downvote_and_retry", exc)

        # Ingest as negative boundary training block, and add it to the work.
        subject = self._subject_of(path)
        block_id = self._queue_image_feedback(path, -1.0, subject=subject)
        again = self._ask_for_image(subject)

        self._say(f"downvoted {Path(path).name} — added to training, and asked for it again.")
        return {"status": "downvoted", "path": str(path), "training_block_id": block_id,
                "asked_again": again.get("id", "")}

    def _subject_of(self, path: Path | str) -> str:
        """What a picture was meant to be, from the image catalog, or its file name.

        Intention: a retry asks for the SUBJECT, not the file name — "cat", not
        "cat_attempt_3_20260917".
        """
        from warp2.ask.media import list_created_images
        wanted = str(Path(path).resolve())
        try:
            for row in list_created_images(self.state, limit=200):
                if str(Path(str(row.get("image_path") or "")).resolve()) == wanted and row.get("subject"):
                    return str(row["subject"])
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._subject_of", exc)
        return Path(path).stem

    def select_project(self, name: str) -> None:
        """Focus the session on a specific project.

        User intention (Andrew, 2026-09-07):
        "We also need stuff for past conversations and folders for projects."
        """
        self.active_project = name
        if self.header_sub:
            self.header_sub.configure(text=f"Active Project: {name} (Focus)")
        if self.said:
            self.said.delete("1.0", "end")
            self.said.insert("1.0", f"about project:{name}: ")
        self._say(f"focused on project:{name}")

    def _render_turn(self, turn: dict) -> None:
        """Render a single conversation turn with target banners, references, and actions.

        Intention: Consistent visual representation across live chat and archive browsing,
        displaying real-world reference photos and synthesized Eye model output.
        """
        if not self.paper:
            return
        was_disabled = str(self.paper.cget("state")) == "disabled"
        if was_disabled:
            self.paper.configure(state="normal")
        try:
            self._render_turn_body(turn)
        finally:
            if was_disabled:
                self.paper.configure(state="disabled")

    def _render_turn_body(self, turn: dict) -> None:
        """Intention: draw one shown conversation turn into the chat: who spoke, what was said, and its pictures."""
        who = turn.get("who") or WARP
        said_text = str(turn.get("said") or "")
        # Intention: the machine's own image practice, written into the
        # conversation before 2026-09-18, is not drawn here any more — its
        # pictures go to the Confirmations panel like the image feed's.
        if said_text.startswith(PRACTICE_SAYS):
            self._review_from_turn(turn)
            return

        # Intention (Andrew, 2026-09-22): Detach the chat from background WARP engine functions.
        # The rule lives in turn_is_shown so the one window's chat page uses the same one.
        if not turn_is_shown(turn):
            return

        self.paper.insert("end", f"{'You' if who == ANDREW else 'Assistant'}\n", who)
        self.paper.insert("end", said_text + "\n", who)

        # 1. Real-world reference images to verify what the image is
        ref_list = turn.get("references")
        if not ref_list and turn.get("reference"):
            ref_list = [turn["reference"]]
        if ref_list:
            valid_refs = [Path(p) for p in ref_list if Path(p).is_file()]
            # Filter out references that are already confirmed or rejected in VisualLearning so they go away
            from warp2.ask.visual import VisualLearning
            try:
                learning = VisualLearning(self.root_dir, self.state)
                all_refs = learning.references()
                settled_names = {Path(r['path']).name.lower() for r in all_refs if r.get('status') in ('confirmed', 'rejected')}
                settled_paths = {str(Path(r['path']).resolve()).lower() for r in all_refs if r.get('status') in ('confirmed', 'rejected')}
                active_refs = [p for p in valid_refs if p.name.lower() not in settled_names and str(p.resolve()).lower() not in settled_paths]
            except Exception:
                active_refs = valid_refs

            if active_refs:
                subj = turn.get("subject", "subject")
                hdr = (f"📷 Reference Candidate (please verify '{subj}'):\n"
                       if len(active_refs) == 1 else
                       f"📷 {len(active_refs)} Reference Candidates (please verify '{subj}'):\n")
                self.paper.insert("end", hdr, "grounds")
                for idx, ref in enumerate(active_refs):
                    self.paper.insert("end", f"  • Reference #{idx + 1}: {ref.name}\n", "grounds")
                    review = next((r for r in turn.get("reference_reviews", []) if r.get("path") == str(ref) or Path(r.get("path", "")).name == ref.name), None)
                    if review:
                        r_score = review.get("reader_score")
                        if r_score is not None:
                            pct = int(r_score * 100) if r_score <= 1.0 else int(r_score)
                            badge = f"    👁️ Reader Test: {pct}% ({'✓ Verified' if pct >= 60 else '⚠️ Low Match'})"
                            self.paper.insert("end", badge + "\n", "grounds")
                        if review.get("tags"):
                            tag_prev = ", ".join(review["tags"][:6])
                            self.paper.insert("end", f"    🏷️ Training Tags: {tag_prev}\n", "grounds")
                    self._insert_image(ref, is_reference=True, review=review)

        # Stored references badge (when confirmed and removed from chat to keep transcript clean)
        stored_refs = turn.get("stored_references")
        if stored_refs:
            for s_ref in stored_refs:
                ref_name = Path(s_ref).name
                self.paper.insert("end", f"✓ Stored Reference: {ref_name} (view in sidebar)\n", "grounds")

        # 2. Native Eye Model synthesis image
        if turn.get("image"):
            img_path = Path(turn["image"])
            if img_path.is_file():
                subj = turn.get("subject", "subject")
                att = turn.get("attempt", 1)
                self.paper.insert("end", f"🎨 Native Eye Model Synthesis — Target: '{subj}' (Attempt #{att}):\n", "grounds")
                self._insert_image(img_path, is_reference=False)
        elif turn.get("stored_image"):
            # Image was confirmed and removed from chat to keep transcript clean
            img_name = Path(turn["stored_image"]).name
            self.paper.insert("end", f"✓ Stored to Gallery: {img_name} (view in sidebar)\n", "grounds")

        # 3. Video clip
        if turn.get("video"):
            self._insert_video(Path(turn["video"]))

        # 4. Grounds / context (only shown if developer tools panel is toggled on)
        if turn.get("grounds") and getattr(self, "_dev_tools_visible", False):
            self.paper.insert("end", turn["grounds"] + "\n", "grounds")

        # 5. Turn action bar (Copy to clipboard, timestamp)
        import tkinter as _tk
        c = self._colour or colours()
        turn_bar = _tk.Frame(self.paper, bg=self.paper["bg"])
        _tk.Button(turn_bar, text="📋 Copy", font=("Segoe UI", 8),
                   command=lambda t=turn.get("said", ""): self._copy_to_clipboard(t),
                   relief="flat", bg=c["panel"], fg=c["quiet"],
                   activebackground=c["field"], activeforeground=c["blue"],
                   cursor="hand2", padx=6, pady=1).pack(side="left", padx=(0, 6))
        if turn.get("at"):
            time_label = str(turn["at"])[:19].replace("T", " ")
            _tk.Label(turn_bar, text=time_label, font=("Consolas", 8),
                      fg=c["quiet"], bg=self.paper["bg"]).pack(side="left")
        self.paper.window_create("end", window=turn_bar)
        self.paper.insert("end", "\n\n")

    def _copy_to_clipboard(self, text: str) -> None:
        """Copy message text to the operating system clipboard."""
        if not self.root:
            return
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self._say("copied message to clipboard")
        except Exception as exc:
            noted("warp2/ask/window.py:ActionCentre._copy_to_clipboard", exc)

    def show_archive(self, path: str) -> list:
        """Display turns from an archived past conversation.

        User intention (Andrew, 2026-09-07):
        "We also need stuff for past conversations and folders for projects."
        """
        self.viewing_archive = path
        turns = self.thread.load_archive(path)
        if self.paper is None:
            return turns
        self._img_refs.clear()
        self.paper.configure(state="normal")
        self.paper.delete("1.0", "end")
        self.paper.insert("end", f"--- ARCHIVED CONVERSATION: {Path(path).name} ---\n\n", "grounds")
        for turn in turns:
            self._render_turn(turn)
        self.paper.configure(state="disabled")
        self.paper.see("end")
        if self.header_title:
            self.header_title.configure(text="Past Conversation (Archive)")
        if self.header_sub:
            self.header_sub.configure(text=f"Viewing {Path(path).name} — click '+ New Chat' or 'Current Chat' to return")
        self._refresh_chats_list()
        self._say("viewing archived chat")
        return turns

    def show_active_chat(self) -> None:
        """Switch back from archive view to active chat."""
        self.viewing_archive = ""
        if self.header_title:
            self.header_title.configure(text="Talk to the warp")
        if self.header_sub:
            self.header_sub.configure(text="Ask about a project, say what you want, or generate media.")
        self._refresh_chats_list()
        self.refresh()
        self._say("active chat")

    # -- what the buttons do -------------------------------------------------

    def send(self) -> dict:
        """Take his turn, answer it, and show what came back.

        User intention (Andrew): typing 'yes' or 'no' when a proposal is offered
        acts on the proposal directly, without needing to click the button.
        """
        words = self.said.get("1.0", "end").strip() if self.said else ""
        if not words:
            return {}
        if self.said:
            self.said.delete("1.0", "end")

        if words.lower() in ("/reset", "reset"):
            return self.reset()

        if words.lower() in ("/clear", "clear", "/delete", "delete conversation"):
            self.clear_current_chat()
            return {}

        if self._busy:
            self._say(self._still_busy())
            return {"status": "busy"}
        if self.viewing_archive:
            self.show_active_chat()

        if words.lower() in ("/save", "save", "/snapshot", "save conversation"):
            arch = self.thread.save_session()
            self._refresh_chats_list()
            self._say(f"conversation snapshot saved ({arch.get('turns', 0)} turns)")
            return arch

        if words.lower() in ("/strip_images", "strip images", "/remove_images", "remove images"):
            count = self.strip_images_action()
            return {"status": "images stripped from chat", "stripped": count}

        if words.lower() in ("/duplicates", "duplicates", "find duplicates", "check duplicates", "/dedup"):
            return self.scan_duplicates_action()

        if words.lower() in ("/prune_duplicates", "prune duplicates"):
            return self.prune_duplicates_action()

        if words.lower().startswith(("/search ", "/research ")):
            return self.search_research_action(words)

        if words.lower() in ("/triage", "triage", "/uncertain", "uncertain", "uncertain images"):
            from warp2.ask.image_triage import ImageTriageHandler
            triage = ImageTriageHandler(self.state)
            pending = [it for it in triage.list_uncertain() if it.status in ("pending_triage", "analyzed")]
            if not pending:
                self.thread.add(WARP, "✨ No uncertain images awaiting triage. All images have been confirmed, rejected, or resolved.", grounds="Image Triage Status")
            else:
                lines = [f"❓ Uncertain Images Triage ({len(pending)} pending):"]
                for i, it in enumerate(pending, 1):
                    p_name = Path(it.path).name
                    hyp_str = f" — Top hypothesis: '{it.hypotheses[0]['concept']}' ({int(it.hypotheses[0]['confidence']*100)}%)" if it.hypotheses else " — (pending analysis)"
                    lines.append(f"  {i}. {p_name} (Initial: '{it.initial_subject}') [{it.status}]{hyp_str}")
                lines.append("\nTip: Review and resolve them in the Right Deck '❓ Triage' tab.")
                self.thread.add(WARP, "\n".join(lines), grounds="Image Triage Status")
            self.refresh(force=True)
            self._say(f"{len(pending)} uncertain image(s)")
            return {"status": "triage_reported", "count": len(pending)}

        if self.proposal:
            cleaned = words.strip(" .!").lower()
            if cleaned in ("y", "yes", "sure", "ok", "okay", "yep", "yeah", "do it", "approve", "accept"):
                return self.approve()
            if cleaned in ("n", "no", "nope", "skip", "cancel", "refuse"):
                return self.refuse()

        # Direct media commands (image / video) execute directly without stalling:
        from warp2.ask.talk import detect_image_request, detect_video_request
        from warp2.ask.media import extract_visual_subject
        img_subj = detect_image_request(words)
        if img_subj:
            clean_sub = extract_visual_subject(img_subj)
            self.thread.add(ANDREW, words)
            self.refresh()
            item = self.enqueue_image_action(clean_sub)
            return {"said": f"Added a picture of '{clean_sub}' to the work.", "queue_item": item}

        vid_subj = detect_video_request(words)
        if vid_subj:
            clean_sub = extract_visual_subject(vid_subj)
            self.thread.add(ANDREW, words)
            self.refresh()
            item = self._ask_for_media(VIDEO, clean_sub)
            return {"said": f"Added a video of '{clean_sub}' to the work.", "queue_item": item}

        self.thread.add(ANDREW, words)
        self._say("thinking...")
        self.refresh()
        self._busy = True
        history = self.thread.recent()
        def reply():
            """Wait for the local model without blocking typing or repainting."""
            if self.talk is None:
                self._say("waking up...")
                self.wake(self.root_dir, self.state)
            answer = self.talk.reply(words, history) if self.talk else {
                "said": "nothing is set up to answer yet.", "grounds": "", "proposes": None}

            said_text = str(answer.get("said") or "").strip()
            prop = answer.get("proposes")

            if not said_text and prop:
                said_text = f"Understood. Queued task: {prop.get('words', '')}."
            elif not said_text:
                said_text = "I'm here. How can I help with your projects or work?"

            self.thread.add(WARP, said_text, grounds=answer.get("grounds"))

            self.proposal = prop
            if prop and prop.get("auto_execute"):
                try:
                    self.approve()
                except Exception as exc:
                    noted("warp2/ask/window.py:ActionCentre.send.reply", exc)
                self.proposal = None
            self._show_proposal(prop)

            self._say("")
            self.refresh()
            return answer
        return self._background(reply)

    @_on_ui
    def adjust_font_size(self, delta: int = 1) -> int:
        """Dynamically scale text and chat fonts across all widgets in the Action Centre."""
        self.font_size = max(9, min(28, getattr(self, "font_size", 11) + delta))
        if self.paper:
            try:
                self.paper.configure(font=("Segoe UI", self.font_size))
                self.paper.tag_configure(ANDREW, font=("Segoe UI", self.font_size, "bold"))
                self.paper.tag_configure(WARP, font=("Segoe UI", self.font_size))
                self.paper.tag_configure("grounds", font=("Consolas", max(8, self.font_size - 2)))
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre.adjust_font_size", exc)
        if self.said:
            try:
                self.said.configure(font=("Segoe UI", self.font_size))
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre.adjust_font_size", exc)

        if self.root:
            import tkinter.font as tkFont
            def _scale_widget(w):
                """Intention: change the font size of this widget and all inside it, except the chat
                and the entry box.
                """
                if w not in (self.paper, self.said):
                    try:
                        font_spec = w.cget("font")
                        if font_spec:
                            actual = tkFont.Font(font=font_spec).actual()
                            fam = actual.get("family", "Segoe UI")
                            sz = actual.get("size", 10)
                            wt = actual.get("weight", "normal")
                            new_sz = max(7, min(32, sz + delta))
                            w.configure(font=(fam, new_sz, wt))
                    except Exception:  # Intention: many widgets have no font option at all; those are simply left as they are.
                        pass
                for ch in w.winfo_children():
                    _scale_widget(ch)
            try:
                _scale_widget(self.root)
            except Exception as exc:
                noted("warp2/ask/window.py:ActionCentre.adjust_font_size", exc)

        self._say(f"Font size: {self.font_size} pt")
        return self.font_size

    def generate_image_action(self) -> dict:
        """Generate a picture by adding it to the queue or running in headless test.

        User intention:
        "detach the image user input for images into something that gets added to a que"
        And 2026-09-18: it adds to the work; the loop makes it.
        """
        words = self.said.get("1.0", "end").strip() if self.said else ""
        if not words:
            return self.open_image_queue_dialog()
        if self.said:
            self.said.delete("1.0", "end")
        self.thread.add(ANDREW, f"make a picture of {words}")
        self.refresh()
        return self.enqueue_image_action(words)

    def generate_video_action(self) -> dict:
        """Generate an animated video clip from the current prompt.

        User intention (Andrew, 2026-09-07):
        "add some functions for image and video generation to the user interface"
        """
        words = self.said.get("1.0", "end").strip() if self.said else ""
        if not words:
            self._say("type a subject in the box below, then click Make Video")
            return {}
        if self.said:
            self.said.delete("1.0", "end")
        self.thread.add(ANDREW, f"make a video of {words}")
        self.refresh()
        return self._ask_for_media(VIDEO, words)

    def approve(self) -> dict:
        """Store what was offered, in his words, through the inbox."""
        offered = self.proposal
        if not offered:
            return {}
        kind = offered["kind"]
        if kind == IMAGE:
            made = self.inbox.put(IMAGE, said=offered["words"], about=offered["about"])
            self._ask_for_image(offered["words"], inbox_id=made["id"])
            self._load_image_queue()
            self._refresh_image_queue_ui()
        elif kind == VIDEO:
            made = self.inbox.put(VIDEO, said=offered["words"], about=offered["about"])
            self._ask_for_media(VIDEO, offered["words"], inbox_id=made["id"])
        elif kind == PROJECT:
            made = self.inbox.put(PROJECT, said=offered["words"], about=offered["about"])
            self.thread.add(WARP, f"Started project: \"{offered['about']}\" for \"{offered['words']}\".",
                            stored=made["id"])
            self._refresh_projects_list()
        else:
            inbox_kind = COMMENT if kind in (INTENTION, COMMENT) else PROJECT
            made = self.inbox.put(inbox_kind, said=offered["words"], about=offered["about"])
            self.thread.add(WARP, f"Stored: \"{offered['words']}\" on {offered['about']}.",
                            stored=made["id"])

            # In live GUI, actively take autonomous engineering steps to make said change or create said thing
            if self.root is not None:
                self._take_steps_for_intention(offered.get("about", ""), offered.get("words", ""), made["id"])

        if self.talk and getattr(self.talk, "personality", None):
            self.talk.personality.observe("andrew", "yes", action="approve")
        # Intention: the turn was what was offered — the action model learns it.
        if self.talk and hasattr(self.talk, "turn_heard"):
            self.talk.turn_heard(kind)

        self._show_proposal(None)
        self.refresh()
        self._say("stored — taking steps to make the change...")
        return made

    def _take_steps_for_intention(self, about: str, words: str, inbox_id: str) -> None:
        """Actively take autonomous engineering steps to make the desired change or create the requested thing."""
        def _work():
            """Intention: the background job: take the stored intention into the store, find its target
            and act on it.
            """
            target_str = str(about or "").strip()
            words_str = str(words or "").strip()
            self._say(f"taking steps: '{words_str[:30]}...'")

            try:
                from warp2.store.store import Store, store_home
                from warp2.store.projects import Projects
                from warp2.store.questions import Questions
                from warp2.work.queue import WorkQueue
                from warp2.ask.taking import Taking
                from warp2.run import build as build_loop

                store = Store(store_home(self.state), run="step_exec")
                projects = Projects(store, self.root_dir)
                queue = WorkQueue(store)
                questions = Questions(store)
                taking = Taking(store, projects, questions, queue, self.state)

                # Step 1: Ingest intention into store and Overgraph
                took_report = taking.take()
                target_subject, py_file = taking._resolve_target(target_str, words_str)
                resolved_target = py_file or target_str
                self._say(f"Applying intention for {resolved_target}...")

                # Step 2: Formulate work item
                work_item_id = f"work:revise:{resolved_target}" if (resolved_target and resolved_target.endswith(".py")) else f"work:build:{resolved_target}"

                # Step 3: Run autonomous execution pass
                loop = build_loop(self.root_dir, self.state, run_id="action_centre_step")
                pass_report = loop.pass_once(index=False)

                # Step 4: Report outcome cleanly
                proved = pass_report.get("proved") or {}
                if proved.get("passed"):
                    self.thread.add(WARP, f"✓ I have updated {resolved_target} and verified tests. All changes applied successfully!")
                elif proved.get("reconstituted"):
                    self.thread.add(WARP, f"⚙️ Began work on {resolved_target} for: \"{words_str}\". Tests did not pass on this pass — keeping the task open in the background to continue until it passes.")
                else:
                    self.thread.add(WARP, f"⚙️ Started work on {resolved_target} for: \"{words_str}\". Continuing until it passes.")
                self.refresh(force=True)
            except Exception as exc:
                self.thread.add(WARP, f"Could not complete changes: {exc}")
                self.refresh()
            finally:
                self._say("ready")

        self._background(_work)

    def refuse(self) -> dict:
        """Turn down what was offered, and keep that it was turned down."""
        offered = self.proposal
        if not offered:
            return {}
        if self.talk and getattr(self.talk, "personality", None):
            self.talk.personality.observe("andrew", "no", action="refuse")
        # Intention: he did not want it acted on, so it was talk.
        if self.talk and hasattr(self.talk, "turn_heard"):
            self.talk.turn_heard("talk")
        self.thread.add(ANDREW, "no", refused=offered["words"])
        self._show_proposal(None)
        self.refresh()
        return offered

    def add_a_file(self) -> list:
        """Copy files he picked into the inbox, with whatever he was saying."""
        from tkinter import filedialog
        chosen = filedialog.askopenfilenames(title="Add files or images")
        words = self.said.get("1.0", "end").strip() if self.said else ""
        made = []
        for path in chosen or ():
            made.append(self.inbox.put_file(path, said=words))
            self.thread.add(ANDREW, f"[added {Path(path).name}]"
                                    + (f" — {words}" if words else ""))
        if made:
            self.refresh()
            self._say(f"kept {len(made)} file(s)")
        return made

    def reset(self) -> dict:
        """Reset the conversation thread, auto-saving history to archive, and clear transcript.

        User intention (Andrew, 2026-09-07):
        "we need to have it always save the conversation and just have a way to delete conversations."
        "when I make a new conversation it should clear out the old"
        """
        self._busy = False
        result = self.thread.reset()
        self.viewing_archive = ""
        self._last_turn_sig = None
        self.proposal = None
        self._show_proposal(None)
        if self.said:
            self.said.delete("1.0", "end")
        self._img_refs.clear()
        if self.paper:
            self.paper.configure(state="normal")
            self.paper.delete("1.0", "end")
            self._render_empty_starter_cards()
            self.paper.configure(state="disabled")
        if self.header_title:
            self.header_title.configure(text="Talk to the warp")
        if self.header_sub:
            self.header_sub.configure(text="New conversation started. Ask about a project or generate media.")
        self._refresh_chats_list()
        msg = f"saved past conversation ({result.get('turns', 0)} turns)" if result.get("archived") else "fresh conversation started"
        self._say(msg)
        return result

    # -- showing it ----------------------------------------------------------

    @_on_ui
    def refresh(self, force: bool = False) -> list:
        """Draw the conversation as it stands on disk."""
        if self.viewing_archive:
            return []
        turns = self.thread.recent()
        if self.paper is None:
            return turns
        sig = len(turns)
        if not force and getattr(self, "_last_turn_sig", None) == sig:
            return turns
        self._last_turn_sig = sig
        self._img_refs.clear()
        self.paper.configure(state="normal")
        self.paper.delete("1.0", "end")
        if not turns:
            self._render_empty_starter_cards()
        else:
            for turn in turns:
                self._render_turn(turn)
        self.paper.configure(state="disabled")
        self.paper.see("end")
        return turns

    def _render_empty_starter_cards(self) -> None:
        """Display welcoming interactive starter prompt cards when chat is blank."""
        if not self.paper:
            return
        import tkinter as _tk
        c = self._colour or colours()

        container = _tk.Frame(self.paper, bg=c["page"], pady=24)

        header = _tk.Label(container, text="💬 How can I help you today?",
                          bg=c["page"], fg=c["blue"], font=("Segoe UI", 16, "bold"))
        header.pack(anchor="center", pady=(0, 4))

        sub = _tk.Label(container, text="Ask a question, brainstorm ideas, or generate images and videos.\nPick a suggestion below or type in the box.",
                        bg=c["page"], fg=c["quiet"], font=("Segoe UI", 9), justify="center")
        sub.pack(anchor="center", pady=(0, 16))

        cards_grid = _tk.Frame(container, bg=c["page"])
        cards_grid.pack(anchor="center")

        def _apply_prompt(text: str):
            """Intention: put a starter card's text in the entry box, ready to send."""
            if self.said:
                self.said.delete("1.0", "end")
                self.said.insert("1.0", text)
                self.said.focus_set()
                self.said.mark_set("insert", "end")

        starter_items = [
            ("🎨 Generate Image", "Create an image with the neural eye", "Generate an image of "),
            ("🎥 Make Video", "Synthesize a short video clip", "Make a video of "),
            ("🔎 Search & Research", "Multi-source visual & concept research", "/search "),
            ("💡 Brainstorm Ideas", "Explore and discuss new concepts", "Let's brainstorm ideas for "),
        ]

        for i, (title, desc, prompt) in enumerate(starter_items):
            row_idx = i // 2
            col_idx = i % 2
            card = _tk.Frame(cards_grid, bg=c["panel"], bd=1, relief="solid", padx=14, pady=10)
            card.grid(row=row_idx, column=col_idx, padx=6, pady=6, sticky="nsew")

            t_lbl = _tk.Label(card, text=title, bg=c["panel"], fg=c["ink"],
                             font=("Segoe UI", 9, "bold"), anchor="w", cursor="hand2")
            t_lbl.pack(fill="x", anchor="w")
            d_lbl = _tk.Label(card, text=desc, bg=c["panel"], fg=c["quiet"],
                             font=("Segoe UI", 8), anchor="w", cursor="hand2")
            d_lbl.pack(fill="x", anchor="w", pady=(2, 0))

            def _on_enter(event, w=card, tl=t_lbl, dl=d_lbl):
                """Intention: light up a starter card while the mouse is over it."""
                w.configure(bg=c["field"])
                tl.configure(bg=c["field"])
                dl.configure(bg=c["field"])

            def _on_leave(event, w=card, tl=t_lbl, dl=d_lbl):
                """Intention: put a starter card back to its plain colour when the mouse leaves."""
                w.configure(bg=c["panel"])
                tl.configure(bg=c["panel"])
                dl.configure(bg=c["panel"])

            for widget in (card, t_lbl, d_lbl):
                widget.bind("<Button-1>", lambda e, p=prompt: _apply_prompt(p))
                widget.bind("<Enter>", _on_enter)
                widget.bind("<Leave>", _on_leave)

        self.paper.insert("end", "\n")
        self.paper.window_create("end", window=container)
        self.paper.insert("end", "\n\n")

    def export_chat_action(self) -> None:
        """Export the active or viewed conversation to a formatted Markdown file.

        User intention:
        Allow saving, reviewing, and archiving conversations in human-readable Markdown.
        """
        from tkinter import filedialog
        from datetime import datetime

        archive = self.viewing_archive if getattr(self, "viewing_archive", "") else None
        turns = self.thread.load_archive(archive) if archive else self.thread.recent()
        if not turns:
            self._say("no conversation turns to export")
            return

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        prefix = "warp2_archive" if archive else "warp2_chat"
        default_file = f"{prefix}_{stamp}.md"

        save_path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Export Chat as Markdown",
            initialfile=default_file,
            defaultextension=".md",
            filetypes=[("Markdown Document", "*.md"), ("Text Document", "*.txt"), ("All Files", "*.*")]
        )
        if not save_path:
            return

        try:
            content = self.thread.export_markdown(archive)
            Path(save_path).write_text(content, encoding="utf-8")
            self._say(f"exported conversation to {Path(save_path).name}")
        except Exception as exc:
            self._say(f"export failed: {exc}")

    def strip_images_action(self) -> int:
        """Strip all image and reference embeds from active chat, keeping text records.

        User intention (Andrew, 2026-09-08):
        "The images should be removed from the chat"
        """
        count = self.thread.strip_all_images()
        self.refresh(force=True)
        self._say(f"removed {count} image embed(s) from chat — files remain in gallery")
        return count

    @_on_ui
    def toggle_tools_panel_action(self) -> None:
        """Toggle developer tools, game arena, and confirmations panel on/off."""
        if self.right_container is None:
            return
        if self.right_container.winfo_ismapped():
            self.right_container.pack_forget()
            self._say("developer panel hidden")
        else:
            self.right_container.pack(side="right", fill="y")
            self._say("developer panel visible")

    @_on_ui
    def open_games_action(self) -> None:
        """Toggle and display the Game Arena in the Right Deck."""
        if self.right_container is None:
            return
        if not self.right_container.winfo_ismapped():
            self.right_container.pack(side="right", fill="y")
            self._switch_right_view("games")
            self._say("opened Game Arena")
        elif getattr(self, "right_view_mode", "") != "games":
            self._switch_right_view("games")
            self._say("switched to Game Arena")
        else:
            self.right_container.pack_forget()
            self._say("closed Game Arena")


    def scan_duplicates_action(self, sync: bool = False) -> dict:
        """Scan state images and references for exact and perceptual near-duplicates.

        User intention (Andrew, 2026-09-08):
        "there needs to be a system to look for ducplicates"
        """
        if self._busy:
            self._say(self._still_busy())
            return {"status": "busy"}
        self._busy = True
        self._say("🔍 Scanning stored images for exact and visual near-duplicates...")

        def _scan():
            """Intention: the scan itself: find exact and near-duplicate images in the state folders
            and show a report.
            """
            try:
                from warp2.ask.dedup import ImageDeduplicator
                dedup = ImageDeduplicator(max_distance=5)
                search_dirs = [
                    self.state / "images",
                    self.state / "images" / "references",
                    self.state / "images" / "research",
                ]
                report = dedup.find_duplicates(dirs=search_dirs)

                lines = [
                    "═══════════════════════════════════════════════════════════════",
                    f"🔍 DUPLICATE IMAGE SCAN REPORT ({report['total_scanned']} images scanned)",
                    "═══════════════════════════════════════════════════════════════",
                ]
                exact_g = report.get("exact_duplicate_groups", [])
                near_g = report.get("near_duplicate_pairs", [])

                if not exact_g and not near_g:
                    lines.append("✓ No exact or near-duplicates found in your image collections.")
                else:
                    if exact_g:
                        lines.append(f"\n📁 Exact Duplicate Sets Found: {len(exact_g)}")
                        for i, grp in enumerate(exact_g, 1):
                            lines.append(f"  Set #{i} ({grp['count']} copies, SHA: {grp['sha256'][:12]}):")
                            for item in grp["items"]:
                                lines.append(f"    • {item['name']} ({item['resolution']}, {item['size_bytes']//1024} KB)")

                    if near_g:
                        lines.append(f"\n🖼️ Perceptual Near-Duplicates Found: {len(near_g)} pair(s)")
                        for j, pair in enumerate(near_g, 1):
                            it1, it2 = pair["items"]
                            lines.append(f"  Pair #{j} (Similarity: {pair['similarity']}%, Hamming: {pair['hamming_distance']}):")
                            lines.append(f"    • {it1['name']} ({it1['resolution']}) vs {it2['name']} ({it2['resolution']})")

                    lines.append("\nTip: Type /prune_duplicates to automatically remove exact duplicate files while keeping the highest-resolution copy.")

                report_text = "\n".join(lines)
                self.thread.add(WARP, report_text, grounds="Duplicate image scan report")
                self.refresh(force=True)
                msg = f"found {report['duplicate_count']} duplicate item(s)" if report["has_duplicates"] else "no duplicates found"
                self._say(msg)
                return report
            finally:
                self._busy = False

        if not sync and self.root is not None:
            self._background(_scan)
            return {"status": "scanning in background"}
        return _scan()

    def prune_duplicates_action(self) -> dict:
        """Prune exact duplicate images from disk, keeping the highest resolution copy.

        User intention (Andrew, 2026-09-08):
        "there needs to be a system to look for ducplicates"
        """
        from warp2.ask.dedup import ImageDeduplicator
        dedup = ImageDeduplicator(max_distance=5)
        search_dirs = [self.state / "images", self.state / "images" / "references"]
        report = dedup.find_duplicates(dirs=search_dirs)
        result = dedup.prune_duplicates(report, keep="best_res", dry_run=False)
        self.thread.add(WARP, f"🧹 Pruned {result['removed_count']} exact duplicate file(s) from disk.", grounds="Duplicate prune")
        self._refresh_images_list()
        self.refresh(force=True)
        self._say(f"pruned {result['removed_count']} duplicate(s)")
        return result

    def search_research_action(self, command_line: str = "", sources: list[str] | None = None) -> dict:
        """Execute multi-source visual research on a subject with duplicate suppression.

        User intention (Andrew, 2026-09-08):
        "and we need more options for image search and research."
        "there needs to be a system to look for ducplicates"
        """
        raw = command_line.strip()
        if raw.lower().startswith(("/search ", "/research ")):
            subject = raw.split(" ", 1)[1].strip()
        else:
            subject = self.said.get("1.0", "end").strip() if self.said else ""

        if not subject:
            return self.search_research_dialog_action()
        if self.said:
            self.said.delete("1.0", "end")

        from warp2.ask.media import extract_visual_subject
        clean = extract_visual_subject(subject)
        self.thread.add(ANDREW, f"Search & research: '{clean}'")
        # Intention (2026-10-09, fix 3.7, check B10): added to the work; the loop
        # searches, has the readers look, and shows what it found. `sources`
        # is kept for callers; the loop asks the providers it always does.
        return self._ask_for_media(RESEARCH, clean)

    def search_research_dialog_action(self) -> None:
        """Open an interactive search & research dialog or insert a starter prompt."""
        if not self.root:
            return
        words = self.said.get("1.0", "end").strip() if self.said else ""
        if words:
            self.search_research_action(words)
            return

        from tkinter import simpledialog
        query = simpledialog.askstring("Image Search & Research",
                                       "Enter visual subject or concept to search & research across repositories:",
                                       parent=self.root)
        if query and query.strip():
            self.search_research_action(query.strip())

    def _insert_image(self, path: Path, is_reference: bool = False, review=None) -> None:
        """Render a generated or reference image inline with interactive action controls.

        User intention (Andrew, 2026-09-07):
        "make some more things to support created images"
        "It should also show refrence images that it finds to varifay what the image is"
        Provides buttons for full-size inspection, opening folder, and Eye model training feedback.
        """
        if not path.is_file():
            return
        try:
            dims_note = ""
            try:
                from PIL import Image
                with open_picture(path) as raw:
                    dims_note = f" — {raw.width}×{raw.height} px"
            except Exception:  # Intention: the size is an optional note on the label; the picture is still listed without it.
                pass
            self.paper.insert("end", f"\n[{path.name}]{dims_note}\n")

            import tkinter as _tk
            c = self._colour or colours()
            bar = _tk.Frame(self.paper, bg=self.paper["bg"])
            _tk.Button(bar, text="🔍 Inspect", font=("Segoe UI", 8),
                       command=lambda p=path: self._view_image(p),
                       relief="flat", bg=c["panel"], fg=c["ink"],
                       activebackground=c["field"], activeforeground=c["blue"],
                       cursor="hand2", padx=6, pady=1).pack(side="left", padx=2)
            _tk.Button(bar, text="📁 Folder", font=("Segoe UI", 8),
                       command=lambda p=path: self._open_folder(p),
                       relief="flat", bg=c["panel"], fg=c["ink"],
                       activebackground=c["field"], activeforeground=c["blue"],
                       cursor="hand2", padx=6, pady=1).pack(side="left", padx=2)
            _tk.Button(bar, text="🗑️ Remove", font=("Segoe UI", 8),
                       command=lambda p=path: self._remove_image_action(p),
                       relief="flat", bg=c["panel"], fg=c["quiet"],
                       activebackground=c["field"], activeforeground=c["warn"],
                       cursor="hand2", padx=6, pady=1).pack(side="left", padx=2)
            if is_reference and review:
                # Register in dedicated Confirmation Space outside conversation
                try:
                    key = str(Path(path).resolve())
                    self.pending_image_confirmations[key] = {
                        "path": str(path), "is_reference": True, "review": review
                    }
                    self._refresh_confirmations_space()
                except Exception as exc:
                    noted("warp2/ask/window.py:ActionCentre._insert_image", exc)
                _tk.Label(bar, text="📋 Reference Review (see Confirmations panel)", fg=c["quiet"],
                          bg=self.paper["bg"] if self.paper else c["panel"],
                          font=("Segoe UI", 8, "italic")).pack(side="left", padx=4)
            if not is_reference:
                from warp2.ask.visual import VisualLearning
                is_approved = VisualLearning(self.root_dir, self.state).approved(path)
                if is_approved:
                    _tk.Label(bar, text="✓ Stored to Gallery", fg=c["good"],
                              bg=self.paper["bg"] if self.paper else c["panel"],
                              font=("Segoe UI", 8, "bold")).pack(side="left", padx=4)
                else:
                    # Register in dedicated Confirmation Space outside conversation
                    try:
                        key = str(Path(path).resolve())
                        self.pending_image_confirmations[key] = {
                            "path": str(path), "is_reference": False, "review": None
                        }
                        self._refresh_confirmations_space()
                    except Exception as exc:
                        noted("warp2/ask/window.py:ActionCentre._insert_image", exc)
                    _tk.Label(bar, text="📋 Pending Review (see Confirmations panel)", fg=c["quiet"],
                              bg=self.paper["bg"] if self.paper else c["panel"],
                              font=("Segoe UI", 8, "italic")).pack(side="left", padx=4)
            self.paper.window_create("end", window=bar)
            self.paper.insert("end", "\n\n")
        except Exception:
            self.paper.insert("end", f"[image: {path.name}]\n")

    def _insert_video(self, path: Path) -> None:
        """Render an animated video clip inline with looping playback."""
        if not path.is_file():
            return
        try:
            import tkinter as _tk
            from PIL import Image, ImageTk, ImageSequence
            with open_picture(path) as raw:
                frames = []
                for frame in ImageSequence.Iterator(raw):
                    f = frame.convert("RGBA")
                    f.thumbnail((320, 320))
                    photo = ImageTk.PhotoImage(f, master=self.paper or self.root)
                    frames.append(photo)
                    self._img_refs.append(photo)
                duration = raw.info.get("duration", 125)

            if not frames:
                return

            delay_ms = max(50, min(duration, 500))
            lbl = _tk.Label(self.paper, image=frames[0], bg=self.paper["bg"], bd=0)
            self.paper.window_create("end", window=lbl)
            self.paper.insert("end", f"\n[{path.name} — {len(frames)} frames]\n")

            if len(frames) > 1:
                self._play_animation(lbl, frames, 0, delay_ms)
        except Exception:
            self.paper.insert("end", f"[video: {path.name}]\n")

    def _play_animation(self, label, frames: list, index: int, delay_ms: int) -> None:
        """Loop through animated video frames."""
        try:
            if not label.winfo_exists():
                return
            next_idx = (index + 1) % len(frames)
            label.configure(image=frames[next_idx])
            label.after(delay_ms, lambda: self._play_animation(label, frames, next_idx, delay_ms))
        except Exception:  # Intention: the label can be destroyed between frames when the chat redraws; the animation just ends.
            pass

    @_on_ui
    def _show_proposal(self, offered) -> None:
        """Intention: hold what the model offered and refresh the Confirmations panel; the old pop-up
        card stays hidden.
        """
        self.proposal = offered
        if self.offer is None:
            return
        if not offered:
            self.offer.pack_forget()
            self._refresh_confirmations_space()
            return
        self.offer_words.configure(
            text=f"Store this on {offered.get('about', 'project')}?\n“{offered.get('words', '')}”")
        # Intention (Andrew, 2026-09-22): Detach the chat from WARP storage proposals.
        # Do not pop up proposal cards or force view switches interrupting user conversation.
        self.offer.pack_forget()
        self._refresh_confirmations_space()

    def _on_return(self, event):
        """Intention: Enter sends the message; Shift+Enter is left alone so it makes a new line."""
        if not (event.state & 0x0001):
            self.send()
            return "break"
        return None

    def wake(self, root_dir, state) -> str:
        """Find the store and a model, once the window is already up."""
        if self.talk is not None:
            return ""
        try:
            self.talk = assemble(root_dir, state)
            self._project_names = self.talk.knowing.projects.names()
            self._refresh_projects_list()
        except Exception as exc:
            self.thread.add(WARP, "I cannot reach what I know yet — "
                                  f"{type(exc).__name__}: {exc}. "
                                  "You can still type; it is all kept.")
            self.refresh()
            self._say("could not reach the store — see above")
            return f"{type(exc).__name__}: {exc}"
        self._say("ready")
        if getattr(self, "header_badge", None) is not None:
            c = self._colour or colours()
            self.header_badge.configure(text="● Ready", fg=c.get("good", "#34d399"))
        return ""

    # -- stopping, and saying where it stands --------------------------------

    def stop_action(self) -> dict:
        """Halt the machine. The same authority the cockpit's ALL STOP has.

        Intention: it takes effect before the next action anywhere in the tree
        and kills any child that is running, so it works on a training round
        and an image round alike. It does not close the window, and it does not
        throw away what is already done.
        """
        if self.halt.raised():
            return self.resume_action()
        return self.halt_action()

    def halt_action(self) -> dict:
        """An explicit Stop stays a stop even when pressed a second time."""
        # Intention (2026-10-09, check F3): a kill, like ALL_STOP.bat — the flag,
        # then every process this system owns (warp2/record/all_stop.py).
        from warp2.record.all_stop import halt as all_stop
        said = all_stop(self.state, "stopped from the Action Centre")
        self._say("stopped — press Resume when you want it going again")
        self._standing()
        return said

    def resume_action(self) -> dict:
        """Lift the halt, from every mirror.

        Intention: Andrew has to be able to trust this. A Resume that leaves
        one mirror behind is a machine that stays stopped with nothing on
        screen saying why — see `Halt` in warp2/record/stop.py.
        """
        lifted = self.halt.clear()
        from warp2.ui.runner import start
        try:
            lifted["runner"] = start(self.root_dir, self.state)
            self._say("runner requested")
        except OSError as exc:
            lifted["error"] = str(exc)
            self._say(f"could not start runner: {exc}")
        self._standing()
        return lifted

    @_on_ui
    def _standing(self) -> str:
        """Show whether it is stopped, working, or waiting for you.

        Intention: three states and nothing else, because a person deciding
        whether to wait or to intervene is asking one question. The elapsed
        time is there so a long job never looks like a dead one.
        """
        if self.root is None:
            return ""
        colour = self._colour or colours()
        stopped = False
        try:
            stopped = self.halt.raised()
        except Exception:
            stopped = False
        if stopped:
            self._since = None
            state, tint = "■ Stopped", colour.get("warn", "#f59e0b")
            button, button_tint = "▶ Resume", colour.get("good", "#34d399")
        elif getattr(self, "_busy", False):
            if self._since is None:
                self._since = time.monotonic()
            state = f"● Working{self._doing()} — {self._how_long()}"
            tint = colour.get("blue", "#60a5fa")
            button, button_tint = "■ Stop", colour.get("warn", "#f59e0b")
        else:
            self._since = None
            # Intention: not loaded is not "loading" — it wakes when spoken to.
            state = "● Ready" if self.talk is not None else "● Ready (wakes when you type)"
            tint = colour.get("good", "#34d399")
            button, button_tint = "■ Stop", colour.get("warn", "#f59e0b")
        if getattr(self, "header_badge", None) is not None and state != self._showing:
            self.header_badge.configure(text=state, fg=tint)
        if getattr(self, "btn_halt", None) is not None:
            self.btn_halt.configure(text=button, fg=button_tint)
        self._showing = state
        self._warp_line()
        return state

    def _tick(self) -> None:
        """Say where it stands, once a second, for as long as the window is up.

        Intention: THE TIMER IS OWNED HERE AND NOWHERE ELSE. `_standing` is
        also called straight after a button press, and if that re-armed the
        timer too there would be two clocks after one click, four after two,
        and a window spending itself on its own status line.
        """
        if self.root is None:
            return
        try:
            self._standing()
            self._update_maps()
        finally:
            self.root.after(1000, self._tick)

    def _update_maps(self) -> None:
        """Read telemetry off Tk; both maps consume the same completed snapshot."""
        snapshot = getattr(self, "_map_snapshot", None)
        for name in ("raptor_workspace", "_raptor_popup_workspace"):
            workspace = getattr(self, name, None)
            if snapshot is not None and workspace is not None and workspace.winfo_exists():
                workspace.refresh_live_state(snapshot)
        if getattr(self, "_map_reading", False) or time.monotonic() - getattr(self, "_map_read_at", 0) < 10:
            return
        # Intention: THE MAP IS READ ONLY WHILE A MAP IS SHOWING. It gathered a
        # whole snapshot of the machine every ten seconds for as long as the
        # window was open, whether any map was on screen or not.
        if not any(getattr(self, name, None) is not None and getattr(self, name).winfo_exists()
                   for name in ("raptor_workspace", "_raptor_popup_workspace")):
            return
        self._map_reading = True
        self._map_read_at = time.monotonic()

        def read():
            """Intention: gather the machine snapshot for the map off the window's thread, then mark
            the read as done.
            """
            try:
                from warp2.ui.snapshot import ObserverSnapshot
                self._map_snapshot = ObserverSnapshot(self.root_dir, self.state).gather()
            except Exception as exc:
                self._say(f"map reading failed: {exc}")
            finally:
                self._map_reading = False

        threading.Thread(target=read, name="warp2-action-map", daemon=True).start()

    def _warp_line(self) -> str:
        """Whether the background warp is running, and what it is on.

        Intention: never allowed to be the thing that breaks the window. It
        reads two files a second; if either is mid-write it says so quietly and
        tries again next tick.
        """
        if getattr(self, "lbl_warp_doing", None) is None:
            return ""
        try:
            from warp2.ask.doing import Doing
            words = Doing(self.state).says()
        except Exception:
            words = "Warp: cannot tell just now"
        self.lbl_warp_doing.configure(text=words)
        return words

    def _still_busy(self) -> str:
        """Why a click did nothing, in words that answer the next question.

        Intention: every one of these said "please wait — another operation is
        currently in progress", which tells a person nothing about what to wait
        for or how long, and the top of the window did not tell them either. A
        person who cannot find out closes the program.
        """
        return (f"still working{self._doing()} — {self._how_long()} so far. "
                f"Press Stop at the top if you want it to give up.")

    def _doing(self) -> str:
        """What the job in flight is for, if anything said.

        Intention: the mark a user job already raises so the loop stands down
        carries the words for it. Reusing that is one truth rather than two.
        """
        try:
            from warp2.ask.waiting import Waiting
            mark = Waiting(self.state).someone()
        except Exception:
            return ""
        what = str(mark.get("what") or "")
        return f" on {what}" if what else ""

    def _how_long(self) -> str:
        """How long the job in flight has been going, in plain words."""
        if self._since is None:
            return "just started"
        spent = int(max(0.0, time.monotonic() - self._since))
        if spent < 60:
            return f"{spent}s"
        return f"{spent // 60}m {spent % 60}s"

    @_on_ui
    def _say(self, words: str) -> None:
        """Intention: show a short message on the window's note line, if the window is built."""
        if self.note is not None:
            self.note.configure(text=words)


def assemble(root_dir, state):
    """Build the talking half: what it knows, and who does the talking."""
    from warp2.ask.knowing import Knowing
    from warp2.ask.personality import Personality
    from warp2.decide import Decisions
    from warp2.projects.capabilities import Capabilities
    from warp2.store.projects import Projects
    from warp2.store.store import Store, store_home
    from warp2.work.queue import WorkQueue

    store = Store(store_home(state), run="ask")
    projects = Projects(store, Path(root_dir))
    knowing = Knowing(store, projects, WorkQueue(store), state=state)
    capabilities = Capabilities(store, projects)
    personality = Personality(state)
    return Talk(knowing, ask=_a_model(root_dir, store, state),
                capabilities=capabilities, personality=personality,
                decisions=None, state=state)


def _a_model(root_dir, store=None, state=None):
    """Intention: A model if there is one, and silence if not — never an error. With a state folder, the chat's speaker chooses who answers each turn (warp2/chat_learning/speaker.py)."""
    try:
        from warp2.ask.quiet import Quiet
        from warp2.models.roster import assemble as enlist
        from warp2.store.tagnet import TagNet
    except ImportError:
        return None
    try:
        made = enlist(Path(root_dir), TagNet(Quiet(store) if store is not None else None))
        fleet = made.get("fleet")
        chosen = fleet.names() if fleet else []
        if not chosen:
            return None
        if state is not None:
            from warp2.chat_learning.speaker import ChatSpeaker
            return ChatSpeaker(fleet, state)
        return lambda prompt: fleet.ask(chosen[0], prompt)
    except Exception:
        return None


def open_the_action_centre(state, root=None, root_dir="."):
    """Open the action centre, or return None where there is no screen."""
    try:
        import tkinter as tk
    except ImportError:
        return None
    made = root or tk.Tk()
    centre = ActionCentre(state, root_dir=root_dir)
    centre.build(tk, made, colours())
    centre._show_proposal(None)
    centre.refresh()
    # Intention: WAKE ON THE WINDOW'S OWN THREAD, AS SOON AS IT IS UP (fixed
    # 2026-10-08). This used to run in a background thread, so the store's
    # SQLite connection was made there and then used by the main thread — the
    # first chat message, or `ask check` — which SQLite refuses ("SQLite
    # objects created in a thread can only be used in that same thread"), and
    # it touched Tk widgets off the Tk thread. Scheduled with `after`, it runs
    # in the window's own loop the moment the window is showing; with no loop
    # running (`ask check`), the caller wakes it itself, on the same thread.
    def _pre_warm():
        try:
            centre.wake(root_dir, state)
        except Exception as exc:
            noted("warp2/ask/window.py:open_the_action_centre._pre_warm", exc)
    made.after(1, _pre_warm)

    def again():
        """Intention: the window's timer: refresh it, every fifth tick take in the image work, then
        schedule itself again.
        """
        centre.refresh()
        # Intention: the window only READS the image work now. It used to run
        # an image practice round from here every thirtieth tick, beside the
        # loop; the loop's own `practice_centering` step does that job.
        centre._proactive_ticks += 1
        if centre._proactive_ticks % 5 == 0:
            centre._load_image_queue()
            centre._refresh_image_queue_ui()
            centre._take_image_feed()
        made.after(EVERY, again)

    made.after(EVERY, again)
    return centre


def main(argv=None) -> int:
    """Open the action centre on its own. `python -m warp2.ask.window <root>`."""
    import sys
    import traceback
    words = list(argv if argv is not None else sys.argv[1:])
    root_dir = Path(words[0]) if words else Path(".")
    state = Path(words[1]) if len(words) >= 2 else root_dir / "state"

    try:
        import tkinter as tk
    except ImportError:
        print("warp2.ask.window: Tkinter is not installed; no GUI available.",
              file=sys.stderr)
        return 1

    root = tk.Tk()
    centre = open_the_action_centre(state, root=root, root_dir=root_dir)
    if centre is None:
        # Intention: a window that could not be built is closed, not left on
        # screen. It was left open as an empty "tk" window — found 2026-09-18
        # as the likely cause of the full suite stalling on Windows with a
        # visible window titled "tk".
        root.destroy()
        return 1
    try:
        root.mainloop()
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
