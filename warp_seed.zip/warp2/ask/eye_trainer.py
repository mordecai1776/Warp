# WARP2/warp2/ask/eye_trainer.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/eye_trainer.py
#  Used by   : warp2/ask/window.py, warp2/ask/media.py, CLI, autonomous loop.
#  Uses      : projects/behemoth_eye/eye/warp_pictures.py (EyePictures),
#              projects/centering_image/readers.py (OllamaReader, test_searched_image),
#              warp2/train/dataset_curator.py (DatasetCurator),
#              warp2/ask/media.py, warp2/ask/reference.py (Worth),
#              warp2/ask/visual.py (READ_VERB), warp2/record/deadline.py (Deadlines).
#              warp2/tags/media/pictures.py (is_there, bytes_of - asked of the small form; BUILD_LOG 1596c);
#  Description:
#    In-place continuous trainer for the WARP Eye vision model.
#    Generates an image (or video frame sequence), scores it via vision
#    readers, identifies visual defects/missing parts, dynamically gathers
#    verified references via internet/curator/renders, trains the Eye weights
#    in-place, and continuously retrains until the image passes.
#  User intention (Andrew, 2026-09-22):
#    "We also nee the abality to constant train to get a image made and train a
#    the eye right there for said image or video where it just retrains until it passes."
# ============================================================================
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import uuid
from pathlib import Path

from warp2.tags.media import pictures
from typing import Any, Callable, Dict, List, Optional
from warp2.record.swallowed import noted

# Add project paths to sys.path if not already present
ROOT_DIR = Path(__file__).resolve().parents[2]
CI_DIR = ROOT_DIR / "projects" / "centering_image"
BEHEMOTH_DIR = ROOT_DIR / "projects" / "behemoth_eye"

for d in (ROOT_DIR, CI_DIR, BEHEMOTH_DIR):
    if d.is_dir() and str(d) not in sys.path:
        sys.path.insert(0, str(d))

from warp2.ask.media import (
    IMAGE_CHECKPOINT,
    extract_visual_subject,
    get_or_load_eye_model,
    record_image_catalog,
)
from warp2.ask.reference import Worth
from warp2.train.dataset_curator import DatasetCurator, compute_image_quality


class EyePersistentTrainer:
    """Continuous in-place trainer for the Eye model until target visual standards pass."""

    def __init__(self, root_dir: Path | str, state_dir: Path | str, default_target: float = 0.85):
        """Intention: keep the root, the state folder and the target score, and set up the dataset
        curator it trains from.
        """
        self.root = Path(root_dir)
        self.state = Path(state_dir)
        self.default_target = float(default_target)
        self.curator = DatasetCurator(self.root, self.state)

    def _get_readers(self) -> list:
        """Discover available vision readers (Ollama or fallback)."""
        from readers import OllamaReader, available_readers

        config_path = self.state / "visual" / "settings.json"
        settings = {}
        if config_path.is_file():
            try:
                settings = json.loads(config_path.read_text(encoding="utf-8"))
            except Exception as exc:
                noted("warp2/ask/eye_trainer.py:EyePersistentTrainer._get_readers", exc)

        reader_names = settings.get("readers")
        if reader_names is None:
            reader_names = [n for n in available_readers() if "moondream" not in n.lower()]

        if reader_names:
            # Intention (2026-10-09, fix 3.8, check F4): no flat 45 s — the
            # wait on a silent reader is what reads have cost on this machine
            # (learned by the picture round), and every reader is asked.
            from warp2.ask.visual import READ_VERB
            from warp2.record.deadline import Deadlines
            waited = Deadlines(self.state / "deadlines.json").budget(READ_VERB)["seconds"]
            return [OllamaReader(name=n, timeout=waited) for n in reader_names]
        # Intention (2026-10-09, fix 3.4, check B4): no reader running is no
        # reader — the stand-in that passed any picture with some variance is gone.
        return []

    def _extract_missing_parts(self, eval_res: dict, subject: str) -> list[str]:
        """Extract missing features or components mentioned in the reader feedback."""
        missing = list(eval_res.get("missing") or [])
        if missing:
            return missing

        diff = str(eval_res.get("difference") or "")
        obs = str(eval_res.get("observation") or "")
        combined = f"{diff} {obs}".lower()

        # Simple extraction of nouns/keywords
        candidates = []
        tokens = [t.strip(".,;:!?()[]\"'") for t in combined.split() if len(t) > 3]
        stop_words = {
            "image", "picture", "photo", "subject", "visible", "missing", "present",
            "clearly", "rather", "instead", "blurry", "noise", "looks", "appears",
            "there", "which", "would", "could", "should", "without", "detail"
        }
        for token in tokens:
            if token not in stop_words and token not in subject.lower():
                candidates.append(token)

        return sorted(set(candidates))[:4]

    def _find_verified_references(self, subject: str, missing_parts: list[str],
                                   tag: dict, readers: list, limit: int = 3) -> list[dict]:
        """Fetch and reader-verify new real-world references specifically for missing attributes."""
        dest_dir = self.state / "images" / "references"
        dest_dir.mkdir(parents=True, exist_ok=True)

        queries = [subject]
        if missing_parts:
            queries.extend([f"{subject} {part}" for part in missing_parts[:2]])

        raw_candidates = []
        for q in queries:
            try:
                # Use dataset curator internet media search
                media_items = self.curator.search_internet_media(q, limit=limit)
                for item in media_items:
                    raw_candidates.append(item["path"])
            except Exception as exc:
                noted("warp2/ask/eye_trainer.py:EyePersistentTrainer._find_verified_references", exc)

        # If curator found none, fallback to image_search if present
        if not raw_candidates:
            try:
                from image_search import CommonsSearch
                search_tag = {"tag_id": "eye_ref_" + uuid.uuid4().hex[:8], "name": subject}
                found = CommonsSearch(timeout=8, limit=limit).fetch(search_tag, dest_dir)
                for ref in found:
                    if "image_path" in ref and Path(ref["image_path"]).is_file():
                        raw_candidates.append(ref["image_path"])
            except Exception as exc:
                noted("warp2/ask/eye_trainer.py:EyePersistentTrainer._find_verified_references", exc)

        # Deduplicate candidates
        unique_paths = []
        seen_digests = set()
        for p in raw_candidates:
            p_obj = Path(p)
            if not p_obj.is_file():
                continue
            try:
                q_info = compute_image_quality(p_obj)
                if not q_info["valid"] or q_info["score"] < 0.2:
                    continue
                d = q_info["digest"]
                if d not in seen_digests:
                    seen_digests.add(d)
                    unique_paths.append(p_obj)
            except Exception:
                continue

        # Evaluate candidates with vision reader
        from readers import test_searched_image
        verified = []
        for p_obj in unique_paths:
            try:
                eval_res = test_searched_image(p_obj, tag, readers=readers)
                ref_score = float(eval_res.get("score", 0.0))
                # Intention (2026-10-09, fix 3.5, check B6): only references the
                # readers passed — a good number with a reader saying the subject
                # is not there was admitted on the number.
                if eval_res.get("passed"):
                    verified.append({
                        "path": str(p_obj.resolve()),
                        "score": ref_score,
                        "observation": eval_res.get("observation", ""),
                        "passed": bool(eval_res.get("passed")),
                    })
                    if len(verified) >= limit:
                        break
            except Exception:
                continue

        return verified

    def train_until_pass(
        self,
        subject: str,
        target_score: Optional[float] = None,
        max_rounds: int = 30,
        on_progress: Optional[Callable[[dict], None]] = None,
        is_video: bool = False,
        media_type: str = "image",
    ) -> dict:
        """Execute the generate -> score -> retrain in-place loop until target score is achieved.

        Args:
            subject: Target prompt / subject to synthesize and learn.
            target_score: Minimum reader score to pass (default 0.85).
            max_rounds: Maximum retraining iterations before stopping.
            on_progress: Optional callback invoked on each round with live telemetry.
            is_video: Whether training on a video frame sequence.
            media_type: 'image' or 'video'.

        Returns:
            Dict containing final status, best score, generated image/video path, and round history.
        """
        target = float(target_score or self.default_target)
        clean_subject = extract_visual_subject(subject)

        from generator import form_tag
        tag = form_tag(clean_subject)

        readers = self._get_readers()
        # Intention (2026-10-09, fix 3.4): with nobody to judge, nothing is drawn
        # or trained — "not judged", and the loop asks again when a reader runs.
        if not readers:
            return {"subject": clean_subject, "status": "not_judged", "approved": False,
                    "how": "not_judged", "rounds": 0, "history": [],
                    "said": "not judged: no vision reader is running"}
        model = get_or_load_eye_model(self.root, self.state)

        attempts_dir = self.state / "images" / "attempts"
        attempts_dir.mkdir(parents=True, exist_ok=True)
        models_dir = self.state / "models"
        models_dir.mkdir(parents=True, exist_ok=True)

        history: list[dict] = []
        best_result: Optional[dict] = None
        best_score: float = -1.0
        missing_parts: list[str] = []

        from readers import test_searched_image

        for round_no in range(1, max_rounds + 1):
            seed = int(uuid.uuid4().hex[:8], 16)
            dest_file = attempts_dir / f"{clean_subject.replace(' ', '_')}_{round_no:03d}_{seed:08x}.png"

            # 1. Generate current state of model
            gen_data = model.generate(tag, dest_file, seed=seed)

            # 2. Score via readers
            eval_res = test_searched_image(dest_file, tag, readers=readers)
            score = float(eval_res.get("score", 0.0))
            # Intention (2026-10-09, fix 3.4): the readers' pass AND the target —
            # a number at the target never overrules a reader saying it is not there.
            passed = bool(eval_res.get("passed")) and score >= target

            round_summary = {
                "round": round_no,
                "score": score,
                "passed": passed,
                "image_path": str(dest_file.resolve()),
                "observation": eval_res.get("observation", ""),
                "difference": eval_res.get("difference", ""),
                "timestamp": time.time(),
            }
            history.append(round_summary)

            if score > best_score or best_result is None:
                best_score = score
                best_result = {
                    "subject": clean_subject,
                    "image_path": str(dest_file.resolve()),
                    "score": score,
                    "approved": passed,
                    "round": round_no,
                    "observation": eval_res.get("observation", ""),
                    "difference": eval_res.get("difference", ""),
                    "evidence": eval_res,
                }

            # User intention (Andrew, 2026-09-27):
            # "also make sure all eye networks are always trying to murge into one. but always keep networks for each concept"
            # "it should also do this each training round."
            # "and if it is training and it hits this it trains like this on all of its data in that thing like this."
            try:
                if hasattr(model, "eye") and hasattr(model.eye, "grow"):
                    model.eye.grow(seconds=0.2)
            except Exception as exc:
                noted("warp2/ask/eye_trainer.py:EyePersistentTrainer.train_until_pass", exc)

            if score >= 0.999:
                try:
                    from warp2.train.centroid_cluster_training import CentroidClusterTrainingEngine
                    c_engine = CentroidClusterTrainingEngine(state_dir=self.state, root_dir=self.root)
                    # Intention (2026-10-09, fix 3.5): only the rounds the readers
                    # passed are this subject — failed rounds were taught as it too.
                    all_thing_data = [
                        {"id": h["image_path"], "image_path": h["image_path"], "score": h["score"], "certainty": h["score"]}
                        for h in history if h.get("passed") and pictures.is_there(h.get("image_path", ""))
                    ]
                    c_engine.process_dataset(label=clean_subject, dataset=all_thing_data)
                except Exception as exc:
                    noted("warp2/ask/eye_trainer.py:EyePersistentTrainer.train_until_pass", exc)

            # Progress notification
            if on_progress:
                try:
                    on_progress({
                        "stage": "evaluated",
                        "round": round_no,
                        "max_rounds": max_rounds,
                        "subject": clean_subject,
                        "score": score,
                        "target": target,
                        "passed": passed,
                        "image_path": str(dest_file.resolve()),
                        "difference": eval_res.get("difference", ""),
                    })
                except Exception as exc:
                    noted("warp2/ask/eye_trainer.py:EyePersistentTrainer.train_until_pass", exc)

            # 3. Check termination
            if passed:
                # Save the trained state
                model.save(models_dir / IMAGE_CHECKPOINT)
                final_res = dict(best_result or {})
                final_res.update({
                    "status": "approved",
                    "approved": True,
                    "rounds": round_no,
                    "how": "approved",
                    "history": history,
                })
                record_image_catalog(self.state, final_res)
                return final_res

            # 4. Not passed yet -> Retrain the eye right there!
            missing_parts = self._extract_missing_parts(eval_res, clean_subject)
            verified_refs = self._find_verified_references(clean_subject, missing_parts, tag, readers, limit=3)

            trained_count = 0
            worth_calc = Worth()
            for ref_item in verified_refs:
                ref_path = ref_item["path"]
                ref_score = ref_item["score"]
                weight_val = float(worth_calc.weigh({
                    "reader_score": ref_score,
                    "reader_verdict": "verified" if ref_item.get("passed") else "unverified"
                })["weight"])

                ex = {
                    "tag": tag,
                    "kind": "reference",
                    "image_path": ref_path,
                    "score": ref_score,
                }
                model.train_example(ex, weight=weight_val)
                trained_count += 1

            # Save in-place weights immediately
            model.save(models_dir / IMAGE_CHECKPOINT)

            if on_progress:
                try:
                    on_progress({
                        "stage": "retrained",
                        "round": round_no,
                        "max_rounds": max_rounds,
                        "subject": clean_subject,
                        "trained_references": trained_count,
                        "missing_parts": missing_parts,
                    })
                except Exception as exc:
                    noted("warp2/ask/eye_trainer.py:EyePersistentTrainer.train_until_pass", exc)

        # If exhausted rounds, return the best candidate
        model.save(models_dir / IMAGE_CHECKPOINT)
        out = dict(best_result or {})
        out.update({
            "status": "out_of_rounds",
            "approved": False,
            "rounds": max_rounds,
            "how": "out_of_rounds",
            "history": history,
            "target": target,
        })
        record_image_catalog(self.state, out)
        return out


def main():
    """Command-line interface for the continuous Eye trainer."""
    parser = argparse.ArgumentParser(description="WARP Eye Continuous In-Place Trainer")
    parser.add_argument("--subject", "-s", type=str, required=True, help="Visual subject or prompt to train on")
    parser.add_argument("--target", "-t", type=float, default=0.85, help="Target recognition score to reach (default: 0.85)")
    parser.add_argument("--rounds", "-r", type=int, default=25, help="Maximum retraining rounds (default: 25)")
    parser.add_argument("--root", type=str, default=".", help="Root directory of APEX/WARP2")
    parser.add_argument("--state", type=str, default="state", help="State directory")
    parser.add_argument("--video", action="store_true", help="Train for video sequence")

    args = parser.parse_args()

    trainer = EyePersistentTrainer(args.root, args.state, default_target=args.target)

    def print_progress(p: dict):
        """Intention: print each round's score, or the retraining that followed it, so a person at the
        console can follow along.
        """
        stage = p.get("stage")
        rnd = p.get("round")
        mx = p.get("max_rounds")
        if stage == "evaluated":
            score = p.get("score", 0.0)
            passed = p.get("passed", False)
            mark = "PASSED" if passed else "RETRY"
            print(f"[{mark}] Round {rnd}/{mx} | Score: {score:.2f} (target {p.get('target', 0.85):.2f}) | {p.get('image_path')}")
            if p.get("difference"):
                print(f"       Difference: {p.get('difference')[:120]}")
        elif stage == "retrained":
            print(f"       Retrained Eye on {p.get('trained_references', 0)} verified references for {p.get('missing_parts')}")

    print(f"Starting continuous Eye training for: '{args.subject}' (target={args.target}, max_rounds={args.rounds})...")
    result = trainer.train_until_pass(
        subject=args.subject,
        target_score=args.target,
        max_rounds=args.rounds,
        on_progress=print_progress,
        is_video=args.video,
    )

    print("\nTraining complete.")
    print(f"Approved : {result.get('approved')}")
    print(f"Score    : {result.get('score')}")
    print(f"Rounds   : {result.get('rounds')}")
    print(f"Path     : {result.get('image_path')}")


if __name__ == "__main__":
    main()
