# WARP2/warp2/ask/math_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/math_learning.py
#  Used by   : warp2/work/side/math.py (MathStep — one pass a turn),
#              warp2/ask/tests/test_math_learning.py.
#  Uses      : the standard library only (fractions, itertools, json, math,
#              time, urllib).
#  Description:
#    MathLearning: looks up one maths topic a pass, and proves it when a proof
#    written for exactly that topic exists. Every proof checks its claim
#    exactly (whole numbers and fractions, never a float guess) against a
#    second, independent way of getting the same answer. A topic with no proof
#    is handed back as "no_proof", so the side step can have it built.
#  User intention (Andrew, 2026-10-08):
#    "we need to add in math in the same way as logic is in there."
#    So this file is the twin of warp2/ask/logic_learning.py: same pass, same
#    three honest answers, same one-proof-per-topic table.
# ============================================================================
"""MathLearning: looks up maths topics and proves the ones it has exact proofs for."""
from __future__ import annotations

import itertools
import json
import math
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path
from typing import Any

USER_AGENT = "WARP2MathLearning/0.1 (autonomous mathematics learning engine)"


@dataclass
class MathConcept:
    """A maths topic as it was looked up.

    Intention: what the pass learned about the topic before any proof ran —
    the words, where they came from, and when.
    """
    name: str
    domain: str
    summary: str
    source_url: str = ""
    discovered_at: float = field(default_factory=time.time)


@dataclass
class ProvenMathSkill:
    """One run of a proof, and what it showed.

    Intention: kept in the ledger and the proofs file, so how each proof did
    over time can be read back.
    """
    proof_name: str
    concept: str
    description: str
    proven: bool
    test_message: str
    execution_time_ms: float
    verified_at: float = field(default_factory=time.time)


# Intention: THE MATHS TOPICS, BY FIELD. The same shape as LOGIC_DOMAINS: the
# pass walks them in this order, never-seen first, then oldest-seen first.
# Topics are written as their Wikipedia page names, so the look-up finds them.
MATH_DOMAINS: dict[str, list[str]] = {
    "number_theory": [
        "Euclidean algorithm",
        "Sieve of Eratosthenes",
        "Fundamental theorem of arithmetic",
        "Modular arithmetic",
        "Fermat's little theorem",
        "Chinese remainder theorem",
    ],
    "algebra": [
        "Binomial theorem",
        "Quadratic formula",
        "Polynomial long division",
        "Mathematical induction",
        "Arithmetic progression",
        "Geometric series",
    ],
    "linear_algebra": [
        "Matrix multiplication",
        "Determinant",
        "Gaussian elimination",
        "Dot product",
        "Eigenvalues and eigenvectors",
    ],
    "calculus_and_numerics": [
        "Newton's method",
        "Simpson's rule",
        "Derivative",
        "Taylor series",
        "Limit of a function",
    ],
    "geometry_and_combinatorics": [
        "Pythagorean theorem",
        "Binomial coefficient",
        "Pascal's triangle",
        "Permutation",
        "Inclusion–exclusion principle",
    ],
}


# Intention: WHICH TOPIC EACH HAND-WRITTEN PROOF REALLY IS. One line per topic,
# by its exact name in MATH_DOMAINS — the rule logic learned the hard way
# (logic_learning.py, 2026-09-19): a topic is never called proven by a proof of
# something else. A topic not in this table has no proof; it becomes build work
# (warp2/work/side/skill_work.py) and is proven only when that code is.
TOPIC_PROOFS: dict[str, str] = {
    "Euclidean algorithm": "Euclidean GCD and Bezout Prover",
    "Sieve of Eratosthenes": "Prime Sieve Verifier",
    "Fundamental theorem of arithmetic": "Unique Factorization Prover",
    "Modular arithmetic": "Modular Power Verifier",
    "Fermat's little theorem": "Modular Power Verifier",
    "Chinese remainder theorem": "CRT Reconstruction Solver",
    "Binomial theorem": "Binomial Expansion Prover",
    "Binomial coefficient": "Binomial Expansion Prover",
    "Pascal's triangle": "Binomial Expansion Prover",
    "Quadratic formula": "Exact Quadratic Root Prover",
    "Mathematical induction": "Induction Sum Prover",
    "Arithmetic progression": "Induction Sum Prover",
    "Geometric series": "Geometric Series Prover",
    "Matrix multiplication": "Exact Matrix Algebra Prover",
    "Determinant": "Exact Matrix Algebra Prover",
    "Gaussian elimination": "Exact Gaussian Elimination Solver",
    "Newton's method": "Newton Square Root Finder",
    "Simpson's rule": "Simpson Exactness Verifier",
    "Pythagorean theorem": "Pythagorean Triple Generator",
}


def _primes_by_trial(limit: int) -> list[int]:
    """Intention: the slow, obvious list of primes the faster proofs are checked against."""
    return [n for n in range(2, limit + 1) if all(n % d for d in range(2, math.isqrt(n) + 1))]


def _mat_mul(a: list[list[Fraction]], b: list[list[Fraction]]) -> list[list[Fraction]]:
    """Intention: matrix product by its definition — row times column, exact."""
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), Fraction(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def _det(m: list[list[Fraction]]) -> Fraction:
    """Intention: the determinant by cofactor expansion — slow, but its own definition."""
    if len(m) == 1:
        return m[0][0]
    total = Fraction(0)
    for j in range(len(m)):
        minor = [row[:j] + row[j + 1:] for row in m[1:]]
        total += (-1) ** j * m[0][j] * _det(minor)
    return total


class MathProver:
    """Runs each hand-written maths proof and says whether it held.

    Intention: every proof returns (held, what it showed, milliseconds), the
    same shape as LogicProver, and checks its answer a second, independent way.
    """

    @staticmethod
    def prove_euclid_gcd() -> tuple[bool, str, float]:
        """Euclid's gcd equals the brute-force gcd, and extended Euclid gives Bezout: a*x + b*y = gcd."""
        t0 = time.perf_counter()

        def extended(a: int, b: int) -> tuple[int, int, int]:
            """Intention: extended Euclid: the gcd of a and b and the x, y with a*x + b*y = gcd."""
            if b == 0:
                return a, 1, 0
            g, x, y = extended(b, a % b)
            return g, y, x - (a // b) * y

        checked = 0
        for a, b in itertools.product(range(1, 61), repeat=2):
            g, x, y = extended(a, b)
            brute = max(d for d in range(1, min(a, b) + 1) if a % d == 0 and b % d == 0)
            if g != brute or a * x + b * y != g:
                return False, f"Euclid failed for ({a}, {b}): got {g}, brute {brute}", 0.0
            checked += 1
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, f"Euclid's gcd matched brute force and satisfied Bezout on all {checked} pairs", elapsed_ms

    @staticmethod
    def prove_prime_sieve() -> tuple[bool, str, float]:
        """The sieve's primes up to 500 are exactly the trial-division primes (95 of them)."""
        t0 = time.perf_counter()
        limit = 500
        marks = [True] * (limit + 1)
        marks[0] = marks[1] = False
        for n in range(2, math.isqrt(limit) + 1):
            if marks[n]:
                for multiple in range(n * n, limit + 1, n):
                    marks[multiple] = False
        sieve = [n for n, keep in enumerate(marks) if keep]
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        if sieve == _primes_by_trial(limit) and len(sieve) == 95:
            return True, f"Sieve found all {len(sieve)} primes up to {limit}, matching trial division", elapsed_ms
        return False, "Sieve and trial division disagree", elapsed_ms

    @staticmethod
    def prove_unique_factorization() -> tuple[bool, str, float]:
        """Every n in 2..2000 factors into primes whose product is n, and two different methods give the same factors."""
        t0 = time.perf_counter()
        primes = _primes_by_trial(2000)
        prime_set = set(primes)

        def by_division(n: int) -> list[int]:
            """Intention: the first way to factor n: divide by 2, 3, 4, ... while the divisor squared is at most n."""
            out, d = [], 2
            while d * d <= n:
                while n % d == 0:
                    out.append(d)
                    n //= d
                d += 1
            return out + ([n] if n > 1 else [])

        def by_prime_list(n: int) -> list[int]:
            """Intention: the second way to factor n: divide only by the listed primes, so it can be
            checked against the first.
            """
            out = []
            for p in primes:
                while n % p == 0:
                    out.append(p)
                    n //= p
                if n == 1:
                    break
            return out

        for n in range(2, 2001):
            first, second = by_division(n), by_prime_list(n)
            if first != second or math.prod(first) != n or not set(first) <= prime_set:
                return False, f"Factorization of {n} failed: {first} vs {second}", 0.0
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, "Every n in 2..2000 has one prime factorization, found the same two ways, with product n", elapsed_ms

    @staticmethod
    def prove_modular_power() -> tuple[bool, str, float]:
        """Square-and-multiply equals repeated multiplication mod m, and a^(p-1) = 1 mod p for every prime p < 60 and a not divisible by p."""
        t0 = time.perf_counter()

        def power_mod(base: int, exp: int, mod: int) -> int:
            """Intention: fast modular power by square-and-multiply, checked against slow power and
            Fermat's little theorem.
            """
            result, base = 1 % mod, base % mod
            while exp:
                if exp & 1:
                    result = result * base % mod
                base = base * base % mod
                exp >>= 1
            return result

        for base, exp, mod in itertools.product(range(0, 12), range(0, 25), range(1, 15)):
            slow = 1 % mod
            for _ in range(exp):
                slow = slow * base % mod
            if power_mod(base, exp, mod) != slow:
                return False, f"Fast power failed for {base}^{exp} mod {mod}", 0.0
        fermat = 0
        for p in _primes_by_trial(60):
            for a in range(1, p):
                if power_mod(a, p - 1, p) != 1:
                    return False, f"Fermat failed for a={a}, p={p}", 0.0
                fermat += 1
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, f"Fast modular power matched slow power, and Fermat's little theorem held in all {fermat} cases", elapsed_ms

    @staticmethod
    def prove_chinese_remainder() -> tuple[bool, str, float]:
        """For coprime moduli 3, 5, 7, the CRT rebuilds every x in 0..104 from its three remainders."""
        t0 = time.perf_counter()
        moduli = (3, 5, 7)
        whole = math.prod(moduli)

        def rebuild(remainders: tuple[int, ...]) -> int:
            """Intention: rebuild the number from its remainders mod 3, 5 and 7 by the Chinese remainder formula."""
            total = 0
            for r, m in zip(remainders, moduli):
                rest = whole // m
                total += r * rest * pow(rest, -1, m)
            return total % whole

        for x in range(whole):
            if rebuild(tuple(x % m for m in moduli)) != x:
                return False, f"CRT failed to rebuild {x}", 0.0
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, f"CRT rebuilt all {whole} numbers mod {whole} from their remainders mod 3, 5 and 7", elapsed_ms

    @staticmethod
    def prove_binomial_expansion() -> tuple[bool, str, float]:
        """Pascal's rule builds the same coefficients as n!/(k!(n-k)!), and sum C(n,k) a^k b^(n-k) equals (a+b)^n."""
        t0 = time.perf_counter()
        row = [1]
        for n in range(0, 21):
            if row != [math.factorial(n) // (math.factorial(k) * math.factorial(n - k)) for k in range(n + 1)]:
                return False, f"Pascal row {n} does not match the factorial formula", 0.0
            for a, b in itertools.product(range(-3, 4), repeat=2):
                if sum(row[k] * a ** k * b ** (n - k) for k in range(n + 1)) != (a + b) ** n:
                    return False, f"Binomial expansion failed for n={n}, a={a}, b={b}", 0.0
            row = [1] + [row[k] + row[k + 1] for k in range(len(row) - 1)] + [1]
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, "Pascal's rule matched the factorial formula and expanded (a+b)^n exactly for n up to 20", elapsed_ms

    @staticmethod
    def prove_quadratic_formula() -> tuple[bool, str, float]:
        """For every (x - r)(x - s) with whole r, s in -9..9, the formula gives back exactly r and s."""
        t0 = time.perf_counter()
        checked = 0
        for r, s in itertools.product(range(-9, 10), repeat=2):
            a, b, c = 1, -(r + s), r * s
            disc = b * b - 4 * a * c
            root = math.isqrt(disc)
            if root * root != disc:
                return False, f"Discriminant {disc} is not a square for r={r}, s={s}", 0.0
            found = sorted([Fraction(-b + root, 2 * a), Fraction(-b - root, 2 * a)])
            if found != sorted([Fraction(r), Fraction(s)]):
                return False, f"Quadratic formula gave {found} for roots {r}, {s}", 0.0
            checked += 1
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, f"Quadratic formula recovered both roots exactly for all {checked} quadratics", elapsed_ms

    @staticmethod
    def prove_induction_sums() -> tuple[bool, str, float]:
        """Base case and step for sum(1..n) = n(n+1)/2 and sum of first n odds = n^2, checked for n up to 1000."""
        t0 = time.perf_counter()

        def triangle(n: int) -> int:
            """Intention: the closed form n(n+1)/2 for 1 + 2 + ... + n, whose base case and step are checked."""
            return n * (n + 1) // 2

        if triangle(1) != 1 or 1 != 1 ** 2:
            return False, "Base case failed", 0.0
        running = 0
        for n in range(1, 1001):
            if triangle(n + 1) != triangle(n) + (n + 1):
                return False, f"Induction step failed for sum at n={n}", 0.0
            if (n + 1) ** 2 != n ** 2 + (2 * n + 1):
                return False, f"Induction step failed for odds at n={n}", 0.0
            running += n
            if running != triangle(n):
                return False, f"Closed form disagrees with the running sum at n={n}", 0.0
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, "Induction base and step held for n(n+1)/2 and n^2, and matched running sums to n=1000", elapsed_ms

    @staticmethod
    def prove_geometric_series() -> tuple[bool, str, float]:
        """sum(r^k, k=0..n-1) = (1 - r^n)/(1 - r) exactly, for fractional r, and the partial sums of 1/2^k approach 2."""
        t0 = time.perf_counter()
        ratios = sorted({Fraction(p, q) for p in range(-5, 6) for q in range(1, 6)} - {Fraction(1)})
        for r, n in itertools.product(ratios, range(1, 15)):
            if sum((r ** k for k in range(n)), Fraction(0)) != (1 - r ** n) / (1 - r):
                return False, f"Geometric sum failed for r={r}, n={n}", 0.0
        half = sum((Fraction(1, 2 ** k) for k in range(40)), Fraction(0))
        if not Fraction(2) - half == Fraction(1, 2 ** 39):
            return False, "The halving series did not close in on 2", 0.0
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, f"Geometric sum formula held exactly for {len(ratios)} ratios and 14 lengths; 1/2^k sums to 2", elapsed_ms

    @staticmethod
    def prove_matrix_algebra() -> tuple[bool, str, float]:
        """Matrix product is associative, the identity changes nothing, and det(AB) = det(A) det(B), all exact."""
        t0 = time.perf_counter()
        f = Fraction
        mats = [
            [[f(2), f(-1), f(0)], [f(1), f(3), f(4)], [f(0), f(5), f(-2)]],
            [[f(1, 2), f(0), f(3)], [f(-2), f(1), f(1)], [f(4), f(2, 3), f(0)]],
            [[f(0), f(1), f(1)], [f(1), f(0), f(1)], [f(1), f(1), f(0)]],
        ]
        ident = [[f(int(i == j)) for j in range(3)] for i in range(3)]
        for a, b, c in itertools.permutations(mats, 3):
            if _mat_mul(_mat_mul(a, b), c) != _mat_mul(a, _mat_mul(b, c)):
                return False, "Matrix product was not associative", 0.0
            if _mat_mul(a, ident) != a or _mat_mul(ident, a) != a:
                return False, "The identity changed a matrix", 0.0
            if _det(_mat_mul(a, b)) != _det(a) * _det(b):
                return False, "det(AB) differed from det(A) det(B)", 0.0
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, "Matrix product associative with identity, and det(AB) = det(A)det(B), on all ordered triples", elapsed_ms

    @staticmethod
    def prove_gaussian_elimination() -> tuple[bool, str, float]:
        """Elimination solves A x = b exactly; putting x back in gives b, and it matches Cramer's rule."""
        t0 = time.perf_counter()
        f = Fraction
        a = [[f(2), f(1), f(-1)], [f(-3), f(-1), f(2)], [f(-2), f(1), f(2)]]
        b = [f(8), f(-11), f(-3)]
        rows = [row[:] + [rhs] for row, rhs in zip(a, b)]
        size = len(rows)
        for col in range(size):
            pivot = next(r for r in range(col, size) if rows[r][col] != 0)
            rows[col], rows[pivot] = rows[pivot], rows[col]
            for r in range(size):
                if r != col and rows[r][col] != 0:
                    factor = rows[r][col] / rows[col][col]
                    rows[r] = [x - factor * y for x, y in zip(rows[r], rows[col])]
        x = [rows[i][size] / rows[i][i] for i in range(size)]
        back = [sum((a[i][j] * x[j] for j in range(size)), f(0)) for i in range(size)]
        whole = _det(a)
        cramer = [_det([[b[i] if j == k else a[i][j] for j in range(size)] for i in range(size)]) / whole
                  for k in range(size)]
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        if back == b and x == cramer == [f(2), f(3), f(-1)]:
            return True, "Gaussian elimination solved the system to x=(2, 3, -1), checked by substitution and Cramer's rule", elapsed_ms
        return False, f"Elimination gave {x}, Cramer gave {cramer}", elapsed_ms

    @staticmethod
    def prove_newton_sqrt() -> tuple[bool, str, float]:
        """Newton's step x -> (x + n/x)/2 reaches the whole square root of every n up to 5000, checked by r^2 <= n < (r+1)^2."""
        t0 = time.perf_counter()

        def newton_isqrt(n: int) -> int:
            """Intention: the whole square root of n by Newton's step, stopping when the guess stops going down."""
            if n < 2:
                return n
            x = n
            while True:
                y = (x + n // x) // 2
                if y >= x:
                    return x
                x = y

        for n in range(0, 5001):
            r = newton_isqrt(n)
            if not (r * r <= n < (r + 1) * (r + 1)) or r != math.isqrt(n):
                return False, f"Newton's method gave {r} for the square root of {n}", 0.0
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, "Newton's method found the exact whole square root of every n up to 5000", elapsed_ms

    @staticmethod
    def prove_simpson_exactness() -> tuple[bool, str, float]:
        """Simpson's rule is exact for every cubic: it matches the antiderivative exactly, in fractions."""
        t0 = time.perf_counter()
        checked = 0
        for c0, c1, c2, c3 in itertools.product(range(-2, 3), repeat=4):
            def poly(x: Fraction) -> Fraction:
                """Intention: the cubic being integrated, for this round's coefficients."""
                return c0 + c1 * x + c2 * x ** 2 + c3 * x ** 3

            def anti(x: Fraction) -> Fraction:
                """Intention: the exact antiderivative of the cubic, the true integral Simpson's rule
                is compared with.
                """
                return c0 * x + Fraction(c1, 2) * x ** 2 + Fraction(c2, 3) * x ** 3 + Fraction(c3, 4) * x ** 4

            lo, hi = Fraction(-1), Fraction(3, 2)
            simpson = (hi - lo) / 6 * (poly(lo) + 4 * poly((lo + hi) / 2) + poly(hi))
            if simpson != anti(hi) - anti(lo):
                return False, f"Simpson's rule was not exact for {c0}+{c1}x+{c2}x^2+{c3}x^3", 0.0
            checked += 1
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, f"Simpson's rule matched the exact integral of all {checked} cubics", elapsed_ms

    @staticmethod
    def prove_pythagorean_triples() -> tuple[bool, str, float]:
        """Euclid's formula makes triples with a^2 + b^2 = c^2, and it finds every primitive triple with c up to 100."""
        t0 = time.perf_counter()
        made = set()
        for m in range(2, 11):
            for n in range(1, m):
                if (m - n) % 2 == 1 and math.gcd(m, n) == 1:
                    a, b, c = m * m - n * n, 2 * m * n, m * m + n * n
                    if a * a + b * b != c * c:
                        return False, f"Euclid's formula broke at m={m}, n={n}", 0.0
                    if c <= 100:
                        made.add((min(a, b), max(a, b), c))
        brute = {(a, b, c) for c in range(1, 101) for a in range(1, c) for b in range(a, c)
                 if a * a + b * b == c * c and math.gcd(math.gcd(a, b), c) == 1}
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        if made == brute:
            return True, f"Euclid's formula made all {len(brute)} primitive Pythagorean triples with c up to 100", elapsed_ms
        return False, f"Euclid's formula missed {sorted(brute - made)}", elapsed_ms

    @classmethod
    def proof_source(cls, proof_name: str) -> str:
        """The code of the proof that ran under this name, or "".

        Intention: THE PROOF ITSELF IS THE TRAINING TEXT — the same rule as
        LogicProver.proof_source. The code of a proof that passed is verified
        code, which is what Andrew's rule says is trained on.
        """
        import inspect
        method = PROOF_METHODS.get(str(proof_name))
        try:
            return inspect.getsource(method) if method is not None else ""
        except (OSError, TypeError):
            return ""

    @classmethod
    def prove_math_for(cls, topic: str) -> tuple[bool, str, str, float] | None:
        """Run the proof written for this exact topic, or None when there is none.

        Intention: None is the honest answer for a topic with no proof. It is
        never answered with some other proof's pass.
        """
        name = TOPIC_PROOFS.get(str(topic))
        if name is None:
            return None
        ok, msg, ms = PROOF_METHODS[name]()
        return ok, name, msg, ms


# Intention: which proof runs under each name, so the code of a passed proof
# can be kept with it. One line per name; ask/tests/test_math_learning.py
# checks every name in TOPIC_PROOFS has its method here.
PROOF_METHODS = {
    "Euclidean GCD and Bezout Prover": MathProver.prove_euclid_gcd,
    "Prime Sieve Verifier": MathProver.prove_prime_sieve,
    "Unique Factorization Prover": MathProver.prove_unique_factorization,
    "Modular Power Verifier": MathProver.prove_modular_power,
    "CRT Reconstruction Solver": MathProver.prove_chinese_remainder,
    "Binomial Expansion Prover": MathProver.prove_binomial_expansion,
    "Exact Quadratic Root Prover": MathProver.prove_quadratic_formula,
    "Induction Sum Prover": MathProver.prove_induction_sums,
    "Geometric Series Prover": MathProver.prove_geometric_series,
    "Exact Matrix Algebra Prover": MathProver.prove_matrix_algebra,
    "Exact Gaussian Elimination Solver": MathProver.prove_gaussian_elimination,
    "Newton Square Root Finder": MathProver.prove_newton_sqrt,
    "Simpson Exactness Verifier": MathProver.prove_simpson_exactness,
    "Pythagorean Triple Generator": MathProver.prove_pythagorean_triples,
}


class MathLearning:
    """Looks maths topics up, keeps a ledger of them, and proves the ones it can.

    Intention: the twin of LogicLearning — its own ledger and proofs file in
    state/knowledge, so maths and logic never write over each other.
    """

    def __init__(self, root_dir: Path | str, state_dir: Path | str) -> None:
        """Intention: where the ledger and the proofs file live, read once."""
        self.root_dir = Path(root_dir)
        self.state_dir = Path(state_dir)
        self.knowledge_dir = self.state_dir / "knowledge"
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)
        self.ledger_path = self.knowledge_dir / "math_learning.json"
        self.proofs_path = self.knowledge_dir / "math_proofs.jsonl"
        self._load_ledger()

    def _load_ledger(self) -> dict[str, Any]:
        """Intention: the ledger as it was left; a new or broken one starts empty."""
        empty = {"concepts": {}, "proven_skills": {}, "total_passes": 0, "checked": {}}
        if not self.ledger_path.is_file():
            self.data: dict[str, Any] = dict(empty)
            self._save_ledger()
            return self.data
        # Intention (2026-11-07): a ledger that cannot be read stops here (warp2/record/kept_file.py), never read as empty.
        from warp2.record.kept_file import read_kept
        self.data = read_kept(self.ledger_path, dict(empty))
        return self.data

    def _save_ledger(self) -> None:
        """Intention: written to a side file and swapped in, so a stop mid-write cannot leave half a ledger."""
        temp = self.ledger_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(self.ledger_path)

    def search_online_concept(self, topic: str, timeout: float = 4.0) -> MathConcept | None:
        """Look the topic up on Wikipedia's summary page; None when it cannot be reached.

        Intention: the words of the topic, so the build lane knows what to write
        when no proof exists. A failed look-up is not an error — the pass goes on.
        """
        clean_topic = topic.strip()
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{urllib.parse.quote(clean_topic)}"
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except Exception:
            return None
        extract = data.get("extract", "")
        if not extract:
            return None
        return MathConcept(
            name=data.get("title", clean_topic),
            domain="mathematics",
            summary=extract[:250] + "...",
            source_url=data.get("content_urls", {}).get("desktop", {}).get("page", ""),
        )

    def pick_next_concept_to_learn(self) -> tuple[str, str]:
        """The next topic: one never looked at, else the one looked at longest ago.

        Intention: keyed by the topic, not the page title (the lesson in
        logic_learning.py), and round them evenly once all are known.
        """
        seen = self.data.get("checked", {})
        order = [(domain, t) for domain, topics in MATH_DOMAINS.items() for t in topics]
        for domain, t in order:
            if t not in seen:
                return domain, t
        return min(order, key=lambda pair: float(seen.get(pair[1], 0.0)))

    def _record_run(self, topic: str, skill: ProvenMathSkill) -> None:
        """Intention: one proof run into the ledger and onto the end of the proofs file."""
        self.data.setdefault("proven_skills", {})[skill.proof_name] = {
            "proof_name": skill.proof_name, "concept": skill.concept, "topic": topic,
            "proven": skill.proven, "test_message": skill.test_message,
            "time_ms": skill.execution_time_ms, "verified_at": skill.verified_at,
        }
        try:
            with open(self.proofs_path, "a", encoding="utf-8") as handle:
                handle.write(json.dumps({
                    "proof": skill.proof_name, "concept": skill.concept, "topic": topic,
                    "proven": skill.proven, "time_ms": skill.execution_time_ms,
                    "verified_at": skill.verified_at, "message": skill.test_message,
                }) + "\n")
        except OSError:
            pass

    def learn_pass(self) -> dict[str, Any]:
        """Look one topic up, and prove it if a proof for exactly it exists.

        Intention: three honest answers, as in logic. "proven" / "unproven"
        when a proof for this topic ran; "no_proof" when none exists, so the
        caller can have it built.
        """
        self.data["total_passes"] = self.data.get("total_passes", 0) + 1
        domain, topic = self.pick_next_concept_to_learn()
        self.data.setdefault("checked", {})[topic] = time.time()
        concept = self.search_online_concept(topic) or MathConcept(
            name=topic, domain=domain,
            summary=f"Mathematics concept in the {domain} field.",
            source_url=f"https://en.wikipedia.org/wiki/{urllib.parse.quote(topic)}",
        )
        self.data.setdefault("concepts", {})[topic.lower()] = {
            "name": concept.name, "topic": topic, "domain": domain,
            "summary": concept.summary, "source_url": concept.source_url,
            "learned_at": concept.discovered_at,
        }
        ran = MathProver.prove_math_for(topic)
        if ran is None:
            self._save_ledger()
            return {"status": "no_proof", "topic": topic, "concept": concept.name,
                    "domain": domain, "summary": concept.summary, "proof_name": "",
                    "proof_text": "", "message": f"no proof written for {topic}",
                    "execution_time_ms": 0.0}
        ok, proof_name, msg, ms = ran
        skill = ProvenMathSkill(proof_name=proof_name, concept=concept.name, description=msg,
                                proven=ok, test_message=msg, execution_time_ms=round(ms, 3))
        self._record_run(topic, skill)
        self._save_ledger()
        return {
            "status": "proven" if ok else "unproven",
            "topic": topic,
            "concept": concept.name,
            "domain": domain,
            "summary": concept.summary,
            "proof_name": proof_name,
            # Intention: only a proof that passed carries its code.
            "proof_text": MathProver.proof_source(proof_name) if ok else "",
            "message": msg,
            "execution_time_ms": skill.execution_time_ms,
        }
