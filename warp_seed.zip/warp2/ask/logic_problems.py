# WARP2/warp2/ask/logic_problems.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/logic_problems.py
#  Used by   : warp2/work/side/logic.py (LogicStep — checked problems as the
#              Eye's logic blocks), warp2/ask/tests/test_logic_problems_are_checked.py.
#  Uses      : warp2/ask/logic_rules.py (the rules, the formulas, the
#              truth-table check), warp2/train/training_blocks.py
#              (TrainingBlock); stdlib hashlib, random.
#  Description:
#    The logic dataset: arguments a truth table has checked, made fresh each
#    turn. Each problem is a pair worded alike — a rule's argument and its
#    fallacy's, with the same statements put in for the letters — so the
#    only difference between right and wrong is the reasoning. Every pair is
#    checked again on its own table after the statements are put in (a
#    put-in that makes the fallacy valid too is dropped), and each side is
#    given in words and in symbols. As a training block the valid side is
#    what is right and the invalid side what is wrong, with nothing else to
#    tell them apart: the block's features are the same on both sides.
#    Measured 2026-11-02 (BUILD_LOG 1118): the Eye's logic part sat at 50%
#    (a coin flip) on held-back blocks; its blocks were the same 8 proofs,
#    each against one fixed sentence of a "fallacious derivation".
#  User intention (Andrew, 2026-11-02): "make sure they have proper datasets
#    and that they are given proper leaning methods and test". (2026-10-25:
#    real concepts first, learned from data that can be checked.)
# ============================================================================
"""Checked logic problems — valid and invalid arguments worded alike — as the Eye's logic blocks."""
from __future__ import annotations

import hashlib
import random

from warp2.ask.logic_rules import RULES, atom, atoms_of, entails, shown

# Intention: everyday statements put in for the letters, so the words carry no hint of the answer. Words, not numbers.
STATEMENTS = ("it rains", "the ground is wet", "the light is on", "the door is open", "the alarm rings",
              "the cat sleeps", "the road is closed", "the train is late", "the oven is hot", "the shop is open",
              "the phone rings", "the river floods")


def in_words(f: tuple, said: dict) -> str:
    """Intention: a formula as an English sentence, with the statement put in for each letter."""
    op = f[0]
    if op == "atom":
        return said[f[1]]
    if op == "not":
        return f"it is not the case that {in_words(f[1], said)}"
    a, b = in_words(f[1], said), in_words(f[2], said)
    return {"and": f"{a} and {b}", "or": f"either {a} or {b}", "imp": f"if {a}, then {b}",
            "iff": f"{a} exactly when {b}"}[op]


def argument_text(premises: list, conclusion: tuple, said: dict) -> str:
    """Intention: the argument in words, then in symbols — the same for a valid one and an invalid one."""
    words = " ".join(f"{in_words(p, said).capitalize()}." for p in premises)
    lead = f"{words} So, " if words else "So, "
    symbols = " ; ".join(shown(p) for p in premises) + " |- " + shown(conclusion)
    return f"{lead}{in_words(conclusion, said)}. [{symbols}]"


def put_in(f: tuple, subs: dict) -> tuple:
    """Intention: every letter replaced by its formula — a uniform put-in, which keeps a valid argument valid."""
    if f[0] == "atom":
        return subs.get(f[1], f)
    return (f[0], *(put_in(part, subs) for part in f[1:]))


class Problem:
    """One checked pair: a valid argument and an invalid one, worded alike."""

    def __init__(self, rule: str, valid: str, invalid: str) -> None:
        """Intention: the rule it came from and the two arguments as text."""
        self.rule, self.valid, self.invalid = rule, valid, invalid


class LogicProblems:
    """Fresh checked problems from a seed: the same seed, the same problems."""

    def __init__(self, seed: int) -> None:
        """Intention: a seed per turn, so each turn's problems are new and any can be made again."""
        self.rng = random.Random(seed)

    def one(self) -> Problem | None:
        """A rule's argument and its fallacy's, statements put in, both checked again; None when the check refuses.

        Intention: THE CHECK, NOT THE RULE'S NAME, DECIDES. The pair is used
        only when the valid side still has no counter row and the invalid
        side still has one after the statements are put in.
        """
        name = self.rng.choice(sorted(RULES))
        rule = RULES[name]
        letters = sorted(set().union(*(atoms_of(f) for f in [*rule.premises, rule.conclusion,
                                                              *rule.fallacy_premises, rule.fallacy_conclusion])))
        subs = {letter: self._part() for letter in letters}
        premises = [put_in(f, subs) for f in rule.premises]
        conclusion = put_in(rule.conclusion, subs)
        bad_premises = [put_in(f, subs) for f in rule.fallacy_premises]
        bad_conclusion = put_in(rule.fallacy_conclusion, subs)
        used = sorted(set().union(*(atoms_of(f) for f in [*premises, conclusion, *bad_premises, bad_conclusion])))
        said = dict(zip(used, self.rng.sample(STATEMENTS, len(used))))
        if not entails(premises, conclusion):
            return None
        if entails(bad_premises, bad_conclusion):
            return None
        return Problem(name, argument_text(premises, conclusion, said),
                       argument_text(bad_premises, bad_conclusion, said))

    def _part(self) -> tuple:
        """What a rule's letter becomes: a fresh statement, or two joined, or one negated.

        Intention: VARIETY THE RULE CANNOT GIVE BY ITSELF. Thirteen rules are
        thirteen shapes; put-ins make each shape many arguments, so what is
        learned is the reasoning, not thirteen sentences.
        """
        letters = [f"s{i}" for i in range(len(STATEMENTS))]
        kind = self.rng.choice(("one", "not", "and", "or"))
        first = atom(self.rng.choice(letters))
        if kind == "one":
            return first
        if kind == "not":
            return ("not", first)
        return (kind, first, atom(self.rng.choice(letters)))

    def some(self, count: int) -> list:
        """Intention: up to `count` checked problems; a refused draw is simply not one."""
        made = [self.one() for _ in range(max(0, int(count)))]
        return [p for p in made if p is not None]


def block_of(problem: Problem):
    """One problem as a logic training block: the valid argument right, the invalid one wrong.

    Intention: NOTHING BUT THE REASONING TELLS THEM APART. Each side is only
    its words (the Eye reads a "prompt" side as words, warp2/train/
    block_sides.py); the features, weight and provenance belong to the
    block and go with both sides alike. The rule's name is kept on the
    provenance, never on a side, so it cannot give the answer away.
    """
    from warp2.train.training_blocks import TrainingBlock
    bid = hashlib.sha256(f"logic-problem:{problem.valid}|{problem.invalid}".encode("utf-8")).hexdigest()[:16]
    return TrainingBlock(
        block_id=bid,
        domain="logic",
        subject=f"logic problem: {problem.rule}",
        intent="Tell a valid argument from an invalid one worded alike, both checked by truth table",
        positive={"prompt": problem.valid},
        negative={"prompt": problem.invalid},
        weight=1.0,
        features={"logic:checked_by_truth_table": 1.0},
        provenance={"checked_by": "truth table", "rule": problem.rule, "made_by": "warp2/ask/logic_problems.py"},
        modality="logic",
        modalities=["logic"],
        modality_payload={"valid": problem.valid, "invalid": problem.invalid, "rule": problem.rule},
    )


__all__ = ["LogicProblems", "Problem", "block_of", "argument_text", "in_words", "atom"]
