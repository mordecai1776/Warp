# WARP2/warp2/ask/code_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/code_learning.py
#  Used by   : warp2/ask/tests/test_code_learning.py,
#              warp2/work/side/code.py
#  Uses      : the standard library only
#  Description:
#    CodeLearning: Researches computer science algorithms, software concepts,
#    and proves code skills.
#  User intention:
#    Not written down in this file yet; noted to ask Andrew (2026-09-18).
# ============================================================================
"""CodeLearning: Researches computer science algorithms, software concepts, and proves code skills."""
from __future__ import annotations

import heapq
import json
import random
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable
from warp2.record.swallowed import noted


USER_AGENT = "WARP2CodeLearning/0.3 (autonomous programming and algorithmic skill learning engine)"


@dataclass
class CodeConcept:
    """A learned programming or computer science concept."""
    name: str
    domain: str
    summary: str
    source_url: str = ""
    discovered_at: float = field(default_factory=time.time)


@dataclass
class ProvenRecipe:
    """An executable programming skill or algorithm verified against assertions."""
    recipe_name: str
    concept: str
    description: str
    proven: bool
    test_message: str
    code_signature: str
    execution_time_ms: float
    verified_at: float = field(default_factory=time.time)


# Broad taxonomy of computer science and software engineering domains
ALGORITHM_DOMAINS: dict[str, list[str]] = {
    "graph_and_pathfinding": [
        "A* search algorithm",
        "Dijkstra's algorithm",
        "Breadth-first search",
        "Depth-first search",
        "Bellman-Ford algorithm",
        "Floyd-Warshall algorithm",
        "Topological sorting",
    ],
    "game_and_graphics": [
        "Bresenham's line algorithm",
        "Flood fill",
        "Cellular automaton",
        "Spatial hashing",
        "Bounding volume hierarchy",
        "Ray casting",
        "Perlin noise",
    ],
    "patterns_and_architecture": [
        "State pattern",
        "Observer pattern",
        "Command pattern",
        "Entity component system",
        "Event-driven architecture",
        "Model-view-controller",
    ],
    "data_structures": [
        "LRU cache",
        "Bloom filter",
        "Binary search tree",
        "Trie",
        "Disjoint-set data structure",
        "Ring buffer",
        "Skip list",
    ],
}


class RecipeProver:
    """Executes and mathematically verifies programming algorithms against concrete tests."""

    @staticmethod
    def prove_astar_pathfinding() -> tuple[bool, str, float]:
        """Verify A* search finding the optimal shortest path on an obstacle grid."""
        t0 = time.perf_counter()

        def astar(grid: list[list[int]], start: tuple[int, int], goal: tuple[int, int]) -> list[tuple[int, int]] | None:
            """Intention: the A* search under test: the shortest path on a grid of free (0) and wall cells, or None."""
            h, w = len(grid), len(grid[0])
            open_set: list[tuple[int, int, tuple[int, int]]] = []
            heapq.heappush(open_set, (0, 0, start))
            came_from: dict[tuple[int, int], tuple[int, int]] = {}
            g_score: dict[tuple[int, int], int] = {start: 0}

            def heuristic(a: tuple[int, int], b: tuple[int, int]) -> int:
                """Intention: the grid (Manhattan) distance between two cells, the guess A* uses to
                choose the next cell.
                """
                return abs(a[0] - b[0]) + abs(a[1] - b[1])

            while open_set:
                _, current_g, current = heapq.heappop(open_set)
                if current == goal:
                    path = []
                    curr: tuple[int, int] | None = current
                    while curr is not None:
                        path.append(curr)
                        curr = came_from.get(curr)
                    return path[::-1]

                for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    nx, ny = current[0] + dx, current[1] + dy
                    neighbor = (nx, ny)
                    if 0 <= nx < w and 0 <= ny < h and grid[ny][nx] == 0:
                        tentative_g = current_g + 1
                        if tentative_g < g_score.get(neighbor, float("inf")):
                            came_from[neighbor] = current
                            g_score[neighbor] = tentative_g
                            f = tentative_g + heuristic(neighbor, goal)
                            heapq.heappush(open_set, (f, tentative_g, neighbor))
            return None

        test_grid = [
            [0, 0, 0, 0],
            [1, 1, 1, 0],
            [0, 0, 0, 0],
            [0, 1, 1, 1],
            [0, 0, 0, 0],
        ]
        path = astar(test_grid, (0, 0), (0, 4))
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        if path is not None and len(path) == 11 and path[0] == (0, 0) and path[-1] == (0, 4):
            return True, f"A* successfully computed optimal obstacle-avoiding path of {len(path)} steps", elapsed_ms
        return False, "A* pathfinding failed to solve obstacle grid", elapsed_ms

    @staticmethod
    def prove_cellular_automata_caves() -> tuple[bool, str, float]:
        """Verify 2D cellular automata step smoothing a procedural cavern map."""
        t0 = time.perf_counter()

        def smooth_map(grid: list[list[int]], w: int, h: int) -> list[list[int]]:
            """Intention: one smoothing step of the cave automaton: a cell becomes wall when 4 or more
            neighbours are walls.
            """
            new_grid = [[grid[y][x] for x in range(w)] for y in range(h)]
            for y in range(1, h - 1):
                for x in range(1, w - 1):
                    wall_count = 0
                    for dy in (-1, 0, 1):
                        for dx in (-1, 0, 1):
                            if dy == 0 and dx == 0:
                                continue
                            if grid[y + dy][x + dx] == 1:
                                wall_count += 1
                    new_grid[y][x] = 1 if wall_count >= 4 else 0
            return new_grid

        w, h = 10, 10
        rng = random.Random(42)
        initial = [[1 if rng.random() < 0.45 else 0 for _ in range(w)] for _ in range(h)]
        smoothed = smooth_map(initial, w, h)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        # Assert map boundaries and dimensions remain intact
        valid_dims = len(smoothed) == h and len(smoothed[0]) == w
        has_walls = any(1 in row for row in smoothed)
        has_openings = any(0 in row for row in smoothed)
        if valid_dims and has_walls and has_openings:
            return True, f"Cellular automata generated smoothed {w}x{h} procedural cave matrix", elapsed_ms
        return False, "Cellular automata cave generation produced degenerate matrix", elapsed_ms

    @staticmethod
    def prove_flood_fill() -> tuple[bool, str, float]:
        """Verify 4-connected flood fill area traversal."""
        t0 = time.perf_counter()

        def flood_fill(grid: list[list[int]], start: tuple[int, int], fill_val: int) -> int:
            """Intention: the flood fill under test: repaint the connected region at start and return
            how many cells changed.
            """
            h, w = len(grid), len(grid[0])
            sx, sy = start
            target_val = grid[sy][sx]
            if target_val == fill_val:
                return 0
            queue = [(sx, sy)]
            filled_count = 0
            while queue:
                cx, cy = queue.pop(0)
                if not (0 <= cx < w and 0 <= cy < h):
                    continue
                if grid[cy][cx] != target_val:
                    continue
                grid[cy][cx] = fill_val
                filled_count += 1
                for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    queue.append((cx + dx, cy + dy))
            return filled_count

        test_grid = [
            [1, 1, 1, 1],
            [1, 0, 0, 1],
            [1, 0, 0, 1],
            [1, 1, 1, 1],
        ]
        count = flood_fill(test_grid, (1, 1), fill_val=2)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        if count == 4 and test_grid[1][1] == 2 and test_grid[2][2] == 2 and test_grid[0][0] == 1:
            return True, f"Flood fill accurately bounded and colored {count} interior cells", elapsed_ms
        return False, f"Flood fill failed (filled {count} cells)", elapsed_ms

    @staticmethod
    def prove_bresenham_line() -> tuple[bool, str, float]:
        """Verify Bresenham integer line rasterization."""
        t0 = time.perf_counter()

        def bresenham(x0: int, y0: int, x1: int, y1: int) -> list[tuple[int, int]]:
            """Intention: the Bresenham line under test: every grid point on the line between two points, in order."""
            points = []
            dx = abs(x1 - x0)
            dy = -abs(y1 - y0)
            sx = 1 if x0 < x1 else -1
            sy = 1 if y0 < y1 else -1
            err = dx + dy
            while True:
                points.append((x0, y0))
                if x0 == x1 and y0 == y1:
                    break
                e2 = 2 * err
                if e2 >= dy:
                    err += dy
                    x0 += sx
                if e2 <= dx:
                    err += dx
                    y0 += sy
            return points

        pts = bresenham(0, 0, 4, 2)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        if pts[0] == (0, 0) and pts[-1] == (4, 2) and len(pts) == 5:
            return True, f"Bresenham rasterized line across {len(pts)} exact coordinates", elapsed_ms
        return False, f"Bresenham produced incorrect points: {pts}", elapsed_ms

    @staticmethod
    def prove_lru_cache() -> tuple[bool, str, float]:
        """Verify Least Recently Used cache eviction semantics."""
        t0 = time.perf_counter()

        class LRUCache:
            """Intention: the LRU cache under test: it holds at most `capacity` items and drops the
            least recently used first.
            """
            def __init__(self, capacity: int) -> None:
                """Intention: start empty with the most items the cache may hold."""
                self.capacity = capacity
                self.cache: dict[str, Any] = {}

            def get(self, key: str) -> Any:
                """Intention: the value for a key, moved to the newest end so it is evicted last; None if absent."""
                if key not in self.cache:
                    return None
                val = self.cache.pop(key)
                self.cache[key] = val
                return val

            def put(self, key: str, val: Any) -> None:
                """Intention: store a value as the newest, first dropping the oldest item when the cache is full."""
                if key in self.cache:
                    self.cache.pop(key)
                elif len(self.cache) >= self.capacity:
                    oldest = next(iter(self.cache))
                    del self.cache[oldest]
                self.cache[key] = val

        cache = LRUCache(2)
        cache.put("a", 1)
        cache.put("b", 2)
        _ = cache.get("a")  # access "a", making "b" least recently used
        cache.put("c", 3)   # should evict "b"
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        if cache.get("b") is None and cache.get("a") == 1 and cache.get("c") == 3:
            return True, "LRU cache evicted least recently used key 'b' and retained 'a' and 'c'", elapsed_ms
        return False, "LRU cache eviction order failed", elapsed_ms

    @staticmethod
    def prove_state_machine() -> tuple[bool, str, float]:
        """Verify finite state machine transition table and action handling."""
        t0 = time.perf_counter()

        class StateMachine:
            """Intention: the finite state machine under test: a state that moves only along
            transitions it was given.
            """
            def __init__(self, initial_state: str) -> None:
                """Intention: start in the given state with no transitions."""
                self.state = initial_state
                self.transitions: dict[tuple[str, str], str] = {}

            def add_transition(self, source: str, event: str, target: str) -> None:
                """Intention: allow `event` to move the machine from `source` to `target`."""
                self.transitions[(source, event)] = target

            def trigger(self, event: str) -> bool:
                """Intention: move along the transition for this event if there is one; say whether it moved."""
                key = (self.state, event)
                if key in self.transitions:
                    self.state = self.transitions[key]
                    return True
                return False

        fsm = StateMachine("IDLE")
        fsm.add_transition("IDLE", "START", "RUNNING")
        fsm.add_transition("RUNNING", "PAUSE", "PAUSED")
        fsm.add_transition("PAUSED", "RESUME", "RUNNING")
        fsm.add_transition("RUNNING", "FINISH", "DONE")

        step1 = fsm.trigger("START") and fsm.state == "RUNNING"
        step2 = fsm.trigger("PAUSE") and fsm.state == "PAUSED"
        step3 = fsm.trigger("RESUME") and fsm.state == "RUNNING"
        step4 = fsm.trigger("FINISH") and fsm.state == "DONE"
        step5 = not fsm.trigger("INVALID_EVENT")
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        if all([step1, step2, step3, step4, step5]):
            return True, "Finite State Machine cleanly transitioned through IDLE->RUNNING->PAUSED->RUNNING->DONE", elapsed_ms
        return False, "State machine transition failed", elapsed_ms

    @classmethod
    def prove_recipe_for(cls, topic: str) -> tuple[bool, str, str, str, float] | None:
        """Run the recipe written for this exact topic, or None when there is none.

        Intention: None is the honest answer for a topic with no recipe. It is
        never answered with some other recipe's pass.
        """
        found = RECIPES.get(str(topic))
        if found is None:
            return None
        name, prover, signature = found
        ok, msg, ms = prover()
        return ok, name, msg, signature, ms

    @classmethod
    def recipe_source(cls, topic: str) -> str:
        """The code of the recipe for this topic, or "".

        Intention: THE RECIPE ITSELF IS THE TRAINING TEXT, as for logic. The
        side step read a `code` this file never returned, so every code block
        carried no code. Only a recipe that passed is given its code.
        """
        import inspect
        found = RECIPES.get(str(topic))
        try:
            return inspect.getsource(found[1]) if found else ""
        except (OSError, TypeError):
            return ""


# Intention: WHICH TOPIC EACH HAND-WRITTEN RECIPE REALLY IS. One line per
# topic, by its exact name in ALGORITHM_DOMAINS. It replaced a substring guess
# that sent every topic it did not recognise to the state-machine test and
# called the topic proven. MEASURED 2026-09-19: "Bellman–Ford algorithm" was
# recorded proven 367 times by a state machine, and Dijkstra by A*. A topic
# not in this table has no recipe; it becomes build work instead (see
# warp2/work/side/skill_work.py), and is proven only when that code is.
# topic -> (recipe name, prover, signature). After the class, because the
# provers are named here directly rather than as strings.
RECIPES: dict[str, tuple] = {
    "A* search algorithm": ("A* Pathfinding Grid Solver", RecipeProver.prove_astar_pathfinding,
                            "def astar(grid, start, goal) -> list"),
    "Cellular automaton": ("Cellular Automata Cave Generator", RecipeProver.prove_cellular_automata_caves,
                           "def smooth_map(grid, w, h) -> list"),
    "Flood fill": ("Flood Fill Region Painter", RecipeProver.prove_flood_fill,
                   "def flood_fill(grid, start, fill_val) -> int"),
    "Bresenham's line algorithm": ("Bresenham Line Rasterizer", RecipeProver.prove_bresenham_line,
                                   "def bresenham(x0, y0, x1, y1) -> list"),
    "LRU cache": ("LRU Eviction Cache", RecipeProver.prove_lru_cache, "class LRUCache: get(k), put(k, v)"),
    "State pattern": ("Finite State Machine Controller", RecipeProver.prove_state_machine,
                      "class StateMachine: trigger(event)"),
}


class CodeLearning:
    """Discovers programming concepts online, learns code patterns, and proves algorithmic recipes."""

    def __init__(self, root_dir: Path | str, state_dir: Path | str) -> None:
        """Intention: set where the code learning ledger and proven recipes live under state/knowledge,
        and load the ledger.
        """
        self.root_dir = Path(root_dir)
        self.state_dir = Path(state_dir)
        self.knowledge_dir = self.state_dir / "knowledge"
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)
        self.ledger_path = self.knowledge_dir / "code_learning.json"
        self.recipes_path = self.knowledge_dir / "recipes.jsonl"
        self._load_ledger()

    def _load_ledger(self) -> dict[str, Any]:
        """Intention: read the ledger, or start (and save) an empty one; a broken file is read as empty."""
        if not self.ledger_path.is_file():
            self.data: dict[str, Any] = {
                "concepts": {},
                "proven_recipes": {},
                "total_passes": 0,
                "last_domain": "",
            }
            self._save_ledger()
        else:
            # Intention (2026-11-07): a ledger that cannot be read stops here (warp2/record/kept_file.py) - it used to
            # be read as empty and the next save wrote the empty one over the whole learning history.
            from warp2.record.kept_file import read_kept
            self.data = read_kept(self.ledger_path, {"concepts": {}, "proven_recipes": {}, "total_passes": 0, "last_domain": ""})
        return self.data

    def _save_ledger(self) -> None:
        """Intention: write the ledger whole through a temp file, so a crash never leaves half a file."""
        temp = self.ledger_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(self.ledger_path)

    def search_online_concept(self, topic: str, timeout: float = 4.0) -> CodeConcept | None:
        """Search Wikipedia API for clean definitions and principles of a CS topic."""
        clean_topic = topic.strip()
        encoded = urllib.parse.quote(clean_topic)
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{encoded}"
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                extract = data.get("extract", "")
                page_url = data.get("content_urls", {}).get("desktop", {}).get("page", "")
                title = data.get("title", clean_topic)
                if extract:
                    return CodeConcept(
                        name=title,
                        domain="computer_science",
                        summary=extract[:250] + "...",
                        source_url=page_url,
                    )
        except Exception as exc:
            noted("warp2/ask/code_learning.py:CodeLearning.search_online_concept", exc)
        return None

    def pick_next_concept_to_learn(self) -> tuple[str, str]:
        """The next topic: one never looked at, else the one looked at longest ago.

        Intention: KEYED BY THE TOPIC, NOT BY WHAT THE WEB CALLS IT. The ledger
        used the page title, and Wikipedia titles "Bellman-Ford algorithm"
        with an en dash. So the topic never counted as known and was picked
        again on every one of 367 passes. And once all are known it goes
        round them evenly, oldest first, instead of at random.
        """
        seen = self.data.get("checked", {})
        order = [(domain, t) for domain, topics in ALGORITHM_DOMAINS.items() for t in topics]
        for domain, t in order:
            if t not in seen:
                return domain, t
        return min(order, key=lambda pair: float(seen.get(pair[1], 0.0)))

    def learn_pass(self) -> dict[str, Any]:
        """Look one topic up, and prove it if a recipe for exactly it exists.

        Intention: three honest answers. "proven" / "unproven" when a recipe
        for this topic ran; "no_recipe" when none exists, so the caller can
        have it built. Nothing is called proven by a recipe for something else.
        """
        self.data["total_passes"] = self.data.get("total_passes", 0) + 1
        domain, topic = self.pick_next_concept_to_learn()
        self.data.setdefault("checked", {})[topic] = time.time()

        # Step 1: Online research
        concept = self.search_online_concept(topic)
        if not concept:
            concept = CodeConcept(
                name=topic,
                domain=domain,
                summary=f"Algorithmic computer science concept in the {domain} domain.",
                source_url=f"https://en.wikipedia.org/wiki/{urllib.parse.quote(topic)}",
            )

        self.data["concepts"][topic.lower()] = {
            "name": concept.name,
            "topic": topic,
            "domain": domain,
            "summary": concept.summary,
            "source_url": concept.source_url,
            "learned_at": concept.discovered_at,
        }

        # Step 2: the recipe for exactly this topic, if there is one
        ran = RecipeProver.prove_recipe_for(topic)
        if ran is None:
            self._save_ledger()
            return {"status": "no_recipe", "topic": topic, "concept": concept.name,
                    "domain": domain, "summary": concept.summary, "recipe_name": "",
                    "signature": "", "code": "", "message": f"no recipe written for {topic}",
                    "execution_time_ms": 0.0}
        ok, recipe_name, msg, sig, ms = ran
        recipe = ProvenRecipe(
            recipe_name=recipe_name,
            concept=concept.name,
            description=msg,
            proven=ok,
            test_message=msg,
            code_signature=sig,
            execution_time_ms=round(ms, 3),
        )

        self.data["proven_recipes"][recipe_name] = {
            "recipe_name": recipe.recipe_name,
            "concept": recipe.concept,
            "topic": topic,
            "proven": recipe.proven,
            "test_message": recipe.test_message,
            "signature": recipe.code_signature,
            "time_ms": recipe.execution_time_ms,
            "verified_at": recipe.verified_at,
        }

        # Append to recipes.jsonl
        try:
            with open(self.recipes_path, "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "recipe": recipe.recipe_name,
                    "concept": recipe.concept,
                    "topic": topic,
                    "proven": recipe.proven,
                    "time_ms": recipe.execution_time_ms,
                    "verified_at": recipe.verified_at,
                    "message": recipe.test_message,
                }) + "\n")
        except OSError:
            pass

        self._save_ledger()

        return {
            "status": "proven" if ok else "unproven",
            "topic": topic,
            "concept": concept.name,
            "domain": domain,
            "summary": concept.summary,
            "recipe_name": recipe.recipe_name,
            "signature": recipe.code_signature,
            # Intention: only a recipe that passed carries its code.
            "code": RecipeProver.recipe_source(topic) if ok else "",
            "message": recipe.test_message,
            "execution_time_ms": recipe.execution_time_ms,
        }
