# WARP2/warp2/ask/until.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/until.py
#  Used by   : warp2/ask/media.py (making an image for a person),
#              warp2/work/loop.py (centering practice).
#  Uses      : warp2/ask/visual.py (one generate/read/search cycle),
#              warp2/train/mistakes.py (a failed image is a mistake, counted in
#              the same tally as everything else), warp2/settings.py,
#              warp2/work/memory_floor.py (LowMemory — a part stopped for
#              memory is kept to be taken again).
#  Description:
#    Go again. Generate, let the readers look, and if it is not what was asked
#    for, go and get new reference data, train on it, and generate again —
#    until a reader says yes or the budget is spent.
#  User intention (Andrew, 2026-09-12):
#    "it should just keep retraining with new internet data and retraining
#    until it gives one that the reader says is what was asked for."
#
#    WHAT WAS THERE WAS ONE CYCLE AND A STOP. `generate` made one image, read
#    it, and if it failed it searched for references and then set them
#    `pending` — waiting for a person to confirm them before any of it could be
#    used. Nothing ever came back to the subject except `practice`, which every
#    thirty minutes picked whichever subject had been left longest. So a failed
#    image was retried once every half hour at best, with data nobody had
#    approved, and the person who asked for the picture got the failed one.
#
#    WHY IT STOPS WHERE IT STOPS. The reader saying yes is the ending Andrew
#    named, and it is the only one that counts as success. The budget behind it
#    is not a second opinion about quality, it is a bound on a loop that talks
#    to the internet and a model: arXiv 2607.04691 ran exactly this shape of
#    closed generate-and-check loop and reached 95% of the final gain in four
#    to seven iterations, with the rapid part in the first five; arXiv
#    2601.15286 runs a reader in the loop that emits STOP on satisfaction and
#    otherwise halts on budget, which is these two endings exactly. Six rounds
#    sits inside that plateau.
#
#    AND IT NEVER PRETENDS. A run that spends its budget says so and hands back
#    the best the readers saw, with their words for why it was not right. A
#    loop like this failing quietly is how somebody ends up looking at the
#    fourth-best picture believing it was the answer.
# ============================================================================
from __future__ import annotations

from warp2.settings import number
from warp2.work.memory_floor import LowMemory

# How many generate-and-check rounds one request may have. Six: inside the
# four-to-seven where the measured gain has already flattened, and small enough
# that a person asking for a picture is not left waiting through twenty.
ROUNDS = number("WARP2_IMAGE_ROUNDS", 6, minimum=1)

# What the record calls a failed image, so the count lands on one subject.
SUBJECT = "image:"


# Intention (2026-10-09, fix 3.6, check B9): a round no reader could judge —
# busy (timed out on a loaded machine) or not there — is not a failed picture,
# so it never lifts training's share of the machine.
NOT_JUDGED = ("reader_unavailable", "reader_busy")


def _judged(result) -> bool:
    """Whether a reader actually judged this round's picture."""
    return str((result or {}).get("status") or "") not in NOT_JUDGED


class Until:
    """Generate and check, with new data each round, until a reader says yes."""

    def __init__(self, learning, mistakes=None, rounds: int = 0, each=None,
                 until_it_passes: bool = False, is_user_ask: bool = False,
                 one_part: bool = False, each_part=None, size=None) -> None:
        """Intention: keep how a run of rounds should go: how many, whether a user ask holds until it
        passes, and who is told.
        """
        self.learning = learning
        self.mistakes = mistakes
        self.rounds = int(rounds or ROUNDS)
        # User intention (Andrew, 2026-09-27):
        # "when a user ask for something it should not let it go until it can produce it at a 100 from the reader"
        # The loop MUST NOT let it go or stop until the reader produces 100% (1.0).
        self.until_it_passes = bool(until_it_passes or is_user_ask)
        self.is_user_ask = bool(is_user_ask)
        # Intention: SOMEBODY MAY BE WATCHING. A round is a generation, two
        # reader calls and a search of Wikimedia — about a minute — and six of
        # them in silence is indistinguishable from a hang. Andrew hit exactly
        # that: he rejected an image and the window froze. Given something to
        # call, this says where it has got to after every round.
        self.each = each
        # Intention (Andrew, 2026-10-02): "that is too long to wait for a
        # possible failure. We need to split it out into more small directed
        # parts." With `one_part`, a call runs ONE part of a round
        # (warp2/ask/picture_round.py) and hands the loop back; `each_part` is
        # told what that part did and how long it took.
        self.one_part = bool(one_part)
        self.each_part = each_part
        # Intention (Andrew, 2026-10-03): "it should be able to make images of
        # any size requested" — [width, height] asked for, or [] for the
        # picture model's own size; every round is made at it.
        self.size = [int(v) for v in (size or [])]

    def make(self, subject: str, resume=None, at_a_time: int = 0) -> dict:
        """Keep going until the readers accept it, or the budget is spent.

        Intention: ONE CALL, AND IT EITHER SUCCEEDS OR SAYS WHY NOT. Every
        round is kept — what the readers said each time is the record of what
        was tried, and it is what a person needs to see when the answer is
        "it could not".

        `at_a_time` IS THE WHOLE OF ANDREW'S RULE, 2026-09-12: "it is fine if
        it spends the entire process if it is a user need just not if it is on
        its own work that should be split up." A person who asked for a picture
        may have the six rounds in one go and wait for them. The machine
        practising on its own may not: it takes one round, hands the loop back,
        and picks up where it left off next turn. MEASURED before this: one
        practice turn held the whole loop for 338 seconds.

        `resume` is where it left off — the round it had reached and what the
        readers last said was missing. Carried by the caller because the caller
        is the thing that knows whether this is the same piece of work.
        """
        tried = []
        best = None
        # Intention: WHAT THE LAST ROUND SAID WAS MISSING IS WHAT THIS ROUND
        # GOES AND GETS. Andrew: "it should also be able to break that down
        # when parts need to be trained." Carried round to round because the
        # search, the weighting and the tag all need the same list, and three
        # separate guesses at it would be three different answers.
        wanted = [str(one) for one in ((resume or {}).get("wanted") or ())]
        done_already = max(0, int((resume or {}).get("round") or 0))
        budget = (int(at_a_time) if at_a_time > 0
                  else int(self.rounds) if self.until_it_passes
                  else min(int(self.rounds), self.rounds - done_already))
        if self.one_part:
            return self._one_part(subject, resume, wanted, done_already)
        if budget <= 0:
            return self._said(subject, None, tried, "out_of_rounds", done_already)
        for round_no in range(done_already + 1, done_already + budget + 1):
            # Intention (2026-10-17): stopped for memory, the round is kept to be taken again.
            try:
                result = self.learning.generate(subject, wanted=wanted,
                                                round_no=round_no, **self._sized())
            except LowMemory as low:
                self._told({"round": round_no, "said": f"stopped early — {low}"})
                out = self._said(subject, best, tried, "more_to_do", round_no - 1,
                                 resume={"round": round_no - 1, "wanted": wanted})
                # Intention (Remy 2026-11-01): the answer says it was memory, not the readers. Practice stood at
                # round 5 for days with no picture and no reason in its receipt; only the told line had it.
                out["said"] = f"stopped early: {low}"[:400]
                out["held_by"] = "memory"
                return out
            result["round"] = round_no
            wanted = [str(one) for one in (result.get("missing") or wanted)]
            tried.append(self._short(result))
            self._told(tried[-1])
            best = self._better(best, result)
            if result.get("approved"):
                self._cleared(subject)
                return self._said(subject, result, tried, "approved", round_no)
            # Intention: A STOPPED RUN IS NOT A FAILED ONE. The stop flag being
            # raised mid-round says the machine was asked to halt, and counting
            # that as the model getting it wrong would poison the tally that
            # decides how much of its time goes to training.
            if str(result.get("status") or "") == "stopped":
                return self._said(subject, best, tried, "stopped", round_no)
            # Intention: NO READER IS NOT A NO. Going round again with nothing
            # able to look can never end in a yes, however many rounds are
            # left, and every one of those rounds would search the internet and
            # train the model on the strength of nobody's opinion.
            #
            # BUT A READER THAT TIMED OUT IS NOT A MISSING ONE. Andrew asked
            # for a cat on 2026-09-12 fourteen minutes into a LoRA round; the
            # nine-billion parameter vision model on the same machine ran out
            # of time, and this line read that as "nothing can look" and handed
            # him an unjudged picture after one round. It was there — it was
            # busy. Two things now make the next round worth taking: the loop
            # stands down from its own training while somebody is waiting
            # (warp2/ask/waiting.py), and the reader's deadline is measured
            # rather than a flat forty-five seconds. So it goes round again,
            # and the round cap still bounds what that can cost.
            if str(result.get("status") or "") == "reader_unavailable":
                # Intention: for its own practice, no reader this turn is a
                # turn taken, not an ending — the subject is kept, and the
                # next turn picks up here when a reader can look.
                if self.until_it_passes:
                    return self._said(subject, best, tried, "more_to_do", round_no,
                                      resume={"round": round_no, "wanted": wanted})
                return self._said(subject, best, tried, "no_reader", round_no)
            if _judged(result):
                self._missed(subject, result)
        # Intention: SPENT OR ONLY PAUSED, AND THE DIFFERENCE MATTERS. Out of
        # rounds is an ending and clears the slate; more to do is a turn taken,
        # and the next one must start where this stopped rather than searching
        # for the bare subject all over again.
        reached = done_already + budget
        if reached >= self.rounds and not self.until_it_passes:
            return self._said(subject, best, tried, "out_of_rounds", reached)
        return self._said(subject, best, tried, "more_to_do", reached,
                          resume={"round": reached, "wanted": wanted})

    def _sized(self) -> dict:
        """Intention: the size passed on only when one was asked for, so a picture maker without sizes is called as before."""
        return {"size": list(self.size)} if self.size else {}

    def _one_part(self, subject: str, resume, wanted: list, done_already: int) -> dict:
        """One part of the current round; when that part ends the round, the round is judged as `make` judges one.

        Intention: the part's state rides in `resume["part_state"]`, so the
        next turn carries on from that part; a round that ends clears it.
        """
        part_state = (resume or {}).get("part_state")
        round_no = int(part_state["round"]) if part_state else done_already + 1
        # Intention (2026-10-17): A PART STOPPED FOR MEMORY IS NOT A FAILED
        # ONE. The picture work stops at a safe point when free memory stays
        # under the floor (warp2/work/memory_floor.py); the part
        # is said, and the next turn starts it again from where it stood.
        try:
            state, report, result = self.learning.step(subject, part_state, wanted=wanted, round_no=round_no,
                                                       **self._sized())
        except LowMemory as low:
            self._told_part({"round": round_no, "part": "memory", "said": f"stopped early — {low}", "seconds": 0})
            return self._said(subject, None, [], "more_to_do", done_already,
                              resume={"round": done_already, "wanted": wanted, "part_state": part_state})
        self._told_part(report)
        if result is None:
            return self._said(subject, None, [], "more_to_do", done_already,
                              resume={"round": done_already, "wanted": wanted, "part_state": state})
        result["round"] = round_no
        wanted = [str(one) for one in (result.get("missing") or wanted)]
        tried = [self._short(result)]
        self._told(tried[-1])
        if result.get("approved"):
            self._cleared(subject)
            return self._said(subject, result, tried, "approved", round_no)
        if str(result.get("status") or "") == "stopped":
            return self._said(subject, result, tried, "stopped", round_no,
                              resume={"round": done_already, "wanted": wanted})
        if str(result.get("status") or "") == "reader_unavailable" and not self.until_it_passes:
            return self._said(subject, result, tried, "no_reader", round_no)
        if _judged(result):
            self._missed(subject, result)
        if round_no >= self.rounds and not self.until_it_passes:
            return self._said(subject, result, tried, "out_of_rounds", round_no)
        return self._said(subject, result, tried, "more_to_do", round_no,
                          resume={"round": round_no, "wanted": wanted})

    def _told_part(self, report) -> None:
        """Intention: say what one part did and how long it took; a listener that fails never stops the part."""
        if self.each_part is None:
            return
        try:
            self.each_part(dict(report))
        except Exception:
            self.each_part = None

    def _told(self, short) -> None:
        """Say where it has got to, and never let that stop the round.

        Intention: whoever is listening is a window, and a window can be
        closing, gone, or on another thread. A round that failed because a
        progress line failed would be the worst possible trade.
        """
        if self.each is None:
            return
        try:
            self.each(dict(short), self.rounds)
        except Exception:
            self.each = None

    # -- the counting, shared with everything else the machine gets wrong ----

    def _missed(self, subject: str, result) -> None:
        """One image that was not what was asked for.

        Intention: THE SAME TALLY AS THE CODE SIDE. A failed picture is a
        refusal like any other, so it lifts training's share of the machine's
        time by the same rule and shows up in the same reading. Two separate
        notions of "how well is it doing" would be two answers to one question.
        """
        if self.mistakes is None:
            return
        said = self._why(result)
        self.mistakes.note(SUBJECT + str(subject), said)

    def _cleared(self, subject: str) -> None:
        """It made something usable."""
        if self.mistakes is not None:
            self.mistakes.note_accepted()

    # -- reading the result --------------------------------------------------

    @staticmethod
    def _why(result) -> str:
        """What the readers actually said was wrong, in their words.

        Intention: the complaint has to be the reader's own difference, not
        "score too low". The difference is the thing that could be searched for
        next round, and a number is not.
        """
        for reader in ((result or {}).get("readers") or ()):
            if isinstance(reader, dict) and reader.get("difference"):
                return str(reader["difference"])[:400]
        for reader in ((result or {}).get("readers") or ()):
            if isinstance(reader, dict) and reader.get("error"):
                return f"reader {reader.get('name', '')}: {reader['error']}"[:400]
        evidence = (result or {}).get("evidence") or {}
        return f"the readers scored it {evidence.get('score')}"[:400]

    @staticmethod
    def _score(result) -> float:
        """Intention: the reader's score for a round, or -1 when the round has none, so rounds can be compared."""
        evidence = (result or {}).get("evidence") or {}
        try:
            return float(evidence.get("score"))
        except (TypeError, ValueError):
            return -1.0

    def _better(self, best, result):
        """Keep the best the readers saw.

        Intention: if the budget runs out, the person gets the nearest miss
        rather than whichever one happened to be last. Six tries and handing
        back number six is not a search, it is a queue.
        """
        if best is None:
            return result
        return result if self._score(result) > self._score(best) else best

    def _short(self, result) -> dict:
        """Intention: a short summary of one round (score, what was said and missing, the image) for the tried list."""
        return {"round": result.get("round"), "status": result.get("status"),
                "score": self._score(result), "said": self._why(result),
                "missing": list(result.get("missing") or ()),
                "image_path": result.get("image_path"),
                "references": len(result.get("references") or ())}

    def _said(self, subject: str, result, tried: list, how: str,
              rounds: int, resume=None) -> dict:
        """The answer, with the whole attempt behind it."""
        result = result or {}
        return {"subject": str(subject), "how": how, "rounds": rounds,
                # Intention: THE WHOLE OF THE BEST ROUND, not a summary of it.
                # Callers built on the old single-cycle answer read fields off
                # it — how many references were trained, which ones are waiting
                # for review — and a loop that returns its own tidy shape and
                # drops the rest silently breaks every one of them.
                "best": dict(result),
                "resume": dict(resume) if resume else None,
                "missing": list(result.get("missing") or ()),
                "approved": bool(result.get("approved")),
                "image_path": result.get("image_path", ""),
                "score": self._score(result),
                "said": "" if result.get("approved") else self._why(result),
                "evidence": result.get("evidence"),
                "tried": tried}
