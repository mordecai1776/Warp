# WARP2/warp2/ask/doing.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/doing.py
#  Used by   : warp2/ask/window.py (the line in the sidebar that says whether
#              the warp is running and what it is on).
#  Uses      : warp2/record/journal.py (last_lines),
#              warp2/record/processes.py (Processes).
#  Description:
#    What the machine is busy with right now, in one line a person can read.
#  User intention (Andrew, 2026-09-12):
#    "make it easy and simple for the user to use."
#
#    THE QUESTION HE KEPT HAVING TO ASK SOMEBODY ELSE. Over one evening he
#    asked "how is it going", "how is the program doing then", "is the warp
#    working as described yet" — and every answer came from reading journal
#    files, because the window he was sitting in front of could not tell him.
#    Its badge said "Ready" once when it opened and never changed again, so a
#    machine thinking for four minutes and a machine that had died looked
#    exactly the same. He closed the program six times that evening.
#
#    TWO FACTS, AND THEY ARE DIFFERENT FACTS. Is the loop alive — which the
#    process register knows, because it holds a pid and the moment it started,
#    so a recycled pid is not mistaken for a living run. And what it last did —
#    which the execution lane knows. A machine that is alive but has written
#    nothing for ten minutes is a machine stuck on something long, and that
#    reads differently from one that is not running at all. Neither fact alone
#    says which.
#
#    IT NEVER COSTS MORE THAN A GLANCE. Asked once a second by a window, so it
#    reads the end of the lane and nothing else — see `last_lines`, written
#    after the cockpit was found re-reading a twenty megabyte file every two
#    seconds to show twenty-five rows.
# ============================================================================
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from warp2.record.journal import last_lines
from warp2.record.swallowed import noted

# What the loop calls itself on the process register.
RUNNING = "run"


class Doing:
    """What the machine is busy with right now, in one line."""

    def __init__(self, state: Path | str) -> None:
        """Intention: keep the state folder the busy line is read from."""
        self.state = Path(state)

    def _active_lane(self) -> Path:
        """The most recently modified execution journal."""
        journals = self.state / "journals"
        candidates = []
        if journals.is_dir():
            for name in ("continuous.jsonl", "web.jsonl", "run.jsonl"):
                p = journals / name
                if p.is_file():
                    try:
                        candidates.append((p.stat().st_mtime, p))
                    except OSError:
                        pass
            candidates.sort(reverse=True)
        return candidates[0][1] if candidates else (journals / "run.jsonl")

    @property
    def lane(self) -> Path:
        """Intention: backwards compatibility for callers or tests expecting `doing.lane`."""
        return self._active_lane()

    def alive(self) -> bool:
        """Whether a loop or lane is registered and still active."""
        try:
            from warp2.record.processes import Processes
            for row in Processes().snapshot():
                if str(row.get("role")) in (RUNNING, "web") and row.get("state") != "gone":
                    return True
            import time
            lanes_dir = self.state / "lanes"
            for b in ("card.beat", "web.beat"):
                bp = lanes_dir / b
                if bp.is_file() and (time.time() - bp.stat().st_mtime) <= 120:
                    return True
        except Exception:
            return False
        return False

    def last(self) -> dict:
        """The last thing the loop wrote down, and how long ago."""
        for line in reversed(last_lines(self._active_lane(), 5)):
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            if not isinstance(entry, dict) or not entry.get("verb"):
                continue
            return {"verb": str(entry.get("verb") or ""),
                    "outcome": str(entry.get("outcome") or ""),
                    "target": str(entry.get("target") or ""),
                    "ago": self._ago(str(entry.get("ts") or ""))}
        return {}

    def says(self) -> str:
        """Where the warp stands, in the words a person would use.

        Intention: one line, and it always says something. "Nothing to report"
        is a worse answer than "not running" — the point of the line is that a
        person never has to open a file to find out.
        """
        if not self.alive():
            went = self.last()
            if not went:
                return "Warp: not running"
            return f"Warp: not running · last {self._plainly(went['verb'])}{self._when(went)}"

        try:
            from warp2.ask.waiting import Waiting
            mark = Waiting(self.state).someone()
            if mark and mark.get("what"):
                return f"Warp: working on {mark['what']}"
        except Exception as exc:
            noted("warp2/ask/doing.py:Doing.says", exc)

        try:
            from warp2.work.lane_progress import read
            for lane_beat in ("card", "web"):
                live = read(self.state, lane_beat)
                if live and live.get("progress"):
                    p = live["progress"]
                    return f"Warp: {self._plainly(p.get('verb', 'active'))} · {p.get('target', '')}"
        except Exception as exc:
            noted("warp2/ask/doing.py:Doing.says", exc)

        went = self.last()
        if not went:
            return "Warp: running · nothing written down yet"
        ago = went.get("ago")
        if ago is not None and ago > 180:
            return f"Warp: active · running {self._plainly(went['verb'])}{self._when(went)}"
        return f"Warp: {self._plainly(went['verb'])}{self._when(went)}"

    # -- putting it in words -------------------------------------------------

    @staticmethod
    def _plainly(verb: str) -> str:
        """A verb as a person would say it, and unchanged if there is no better."""
        return str(verb).replace("_", " ")

    def _when(self, went: dict) -> str:
        """Intention: how long ago the last action was, as a short " · 12s ago" piece for the status
        line; "" if unknown.
        """
        ago = went.get("ago")
        if ago is None:
            return ""
        if ago < 90:
            return f" · {int(ago)}s ago"
        return f" · {int(ago // 60)}m ago"

    @staticmethod
    def _ago(stamp: str):
        """Seconds since a recorded moment, or nothing if it cannot be read."""
        if not stamp:
            return None
        try:
            when = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        except ValueError:
            return None
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - when).total_seconds())
