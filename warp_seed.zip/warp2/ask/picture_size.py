# WARP2/warp2/ask/picture_size.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/picture_size.py
#  Used by   : warp2/ask/media.py (extract_visual_subject drops the size words;
#              make_project_image takes the size), warp2/work/side/asked.py
#              (reads the size from what was asked).
#  Uses      : (stdlib) re.
#  Description:
#    The size a picture was asked for, read from the words of the ask:
#    "512x512", "1920 by 1080", "800 px", "300 pixels wide", "size 256".
#    Width first, then height; one number means a square. Nothing asked
#    means no size (the picture model's own).
#  User intention (Andrew, 2026-10-03): "it should be able to make images of
#    any size requested".
# ============================================================================
"""The size a picture was asked for."""
from __future__ import annotations

import re

_UNIT = r"(?:\s*(?:px|pixels?))?"
# Intention: the forms a size is said in, most specific first; each gives
# (width, height) from its match.
_FORMS = (
    (re.compile(rf"\b(\d{{1,6}}){_UNIT}\s*(?:x|×|\*|by)\s*(\d{{1,6}}){_UNIT}\b", re.I),
     lambda m: (int(m.group(1)), int(m.group(2)))),
    (re.compile(rf"\b(\d{{1,6}}){_UNIT}\s+wide\b", re.I), lambda m: (int(m.group(1)), int(m.group(1)))),
    (re.compile(rf"\b(\d{{1,6}}){_UNIT}\s+(?:tall|high)\b", re.I), lambda m: (int(m.group(1)), int(m.group(1)))),
    (re.compile(r"\b(\d{1,6})\s*(?:px|pixels?)\b(?:\s+square)?", re.I), lambda m: (int(m.group(1)), int(m.group(1)))),
    (re.compile(r"\bsize\s+(?:of\s+)?(\d{1,6})\b", re.I), lambda m: (int(m.group(1)), int(m.group(1)))),
)
# Intention: the little words left around a size once it is taken out.
_LEFT = re.compile(r"\b(?:at|in|of|sized?|with a size of|that is|which is)\s*$", re.I)


def requested_size(text: str) -> list:
    """[width, height] asked for in the words, or [] when no size was asked for (or it was nought)."""
    for form, sides in _FORMS:
        found = form.search(str(text or ""))
        if found:
            wide, high = sides(found)
            return [wide, high] if wide > 0 and high > 0 else []
    return []


def without_size(text: str) -> str:
    """Intention: the words with the size taken out, so "a cat 512x512" asks for a cat."""
    out = str(text or "")
    for form, _ in _FORMS:
        out = form.sub(" ", out)
    out = " ".join(out.split())
    return _LEFT.sub("", out).strip(" ,.;:")
