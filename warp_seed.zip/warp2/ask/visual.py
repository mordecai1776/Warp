# WARP2/warp2/ask/visual.py
# Pathway   : WARP2/warp2/ask/visual.py
# Used by   : ask/media.py, ask/window.py, work/loop.py, centering_image/experiment.py.
# Uses      : centering_image generator/readers, record locks/stop, util,
#             ask/practice_choice.py (which subject to practise), ask/blank.py
#             (a blank picture scores 0 before any reader is asked),
#             ask/picture_round.py (a round in small parts),
#             work/memory_floor.py (the memory floor before each weigher reading).
#             warp2/tags/media/pictures.py (is_there, bytes_of - asked of the small form; BUILD_LOG 1596c);
# Description: Shared reader-gated image learning. Every searched reference is
#              judged by the readers before it may be trained on, each is
#              trained at what it is worth, and a failed image sets the weight
#              and the next search rather than being taught as a negative.
# User intention (Andrew, 2026-09-12): "it should just keep retraining with new
#              internet data and retraining until it gives one that the reader
#              says is what was asked for"; "The reader should check the
#              internet data as well and only give what matches"; "it should
#              also be able to break that down when parts need to be trained."
#              The earlier shape of this file -- failed images trained as
#              negatives, and only human-confirmed references ever used -- is
#              recorded in `generate`, with why each half of it had to go.
#              2026-11-09 18:49: "use only internal models" - with
#              "internal_only" in models.json no Ollama reader is asked
#              (BUILD_LOG 1483); the house's own picture readers judge
#              (warp2/house/picture_reader.py, BUILD_LOG 1485).
from __future__ import annotations

import hashlib
import json
import sys
import time
import uuid
from pathlib import Path

from warp2.record.locks import Lock, Held
from warp2.record.stop import Stop
from warp2.util import atomic_write_bytes
from warp2.tags.media import pictures

# Intention: ONE STATEMENT OF WHAT A PERSON'S YES IS WORTH. This was a 3.0
# here and the same 3.0 applied as three passes of a training loop; it is now
# a weight, stated once, in the file that does the weighing. Kept under the old
# name because the window and the project's own code read it.
from warp2.ask.reference import CONFIRMED_LIFT as CONFIRMED_WEIGHT
from warp2.record.swallowed import noted

NORMAL_WEIGHT = 1.0
PRACTICE_SECONDS = 1800


def _digest(path):
    """Bind every approval to exact image bytes.

    Intention (BUILD_LOG 1596c): the bytes are asked of the small form (pictures.bytes_of): the file when it is in
    the warp, else the very bytes it had. An approval still binds after the picture's original has gone to deep
    storage. A picture that is nowhere raises as a missing file always did.
    """
    raw = pictures.bytes_of(path)
    if raw is None:
        raise FileNotFoundError(str(path))
    return hashlib.sha256(raw).hexdigest()


# What the measured record calls a vision read. One spelling, here.
READ_VERB = "read_image"

# Multi-directional concept domains for open-ended learning across all directions.
DIRECTIONAL_DOMAINS: dict[str, list[str]] = {
    "animals": [
        "cat", "dog", "owl", "fox", "dolphin", "horse", "eagle", "turtle",
        "tiger", "bear", "rabbit", "wolf", "deer", "panda", "otter"
    ],
    "nature": [
        "tree", "mountain", "river", "forest", "waterfall", "desert", "crystal",
        "cloud", "canyon", "volcano", "glacier", "ocean", "meadow", "island"
    ],
    "architecture": [
        "castle", "bridge", "tower", "cottage", "lighthouse", "arch", "temple",
        "pyramid", "windmill", "cabin", "monument", "gate", "colosseum"
    ],
    "tools_objects": [
        "compass", "telescope", "guitar", "hourglass", "lantern", "clock",
        "book", "key", "bell", "anchor", "sword", "shield", "cup", "camera"
    ],
    "vehicles": [
        "car", "locomotive", "airship", "sailboat", "bicycle", "submarine",
        "helicopter", "canoe", "train", "wagon", "spacecraft", "rowboat"
    ],
    "geometry": [
        "sphere", "cube", "torus", "spiral", "cylinder", "cone", "prism",
        "octahedron", "helix", "hexagon", "tetrahedron", "fractal"
    ],
    "fantasy_game": [
        "game_sprite", "potion", "dragon", "treasure_chest", "crystal_orb",
        "dungeon_door", "magic_wand", "golem", "rune", "crown"
    ],
    "celestial": [
        "moon", "sun", "nebula", "comet", "saturn", "asteroid", "constellation",
        "galaxy", "eclipse", "planet", "aurora", "star"
    ]
}


def discover_random_subjects(known_subjects: set[str], count: int = 2, seed: int | None = None) -> list[str]:
    """Sample random unlearned subjects across different directional domains."""
    import random
    rng = random.Random(seed)
    domains = list(DIRECTIONAL_DOMAINS.keys())
    rng.shuffle(domains)
    new_found = []
    for domain in domains:
        candidates = [s for s in DIRECTIONAL_DOMAINS[domain] if s not in known_subjects and s not in new_found]
        if candidates:
            chosen = rng.choice(candidates)
            new_found.append(chosen)
            if len(new_found) >= count:
                break
    return new_found


class VisualLearning:
    """One shared checkpoint and subject-specific, byte-bound evidence ledger."""
    def __init__(self, root, state):
        """Intention: find the centering_image project and put it on the import path, set up the ledger
        folder and the stop flag.
        """
        self.root, self.state = Path(root), Path(state)
        ci_path = self.root / 'projects' / 'centering_image'
        if not ci_path.is_dir():
            ci_path = Path(__file__).resolve().parents[2] / 'projects' / 'centering_image'
        if ci_path.is_dir() and str(ci_path) not in sys.path:
            sys.path.insert(0, str(ci_path))
        self.home = self.state / 'visual_learning'
        self.home.mkdir(parents=True, exist_ok=True)
        self.path = self.home / 'learning.json'
        self.stop = Stop(mirror=self.state / 'locks' / 'stop.flag')

    def _load(self):
        """Do not silently replace a corrupt evidence ledger."""
        return json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {
            'references': {}, 'attempts': {}, 'subjects': {}, 'last_practice': 0}

    def _save(self, data):
        """Publish evidence atomically under the shared model lock."""
        self._samples_out(data)
        atomic_write_bytes(self.path, json.dumps(data, ensure_ascii=False).encode())

    def _samples_out(self, data):
        """Keep each attempt's generated sample in its own file, not in the ledger.

        Intention: CLEAN — the ledger holds claims, the big things stay where
        they are and are named by path (Andrew's "split by kind", 2026-09-07).
        Every attempt carried its whole generated sample inline, about 70 KB
        each; 849 attempts made the ledger 203 MB, so every read and write of
        it — every confirm click, every practice round — moved 203 MB, and the
        Action Centre froze on confirm (measured 2026-09-18: 16 s just to read
        it on the VM). Nothing reads a sample back from here. The first save
        after this moves every inline sample out once; after that each new
        attempt's sample is written out as it is saved.
        """
        home = self.home / 'samples'
        for ident, attempt in (data.get('attempts') or {}).items():
            if not isinstance(attempt, dict) or 'sample' not in attempt:
                continue
            sample = attempt.pop('sample')
            where = home / f"{attempt.get('id') or ident}.json"
            if not where.is_file():
                atomic_write_bytes(where, json.dumps(sample, ensure_ascii=False).encode())
            attempt['sample_path'] = where.relative_to(self.state).as_posix()

    def _model(self):
        """The image model — pairs of pop networks since 2026-09-19 — and its shared note."""
        from warp2.ask.media import get_or_load_eye_model
        model = get_or_load_eye_model(self.root, self.state)
        if model is None:
            raise RuntimeError('Centering image model is unavailable')
        return model

    def _checkpoint(self, model):
        """Replace checkpoints only after the full replacement has been written.

        Intention: the file is named by `media.IMAGE_CHECKPOINT` and nowhere
        else, so the model and the thing that loads it cannot end up looking
        in two different places — which is how a machine quietly trains one
        model and reloads another.
        """
        from warp2.ask.media import IMAGE_CHECKPOINT
        target = self.state / 'models' / IMAGE_CHECKPOINT
        target.parent.mkdir(parents=True, exist_ok=True)
        pending = target.with_suffix('.pending.json')
        model.save(pending)
        pending.replace(target)

    def _readers(self):
        """Use configured readers or discover scoring-capable local vision readers.

        Intention: THE DEADLINE IS MEASURED, NOT PICKED. Andrew asked for a cat
        on 2026-09-12 while a LoRA round was fourteen minutes in at about
        fourteen seconds a step, and the record of that attempt reads
        `[{"name": "...:9b", "error": "timed out"}]`. A nine-billion parameter
        vision model was given a flat forty-five seconds on a machine that was
        busy training — so nothing could judge the picture, so the round that
        is supposed to keep going until a reader says yes had no verdict to go
        on and stopped after one.

        A fixed number in a tree whose deadline file opens with "No fixed
        timeouts" was always going to do this. What a read costs is now learned
        the same way training's cost is: unmeasured it is generous, and after
        three reads it is the measured middle plus room for the spread this
        machine actually shows. `available_readers` still pings ollama with a
        one second timeout, so a reader that is not there is refused quickly
        rather than waited on.
        """
        # Intention (BUILD_LOG 1483): with only internal models (models.json), no Ollama vision reader is asked.
        # (BUILD_LOG 1485) The house's own picture readers judge instead; with none on its shelf a picture is
        # "not judged", never passed.
        from warp2.models.internal import internal_only
        if internal_only(self.root):
            from warp2.house.picture_reader import house_readers
            return house_readers(self.root, self.state)
        from readers import OllamaReader, available_readers
        config_path = self.home / 'settings.json'
        settings = json.loads(config_path.read_text()) if config_path.exists() else {}
        names = settings.get('readers')
        if names is None:
            names = available_readers()
            if not names:
                names = ['moondream:latest', 'huihui_ai/qwen3.5-abliterated:9b']
        waited = self._deadlines().budget(READ_VERB)['seconds']
        # Intention (2026-10-09, fix 3.8): the learned read cost is now the
        # wait on silence between streamed pieces — a reader still writing is
        # never cut off — and every vision reader is asked, not the first two.
        return [OllamaReader(name, timeout=waited) for name in names]

    def _deadlines(self):
        """What this machine has learned things cost.

        Intention: read fresh each time rather than held, because the loop is
        writing the same file from another process and a held copy would answer
        with whatever was true when the window opened.
        """
        from warp2.record.deadline import Deadlines
        return Deadlines(self.state / 'deadlines.json')

    def references(self, subject=None, status=None):
        """Only unchanged bytes retain confirmation; references never cross subjects.

        Intention: READ WITHOUT THE WRITER'S LOCK. This is what the window
        calls to draw, and `generate` holds that same lock for about a minute
        at a time — across the model, both readers at forty-five seconds each,
        and a search of Wikimedia. So every attempt to draw the list queued
        behind a network call, and Andrew rejected an image and watched the
        window freeze.

        A reader does not need the writer's lock here, because `_save` writes a
        temporary file and replaces it: a reader sees either the whole old file
        or the whole new one, never a torn one. Taking the lock bought nothing
        and cost the window.
        """
        rows = list(self._load()['references'].values())
        return [row for row in rows if (subject is None or row['subject'] == subject)
                and (status is None or row['status'] == status)
                and pictures.is_there(row['path']) and _digest(row['path']) == row['digest']]

    def first_reference(self, status=None, skip=()):
        """The first reference (in ledger order) with a subject, whose digest is not in `skip` and whose bytes are
        still the ones confirmed; or None.

        Intention (2026-11-01, measured: the Eye turn's `references(status="confirmed")` hashed all 31,607 confirmed
        pictures, 839 MB on OneDrive, minutes of a thirteen-minute turn, to use one): the same check as
        `references`, made only of the rows that could be used, one at a time, until one passes. A row whose bytes
        changed is passed over exactly as `references` drops it.
        """
        skip = set(skip)
        for row in self._load()['references'].values():
            if (status is None or row.get('status') == status) and row.get('subject') \
                    and row.get('digest') not in skip \
                    and pictures.is_there(row['path']) and _digest(row['path']) == row['digest']:
                return row
        return None

    # Intention (2026-10-09, fix 3.5, check B11): one place a found picture
    # enters the ledger — the round's search and the chat's "search &
    # research" both — so a picture a person confirms is in the ledger to be
    # confirmed. Research results were never saved, and confirming one
    # answered "confirmed" for a row that did not exist.
    def _take_found(self, data, subject, path, ref, readers=None, round_no=0, wanted=None, judged=None):
        """Own the found picture's bytes, judge it (unless `judged` is given), and add its pending row; its id."""
        from readers import test_searched_image
        from concept_terms import extract_all_tags
        digest = _digest(path)
        ident = hashlib.sha256((subject + digest).encode()).hexdigest()
        if ident in data['references']:
            return ident
        # Own immutable candidate bytes even if a provider reuses a filename.
        owned = self.home / 'references' / (digest + path.suffix)
        owned.parent.mkdir(parents=True, exist_ok=True)
        if not owned.exists():
            atomic_write_bytes(owned, path.read_bytes())
        # Test searched reference candidate with vision readers
        eval_res = judged if judged is not None else test_searched_image(owned, {'name': subject}, readers=readers)
        ref_tags = eval_res.get('tags') or extract_all_tags(ref, subject=subject)
        if eval_res.get('observation'):
            ref_tags.extend(extract_all_tags(eval_res['observation'], subject=subject))
        ref_tags = sorted(set(ref_tags))
        data['references'][ident] = dict(
            id=ident, subject=subject, path=str(owned.resolve()),
            digest=digest, status='pending', source=ref, weight=NORMAL_WEIGHT,
            # Intention: WHEN, AND FOR WHICH ROUND. Both are readings in
            # the weighting -- fresh data counts more, and the batch
            # fetched BECAUSE the last attempt failed counts more still.
            # Neither could be asked of a reference that only knew its
            # own bytes. See warp2/ask/reference.py.
            found_at=time.time(), round=int(round_no), wanted=list(wanted or ()),
            reader_score=eval_res.get('score', 0.0),
            reader_observation=eval_res.get('observation', ''),
            reader_verdict=('verified' if eval_res.get('passed') else
                            'not_judged' if eval_res.get('judged') is False else 'unverified'),
            readers=eval_res.get('readers', []),
            tags=ref_tags,
            concept_scores=eval_res.get('detected_concepts', {}),
            concept_tags=eval_res.get('concept_tags', []),
            attached_datasets=eval_res.get('attached_datasets', []),
            preemptive_concepts=eval_res.get('preemptive_concepts', []),
        )
        try:
            from concept_separation import ConceptSeparationStore
            ConceptSeparationStore.instance(self.state).record_observation(
                image_id=ident,
                path=owned,
                subject=subject,
                concept_scores=eval_res.get('detected_concepts', {}),
                attached_datasets=eval_res.get('attached_datasets', []),
                preemptive_concepts=eval_res.get('preemptive_concepts', []),
            )
        except Exception as exc:
            noted("warp2/ask/visual.py:VisualLearning._take_found", exc)
        return ident

    def keep_found(self, subject, path, ref=None, judged=None) -> dict:
        """A picture found outside a round, kept in the ledger as pending with its reader verdict; its row."""
        with Lock(self.path):
            data = self._load()
            ident = self._take_found(data, subject, Path(path), dict(ref or {}), self._readers()
                                     if judged is None else None, judged=judged)
            self._save(data)
            return dict(data['references'][ident])

    def _search(self, data, subject, search=None, wanted=None, round_no=0):
        """Search for what the readers said was missing; judge every candidate.

        User intention (Andrew, 2026-09-12):
        "it should also be able to break that down when parts need to be trained."
        The query used to be the subject with an adjective bolted on by a
        counter -- 'photograph closeup', then 'photograph object' -- which is a
        guess, while the readers had already said what was missing and nobody
        read it. Now the parts decide what to go and get.
        """
        from image_search import MultiSourceSearch, CommonsSearch
        from warp2.ask.parts import Parts
        try:
            search = search or MultiSourceSearch(
                providers=["commons", "wikipedia", "openverse"],
                timeout=12,
                limit=6,
                deduplicate=True,
            )
        except Exception:
            search = search or CommonsSearch(timeout=8, limit=4)
        asked = Parts().queries(subject, wanted)
        found = []
        errors = []
        for query in asked:
            try:
                found.extend(search.fetch({'name': query}, self.home / 'references'))
            except Exception as exc:
                errors.append(f'{query}: {exc}')
        if not found:
            return [], '; '.join(errors)
        readers_to_use = self._readers()
        rows = []
        for ref in found:
            path = Path(ref.get('image_path', ''))
            if not path.is_file():
                continue
            ident = self._take_found(data, subject, path, ref, readers_to_use, round_no, wanted)
            row = data['references'][ident]
            if row['status'] == 'pending':
                rows.append(row)
        return rows, ''

    def confirm(self, reference_id, accepted, confirmed_by: str = "user"):
        """Record yes/no/unknown without teaching from an uncertain answer.

        ``None`` (or ``"unknown"``) means the person could not identify the
        reference. It remains visible in the ledger for research, but is not a
        positive or negative training example and the subject stays in need of
        references.
        """
        unknown = accepted is None or str(accepted).lower() == "unknown"
        confirmed = bool(accepted) and not unknown
        with Lock(self.path):
            data = self._load()
            row = data['references'].get(reference_id)
            if row is None:
                row = next((r for r in data['references'].values()
                            if r.get('id') == reference_id or Path(r.get('path', '')).stem == reference_id), None)
            if row is None:
                # Intention (2026-10-09, fix 3.5, check B11): nothing to confirm
                # is said plainly — it answered "confirmed" for a missing row.
                return {'status': 'not_found', 'id': reference_id, 'subject': ''}
            if _digest(row['path']) != row['digest']:
                raise ValueError('Reference changed; review the new image before confirming')
            if row['status'] != 'pending':
                return dict(row)
            row.update(status='unknown' if unknown else ('confirmed' if confirmed else 'rejected'),
                       confirmed_by=str(confirmed_by or 'user'), confirmed_at=time.time(),
                       weight=CONFIRMED_WEIGHT if confirmed else 0)
            data['subjects'][row['subject']] = 'ready' if confirmed else 'needs_references'
            self._save(data)
            return dict(row)

    def generate(self, subject, readers=None, search=None, negative_path=None,
                 wanted=None, round_no=0, size=None):
        """One generate/read/search cycle, weighted, and never waiting on a person.

        User intention (Andrew, 2026-09-12):
        "it should just keep retraining with new internet data and retraining
        until it gives one that the reader says is what was asked for", and
        "The reader should check the internet data as well and only give what
        matches."

        Three things changed here and each of them was stopping that.

        IT WAITED FOR A PERSON. Only references a human had clicked
        `confirmed` were ever trained on, so a machine left to itself fetched
        references, had the readers score every one of them, and then trained
        on none of them for ever. The reader's verdict now admits a reference;
        a person's still outranks it. See `usable` in warp2/ask/reference.py.

        IT WEIGHTED BY REPETITION. A confirmed reference was trained three
        times in a loop, which is three steps of drift towards one picture
        where one weighted step was wanted -- and the model's own
        `train_example(example, weight)` has always taken a weight that nothing
        ever set to anything but 1.0.

        IT TRAINED ON THE FAILURE. A failed generation was fed back as a
        negative example. That is against Andrew's own standing rule -- the
        mistake sets the weight and is never the lesson -- and the evidence on
        models this size is blunt: arXiv 2512.22293 (Llama-3.2-3B, Gemma-2-2B)
        found training on warning-framed negatives reproduced the flagged
        content at 76.7% against 83.3% for models simply shown it, because
        "describing X" and "performing X" share latent features. The failure
        is still recorded, counted, and used to decide what to search for next.

        Since 2026-10-02 the round is run in parts (warp2/ask/picture_round.py)
        -- weigh, teach one reference at a time, practise, draw (a blank fails
        there), read, search, record -- and this runs them all in one call, as
        it always did. `step` runs one part at a time. `size` is [width,
        height] when a size was asked for (warp2/ask/picture_size.py).
        """
        from warp2.ask import picture_round
        state = picture_round.start(subject, round_no, wanted, negative_path, size=size)
        return picture_round.PictureRound(self, readers, search).run(state)

    def step(self, subject, state=None, wanted=None, round_no=0, readers=None, search=None, size=None):
        """One part of a picture round; returns (state, report, result-or-None).

        Intention (Andrew, 2026-10-02): "that is too long to wait for a
        possible failure. We need to split it out into more small directed
        parts." Each part is short and says what it did and how long it took;
        `state` (JSON-able) is where the round got to, carried by the caller.
        """
        from warp2.ask import picture_round
        state = state or picture_round.start(subject, round_no, wanted, size=size)
        return picture_round.PictureRound(self, readers, search).step(state)

    def _weighed(self, data, mine, subject: str, round_no: int, wanted) -> list:
        """What each reference is worth, from the trained weigher if there is one.

        Intention: the whole ledger is the record it learns from — every
        attempt at an image and what the readers scored it, and every reference
        and what they scored that. That is "all data it can find that is of the
        same type", and it is already sitting in this file.
        """
        from warp2.ask.reference import Worth
        from warp2.train.weigher import Kin, Weigher
        weigher = Weigher("image", fresh=False)
        if not weigher.ready:
            return Worth(latest_round=int(round_no), parts=wanted).over(mine)
        # How the part asking is doing: what the readers have said of the
        # pictures made for this subject so far.
        went = [float((one.get("evidence") or {}).get("score") or 0.0)
                for one in data["attempts"].values()
                if one.get("subject") == subject]
        doing = (sum(went) / len(went)) if went else 0.5
        rows = list(data["references"].values()) + [
            {"score": (one.get("evidence") or {}).get("score"),
             "image_path": one.get("image_path"),
             "time": one.get("time"),
             "readers": one.get("readers")}
            for one in data["attempts"].values()]
        # Intention (2026-10-17, BUILD_LOG 302): THE EYE'S READINGS HERE ARE
        # PICTURE WORK TOO. Three native crashes in one hour (exit 0xC0000005)
        # were all inside this weighing, in a different line each time — the
        # mark of the machine running out of memory, not of one bad line. The
        # same floor the painter keeps is checked before the weigher learns and
        # before each reading; under it the part stops cleanly (LowMemory,
        # caught in warp2/ask/until.py) and the next turn carries on.
        from warp2.work.memory_floor import above_floor
        had = weigher.had()
        start = int(had.get("count", 0) or 0)
        if start < len(rows):
            new_rows = rows[start:]
            above_floor("weigher: learning what references were worth")
            weigher.learn_from(new_rows[:64], doing=doing)
            weigher.mark(min(len(rows), start + 64), "")
        kin = Kin(one.get("reader_score") for one in data["references"].values())
        weighed = weigher.over(mine, doing=doing, kin=kin,
                               before_each=lambda: above_floor("weigher: reading what a reference is worth"))
        return [{"reference": one["item"], "weight": one["weight"]}
                for one in weighed]

    def _remember(self, subject: str, resume) -> None:
        """Keep where a split job got to, or forget it when it is finished.

        Intention: written under the lock and nowhere else, because it is part
        of the ledger — and cleared on an ending so a subject that finished
        does not look part way through for ever, which would make it the one
        picked first every single turn.
        """
        with Lock(self.path):
            data = self._load()
            waiting = data.setdefault('progress', {})
            if resume:
                waiting[str(subject)] = dict(resume)
            else:
                waiting.pop(str(subject), None)
            self._save(data)

    def approve_attempt(self, image_path, confirmed_by: str = "user", subject: str = ""):
        """Confirmation approves an attempt, marking it stored and permanent with accurate attribution."""
        resolved = str(Path(image_path).resolve())
        with Lock(self.path):
            data = self._load()
            attempt = next((a for a in data['attempts'].values() if a['image_path'] == resolved), None)
            stem_name = Path(image_path).stem
            subj = subject or (attempt.get("subject") if attempt else "") or stem_name
            if subj == "user_confirmed":
                subj = stem_name
            by = str(confirmed_by or 'user')
            if attempt is None:
                digest = _digest(image_path) if pictures.is_there(image_path) else ''
                attempt_id = stem_name
                attempt = dict(
                    id=attempt_id,
                    subject=subj,
                    image_path=resolved,
                    digest=digest,
                    approved=True,
                    confirmed_by=by,
                    confirmed_at=time.time(),
                    time=time.time(),
                )
                data['attempts'][attempt_id] = attempt
            else:
                attempt['approved'] = True
                attempt['confirmed_by'] = by
                if subj and attempt.get('subject') in ('', 'user_confirmed'):
                    attempt['subject'] = subj
                attempt['confirmed_at'] = time.time()
            self._save(data)
            return dict(attempt)

    def approved_paths(self) -> set[str]:
        """Load approved paths in a single read of the ledger for batch UI rendering."""
        data = self._load()
        return {a['image_path'] for a in data.get('attempts', {}).values()
                if a.get('approved') and (a.get('confirmed_by') in ('user', 'system') or a.get('digest'))}

    def approved(self, path):
        """Old images and changed bytes cannot bypass reader approval in any gallery.

        Intention: the same reading, without the writer's lock, for the same
        reason — see `references` above. The gallery asks this per image every
        time it draws.
        """
        data = self._load()
        resolved = str(Path(path).resolve())
        return any(a['image_path'] == resolved and a.get('approved') and pictures.is_there(path)
                   and (_digest(path) == a.get('digest') or a.get('confirmed_by') in ('user', 'system'))
                   for a in data['attempts'].values())

    def discover_new_subjects(self, data: dict, count: int = 1, search_online: bool = True) -> list[str]:
        """Discover and enroll random subjects across all directional domains and online sources.

        User intention (Andrew, 2026-09-15):
        "it should look for more random things to learn in all directions."
        "it should search online for more games images and concepts to learn"
        """
        known = set(data.get('subjects', {}).keys())
        for ref in data.get('references', {}).values():
            for tag in ref.get('tags', []):
                if 3 <= len(tag) <= 15 and tag.isalpha() and tag not in known:
                    known.add(tag)

        found: list[str] = []
        if search_online:
            try:
                from warp2.ask.online_concepts import OnlineConceptSearcher
                searcher = OnlineConceptSearcher(timeout=4)
                online_concepts = searcher.fetch_random_concepts(count=count * 2)
                for concept in online_concepts:
                    subj = concept.subject
                    if subj and subj not in known and subj not in found:
                        found.append(subj)
                        if concept.image_url:
                            # Pre-download candidate image for reference evaluation
                            searcher.download_image(concept.image_url, self.home / 'references')
                        if len(found) >= count:
                            break
            except Exception as exc:
                noted("warp2/ask/visual.py:VisualLearning.discover_new_subjects", exc)

        if len(found) < count:
            remaining = count - len(found)
            from_taxonomy = discover_random_subjects(known.union(found), count=remaining)
            found.extend(from_taxonomy)

        for s in found:
            data.setdefault('subjects', {})[s] = 'needs_references'
        return found

    def user_asked_subjects(self) -> set[str]:
        """Subjects explicitly asked for or tasked by the user.

        User intention (Andrew, 2026-09-27):
        - "that should only be for user asked things"
        - "the cube was a training thing it should have not been closed out it just should have been put somewhere else"
        Visual practice for chat/user asks only selects subjects the user explicitly tasked.
        Synthetic 3D training assets (e.g. cube, primitives) are trained in their dedicated
        3D/Blender pipeline (BlenderStep, RandomTraining, TrainingBlockIngestor), segregated
        from user picture tasks.
        """
        from warp2.ask.media import extract_visual_subject
        subjects = set()
        asked_dir = self.state / "asked"
        if asked_dir.is_dir():
            for f in asked_dir.glob("*.json"):
                if f.stem in ("waiting", "ratings", "files"):
                    continue
                try:
                    row = json.loads(f.read_text(encoding="utf-8"))
                    if row.get("kind") in ("image", "video", "request") and row.get("said"):
                        sub = extract_visual_subject(str(row["said"]))
                        if sub and sub.lower() != "cube":
                            subjects.add(sub)
                except Exception:
                    continue
        ci_inbox = self.state / "centering_image" / "inbox"
        if ci_inbox.is_dir():
            for f in ci_inbox.glob("*.json"):
                try:
                    row = json.loads(f.read_text(encoding="utf-8"))
                    sub = extract_visual_subject(str(row.get("subject") or ""))
                    if sub and sub.lower() != "cube":
                        subjects.add(sub)
                except Exception:
                    continue
        cat_file = self.state / "images" / "catalog.jsonl"
        if cat_file.is_file():
            try:
                for line in cat_file.read_text(encoding="utf-8", errors="replace").splitlines():
                    if line.strip():
                        item = json.loads(line)
                        if item.get("confirmed_by") == "user" and item.get("subject"):
                            sub = extract_visual_subject(str(item["subject"]))
                            if sub and sub.lower() != "cube":
                                subjects.add(sub)
            except Exception as exc:
                noted("warp2/ask/visual.py:VisualLearning.user_asked_subjects", exc)
        return subjects

    def practice(self, now=None, every=None, mistakes=None, at_a_time=1):
        """One centering subject, carried through until a reader accepts it.

        Intention: `every` IS THE CALLER'S TO SET. This held its own thirty
        minute clock, and the loop now decides what share of the machine's time
        training gets from how much of its work is being refused — so a fixed
        interval here would quietly overrule that, and the stricter of the two
        gates would always be this one. Passed nothing, it behaves exactly as
        it did; passed nought, the caller is the gate.
        """
        now = time.time() if now is None else now
        every = float(PRACTICE_SECONDS if every is None else every)
        try:
            with Lock(self.path, seconds=0.1):
                data = self._load()
                if self.stop.raised() or (every > 0 and now-data['last_practice'] < every):
                    return {'status': 'not_due'}

                # User intention (Andrew, 2026-09-27): "that should only be for user asked things".
                # Visual practice must ONLY run on subjects explicitly asked for by the user.
                # Never auto-enroll unasked taxonomy concepts or random shapes.
                allowed = self.user_asked_subjects()
                from warp2.ask.practice_choice import choose
                subject = choose(data, allowed_subjects=allowed)
                if not subject:
                    data['last_practice'] = now
                    self._save(data)
                    return {'status': 'nothing_to_practise', 'why': 'only user asked things are practised'}
                resume = dict(data.setdefault('progress', {}).get(subject) or {})
                data['last_practice'] = now
                self._save(data)
            # Intention: THE SAME ROUND AS EVERYTHING ELSE. Practice used to be
            # one generation, and whatever came out was the practice. Andrew:
            # keep retraining with new internet data until the reader says it
            # is what was asked for — practice is exactly where that should
            # happen, because nobody is waiting on it.
            # Intention: ONE ROUND, THEN HAND THE LOOP BACK. Andrew,
            # 2026-09-12: "it is fine if it spends the entire process if it is
            # a user need just not if it is on its own work that should be
            # split up." Nobody asked for this picture, so it takes its turn
            # like everything else — MEASURED at 338 seconds of the whole loop
            # before this, for six rounds nobody was waiting on.
            from warp2.ask.until import Until
            # Intention: AND IT DOES NOT STOP UNTIL IT PASSES (warp2/ask/until.py).
            went = Until(self, mistakes=mistakes, until_it_passes=True).make(
                subject, resume=resume, at_a_time=int(at_a_time))
            self._remember(subject, went.get('resume'))
            result = dict(went.get('best') or {})
            result.update(image_path=went.get('image_path', ''),
                          approved=went.get('approved', False),
                          status='approved' if went.get('approved') else went.get('how', ''),
                          rounds=went.get('rounds', 0), missing=went.get('missing', []),
                          said=went.get('said', ''), tried=went.get('tried', []))
            # Intention (BUILD_LOG 833): THE ANSWER NAMES ITS SUBJECT. `best` is
            # the best round's result, which carries no subject, so the step
            # (warp2/work/side/images.py) read "" on every practice turn and
            # skipped writing the training block, the self-confirm and the
            # last subject (seen 2026-10-27/28: subject "" in every journal
            # entry). The subject practised is the one chosen above.
            result['subject'] = str(went.get('subject') or subject)
            # Intention: practice is the machine's own work, so it is reported
            # to the image feed, not the conversation (see ask/thread.py).
            # Candidate image path is passed so in-progress practice surfaces in the review panel.
            candidate_image = result.get('image_path') or None
            from warp2.ask.thread import WARP, image_feed
            image_feed(self.state).add(WARP, f"Centering practice: {subject} — {result.get('status')}",
                subject=subject, image=candidate_image,
                reference_reviews=result.get('reference_reviews'), references=result.get('references'))
            return result
        except Held:
            return {'status': 'busy'}
