# WARP2/warp2/ask/reference.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/reference.py
#  Used by   : warp2/ask/visual.py (what each reference is worth before it is
#              trained on), warp2/ask/until.py, warp2/ask/media.py (taught_score).
#  Uses      : warp2/settings.py; stdlib datetime.
#  Description:
#    What one searched reference image is worth for one subject, and why. Four
#    readings — how well the reader says it matches, whether a person confirmed
#    it, how fresh it is, and whether it is the new data fetched because the
#    last attempt failed — each bounded, multiplied, and normalised so the
#    average reference still counts one.
#  User intention (Andrew, 2026-09-12):
#    "it should just keep retraining with new internet data and retraining
#    until it gives one that the reader says is what was asked for", and
#    "The reader should check the internet data as well and only give what
#    matches."
#
#    WHAT WAS THERE. Two constants: `NORMAL_WEIGHT = 1.0` passed to every
#    single `train_example` call, and `CONFIRMED_WEIGHT = 3.0` applied by
#    RUNNING THE SAME EXAMPLE THROUGH THREE TIMES rather than by weighting it.
#    So a reference the reader scored 0.61 and one it scored 1.0 counted the
#    same, and freshly fetched data counted the same as a fortnight-old file.
#    The model's own `train_example(example, weight)` has always taken a
#    weight; nothing ever passed one that was not 1.0.
#
#    THE READER'S SCORE LIFTS RATHER THAN SINKS. This is the one that looks
#    backwards and is not: FLOW (arXiv 2502.02797) weights each sample
#    `exp(-loss/tau)` — UPWEIGHTING the ones the model already handles well —
#    and reports about 17% higher average accuracy on vision against plain
#    fine-tuning, because boosting the well-learned examples holds the model
#    still instead of dragging it. The instinct to pour weight into the worst
#    reference is the one that causes drift.
#
#    NOTHING HERE IS TRAINED ON A FAILURE. The bad generation sets the weight
#    and is never the lesson — Andrew's own rule, and the evidence is blunt on
#    small models: arXiv 2512.22293, on Llama-3.2-3B and Gemma-2-2B, found
#    models trained on warning-framed negatives reproduced the flagged content
#    at 76.7% against 83.3% for models simply given it — statistically
#    indistinguishable — because "describing X" and "performing X" share latent
#    features. Showing a small model a wrong picture labelled "wrong" mostly
#    teaches it the wrong picture.
# ============================================================================
from __future__ import annotations

from datetime import datetime, timezone

from warp2.settings import fraction

# What the reader's own score is worth, from the match bar up to a perfect one.
LEAST_READ = fraction("WARP2_REF_LEAST_READ", 0.5, minimum=0.05)
MOST_READ = fraction("WARP2_REF_MOST_READ", 1.5, minimum=0.1)

# What a person saying yes is worth over a reader saying yes. Three, which is
# the number this tree already used — carried over as a WEIGHT rather than as
# three passes of the same example, so it is one statement in one place.
CONFIRMED_LIFT = fraction("WARP2_REF_CONFIRMED_LIFT", 3.0, minimum=1.0)

# How quickly a reference stops being fresh, and how far age may push it down.
HALF_LIFE_HOURS = fraction("WARP2_REF_HALF_LIFE_HOURS", 72.0, minimum=0.1)
OLDEST_WORTH = fraction("WARP2_REF_OLDEST_WORTH", 0.5, minimum=0.05)

# What the batch fetched because of the latest failure is worth over the rest.
# This is the mistake setting the weight: the newest data was gone and got
# BECAUSE the last attempt was refused, which is what makes it the data most
# likely to fix it.
NEW_DATA_LIFT = fraction("WARP2_REF_NEW_DATA_LIFT", 2.0, minimum=1.0)

# What covering a part the readers said was missing is worth, per part.
# Intention: Andrew, 2026-09-12 — "it should also be able to break that down
# when parts need to be trained." A reference that shows the wheel the reader
# said was missing is the reference this round exists to find, and it must not
# count the same as another picture of the whole bicycle.
PART_LIFT = fraction("WARP2_REF_PART_LIFT", 1.5, minimum=1.0)

# The outer edges of one reference's weight, so no single reading can silence
# the rest or drown them.
LEAST = fraction("WARP2_REF_LEAST", 0.1, minimum=0.001)
MOST = fraction("WARP2_REF_MOST", 8.0, minimum=1.0)


def _when(stamp):
    """A moment from whatever the ledger happens to hold, or nothing.

    Intention: references carry a unix time from `time.time()` and facts carry
    text. Either has to read, and neither may raise — a reference with an
    unreadable stamp is still a reference.
    """
    if stamp in (None, ""):
        return None
    try:
        return datetime.fromtimestamp(float(stamp), tz=timezone.utc)
    except (TypeError, ValueError, OSError, OverflowError):
        pass
    try:
        moment = datetime.fromisoformat(str(stamp))
    except (TypeError, ValueError):
        return None
    return moment if moment.tzinfo else moment.replace(tzinfo=timezone.utc)


class Worth:
    """What each reference is worth for this subject, and the reading behind it."""

    def __init__(self, now=None, latest_round: int = 0, parts=None) -> None:
        """Intention: keep the time, the latest round and the missing parts that the worth of each
        reference is judged by.
        """
        self.now = now or datetime.now(timezone.utc)
        self.latest_round = int(latest_round)
        # Intention: the parts the readers said were missing, so a reference
        # that shows one of them is worth more than one that shows the subject
        # again. Empty is the ordinary case and changes nothing.
        self.parts = [str(one) for one in (parts or ()) if str(one).strip()]

    def by_reader(self, reference) -> float:
        """Lifted by how well the reader said it matches.

        Intention: FLOW's finding, applied. The reference the reader is surest
        about is the one that holds the model steady; the one it barely passed
        is the one that drags it. A reference with no score reads as the bottom
        of the range rather than the middle, because "nobody could look at it"
        is not the same as "it was fine".
        """
        try:
            score = float((reference or {}).get("reader_score"))
        except (TypeError, ValueError):
            return float(LEAST_READ)
        score = max(0.0, min(1.0, score))
        return float(LEAST_READ) + (float(MOST_READ) - float(LEAST_READ)) * score

    def by_person(self, reference) -> float:
        """Lifted when a person confirmed these exact bytes.

        Intention: a person outranks a reader, and this is where the tree's old
        `CONFIRMED_WEIGHT` went. It is a weight now instead of a loop that
        trained the same example three times, because three passes of one
        example is three steps of drift towards it and one weight is one step.
        """
        # Intention (2026-10-09, fix 3.5, check B6): a PERSON's yes — not a
        # dataset's label ("dataset:<name>") or the machine's own ("system").
        # Rows from before confirmed_by was written were a person's.
        by = str((reference or {}).get("confirmed_by") or "user")
        return (float(CONFIRMED_LIFT)
                if str((reference or {}).get("status") or "") == "confirmed" and by == "user" else 1.0)

    def by_time(self, reference) -> float:
        """Lowered by age, never to nothing.

        Intention: each round of this loop goes and gets new data, so freshness
        is the difference between the batch that was fetched to fix the problem
        and the batch that did not. An old reference is still a true picture of
        the subject, so it keeps a floor.
        """
        stamp = _when((reference or {}).get("found_at"))
        if stamp is None:
            return 1.0
        hours = max(0.0, (self.now - stamp).total_seconds() / 3600.0)
        decayed = 0.5 ** (hours / float(HALF_LIFE_HOURS))
        return float(OLDEST_WORTH) + (1.0 - float(OLDEST_WORTH)) * decayed

    def by_round(self, reference) -> float:
        """Lifted when this is the data fetched because the last attempt failed.

        Intention: THE MISTAKE SETTING THE WEIGHT, for images. Everything known
        about the subject stays in the training — Andrew's rule is "everything
        that is known with the added mistake" — and what the failure changes is
        which references pull hardest, which is the batch that was gone and got
        in answer to it.
        """
        if not self.latest_round:
            return 1.0
        try:
            got = int((reference or {}).get("round") or 0)
        except (TypeError, ValueError):
            return 1.0
        return float(NEW_DATA_LIFT) if got >= self.latest_round else 1.0

    def by_part(self, reference) -> float:
        """Lifted by how many of the missing parts this reference shows.

        Intention: compounding per part, because a picture that shows both the
        wheel and the frame the reader missed is worth more than two pictures
        that each show one — it teaches the parts in the same place they
        actually sit. Bounded by how many parts a round chases, which is three.
        """
        if not self.parts:
            return 1.0
        from warp2.ask.parts import Parts
        covered = Parts().covered_by(reference, self.parts)
        return float(PART_LIFT) ** max(0, int(covered))

    def weigh(self, reference) -> dict:
        """One reference's weight, with every reading that made it."""
        because = {"reader": round(self.by_reader(reference), 4),
                   "person": round(self.by_person(reference), 4),
                   "time": round(self.by_time(reference), 4),
                   "round": round(self.by_round(reference), 4),
                   "part": round(self.by_part(reference), 4)}
        product = 1.0
        for value in because.values():
            product *= float(value)
        return {"weight": round(min(float(MOST), max(float(LEAST), product)), 4),
                "because": because}

    def over(self, references) -> list:
        """Every reference's weight, averaging one.

        Intention: THE AVERAGE IS ONE, ALWAYS — the same rule as the code side,
        for the same reason. A weight scales the step this example takes, so a
        batch whose weights average three trains at three times the rate, and
        the result would be read as "the weighting helped" when all that
        changed was how far every step went.
        """
        weighed = [self.weigh(one) for one in (references or ())]
        if not weighed:
            return []
        mean = sum(one["weight"] for one in weighed) / len(weighed)
        if mean <= 0:
            return [{**one, "weight": 1.0} for one in weighed]
        return [{**one, "weight": round(one["weight"] / mean, 4)} for one in weighed]


def usable(reference) -> bool:
    """Whether this reference may be trained on at all.

    Intention: ANDREW, 2026-09-12 — "only give what matches". A person's yes
    admits it; a reader's yes admits it; anything else does not, and that
    includes the pending references this tree used to sit on for ever waiting
    for somebody to click. Waiting for a person is what stopped the loop being
    able to finish on its own, and the reader is already looking at every one
    of these — see `test_searched_image` in the centering project.
    """
    status = str((reference or {}).get("status") or "")
    if status == "confirmed":
        return True
    if status == "rejected":
        return False
    return str((reference or {}).get("reader_verdict") or "") == "verified"


# Intention (2026-10-09, fix 3.5, check B6): the score a reference is taught
# at — the readers' own when they gave one, a person's yes as 1.0, and nothing
# (not taught) for a reference that is not usable. A missing score was taught
# as 1.0, and rejected or pending references were taught as the subject.
def taught_score(reference) -> float | None:
    """The score to teach this reference at, or None when it is not to be taught."""
    if not usable(reference):
        return None
    said = (reference or {}).get("reader_score")
    if type(said) in (int, float):
        return float(said)
    return 1.0 if str((reference or {}).get("status")) == "confirmed" else None
