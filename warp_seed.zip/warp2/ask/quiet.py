# WARP2/warp2/ask/quiet.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/quiet.py
#  Used by   : warp2/ask/window.py, which needs to READ the store to pick a
#              model and must never WRITE to it.
#  Uses      : nothing. It wraps whatever store it is handed.
#  Description:
#    A store that answers questions and refuses to remember anything. Reads go
#    through; writes are dropped and counted.
#  User intention (Andrew, 2026-09-07):
#    "the store first, a model on top" — and the window writes a turn and a
#    request and touches the store never. This is that rule, in code, instead
#    of in a comment.
# ============================================================================
from __future__ import annotations


class Quiet:
    """Reads pass through. Writes go nowhere, and are counted.

    Intention: THE RULE WAS KEPT BY HANDING THE FLEET NO STORE AT ALL, and that
    is why the window could never find a model. `Fleet.enlist` states two facts
    about every model it takes on; with `TagNet(None)` behind it, the first one
    raised AttributeError, the whole assembly was swallowed by a broad `except`,
    and `_a_model` returned None every single time on every machine. The window
    has been "store first, model never" since it was built, and nothing said so
    because the failure was silent by design.

    Dropping a write is the honest version of the same rule: the fleet can be
    assembled and ranked on real weights, and nothing it does while being
    assembled reaches the record.
    """

    def __init__(self, store) -> None:
        """Intention: wrap the real store and count the writes that were dropped."""
        self.store = store
        self.dropped = 0

    def assert_fact(self, *args, **kwargs) -> str:
        """Intention: drop a fact write and count it, so the fleet can be put together without writing to the record."""
        # Intention: it returns what a real write returns — a key-shaped string
        # — so a caller that keeps the answer is not the next thing to break.
        self.dropped += 1
        return ""

    def invalidate(self, *args, **kwargs) -> None:
        """Intention: drop a fact removal and count it, the other way a fact moves."""
        self.dropped += 1

    def __getattr__(self, name: str):
        """Intention: every other name, reads included, goes to the real store."""
        # Intention: everything else is the real store. Reading is the whole
        # point; only the two ways a fact moves are stopped, and they are
        # stopped by name so a new writing method is not silently allowed.
        return getattr(self.store, name)
