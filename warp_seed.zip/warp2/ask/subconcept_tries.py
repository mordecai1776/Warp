# WARP2/warp2/ask/subconcept_tries.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/subconcept_tries.py
#  Used by   : warp2/ask/picture_round.py (the `parts` part).
#  Uses      : warp2/ask/subconcepts.py (SubconceptGuesser, GuessBook);
#              projects/behemoth_eye/eye/taxonomy.py (ConceptTaxonomy — the
#              guesses become the Eye's own networks); warp2/ask/visual.py
#              (VisualLearning._search — pictures found on the web for a name);
#              warp2/ask/picture_datasets.py (PictureDatasets.pull — a labelled
#              dataset page for a name); warp2/record/swallowed.py (noted).
#  Description:
#    A guessed sub-concept is TRIED: it is made a network of its own in the
#    Eye (born at one node, like every network), and it is given data — a
#    dataset page where a dataset names it, pictures searched for by its
#    name where none does. The pictures are added as references with the
#    sub-concept as their subject, so the round's teach part trains that
#    network on them from the next round on. What happened to each try is
#    kept in the guess book: registered or not, how many pictures it got, and
#    from where. A try that finds nothing is kept as tried, not hidden.
#  User intention (Andrew, muse-476 2026-10-23, muse-471): "we tried adding that
#    in and we tried training on that and it should be able to train on that
#    because it should be able to pull up data sets and if it can't it should
#    be able to make data sets from search". BUILD_LOG 585.
# ============================================================================
"""Trying guessed sub-concepts: registered in the Eye, given pictures, kept."""
from __future__ import annotations

from warp2.record.swallowed import noted

# Intention: how many guesses one round tries. Each one is a web search and a
# dataset page, and a round must still finish in minutes; the rest are tried
# by the rounds after.
TRIES_PER_ROUND = 3

# Intention (BUILD_LOG 637): how many of each sub-concept's own pictures one
# round's block lesson teaches it, and how many sub-concepts at most a round
# teaches — every picture is read once per round, so this keeps a round short.
PICTURES_PER_SUBCONCEPT = 8
SUBCONCEPTS_PER_ROUND = 12


class SubconceptRegistrar:
    """Puts a concept's GUESSED types and parts into the Eye as networks — those, once each, nothing else.

    Intention (BUILD_LOG 643): Andrew asked for the models to guess types
    and parts (muse-476). This used the taxonomy's register_taxonomy, which
    also made networks nobody guessed (hand-written part varieties, poses,
    18 picture "qualities", "connected" words) and a second copy of every
    one as a WarpEye task ("parts: cat: cat ears"): 78 pairs became 230, and
    every look of every picture cost about three times as much. Now only the
    guessed names are made, one network each; the extras are retired — kept
    in the book and on disk, never activated again.
    """

    def __init__(self, state) -> None:
        """Intention: the Eye's taxonomy for this state folder (for its _register only)."""
        from projects.behemoth_eye.eye.taxonomy import ConceptTaxonomy
        self.taxonomy = ConceptTaxonomy(state)

    def register(self, model, subject: str, guesser, page: dict) -> dict:
        """Intention: each guessed type and part one Eye network; the extras made before retired."""
        sub = " ".join(subject.lower().split())
        eye = getattr(model, "eye", None)
        if eye is None:
            return {"registered": 0, "why": "the picture model has no Eye"}
        names = [(guesser.full_name(sub, name, "types"), "subtype") for name in page.get("types", [])]
        names += [(guesser.full_name(sub, name, "parts"), "part") for name in page.get("parts", [])]
        made = 0
        for name, what in dict.fromkeys(names):
            if self.taxonomy._register(eye, name, f"{what} of {sub}", "guessed by a local model"):
                made += 1
        retired = ExtraNetworks.retire(eye, getattr(model, "warp", None), sub, {n for n, _ in names})
        return {"registered": made, "retired": retired}

    @staticmethod
    def retire_extras(model, subject: str, state) -> int:
        """Intention: at a round's start, the extras retired before its cascades run (BUILD_LOG 643)."""
        from warp2.ask.subconcepts import GuessBook, SubconceptGuesser
        eye = getattr(model, "eye", None)
        if eye is None:
            return 0
        sub = " ".join(subject.lower().split())
        page = GuessBook(state).entry(sub)
        namer = SubconceptGuesser.__new__(SubconceptGuesser)
        guessed = {namer.full_name(sub, n, "types") for n in page.get("types", [])}
        guessed |= {namer.full_name(sub, n, "parts") for n in page.get("parts", [])}
        return ExtraNetworks.retire(eye, getattr(model, "warp", None), sub, guessed)

    def register_parts_of_part(self, model, part: str, guesser, page: dict) -> int:
        """Intention: a part's own guessed parts (paw -> paw pads, claws) as networks."""
        eye = getattr(model, "eye", None)
        if eye is None:
            return 0
        count = 0
        for name in page.get("parts", []):
            full = guesser.full_name(part, name, "parts")
            if self.taxonomy._register(eye, full, f"part of {part}", "guessed by a local model"):
                count += 1
        return count


class ExtraNetworks:
    """The networks register_taxonomy made that nobody guessed — retired, never deleted."""

    # Intention: the WarpEye task groups register_taxonomy made for a subject.
    GROUPS = ("subtypes", "parts", "part_subtypes", "poses", "qualities")

    # Intention: who register_taxonomy said made a network (eye.define's `by`).
    # A network the readers or a person made first keeps its own `by` and is
    # never retired here.
    MADE_BY = ("mapped taxonomy", "structural taxonomy", "part taxonomy", "associative taxonomy",
               "pose taxonomy", "quality taxonomy")

    @classmethod
    def names(cls, eye, subject: str, guessed: set) -> list:
        """Intention: the networks register_taxonomy itself made (by its own `by`), and its task copies — never a guessed name."""
        copies = tuple(f"{group}: {subject}: " for group in cls.GROUPS) + tuple(
            f"task: {group}: {subject}" for group in cls.GROUPS)
        pairs = getattr(getattr(eye, "concepts", None), "pairs", {}) or {}
        out = []
        for name, concept in pairs.items():
            text = str(name)
            if text in guessed or text == subject:
                continue
            made_by = str(getattr(concept, "defined_by", "") or "")
            if made_by in cls.MADE_BY or text.startswith(copies):
                out.append(text)
        return out

    @classmethod
    def retire(cls, eye, warp, subject: str, guessed: set) -> int:
        """Intention: each extra never activated again (kept in the book), and its task group no longer trained."""
        layer = getattr(eye, "concept_activation", None)
        count = 0
        for name in cls.names(eye, subject, guessed):
            if layer is not None and name not in layer.retired:
                layer.retire(name)
                count += 1
        parts = getattr(warp, "parts", None)
        if isinstance(parts, dict):
            for group in cls.GROUPS:
                parts.pop(f"{group}: {subject}", None)
            pictures = parts.get("pictures", {})
            extra = set(cls.names(eye, subject, guessed))
            if isinstance(pictures, dict) and extra:
                pictures["classes"] = [c for c in pictures.get("classes", []) if c not in extra]
        return count


class SubconceptData:
    """Finds pictures for one sub-concept: a dataset page first, the web always."""

    def __init__(self, learning, search=None) -> None:
        """Intention: the round's learning and search, the same ones its search part uses."""
        self.learning = learning
        self.search = search

    def fetch(self, name: str, references: dict, round_no: int) -> dict:
        """Intention: pictures added to `references` with `name` as their subject; what came from where."""
        got = {"dataset": "", "from_dataset": 0, "from_search": 0, "error": ""}
        try:
            from warp2.ask.picture_datasets import PictureDatasets
            pulled = PictureDatasets(self.learning).pull(name, references, round_no)
            got["dataset"], got["from_dataset"] = pulled.get("dataset", ""), int(pulled.get("added", 0))
        except Exception as exc:
            noted("warp2/ask/subconcept_tries.py:SubconceptData.fetch(dataset)", exc)
            got["error"] = f"dataset: {type(exc).__name__}: {exc}"
        try:
            rows, error = self.learning._search(references, name, self.search, wanted=None, round_no=round_no)
            got["from_search"] = len(rows)
            if error:
                got["error"] = (got["error"] + "; " if got["error"] else "") + f"search: {error}"
        except Exception as exc:
            noted("warp2/ask/subconcept_tries.py:SubconceptData.fetch(search)", exc)
            got["error"] = (got["error"] + "; " if got["error"] else "") + f"search: {type(exc).__name__}: {exc}"
        return got


class SubconceptTries:
    """One round's turn: guess what is not guessed yet, register it, give up to three guesses data."""

    def __init__(self, learning, search=None, guesser=None) -> None:
        """Intention: `guesser` is the local-LLM one by default; tests give their own."""
        from warp2.ask.subconcepts import SubconceptGuesser
        self.learning = learning
        self.guesser = guesser or SubconceptGuesser(learning.root, learning.state)
        self.registrar = SubconceptRegistrar(learning.state)
        self.data = SubconceptData(learning, search)

    def turn(self, model, subject: str, round_no: int) -> dict:
        """Intention: what was guessed, registered and fetched; the new references are returned to keep.

        The subject's types and parts are guessed once; each part tried is
        then asked for its own parts (Andrew: the paw, the paw pads, the
        claws), so the guesses go a level deeper as the rounds go on.
        """
        new = self.guesser.guess(subject)
        book = self.guesser.book
        page = book.entry(subject)
        registered = self.registrar.register(model, subject, self.guesser, page)
        references = {"references": dict(self.learning._load()["references"])}
        before = set(references["references"])
        tried = []
        for owner, name, kind in self._next(subject)[:TRIES_PER_ROUND]:
            full = self.guesser.full_name(owner, name, kind)
            got = self.data.fetch(full, references, round_no)
            deeper = 0
            if kind == "parts" and owner == " ".join(subject.lower().split()):
                self.guesser.guess(full, kinds=("parts",), models_per_question=1)
                deeper = self.registrar.register_parts_of_part(model, full, self.guesser, book.entry(full))
            book.tried(owner, name, dict(got, concept=full, round=int(round_no), deeper_parts=deeper))
            tried.append({"name": full, "deeper_parts": deeper, **got})
        book.save()
        added = {k: v for k, v in references["references"].items() if k not in before}
        return {"guessed": new, "registered": registered, "tried": tried, "added": added}

    def _next(self, subject: str) -> list:
        """Intention: the subject's untried guesses first, then the untried parts of its tried parts."""
        book = self.guesser.book
        sub = " ".join(subject.lower().split())
        page = book.entry(sub)
        order = [(sub, name, "types" if name in page["types"] else "parts") for name in book.untried(sub)]
        for name in page["parts"]:
            if name in page["tried"]:
                full = self.guesser.full_name(sub, name, "parts")
                order.extend((full, deeper, "parts") for deeper in book.untried(full))
        return order


class SubconceptPictures:
    """A subject's tried sub-concepts and the pictures each may be trained on.

    Intention (Andrew, muse-476: "we tried adding that in and we tried
    training on that"; BUILD_LOG 637): the guesses were made networks and
    given pictures, but no round taught them — a round teaches only its own
    subject. This says, for the round's subject, which sub-concepts were
    tried and which of their pictures are usable (a person's or a reader's
    yes), so the round's block lesson trains each one. Least-trained first,
    so every sub-concept gets its turn.
    """

    def __init__(self, state) -> None:
        """Intention: the guess book of this state folder."""
        from warp2.ask.subconcepts import GuessBook
        self.book = GuessBook(state)

    def names(self, subject: str) -> list:
        """Intention: the full names of the subject's tried sub-concepts, and of their tried parts."""
        sub = " ".join(str(subject).lower().split())
        found = []
        for owner in [sub] + [t.get("concept", "") for t in self.book.entry(sub)["tried"].values()]:
            for tried in self.book.data.get(owner, {}).get("tried", {}).values():
                name = str(tried.get("concept") or "")
                if name and name != sub and name not in found:
                    found.append(name)
        return found

    def trained(self, subject: str, names) -> None:
        """Intention: how many rounds each sub-concept was trained in, kept in the guess book."""
        page = self.book.entry(subject).setdefault("trained", {})
        for name in names:
            page[name] = int(page.get(name, 0)) + 1
        self.book.save()

    def pictures(self, subject: str, references: dict, taught: dict | None = None) -> dict:
        """Intention: {sub-concept: [usable picture paths]}, least trained first, capped per round."""
        from pathlib import Path
        from warp2.ask.reference import usable
        taught = dict(taught or {}, **self.book.entry(subject).get("trained", {}))
        by_name = {}
        for name in self.names(subject):
            paths = [str(r["path"]) for r in references.values()
                     if isinstance(r, dict) and r.get("subject") == name and usable(r)
                     and r.get("path") and Path(r["path"]).is_file()]
            if paths:
                by_name[name] = paths[:PICTURES_PER_SUBCONCEPT]
        order = sorted(by_name, key=lambda n: int(taught.get(n, 0)))
        return {name: by_name[name] for name in order[:SUBCONCEPTS_PER_ROUND]}

    def kin(self, subject: str, names) -> dict:
        """Intention: the subject and its sub-concepts are never each other's "is not" (an abyssinian is a cat; cat pictures hold ears)."""
        family = {" ".join(str(subject).lower().split())} | set(names)
        return {name: set(family) for name in family}
