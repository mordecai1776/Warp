# WARP2/warp2/ask/practice_choice.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/practice_choice.py
#  Used by   : warp2/ask/visual.py (VisualLearning.practice — which subject
#              the Eye practises next).
#  Uses      : stdlib only.
#  Description:
#    Chooses the subject the Eye practises: one it has real pictures of, kept
#    while it is still getting better, and rested when it has stopped — so a
#    subject with nothing to learn from cannot hold practice for ever. A
#    rested subject keeps its progress and comes back, resting longer each
#    time it is still flat (2026-10-09).
#  User intention (Andrew):
#    2026-09-24, after the Eye practised "wrestling_at" (a scrap of a title,
#    three unconfirmed pictures) for seven rounds at a reader score of 0 to
#    0.3: "lets get this fixed" — practise real things, and move on from one
#    that is going nowhere.
# ============================================================================
from __future__ import annotations

# Intention: the states that mean a person's yes stands behind the pictures.
BACKED = ("ready", "prepared")


def references_of(data: dict) -> dict:
    """How many kept pictures each subject has, and how many a person confirmed."""
    count: dict = {}
    for ref in (data.get("references") or {}).values():
        subject = str(ref.get("subject") or "")
        row = count.setdefault(subject, {"all": 0, "confirmed": 0})
        row["all"] += 1
        if ref.get("status") == "confirmed":
            row["confirmed"] += 1
    return count


def candidates(data: dict, allowed_subjects: set[str] | None = None) -> list:
    """The subjects worth practising, best backed first.

    Intention: a subject a person confirmed pictures of first; if there are
    none, the ones with the most pictures kept, at least two (one picture is
    nothing to tell apart from); only if there are none of those either, any
    subject — so practice is never left with nothing.

    User intention (Andrew, 2026-09-27): "that should only be for user asked things".
    When allowed_subjects is provided, only subjects the user asked for are considered.
    """
    subjects = list(data.get("subjects") or {})
    if allowed_subjects is not None:
        subjects = [s for s in subjects if s in allowed_subjects]
    refs = references_of(data)
    backed = [s for s in subjects
              if data.get("subjects", {}).get(s) in BACKED or refs.get(s, {}).get("confirmed", 0) > 0]
    if backed:
        return sorted(backed, key=lambda s: -refs.get(s, {}).get("confirmed", 0))
    pictured = [s for s in subjects if refs.get(s, {}).get("all", 0) >= 2]
    if pictured:
        return sorted(pictured, key=lambda s: -refs.get(s, {}).get("all", 0))
    if allowed_subjects is not None:
        return subjects
    return []


def scores_of(data: dict, subject: str) -> list:
    """The readers' score of each attempt at this subject, oldest first."""
    rows = [a for a in (data.get("attempts") or {}).values() if a.get("subject") == subject]
    rows.sort(key=lambda a: float(a.get("time") or 0.0))
    out = []
    for a in rows:
        evidence = a.get("evidence") if isinstance(a.get("evidence"), dict) else {}
        score = evidence.get("score")
        out.append(float(score) if isinstance(score, (int, float)) else 0.0)
    return out


def still_improving(scores: list) -> bool:
    """Whether the best score is recent enough to be worth another round.

    Intention: MEASURED, NOT SET. The patience is how many rounds the best
    score took to reach: a subject that improved on its tenth round gets ten
    more to improve again, one that peaked on its first round gets two. No
    rounds yet, or one, is always worth going on with.
    """
    if len(scores) < 2:
        return True
    best = max(scores)
    reached = scores.index(best)
    since = len(scores) - 1 - reached
    return since < max(2, reached + 1)


def choose(data: dict, allowed_subjects: set[str] | None = None) -> str:
    """The subject to practise now, or "" when there is none.

    Intention: the one in progress keeps its turn while it is still getting
    better and is still worth practising; otherwise it is rested (its
    progress is let go, its attempts and pictures kept) and the backed
    subject practised longest ago goes next.

    User intention (Andrew, 2026-09-27): "that should only be for user asked things".
    """
    choices = candidates(data, allowed_subjects=allowed_subjects)
    if not choices:
        return ""
    waiting = data.setdefault("progress", {})
    resting = data.setdefault("resting", {})
    # Intention (2026-10-09, fix 4.8, check E3): a subject in progress that
    # has stopped getting better is RESTED, not dropped — its progress is
    # kept, and it is tried again after 1, 2, 4, ... choices while it stays
    # flat. It was let go, its progress deleted, before it ever passed.
    for subject in list(waiting):
        if not waiting.get(subject) or subject not in choices:
            continue
        if still_improving(scores_of(data, subject)):
            resting.pop(subject, None)
            return subject
        rest = resting.setdefault(subject, {"rest": 0, "waited": 0})
        if rest["waited"] >= rest["rest"]:
            rest.update(rest=max(1, 2 * rest["rest"]), waited=0)
            if rest["rest"] > 1:
                return subject
    for rest in resting.values():
        rest["waited"] += 1

    def last_tried(s: str) -> float:
        """Intention: when this subject was last attempted, so the one practised longest ago goes next."""
        return max((float(a.get("time") or 0.0) for a in (data.get("attempts") or {}).values()
                    if a.get("subject") == s), default=0.0)

    awake = [s for s in choices if s not in resting or s not in waiting] or choices
    return min(awake, key=last_tried)
