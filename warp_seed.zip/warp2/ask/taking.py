# WARP2/warp2/ask/taking.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/taking.py
#  Used by   : warp2/work/loop.py, once a pass, through the one door.
#  Uses      : warp2/ask/inbox.py, warp2/store/projects.py,
#              warp2/tags/grounding.py (its writes graded by who is speaking),
#              warp2/research/carried.py (outside research carried into the KG),
#              warp2/store/questions.py, warp2/ask/request_folder.py,
#              warp2/work/queue.py (offered to, and
#              it may refuse), warp2/util.py.
#  Description:
#    Turns what a person asked for into things the warp already understands: a
#    project, a request to a project that makes pictures, a stated comment with
#    work raised to act on it, or a file kept with the thing it belongs to.
#  User intention (Andrew, 2026-09-07):
#    "Where I can ask for an image to be made or a project to be started or
#    comment on one and have changes made. I should also be able to drop in
#    files or images to it."
#    Nothing new is invented to hold these. A project is a project, a comment
#    is his words about a thing, and a dropped file is evidence. The whole job
#    of this file is translation, so the window never has to know what the warp
#    is made of and the warp never has to know there is a window.
#  Principles: Clean — one place that knows what an ask becomes. Adaptive — a
#    project says where it takes requests, so asking a project for a picture
#    needs no project's name written down here.
# ============================================================================
from __future__ import annotations

from warp2.tags import grounding

from pathlib import Path

from warp2.ask.inbox import COMMENT, FEEDBACK, FILE, IMAGE, PROJECT, REDO, RESEARCH, VIDEO, Inbox
from warp2.ask.thread import ANDREW, Thread
from warp2.util import now_iso, sha256_hex

# Where a project takes requests, when it has not said. Intention: derived from
# the project's home, the same shape `publishes` uses for the other direction —
# so a project that already reads an inbox is reachable without naming it here.
# `projects/centering_image` has read exactly this folder since 2026-09-06.
TAKES = "takes_requests"
DEFAULT_TAKES = "{slug}/inbox"

# What a person's words and intentions are stated as.
# User intention (Andrew, 2026-09-10):
# "The conversations should be placed under user intentions. That should cause
# them to tag things related to them. Lets try to squeeze it in in that route
# it does not have to be instant just done at some known point"
SAID = "user_said"
INTENTION = "user_intention"

GUI_KEYWORDS = (
    "gui", "ui", "interface", "window", "button", "canvas",
    "layout", "display", "screen", "widget", "tab", "dialog", "observer",
    "font", "fontsize", "typography", "theme", "styling", "color",
    "colour", "palette", "language", "lauangue", "lang", "locale", "speak", "spanish", "french", "german",
)


class Taking:
    """Turns what was asked for and spoken in conversation into what the warp knows.

    Intention: the window puts a small file in a folder or writes a turn to the
    thread. Everything that makes that mean something happens here, once a pass,
    inside the guarded pathway — so an ask or conversation turn is taken exactly
    like any other action, with a record of what it became.
    """

    def __init__(self, store, projects, questions, queue, state) -> None:
        """Intention: hold the store, projects, questions and queue it writes into, and the inbox and
        thread it reads from.
        """
        self.store = store
        self.projects = projects
        self.questions = questions
        self.queue = queue
        self.state = Path(state)
        self.inbox = Inbox(state)
        self.thread = Thread(state)
        self._seen_turns: set[str] = set()

    # Intention: ONE PASS TAKES EVERYTHING WAITING AND CONVERSATIONS AT THIS
    # KNOWN POINT. Andrew: "Lets try to squeeze it in in that route it does not
    # have to be instant just done at some known point".
    @grounding.spoken(grounding.STATED)
    def take(self) -> dict:
        """Take everything asked for and spoken, and say what each one became."""
        report = {"took": 0, "became": [], "refused": [], "conversations": 0}
        for asked in self.inbox.waiting():
            # Intention: A ROW WITH NO NAME CANNOT BE MARKED HANDLED, AND
            # MUST NOT TAKE THE PASS DOWN WITH IT. MEASURED on the live run of
            # 2026-09-12: this step died with `KeyError('id')`. The guard below
            # says a request must never stop a pass — and then reached for
            # `asked["id"]` itself, so the one thing it could not survive was a
            # request missing the very field the guard needs. Read once, up
            # front, and a nameless row is set aside and reported rather than
            # thrown.
            name = str(asked.get("id") or "")
            if not name:
                report["refused"].append({"id": "", "why": "no id on this request"})
                continue
            try:
                became = self._one(asked)
            except Exception as exc:            # a request must never stop a pass
                self.inbox.handled(name, "could not be taken", repr(exc)[:200])
                report["refused"].append({"id": name, "why": repr(exc)[:120]})
                continue
            self.inbox.handled(name, became["how"], became.get("made", ""))
            report["took"] += 1
            report["became"].append(became)

        # Ingest conversation turns under user intentions at this known point
        turns_report = self._take_conversation_turns()
        report["conversations"] = len(turns_report)
        report["took"] += len(turns_report)
        report["became"].extend(turns_report)
        # Intention: research brought in from outside the warp (state/
        # research_inbox/) is carried into the KG at this same known point, so
        # the fact lane keeps one writer (warp2/research/carried.py).
        from warp2.research.carried import carry_in
        try:
            report["research carried in"] = len(carry_in(self.store, self.state))
        except Exception as exc:                 # research must never stop a pass
            report["refused"].append({"id": "research_inbox", "why": repr(exc)[:120]})
        return report

    def _resolve_target(self, about: str, words: str) -> tuple[str, str | None]:
        """Resolve the subject and matching Python/GUI file from context and keywords."""
        about_clean = str(about or "").strip()
        words_clean = str(words or "").strip().lower()

        if about_clean.endswith(".py"):
            return about_clean, about_clean

        matched_slug = ""
        if about_clean.startswith("project:"):
            matched_slug = about_clean.split(":", 1)[1]
        elif about_clean in self.projects.names():
            matched_slug = self.projects.home(about_clean).name
        else:
            for name in self.projects.names():
                slug = self.projects.home(name).name
                if slug in words_clean or name.lower() in words_clean:
                    matched_slug = slug
                    break

        has_gui_keyword = any(kw in words_clean for kw in GUI_KEYWORDS) or any(
            kw in about_clean.lower() for kw in GUI_KEYWORDS
        )

        if matched_slug:
            proj_subject = f"project:{matched_slug}"
            base_root = getattr(self.projects, "root", None) or self.state.parent
            proj_home = None
            for name in self.projects.names():
                if self.projects.home(name).name == matched_slug:
                    proj_home = self.projects.home(name)
                    break
            if proj_home is None:
                proj_home = base_root / "projects" / matched_slug

            if has_gui_keyword and proj_home.is_dir():
                candidate_gui = proj_home / "gui.py"
                if candidate_gui.is_file():
                    try:
                        rel = candidate_gui.relative_to(base_root).as_posix()
                    except ValueError:
                        rel = str(candidate_gui).replace("\\", "/")
                    return proj_subject, rel
                for f in proj_home.glob("*gui*.py"):
                    if f.is_file():
                        try:
                            rel = f.relative_to(base_root).as_posix()
                        except ValueError:
                            rel = str(f).replace("\\", "/")
                        return proj_subject, rel

            return proj_subject, None

        if has_gui_keyword:
            if any(term in words_clean for term in ("all", "entire", "everything", "window", "gui", "ui", "interface")) and any(k in words_clean for k in ("language", "lauangue", "spanish", "french", "german")):
                return "warp2/ask/window.py", "warp2/ask/window.py"
            if any(term in words_clean for term in ("language", "lauangue", "locale", "speak in", "talk in")):
                return "warp2/ask/personality.py", "warp2/ask/personality.py"
            if any(term in words_clean for term in ("cockpit", "warp observer")):
                return "warp2/ui/observer.py", "warp2/ui/observer.py"
            if any(term in words_clean for term in ("chat", "centre", "center", "action centre", "action center", "warp window", "general", "app", "application")) or any(k in words_clean for k in ("font", "theme", "color", "colour", "palette")):
                return "warp2/ask/window.py", "warp2/ask/window.py"
            if "observer" in words_clean:
                return "warp2/ui/observer.py", "warp2/ui/observer.py"
            return "warp2/ask/window.py", "warp2/ask/window.py"

        return about_clean, None

    def _take_conversation_turns(self) -> list[dict]:
        """Ingest conversation thread turns from Andrew under user intentions."""
        out = []
        recent_turns = self.thread.recent(limit=100)
        for turn in recent_turns:
            who = str(turn.get("who") or "").lower()
            if who not in (ANDREW, "you", "andrew"):
                continue
            said = str(turn.get("said") or "").strip()
            if not said:
                continue
            at = str(turn.get("at") or "")
            turn_digest = sha256_hex(f"{at}:{said}".encode("utf-8"))[:12]
            turn_id = f"conversation:turn:{turn_digest}"

            if turn_id in self._seen_turns:
                continue
            if self.store.current(subject=turn_id, attr=INTENTION):
                self._seen_turns.add(turn_id)
                continue

            self._seen_turns.add(turn_id)
            self.store.assert_fact(turn_id, "has", attr="kind", value="conversation_turn")
            self.store.assert_fact(turn_id, "has", attr="speaker", value="you")
            if at:
                self.store.assert_fact(turn_id, "has", attr="at", value=at)
            self.store.assert_fact(turn_id, "has", attr=INTENTION, value=said)
            self.store.assert_fact(turn_id, "has", attr=SAID, value=said)

            about = str(turn.get("about") or turn.get("project") or "").strip()
            target_subject, py_file = self._resolve_target(about, said)
            related = py_file or target_subject or about

            if related:
                self.store.assert_fact(turn_id, "supports", related)
                if not self.store.current(subject=related, attr=INTENTION):
                    self.store.assert_fact(related, "has", attr=INTENTION, value=said)
                self.store.assert_fact(related, "has", attr=SAID, value=said)
                if self.store.distiller is not None:
                    self.store.distiller.cover(related, said)

            if py_file and py_file.endswith(".py"):
                from warp2.work.queue import Refused
                work_item_id = f"work:revise:{py_file}"
                try:
                    self.queue.offer(
                        item_id=work_item_id, kind="revise",
                        target=py_file, rank=0.9,
                        verification="its own test passes against the change asked for")
                    self.store.assert_fact(work_item_id, "has", attr="requested_by", value="user")
                    self.store.assert_fact(work_item_id, "has", attr="user_intention", value=said)
                    self.store.assert_fact(work_item_id, "has", attr="until_it_passes", value="true")
                except Refused:
                    pass

            out.append({
                "how": "stated conversation turn under user_intention",
                "made": turn_id,
                "related": related,
            })
        return out

    # Intention: one place the kinds are matched, so a new kind is one branch
    # and one method rather than a change spread over the window and the loop.
    def _one(self, asked: dict) -> dict:
        kind = str(asked.get("kind") or "")
        if kind == PROJECT:
            return self._start_a_project(asked)
        if kind in (IMAGE, VIDEO, RESEARCH):
            return self._ask_for_a_picture(asked)
        if kind == COMMENT:
            return self._take_a_comment(asked)
        if kind == FILE:
            return self._keep_a_file(asked)
        if kind == FEEDBACK:
            return self._pass_on_feedback(asked)
        if kind == REDO:
            return self._redo_a_task(asked)
        return {"how": "nothing knows how to take that", "made": ""}

    # Intention (2026-10-09, check G5): "NOT DONE? REDO" REALLY REOPENS. The
    # window's button read a store and a queue the window does not have, so it
    # reopened nothing while telling Andrew it had. The window now asks; the
    # runner, which owns the queue, reopens the item here — through the
    # queue, the one writer of a work item's state — and keeps his words.
    def _redo_a_task(self, asked: dict) -> dict:
        task = str(asked.get("about") or "").strip()
        said = str(asked.get("said") or "").strip() or "not done yet"
        if not task:
            return {"how": "a redo needs the task it is about", "made": ""}
        self.store.assert_fact(task, "has", attr="until_it_passes", value="true")
        self.store.assert_fact(task, "has", attr="retry_reason", value=said)
        self.store.assert_fact(task, "has", attr=INTENTION, value=said)
        self.store.assert_fact(task, "has", attr="requested_by", value="user")
        if self.queue is None:
            return {"how": "kept his words; no queue here to reopen it", "made": task}
        self.queue.reopen(task, why=f"Andrew says not done: {said}")
        return {"how": "reopened", "made": task}

    # -- what each ask becomes ----------------------------------------------

    # Intention: a project is a project. `Projects.open` states the facts and
    # writes the card, so what a person typed in a window is the same thing as
    # what a person typed at the command line — there is no second way to have
    # a project.
    def _start_a_project(self, asked: dict) -> dict:
        name = str(asked.get("about") or asked.get("said") or "").strip()
        if not name:
            return {"how": "a project needs a name", "made": ""}
        made = self.projects.open(name, intention=str(asked.get("said") or ""),
                                  source="asked for in the action centre")
        self.store.assert_fact(made["project"], "has", attr="requested_by", value="user")
        self.store.assert_fact(made["project"], "has", attr="until_it_passes", value="true")
        return {"how": "started it", "made": made["project"]}

    # Intention: THE PROJECT SAYS WHERE IT TAKES REQUESTS, so this does not know
    # the name of the project that makes pictures. Written in the shape
    # `projects/centering_image` already reads — one small JSON file in its
    # inbox — so a picture asked for here reaches the worker that draws it with
    # nothing new built on either side.
    def _ask_for_a_picture(self, asked: dict) -> dict:
        wanted = str(asked.get("said") or "").strip()
        if not wanted:
            return {"how": "an image needs something to be of", "made": ""}
        where = self._where_it_takes_requests(str(asked.get("about") or ""))
        if not where:
            return {"how": "no project here makes pictures yet", "made": ""}
        from warp2.ask.request_folder import RequestFolder
        # Intention (2026-10-09, fix 3.7, check B10): a video or a search &
        # research waits in the same folder as a picture, saying which it is,
        # so the loop makes it on its own turn — not the window at the click.
        body = {"kind": "request", "subject": wanted, "media": str(asked.get("kind") or IMAGE),
                "asked_at": asked.get("asked_at") or now_iso(),
                "from": "the action centre"}
        made = RequestFolder(where).add(asked["id"], body)
        return {"how": "asked for it", "made": str(made)}

    # Intention: A CLICK ON A PICTURE IS FEEDBACK, NOT A TRAINING RUN. Andrew,
    # 2026-09-18: "place that into something that adds to the work instead of
    # acting like a trigger." Passed to the project that makes pictures, in the
    # same folder its requests wait in, and the loop learns from it on its own
    # turn (warp2/work/side/asked.py).
    def _pass_on_feedback(self, asked: dict) -> dict:
        path = str(asked.get("path") or "").strip()
        if not path:
            return {"how": "feedback needs the picture it is about", "made": ""}
        where = self._where_it_takes_requests(str(asked.get("about") or ""))
        if not where:
            return {"how": "no project here makes pictures yet", "made": ""}
        from warp2.ask.request_folder import RequestFolder
        body = {"kind": "feedback", "path": path, "subject": str(asked.get("said") or ""),
                "score": float(asked.get("score") or 0.0),
                "asked_at": asked.get("asked_at") or now_iso()}
        made = RequestFolder(where).add(asked["id"], body)
        return {"how": "passed on", "made": str(made)}

    def where_requests_wait(self, about: str = "project:centering_image") -> Path | None:
        """The folder a project reads its requests from, if one does.

        Intention: public, so the loop's step that makes asked pictures looks
        in exactly the folder this file writes to — one answer, not two.
        """
        return self._where_it_takes_requests(about)

    # Intention: HIS WORDS ARE KEPT AS HIS WORDS, and work is offered to act on
    # them. Stated as user_intention on the comment and distilled by the Overgraph
    # so related things are tagged.
    def _take_a_comment(self, asked: dict) -> dict:
        about = str(asked.get("about") or "").strip()
        said = str(asked.get("said") or "").strip()
        if not about or not said:
            return {"how": "a comment needs a thing and something to say", "made": ""}

        asked_id = str(asked.get("id") or "")
        comment_subject = (f"asked:comment:{asked_id}" if asked_id
                           else f"conversation:comment:{sha256_hex(said.encode('utf-8'))[:10]}")

        self.store.assert_fact(comment_subject, "has", attr="kind", value="user_comment")
        self.store.assert_fact(comment_subject, "has", attr=INTENTION, value=said)
        self.store.assert_fact(comment_subject, "has", attr=SAID, value=said)
        if about:
            self.store.assert_fact(comment_subject, "supports", about)
            self.store.assert_fact(about, "has", attr=SAID, value=said)
            if not self.store.current(subject=about, attr=INTENTION):
                self.store.assert_fact(about, "has", attr=INTENTION, value=said)
            elif self.store.distiller is not None:
                self.store.distiller.cover(about, said)

        target_subject, py_file = self._resolve_target(about, said)
        target_file = py_file if py_file else (about if about.endswith(".py") else None)

        if not target_file:
            return {"how": "kept it against the thing", "made": about or comment_subject}

        if target_file != about:
            self.store.assert_fact(comment_subject, "supports", target_file)
            self.store.assert_fact(target_file, "has", attr=SAID, value=said)
            if not self.store.current(subject=target_file, attr=INTENTION):
                self.store.assert_fact(target_file, "has", attr=INTENTION, value=said)
            elif self.store.distiller is not None:
                self.store.distiller.cover(target_file, said)

        from warp2.work.queue import Refused
        work_item_id = f"work:revise:{target_file}"
        try:
            self.queue.offer(item_id=work_item_id, kind="revise",
                             target=target_file, rank=0.9,
                             verification="its own test passes against the change asked for")
            self.store.assert_fact(work_item_id, "has", attr="requested_by", value="user")
            self.store.assert_fact(work_item_id, "has", attr="user_intention", value=said)
            self.store.assert_fact(work_item_id, "has", attr="until_it_passes", value="true")
        except Refused as full:
            return {"how": f"kept it; no room to work on it yet ({full})", "made": target_file}
        return {"how": "kept it and raised work to change it", "made": target_file}

    # Intention: a dropped file is EVIDENCE, and evidence is addressed by what
    # it holds. The bytes are already kept by the inbox; this states that they
    # exist, what they are called, and what they were dropped in for — so the
    # thing a person attached is findable from the thing it is about.
    def _keep_a_file(self, asked: dict) -> dict:
        kept = str(asked.get("kept") or "")
        if not kept:
            return {"how": "nothing came with it", "made": ""}
        where = f"state/{kept}"
        self.store.assert_fact(where, "has", attr="kind", value="dropped_file")
        self.store.assert_fact(where, "has", attr="name",
                               value=str(asked.get("name") or ""))
        self.store.assert_fact(where, "has", attr="content_digest",
                               value=str(asked.get("digest") or ""))
        if asked.get("said"):
            self.store.assert_fact(where, "has", attr=SAID, value=str(asked["said"]))
        about = str(asked.get("about") or "").strip()
        if about:
            self.store.assert_fact(where, "supports", about)
        return {"how": "kept it", "made": where}

    # Intention: asked of the store, with a default derived from the home — the
    # same rule the run ingest uses for `publishes`, so the two directions of
    # talking to a project are learned once.
    def _where_it_takes_requests(self, wanted: str) -> Path | None:
        for name in self.projects.names():
            slug = self.projects.home(name).name
            if wanted and wanted not in (name, slug, f"project:{slug}"):
                continue
            stated = self.store.current(subject=f"project:{slug}", attr=TAKES)
            shape = str(stated[0]["value"]) if stated else DEFAULT_TAKES
            where = self.state / shape.format(slug=slug)
            if where.exists() or stated or (self.state / slug).is_dir():
                return where
        return None
