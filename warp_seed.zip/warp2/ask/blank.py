# WARP2/warp2/ask/blank.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/blank.py
#  Used by   : warp2/ask/visual.py (before the vision readers are asked).
#  Uses      : PIL, numpy.
#  Description:
#    The cheapest reader there is: an automation that says a made picture is
#    blank when a person could not see anything in it. A blank picture scores
#    0 without waiting minutes for a vision model, and the model's reading
#    cannot dress it up.
#  User intention (Andrew, 2026-09-18): "use the smallest/simplest form it
#    has" — automations first, then action models, then bigger models.
#    (2026-10-01) fix the reader first, so a blank scores near zero.
# ============================================================================
"""Is there anything in this picture a person could see?"""
from __future__ import annotations

from pathlib import Path

# Intention: MEASURED 2026-10-01. From 13 Sep to 29 Sep almost every picture
# the WARP made had a brightness spread of 0.2 to 1.6 grey levels out of 255:
# flat grey. The vision reader (qwen3.5 9b) said "the subject is absent" and
# still scored it 0.2-0.3, every time, for 67 tries at up to two hours each.
# A person stops seeing contrast at about 1-2% of the range (Weber's law for
# brightness), so a picture whose spread is under 2% of the range shows
# nothing. That is a fact about seeing, not a tuning knob.
SEEN_CONTRAST = 0.02


def contrast(path) -> float:
    """Intention: the picture's brightness spread as a share of the full range (0 flat, ~0.5 most)."""
    import numpy as np
    from PIL import Image
    with Image.open(path) as picture:
        grey = np.asarray(picture.convert("L"), dtype=np.float64) / 255.0
    return float(grey.std())


def blank_reading(path) -> dict | None:
    """A reader's answer for a blank picture, or None when there is something to see.

    Intention: shaped like every other reader's answer (score, score_kind,
    observation, difference), so `combine` and `Parts().missing` read it the
    same way; `difference` says what is missing, which is what the next
    search looks for.
    """
    if not Path(path).is_file():
        return None
    spread = contrast(path)
    if spread >= SEEN_CONTRAST:
        return None
    return {"name": "blank check", "score": 0.0, "score_kind": "explicit",
            "observation": f"blank: brightness spread {spread:.4f} of the range, below what a person can see",
            "difference": "nothing is drawn — no shape, no edges, no contrast; the subject is absent",
            "contrast": round(spread, 5)}
