# WARP2/warp2/ask/blender_held_apart.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/blender_held_apart.py
#  Used by   : warp2/ask/all_pictures.py (the Blender source leaves these
#              pictures out of teaching; AllPictures.held_apart_blender);
#              warp2/work/side/true_image_lessons.py (_show: the Blender faint
#              reading); warp2/ask/tests/test_blender_held_apart.py.
#  Uses      : (stdlib) json, re, pathlib.
#  Description:
#    A small FIXED set of Blender pictures that are never taught, the same
#    from check to check, so the faint reading has never-taught pictures of
#    another source than Hypersim to look at. Chosen once, spread over the
#    shapes (one picture per shape: cone, cube, sphere, ...), from the end of
#    the Blender list (farthest from where teaching stands), and kept on disk
#    so the set never moves. The Blender source drops these from its list, so
#    teaching never reaches them. If the Blender source had already gone all
#    the way round when the set was chosen, the file says so.
#  Why (Muse-743/746, settled by Claude by protocol 2026-10-28): a moving set
#    is a moving target (the beside frames are fixed for the same reason);
#    five, not three, because faint cases are noisy and one frame must not
#    decide the average; spread over shapes so one shape does not decide it.
#    A reading only, never a bar; undone by removing the file and reading.
#  User intention (Andrew, 2026-10-27 23:09): "we need to leave some parts
#    unknown so we dont have it feed weird answers at times"; his rulings:
#    temperatures not bars, keep everything. BUILD_LOG 855.
# ============================================================================
"""The fixed, never-taught Blender pictures for the faint reading."""
from __future__ import annotations

import json
import re
from pathlib import Path

# Intention (Muse-746): how many Blender pictures the fixed faint set holds.
COUNT = 5
# Intention: the shape in a Blender render's name (random_<n>_<shape>_<colour>_<finish>.png).
# Intention: the fewest Blender pictures the source must have before any are held out, so teaching is never starved.
FEWEST = 100
SHAPE = re.compile(r"random_\d+_(.+)_[a-z]+_[a-z]+\.[a-z]+$")


class BlenderHeldApart:
    """Intention: the fixed set — chosen once, kept on disk, handed out as (photo, None, name) like the beside frames."""

    def __init__(self, home: Path, source, taught_up_to=lambda: 0, count: int = COUNT) -> None:
        """Intention: where the set is kept, the Blender LocalSource (its full list), how far teaching has come in it."""
        self.file = Path(home) / "blender_faint_set.json"
        self.source, self.taught_up_to, self.count = source, taught_up_to, count

    def kept(self) -> dict:
        """Intention: the set as kept; chosen and written the first time (an empty set while the source is empty)."""
        try:
            return json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        files = self.source.listed()
        if len(files) < FEWEST:
            return {"files": [], "said": f"only {len(files)} Blender pictures (fewer than {FEWEST}); none held out yet"}
        chosen = self.choose(files)
        went_round = int(self.taught_up_to()) >= len(files)
        kept = {"files": chosen, "count": self.count, "chosen_from": len(files), "went_round_before": went_round,
                "said": (f"{len(chosen)} Blender pictures, one per shape, from the end of the list; never taught"
                         + ("; NOTE the Blender source had gone all the way round before, so these may have been "
                            "taught once" if went_round else ""))}
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self.file.write_text(json.dumps(kept, indent=1), encoding="utf-8")
        return kept

    def choose(self, files: list) -> list:
        """Intention: one picture per shape, walking the list from its end, until `count` (other names fill any gap)."""
        chosen, shapes = [], set()
        for name in reversed(files):
            found = SHAPE.search(name.rsplit("/", 1)[-1])
            shape = found.group(1) if found else None
            if shape is not None and shape not in shapes:
                chosen.append(name)
                shapes.add(shape)
            if len(chosen) == self.count:
                return chosen
        for name in reversed(files):
            if len(chosen) == self.count:
                break
            if name not in chosen:
                chosen.append(name)
        return chosen

    def names(self) -> list:
        """Intention: the relative names the Blender source leaves out of teaching."""
        return list(self.kept().get("files") or [])

    def held_apart_beside(self, count: int = COUNT) -> list:
        """Intention: (photo, None, name) for each kept picture, or (None, None, why) when one is missing."""
        out = []
        for name in self.names()[:count]:
            path = Path(self.source.folder) / name
            out.append((path, None, f"blender {name} (never taught)") if path.is_file()
                       else (None, None, f"blender {name}: not had (file missing)"))
        return out
