# WARP2/warp2/ask/parts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/parts.py
#  Used by   : warp2/ask/until.py (what to go and look for next round),
#              warp2/ask/visual.py (what to search for), warp2/ask/reference.py
#              (which references are worth more because they cover it).
#  Uses      : projects/centering_image/concept_terms.py when it is there;
#              stdlib re.
#  Description:
#    What the readers said was missing or wrong, broken into parts that can be
#    searched for and trained one at a time.
#  User intention (Andrew, 2026-09-12):
#    "it should also be able to break that down when parts need to be trained."
#
#    THE READER ALREADY SAYS WHAT IS WRONG AND NOBODY READ IT. Every reader
#    answer carries a `difference` field — the prompt asks for "what is missing
#    or wrong" — and the whole of what the machine did with it was store it.
#    The next round then searched for the same subject again with a different
#    adjective bolted on ("photograph closeup", "photograph object"), which is
#    a guess where an answer was already sitting in the record.
#
#    So a round that fails now knows what it failed AT. "wheels" is a thing
#    that can be searched for, weighted, and given its own tag — and the tag
#    machinery for exactly that already exists: `form_tag(subject, tags=...)`
#    attaches child concept tags so the model projects each part separately.
#    This is the missing half of it, which is deciding WHICH parts.
# ============================================================================
from __future__ import annotations

import re

# Words that describe the complaint rather than the thing complained about. A
# part called "missing" would be searched for and trained on, which is how a
# model learns the shape of the word "missing" instead of the shape of a wheel.
NOT_A_PART = {
    "missing", "absent", "wrong", "incorrect", "lacks", "lacking", "without",
    "none", "nothing", "unclear", "blurry", "blurred", "noise", "noisy",
    "difference", "differences", "caption", "mentions", "negation", "true",
    "false", "image", "photo", "picture", "subject", "object", "objects",
    "recognizable", "identifiable", "discernible", "visible", "appears",
    "should", "instead", "rather", "quality", "score", "explicit", "derived",
}

# The small words. A part called "the" would be searched for and trained on
# just as happily as one called "wheel" — the fall-back extractor below is a
# plain word match and cannot tell them apart. The project's own extractor has
# a proper list and is used when it is on the path; this is what is left when
# it is not.
FUNCTION_WORDS = {
    "the", "and", "but", "for", "not", "are", "was", "were", "has", "have",
    "had", "its", "it's", "this", "that", "these", "those", "with", "from",
    "into", "onto", "than", "then", "there", "their", "they", "them", "which",
    "what", "when", "where", "while", "some", "any", "all", "one", "two",
    "very", "much", "more", "most", "less", "least", "also", "just", "only",
    "does", "did", "doing", "been", "being", "would", "could", "shall",
}

# The derived reader writes its difference in a fixed shape, and reading that
# shape is exact where pulling words out of prose is a guess.
_MISSING = re.compile(r"missing\s*\[([^\]]*)\]", re.IGNORECASE)


class Parts:
    """What is missing from the picture, as things that can be gone and got."""

    def __init__(self) -> None:
        """Intention (2026-11-06; Andrew: no limit on parts): every part named is returned, best first; the round
        chases as many as its turn has time for."""

    def missing(self, result) -> list:
        """The parts the readers said were not there, best first.

        Intention: EVERY READER IS ASKED, and a part two readers both name goes
        first. Two readers independently missing the same thing is the
        strongest signal in the whole answer, and taking only the first
        reader's list throws that away.
        """
        counted: dict = {}
        for reader in ((result or {}).get("readers") or ()):
            if not isinstance(reader, dict) or reader.get("error"):
                continue
            for part in self._from(str(reader.get("difference") or "")):
                counted[part] = counted.get(part, 0) + 1
        order = sorted(counted.items(), key=lambda one: (-one[1], one[0]))
        return [part for part, _ in order]  # every part, best first

    def _from(self, said: str) -> list:
        """The parts named in one reader's difference — the stated list only.

        Intention: MEASURED ON ANDREW'S LIVE RUN, 2026-09-12, AND IT WAS WRONG
        THREE TIMES OUT OF THREE. This used to fall back to pulling content
        words out of the reader's prose. The reader had written "The central
        object is somewhat obscured by color bleed and soft edges, making it
        hard to define its boundaries", which is a complaint about RENDERING,
        not a missing part — and out came the parts `bleed`, `boundaries`,
        `causing`. The next round then searched Wikimedia for "cat bleed",
        "cat boundaries" and "cat causing", and brought back a stone boundary
        wall, a trig point and a close-up of scratched human skin, all of which
        went into the training as references for "cat".

        So prose is not mined any more. The derived reader writes
        `missing ['wheel', 'frame']` — a list of the subject's own words the
        caption did not mention, correct by construction — and that is the only
        form trusted. No list means no parts, and the search stays on the bare
        subject, which is the honest answer to "it came out blurry".
        """
        if not said.strip():
            return []
        found = _MISSING.search(said)
        if not found:
            return []
        named = [one.strip().strip("'\"") for one in found.group(1).split(",")]
        return [one for one in named if self._is_a_part(one)]

    @staticmethod
    def _is_a_part(word: str) -> bool:
        """Intention: a word or short phrase counts as a part only if it is a sane length and not all filler words."""
        word = " ".join(str(word).lower().split())
        if len(word) < 3 or len(word) > 40:
            return False
        pieces = word.split()
        return not all(piece in NOT_A_PART or piece in FUNCTION_WORDS
                       for piece in pieces)

    def queries(self, subject: str, parts) -> list:
        """What to go and search for, now that the parts are known.

        Intention: THE SUBJECT ALWAYS STAYS IN THE QUERY. "wheel" on its own
        fetches a wheel, and a wheel is not a reference for a bicycle — it is a
        new subject the model would learn instead. What is wanted is a picture
        of the thing that shows the part clearly.
        """
        subject = " ".join(str(subject).split())
        asked = [f"{subject} {part}" for part in (parts or ()) if part]  # one search per part named
        return asked or [subject]

    def covered_by(self, reference, parts) -> int:
        """How many of the missing parts this reference is said to show.

        Intention: read from what the READER said about the reference and from
        the tags already stored on it, never from its filename or its source
        page's title — those are the provider's words about the file, and the
        whole point of the reader looking at searched images is that those
        words are not evidence.
        """
        if not parts:
            return 0
        said = str((reference or {}).get("reader_observation") or "").lower()
        tags = " ".join(str(one).lower() for one in ((reference or {}).get("tags") or ()))
        haystack = said + " " + tags
        return sum(1 for part in parts if str(part).lower() in haystack)
