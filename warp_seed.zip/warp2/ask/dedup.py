# WARP2/warp2/ask/dedup.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/dedup.py
#  Used by   : warp2/ask/window.py, warp2/ask/media.py,
#              projects/centering_image/image_search.py.
#  Uses      : PIL (Image), hashlib, pathlib, typing.
#  Description:
#    Dual-tier image duplicate detection system:
#    1. Exact matching via SHA-256 byte digest.
#    2. Perceptual near-duplicate matching via difference hashing (dHash)
#       with bitwise Hamming distance, detecting resized, recompressed,
#       or format-converted duplicates.
#  User intention (Andrew, 2026-09-08):
#    "there needs to be a system to look for ducplicates"
# ============================================================================
from __future__ import annotations

import hashlib
import os
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
from PIL import Image
from warp2.record.swallowed import noted


def content_hash(source: Path | str | bytes) -> str:
    """Compute SHA-256 digest of image file bytes or byte buffer."""
    if isinstance(source, (bytes, bytearray)):
        return hashlib.sha256(source).hexdigest()
    p = Path(source)
    if not p.is_file():
        return ""
    hasher = hashlib.sha256()
    with p.open("rb") as stream:
        while chunk := stream.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest()


def dhash(image_or_path: Path | str | Image.Image, hash_size: int = 8) -> str:
    """Compute 64-bit difference hash (dHash) from image luminance gradient.

    Converts to grayscale, resizes to (hash_size + 1, hash_size), and computes
    adjacent column pixel difference. Highly resilient to scaling, compression,
    and minor color profile shifts.
    """
    img: Image.Image | None = None
    opened_here = False
    try:
        if isinstance(image_or_path, (str, Path)):
            p = Path(image_or_path)
            if not p.is_file():
                return ""
            img = Image.open(p)
            opened_here = True
        elif isinstance(image_or_path, Image.Image):
            img = image_or_path
        else:
            return ""

        # Grayscale and resize to (hash_size + 1, hash_size)
        gray = img.convert("L").resize((hash_size + 1, hash_size), Image.Resampling.BILINEAR)
        pixels = list(gray.get_flattened_data()) if hasattr(gray, "get_flattened_data") else list(gray.getdata())
        width = hash_size + 1

        # Compare adjacent pixels in each row
        difference = 0
        for row in range(hash_size):
            row_start = row * width
            for col in range(hash_size):
                left = pixels[row_start + col]
                right = pixels[row_start + col + 1]
                if left > right:
                    difference |= 1 << (row * hash_size + col)

        # Format as hexadecimal string padded to 16 chars (64-bit)
        hex_len = (hash_size * hash_size + 3) // 4
        return f"{difference:0{hex_len}x}"
    except Exception:
        return ""
    finally:
        if opened_here and img is not None:
            try:
                img.close()
            except Exception:  # Intention: closing the image is cleanup; the hash is already made or already given up.
                pass


def hamming_distance(h1: str, h2: str) -> int:
    """Compute number of bit positions differing between two hexadecimal hashes."""
    if not h1 or not h2:
        return 64
    try:
        val1 = int(h1, 16)
        val2 = int(h2, 16)
        return (val1 ^ val2).bit_count()
    except (ValueError, TypeError):
        return 64


def dhash_similarity(h1: str, h2: str) -> float:
    """Calculate normalized visual similarity score between 0.0 and 1.0 (100%)."""
    dist = hamming_distance(h1, h2)
    return max(0.0, min(1.0, 1.0 - (dist / 64.0)))


class ImageDeduplicator:
    """Scans collections of images, detecting exact and perceptual near-duplicates."""

    DEFAULT_EXTENSIONS = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif")

    def __init__(self, max_distance: int = 5) -> None:
        """
        Args:
            max_distance: Max Hamming distance to classify as near-duplicate.
                          5 bits out of 64 corresponds to >= 92.2% visual similarity.
        """
        self.max_distance = max_distance

    def inspect_image(self, path: Path | str) -> dict[str, Any] | None:
        """Extract metadata, SHA-256 digest, and perceptual dHash for an image file."""
        p = Path(path)
        if not p.is_file():
            return None
        try:
            with Image.open(p) as img:
                w, h = img.size
                format_name = img.format or p.suffix.lstrip(".").upper()
                dh = dhash(img)
            stat = p.stat()
            return {
                "path": str(p.resolve()),
                "name": p.name,
                "size_bytes": stat.st_size,
                "modified_at": stat.st_mtime,
                "width": w,
                "height": h,
                "resolution": f"{w}x{h}",
                "format": format_name,
                "sha256": content_hash(p),
                "dhash": dh,
            }
        except Exception as exc:
            return {
                "path": str(p.resolve()),
                "name": p.name,
                "error": str(exc),
                "size_bytes": p.stat().st_size if p.exists() else 0,
                "sha256": content_hash(p),
                "dhash": "",
            }

    def scan_directories(self, dirs: Sequence[Path | str],
                         extensions: Sequence[str] | None = None) -> list[dict[str, Any]]:
        """Collect records for all image files found in specified directories."""
        exts = tuple(e.lower() for e in (extensions or self.DEFAULT_EXTENSIONS))
        records = []
        for d in dirs:
            dir_path = Path(d)
            if not dir_path.is_dir():
                continue
            for root, _, files in os.walk(dir_path):
                for f in sorted(files):
                    if f.lower().endswith(exts):
                        rec = self.inspect_image(Path(root) / f)
                        if rec and "error" not in rec:
                            records.append(rec)
        return records

    def find_duplicates(self, paths: Sequence[Path | str] | None = None,
                        dirs: Sequence[Path | str] | None = None,
                        max_distance: int | None = None) -> dict[str, Any]:
        """Find both exact byte duplicates and perceptual near-duplicates."""
        max_dist = self.max_distance if max_distance is None else max_distance
        records: list[dict[str, Any]] = []

        if paths:
            for p in paths:
                rec = self.inspect_image(p)
                if rec and "error" not in rec:
                    records.append(rec)
        if dirs:
            records.extend(self.scan_directories(dirs))

        # 1. Exact duplicates by SHA-256
        by_sha: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for rec in records:
            if rec.get("sha256"):
                by_sha[rec["sha256"]].append(rec)

        exact_groups: list[dict[str, Any]] = []
        exact_matched_paths: set[str] = set()
        for sha, group in by_sha.items():
            if len(group) > 1:
                exact_groups.append({
                    "kind": "exact",
                    "sha256": sha,
                    "count": len(group),
                    "items": group,
                })
                for r in group:
                    exact_matched_paths.add(r["path"])

        # 2. Perceptual near-duplicates by dHash Hamming distance
        near_groups: list[dict[str, Any]] = []
        valid_records = [r for r in records if r.get("dhash")]
        paired: set[tuple[str, str]] = set()

        for i in range(len(valid_records)):
            for j in range(i + 1, len(valid_records)):
                r1, r2 = valid_records[i], valid_records[j]
                if r1["path"] == r2["path"]:
                    continue
                # If they already match exactly, skip near-duplicate pairing
                if r1.get("sha256") and r1["sha256"] == r2.get("sha256"):
                    continue

                dist = hamming_distance(r1["dhash"], r2["dhash"])
                if dist <= max_dist:
                    pair_key = (min(r1["path"], r2["path"]), max(r1["path"], r2["path"]))
                    if pair_key not in paired:
                        paired.add(pair_key)
                        sim = dhash_similarity(r1["dhash"], r2["dhash"])
                        near_groups.append({
                            "kind": "perceptual",
                            "hamming_distance": dist,
                            "similarity": round(sim * 100.0, 1),
                            "items": [r1, r2],
                        })

        return {
            "total_scanned": len(records),
            "exact_duplicate_groups": exact_groups,
            "near_duplicate_pairs": near_groups,
            "has_duplicates": bool(exact_groups or near_groups),
            "duplicate_count": sum(g["count"] - 1 for g in exact_groups) + len(near_groups),
        }

    def is_duplicate(self, candidate: Path | str | bytes,
                     existing_paths: Sequence[Path | str],
                     max_distance: int | None = None) -> tuple[bool, dict[str, Any] | None]:
        """Check if a new candidate image is a duplicate of any existing image."""
        max_dist = self.max_distance if max_distance is None else max_distance

        # Compute candidate signatures
        if isinstance(candidate, (bytes, bytearray)):
            import io
            cand_sha = hashlib.sha256(candidate).hexdigest()
            try:
                with Image.open(io.BytesIO(candidate)) as raw:
                    cand_dh = dhash(raw)
            except Exception:
                cand_dh = ""
            cand_name = "candidate_bytes"
        else:
            p = Path(candidate)
            if not p.is_file():
                return False, None
            cand_sha = content_hash(p)
            cand_dh = dhash(p)
            cand_name = p.name

        for ep in existing_paths:
            ep_path = Path(ep)
            if not ep_path.is_file():
                continue
            # Check exact match
            ep_sha = content_hash(ep_path)
            if cand_sha and ep_sha == cand_sha:
                return True, {
                    "match": "exact",
                    "matched_path": str(ep_path.resolve()),
                    "matched_name": ep_path.name,
                    "candidate_name": cand_name,
                    "distance": 0,
                    "similarity": 100.0,
                }

            # Check perceptual match
            if cand_dh:
                ep_dh = dhash(ep_path)
                dist = hamming_distance(cand_dh, ep_dh)
                if dist <= max_dist:
                    return True, {
                        "match": "perceptual",
                        "matched_path": str(ep_path.resolve()),
                        "matched_name": ep_path.name,
                        "candidate_name": cand_name,
                        "distance": dist,
                        "similarity": round(dhash_similarity(cand_dh, ep_dh) * 100.0, 1),
                    }

        return False, None

    def prune_duplicates(self, duplicate_report: Mapping[str, Any],
                         keep: str = "best_res",
                         dry_run: bool = False) -> dict[str, Any]:
        """Prune exact duplicates, keeping the best resolution or primary copy."""
        exact_groups = duplicate_report.get("exact_duplicate_groups", [])
        removed: list[str] = []
        preserved: list[str] = []

        for group in exact_groups:
            items = group.get("items", [])
            if len(items) <= 1:
                continue

            if keep == "best_res":
                items_sorted = sorted(
                    items,
                    key=lambda r: (r.get("width", 0) * r.get("height", 0), -r.get("modified_at", 0)),
                    reverse=True
                )
            else:
                items_sorted = items

            keeper = items_sorted[0]
            preserved.append(keeper["path"])

            for dup in items_sorted[1:]:
                dup_path = Path(dup["path"])
                if dup_path.is_file():
                    if not dry_run:
                        try:
                            dup_path.unlink(missing_ok=True)
                        except Exception as exc:
                            noted("warp2/ask/dedup.py:ImageDeduplicator.prune_duplicates", exc)
                    removed.append(str(dup_path.resolve()))

        return {
            "dry_run": dry_run,
            "preserved": preserved,
            "removed": removed,
            "removed_count": len(removed),
        }
