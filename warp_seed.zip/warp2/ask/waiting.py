# WARP2/warp2/ask/waiting.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/waiting.py
#  Used by   : warp2/ask/window.py (raises the mark while a person's job runs),
#              warp2/work/loop.py (stands down from its own training while it
#              is up).
#  Uses      : warp2/record/processes.py (to tell a live window from a dead
#              one), warp2/util.py.
#  Description:
#    Whether a person is waiting on this machine right now. One small file, one
#    question, and a mark that cannot outlive the process that raised it.
#  User intention (Andrew, 2026-09-12):
#    "it is fine if it spends the entire process if it is a user need just not
#    if it is on its own work that should be split up."
#
#    THE HALF THAT WAS MISSING. The machine's own work was split into rounds
#    that hand the loop back, which is the second half of that sentence. The
#    first half was never built: a user need may take the whole process — but
#    it cannot take what the machine has already given to itself.
#
#    MEASURED, 2026-09-12. Andrew asked for a picture of a cat fourteen minutes
#    into a LoRA round running at about fourteen seconds a step. The vision
#    reader is a nine-billion parameter model on the same machine; it timed
#    out, so nothing could judge the picture, so the loop that is meant to keep
#    going until a reader says yes had no verdict and stopped after one round.
#    He asked for a cat and got an unjudged picture, because the machine was
#    busy with its own work.
#
#    THE MARK DIES WITH THE PROCESS THAT RAISED IT, and that is the whole
#    reason this reads the process register rather than a timestamp. A window
#    that crashes mid-job would otherwise leave a file saying somebody is
#    waiting, and the machine would never train again — a stand-down rule that
#    can wedge the machine for ever is worse than the starvation it fixes.
#
#    IT STOPS A ROUND FROM STARTING; IT NEVER STOPS ONE THAT IS RUNNING. A
#    trainer half way through is minutes of work that would be thrown away, and
#    throwing it away helps nobody — the person's job is already competing with
#    it either way. So the rule is: while somebody is waiting, do not start
#    another.
# ============================================================================
from __future__ import annotations

import json
import os
from pathlib import Path

from warp2.record.processes import identity
from warp2.util import atomic_write_bytes, now_iso


class Waiting:
    """Whether a person is waiting on this machine right now."""

    def __init__(self, state: Path | str) -> None:
        """Intention: set where the waiting mark lives: asked/waiting.json under the state folder."""
        self.state = Path(state)
        self.path = self.state / "asked" / "waiting.json"

    # -- raising and lowering the mark ---------------------------------------

    def begin(self, what: str = "") -> dict:
        """Say a person is waiting on this process, and for what."""
        pid = int(os.getpid())
        who = identity(pid)
        mark = {"pid": pid, "what": str(what)[:200], "since": now_iso(),
                "started": (who or {}).get("started", "")}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_bytes(self.path, json.dumps(mark).encode("utf-8"))
        return mark

    def done(self) -> bool:
        """Nobody is waiting on this process any more.

        Intention: only lowers a mark THIS process raised, so a second window
        finishing its own job cannot tell the machine that the first one's
        person has stopped waiting.
        """
        mark = self._read()
        if not mark or int(mark.get("pid", -1)) != int(os.getpid()):
            return False
        atomic_write_bytes(self.path, json.dumps({}).encode("utf-8"))
        return True

    def __enter__(self) -> "Waiting":
        """Intention: use as `with Waiting(state):` so the mark is cleared on the way out."""
        return self

    def __exit__(self, *_unused) -> None:
        """Intention: clear the waiting mark when the with block ends, even on an error."""
        self.done()

    # -- asking --------------------------------------------------------------

    def someone(self) -> dict:
        """Who is waiting, if anybody, and for what.

        Intention: a mark whose process is gone is not a person waiting, it is
        a leftover. The process register can tell those apart because it keeps
        WHEN a process started, so a recycled pid is not mistaken for the one
        that raised the mark.
        """
        mark = self._read()
        if not mark or not mark.get("pid"):
            return {}
        who = identity(int(mark["pid"]))
        if who is None:
            return {}
        was = str(mark.get("started") or "")
        if was and str(who.get("started", "")) != was:
            return {}
        return dict(mark)

    def says(self) -> str:
        """Why the machine is standing down, in the words a person would use."""
        mark = self.someone()
        if not mark:
            return ""
        what = mark.get("what") or "something"
        return f"somebody is waiting on {what}; its own training can wait"

    def _read(self) -> dict:
        """Intention: the waiting mark as a dict, or {} when the file is missing or broken."""
        if not self.path.is_file():
            return {}
        try:
            mark = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return mark if isinstance(mark, dict) else {}
