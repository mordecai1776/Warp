# WARP2/warp2/ask/tests/test_image_queue_and_game_arena.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_image_queue_and_game_arena.py
#  Used by   : pytest
#  Uses      : projects/game_builder/reference_game.py, warp2/ask/inbox.py,
#              warp2/ask/media.py, warp2/ask/window.py
#  Description:
#    Tests for projects/game_builder/reference_game.py, warp2/ask/inbox.py,
#    warp2/ask/media.py, warp2/ask/window.py.
#  User intention:
#    The same as the file it tests: see the header of
#    projects/game_builder/reference_game.py and warp2/ask/inbox.py.
# ============================================================================
from __future__ import annotations

import json
import time
from pathlib import Path

from warp2.ask.inbox import Inbox
import pytest

from warp2.ask.window import ActionCentre
from projects.game_builder.reference_game import REFERENCE_GAMES_CATALOG


class DummyWidget:
    def __init__(self, text=''):
        self.text = text
        self.props = {}
    def configure(self, **kwargs):
        self.props.update(kwargs)
        if 'text' in kwargs:
            self.text = kwargs['text']
    def get(self, *args):
        return self.text
    def set(self, val):
        self.text = val
    def delete(self, *args):
        self.text = ''
    def insert(self, *args):
        if len(args) == 2:
            self.text += str(args[1])
    def focus_set(self):
        pass
    def curselection(self):
        return [0]


def test_an_image_ask_goes_to_the_work_and_nothing_is_made_here(tmp_path, monkeypatch):
    """Intention: Andrew, 2026-09-18 — the ask adds to the work instead of
    acting like a trigger. It lands in the inbox, the list reads it back, and
    no picture is made in the window."""
    import warp2.ask.media as media
    monkeypatch.setattr(media, "make_project_image",
                        lambda *a, **k: pytest.fail("the window made a picture"))
    centre = ActionCentre(tmp_path / 'state', root_dir=Path('.'))
    assert len(centre.image_queue) == 0

    item = centre.enqueue_image_action('sunset on a retro beach')
    assert item['status'] == 'pending'
    waiting = Inbox(tmp_path / 'state').waiting()
    assert [w['kind'] for w in waiting] == ['image']
    assert waiting[0]['said'] == 'sunset on a retro beach'

    # A second window reads the same work back; there is no window queue file.
    centre2 = ActionCentre(tmp_path / 'state', root_dir=Path('.'))
    assert [row['subject'] for row in centre2.image_queue] == ['sunset on a retro beach']
    assert not (tmp_path / 'state' / 'images' / 'queue.jsonl').exists()


def test_image_queue_cancel_and_clear(tmp_path):
    """Intention: a pending ask can be taken back; clearing only hides finished ones."""
    centre = ActionCentre(tmp_path / 'state', root_dir=Path('.'))
    item1 = centre.enqueue_image_action('item to delete')
    item2 = centre.enqueue_image_action('item to keep')
    assert len(centre.image_queue) == 2

    assert centre._remove_from_queue_action(item1['id']) is True
    standing = {row['id']: row['status'] for row in centre.image_queue}
    assert standing[item1['id']] == 'failed' and standing[item2['id']] == 'pending'

    centre._clear_completed_queue_action()
    assert [row['id'] for row in centre.image_queue] == [item2['id']]




