# WARP2/warp2/ask/tests/test_practice_rests_but_never_drops_a_subject.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_practice_rests_but_never_drops_a_subject.py
#  Used by   : pytest.
#  Uses      : warp2/ask/practice_choice.py (choose).
#  Description:
#    A subject that has stopped getting better is rested — others go — but
#    its progress is kept and it comes back, resting longer each time it is
#    still flat. It is never dropped before it passes.
#  User intention (Andrew, 2026-09-23): "training and centering practice must
#    not be able to stop until they pass"; (2026-09-24) move on from one that
#    is going nowhere. 2026-10-09, "ok lets get it done" — fix 4.8 of
#    claude/warp2_fix_plan_2026_10_09.md (check E3).
# ============================================================================
from __future__ import annotations

from warp2.ask.practice_choice import choose


def _data():
    """Intention: two backed subjects; "cat" in progress and flat for a long while."""
    attempts = {f"c{i}": {"subject": "cat", "time": i, "evidence": {"score": 0.5 if i == 0 else 0.3}}
                for i in range(6)}
    attempts["d0"] = {"subject": "dog", "time": 0.5, "evidence": {"score": 0.2}}
    return {"subjects": {"cat": "ready", "dog": "ready"}, "attempts": attempts,
            "progress": {"cat": {"round": 6, "wanted": ["ears"]}}}


def test_a_flat_subject_keeps_its_progress_and_comes_back():
    """Intention: check E3 — its progress was deleted and it was let go before it passed."""
    data = _data()
    picks = [choose(data) for _ in range(8)]
    assert picks[0] == "dog"
    assert data["progress"]["cat"] == {"round": 6, "wanted": ["ears"]}
    assert "cat" in picks
