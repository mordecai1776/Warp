# WARP2/warp2/ask/tests/test_only_passed_pictures_are_taught.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_only_passed_pictures_are_taught.py
#  Used by   : pytest.
#  Uses      : warp2/ask/eye_trainer.py, warp2/ask/media.py,
#              warp2/ask/picture_datasets.py, warp2/work/side/asked.py,
#              warp2/train/centroid_cluster_training.py (stubbed).
#  Description:
#    Only pictures the readers judged and passed are taught as the subject,
#    and at the score they were given — never a made-up 1.0 or a 3x boost a
#    person did not give.
#  User intention (Andrew, 2026-10-09): "ok lets get it done" — fix 3.5 of
#    claude/warp2_fix_plan_2026_10_09.md (checks B5, B6, B11). Method: wrong
#    labels hurt deep networks badly; select clean samples (Song et al. 2022,
#    "Learning from noisy labels with deep neural networks: a survey").
# ============================================================================
from __future__ import annotations

from PIL import Image

import readers


def _pictures(tmp_path, n):
    """Intention: n small pictures on disk."""
    paths = []
    for i in range(n):
        path = tmp_path / f"p{i}.png"
        Image.new("RGB", (32, 32), (i * 50, 90, 200 - i * 30)).save(path)
        paths.append(path)
    return paths


def _trainer(tmp_path, monkeypatch):
    """Intention: an eye trainer with no dataset search."""
    from warp2.ask import eye_trainer
    monkeypatch.setattr(eye_trainer, "DatasetCurator", lambda *a, **k: None)
    return eye_trainer, eye_trainer.EyePersistentTrainer(tmp_path, tmp_path)


def test_a_refused_reference_is_not_admitted_on_its_number(tmp_path, monkeypatch):
    """Intention: check B6 — a 0.8 reference whose reader said the cat is not there was admitted."""
    eye_trainer, trainer = _trainer(tmp_path, monkeypatch)
    pictures = _pictures(tmp_path, 2)

    from unittest.mock import Mock, create_autospec
    import image_search
    from warp2.train.dataset_curator import DatasetCurator

    curator = DatasetCurator(tmp_path, tmp_path / "curator-state")
    search = create_autospec(curator.search_internet_media,
                             return_value=[{"path": str(p)} for p in pictures])
    monkeypatch.setattr(curator, "search_internet_media", search)
    trainer.curator = curator
    fallback = Mock(side_effect=AssertionError("curator results must not need fallback search"))
    monkeypatch.setattr(image_search, "CommonsSearch", fallback)
    monkeypatch.setattr(eye_trainer, "noted", lambda *a, **k: None)
    verdicts = iter([{"score": 0.8, "passed": False, "absent": "the cat is not visibly present"},
                     {"score": 0.7, "passed": True}])
    monkeypatch.setattr(eye_trainer, "compute_image_quality",
                        lambda p: {"valid": True, "score": 1.0, "digest": str(p)})
    monkeypatch.setattr(readers, "test_searched_image", lambda *a, **k: next(verdicts))
    got = trainer._find_verified_references("cat", [], {"name": "cat"}, ["a reader"])
    search.assert_called_once_with("cat", limit=3)
    fallback.assert_not_called()
    assert [g["path"] for g in got] == [str(pictures[1].resolve())]


def test_the_centroid_learns_only_the_rounds_that_passed(tmp_path, monkeypatch):
    """Intention: every round so far — failed ones too — was taught as the subject at a perfect score."""
    import warp2.train.centroid_cluster_training as centroid
    eye_trainer, trainer = _trainer(tmp_path, monkeypatch)
    taught = []

    class _Engine:
        def __init__(self, *a, **k):
            pass

        def process_dataset(self, label, dataset):
            taught.extend(dataset)
    monkeypatch.setattr(centroid, "CentroidClusterTrainingEngine", _Engine)

    class _Model:
        def generate(self, tag, path, seed=0):
            Image.new("RGB", (8, 8)).save(path)

        def train_example(self, *a, **k):
            pass

        def save(self, *a, **k):
            pass
    monkeypatch.setattr(eye_trainer, "get_or_load_eye_model", lambda *a: _Model())
    monkeypatch.setattr(trainer, "_get_readers", lambda: ["a reader"])
    monkeypatch.setattr(trainer, "_find_verified_references", lambda *a, **k: [])
    rounds = iter([{"score": 0.5, "passed": False}, {"score": 1.0, "passed": True}])
    monkeypatch.setattr(readers, "test_searched_image", lambda *a, **k: next(rounds))
    trainer.train_until_pass("cat", target_score=0.85, max_rounds=2)
    assert [row["score"] for row in taught] == [1.0]


def _ledger(tmp_path, rows):
    """Intention: a picture ledger holding the given references of "cat"."""
    from warp2.ask.visual import VisualLearning, _digest
    learning = VisualLearning(tmp_path, tmp_path / "state")
    data = learning._load()
    for n, (path, row) in enumerate(zip(_pictures(tmp_path, len(rows)), rows)):
        data["references"][f"r{n}"] = dict(id=f"r{n}", subject="cat", path=str(path),
                                           digest=_digest(path), **row)
    learning._save(data)


def test_make_project_image_teaches_only_usable_references_at_their_score(tmp_path, monkeypatch):
    """Intention: check B6 — rejected and pending references were taught as the subject, a missing score as 1.0."""
    import warp2.ask.media as media
    import warp2.ask.until as until
    import warp2.train.centroid_cluster_training as centroid
    import warp2.train.dataset_curator as curator
    _ledger(tmp_path, [dict(status="rejected", reader_score=0.9),
                       dict(status="pending", reader_verdict="unverified"),
                       dict(status="pending", reader_verdict="verified", reader_score=0.7),
                       dict(status="confirmed", confirmed_by="user")])
    taught, certain = [], []

    class _Model:
        def train_example(self, example, weight=1.0):
            taught.append(example["score"])

        def save(self, *a, **k):
            pass

    class _Engine:
        def __init__(self, *a, **k):
            pass

        def process_dataset(self, label, dataset):
            certain.extend(row["certainty"] for row in dataset)

    class _Until:
        def __init__(self, *a, **k):
            pass

        def make(self, *a, **k):
            return {"approved": False, "how": "out_of_rounds", "evidence": {}}

    class _NoCurator:
        def __init__(self, *a, **k):
            pass

        def discover_and_create_needed(self, *a, **k):
            return []
    monkeypatch.setattr(media, "get_or_load_eye_model", lambda *a: _Model())
    monkeypatch.setattr(centroid, "CentroidClusterTrainingEngine", _Engine)
    monkeypatch.setattr(until, "Until", _Until)
    monkeypatch.setattr(curator, "DatasetCurator", _NoCurator)
    media.make_project_image(tmp_path, tmp_path / "state", "cat")
    assert sorted(taught) == [0.7, 1.0] and sorted(certain) == [0.7, 1.0]


def test_self_confirm_all_leaves_unscored_pictures_for_a_person(tmp_path):
    """Intention: check B5 — unscored pictures were confirmed at a made-up 0.85 / 0.80."""
    from warp2.ask.window import ActionCentre
    made, found = _pictures(tmp_path, 2)
    centre = ActionCentre(tmp_path / "state", root_dir=tmp_path)
    centre.pending_image_confirmations[str(made)] = {"path": str(made), "is_reference": False, "review": None}
    centre.pending_image_confirmations[str(found)] = {"path": str(found), "is_reference": True,
                                                       "review": {"id": "x", "path": str(found), "subject": "cat"}}
    assert centre.self_confirm_pending(threshold=0.7) == []
    assert len(centre.pending_image_confirmations) == 2


def test_a_reference_without_a_reader_score_is_not_self_confirmed(tmp_path):
    """Intention: check B5 — a missing score was confirmed as 1.0."""
    from warp2.ask.media import self_confirm_reference
    from warp2.ask.visual import VisualLearning
    _ledger(tmp_path, [dict(status="pending")])
    row = VisualLearning(tmp_path, tmp_path / "state").references("cat")[0]
    got = self_confirm_reference(tmp_path, tmp_path / "state", {"id": row["id"], "path": row["path"], "subject": "cat"})
    assert got["status"] == "not_judged"
    assert VisualLearning(tmp_path, tmp_path / "state").references("cat")[0]["status"] == "pending"


def test_a_confirmed_reference_is_not_made_an_approved_picture(tmp_path):
    """Intention: check B11 — confirming a reference also approved it as a picture the Eye made."""
    from warp2.ask.media import self_confirm_reference
    from warp2.ask.visual import VisualLearning
    _ledger(tmp_path, [dict(status="pending", reader_verdict="verified", reader_score=0.8)])
    learning = VisualLearning(tmp_path, tmp_path / "state")
    row = learning.references("cat")[0]
    self_confirm_reference(tmp_path, tmp_path / "state", dict(row))
    assert learning.references("cat")[0]["status"] == "confirmed"
    assert not learning._load()["attempts"]


def test_a_found_picture_is_kept_so_it_can_be_confirmed(tmp_path):
    """Intention: check B11 — research results were never saved, and confirming one said "confirmed" for nothing."""
    from warp2.ask.visual import VisualLearning
    learning = VisualLearning(tmp_path, tmp_path / "state")
    assert learning.confirm("nothing-here", True)["status"] == "not_found"
    found = _pictures(tmp_path, 1)[0]
    row = learning.keep_found("cat", found, judged={"score": 0.3, "passed": False, "readers": []})
    assert row["status"] == "pending" and row["reader_verdict"] == "unverified"
    assert learning.confirm(row["id"], True)["status"] == "confirmed"


def test_the_feed_self_confirms_only_what_the_readers_passed(tmp_path):
    """Intention: a 0.9 the readers did not pass (a reader said it is not there) was self-confirmed on its number."""
    from warp2.ask.thread import WARP, image_feed
    from warp2.ask.window import ActionCentre
    passed, refused = _pictures(tmp_path, 2)
    state = tmp_path / "state"
    image_feed(state).add(WARP, "Practice: cat", subject="cat", references=[str(passed), str(refused)],
                          reference_reviews=[
                              {"path": str(passed), "subject": "cat", "id": "a", "reader_score": 0.9,
                               "reader_verdict": "verified"},
                              {"path": str(refused), "subject": "cat", "id": "b", "reader_score": 0.9,
                               "reader_verdict": "unverified"}])
    centre = ActionCentre(state, root_dir=tmp_path)
    centre._take_image_feed()
    assert str(passed.resolve()) not in centre.pending_image_confirmations
    assert str(refused.resolve()) in centre.pending_image_confirmations


def _asked_step_with(tmp_path, monkeypatch, made):
    """Intention: the asked step run once, in this process, on a picture round that answers `made`; what the centroid learned."""
    import warp2.ask.media as media
    import warp2.train.centroid_cluster_training as centroid
    from warp2.ask.inbox import IMAGE, Inbox
    from warp2.work.cadence import Cadence
    from warp2.work.loop import Loop
    from warp2.work.side.turns import SideTurns
    monkeypatch.setenv("WARP2_ASKED_INLINE", "1")
    learned = []

    class _Engine:
        def __init__(self, *a, **k):
            pass

        def process_dataset(self, label, dataset):
            learned.extend(dataset)
    monkeypatch.setattr(centroid, "CentroidClusterTrainingEngine", _Engine)
    picture = _pictures(tmp_path, 1)[0]
    monkeypatch.setattr(media, "make_project_image", lambda *a, **k: dict(made, image_path=str(picture)))
    root = tmp_path / "tree"
    (root / "pkg").mkdir(parents=True)
    (root / "pkg" / "thing.py").write_text("# Intention: x.\ndef hold(n):\n    return n\n", encoding="utf-8")
    state = tmp_path / "state"
    (state / "centering_image").mkdir(parents=True)
    machine = Loop(root, state, run_id="centroid")
    try:
        machine.projects.open("centering_image", intention="makes pictures", source="test")
        Inbox(state).put(IMAGE, said="cat", about="project:centering_image")
        machine.taking.take()
        cadence = Cadence(share=1.0)
        cadence.due = lambda verb: False
        SideTurns(machine, score=200).take(cadence)
    finally:
        machine.close()
    return learned


def test_a_picture_out_of_rounds_is_not_learned_as_the_subject(tmp_path, monkeypatch):
    """Intention: the centroid learned a refused picture as the subject at certainty 1.0."""
    learned = _asked_step_with(tmp_path, monkeypatch, {
        "approved": False, "status": "out_of_rounds", "evidence": {"score": 0.3},
        "reference_reviews": [{"path": "r.png", "reader_score": 0.9, "reader_verdict": "unverified"}]})
    assert learned == []


def test_an_approved_picture_is_learned_at_its_real_score(tmp_path, monkeypatch):
    """Intention: the readers' score, not 1.0; refused references left out; a missing score not made up."""
    learned = _asked_step_with(tmp_path, monkeypatch, {
        "approved": True, "status": "approved", "evidence": {"score": 0.82},
        "reference_reviews": [{"path": "a.png", "reader_score": 0.9, "reader_verdict": "verified"},
                              {"path": "b.png", "reader_score": 0.9, "reader_verdict": "unverified"},
                              {"path": "c.png", "reader_verdict": "verified"}]})
    assert sorted(row["certainty"] for row in learned) == [0.82, 0.9]


def test_a_video_reference_is_taught_only_when_passed_at_its_worth(tmp_path):
    """Intention: check B6 — every searched video reference was taught at weight 1.0, a missing score as 1.0."""
    from warp2.ask.media import _teach_if_passed
    taught = []

    class _Model:
        def train_example(self, example, weight=1.0):
            taught.append((example["score"], weight))
    path = _pictures(tmp_path, 1)[0]
    assert _teach_if_passed(_Model(), {"name": "cat"}, "cat", {}, path, {"passed": False, "score": 0.9}) == 0
    assert _teach_if_passed(_Model(), {"name": "cat"}, "cat", {}, path, {"passed": True}) == 0
    assert _teach_if_passed(_Model(), {"name": "cat"}, "cat", {}, path, {"passed": True, "score": 0.7}) == 1
    assert len(taught) == 1 and taught[0][0] == 0.7
