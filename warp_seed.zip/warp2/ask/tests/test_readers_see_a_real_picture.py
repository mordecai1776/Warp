# WARP2/warp2/ask/tests/test_readers_see_a_real_picture.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_readers_see_a_real_picture.py
#  Used by   : pytest.
#  Uses      : warp2/ask/picture_round.py (PictureRound._read),
#              warp2/ask/visual.py (VisualLearning, its ledger).
#  Description:
#    When a confirmed real picture of the subject is in the ledger, the
#    readers are handed it with the made picture so they can compare; with
#    none, they are asked as before.
#  User intention (Andrew, 2026-10-09): "ok lets get it done" — fix 3.3 of
#    claude/warp2_fix_plan_2026_10_09.md.
# ============================================================================
from __future__ import annotations

from PIL import Image


class _Reader:
    """Intention: a reader that only remembers what it was asked about."""
    name = "seen"

    def __init__(self):
        self.tags = []

    def read(self, path, tag):
        self.tags.append(tag)
        return {"name": self.name, "score": 0.9, "score_kind": "explicit"}


def _round_with(tmp_path, statuses):
    """Intention: a ledger holding one reference of each status, and a made picture to read."""
    from warp2.ask.picture_round import PictureRound
    from warp2.ask.visual import VisualLearning, _digest
    learning = VisualLearning(tmp_path, tmp_path / "state")
    data = learning._load()
    for n, status in enumerate(statuses):
        path = tmp_path / f"real{n}.png"
        Image.new("RGB", (8, 8), (n * 40, 0, 0)).save(path)
        data["references"][f"r{n}"] = dict(id=f"r{n}", subject="cat", path=str(path),
                                           digest=_digest(path), status=status, reader_score=0.5 + n / 10)
    learning._save(data)
    made = tmp_path / "made.png"
    Image.new("RGB", (8, 8), (9, 9, 9)).save(made)
    reader = _Reader()
    state = {"image_path": str(made), "subject": "cat", "tag": {"name": "cat"}}
    PictureRound(learning, readers=[reader])._read(state)
    return reader.tags[0], tmp_path


def test_a_confirmed_real_picture_is_handed_to_the_readers(tmp_path):
    """Intention: the best-scored confirmed picture is the one compared against."""
    tag, root = _round_with(tmp_path, ["rejected", "confirmed", "confirmed"])
    assert tag["data"]["reference"] == str(root / "real2.png") and tag["name"] == "cat"


def test_nothing_confirmed_means_nothing_to_compare(tmp_path):
    """Intention: a pending or rejected picture is not "real" enough to judge by."""
    tag, _ = _round_with(tmp_path, ["rejected", "pending"])
    assert not (tag.get("data") or {}).get("reference") if isinstance(tag, dict) else True
