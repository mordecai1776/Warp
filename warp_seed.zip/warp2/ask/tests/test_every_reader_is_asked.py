# WARP2/warp2/ask/tests/test_every_reader_is_asked.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_every_reader_is_asked.py
#  Used by   : pytest.
#  Uses      : warp2/ask/visual.py (VisualLearning._readers),
#              warp2/ask/eye_trainer.py (EyePersistentTrainer._get_readers),
#              warp2/record/deadline.py (Deadlines).
#  Description:
#    Every vision reader on the machine is asked — not the first two — and
#    the wait on a silent reader is the read cost learned on this machine,
#    never a flat 45 seconds.
#  User intention (Andrew, 2026-10-09): "ok lets get it done" — fix 3.8 of
#    claude/warp2_fix_plan_2026_10_09.md (check F4).
# ============================================================================
from __future__ import annotations

import json

import readers

NAMES = ["vision-a:1b", "vision-b:2b", "vision-c:3b"]


def _learned(state, seconds):
    """Intention: a read cost measured enough times to be trusted."""
    from warp2.ask.visual import READ_VERB
    from warp2.record.deadline import Deadlines
    timing = Deadlines(state / "deadlines.json")
    for _ in range(5):
        timing.observe(READ_VERB, seconds)
    timing.save()
    return timing.budget(READ_VERB)["seconds"]


def test_the_eye_trainer_asks_every_reader_and_waits_what_reads_cost(tmp_path, monkeypatch):
    """Intention: the eye trainer took two readers at a flat 45 s each."""
    from warp2.ask import eye_trainer
    monkeypatch.setattr(eye_trainer, "DatasetCurator", lambda *a, **k: None)
    monkeypatch.setattr(readers, "available_readers", lambda *a, **k: list(NAMES))
    waited = _learned(tmp_path, 200.0)
    got = eye_trainer.EyePersistentTrainer(tmp_path, tmp_path)._get_readers()
    assert [r.name for r in got] == NAMES
    assert all(r.timeout == waited for r in got) and waited != 45


def test_the_picture_round_asks_every_reader(tmp_path):
    """Intention: the picture round's readers were cut to the first two."""
    from warp2.ask.visual import VisualLearning
    learning = VisualLearning(tmp_path, tmp_path / "state")
    learning.home.mkdir(parents=True, exist_ok=True)
    (learning.home / "settings.json").write_text(json.dumps({"readers": NAMES}))
    assert [r.name for r in learning._readers()] == NAMES
