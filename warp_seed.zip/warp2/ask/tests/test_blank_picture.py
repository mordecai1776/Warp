# WARP2/warp2/ask/tests/test_blank_picture.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_blank_picture.py
#  Used by   : pytest.
#  Uses      : warp2/ask/blank.py; PIL, numpy.
#  Description:
#    A picture with nothing a person could see is read as blank (score 0);
#    a picture with something in it is left to the vision readers.
#  User intention (Andrew, 2026-10-01): fix the reader first, so a blank
#    scores near zero.
# ============================================================================
from __future__ import annotations

import numpy as np
from PIL import Image

from warp2.ask.blank import blank_reading


def _save(tmp_path, pixels, name):
    """Intention: a small picture written to a file, as the WARP writes its own."""
    path = tmp_path / name
    Image.fromarray(np.asarray(pixels, dtype=np.uint8)).save(path)
    return path


def test_flat_grey_like_the_warp_made_is_blank(tmp_path):
    """Intention: the measured case — grey with a spread of about 1.5 levels — scores 0 and says why."""
    rng = np.random.default_rng(0)
    grey = np.clip(rng.normal(118, 1.5, (64, 64, 3)), 0, 255)
    said = blank_reading(_save(tmp_path, grey, "grey.png"))
    assert said is not None and said["score"] == 0.0 and said["score_kind"] == "explicit"
    assert "absent" in said["difference"]


def test_a_picture_with_a_shape_is_not_blank(tmp_path):
    """Intention: a dark disc on a light ground is left to the readers."""
    y, x = np.mgrid[0:64, 0:64]
    picture = np.full((64, 64, 3), 200.0)
    picture[(x - 32) ** 2 + (y - 32) ** 2 < 15 ** 2] = 40.0
    assert blank_reading(_save(tmp_path, picture, "disc.png")) is None
