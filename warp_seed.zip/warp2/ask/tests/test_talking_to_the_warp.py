# WARP2/warp2/ask/tests/test_talking_to_the_warp.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_talking_to_the_warp.py
#  Used by   : pytest.
#  Uses      : warp2/ask/{talk,knowing,thread,window}.py.
#  Description:
#    The conversation held to what it promises: the facts answer first, a model
#    only talks, and nothing reaches the store without a yes.
#  User intention (Andrew, 2026-09-07):
#    "We need to be able to talk and get feedback about projects and talk about
#    what and how I want things." And, asked how what he settles on gets
#    written: show him the exact words, store nothing until he says yes.
# ============================================================================
from __future__ import annotations

from warp2.ask.inbox import Inbox
from warp2.ask.knowing import Knowing
from warp2.ask.talk import INTENTION, Talk
from warp2.ask.thread import ANDREW, WARP, Thread
from warp2.ask.window import ActionCentre
from warp2.store.projects import Projects
from warp2.store.store import Store


def _knowing(tmp_path):
    root = tmp_path / "tree"
    root.mkdir()
    store = Store(tmp_path / "state" / "store", run="talk",
                  view_path=tmp_path / "view.sqlite3")
    projects = Projects(store, root)
    projects.open("Centering Image", intention="test centering through pictures")
    projects.add_area("Centering Image", "concept population",
                      "a model for every concept")
    return store, projects, Knowing(store, projects)


def test_it_answers_about_a_project_from_the_facts(tmp_path):
    """Intention: he chose store-first so it is never wrong about his own work
    and never needs a model running. Every number comes from the store or the
    disk at the moment it is asked."""
    store, projects, knowing = _knowing(tmp_path)
    said = Talk(knowing).reply("how is centering image going")["said"]
    assert "Centering Image: 0 of 1 parts built." in said
    assert "test centering through pictures" in said
    assert "concept population" in said


def test_with_no_model_it_still_answers_and_says_so(tmp_path):
    """Intention: NO MODEL IS NOT NO ANSWER. A front door that needs Ollama up
    to be any use is not a front door."""
    store, projects, knowing = _knowing(tmp_path)
    answer = Talk(knowing).reply("what about something nobody mentioned")
    assert answer["proposes"] is None
    assert "do not know anything about that yet" in answer["said"]


def test_he_can_say_it_himself_with_no_model_at_all(tmp_path):
    """Intention: he must be able to instruct it with nothing running. Typing it
    plainly is recognised, and it still comes back as a proposal rather than
    being written."""
    store, projects, knowing = _knowing(tmp_path)
    answer = Talk(knowing).reply(
        "set the intention for centering image to hold the subject in the middle")
    offered = answer["proposes"]
    assert offered["kind"] == INTENTION
    assert offered["about"] == "project:centering_image"
    assert offered["words"] == "hold the subject in the middle"


def test_a_model_may_propose_and_the_line_never_reaches_him(tmp_path):
    """Intention: the model's machinery line is lifted out and the rest is shown
    as talk, so it never appears in front of a person as if it were something he
    said."""
    store, projects, knowing = _knowing(tmp_path)
    def model(prompt):
        assert "Centering Image: 0 of 1 parts built." in prompt   # facts first
        assert "cannot change anything yourself" in prompt
        return ("That sounds like the middle matters more than the edges.\n"
                "PROPOSE: intention | project:centering_image | keep the subject centred")
    answer = Talk(knowing, ask=model).reply("I care about where the thing sits")
    assert answer["said"] == "That sounds like the middle matters more than the edges."
    assert "PROPOSE" not in answer["said"]
    assert answer["proposes"]["words"] == "keep the subject centred"


def test_a_proposal_that_is_not_exactly_right_is_dropped(tmp_path):
    """THE ONE THING THAT MUST NEVER HAPPEN.

    Intention: his yes must never land on words he did not read. A kind the
    machine does not know, or an empty sentence, is dropped in silence rather
    than shown to him as something to approve.
    """
    store, projects, knowing = _knowing(tmp_path)
    for bad in ("PROPOSE: teleport | project:centering_image | somewhere nice",
                "PROPOSE: intention | project:centering_image |   ",
                "I think you should PROPOSE something"):
        answer = Talk(knowing, ask=lambda prompt, b=bad: f"ok\n{b}").reply("hello")
        assert answer["proposes"] is None, bad


def test_a_model_that_falls_over_does_not_take_the_answer_with_it(tmp_path):
    """Intention: Ollama is another process on another schedule. If it is down
    or slow, he still gets what the machine knows."""
    store, projects, knowing = _knowing(tmp_path)
    def broken(prompt):
        raise TimeoutError("no answer")
    answer = Talk(knowing, ask=broken).reply("how is centering image going")
    assert "Centering Image: 0 of 1 parts built." in answer["said"]
    assert "TimeoutError" in answer["said"]


def test_nothing_is_stored_until_he_says_yes(tmp_path):
    """HIS CHOICE, MADE MECHANICAL.

    Intention: a chat window is the easiest place in the world to lose the rule
    that kept 198,047 machine-written intentions out of this tree. The window
    writes a turn and a request; it touches the store never, and the request is
    only written when he presses yes.
    """
    store, projects, knowing = _knowing(tmp_path)
    talk = Talk(knowing, ask=lambda prompt: (
        "Right.\nPROPOSE: intention | project:centering_image | keep it centred"))
    centre = ActionCentre(tmp_path / "state", talk=talk)

    class Box:
        def __init__(self): self.words = ""
        def get(self, *a): return self.words
        def delete(self, *a): self.words = ""
    centre.said = Box()
    centre.said.words = "the middle is what matters"

    centre.send()
    assert centre.proposal["words"] == "keep it centred"
    assert Inbox(tmp_path / "state").waiting() == []       # nothing yet

    centre.approve()
    waiting = Inbox(tmp_path / "state").waiting()
    assert [row["said"] for row in waiting] == ["keep it centred"]
    assert waiting[0]["about"] == "project:centering_image"
    assert store.current(subject="project:centering_image",
                         attr="user_intention")[0]["value"] \
        == "test centering through pictures"               # still his old one


def test_saying_no_is_kept_too(tmp_path):
    """Intention: "he was offered this and said no" is worth as much later as a
    yes."""
    store, projects, knowing = _knowing(tmp_path)
    centre = ActionCentre(tmp_path / "state")
    centre._show_proposal({"kind": INTENTION, "about": "project:centering_image",
                           "words": "something he does not want", "why": "suggested"})
    centre.refuse()
    turns = Thread(tmp_path / "state").recent()
    assert turns[-1]["who"] == ANDREW and turns[-1]["said"] == "no"
    assert turns[-1]["refused"] == "something he does not want"
    assert centre.proposal is None


def test_the_conversation_outlives_the_window(tmp_path):
    """Intention: he closes it and comes back. The window is not the
    conversation, the same way it was never the inbox."""
    thread = Thread(tmp_path / "state")
    thread.add(ANDREW, "what is centering for")
    thread.add(WARP, "making pictures with the middle held")
    again = ActionCentre(tmp_path / "state")
    assert [turn["said"] for turn in again.refresh()] == [
        "what is centering for", "making pictures with the middle held"]


def test_it_answers_to_what_he_calls_things(tmp_path):
    """MEASURED ON HIS OWN STORE.

    Intention: "what about the eye" found nothing while BEHEMOTH_EYE sat right
    there, because only whole names matched. Nobody types a project's full name
    in a sentence. A whole name still wins first, so an exact mention is never
    beaten by a word of another project's name.
    """
    store, projects, knowing = _knowing(tmp_path)
    projects.open("BEHEMOTH_EYE", intention="the program the warp builds")
    assert knowing.find("what about the eye") == "project:behemoth_eye"
    assert knowing.find("how is centering going") == "project:centering_image"
    assert knowing.find("tell me about CENTERING_IMAGE") == "project:centering_image"
    # A word of a name too short to mean anything does not drag it in.
    projects.open("Go Fast", intention="quickly")
    assert knowing.find("let us go now") == ""
    assert knowing.find("make it fast") == "project:go_fast"
    # And a word must be a whole word, not a piece of a longer one.
    assert knowing.find("breakfast is ready") == ""


def test_it_answers_from_knowledge_graph_and_web_research(tmp_path):
    """Chat answers conceptual questions and reports web findings directly from the Knowledge Graph."""
    store, projects, knowing = _knowing(tmp_path)
    # Add a concept and a finding
    store.assert_fact("concept:attention_gate", "has", attr="kind", value="concept")
    store.assert_fact("concept:attention_gate", "has", attr="name", value="Attention Gate")
    store.assert_fact("concept:attention_gate", "has", attr="definition",
                      value="A mechanism filtering irrelevant feature responses.")

    store.assert_fact("finding:test_f1", "has", attr="kind", value="finding")
    store.assert_fact("finding:test_f1", "has", attr="question",
                      value="how do neural attention mechanisms work")
    store.assert_fact("finding:test_f1", "has", attr="summary",
                      value="Neural attention computes weighted dynamic representations.")
    store.assert_fact("https://arxiv.org/abs/test", "supports", "finding:test_f1")

    talk = Talk(knowing)

    # 1. Concept inquiry
    concept_reply = talk.reply("explain attention gate")["said"]
    assert "Attention Gate" in concept_reply
    assert "filtering irrelevant feature responses" in concept_reply

    # 2. Latest web research inquiry
    web_reply = talk.reply("what did you find on the web")["said"]
    assert "Neural attention computes weighted dynamic representations" in web_reply
    assert "https://arxiv.org/abs/test" in web_reply

