# WARP2/warp2/ask/tests/test_dataset_pictures_judged_honestly.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_dataset_pictures_judged_honestly.py
#  Used by   : pytest.
#  Uses      : warp2/ask/picture_datasets.py (PictureDatasets.pull),
#              warp2/ask/reference.py (Worth.by_person).
#  Description:
#    A dataset picture the readers refused is not taught as the subject; a
#    read nobody could make (no reader running) is not a failed sample, so
#    one outage never blocks a dataset; and only a person's yes gets the
#    person's lift — not a dataset's label or the machine's own confirm.
#  User intention (Andrew, 2026-10-09): "ok lets get it done" — fixes 3.5 and
#    3.6 of claude/warp2_fix_plan_2026_10_09.md (checks B6, B7).
# ============================================================================
from __future__ import annotations

from warp2.ask.picture_datasets import PictureDatasets
from warp2.ask.reference import Worth
from warp2.ask.tests.test_picture_datasets import Hub, _learning

REFUSED = {"passed": False, "judged": True, "score": 0.1, "absent": "qwen answered no"}
NOBODY = {"passed": False, "judged": False, "score": 0.0, "said": "not judged: no vision reader is running"}


def _sampled(data):
    """Intention: the one picture per page the readers were asked about."""
    return [r for r in data["references"].values() if r.get("reader_verdict") not in (None, "unread")]


def test_a_dataset_picture_the_readers_refused_is_not_taught(tmp_path):
    """Intention: check B6 — it kept status "confirmed" and was trained at the person's 3x."""
    data = {"references": {}}
    PictureDatasets(_learning(tmp_path), hub=Hub()).pull("cat", data, 1, check=lambda p, s: REFUSED)
    assert [r["status"] for r in _sampled(data)] == ["rejected"]


def test_an_outage_is_not_a_failed_sample(tmp_path):
    """Intention: check B7 — "no reader could look" counted as a failed check and blocked the dataset."""
    data = {"references": {}}
    pulls = PictureDatasets(_learning(tmp_path), hub=Hub())
    for round_no in range(3):
        said = pulls.pull("cat", data, round_no, check=lambda p, s: NOBODY)
    assert said["dataset"] == "pets" and pulls.record()["cat"]["pets"]["reads"] == 0
    assert {r["reader_verdict"] for r in _sampled(data)} == {"not_judged"}


def test_only_a_persons_yes_gets_the_persons_lift():
    """Intention: check B6 — a dataset's label and the machine's own confirm were lifted as a person's yes."""
    worth = Worth()
    assert worth.by_person({"status": "confirmed", "confirmed_by": "user"}) > 1.0
    assert worth.by_person({"status": "confirmed"}) > 1.0  # rows from before confirmed_by was written
    assert worth.by_person({"status": "confirmed", "confirmed_by": "dataset:pets"}) == 1.0
    assert worth.by_person({"status": "confirmed", "confirmed_by": "system"}) == 1.0


def test_reads_by_an_older_judge_do_not_decide_trust():
    """Intention: the cat datasets were marked untrusted by reads the old judge made
    (word match, outages counted as fails); trust counts only the current judge's reads."""
    from warp2.ask.picture_datasets import JUDGE, trusted
    assert trusted({"reads": 4, "passes": 1})  # an old record, no judge named
    assert not trusted({"reads": 4, "passes": 1, "judge": JUDGE})


def test_a_new_read_starts_the_count_again_under_the_current_judge(tmp_path):
    """Intention: the old judge's counts are set aside, not added to."""
    from warp2.ask.picture_datasets import JUDGE
    pulls = PictureDatasets(_learning(tmp_path), hub=Hub())
    data = {"references": {}}
    pulls.pull("cat", data, 1, check=lambda p, s: True)
    record = pulls.record()
    record["cat"]["pets"].pop("judge")
    record["cat"]["pets"].update(reads=9, passes=0)  # as the old judge left it
    pulls._save(record)
    pulls.pull("cat", data, 2, check=lambda p, s: True)
    entry = pulls.record()["cat"]["pets"]
    assert entry["judge"] == JUDGE and (entry["reads"], entry["passes"]) == (1, 1)
