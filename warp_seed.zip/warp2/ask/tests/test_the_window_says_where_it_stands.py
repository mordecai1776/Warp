# WARP2/warp2/ask/tests/test_the_window_says_where_it_stands.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_the_window_says_where_it_stands.py
#  Used by   : pytest.
#  Uses      : warp2/ask/doing.py, warp2/record/stop.py (Halt),
#              warp2/record/journal.py (last_lines).
#  Description:
#    That a person can see whether the warp is running and what it is on, that
#    the halt they press is the halt every part of the tree honours, and that
#    lifting it lifts it everywhere.
#  User intention (Andrew, 2026-09-12):
#    "see if there is anything with the interface that can make it better to
#    use do your best to make it easy and simple for the user to use."
#
#    He closed the whole program six times that evening to stop things, and
#    asked three times in words what the machine was doing. Both are answered
#    here.
# ============================================================================
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone

from warp2.ask.doing import Doing
from warp2.record.journal import TAIL_BYTES, last_lines
from warp2.record.stop import Halt, MIRRORS, Stop


def _lane(state, rows):
    lane = state / "journals"
    lane.mkdir(parents=True, exist_ok=True)
    with (lane / "run.jsonl").open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row) + "\n")


def _row(verb, ago_seconds=5, outcome="ok"):
    when = datetime.now(timezone.utc) - timedelta(seconds=ago_seconds)
    return {"verb": verb, "outcome": outcome, "target": "",
            "ts": when.isoformat()}


# -- reading the end of a file, not all of it ---------------------------------

def test_the_tail_reads_from_the_end(tmp_path):
    """MEASURED, 2026-09-12: a 20 MB execution lane, read whole, every two
    seconds, to show twenty-five rows."""
    big = tmp_path / "big.jsonl"
    big.write_text("".join(f"line {n}\n" for n in range(50000)), encoding="utf-8")
    assert last_lines(big, 3) == ["line 49997", "line 49998", "line 49999"]


def test_the_tail_can_still_ask_for_everything(tmp_path):
    small = tmp_path / "small.jsonl"
    small.write_text("a\nb\nc\n", encoding="utf-8")
    assert last_lines(small, 100) == ["a", "b", "c"]


def test_a_file_that_is_not_there_is_no_lines(tmp_path):
    assert last_lines(tmp_path / "nothing.jsonl", 5) == []


def test_an_empty_file_is_no_lines(tmp_path):
    empty = tmp_path / "empty.jsonl"
    empty.write_text("", encoding="utf-8")
    assert last_lines(empty, 5) == []


def test_a_line_longer_than_the_window_is_still_found(tmp_path):
    """The window grows while it still needs lines; it does not give up."""
    long_line = "x" * (TAIL_BYTES * 3)
    wide = tmp_path / "wide.jsonl"
    wide.write_text(f"first\n{long_line}\nlast\n", encoding="utf-8")
    assert last_lines(wide, 1) == ["last"]


# -- what the warp is doing ---------------------------------------------------

def test_it_says_not_running_when_nothing_is(tmp_path):
    _lane(tmp_path, [])
    assert Doing(tmp_path).says() == "Warp: not running"


def test_it_names_the_last_thing_and_when(tmp_path):
    """A machine that is not running is still worth a sentence about what it
    was doing when it stopped."""
    _lane(tmp_path, [_row("do_work", ago_seconds=8)])
    said = Doing(tmp_path).says()
    assert "do work" in said
    assert "ago" in said


def test_a_verb_reads_as_words(tmp_path):
    _lane(tmp_path, [_row("practice_centering", ago_seconds=3)])
    assert "practice centering" in Doing(tmp_path).says()


def test_minutes_once_it_has_been_a_while(tmp_path):
    _lane(tmp_path, [_row("train", ago_seconds=8 * 60)])
    assert "8m ago" in Doing(tmp_path).says()


def test_a_lane_of_rubbish_does_not_stop_it_answering(tmp_path):
    """This line is read once a second by a window. It is never allowed to be
    the thing that breaks."""
    lane = tmp_path / "journals"
    lane.mkdir(parents=True, exist_ok=True)
    (lane / "run.jsonl").write_text("{not json\n[]\n", encoding="utf-8")
    assert Doing(tmp_path).says() == "Warp: not running"


def test_a_row_with_no_stamp_still_names_the_verb(tmp_path):
    _lane(tmp_path, [{"verb": "index_tree", "outcome": "ok"}])
    said = Doing(tmp_path).says()
    assert "index tree" in said
    assert "ago" not in said


# -- the halt a person presses ------------------------------------------------

def test_raising_it_raises_every_mirror(tmp_path):
    """Every part of the tree checks one of these, and they are not the same
    file. The cockpit mirrors to state/STOP.json; the pathway and the image
    rounds to state/locks/stop.flag."""
    halt = Halt(tmp_path)
    halt.raise_stop("a person said so")
    try:
        assert halt.raised() is True
        for where in MIRRORS:
            assert (tmp_path / where).is_file(), where
        assert Stop(mirror=tmp_path / "locks" / "stop.flag").raised() is True
        assert Stop(mirror=tmp_path / "STOP.json").raised() is True
    finally:
        halt.clear()


def test_lifting_it_lifts_every_mirror(tmp_path):
    """THE RESUME BUTTON HAS TO BE TRUSTABLE.

    `Stop.clear` unlinks only the mirror its caller named, so the cockpit's
    RESUME left the pathway's mirror lying there and the machine stayed
    stopped with nothing on screen saying why.
    """
    halt = Halt(tmp_path)
    halt.raise_stop("a person said so")
    halt.clear()
    assert halt.raised() is False
    for where in MIRRORS:
        assert not (tmp_path / where).exists(), where
    assert Stop(mirror=tmp_path / "locks" / "stop.flag").raised() is False


def test_it_lifts_a_halt_somebody_else_raised(tmp_path):
    """Raised from the command line, lifted from the window, and the other way
    round — one meaning either way."""
    Stop(mirror=tmp_path / "locks" / "stop.flag").raise_stop("from the console")
    halt = Halt(tmp_path)
    assert halt.raised() is True
    halt.clear()
    assert halt.raised() is False


def test_it_says_why_it_is_stopped(tmp_path):
    halt = Halt(tmp_path)
    assert halt.says() == ""
    halt.raise_stop("stopped from the Action Centre")
    try:
        assert "stopped from the Action Centre" in halt.says()
    finally:
        halt.clear()


def test_nothing_raised_is_nothing_to_lift(tmp_path):
    halt = Halt(tmp_path)
    assert halt.raised() is False
    assert halt.clear()["cleared"] == {}
    assert halt.raised() is False
