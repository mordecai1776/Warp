# WARP2/warp2/ask/tests/test_parts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_parts.py
#  Used by   : pytest.
#  Uses      : warp2/ask/parts.py.
#  Description:
#    That what the readers said was missing turns into parts that can be
#    searched for, and that the words describing the complaint do not.
#  User intention (Andrew, 2026-09-12):
#    "it should also be able to break that down when parts need to be trained."
# ============================================================================
from __future__ import annotations

from warp2.ask.parts import Parts


def said(*differences) -> dict:
    return {"readers": [{"name": f"r{n}", "difference": one}
                        for n, one in enumerate(differences)]}


def test_the_derived_reader_s_own_list_is_read_as_a_list():
    """Intention: the derived reader writes `missing ['wheel', 'frame']`, which
    IS the answer. Pulling words out of that sentence would be guessing at
    something already stated exactly."""
    got = Parts().missing(said("Caption mentions ['red']; missing ['wheel', 'frame']; negation=False"))
    assert set(got) == {"wheel", "frame"}


def test_a_part_two_readers_both_name_comes_first():
    """Intention: two readers independently missing the same thing is the
    strongest signal in the whole answer, and taking only the first reader's
    list throws it away."""
    got = Parts().missing(said("missing ['wheel', 'frame']", "missing ['wheel']"))
    assert got[0] == "wheel"


def test_words_about_the_complaint_are_not_parts():
    """Intention: a part called "missing" would be searched for and trained on
    exactly as happily as one called "wheel" — and the model would learn the
    shape of the word instead of the shape of a wheel."""
    assert Parts().missing(said("missing ['nothing', 'unclear', 'blurry']")) == []
    assert Parts().missing(said("The image is noisy and unclear")) == []


def test_a_complaint_about_the_rendering_names_no_parts():
    """MEASURED ON ANDREW'S LIVE RUN, 2026-09-12, AND IT WAS WRONG 3 TIMES OF 3.

    Intention: this used to mine content words out of the reader's prose. The
    reader wrote "obscured by color bleed and soft edges, making it hard to
    define its boundaries" — a complaint about RENDERING, not a missing part —
    and out came `bleed`, `boundaries`, `causing`. The next round searched for
    "cat bleed", "cat boundaries" and "cat causing", and brought back a stone
    boundary wall, a trig point and a close-up of scratched human skin, all of
    which went into the training as references for "cat".
    """
    blurry = said("The central object is somewhat obscured by color bleed and "
                  "soft edges, making it hard to define its boundaries")
    assert Parts().missing(blurry) == []
    assert Parts().queries("cat", Parts().missing(blurry)) == ["cat"]


def test_prose_is_never_mined_even_when_it_reads_like_a_part():
    """Intention: "the wheel is missing" plainly names a part to a person, and
    the same sentence shape produced three junk parts in a row on the live run.
    Only the stated list is trusted, because it is correct by construction —
    the subject's own words that the caption did not mention."""
    assert Parts().missing(said("The wheel is missing and the frame is wrong")) == []


def test_a_reader_that_fell_over_says_nothing_about_the_picture():
    """Intention: a reader's error is evidence about the reader. Reading its
    message for parts would send the next search after words like "timeout"."""
    result = {"readers": [{"name": "r1", "error": "connection refused to ollama"}]}
    assert Parts().missing(result) == []


def test_nothing_said_is_no_parts():
    assert Parts().missing({}) == []
    assert Parts().missing({"readers": []}) == []
    assert Parts().missing({"readers": [{"difference": ""}]}) == []


def test_the_subject_always_stays_in_the_query():
    """Intention: "wheel" on its own fetches a wheel, and a wheel is not a
    reference for a bicycle — it is a new subject the model would learn
    instead. What is wanted is a picture of the thing showing the part."""
    asked = Parts().queries("red bicycle", ["wheel", "frame"])
    assert asked == ["red bicycle wheel", "red bicycle frame"]
    assert all("red bicycle" in one for one in asked)


def test_no_parts_means_search_for_the_subject():
    """Intention: the first round has nothing to go on, and that is not a
    reason to search for nothing."""
    assert Parts().queries("red bicycle", []) == ["red bicycle"]
    assert Parts().queries("red bicycle", None) == ["red bicycle"]


def test_a_reference_is_credited_only_for_what_a_reader_saw_in_it():
    """Intention: read from what the READER said and from the tags already on
    it, never from its filename or its source page's title — those are the
    provider's words, and the whole point of the reader looking at searched
    images is that the provider's words are not evidence."""
    parts = ["wheel", "frame"]
    reader = Parts()
    assert reader.covered_by({"reader_observation": "a bicycle wheel"}, parts) == 1
    assert reader.covered_by({"reader_observation": "wheel and frame"}, parts) == 2
    assert reader.covered_by({"tags": ["frame", "red"]}, parts) == 1
    assert reader.covered_by({"source": {"title": "wheel.jpg"}}, parts) == 0
    assert reader.covered_by({"reader_observation": "a wheel"}, []) == 0
