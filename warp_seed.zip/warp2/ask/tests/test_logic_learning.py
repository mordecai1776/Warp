# WARP2/warp2/ask/tests/test_logic_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_logic_learning.py
#  Used by   : pytest
#  Uses      : warp2/ask/logic_learning.py
#  Description:
#    Tests for warp2/ask/logic_learning.py.
#  User intention:
#    The same as the file it tests: see the header of
#    warp2/ask/logic_learning.py.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest

from warp2.ask.logic_learning import (
    LogicLearning,
    LogicProver,
    LogicConcept,
    ProvenLogicSkill,
    LOGIC_DOMAINS,
)


def test_logic_prover_boolean_sat():
    ok, msg, ms = LogicProver.prove_boolean_sat()
    assert ok is True
    assert "Boolean SAT solver proved satisfiability" in msg
    assert ms > 0.0


def test_logic_prover_forward_chaining():
    ok, msg, ms = LogicProver.prove_forward_chaining()
    assert ok is True
    assert "Forward chaining cleanly inferred chain" in msg
    assert ms > 0.0


def test_logic_prover_backward_chaining():
    ok, msg, ms = LogicProver.prove_backward_chaining()
    assert ok is True
    assert "Backward chaining proved hypothesis" in msg
    assert ms > 0.0


def test_logic_prover_constraint_satisfaction():
    ok, msg, ms = LogicProver.prove_constraint_satisfaction()
    assert ok is True
    assert "CSP solver found conflict-free 3-coloring" in msg
    assert ms > 0.0


def test_logic_prover_syllogistic_deduction():
    ok, msg, ms = LogicProver.prove_syllogistic_deduction()
    assert ok is True
    assert "Syllogistic engine verified valid deduction" in msg
    assert ms > 0.0


def test_logic_prover_demorgan_laws():
    ok, msg, ms = LogicProver.prove_demorgan_laws()
    assert ok is True
    assert "De Morgan's dual laws exhaustively proved" in msg
    assert ms > 0.0


def test_logic_prover_dispatch():
    ok, name, msg, ms = LogicProver.prove_logic_for("Boolean satisfiability problem")
    assert ok is True
    assert "SAT Solver" in name

    ok, name, msg, ms = LogicProver.prove_logic_for("Forward chaining")
    assert ok is True
    assert "Forward Chaining" in name

    ok, name, msg, ms = LogicProver.prove_logic_for("Backward chaining")
    assert ok is True
    assert "Backward Chaining" in name

    ok, name, msg, ms = LogicProver.prove_logic_for("Constraint satisfaction problem")
    assert ok is True
    assert "CSP Constraint" in name

    ok, name, msg, ms = LogicProver.prove_logic_for("Syllogism")
    assert ok is True
    assert "Syllogism Engine" in name

    ok, name, msg, ms = LogicProver.prove_logic_for("De Morgan's laws")
    assert ok is True
    assert "De Morgan" in name

    # Intention: a topic with no proof of its own gets none. It was
    # "proven" by a test of the tag registry, 350 times for one topic.
    for topic in ("Horn clause", "First-order logic", "anything else"):
        assert LogicProver.prove_logic_for(topic) is None
    # Intention (BUILD_LOG 1118): a rule topic now has a proof of its own — its
    # truth table against its fallacy (logic_rules.py) — named for it alone.
    for topic in ("Contraposition", "Modus tollens", "Inference rule"):
        ok, name, msg, ms = LogicProver.prove_logic_for(topic)
        assert ok is True and name == f"Truth table proof of {topic}"


def test_every_logic_topic_is_looked_at_once_before_any_twice(tmp_path: Path):
    """Intention: keyed by topic, so a web title that differs cannot trap the picker."""
    ll = LogicLearning(tmp_path / "root", tmp_path / "state")
    ll.search_online_concept = lambda topic, timeout=4.0: LogicConcept(
        name=f"Title of {topic}", domain="formal_logic", summary="s")
    topics = [t for ts in LOGIC_DOMAINS.values() for t in ts]
    seen = [ll.learn_pass()["topic"] for _ in topics]
    assert sorted(seen) == sorted(topics)
    keyed = {ll.data["concepts"][t.lower()]["topic"] for t in topics}
    assert keyed == set(topics)


def test_logic_learning_init_and_pick(tmp_path: Path):
    root = tmp_path / "root"
    state = tmp_path / "state"
    ll = LogicLearning(root, state)

    domain, topic = ll.pick_next_concept_to_learn()
    assert domain in LOGIC_DOMAINS
    assert topic in LOGIC_DOMAINS[domain]


def test_logic_learning_learn_pass(tmp_path: Path):
    root = tmp_path / "root"
    state = tmp_path / "state"
    ll = LogicLearning(root, state)

    result = ll.learn_pass()
    assert result["status"] == "proven"
    assert result["concept"]
    assert result["proof_name"]
    assert result["execution_time_ms"] >= 0

    # Verify ledger file
    ledger_file = state / "knowledge" / "logic_learning.json"
    assert ledger_file.is_file()
    ledger_data = json.loads(ledger_file.read_text(encoding="utf-8"))
    assert ledger_data["total_passes"] == 1
    assert len(ledger_data["concepts"]) == 1
    assert len(ledger_data["proven_skills"]) == 1

    # Verify proofs JSONL file
    proofs_file = state / "knowledge" / "logic_proofs.jsonl"
    assert proofs_file.is_file()
    lines = [json.loads(line) for line in proofs_file.read_text(encoding="utf-8").strip().splitlines()]
    assert len(lines) == 1
    assert lines[0]["proven"] is True


def test_logic_learning_search_online_mocked(tmp_path: Path):
    root = tmp_path / "root"
    state = tmp_path / "state"
    ll = LogicLearning(root, state)

    mock_resp_data = {
        "title": "Boolean satisfiability problem",
        "extract": "In logic and computer science, the Boolean satisfiability problem is the problem of determining if there exists an interpretation that satisfies a given Boolean formula.",
        "content_urls": {"desktop": {"page": "https://en.wikipedia.org/wiki/Boolean_satisfiability_problem"}},
    }

    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(mock_resp_data).encode("utf-8")
    mock_resp.__enter__.return_value = mock_resp

    with patch("urllib.request.urlopen", return_value=mock_resp):
        concept = ll.search_online_concept("Boolean satisfiability problem")
        assert concept is not None
        assert concept.name == "Boolean satisfiability problem"
        assert "satisfies a given Boolean formula" in concept.summary
        assert concept.source_url == "https://en.wikipedia.org/wiki/Boolean_satisfiability_problem"
