# WARP2/warp2/ask/tests/test_reference_worth.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_reference_worth.py
#  Used by   : pytest.
#  Uses      : warp2/ask/reference.py.
#  Description:
#    That a searched reference is worth what the four readings say, that only
#    what the reader passed may be trained on, and that the average reference
#    still counts one.
#  User intention (Andrew, 2026-09-12):
#    "The reader should check the internet data as well and only give what
#    matches", and "it should also be able to break that down when parts need
#    to be trained."
# ============================================================================
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from warp2.ask.reference import CONFIRMED_LIFT, Worth, usable

NOW = datetime(2026, 9, 12, 12, 0, 0, tzinfo=timezone.utc)


def ref(**fields) -> dict:
    base = {"reader_score": 0.8, "reader_verdict": "verified", "status": "pending"}
    base.update(fields)
    return base


def test_only_what_the_reader_passed_may_be_trained_on():
    """THE ONE ANDREW ASKED FOR IN SO MANY WORDS.

    Intention: the reader was already scoring every searched image and the
    verdict was thrown away — only a human's click admitted anything, so a
    machine left alone fetched references, judged them all, and trained on
    none of them for ever.
    """
    assert usable(ref(reader_verdict="verified")) is True
    assert usable(ref(reader_verdict="unverified")) is False
    assert usable({"status": "confirmed"}) is True
    assert usable({"status": "rejected", "reader_verdict": "verified"}) is False
    assert usable({}) is False


def test_the_reference_the_reader_is_surest_about_pulls_hardest():
    """Intention: the reading that looks backwards and is not. FLOW (arXiv
    2502.02797) weights each sample by how well the model already handles it —
    upweighting the sure ones holds the model still, and about 17% higher
    average accuracy on vision came out of it. Pouring weight into the barely
    passable reference is what causes drift."""
    worth = Worth(now=NOW)
    assert worth.by_reader(ref(reader_score=1.0)) > worth.by_reader(ref(reader_score=0.6))
    assert worth.by_reader(ref(reader_score=0.6)) > worth.by_reader({})


def test_a_person_outranks_a_reader():
    """Intention: where the tree's old CONFIRMED_WEIGHT went. It is a weight
    now instead of a loop that trained the same example three times, because
    three passes of one example is three steps of drift towards it."""
    worth = Worth(now=NOW)
    assert worth.by_person({"status": "confirmed"}) == CONFIRMED_LIFT
    assert worth.by_person({"reader_verdict": "verified"}) == 1.0


def test_fresh_data_counts_more_and_old_data_never_counts_nothing():
    """Intention: every round goes and gets new data, so freshness is the whole
    difference between the batch fetched to fix the problem and the batch that
    did not. An old reference is still a true picture of the subject."""
    worth = Worth(now=NOW)
    fresh = worth.by_time(ref(found_at=NOW.timestamp()))
    week = worth.by_time(ref(found_at=(NOW - timedelta(days=7)).timestamp()))
    year = worth.by_time(ref(found_at=(NOW - timedelta(days=365)).timestamp()))
    assert fresh > week > year >= 0.05
    assert worth.by_time(ref()) == 1.0


def test_a_stamp_in_either_shape_reads(tmp_path):
    """Intention: the ledger writes unix time and the record writes text. Both
    have to read, and neither may raise — a reference with an unreadable stamp
    is still a reference."""
    worth = Worth(now=NOW)
    assert worth.by_time(ref(found_at=NOW.timestamp())) == 1.0
    assert worth.by_time(ref(found_at=NOW.isoformat())) == 1.0
    assert worth.by_time(ref(found_at="not a time")) == 1.0


def test_the_batch_fetched_because_of_the_failure_counts_more():
    """Intention: the mistake setting the weight, for images. Everything known
    stays in the training; what the failure changes is which references pull
    hardest, and that is the data gone and got in answer to it."""
    worth = Worth(now=NOW, latest_round=3)
    assert worth.by_round(ref(round=3)) > worth.by_round(ref(round=1))
    assert Worth(now=NOW).by_round(ref(round=1)) == 1.0


def test_a_reference_showing_a_missing_part_counts_more():
    """Intention: Andrew — "it should also be able to break that down when
    parts need to be trained." A picture that shows the wheel the reader said
    was missing is the reference this round exists to find."""
    worth = Worth(now=NOW, parts=["wheel", "frame"])
    both = worth.by_part(ref(reader_observation="a bicycle wheel and frame"))
    one = worth.by_part(ref(reader_observation="a bicycle wheel"))
    none = worth.by_part(ref(reader_observation="a bicycle"))
    assert both > one > none == 1.0
    assert Worth(now=NOW).by_part(ref(reader_observation="a wheel")) == 1.0


def test_the_average_reference_counts_one():
    """Intention: the same rule as the code side, for the same reason. A weight
    scales the step this example takes, so a batch averaging three trains at
    three times the rate — and the result would be read as "the weighting
    helped" when all that changed was how far every step went."""
    over = Worth(now=NOW, latest_round=2, parts=["wheel"]).over([
        ref(reader_score=1.0, status="confirmed", round=2),
        ref(reader_score=0.7, round=1),
        ref(reader_score=0.9, round=2, reader_observation="a wheel"),
    ])
    assert len(over) == 3
    assert abs(sum(one["weight"] for one in over) / 3.0 - 1.0) < 1e-3
    assert over[0]["weight"] > over[1]["weight"]


def test_no_references_is_no_weights():
    """Intention: an empty batch divides by nothing, and a training round is
    not where that should be found out."""
    assert Worth(now=NOW).over([]) == []


def test_every_weight_stays_inside_its_bounds():
    """Intention: five multipliers compound, and the clamp is what stops one
    reference being the only thing a round learns."""
    got = Worth(now=NOW, latest_round=9, parts=["a", "b", "c"]).weigh(
        ref(reader_score=1.0, status="confirmed", round=9,
            reader_observation="a b c", found_at=NOW.timestamp()))
    assert 0.1 <= got["weight"] <= 8.0
