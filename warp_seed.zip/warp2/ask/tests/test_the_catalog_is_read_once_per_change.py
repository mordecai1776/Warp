# WARP2/warp2/ask/tests/test_the_catalog_is_read_once_per_change.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_the_catalog_is_read_once_per_change.py
#  Used by   : pytest.
#  Uses      : warp2/ask/image_asks.py (_catalog_image).
#  Description:
#    The newest catalog picture for a subject is found as before; asked again
#    with the catalog unchanged it is not read again; once the catalog
#    changes, the new picture is found. The newest training preview is
#    looked for again only when its folder changes.
#  User intention (Andrew, 2026-11-01): "if you see a problem fix a problem"
#    (the sidebar re-read a 24.6 MB catalog every two seconds).
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.ask import image_asks
from warp2.ask.image_asks import _catalog_image


def test_the_catalog_is_read_again_only_when_it_changes(tmp_path, monkeypatch):
    old, new = tmp_path / "old.png", tmp_path / "new.png"
    old.write_bytes(b"x"); new.write_bytes(b"y")
    cat = tmp_path / "catalog.jsonl"
    cat.write_text(json.dumps({"subject": "A Cat", "image_path": str(old)}) + "\n"
                   + json.dumps({"subject": "dog", "image_path": str(new)}) + "\n", encoding="utf-8")
    assert _catalog_image(cat, "cat") == str(old)
    reads = []
    real = Path.read_text
    monkeypatch.setattr(Path, "read_text", lambda self, *a, **k: reads.append(self) or real(self, *a, **k))
    assert _catalog_image(cat, "cat") == str(old)
    assert reads == []
    with cat.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"subject": "cat", "image_path": str(new)}) + "\n")
    assert _catalog_image(cat, "cat") == str(new)
    assert reads == [cat]
    image_asks._CATALOG_SEEN.clear()


def test_the_newest_preview_is_looked_for_again_when_the_folder_changes(tmp_path):
    import os
    from warp2.ask.image_asks import _newest_preview
    folder = tmp_path / "previews"; folder.mkdir()
    (folder / "a.png").write_bytes(b"a")
    os.utime(folder / "a.png", (1, 1))
    assert _newest_preview(folder) == str((folder / "a.png").resolve())
    (folder / "b.png").write_bytes(b"b")
    os.utime(folder, ns=(folder.stat().st_mtime_ns + 10**9,) * 2)
    assert _newest_preview(folder) == str((folder / "b.png").resolve())
    (folder / "b.png").unlink()
    assert _newest_preview(folder) in ("", str((folder / "a.png").resolve()))
    image_asks._CATALOG_SEEN.clear()
