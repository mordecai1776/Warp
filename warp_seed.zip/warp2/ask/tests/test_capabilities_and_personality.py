# WARP2/warp2/ask/tests/test_capabilities_and_personality.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_capabilities_and_personality.py
#  Used by   : pytest.
#  Uses      : warp2/ask/{talk,personality,window,inbox,knowing}.py,
#              warp2/projects/capabilities.py.
#  Description:
#    Tests for project capability tracking, gap detection, image generation
#    proposals, and the evolving personality system.
#  User intention (Andrew, 2026-09-07):
#    "We need it to be able to make a image with one of the project and if it
#    cant do something that needs to become a project. We need to have a
#    evolveing system of what it can and cant do. Through that project system.
#    We also need a way it should act and a evolving personality system that
#    adapts to the user."
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.ask.inbox import IMAGE, Inbox, PROJECT
from warp2.ask.knowing import Knowing
from warp2.ask.personality import Personality
from warp2.ask.talk import Talk
from warp2.ask.window import ActionCentre
from warp2.projects.capabilities import Capabilities
from warp2.store.projects import Projects
from warp2.store.store import Store


def _env(tmp_path):
    root = tmp_path / "tree"
    root.mkdir()
    state = tmp_path / "state"
    state.mkdir()
    store = Store(state / "store", run="test", view_path=tmp_path / "view.sqlite3")
    projects = Projects(store, root)
    projects.open("Centering Image", intention="test centering through pictures")
    projects.add_area("Centering Image", "generator", "pixel pair decoder")
    knowing = Knowing(store, projects)
    caps = Capabilities(store, projects)
    persona = Personality(state)
    return root, state, store, projects, knowing, caps, persona


def test_capabilities_discovers_registered_projects(tmp_path):
    """Capabilities maps registered projects to known competencies."""
    _, _, _, _, _, caps, _ = _env(tmp_path)
    known = caps.known_capabilities()
    names = [c["capability"] for c in known]
    assert "image_generation" in names
    summary = caps.summary()
    assert "image_generation (via Centering Image)" in summary


def test_capabilities_matches_image_requests(tmp_path):
    """An image request matches centering_image capability."""
    _, _, _, _, _, caps, _ = _env(tmp_path)
    matched = caps.match("can you draw a picture of a cat")
    assert matched["supported"] is True
    assert matched["project"] == "centering_image"
    assert matched["capability"] == "image_generation"


def test_capabilities_detects_gap_and_suggests_project(tmp_path):
    """An unsupported action request is identified as a capability gap."""
    _, _, _, _, _, caps, _ = _env(tmp_path)
    matched = caps.match("can you synthesize human speech from audio files")
    assert matched["supported"] is False
    assert matched["is_action"] is True
    assert "synthesize_human_speech" in matched["suggested_project"]
    assert "project:" in matched["reason"]


def test_personality_adapts_to_brevity_and_directives(tmp_path):
    """Personality observes user directives and adjusts prompt guidance."""
    _, state, _, _, _, _, persona = _env(tmp_path)
    assert persona.data["brevity"] == 0.8
    persona.observe("andrew", "be brief please")
    assert persona.data["brevity"] > 0.8

    persona.observe("andrew", "don't make stories, just give facts")
    assert any("stories" in rule for rule in persona.data["learned_preferences"])
    guidance = persona.guidance()
    assert "Invariant" in guidance
    assert "Learned preferences" in guidance


def test_direct_image_request_proposes_image(tmp_path):
    """A direct 'make a picture of X' command returns an IMAGE proposal immediately."""
    _, _, _, _, knowing, caps, persona = _env(tmp_path)
    talk = Talk(knowing, capabilities=caps, personality=persona)
    answer = talk.reply("make a picture of a red apple")
    assert answer["proposes"] is not None
    assert answer["proposes"]["kind"] == IMAGE
    assert answer["proposes"]["about"] == "project:centering_image"
    assert answer["proposes"]["words"] == "a red apple"


def test_model_proposes_image_and_gap_projects(tmp_path):
    """A model response with PROPOSE: image or PROPOSE: project is correctly parsed."""
    _, _, _, _, knowing, caps, persona = _env(tmp_path)

    def model_image(prompt):
        assert "Known system capabilities" in prompt or "What this machine can currently do" in prompt
        assert "How you must act" in prompt
        return "I can ask centering_image to generate that.\nPROPOSE: image | project:centering_image | blue sky"

    talk_img = Talk(knowing, ask=model_image, capabilities=caps, personality=persona)
    ans_img = talk_img.reply("draw something blue")
    assert ans_img["proposes"]["kind"] == IMAGE
    assert ans_img["proposes"]["words"] == "blue sky"

    def model_gap(prompt):
        return "No project does that yet. We should build one.\nPROPOSE: project | voice_synth | synthesize voice"

    talk_gap = Talk(knowing, ask=model_gap, capabilities=caps, personality=persona)
    ans_gap = talk_gap.reply("can you record audio voices")
    assert ans_gap["proposes"]["kind"] == PROJECT
    assert ans_gap["proposes"]["about"] == "voice_synth"


def test_action_centre_approves_image_and_stores_inbox(tmp_path, monkeypatch):
    """Approving an image proposal enqueues an IMAGE request in the inbox and updates persona."""
    root, state, _, _, knowing, caps, persona = _env(tmp_path)
    talk = Talk(knowing, capabilities=caps, personality=persona)
    centre = ActionCentre(state, talk=talk, root_dir=root)
    # Approval adds the picture to the work and makes nothing here
    # (2026-09-18). The ask must be the one stored, not a second one.
    import warp2.ask.media as media
    monkeypatch.setattr(media, "make_project_image",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("made here")))
    centre.proposal = {"kind": IMAGE, "about": "project:centering_image",
                       "words": "red apple", "why": "user requested"}
    made = centre.approve()
    assert made["kind"] == IMAGE
    assert made["said"] == "red apple"
    waiting = Inbox(state).waiting()
    assert len(waiting) == 1 and waiting[0]["id"] == made["id"]
    assert waiting[0]["kind"] == IMAGE
    assert persona.data["proposals_accepted"] == 1


def test_a_talk_with_nowhere_to_keep_a_persona_writes_nowhere(tmp_path):
    """Intention: FOUND 2026-09-11 by watching what a test run leaves behind.
    `Talk` read `getattr(knowing, "state", "state")`, so anything built without
    a state fell back to the bare word — a RELATIVE path, which from the tree
    is `WARP2/state`, the live one. The ask suite was writing
    `state/personality/persona.json` into the repository root on every run.

    Same shape as the ALL_STOP incident of 2026-08-17: a default that quietly
    resolves to the real system. The answer is the same — no guess."""
    import os
    from warp2.ask.talk import Talk

    class KnowsNothing:
        store = None
        projects = None

    here = tmp_path / "cwd"
    here.mkdir()
    was = os.getcwd()
    os.chdir(here)
    try:
        talk = Talk(KnowsNothing())
        assert talk.personality is None
        assert not (here / "state").exists(), "a persona was written to a guessed path"
    finally:
        os.chdir(was)
