# WARP2/warp2/ask/tests/test_picture_datasets.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_picture_datasets.py
#  Used by   : pytest.
#  Uses      : warp2/ask/picture_datasets.py, warp2/ask/hub_pictures.py (_same)
#              with a stand-in hub (no network).
#  Description:
#    A dataset is used only where the subject is a label of its own; its
#    pictures of the subject are added, confirmed by the dataset, and its other
#    pictures under their own labels, taught beside the subject; each pull
#    reads on from the last; a dataset its sample check keeps failing is not
#    pulled from again; nothing is pulled twice; a round teaches every new
#    picture and the taught ones weighed at least the mean.
#  User intention (Andrew, 2026-10-03): "it should have pulled datasets why has
#    it not"; the label is enough, a reader checks a sample.
# ============================================================================
from __future__ import annotations

from types import SimpleNamespace

from warp2.ask import hub_pictures
from warp2.ask.picture_datasets import PictureDatasets, trusted


class Hub:
    """Intention: two datasets: "pets" labels cats (0) and dogs (1); "cattle" names no cat."""
    PAGE = 4

    def __init__(self):
        self.read = []

    def datasets_for(self, subject):
        return ["pets", "cattle"]

    def class_of(self, name, subject):
        return ({"config": "default", "split": "train", "column": "labels", "label": 0, "names": ["Cat", "Dog"]}
                if name == "pets" else None)

    def rows(self, name, where, offset):
        self.read.append(offset)
        rows = [(i, i % 2, f"https://x/{i}.jpg") for i in range(10)]
        return rows[offset:offset + self.PAGE]

    def fetch(self, address):
        return address.encode()


def _learning(tmp_path):
    return SimpleNamespace(home=tmp_path, state=tmp_path)


def test_a_label_name_is_the_subject_only_when_its_words_are():
    assert hub_pictures._same("cat", "cat") and hub_pictures._same("Cats", "cat")
    assert not hub_pictures._same("cattle", "cat") and not hub_pictures._same("cataract", "cat")
    assert not hub_pictures._same("tabby cat", "cat")


def test_only_the_subject_is_pulled_confirmed_by_its_dataset_and_never_twice(tmp_path):
    hub, data = Hub(), {"references": {}}
    pulls = PictureDatasets(_learning(tmp_path), hub=hub)
    said = pulls.pull("cat", data, 3, check=lambda path, subject: True)
    assert said["dataset"] == "pets" and said["added"] == 2 and said["others"] == {"dog": 2}  # rows 0..3
    cats = [r for r in data["references"].values() if r["subject"] == "cat"]
    dogs = [r for r in data["references"].values() if r["subject"] == "dog"]
    assert {r["status"] for r in cats + dogs} == {"confirmed"} and {r["confirmed_by"] for r in cats} == {"dataset:pets"}
    assert {r["source"]["row"] for r in cats} == {0, 2} and all(r["tags"] == ["cat"] for r in cats)
    assert {r["source"]["row"] for r in dogs} == {1, 3} and all(r["not_labels"] == ["cat"] for r in dogs)
    again = pulls.pull("cat", data, 4, check=lambda path, subject: True)
    assert hub.read == [0, 4] and again["added"] == 2 and len(data["references"]) == 8
    record = pulls.record()["cat"]
    assert record["cattle"]["done"] and record["pets"]["offset"] == 8 and record["pets"]["reads"] == 2


def test_a_dataset_that_keeps_failing_its_sample_is_not_pulled_from_again(tmp_path):
    hub, data = Hub(), {"references": {}}
    pulls = PictureDatasets(_learning(tmp_path), hub=hub)
    for round_no in range(2):
        pulls.pull("cat", data, round_no, check=lambda path, subject: False)
    said = pulls.pull("cat", data, 3, check=lambda path, subject: False)
    assert said["dataset"] == "" and said["added"] == 0 and len(data["references"]) == 8


def test_a_new_hub_dataset_is_used_after_a_source_becomes_untrusted(tmp_path):
    class RefreshingHub(Hub):
        def __init__(self):
            super().__init__()
            self.calls = 0

        def datasets_for(self, subject):
            self.calls += 1
            return ["pets", "fresh-pets"] if self.calls > 1 else ["pets"]

        def class_of(self, name, subject):
            if name == "fresh-pets":
                return {"config": "default", "split": "train", "column": "labels", "label": 0,
                        "names": ["Cat", "Dog"], "rows": 10}
            return super().class_of(name, subject)

        def rows(self, name, where, offset):
            rows = super().rows(name, where, offset)
            return [(number, label, address.replace("https://x/", "https://fresh/"))
                    for number, label, address in rows] if name == "fresh-pets" else rows

    hub, data = RefreshingHub(), {"references": {}}
    pulls = PictureDatasets(_learning(tmp_path), hub=hub)
    for round_no in range(2):
        pulls.pull("cat", data, round_no, check=lambda path, subject: False)
    said = pulls.pull("cat", data, 3, check=lambda path, subject: True)
    assert said["dataset"] == "fresh-pets" and said["added"] == 2


def test_trust_is_judged_at_one_standard_error():
    from warp2.ask.picture_datasets import JUDGE  # Intention (2026-10-09): reads by today's judge
    assert trusted({"reads": 1, "passes": 0, "judge": JUDGE})  # one read could be anything
    assert not trusted({"reads": 4, "passes": 1, "judge": JUDGE})  # 0.25 + 0.22 is under a half
    assert not trusted({"reads": 9, "passes": 2, "judge": JUDGE}) and trusted({"reads": 9, "passes": 4, "judge": JUDGE})


def test_pictures_a_dataset_labelled_otherwise_are_taught_beside_the_subject(tmp_path):
    """Intention (Andrew, 2026-10-03: "It should also see if images fit any other labels")."""
    from warp2.ask.picture_round import _told_apart
    hub, data = Hub(), {"references": {}}
    pulls = PictureDatasets(_learning(tmp_path), hub=hub)
    pulls.pull("cat", data, 1, check=lambda path, subject: True)
    pulls.pull("cat", data, 2, check=lambda path, subject: True)
    apart = _told_apart(data, "cat", 3)
    assert len(apart) == 3 and {r["subject"] for r in apart} == {"dog"}
    assert apart[0]["found_at"] >= apart[-1]["found_at"]
    # Intention: and the other way round — the cats are what the dataset said a dog is not.
    assert {r["subject"] for r in _told_apart(data, "dog", 5)} == {"cat"} and len(_told_apart(data, "dog", 5)) == 4
    assert _told_apart(data, "bird", 5) == [] and _told_apart(data, "cat", 0) == []


def test_a_round_teaches_every_picture_of_the_subject_at_its_own_weight():
    """Intention (Andrew, 2026-10-04: centering over "every picture of it"): no picture of the concept is left out."""
    from warp2.ask.picture_round import _this_round
    scored = [({"id": "new light"}, 0.1, 1.0), ({"id": "old heavy", "trained_at": 1.0}, 3.0, 1.0),
              ({"id": "old light", "trained_at": 1.0}, 0.2, 1.0), ({"id": "new heavy"}, 2.0, 1.0)]
    assert [ref["id"] for ref, _, _ in _this_round(scored)] == ["new light", "old heavy", "old light", "new heavy"]
    assert _this_round([]) == []


def test_what_the_readers_see_in_a_sampled_picture_is_kept_on_it(tmp_path):
    """Intention (Andrew, 2026-10-03: "It should also see if images fit any other labels")."""
    hub, data = Hub(), {"references": {}}
    pulls = PictureDatasets(_learning(tmp_path), hub=hub)
    reading = {"passed": True, "score": 0.9, "detected_concepts": {"sofa": 0.8}, "tags": ["sofa", "indoors"]}
    pulls.pull("cat", data, 1, check=lambda path, subject: reading)
    sampled = [r for r in data["references"].values() if r["concept_scores"]]
    assert len(sampled) == 1 and sampled[0]["subject"] == "cat" and sampled[0]["concept_scores"] == {"sofa": 0.8}
    assert sampled[0]["tags"] == ["cat", "indoors", "sofa"] and sampled[0]["reader_verdict"] == "verified"
    assert pulls.record()["cat"]["pets"]["passes"] == 1


def test_a_round_teaches_its_pictures_as_blocks_by_label(monkeypatch):
    """Intention (Andrew, 2026-10-03: "Then lets get it all in"; build log 250)."""
    from warp2.ask import picture_round
    asked, saved = {}, []

    class Model:
        def block_lesson(self, pictures, longest=0):
            asked.update(pictures=pictures, longest=longest)
            return [{"concept": "cat", "steps": 3, "pieces": 9, "before": 0.6, "after": 0.4}]

    model = Model()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)
    learning = SimpleNamespace(_checkpoint=saved.append)
    state = {"part": "blocks", "by_label": {"cat": ["a.png"], "dog": ["b.png"], "bird": []}, "learn_at": 64}
    said = picture_round.PictureRound(learning)._blocks(state)
    assert state["part"] == "practice" and asked == {"pictures": {"cat": ["a.png"], "dog": ["b.png"]}, "longest": 64}
    assert saved == [model] and "cat 0.6 -> 0.4 in 3 steps over 9 pieces" in said["said"]
    state = {"part": "blocks"}
    assert picture_round.PictureRound(learning)._blocks(state)["said"] == "no blocks this round"


def test_a_round_gives_the_rest_of_the_eye_its_block_training(monkeypatch):
    """Intention (Andrew, 2026-10-05: "it should just be the pair and the master"): picture rounds skip parts training."""
    from warp2.ask import picture_round
    learning = SimpleNamespace()
    state = {"part": "parts", "times": {"teach": 30.0, "side": 12.5}}
    said = picture_round.PictureRound(learning)._parts(state)
    assert state["part"] == "practice"
    assert "skipped" in said["said"]


def test_pages_are_read_spread_across_the_dataset_each_once():
    """Intention (2026-10-03): both cat datasets list every cat before every dog."""
    from warp2.ask.picture_datasets import next_page, pages_in
    entry = {"where": {"rows": 8000}, "pages": 0}
    seen = []
    for k in range(pages_in(entry)):
        entry["pages"] = k
        seen.append(next_page(entry) // 100)
    assert sorted(seen) == list(range(80)) and seen[:3] == [0, 49, 18]
    assert abs(seen[1] - seen[0]) > 20  # the second page is far from the first
    unknown = {"where": {}, "offset": 300, "pages": 3}
    assert next_page(unknown) == 300 and pages_in(unknown) == 4


def test_a_claimed_page_is_never_claimed_again_by_another_puller(tmp_path):
    """Intention (2026-10-04, review): two lanes pulling at once read one page twice and the next never."""
    hub = Hub()
    one, two = PictureDatasets(_learning(tmp_path), hub=hub), PictureDatasets(_learning(tmp_path), hub=hub)
    first, second = one._claim("cat"), two._claim("cat")
    assert first[0] == second[0] == "pets" and first[2] != second[2]


def test_a_page_whose_every_download_failed_is_given_back_and_counted_as_failed(tmp_path):
    """Intention (2026-10-04, review): a network outage could mark a whole dataset done."""
    class Down(Hub):
        def fetch(self, address):
            raise OSError("network down")
    hub, data = Down(), {"references": {}}
    pulls = PictureDatasets(_learning(tmp_path), hub=hub)
    said = pulls.pull("cat", data, 1, check=lambda path, subject: True)
    entry = pulls.record()["cat"]["pets"]
    assert said["added"] == 0 and said["failed"] == 4
    assert entry["pages"] == 0 and entry["failed"] == 1 and not entry.get("done")
    hub.fetch = Hub().fetch
    assert pulls.pull("cat", data, 2, check=lambda path, subject: True)["added"] == 2
    assert hub.read == [0, 0], "the page given back is read again"


def test_a_row_already_kept_is_not_downloaded_again_and_downloads_keep_page_order(tmp_path):
    """Intention (2026-10-04, review): pulled for "cat" and for "dog", every picture came down twice."""
    class Counting(Hub):
        def __init__(self):
            super().__init__()
            self.fetched = []

        def fetch(self, address):
            self.fetched.append(address)
            return address.encode()
    hub, data = Counting(), {"references": {}}
    pulls = PictureDatasets(_learning(tmp_path), hub=hub)
    pulls.pull("cat", data, 1, check=lambda path, subject: True)
    assert sorted(hub.fetched) == sorted(f"https://x/{i}.jpg" for i in range(4))
    rows = [r["source"]["row"] for r in data["references"].values()]
    assert rows == [0, 1, 2, 3], "references made in page order"
    hub.fetched.clear()
    import json
    record = pulls.record()
    record["cat"]["pets"]["pages"], record["cat"]["pets"]["offset"] = 0, 0  # the same page again, as a pull for another label would read it
    pulls.path.write_text(json.dumps(record), encoding="utf-8")
    pulls.pull("cat", data, 2, check=lambda path, subject: True)
    assert hub.fetched == []
