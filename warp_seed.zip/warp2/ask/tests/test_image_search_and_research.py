# WARP2/warp2/ask/tests/test_image_search_and_research.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_image_search_and_research.py
#  Used by   : pytest.
#  Uses      : projects/centering_image/image_search.py, warp2/ask/media.py, window.py.
#  Description:
#    Verifies multi-source image search, orientation and resolution filters,
#    perceptual deduplication across search results, and subject research.
#  User intention (Andrew, 2026-09-08):
#    "and we need more options for image search and research."
#    "there needs to be a system to look for ducplicates"
# ============================================================================
from __future__ import annotations

import json
import sys
import tkinter as tk
from pathlib import Path
from PIL import Image
import pytest

_warp2_root = Path(__file__).resolve().parents[3]
if str(_warp2_root) not in sys.path:
    sys.path.insert(0, str(_warp2_root))
_ci_root = _warp2_root / "projects" / "centering_image"
if str(_ci_root) not in sys.path:
    sys.path.insert(0, str(_ci_root))

from image_search import LocalCatalogSearch, MultiSourceSearch
from warp2.ask.media import search_and_research_subject
from warp2.ask.thread import Thread, ANDREW, WARP
from warp2.ask.window import ActionCentre, colours



from PIL import Image, ImageDraw


def _create_test_image(path: Path, size: tuple[int, int], color: str = "blue", pattern: str | None = None) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    im = Image.new("RGB", size, color="white" if pattern else color)
    if pattern == "circle":
        draw = ImageDraw.Draw(im)
        draw.ellipse([size[0]//4, size[1]//4, size[0]*3//4, size[1]*3//4], fill=color)
    elif pattern == "stripes":
        draw = ImageDraw.Draw(im)
        for x in range(0, size[0], 16):
            draw.line([(x, 0), (x, size[1])], fill=color, width=4)
    im.save(path, format="PNG")
    return path


def test_local_catalog_search(tmp_path):
    """LocalCatalogSearch indexes and matches images across specified directory trees."""
    images_dir = tmp_path / "images"
    images_dir.mkdir()

    _create_test_image(images_dir / "golden_retriever_dog.png", (200, 150), color="goldenrod")
    _create_test_image(images_dir / "siamese_cat.png", (150, 150), color="wheat")

    searcher = LocalCatalogSearch(search_dirs=[images_dir], limit=5)
    dest = tmp_path / "dest"

    results = searcher.fetch({"name": "dog retriever"}, dest)
    assert len(results) == 1
    assert "retriever" in results[0]["title"].lower()
    assert results[0]["source"] == "local"
    assert results[0]["width"] == 200
    assert results[0]["height"] == 150


def test_multisource_search_orientation_filtering(tmp_path):
    """MultiSourceSearch correctly applies landscape, portrait, and square orientation filters."""
    catalog = tmp_path / "catalog"
    catalog.mkdir()

    _create_test_image(catalog / "landscape_car.png", (300, 150), color="red")
    _create_test_image(catalog / "portrait_car.png", (150, 300), color="blue")
    _create_test_image(catalog / "square_car.png", (200, 200), color="green")

    dest = tmp_path / "dest"

    # 1. Landscape only
    search_land = MultiSourceSearch(providers=["local"], orientation="landscape", local_dirs=[catalog])
    res_land = search_land.fetch({"name": "car"}, dest)
    assert len(res_land) == 1
    assert "landscape" in res_land[0]["title"]

    # 2. Portrait only
    search_port = MultiSourceSearch(providers=["local"], orientation="portrait", local_dirs=[catalog])
    res_port = search_port.fetch({"name": "car"}, dest)
    assert len(res_port) == 1
    assert "portrait" in res_port[0]["title"]

    # 3. Square only
    search_sq = MultiSourceSearch(providers=["local"], orientation="square", local_dirs=[catalog])
    res_sq = search_sq.fetch({"name": "car"}, dest)
    assert len(res_sq) == 1
    assert "square" in res_sq[0]["title"]


def test_multisource_search_min_resolution_filtering(tmp_path):
    """MultiSourceSearch excludes images below the specified min_resolution threshold."""
    catalog = tmp_path / "catalog"
    catalog.mkdir()

    _create_test_image(catalog / "low_res_mountain.png", (64, 64), color="gray")
    _create_test_image(catalog / "high_res_mountain.png", (512, 512), color="snow")

    dest = tmp_path / "dest"
    searcher = MultiSourceSearch(providers=["local"], min_resolution=256, local_dirs=[catalog])
    res = searcher.fetch({"name": "mountain"}, dest)

    assert len(res) == 1
    assert "high_res" in res[0]["title"]
    assert res[0]["width"] == 512


def test_multisource_search_deduplication(tmp_path):
    """MultiSourceSearch prunes perceptual duplicates among candidate results."""
    catalog = tmp_path / "catalog"
    catalog.mkdir()

    # Create two identical copies with different names, plus one distinct pattern
    _create_test_image(catalog / "apple_copy1.png", (128, 128), color="crimson", pattern="circle")
    _create_test_image(catalog / "apple_copy2.png", (128, 128), color="crimson", pattern="circle")
    _create_test_image(catalog / "apple_different.png", (128, 128), color="green", pattern="stripes")

    dest = tmp_path / "dest"

    # With deduplicate=False, all 3 matches are returned
    search_nodedup = MultiSourceSearch(providers=["local"], deduplicate=False, limit=10, local_dirs=[catalog])
    res_nodedup = search_nodedup.fetch({"name": "apple"}, dest)
    assert len(res_nodedup) == 3

    # With deduplicate=True, the duplicate copy is pruned
    search_dedup = MultiSourceSearch(providers=["local"], deduplicate=True, limit=10, local_dirs=[catalog])
    res_dedup = search_dedup.fetch({"name": "apple"}, dest)
    assert len(res_dedup) == 2


def test_search_and_research_subject(tmp_path):
    """search_and_research_subject aggregates candidates, discovers concepts, and tags duplicates."""
    root_dir = _warp2_root
    state_dir = tmp_path / "state"
    state_images = state_dir / "images"
    state_images.mkdir(parents=True)

    # Put an existing image in state/images
    _create_test_image(state_images / "existing_falcon.png", (100, 100), color="navy")

    # Run research with local source
    report = search_and_research_subject(
        root_dir=root_dir,
        state_dir=state_dir,
        subject="falcon bird",
        sources=["local"],
        limit=5,
        deduplicate=True
    )

    assert report["subject"] == "falcon bird"
    assert "providers_used" in report
    assert "results" in report
    assert isinstance(report["concepts_discovered"], list)
    assert "all_tags" in report
    assert len(report["all_tags"]) > 0
    assert "falcon" in report["all_tags"]

    # Candidate images are tested by readers and tagged
    candidate = report["results"][0]
    assert "reader_score" in candidate
    assert "reader_observation" in candidate
    assert "reader_verdict" in candidate
    assert "tags" in candidate
    assert "falcon" in candidate["tags"]

    # Verify .source.json metadata file was created with tags
    src_json = Path(candidate["image_path"]).with_suffix(".source.json")
    assert src_json.is_file()
    meta_content = json.loads(src_json.read_text(encoding="utf-8"))
    assert "tags" in meta_content


def test_action_centre_search_research_commands(tmp_path, tk_root):
    """ActionCentre /search and /research commands trigger research and log turn to paper."""
    state = tmp_path / "state"
    state_images = state / "images"
    state_images.mkdir(parents=True)

    _create_test_image(state_images / "racing_car.png", (200, 100), color="firebrick")

    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    # Test /search action with local sources
    res = centre.search_research_action("/search racing car", sources=["local"])

    assert res.get("status") == "researching in background" or res.get("subject") == "racing car"
    paper_text = centre.paper.get("1.0", "end")
    assert "racing car" in paper_text.lower() or "research" in paper_text.lower()
