# WARP2/warp2/ask/tests/test_subconcepts_are_trained_and_kept.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_subconcepts_are_trained_and_kept.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/subconcept_tries.py (SubconceptPictures),
#              warp2/ask/picture_round.py (_weigh's sub-concept step, _blocks),
#              projects/behemoth_eye/eye/warp_pictures.py (block_lesson kin).
#  Description:
#    The subject's tried sub-concepts are trained in the round's block part
#    on their own usable pictures (and saved with the round's checkpoint),
#    least-trained first; a subject and its sub-concepts are never taught as
#    "is not" each other.
#  User intention (Andrew, 2026-10-25): "make sure it is saving and retraining
#    the concept model pairs and not just training and throwing it away";
#    muse-476: "we tried adding that in and we tried training on that".
#    BUILD_LOG 637.
# ============================================================================
from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "projects"))


def _book(state: Path) -> None:
    (state / "visual_learning").mkdir(parents=True)
    (state / "visual_learning" / "subconcept_guesses.json").write_text(json.dumps({
        "cat": {"types": ["abyssinian"], "parts": ["ears"], "asked": [],
                "tried": {"abyssinian": {"concept": "abyssinian cat"}, "ears": {"concept": "cat ears"}}},
        "cat ears": {"types": [], "parts": ["tip"], "asked": [], "tried": {"tip": {"concept": "cat ears tip"}}},
    }), encoding="utf-8")


def _refs(tmp: Path) -> dict:
    out = {}
    for i, (subject, status, verdict) in enumerate([
            ("abyssinian cat", "pending", "verified"), ("abyssinian cat", "pending", "unverified"),
            ("cat ears", "confirmed", ""), ("cat ears tip", "pending", "verified"), ("dog", "confirmed", "")]):
        path = tmp / f"p{i}.png"
        path.write_bytes(b"x")
        out[str(i)] = {"subject": subject, "status": status, "reader_verdict": verdict, "path": str(path)}
    return out


def test_tried_subconcepts_and_their_usable_pictures(tmp_path):
    """Intention: every tried sub-concept, a level deeper too, with only its usable pictures."""
    from warp2.ask.subconcept_tries import SubconceptPictures
    _book(tmp_path)
    subs = SubconceptPictures(tmp_path)
    got = subs.pictures("cat", _refs(tmp_path))
    assert set(got) == {"abyssinian cat", "cat ears", "cat ears tip"}
    assert len(got["abyssinian cat"]) == 1, "an unverified picture is not trained on"


def test_least_trained_go_first(tmp_path):
    """Intention: a sub-concept trained in more rounds waits behind the others."""
    from warp2.ask.subconcept_tries import SubconceptPictures
    _book(tmp_path)
    subs = SubconceptPictures(tmp_path)
    subs.trained("cat", ["abyssinian cat", "cat ears"])
    assert list(subs.pictures("cat", _refs(tmp_path)))[0] == "cat ears tip"


def test_kin_are_never_each_others_not(tmp_path):
    """Intention: in a block lesson, cat's and its sub-concepts' pictures are not each other's "is not"; a dog's are."""
    from behemoth_eye.eye import warp_pictures
    blocks = []

    class Fake:
        updates = 0
        eye = SimpleNamespace(lesson=lambda taken: taken)

        def _picture(self, path, longest):
            return (path, None)

        def _made_copy(self, path, longest, rng):
            return "copy:" + path

        def _concept(self, subject):
            return subject

    import behemoth_eye.eye.concept_blocks as cb
    import behemoth_eye.eye.random_pictures as rp
    real_fit, real_rand = cb.fitted_block, rp.random_pieces
    cb.fitted_block = lambda eye, name, block: blocks.append((name, block)) or {"concept": name}
    rp.random_pieces = lambda eye, taken: []
    try:
        for p in ("c.png", "e.png", "d.png"):
            (tmp_path / p).write_bytes(b"x")
        pics = {"cat": [str(tmp_path / "c.png")], "cat ears": [str(tmp_path / "e.png")], "dog": [str(tmp_path / "d.png")]}
        kin = {"cat": {"cat", "cat ears"}, "cat ears": {"cat", "cat ears"}}
        warp_pictures.EyePictures.block_lesson(Fake(), pics, kin=kin)
    finally:
        cb.fitted_block, rp.random_pieces = real_fit, real_rand
    by = {name: block for name, block in blocks}
    nots = {name: {p for p, is_it in block if not is_it and not str(p).startswith("copy:")} for name, block in by.items()}
    assert nots["cat ears"] == {str(tmp_path / "d.png")}, "the cat picture is not taught as 'not cat ears'"
    assert nots["cat"] == {str(tmp_path / "d.png")}
    assert str(tmp_path / "c.png") in nots["dog"] and str(tmp_path / "e.png") in nots["dog"]


def test_the_round_puts_them_in_its_blocks_and_counts_them():
    """Intention: _weigh adds them to by_label with kin; _blocks passes kin and records the training."""
    source = (ROOT / "warp2" / "ask" / "picture_round.py").read_text(encoding="utf-8")
    weigh = source[source.index("    def _weigh("):source.index("    def _teach(")]
    blocks = source[source.index("    def _blocks("):source.index("    def _parts(")]
    assert "SubconceptPictures" in weigh and 'state["kin"]' in weigh
    assert "kin=kin" in blocks and ".trained(" in blocks
