# WARP2/warp2/ask/tests/test_practice_names_its_subject.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_practice_names_its_subject.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/visual.py (VisualLearning.practice).
#  Description:
#    The practice answer names the subject it practised, so the practice step
#    (warp2/work/side/images.py) writes its training block and can confirm it.
#  User intention (Andrew, 2026-09-15): "It shoud just look for images and
#    games to make" — the practice step's result goes into the training
#    blocks. BUILD_LOG 833.
# ============================================================================
from __future__ import annotations

from warp2.ask import visual


class _Until:
    """Intention: stands in for the real round; its best result has no subject, as the real one's does not."""

    def __init__(self, *args, **kwargs):
        pass

    def make(self, subject, resume=None, at_a_time=1):
        """Intention: the answer shape of warp2/ask/until.py `_said`, cut down."""
        return {"subject": subject, "how": "more_to_do", "rounds": 5,
                "best": {"evidence": {"score": 0.4}}, "resume": None,
                "approved": False, "image_path": ""}


class _Feed:
    """Intention: the image feed, stood in; nothing is shown."""

    def add(self, *args, **kwargs):
        pass


def test_the_practice_answer_names_its_subject(tmp_path, monkeypatch):
    """Intention: fails on the old code (subject "" every turn), passes on the new."""
    import warp2.ask.practice_choice as choice
    import warp2.ask.thread as thread
    import warp2.ask.until as until
    monkeypatch.setattr(until, "Until", _Until)
    monkeypatch.setattr(choice, "choose", lambda data, allowed_subjects=None: "cat")
    monkeypatch.setattr(thread, "image_feed", lambda state: _Feed())
    learning = visual.VisualLearning(tmp_path, tmp_path / "state")
    monkeypatch.setattr(learning, "user_asked_subjects", lambda: {"cat"})
    got = learning.practice(every=0)
    assert got["subject"] == "cat"
    assert got["rounds"] == 5
    assert got["evidence"] == {"score": 0.4}
