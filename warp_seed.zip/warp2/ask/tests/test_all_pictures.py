# WARP2/warp2/ask/tests/test_all_pictures.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_all_pictures.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/all_pictures.py; numpy, PIL.
#  Description:
#    The error lessons draw from every source in turn, each in its own
#    order; the Eye's own drawings and files that are not pictures are
#    left out; a restart goes on where it was; an empty source is passed
#    by; new pictures join when the list is made again.
#  User intention (Andrew, 2026-10-26): "Lets change that for the errors to
#    use them all because it should all be simulated data". BUILD_LOG 726.
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from warp2.ask import all_pictures  # noqa: E402
from warp2.ask.all_pictures import AllPictures  # noqa: E402


def _picture(path: Path, size=(40, 30)) -> None:
    """Intention: a plain grey picture written at a path (folders made)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(np.full((size[1], size[0], 3), 128, dtype=np.uint8)).save(path)


class FakeHypersim:
    """Intention: rendered frames named the way Hypersim names them."""

    def __init__(self, folder: Path) -> None:
        """Intention: frames written into a folder, counted."""
        self.folder, self.count = folder, 0

    def next(self):
        """Intention: the next rendered frame, named as Hypersim names it."""
        path = self.folder / f"h{self.count}.png"
        _picture(path)
        self.count += 1
        return path, path, f"ai_a frame {self.count - 1:04d}"

    def peek(self, count, skip=0):
        """Intention: the next `count` frames after `skip`, the count not moved (as HypersimFrames.peek, BUILD_LOG 810,
        817); skipped frames are never written."""
        out = []
        for k in range(skip, skip + count):
            path = self.folder / f"h{self.count + k}.png"
            _picture(path)
            out.append((path, path, f"ai_a frame {self.count + k:04d}"))
        return out

    def held_apart(self):
        """Intention: a frame for the drawings shown."""
        return self.next()


def _state(tmp_path):
    """Intention: a state folder with a picture or two in each source, and the files that must be left out."""
    state = tmp_path / "state"
    _picture(state / "datasets/local/blender/set/b1.png")
    _picture(state / "datasets/local/blender/set/b0.png")
    _picture(state / "visual_learning/references/r0.jpg")
    _picture(state / "visual_learning" / ("a" * 32 + ".png"))
    _picture(state / "visual_learning/test_gen_cat.png")
    _picture(state / "visual_learning/training_previews/p.png")
    _picture(state / "curated_media/incoming/c0.png")
    (state / "curated_media/incoming/c0.source.json").write_text("{}")
    (state / "curated_media/incoming/broken.png").write_text("not a picture")
    _picture(state / "images/references/i0.png", size=(8, 8))
    _picture(state / "visual_learning/references/.tmp-r1.jpg")
    return state


def test_one_from_each_source_in_turn_each_in_its_own_order(tmp_path):
    """Intention: hypersim, blender, references, pulled, curated, (image references too small, nyu empty: passed by), then round again."""
    state = _state(tmp_path)
    pictures = AllPictures(state, tmp_path / "home", FakeHypersim(tmp_path / "h"))
    names = [pictures.next()[2] for _ in range(6)]
    assert names == ["ai_a frame 0000", "blender set/b0.png", "references r0.jpg", "pulled " + "a" * 32 + ".png",
                     "curated incoming c0.png", "ai_a frame 0001"]
    assert pictures.next()[2] == "blender set/b1.png"


def test_the_eyes_own_drawings_and_non_pictures_are_left_out(tmp_path):
    """Intention: previews, test pictures, notes, broken, tiny and half-written (.tmp-) files never come up."""
    state = _state(tmp_path)
    pictures = AllPictures(state, tmp_path / "home", FakeHypersim(tmp_path / "h"))
    seen = {pictures.next()[2] for _ in range(40)}
    assert not any("test_gen_cat" in s or "training_previews" in s or "source.json" in s or "broken" in s or "i0.png" in s or ".tmp-" in s
                   for s in seen)


def test_a_hub_dataset_takes_its_turn_fetched_once_and_kept(tmp_path):
    """Intention (Andrew: "Then lets correct it"; BUILD_LOG 783): the hub photos are listed, fetched one at a time when
    their turn comes, kept on disk (never fetched twice), and take their turn after Hypersim."""
    import io
    state = _state(tmp_path)
    fetched = []

    def get(url):
        """Intention: the hub's listing — two pictures and a note."""
        return [{"type": "file", "path": "HR/0002.png"}, {"type": "file", "path": "HR/0001.png"}, {"type": "file", "path": "HR/notes.txt"}]

    def fetch(url):
        """Intention: one picture's bytes, counted."""
        fetched.append(url)
        out = io.BytesIO()
        Image.fromarray(np.full((40, 60, 3), 99, dtype=np.uint8)).save(out, format="PNG")
        return out.getvalue()
    hub = all_pictures.HubSource(state, tmp_path / "home", "div2k", "someone/DIV2K", "HR", get=get, fetch=fetch)
    pictures = AllPictures(state, tmp_path / "home", FakeHypersim(tmp_path / "h"), hubs=[hub])
    names = [pictures.next()[2] for _ in range(3)]
    assert names == ["ai_a frame 0000", "div2k 0001.png", "blender set/b0.png"]
    assert hub.picture(0)[0].is_file() and len(fetched) == 1, "kept on disk, not fetched again"


def test_a_restart_goes_on_and_new_pictures_join(tmp_path, monkeypatch):
    """Intention: a new AllPictures goes on where the last stopped; a picture added joins once the list is made again."""
    state = _state(tmp_path)
    hub = FakeHypersim(tmp_path / "h")
    AllPictures(state, tmp_path / "home", hub).next()
    assert AllPictures(state, tmp_path / "home", hub).next()[2] == "blender set/b0.png"
    _picture(state / "datasets/local/blender/set/a0.png")
    monkeypatch.setattr(all_pictures, "RELIST_SECONDS", 0.0)
    files = all_pictures.LocalSource(state, tmp_path / "home", *all_pictures.SOURCES[0]).pictures()
    assert files == ["set/a0.png", "set/b0.png", "set/b1.png"]


def test_peek_reads_the_coming_pictures_in_order_without_moving_the_place(tmp_path):
    """Intention (Muse-705/710; BUILD_LOG 810): peek(n) gives the same pictures the next n calls to next() give, in the
    same order, passing by the same broken and tiny files, and leaves the saved place exactly as it was."""
    state = _state(tmp_path)
    pictures = AllPictures(state, tmp_path / "home", FakeHypersim(tmp_path / "h"))
    pictures.next()
    before = pictures.place_file.read_text()
    ahead = [said for _, _, said in pictures.peek(7)]
    assert pictures.place_file.read_text() == before, "the place is not moved by a peek"
    assert ahead == [pictures.next()[2] for _ in range(7)], "the very pictures the lessons will be taught, in order"


def test_peek_past_a_gap_gives_the_same_pictures_and_opens_none_inside_the_gap(tmp_path, monkeypatch):
    """Intention (Muse-713/714; BUILD_LOG 817): peek(n, skip=k) gives the pictures at places k..k+n-1 of the very order
    next() gives them, from the same snapshot, the place not moved; pictures inside the gap are counted, never opened."""
    state = _state(tmp_path)
    (state / "curated_media/incoming/broken.png").unlink()  # (a skipped picture is taken to open; all open here)
    (state / "images/references/i0.png").unlink()  # (too small to open)
    pictures = AllPictures(state, tmp_path / "home", FakeHypersim(tmp_path / "h"))
    pictures.next()
    before = pictures.place_file.read_text()
    whole = pictures.peek(9)
    opened = []
    real = all_pictures._opens
    monkeypatch.setattr(all_pictures, "_opens", lambda path: opened.append(str(path)) or real(path))
    past = pictures.peek(3, skip=6)
    assert [said for _, _, said in past] == [said for _, _, said in whole[6:]], "the same pictures, in order"
    assert pictures.place_file.read_text() == before, "the place is not moved by a peek past a gap"
    local = [said for _, _, said in past if not said.startswith("ai_a")]
    assert len(opened) == len(local), "only the pictures given are opened, none inside the gap"


def test_hypersim_peek_past_a_gap_fetches_only_the_frames_it_gives(tmp_path):
    """Intention (BUILD_LOG 817): HypersimFrames.peek(n, skip=k) gives frames k..k+n-1 of peek(k+n), and fetches no
    frame inside the gap; the place on disk is left as it was."""
    import io
    import json as _json
    from warp2.ask.depth_frames import HypersimFrames
    fetched = []

    def get(url):
        if url.endswith("/train"):
            return [{"type": "directory", "path": "train/ai_a"}, {"type": "directory", "path": "train/ai_b"}]
        names = [f"{kind}_fr{n:04d}.png" for n in range(3) for kind in ("rgb_cam_00", "depth_plane_cam_00")]
        return [{"type": "file", "path": f"x/{n}"} for n in names]

    def fetch(url):
        fetched.append(url)
        out = io.BytesIO()
        Image.fromarray(np.zeros((4, 4, 3), dtype=np.uint8)).save(out, format="PNG")
        return out.getvalue()
    def made(state):
        """Intention: a fresh frames reader, nothing fetched yet, its place one frame in."""
        frames = HypersimFrames(state, get=get, fetch=fetch)
        frames.place_file.parent.mkdir(parents=True, exist_ok=True)
        frames.place_file.write_text(_json.dumps({"scene": 0, "frame": 1}))
        return frames
    whole = [name for _, _, name in made(tmp_path / "whole").peek(5)]
    fetched.clear()
    frames = made(tmp_path / "state")
    past = [name for _, _, name in frames.peek(2, skip=3)]
    assert past == whole[3:], "the frames past the gap, in the same order"
    assert len(fetched) == 2 * 2, "only the two frames given are fetched (photo and depth each), none in the gap"
    assert _json.loads(frames.place_file.read_text()) == {"scene": 0, "frame": 1}


def test_a_hub_source_keeps_only_the_files_its_pattern_names_and_reads_every_page(tmp_path, monkeypatch):
    """Intention (Andrew, 2026-10-28: "get a broader dataset on it"; BUILD_LOG 835): one part of a dataset that holds two
    (Flickr2K's six-digit names in DF2K, not DIV2K's four-digit ones), listed across the hub's pages; the broader
    sources are in the list the lessons take pictures from."""
    from warp2.ask import all_pictures
    listing = [{"type": "file", "path": "000001.png"}, {"type": "file", "path": "0001.png"},
               {"type": "file", "path": "002650.png"}, {"type": "file", "path": "README.md"}]
    hub = all_pictures.HubSource(tmp_path / "state", tmp_path / "home", "flickr2k", "someone/DF2K", "",
                                 keep=r"^\d{6}\.png$", get=lambda url: listing, fetch=lambda url: b"")
    assert hub.pictures() == ["000001.png", "002650.png"]
    names = [s[0] for s in all_pictures.HUB_SOURCES]
    assert names == ["div2k", "flickr2k", "urban100"]

    class Answer:
        def __init__(self, body, link):
            self.body, self.headers = body, {"Link": link}

        def read(self):
            return self.body

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False
    pages = {"https://hub/one": Answer(b'[{"path": "a"}]', '<https://hub/two>; rel="next"'),
             "https://hub/two": Answer(b'[{"path": "b"}]', "")}
    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen", lambda request, timeout=0: pages[request.full_url])
    assert [x["path"] for x in all_pictures._all_pages("https://hub/one", 5.0)] == ["a", "b"]
