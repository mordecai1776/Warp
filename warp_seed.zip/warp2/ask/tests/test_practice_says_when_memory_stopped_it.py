# WARP2/warp2/ask/tests/test_practice_says_when_memory_stopped_it.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_practice_says_when_memory_stopped_it.py
#  Used by   : pytest (run_tests.py, RUN_TESTS.bat).
#  Uses      : warp2/ask/until.py, warp2/work/memory_floor.py (LowMemory).
#  Description:
#    A practice turn stopped by the memory floor says so in its answer:
#    centering practice stood at round 5 for days with no picture and no
#    reason in its receipt (found 2026-11-01).
#  User intention (see warp2/ask/until.py): keep the asked image's place
#    when memory prevents work, so the unfinished request can be continued.
# ============================================================================
from __future__ import annotations


class _Short:
    """Intention: a picture maker that is always under the memory floor."""

    def generate(self, subject, wanted=None, round_no=0, **rest):
        from warp2.work.memory_floor import LowMemory
        raise LowMemory("painter: a learning step: 900 MB free, under the floor of 1536 MB")


def test_memory_stop_is_named_and_keeps_its_place():
    from warp2.ask.until import Until
    got = Until(_Short(), until_it_passes=True).make("sphere", resume={"round": 5, "wanted": ["sphere"]},
                                                     at_a_time=1)
    assert got["how"] == "more_to_do" and got["rounds"] == 5
    assert got["resume"] == {"round": 5, "wanted": ["sphere"]}
    assert got["said"].startswith("stopped early: painter") and got["held_by"] == "memory"
