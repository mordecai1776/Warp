# WARP2/warp2/ask/tests/test_taking.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_taking.py
#  Used by   : pytest.
#  Uses      : warp2/ask/taking.py, warp2/ask/inbox.py.
#  Description:
#    What the runner does with a request taken from the inbox — here, a
#    person's "not done, redo" reopening the task through the queue.
#  User intention (Andrew): the GUI must not show things the system does not
#    actually do (check G5, 2026-10-09).
# ============================================================================
from __future__ import annotations


def test_a_redo_from_the_window_is_reopened_by_the_runner(tmp_path):
    """Intention: found 2026-10-09 (check G5). "Not done? Redo" reopened
    nothing while saying it had; now the runner reopens the item through its
    queue when it takes the request."""
    from types import SimpleNamespace
    from warp2.ask.inbox import REDO, Inbox
    from warp2.ask.taking import Taking
    facts, reopened = [], []
    store = SimpleNamespace(assert_fact=lambda *a, **k: facts.append((a, k)), current=lambda **k: [])
    queue = SimpleNamespace(reopen=lambda item, why: reopened.append((item, why)) or {})
    Inbox(tmp_path).put(REDO, said="wings too small", about="work:build:x")
    taking = Taking(store, None, None, queue, tmp_path)
    taking.take()
    assert reopened and reopened[0][0] == "work:build:x" and "wings too small" in reopened[0][1]
    assert any(k.get("attr") == "until_it_passes" for _, k in facts)
