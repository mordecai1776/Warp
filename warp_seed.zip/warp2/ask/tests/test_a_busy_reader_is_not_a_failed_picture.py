# WARP2/warp2/ask/tests/test_a_busy_reader_is_not_a_failed_picture.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_a_busy_reader_is_not_a_failed_picture.py
#  Used by   : pytest.
#  Uses      : warp2/ask/until.py (Until), warp2/train/mistakes.py (Mistakes),
#              warp2/store/store.py; warp2/ask/tests/test_until.py (Learning).
#  Description:
#    A round no reader could judge — busy or not there — is not counted as a
#    failed picture, so it does not raise training's share of the machine.
#  User intention (Andrew, 2026-10-09): "ok lets get it done" — fix 3.6 of
#    claude/warp2_fix_plan_2026_10_09.md (check B9).
# ============================================================================
from __future__ import annotations

from warp2.ask.tests.test_until import Learning, hit
from warp2.ask.until import SUBJECT, Until
from warp2.store.store import Store
from warp2.train.mistakes import Mistakes

BUSY = {"approved": False, "status": "reader_busy", "image_path": "a.png",
        "evidence": {}, "missing": [], "readers": [{"name": "r1", "error": "timed out"}]}


def test_a_busy_reader_is_not_counted_as_a_failed_picture(tmp_path):
    """Intention: check B9 — reader_busy was noted as a mistake; reader_unavailable was not."""
    seen = Mistakes(Store(tmp_path / "state"))
    Until(Learning([BUSY, BUSY, hit()]), mistakes=seen, rounds=6).make("cat")
    assert seen.repeats(SUBJECT + "cat") == 0


def test_a_busy_reader_one_part_at_a_time_is_not_counted_either(tmp_path):
    """Intention: the same in the round taken a part per turn."""
    seen = Mistakes(Store(tmp_path / "state"))

    class _Parts:
        def step(self, subject, part_state, **kw):
            return {}, {"part": "record", "seconds": 0.0}, dict(BUSY)
    Until(_Parts(), mistakes=seen, rounds=3, one_part=True).make("cat")
    assert seen.repeats(SUBJECT + "cat") == 0
