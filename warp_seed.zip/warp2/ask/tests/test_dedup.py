# WARP2/warp2/ask/tests/test_dedup.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_dedup.py
#  Used by   : pytest.
#  Uses      : warp2/ask/dedup.py.
#  Description:
#    Verifies exact and perceptual difference hashing duplicate detection.
#  User intention (Andrew, 2026-09-08):
#    "there needs to be a system to look for ducplicates"
# ============================================================================
from __future__ import annotations

import io
from pathlib import Path
from PIL import Image, ImageDraw

from warp2.ask.dedup import (
    content_hash,
    dhash,
    hamming_distance,
    dhash_similarity,
    ImageDeduplicator,
)


def _make_pattern_image(color="red", shape="circle", size=(64, 64)) -> Image.Image:
    """Create a distinctive synthetic image for testing."""
    img = Image.new("RGB", size, color="white")
    draw = ImageDraw.Draw(img)
    if shape == "circle":
        draw.ellipse([8, 8, size[0] - 8, size[1] - 8], fill=color)
    elif shape == "rectangle":
        draw.rectangle([10, 10, size[0] - 10, size[1] - 10], fill=color)
    elif shape == "line":
        draw.line([0, 0, size[0], size[1]], fill=color, width=4)
    return img


def test_exact_content_hashing(tmp_path):
    """Identical files produce matching SHA-256; differing files do not."""
    f1 = tmp_path / "img1.png"
    f2 = tmp_path / "img2.png"
    f3 = tmp_path / "img3.png"

    im_a = _make_pattern_image("red", "circle")
    im_a.save(f1)
    im_a.save(f2)  # Exact copy

    im_b = _make_pattern_image("blue", "rectangle")
    im_b.save(f3)  # Different content

    h1 = content_hash(f1)
    h2 = content_hash(f2)
    h3 = content_hash(f3)

    assert len(h1) == 64
    assert h1 == h2
    assert h1 != h3


def test_perceptual_dhash_near_duplicates():
    """Resized and re-compressed versions of the same image have near-zero Hamming distance."""
    base = _make_pattern_image("green", "circle", size=(128, 128))
    resized = base.resize((48, 48), Image.Resampling.BILINEAR)

    # Convert to JPEG bytes and reload
    buf = io.BytesIO()
    base.save(buf, format="JPEG", quality=80)
    buf.seek(0)
    recompressed = Image.open(buf)

    different = _make_pattern_image("blue", "rectangle", size=(128, 128))

    dh_base = dhash(base)
    dh_resized = dhash(resized)
    dh_recomp = dhash(recompressed)
    dh_diff = dhash(different)

    assert len(dh_base) == 16  # 64-bit hex

    # Same image resized or recompressed should have very low Hamming distance (<= 3)
    dist_resized = hamming_distance(dh_base, dh_resized)
    dist_recomp = hamming_distance(dh_base, dh_recomp)
    assert dist_resized <= 3
    assert dist_recomp <= 3

    # High similarity (> 95%)
    assert dhash_similarity(dh_base, dh_resized) >= 0.95
    assert dhash_similarity(dh_base, dh_recomp) >= 0.95

    # Completely different images should have distinct distance (threshold is 5)
    dist_diff = hamming_distance(dh_base, dh_diff)
    assert dist_diff >= 8


def test_deduplicator_find_duplicates(tmp_path):
    """ImageDeduplicator identifies both exact duplicate sets and near-duplicate pairs."""
    d = tmp_path / "images"
    d.mkdir()

    # Create exact duplicate pair
    im1 = _make_pattern_image("red", "circle", (64, 64))
    p1 = d / "orig.png"
    p2 = d / "copy.png"
    im1.save(p1)
    im1.save(p2)

    # Create near-duplicate (same pattern, resized to 48x48 saved as JPEG)
    im_near = im1.resize((48, 48), Image.Resampling.BILINEAR)
    p_near = d / "near_copy.jpg"
    im_near.save(p_near)

    # Create unique distinct image
    im_uniq = _make_pattern_image("yellow", "line", (64, 64))
    p_uniq = d / "unique.png"
    im_uniq.save(p_uniq)

    dedup = ImageDeduplicator(max_distance=5)
    report = dedup.find_duplicates(dirs=[d])

    assert report["total_scanned"] == 4
    assert report["has_duplicates"] is True

    # Exact duplicate group containing orig.png and copy.png
    exact_groups = report["exact_duplicate_groups"]
    assert len(exact_groups) == 1
    assert exact_groups[0]["count"] == 2
    exact_names = {item["name"] for item in exact_groups[0]["items"]}
    assert exact_names == {"orig.png", "copy.png"}

    # Near duplicate pair containing near_copy.jpg with orig or copy
    near_pairs = report["near_duplicate_pairs"]
    assert len(near_pairs) >= 1
    near_names = {item["name"] for pair in near_pairs for item in pair["items"]}
    assert "near_copy.jpg" in near_names


def test_deduplicator_is_duplicate_prevention(tmp_path):
    """is_duplicate correctly flags incoming images matching an existing collection."""
    pool_dir = tmp_path / "pool"
    pool_dir.mkdir()

    im = _make_pattern_image("purple", "rectangle", (80, 80))
    existing_file = pool_dir / "target.png"
    im.save(existing_file)

    dedup = ImageDeduplicator(max_distance=5)

    # Test candidate 1: identical bytes
    is_dup1, match1 = dedup.is_duplicate(existing_file, [existing_file])
    assert is_dup1 is True
    assert match1["match"] == "exact"

    # Test candidate 2: resized near duplicate
    near_im = im.resize((50, 50))
    near_file = tmp_path / "candidate_near.png"
    near_im.save(near_file)

    is_dup2, match2 = dedup.is_duplicate(near_file, [existing_file])
    assert is_dup2 is True
    assert match2["match"] in ("exact", "perceptual")

    # Test candidate 3: novel image
    novel_im = _make_pattern_image("black", "line", (80, 80))
    novel_file = tmp_path / "candidate_novel.png"
    novel_im.save(novel_file)

    is_dup3, match3 = dedup.is_duplicate(novel_file, [existing_file])
    assert is_dup3 is False
    assert match3 is None


def test_deduplicator_prune_duplicates(tmp_path):
    """prune_duplicates safely removes exact redundant copies while keeping the primary."""
    d = tmp_path / "prune_test"
    d.mkdir()

    im = _make_pattern_image("teal", "circle", (64, 64))
    p1 = d / "keeper.png"
    p2 = d / "duplicate1.png"
    p3 = d / "duplicate2.png"
    im.save(p1)
    im.save(p2)
    im.save(p3)

    dedup = ImageDeduplicator()
    report = dedup.find_duplicates(dirs=[d])
    assert len(report["exact_duplicate_groups"]) == 1

    # Prune dry run
    dry_res = dedup.prune_duplicates(report, keep="best_res", dry_run=True)
    assert dry_res["removed_count"] == 2
    assert p1.is_file() and p2.is_file() and p3.is_file()

    # Actual prune
    res = dedup.prune_duplicates(report, keep="best_res", dry_run=False)
    assert res["removed_count"] == 2
    preserved_path = Path(res["preserved"][0])
    assert preserved_path.is_file()
    # Exactly one file remains on disk
    remaining = list(d.glob("*.png"))
    assert len(remaining) == 1
    assert remaining[0] == preserved_path
