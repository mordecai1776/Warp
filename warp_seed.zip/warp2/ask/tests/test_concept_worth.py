# WARP2/warp2/ask/tests/test_concept_worth.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_concept_worth.py
#  Used by   : pytest.
#  Uses      : warp2/ask/concept_worth.py, warp2/ask/picture_round.py
#              (_one_side, PictureRound._concepts) with a stand-in Eye.
#  Description:
#    A concept that fires on the pictures it was named on has learned
#    something; one that fires the same everywhere has not; one named on
#    every picture tells nothing apart. The side part skips only those (the
#    rest are reported); with no report it skips nothing. The report is made
#    again only when the pictures change, and the round's `concepts` part
#    makes it.
#  User intention (Andrew, 2026-10-03): "These questions should be answered by
#    testing what is best."
# ============================================================================
from __future__ import annotations

from types import SimpleNamespace

from warp2.ask import concept_worth
from warp2.ask import picture_round
from warp2.ask.picture_round import PictureRound, _one_side


class Eye:
    """Intention: an Eye whose "fur" fires on fur pictures, "clearly" on everything alike, "score" on all."""
    concepts = SimpleNamespace(pairs={"fur": 1, "clearly": 1, "score": 1, "cat": 1})

    def readings(self, taken, names):
        fur = 0.9 if "fur" in taken else 0.1
        return {"fur": fur, "clearly": 0.5, "score": 0.5, "cat": 0.7}, set()


class Model:
    eye = Eye()

    def _picture(self, path):
        return path, None


def _references():
    refs = []
    for i in range(30):
        tags = ["cat", "score"] + (["fur"] if i % 2 else []) + (["clearly"] if i % 3 == 0 else [])
        refs.append({"path": f"{'fur' if i % 2 else 'bare'}-{i}.png", "tags": tags})
    return refs


def test_what_learned_something_and_what_did_not(tmp_path):
    measured = concept_worth.measure(Model(), _references())
    assert measured["fur"]["learned"] and not measured["fur"]["everywhere"]
    assert not measured["clearly"]["learned"]
    assert measured["score"]["everywhere"] and measured["cat"]["everywhere"]
    concept_worth.save(tmp_path, measured, 30)
    assert concept_worth.learned_nothing(tmp_path) == {"score", "cat"}  # "clearly" is reported, not skipped


def test_the_side_part_skips_what_learned_nothing():
    items = [["p", "clearly", 1.0], ["p", "fur", 0.9]]
    assert _one_side(items, [], skip={"clearly"}) == [["p", "fur", 0.9]]
    assert _one_side(items, []) == [["p", "clearly", 1.0]]
    assert _one_side([["p", "score", 1.0]], [], skip={"score"}) == []


def test_no_report_judges_nothing(tmp_path):
    assert concept_worth.learned_nothing(tmp_path) == set()


class Learning:
    """Intention: a stand-in VisualLearning: its state folder, its references, its stop, its model."""

    def __init__(self, state, refs):
        self.state, self.refs, self.made = state, refs, 0
        self.stop = SimpleNamespace(raised=lambda: False)

    def _load(self):
        return {"references": {str(i): r for i, r in enumerate(self.refs)}}

    def _model(self):
        self.made += 1
        return Model()


def _on_disk(tmp_path):
    refs = _references()
    for i, ref in enumerate(refs):
        path = tmp_path / ref["path"]
        path.write_bytes(b"x")
        ref.update(path=str(path), id=str(i), digest=str(i), usable=True)
    return refs


def test_the_round_measures_again_when_the_pictures_double(tmp_path, monkeypatch):
    monkeypatch.setattr("warp2.ask.reference.usable", lambda ref: True)
    monkeypatch.setattr(picture_round, "_MODELS", {})
    learning = Learning(tmp_path, _on_disk(tmp_path))
    rounds = PictureRound(learning)
    state = picture_round.start("cat", 1)
    assert state["part"] == "concepts"
    said = rounds._concepts(state)
    assert state["part"] == "weigh" and "learned something" in said["said"]
    assert said["concepts"]["pictures"] == 30
    assert "measured on these pictures" in rounds._concepts(picture_round.start("cat", 2))["said"]
    # Intention: a changed name on the same pictures stands until the pictures double.
    learning.refs[0]["tags"] = learning.refs[0]["tags"] + ["whiskers"]
    assert "measured on these pictures" in rounds._concepts(picture_round.start("cat", 3))["said"]
    more = tmp_path / "more"
    more.mkdir()
    extra = _on_disk(more)
    for ref in extra:
        ref["id"] = "more " + ref["id"]
    learning.refs = learning.refs + extra
    said = rounds._concepts(picture_round.start("cat", 4))
    assert "learned something" in said["said"] and said["concepts"]["pictures"] == 60


def test_the_report_stands_until_the_pictures_double(tmp_path):
    """Intention (2026-10-03): reading every picture again each round took longer than the round."""
    concept_worth.save(tmp_path, {}, 10, "mark-a")
    assert concept_worth.is_current(tmp_path, "mark-a")
    assert concept_worth.is_current(tmp_path, "mark-b", 19)
    assert not concept_worth.is_current(tmp_path, "mark-b", 20)
    assert not concept_worth.is_current(tmp_path, "mark-b")


def test_fewer_pictures_than_were_measured_measure_again(tmp_path):
    """Intention (2026-10-04, review): only pictures arriving keep the report; removed ones measure again."""
    concept_worth.save(tmp_path, {}, 10, "mark-a")
    assert concept_worth.is_current(tmp_path, "mark-b", 10)
    assert not concept_worth.is_current(tmp_path, "mark-b", 9)


def test_the_side_step_reads_nothing_while_the_report_stands(tmp_path, monkeypatch):
    """Intention (2026-10-04, review): the side step read every picture each turn."""
    from types import SimpleNamespace
    from warp2.work.side.picture_concepts import PictureConceptsStep
    import warp2.ask.visual as visual
    refs = [{"id": "a"}, {"id": "b"}]
    monkeypatch.setattr(concept_worth, "references_of", lambda learning: refs)
    monkeypatch.setattr(concept_worth, "is_current", lambda state, mark, pictures: True)

    class Learning:
        def __init__(self, root, state):
            self.state = state

        def _model(self):
            raise AssertionError("no model is loaded while the report stands")
    monkeypatch.setattr(visual, "VisualLearning", Learning)
    shared = SimpleNamespace(root=tmp_path, state=tmp_path, loop=SimpleNamespace(), tell=lambda *a, **k: None)
    said = PictureConceptsStep(shared).body()
    assert said["measured"] == 0 and "still stands" in said["why"]


def test_large_recognition_check_is_bounded_and_preserves_rare_positives():
    refs = [{'path': f'fur-{i}.png' if i < 3 else f'bare-{i}.png',
             'tags': ['score'] + (['fur'] if i < 3 else [])} for i in range(1000)]
    calls, progress = [], []
    model = Model()
    real = model.eye.readings
    model.eye = SimpleNamespace(concepts=Eye.concepts,
        readings=lambda taken, names: (calls.append((taken, names)), real(taken, names))[1])
    result = concept_worth.measure(model, refs, progress=lambda *counts: progress.append(counts))
    assert len(calls) == 3 + concept_worth.PER_CLASS
    assert all(names == ['fur'] for _, names in calls)  # universal label needs no GPU work
    assert result['fur']['named'] == 3 and result['fur']['not_named'] == 997
    assert result['fur']['measured_named'] == 3 and result['fur']['measured_not_named'] == 64
    assert result['fur']['sampled'] and result['score']['everywhere']
    assert progress[0][0] == 0 and progress[-1] == (67, 67, 67, 67)
    assert concept_worth.measure(Model(), list(reversed(refs))) == result


def test_no_inference_when_every_label_is_universal_or_unknown():
    model = Model()
    model._picture = lambda path: (_ for _ in ()).throw(AssertionError('no inference needed'))
    result = concept_worth.measure(model, [{'path': 'p', 'tags': ['score', 'unknown']}])
    assert result['score']['everywhere'] and not result['score']['learned']
    assert 'unknown' not in result


def test_failed_or_stopped_measurement_preserves_report_and_reports_progress(tmp_path):
    import json
    import pytest
    learning = Learning(tmp_path, _references())
    concept_worth.save(tmp_path, {'old': {}}, 1)
    before = (tmp_path / concept_worth.REPORT).read_bytes()
    learning.stop = SimpleNamespace(raised=lambda: True)
    with pytest.raises(InterruptedError):
        concept_worth.refresh(learning, Model(), learning.refs)
    assert (tmp_path / concept_worth.REPORT).read_bytes() == before
    progress = json.loads((tmp_path / 'lanes/card.progress.json').read_text())
    assert progress['status'] == 'failed' and progress['done'] == 0
