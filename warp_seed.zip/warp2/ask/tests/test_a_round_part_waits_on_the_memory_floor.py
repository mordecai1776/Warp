# WARP2/warp2/ask/tests/test_a_round_part_waits_on_the_memory_floor.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_a_round_part_waits_on_the_memory_floor.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/picture_round.py (PictureRound.step),
#              warp2/work/memory_floor.py (LowMemory, the floor).
#  Description:
#    That a picture round reads the machine's memory floor before every part:
#    under the floor no part starts, LowMemory is raised (until.py turns it
#    into "more to do"), and the round's state still names the part that
#    comes next. Over the floor the part runs as before.
#  User intention (Andrew, 2026-10-16: "yes" — give the picture maker a
#    memory limit). Measured 2026-10-26 10:52 UTC: the runner at 52 GB
#    private, 644 MB RAM free, in the teach part, which never read the floor.
# ============================================================================
from __future__ import annotations

import pytest

from warp2.ask import picture_round
from warp2.work import memory_floor
from warp2.work.memory_floor import LowMemory


class Learning:
    """Intention: a stand-in VisualLearning; the parts under test are replaced, so nothing of it is read."""


def _round(monkeypatch, free_mb: int) -> tuple:
    """Intention: a round whose concepts part only records that it ran, on a machine with `free_mb` free."""
    ran = []
    monkeypatch.setattr(memory_floor, "_free_now", lambda: free_mb * 2 ** 20)
    monkeypatch.setattr(memory_floor, "give_back", lambda: None)
    monkeypatch.setattr(picture_round, "_retire_extras_once", lambda learning, state: None)

    def concepts(self, state):
        """Intention: the part ran; it moves the round on as the real one does."""
        ran.append(state["part"])
        state["part"] = "weigh"
        return {"said": "ran"}

    monkeypatch.setattr(picture_round.PictureRound, "_concepts", concepts)
    return picture_round.PictureRound(Learning()), picture_round.start("cat", 1), ran


def test_under_the_floor_no_part_starts(monkeypatch):
    """Intention: with free memory under the floor the part is not run and LowMemory says where."""
    from warp2.work import memory_gate
    monkeypatch.setattr(memory_gate, "MIN_FREE_MB", 1536)
    rounds, state, ran = _round(monkeypatch, 644)
    with pytest.raises(LowMemory) as stopped:
        rounds.step(state)
    assert ran == []
    assert state["part"] == "concepts"
    assert "concepts part" in str(stopped.value)


def test_over_the_floor_the_part_runs(monkeypatch):
    """Intention: with room to spare the part runs as it always did."""
    from warp2.work import memory_gate
    monkeypatch.setattr(memory_gate, "MIN_FREE_MB", 1536)
    rounds, state, ran = _round(monkeypatch, 8000)
    state, report, result = rounds.step(state)
    assert ran == ["concepts"]
    assert state["part"] == "weigh" and result is None and report["part"] == "concepts"
