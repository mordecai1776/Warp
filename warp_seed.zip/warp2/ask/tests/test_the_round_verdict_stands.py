# WARP2/warp2/ask/tests/test_the_round_verdict_stands.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_the_round_verdict_stands.py
#  Used by   : pytest.
#  Uses      : warp2/ask/media.py (make_project_image), warp2/ask/until.py
#              (Until, stubbed), warp2/train/dataset_curator.py (stubbed),
#              warp2/work/side/asked.py, warp2/work/loop.py, warp2/ask/inbox.py.
#  Description:
#    The picture round's verdict is the verdict: make_project_image and the
#    asked step pass it on unchanged, the status agrees with it, and nothing
#    trained is reported as zero updates, not a made-up count.
#  User intention (Andrew, 2026-10-09): "ok lets get it done" — fix 3.1 of
#    claude/warp2_fix_plan_2026_10_09.md (check findings B1, B8).
# ============================================================================
from __future__ import annotations

import pytest

STRONG = {"score": 0.95, "minimum": 0.95, "complete": True, "explicit": True, "absent": ""}
FAIR = {"score": 0.65, "minimum": 0.65, "complete": True, "explicit": True, "absent": ""}
# Intention: measurements that pass every structural test, so a second
# judgment would have nothing in the picture to refuse it on.
SOUND = {"centering": {"score": 0.9, "offset": [0.0, 0.0]}, "contours": {"score": 0.9},
         "segmentation": {"fg_bg_contrast": 0.5},
         "sharpening": {"acutance": 0.9, "classification": "sharp image"}}


class _NoCurator:
    """Intention: no dataset search in a test (it would reach the internet)."""

    def __init__(self, *args, **kwargs):
        pass

    def discover_and_create_needed(self, *args, **kwargs):
        return []


def _round_says(monkeypatch, went: dict):
    """Intention: a picture round that answers exactly `went`, so only the passing-on is tested."""
    import warp2.ask.until as until
    import warp2.train.dataset_curator as curator

    class _Until:
        def __init__(self, *args, **kwargs):
            pass

        def make(self, *args, **kwargs):
            return dict(went)

    monkeypatch.setattr(until, "Until", _Until)
    monkeypatch.setattr(curator, "DatasetCurator", _NoCurator)


def test_a_refused_round_is_not_approved_afterwards(tmp_path, monkeypatch):
    """Intention: a strong score the round still refused stays refused, with its own status."""
    from warp2.ask.media import make_project_image
    _round_says(monkeypatch, {"approved": False, "how": "out_of_rounds", "evidence": STRONG})
    got = make_project_image(tmp_path, tmp_path / "state", "cat")
    assert got["approved"] is False and got["status"] == "out_of_rounds"


def test_an_approved_round_stays_approved_and_says_so(tmp_path, monkeypatch):
    """Intention: check B8 — approved by the round, then refused here with status "approved"."""
    from warp2.ask.media import make_project_image
    _round_says(monkeypatch, {"approved": True, "how": "approved", "evidence": FAIR})
    got = make_project_image(tmp_path, tmp_path / "state", "cat")
    assert got["approved"] is True and got["status"] == "approved"


def test_nothing_trained_is_zero_updates(tmp_path, monkeypatch):
    """Intention: check B8 — `updates` was set to at least 1 when nothing was trained."""
    from warp2.ask.media import make_project_image
    _round_says(monkeypatch, {"approved": False, "how": "out_of_rounds", "evidence": FAIR})
    assert make_project_image(tmp_path, tmp_path / "state", "cat")["updates"] == 0


@pytest.fixture
def _inline(monkeypatch):
    """Intention: the asked step's own logic, in this process."""
    monkeypatch.setenv("WARP2_ASKED_INLINE", "1")


def test_the_asked_step_does_not_approve_what_the_round_refused(tmp_path, monkeypatch, _inline):
    """Intention: the asked step judged again with round count as progress and approved it."""
    from PIL import Image
    import warp2.ask.media as media
    from warp2.ask.inbox import IMAGE, Inbox
    from warp2.work.cadence import Cadence
    from warp2.work.loop import Loop
    from warp2.work.side.turns import SideTurns
    picture = tmp_path / "cat.png"
    Image.new("RGB", (64, 64), (200, 120, 40)).save(picture)
    monkeypatch.setattr(media, "make_project_image", lambda *a, **k: {
        "image_path": str(picture), "approved": False, "status": "retrying_for_competence",
        "evidence": STRONG, "rounds": 7, "visual_operations": SOUND})
    root = tmp_path / "tree"
    (root / "pkg").mkdir(parents=True)
    (root / "pkg" / "thing.py").write_text("# Intention: x.\ndef hold(n):\n    return n\n", encoding="utf-8")
    state = tmp_path / "state"
    (state / "centering_image").mkdir(parents=True)
    machine = Loop(root, state, run_id="verdict")
    try:
        machine.projects.open("centering_image", intention="makes pictures", source="test")
        Inbox(state).put(IMAGE, said="cat", about="project:centering_image")
        machine.taking.take()
        cadence = Cadence(share=1.0)
        cadence.due = lambda verb: False
        done = SideTurns(machine, score=200).take(cadence)
        value = done["value"]
        assert value["approved"] is False and not value.get("done")
    finally:
        machine.close()
