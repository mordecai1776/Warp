# WARP2/warp2/ask/tests/test_interactive_playable_games.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_interactive_playable_games.py
#  Used by   : pytest
#  Uses      : projects/game_builder/generator.py,
#              projects/game_builder/reference_game.py,
#              projects/game_player/interactive.py,
#              projects/game_player/play.py, warp2/ask/window.py
#  Description:
#    Comprehensive unit test suite for interactive playable retro games with
#    dynamic control legend.
#  User intention:
#    The same as the file it tests: see the header of
#    projects/game_builder/generator.py and
#    projects/game_builder/reference_game.py.
# ============================================================================
"""Comprehensive unit test suite for interactive playable retro games with dynamic control legend."""
from __future__ import annotations

from pathlib import Path
import pytest

from warp2.ask.window import ActionCentre
from projects.game_builder.generator import GameState, Position
from projects.game_builder.reference_game import parse_ascii_layout, REFERENCE_GAMES_CATALOG, GameStorage
from projects.game_player.interactive import PlayableSession, SYMBOL_DEFINITIONS, ACTION_KEY_MAP
from projects.game_player.play import run_terminal_game


class DummyWidget:
    def __init__(self, text=""):
        self.text = text
        self.props = {}
        self.is_packed = False
        self.master = None

    def configure(self, **kwargs):
        self.props.update(kwargs)
        if "text" in kwargs:
            self.text = kwargs["text"]

    def config(self, **kwargs):
        self.configure(**kwargs)

    def get(self, *args):
        return self.text

    def set(self, val):
        self.text = val

    def delete(self, *args):
        self.text = ""

    def insert(self, *args):
        if len(args) == 2:
            self.text += str(args[1])

    def focus_set(self):
        pass

    def curselection(self):
        return [0]

    def pack(self, *args, **kwargs):
        self.is_packed = True

    def pack_forget(self):
        self.is_packed = False

    def winfo_ismapped(self):
        return self.is_packed



class DummyEvent:
    def __init__(self, char="", keysym=""):
        self.char = char
        self.keysym = keysym


def test_parse_ascii_layout_creates_playable_state():
    """Verify that canonical layout strings parse into valid, playable GameState instances."""
    for slug in ("pac-man", "frogger", "sokoban", "asteroids", "rogue"):
        ref = REFERENCE_GAMES_CATALOG[slug]
        state = parse_ascii_layout(ref.canonical_layout)
        assert isinstance(state, GameState)
        assert state.grid.width > 0
        assert state.grid.height > 0
        player = state.grid.get_actor("player")
        assert player is not None
        assert player.kind == "player"
        assert state.step_count == 0
        assert state.total_score == 0.0
        assert state.won is False
        assert state.terminated is False


def test_playable_session_movement_and_scoring(tmp_path):
    """Verify player directional navigation, collision checking, and score tracking."""
    session = PlayableSession.from_name_or_canonical("pac-man", mode="original", state_dir=str(tmp_path))
    assert session.game_name == "Pac-Man"
    assert session.mode == "original"
    assert session.steps == 0

    init_pos = session.state.grid.get_actor("player").position

    # Move right into empty space/pellet
    outcome = session.apply_action("RIGHT")
    new_pos = session.state.grid.get_actor("player").position
    assert session.steps == 1
    assert outcome.reward is not None

    # Move into wall (upwards into boundary wall)
    session.apply_action("UP")
    pos_after_wall = session.state.grid.get_actor("player").position
    assert pos_after_wall.y == new_pos.y  # Blocked by top wall


def test_playable_session_win_and_loss_conditions(tmp_path):
    """Verify goal victory and hazard loss mechanics."""
    # Test loss on hazard (Frogger)
    frog_session = PlayableSession.from_name_or_canonical("frogger", mode="original", state_dir=str(tmp_path))
    # In canonical Frogger, moving UP twice hits the car hazard row
    frog_session.apply_action("UP")
    outcome = frog_session.apply_action("UP")
    assert frog_session.terminated is True
    assert frog_session.won is False

    # Test win condition on custom level
    simple_layout = (
        "#####\n"
        "#@ G#\n"
        "#####"
    )
    win_state = parse_ascii_layout(simple_layout)
    win_session = PlayableSession(win_state, game_name="Quick Win")
    assert win_session.won is False

    # Step right twice to reach goal
    win_session.apply_action("RIGHT")
    assert win_session.won is False
    win_session.apply_action("RIGHT")
    assert win_session.won is True
    assert win_session.terminated is True


def test_playable_session_sokoban_box_push():
    """Verify pushable box and dock mechanics in Sokoban."""
    sokoban_layout = (
        "######\n"
        "#@ B.#\n"
        "######"
    )
    soko_state = parse_ascii_layout(sokoban_layout)
    soko_session = PlayableSession(soko_state, game_name="Mini Sokoban")

    box = soko_state.grid.get_actor("box_0")
    assert box is not None
    assert box.position.x == 3

    # Step right toward box
    soko_session.apply_action("RIGHT")
    assert soko_session.state.grid.get_actor("player").position.x == 2
    assert box.position.x == 3

    # Push box right onto dock
    outcome = soko_session.apply_action("RIGHT")
    assert box.position.x == 4
    assert soko_session.state.won is True
    assert "solved" in outcome.message.lower()


def test_playable_session_legend_and_display(tmp_path):
    """Verify control legend generation, entity symbol discovery, and full render display."""
    session = PlayableSession.from_name_or_canonical("pac-man", mode="original", state_dir=str(tmp_path))
    legend = session.get_legend()

    assert "title" in legend
    assert "controls" in legend
    assert "symbols" in legend
    assert "summary" in legend

    # Symbols present in Pac-Man should include player, wall, coin/dock
    assert "@" in legend["symbols"]
    assert "#" in legend["symbols"]

    # Verify ASCII formatted banner has safe borders
    legend_banner = session.format_legend_text()
    assert "+--------------------------------------------------------+" in legend_banner
    assert "ACTIVE PLAY MODE -- CONTROL LEGEND" in legend_banner
    assert "@  : Player" in legend_banner

    # Verify full display
    full_disp = session.render_full_display()
    assert "Game: Pac-Man (ORIGINAL)" in full_disp
    assert "Score:" in full_disp
    assert "Message:" in full_disp
    assert "@" in full_disp


def test_action_centre_interactive_game_play_gui(tmp_path):
    """Verify ActionCentre GUI play mode activation, controls, and session lifetime."""
    centre = ActionCentre(tmp_path / "state", root_dir=Path("."))

    # Wire dummy UI elements
    centre.lbl_game_title = DummyWidget()
    centre.lbl_game_score = DummyWidget()
    centre.lbl_game_outcome = DummyWidget()
    centre.game_ascii_display = DummyWidget()
    centre.btn_play_game = DummyWidget("🎮 Play")
    centre.game_controls_legend_frame = DummyWidget()
    centre.lbl_legend_title = DummyWidget()
    centre.lbl_legend_symbols = DummyWidget()
    centre.game_select_var = DummyWidget("pac-man")

    assert centre._game_play_active is False
    assert centre._active_session is None

    # 1. Start interactive session
    res = centre.start_interactive_game_action("pac-man", mode="original")
    assert res["status"] == "playing"
    assert centre._game_play_active is True
    assert centre._active_session is not None
    assert centre.btn_play_game.text == "⏹ Stop Play"
    assert centre.game_controls_legend_frame.is_packed is True
    assert "Pac-Man" in centre.lbl_game_title.text
    assert "@" in centre.game_ascii_display.text

    # 2. Send directional inputs
    step_res = centre.send_game_input("RIGHT")
    assert step_res["action"] == "RIGHT"
    assert step_res["steps"] == 1
    assert "Moved" in step_res["message"]

    # 3. Reset level
    centre.reset_current_game()
    assert centre._active_session.steps == 0
    assert "restarted" in centre.lbl_game_outcome.text.lower()

    # 4. Eye step
    eye_res = centre.eye_step_game_action()
    assert eye_res["action"] == "eye"
    assert eye_res["steps"] == 1

    # 5. Stop play mode
    centre.stop_interactive_game_action()
    assert centre._game_play_active is False
    assert centre._active_session is None
    assert centre.btn_play_game.text == "🎮 Play"
    assert centre.game_controls_legend_frame.is_packed is False


def test_keyboard_event_dispatch_focus_protection(tmp_path):
    """Verify keyboard input routing respects text input focus and escape handling."""
    centre = ActionCentre(tmp_path / "state", root_dir=Path("."))
    centre.lbl_game_title = DummyWidget()
    centre.lbl_game_score = DummyWidget()
    centre.lbl_game_outcome = DummyWidget()
    centre.game_ascii_display = DummyWidget()
    centre.btn_play_game = DummyWidget("🎮 Play")
    centre.game_controls_legend_frame = DummyWidget()
    centre.lbl_legend_title = DummyWidget()
    centre.lbl_legend_symbols = DummyWidget()

    # Simulate active chat entry focus
    dummy_chat_entry = DummyWidget()
    centre.said = dummy_chat_entry

    class DummyRoot:
        def __init__(self, focused):
            self._focused = focused
        def focus_get(self):
            return self._focused

    centre.root = DummyRoot(dummy_chat_entry)

    # Start interactive game
    centre.start_interactive_game_action("pac-man", mode="original")
    assert centre._game_play_active is True

    # When user is focused in chat entry, game navigation MUST NOT intercept
    assert centre._is_text_entry_focused() is True
    nav_ret = centre._on_game_nav_key("UP")
    assert nav_ret is None  # Not intercepted

    gen_ret = centre._on_game_general_key(DummyEvent(char="w"))
    assert gen_ret is None  # Not intercepted

    # Now simulate focus moving to the game panel or neutral area
    dummy_game_widget = DummyWidget()
    centre.root = DummyRoot(dummy_game_widget)
    assert centre._is_text_entry_focused() is False

    # Key press SHOULD be intercepted and consume event
    assert centre._on_game_nav_key("UP") == "break"
    assert centre._on_game_general_key(DummyEvent(char="s")) == "break"
    assert centre._on_game_general_key(DummyEvent(keysym="space")) == "break"
    assert centre._on_game_general_key(DummyEvent(char="r")) == "break"

    # Escape stops active game
    esc_ret = centre._on_escape()
    assert esc_ret == "break"
    assert centre._game_play_active is False


def test_standalone_play_cli_runner(tmp_path):
    """Verify the standalone terminal game runner executes non-interactive move sequences."""
    session = run_terminal_game("pac-man", mode="original", moves=["right", "right", "wait"],
                                state_dir=str(tmp_path))
    assert session.steps == 3
    assert session.game_name == "Pac-Man"
    assert session.history[0].action == "RIGHT"
    assert session.history[2].action == "WAIT"


def test_open_games_action_toggle(tmp_path):
    """Verify open_games_action opens, switches to, and toggles the Game Arena in the Right Deck."""
    centre = ActionCentre(tmp_path / "state", root_dir=Path("."))
    centre.right_container = DummyWidget()
    centre.confirm_panel = DummyWidget()
    centre.game_panel = DummyWidget()

    # 1. Closed -> Open Game Arena
    assert centre.right_container.is_packed is False
    centre.open_games_action()
    assert centre.right_container.is_packed is True
    assert getattr(centre, "right_view_mode", "") == "games"

    # 2. Open but in another mode -> Switch to Game Arena
    centre._switch_right_view("confirmations")
    assert getattr(centre, "right_view_mode", "") == "confirmations"
    centre.open_games_action()
    assert centre.right_container.is_packed is True
    assert getattr(centre, "right_view_mode", "") == "games"

    # 3. Already open in games mode -> Toggle closed
    centre.open_games_action()
    assert centre.right_container.is_packed is False

