# WARP2/warp2/ask/tests/test_each_round_part_says_its_memory.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_each_round_part_says_its_memory.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/picture_round.py (PictureRound.step, _part_memory),
#              warp2/work/side/asked.py (_memory_words), warp2/work/memory_floor.py.
#  Description:
#    That every picture round part reports this process's private memory at
#    its start and end, the growth, and how many pictures it took off the
#    teach queue, under the same part name every round; and that the part's
#    line in the thread says it.
#  User intention (Andrew, 2026-10-16: give the picture maker a memory limit;
#    standing memory investigation). Measured 2026-10-26 10:52 UTC: the runner
#    at 52 GB private with no part to blame (BUILD_LOG 698, muse-621/624).
# ============================================================================
from __future__ import annotations

from warp2.ask import picture_round
from warp2.work import memory_floor
from warp2.work.side.asked import _memory_words


class Learning:
    """Intention: a stand-in VisualLearning; the part under test is replaced, so nothing of it is read."""


def test_a_part_reports_start_end_growth_and_pictures(monkeypatch):
    """Intention: a teach-like part that takes two pictures and grows 300 MB says exactly that."""
    readings = iter([2000, 2300])
    monkeypatch.setattr(picture_round, "_private_mb", lambda: next(readings))
    monkeypatch.setattr(memory_floor, "_free_now", lambda: 64 * 2 ** 30)
    monkeypatch.setattr(picture_round, "_retire_extras_once", lambda learning, state: None)

    def concepts(self, state):
        """Intention: the part takes two pictures off the queue, as teach does."""
        state["queue"] = state["queue"][2:]
        state["part"] = "weigh"
        return {"said": "ran"}

    monkeypatch.setattr(picture_round.PictureRound, "_concepts", concepts)
    state = picture_round.start("cat", 1)
    state["queue"] = [{"id": 1}, {"id": 2}, {"id": 3}]
    state, report, _ = picture_round.PictureRound(Learning()).step(state)
    memory = report["memory"]
    assert report["part"] == "concepts" and report["part"] in picture_round.PARTS
    assert (memory["start_mb"], memory["end_mb"], memory["growth_mb"], memory["pictures_taken"]) == (2000, 2300, 300, 2)
    assert isinstance(memory["pid"], int)


def test_unknown_memory_stays_unknown():
    """Intention: a platform that cannot say gives None growth, never a made-up number, and the line says nothing."""
    memory = picture_round._part_memory(None, None, 0, 4)
    assert memory["growth_mb"] is None and memory["pictures_taken"] == 0
    assert _memory_words(memory) == ""


def test_the_line_says_the_memory():
    """Intention: the thread line carries start, end, growth and pictures taken."""
    words = _memory_words({"start_mb": 2000, "end_mb": 2300, "growth_mb": 300, "pictures_taken": 2, "pid": 7})
    assert "2000 → 2300 MB (+300 MB)" in words and "2 picture(s) taken" in words


def test_the_real_reading_is_a_number_or_none():
    """Intention: the real reading never raises."""
    value = picture_round._private_mb()
    assert value is None or isinstance(value, int)
