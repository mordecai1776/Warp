# WARP2/warp2/ask/tests/test_new_chat_and_features.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_new_chat_and_features.py
#  Used by   : pytest.
#  Uses      : warp2/ask/{window,thread}.py.
#  Description:
#    Verifies that starting a new conversation clears out the old transcript,
#    archives past turns, and renders empty starter cards without being blocked.
#  User intention (Andrew, 2026-09-08):
#    "when I make a new conversation it should clear out the old look online for
#     features for systems like this and add any that seem like they fit"
# ============================================================================
from __future__ import annotations

import os
import tkinter as tk
from pathlib import Path
import pytest

from warp2.ask.thread import Thread, ANDREW, WARP
from warp2.ask.window import ActionCentre, colours


def test_thread_reset_archives_and_clears_file(tmp_path):
    """Calling Thread.reset() archives existing turns and leaves a 0-byte file."""
    state = tmp_path / "state"
    thread = Thread(state)
    assert thread.path.name == "talking.jsonl"

    # 1. Reset on empty thread
    res0 = thread.reset()
    assert res0["turns"] == 0
    assert thread.path.is_file()
    assert thread.path.read_text(encoding="utf-8") == ""

    # 2. Add turns
    thread.add(ANDREW, "hello warp")
    thread.add(WARP, "hello Andrew")
    assert len(thread.recent()) == 2

    # 3. Reset with turns archives to archive/ folder and wipes talking.jsonl
    res1 = thread.reset()
    assert res1["turns"] == 2
    assert Path(res1["archived"]).is_file()
    assert thread.path.read_text(encoding="utf-8") == ""
    assert len(thread.recent()) == 0

    # 4. List archives shows the saved conversation
    archives = thread.list_archives()
    assert len(archives) == 1
    assert "hello warp" in archives[0]["title"]


def test_thread_markdown_export(tmp_path):
    """Thread.export_markdown() formats turns into clean markdown."""
    state = tmp_path / "state"
    thread = Thread(state)
    thread.add(ANDREW, "make a picture of a mountain", grounds="chat prompt")
    thread.add(WARP, "Here is the mountain", image="test_img.png")

    md = thread.export_markdown()
    assert "# WARP2 Conversation Export" in md
    assert "You (Andrew)" in md
    assert "make a picture of a mountain" in md
    assert "WARP" in md
    assert "Here is the mountain" in md
    assert "Grounds:" in md
    assert "Generated Image:" in md



def test_action_centre_reset_unconditional_clearing(tmp_path, tk_root):
    """ActionCentre.reset() clears out old conversation even when busy flag was set."""
    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.thread.add(ANDREW, "previous turn")
    centre.thread.add(WARP, "previous answer")

    centre.build(tk, tk_root, colours())
    centre.refresh()

    # Simulate that an operation was busy
    centre._busy = True

    # Calling reset MUST succeed and wipe paper unconditionally
    res = centre.reset()
    assert res["turns"] == 2
    assert centre._busy is False
    assert centre.thread.path.read_text(encoding="utf-8") == ""
    assert len(centre.thread.recent()) == 0

    # Paper should not contain old text and should have starter cards window embedded
    paper_text = centre.paper.get("1.0", "end")
    assert "previous turn" not in paper_text
    assert len(centre.paper.window_names()) > 0


def test_action_centre_send_reset_bypasses_busy(tmp_path, tk_root):
    """Typing /reset in the input box executes immediately even if _busy is True."""
    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.thread.add(ANDREW, "active turn 1")

    centre.build(tk, tk_root, colours())
    centre.refresh()
    centre._busy = True

    centre.said.insert("1.0", "/reset")
    res = centre.send()

    assert res.get("turns") == 1
    assert centre._busy is False
    assert len(centre.thread.recent()) == 0


def test_action_centre_starter_cards_interaction(tmp_path, tk_root):
    """Empty conversation displays starter cards that populate said entry upon click."""
    state = tmp_path / "state"
    centre = ActionCentre(state)

    centre.build(tk, tk_root, colours())
    centre.refresh()

    # Starter cards container is embedded in paper
    assert len(centre.paper.window_names()) > 0

    # Verify applying prompt updates said box
    centre.said.delete("1.0", "end")
    centre.said.insert("1.0", "Generate an image of ")
    assert "Generate an image of " in centre.said.get("1.0", "end")


def test_action_centre_search_filter(tmp_path, tk_root):
    """Past conversations list filters dynamically based on search entry text."""
    state = tmp_path / "state"
    centre = ActionCentre(state)

    # Create two archives
    centre.thread.add(ANDREW, "apple project design")
    centre.reset()

    centre.thread.add(ANDREW, "banana visual model")
    centre.reset()

    centre.build(tk, tk_root, colours())

    # With default placeholder, all archives show
    assert len(centre.thread.list_archives()) == 2

    # Filter by 'banana'
    centre.search_entry.delete(0, "end")
    centre.search_entry.insert(0, "banana")
    centre._refresh_chats_list()

    # Children in chats_frame should include '● Current Chat' + matching archive
    children = centre.chats_frame.winfo_children()
    assert len(children) >= 2


def test_confirm_and_store_image_workflow(tmp_path):
    """confirm_and_store_image marks attempt approved in VisualLearning and records to catalog."""
    from PIL import Image as PILImage
    from warp2.ask.media import confirm_and_store_image
    from warp2.ask.visual import VisualLearning

    root_dir = tmp_path / "root"
    state_dir = tmp_path / "state"
    root_dir.mkdir(parents=True)
    state_dir.mkdir(parents=True)

    # Create dummy image
    img_dir = tmp_path / "work"
    img_dir.mkdir(parents=True)
    img_path = img_dir / "test_apple.png"
    PILImage.new("RGB", (32, 32), color="red").save(img_path)

    learning = VisualLearning(root_dir, state_dir)
    assert not learning.approved(img_path)

    res = confirm_and_store_image(root_dir, state_dir, img_path, train=False)
    assert res.get("status") == "stored"
    assert learning.approved(img_path)

    # Stored image file copied to state/images
    gallery_img = state_dir / "images" / img_path.name
    assert gallery_img.is_file()


def test_action_centre_confirm_image_action_dismisses_buttons(tmp_path, tk_root):
    """_confirm_image_action replaces action buttons with '✓ Stored to Gallery' badge."""
    from PIL import Image as PILImage
    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    # Create test image
    img_path = tmp_path / "art.png"
    PILImage.new("RGB", (32, 32), color="blue").save(img_path)

    # Create button bar with confirm button
    bar = tk.Frame(centre.paper)
    btn_confirm = tk.Button(bar, text="👍 Confirm & Store")
    btn_confirm.pack(side="left")
    btn_retrain = tk.Button(bar, text="👎 Retrain")
    btn_retrain.pack(side="left")

    res = centre._confirm_image_action(img_path, button_bar=bar)
    assert res.get("status") == "stored"

    # Buttons should be destroyed and replaced by '✓ Stored to Gallery' label
    child_texts = [w.cget("text") for w in bar.winfo_children() if hasattr(w, "cget")]
    assert "👍 Confirm & Store" not in child_texts
    assert "👎 Retrain" not in child_texts
    assert "✓ Stored to Gallery" in child_texts


def test_action_centre_confirm_reference_dismisses_buttons(tmp_path, tk_root):
    """_confirm_reference replaces review buttons with '✓ Stored' status badge."""
    from PIL import Image as PILImage
    import hashlib
    from warp2.ask.visual import VisualLearning

    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    ref_path = tmp_path / "ref.png"
    PILImage.new("RGB", (32, 32), color="green").save(ref_path)
    ref_bytes = ref_path.read_bytes()
    digest = hashlib.sha256(ref_bytes).hexdigest()
    subject = "tree"
    ident = hashlib.sha256((subject + digest).encode()).hexdigest()

    # Pre-populate reference in VisualLearning
    learning = VisualLearning(centre.root_dir, centre.state)
    data = learning._load()
    data["references"][ident] = dict(
        id=ident, subject=subject, path=str(ref_path),
        digest=digest, status="pending", source={}, weight=1.0
    )
    learning._save(data)

    bar = tk.Frame(centre.paper)
    btn_confirm = tk.Button(bar, text="✓ Confirm for tree")
    btn_confirm.pack(side="left")
    btn_reject = tk.Button(bar, text="✕ Reject")
    btn_reject.pack(side="left")

    review = {"id": ident, "subject": subject, "path": str(ref_path)}
    # Call without blocking
    centre._confirm_reference(review, accepted=True, button_bar=bar)

    child_texts = [w.cget("text") for w in bar.winfo_children() if hasattr(w, "cget")]
    assert "✓ Confirm for tree" not in child_texts
    assert "✕ Reject" not in child_texts
    assert "✓ Stored — added to training" in child_texts or "✓ Stored — Training model..." in child_texts


def test_action_centre_settled_references_go_away(tmp_path, tk_root):
    """References already confirmed or rejected are filtered out of turn display."""
    from PIL import Image as PILImage
    import hashlib
    from warp2.ask.visual import VisualLearning

    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    ref_path = tmp_path / "flower.png"
    PILImage.new("RGB", (32, 32), color="yellow").save(ref_path)
    ref_bytes = ref_path.read_bytes()
    digest = hashlib.sha256(ref_bytes).hexdigest()
    subject = "flower"
    ident = hashlib.sha256((subject + digest).encode()).hexdigest()

    # Mark as confirmed in VisualLearning
    learning = VisualLearning(centre.root_dir, centre.state)
    data = learning._load()
    data["references"][ident] = dict(
        id=ident, subject=subject, path=str(ref_path.resolve()),
        digest=digest, status="confirmed", source={}, weight=3.0
    )
    learning._save(data)

    # Turn contains references
    turn = {
        "who": WARP,
        "said": "Candidate flower",
        "subject": "flower",
        "references": [str(ref_path)],
        "reference_reviews": [{"id": ident, "subject": subject, "path": str(ref_path)}],
    }

    centre.paper.configure(state="normal")
    centre.paper.delete("1.0", "end")
    centre._render_turn(turn)
    paper_text = centre.paper.get("1.0", "end")

    # The confirmed reference should not show "Reference Candidate" in paper
    assert "Reference Candidate" not in paper_text


def test_insert_image_no_withholding(tmp_path, tk_root):
    """Generated images are displayed immediately with Confirm & Store button rather than withheld."""
    from PIL import Image as PILImage
    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    img_path = tmp_path / "generated_sun.png"
    PILImage.new("RGB", (32, 32), color="orange").save(img_path)

    centre.paper.configure(state="normal")
    centre.paper.delete("1.0", "end")
    centre._insert_image(img_path, is_reference=False)
    paper_text = centre.paper.get("1.0", "end")

    # Withholding message MUST NOT appear
    assert "Attempt withheld" not in paper_text
    assert "[generated_sun.png]" in paper_text
    # Action bar window is embedded
    assert len(centre.paper.window_names()) > 0
