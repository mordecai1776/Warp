# WARP2/warp2/ask/tests/test_the_window.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_the_window.py
#  Used by   : pytest.
#  Uses      : warp2/ask/window.py, warp2/ask/quiet.py, warp2/models/fleet.py.
#  Description:
#    The window comes up, and stays up whatever it cannot reach.
#  User intention (Andrew, 2026-09-07):
#    "I ran the bat and so far no user window."
#    "The image should say what it is trying to make and look for more suporting images each time it retrains"
#    "It should also always say what it is trying to make"
#    "It should also show refrence images that it finds to varifay what the image is"
# ============================================================================
from __future__ import annotations

from pathlib import Path


import pytest


@pytest.fixture(autouse=True)
def local_reference_search(monkeypatch, tmp_path):
    """Exercise media wiring with known image bytes, independent of web latency."""
    from PIL import Image
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[3] / "projects" / "centering_image"))
    from image_search import CommonsSearch, WikipediaSearch, OpenverseSearch, MultiSourceSearch
    def fetch(self, tag, destination):
        """Supply a labelled test fixture rather than querying a public service."""
        destination = Path(destination)
        destination.mkdir(parents=True, exist_ok=True)
        path = destination / "test_reference.png"
        Image.new("RGB", (48, 48), (40, 160, 70)).save(path)
        q = tag.get("name", "fixture") if isinstance(tag, dict) else str(tag)
        return [{"image_path": str(path), "title": "test fixture", "query": q, "source": "test"}]
    monkeypatch.setattr(CommonsSearch, "fetch", fetch)
    monkeypatch.setattr(WikipediaSearch, "fetch", fetch)
    monkeypatch.setattr(OpenverseSearch, "fetch", fetch)
    monkeypatch.setattr(MultiSourceSearch, "fetch", fetch)

def test_the_window_is_drawn_before_anything_is_looked_up(tmp_path):
    """"I ran the bat and so far no user window."

    Intention: it used to open the store and assemble a fleet BEFORE drawing a
    pixel, and the launcher starts it at the same instant it starts the loop,
    which opens the same store. Anything slow or refused in there meant no
    window at all. The launcher now uses a windowless Python for GUI surfaces;
    restart failures go to a persistent diagnostic file, not a flash console.
    """
    from warp2.ask.window import ActionCentre

    centre = ActionCentre(tmp_path / "state")
    assert centre.talk is None, "it holds nothing it had to go and find"


def test_a_store_it_cannot_reach_is_a_sentence_not_a_dead_window(tmp_path):
    from warp2.ask.window import ActionCentre

    centre = ActionCentre(tmp_path / "state")

    def explodes(*_args, **_kwargs):
        raise OSError("database is locked")

    import warp2.ask.window as window
    was, window.assemble = window.assemble, explodes
    try:
        said = centre.wake(".", tmp_path / "state")
    finally:
        window.assemble = was

    assert "database is locked" in said
    assert centre.talk is None
    # And he can read it in the window, and still type.
    turns = centre.thread.recent()
    assert any("cannot reach what I know" in (turn.get("said") or "") for turn in turns)


def test_waking_twice_does_not_look_twice(tmp_path):
    from warp2.ask.window import ActionCentre

    centre = ActionCentre(tmp_path / "state")
    centre.talk = object()
    assert centre.wake(".", tmp_path / "state") == ""


def test_the_window_can_find_a_model_and_still_writes_nothing(tmp_path):
    """THE MODEL THE WINDOW COULD NEVER HAVE.

    Intention: `_a_model` handed the fleet `TagNet(None)` to keep the window
    from writing. `Fleet.enlist` states two facts about every model it takes
    on, so the first one raised AttributeError on the None, a broad `except`
    swallowed it, and this returned None on every machine, every time. The rule
    was right and the way it was kept made the feature impossible.
    """
    from warp2.ask.quiet import Quiet
    from warp2.models.fleet import Fleet
    from warp2.store.store import Store
    from warp2.store.tagnet import TagNet

    store = Store(tmp_path / "state")
    before = len(store.current(relation="has"))
    fleet = Fleet(TagNet(Quiet(store)))
    fleet.enlist("a-model", lambda prompt: "hello", kinds=("build",))

    assert fleet.names() == ["a-model"], "it is actually enlisted"
    assert fleet.choose("build") == "a-model"
    assert len(store.current(relation="has")) == before, "and nothing was written"


def test_a_quiet_store_answers_questions_and_forgets_writes(tmp_path):
    from warp2.ask.quiet import Quiet
    from warp2.store.store import Store

    store = Store(tmp_path / "state")
    store.assert_fact("thing:one", "has", attr="colour", value="blue")
    quiet = Quiet(store)

    assert quiet.current(subject="thing:one")[0]["value"] == "blue"
    quiet.assert_fact("thing:one", "has", attr="colour", value="red")
    assert quiet.dropped == 1
    assert store.current(subject="thing:one")[0]["value"] == "blue"


def test_conversational_approval_and_refusal(tmp_path):
    """Typing 'yes' or 'no' when a proposal is active directly acts on it."""
    from warp2.ask.window import ActionCentre
    centre = ActionCentre(tmp_path / "state")

    class FakeEntry:
        def __init__(self, text=""):
            self.text = text
        def get(self, *args):
            return self.text
        def delete(self, *args):
            self.text = ""

    # Set up pending proposal
    centre.proposal = {"kind": "project", "words": "explore audio", "about": "sound_lab", "why": "testing"}
    centre.said = FakeEntry("yes")

    res = centre.send()
    assert res.get("id"), "accepted the proposal and put it in inbox"
    assert centre.proposal is None

    # Test refusal
    centre.proposal = {"kind": "project", "words": "explore video", "about": "video_lab", "why": "testing"}
    centre.said = FakeEntry("no")

    res = centre.send()
    assert res.get("words") == "explore video"
    assert centre.proposal is None
    recent = centre.thread.recent()
    assert recent[-1]["said"] == "no"
    assert recent[-1].get("refused") == "explore video"


def test_media_generation_actions(tmp_path):
    """Buttons for image and video generation add them to the work."""
    from warp2.ask.window import ActionCentre
    centre = ActionCentre(tmp_path / "state", root_dir=Path("."))

    class FakeEntry:
        def __init__(self, text=""):
            self.text = text
        def get(self, *args):
            return self.text
        def delete(self, *args):
            self.text = ""

    centre.said = FakeEntry("circle")
    img_res = centre.generate_image_action()
    assert img_res["status"] == "pending", "the picture is added to the work, not made here"

    # Intention (2026-10-09, fix 3.7, check B10): a video is added to the work
    # like a picture; the loop makes it (warp2/work/side/asked.py).
    centre.said = FakeEntry("moving circle")
    vid_res = centre.generate_video_action()
    assert vid_res["status"] == "asked" and vid_res["kind"] == "video", "the video is added to the work, not made here"


def test_project_selection_and_archive_browsing(tmp_path):
    """Selecting projects focuses session; past archives load cleanly."""
    from warp2.ask.window import ActionCentre
    centre = ActionCentre(tmp_path / "state", root_dir=Path("."))
    centre.thread.add("you", "hello previous session")
    centre.thread.add("warp", "hello there")

    # Archive this conversation
    reset_res = centre.reset()
    assert reset_res["turns"] >= 2
    assert Path(reset_res["archived"]).is_file()

    # Past archives list
    archives = centre.thread.list_archives()
    assert len(archives) >= 1
    arch_path = archives[0]["path"]

    # Load and view archive
    loaded = centre.show_archive(arch_path)
    assert len(loaded) >= 2
    assert centre.viewing_archive == arch_path

    # Return to active chat
    centre.show_active_chat()
    assert centre.viewing_archive == ""

    # Test project selection
    centre.said = None
    centre.select_project("single_point_of_truth")
    assert centre.active_project == "single_point_of_truth"


def test_conversation_archive_deletion_and_clearing(tmp_path):
    """User can delete past conversation archives and clear active chat.

    User intention (Andrew, 2026-09-07):
    "just have a way to delete conversations."
    """
    from warp2.ask.window import ActionCentre

    centre = ActionCentre(tmp_path / "state", root_dir=Path("."))
    centre.thread.add("you", "turn to archive")
    centre.thread.add("warp", "reply to archive")

    # Reset auto-archives
    arch_res = centre.reset()
    arch_path = arch_res["archived"]
    assert Path(arch_path).is_file()

    # Deleting archive deletes file from disk
    centre.delete_archive_action(arch_path)
    assert not Path(arch_path).is_file()
    assert len(centre.thread.list_archives()) == 0

    # Test clear_current_chat
    centre.thread.add("you", "turn to discard")
    assert len(centre.thread.recent()) == 1
    centre.clear_current_chat()
    assert len(centre.thread.recent()) == 0


def test_direct_media_command_in_chat_without_confirmation(tmp_path):
    """Direct media instructions go straight into the work without stalling on yes/no.

    User intention (Andrew, 2026-09-07):
    "make an image of something form the real workld you know."
    """
    from warp2.ask.window import ActionCentre
    from warp2.ask.media import list_created_images

    centre = ActionCentre(tmp_path / "state", root_dir=Path("."))

    class FakeEntry:
        def __init__(self, text=""):
            self.text = text
        def get(self, *args):
            return self.text
        def delete(self, *args):
            self.text = ""

    centre.said = FakeEntry("make an image of a red apple")
    centre.send()
    assert centre.proposal is None, "did not stall with a proposal"
    recent = centre.thread.recent()
    assert any("Added a picture of" in t.get("said", "") for t in recent), \
        "the picture is added to the work (2026-09-18); the loop makes it"
    from warp2.ask.inbox import Inbox
    assert [w["kind"] for w in Inbox(tmp_path / "state").waiting()] == ["image"]

    # Nothing is made in the window, so nothing is catalogued yet.
    assert list_created_images(tmp_path / "state") == []


def test_image_training_feedback_and_checkpointing(tmp_path):
    """Interactive feedback trains the Eye model and persists weights.

    User intention (Andrew, 2026-09-07):
    "we need to have a evolveing system of what it can and cant do... make some more things to support created images."
    """
    from warp2.ask.media import IMAGE_CHECKPOINT, make_project_image, train_on_image

    img_res = make_project_image(Path("."), tmp_path / "state", "green tree")
    img_path = img_res["image_path"]
    assert Path(img_path).is_file()

    # Train with positive feedback
    train_res = train_on_image(Path("."), tmp_path / "state", img_path, score=1.0)
    assert "error" not in train_res
    assert train_res.get("saved") is True
    ckpt = tmp_path / "state" / "models" / IMAGE_CHECKPOINT
    assert ckpt.is_file(), "checkpoint was saved"


def test_downvote_adds_feedback_and_a_retry_to_the_work(tmp_path, monkeypatch):
    """Downvoting learns and tries again — through the work, not at the click.

    User intention (Andrew, 2026-09-07, 2026-09-17, 2026-09-18):
    "If I down vote an image it should train on more data and try again"
    "It should also just add to something and not trigger a training at the moment I click the buttons."
    """
    import warp2.ask.media as media
    from warp2.ask.inbox import Inbox
    from warp2.ask.window import ActionCentre
    monkeypatch.setattr(media, "train_on_image", lambda *a, **k: pytest.fail("trained at the click"))
    monkeypatch.setattr(media, "make_project_image", lambda *a, **k: pytest.fail("made at the click"))

    state = tmp_path / "state"
    picture = state / "images" / "banana_attempt_1.png"
    picture.parent.mkdir(parents=True)
    picture.write_bytes(b"png")
    media.record_image_catalog(state, {"image_path": str(picture), "subject": "yellow banana"})
    centre = ActionCentre(state, root_dir=Path("."))

    res = centre._downvote_and_retry(picture)
    assert res["status"] == "downvoted" and res["asked_again"]
    waiting = {w["kind"]: w for w in Inbox(state).waiting()}
    assert waiting["feedback"]["score"] == -1.0 and waiting["feedback"]["path"] == str(picture)
    assert waiting["image"]["said"] == "yellow banana"


def test_make_project_image_proactively_trains_and_persists(tmp_path):
    """make_project_image automatically and proactively trains on reference data and persists weights.

    User intention (Andrew, 2026-09-07):
    "it should do it automaticaly it should always be proactive like that"
    """
    from warp2.ask.media import IMAGE_CHECKPOINT, make_project_image

    state_dir = tmp_path / "state"
    res = make_project_image(Path("."), state_dir, "red apple")
    assert "image_path" in res
    assert Path(res["image_path"]).is_file()
    assert res.get("proactive") is True
    # Intention (2026-10-09, fix 3.1, check B8): `updates` is what was really
    # trained — it was set to at least 1 when nothing was. Here no reader can
    # pass anything (no internet, no vision model), so nothing is taught.
    assert isinstance(res.get("updates"), int) and res["updates"] >= 0
    ckpt = state_dir / "models" / IMAGE_CHECKPOINT
    assert ckpt.is_file(), "model weights checkpoint was saved proactively"


def test_multi_reference_images_and_gallery_rendering(tmp_path):
    """Multiple reference images are collected, returned, and rendered to verify subjects.

    User intention (Andrew, 2026-09-07):
    "It should also show refrence images that it finds to varifay what the image is"
    """
    from PIL import Image
    from warp2.ask.window import ActionCentre
    from warp2.ask.media import make_project_image

    state_dir = tmp_path / "state"
    res = make_project_image(Path("."), state_dir, "green leaf")
    assert "image_path" in res
    assert "references" in res
    assert isinstance(res["references"], list)

    centre = ActionCentre(state_dir, root_dir=Path("."))

    # Create dummy reference images to simulate multiple supporting references
    ref_dir = state_dir / "images" / "references"
    ref_dir.mkdir(parents=True, exist_ok=True)
    ref1 = ref_dir / "ref1.png"
    ref2 = ref_dir / "ref2.png"
    Image.new("RGB", (64, 64), color=(0, 200, 0)).save(ref1)
    Image.new("RGB", (64, 64), color=(0, 150, 0)).save(ref2)

    turn = {
        "who": "warp",
        "said": "Generated picture of 'green leaf'",
        "subject": "green leaf",
        "attempt": 1,
        "image": res["image_path"],
        "references": [str(ref1), str(ref2)],
    }
    centre.thread.add(**turn)

    recent = centre.thread.recent()
    assert len(recent) >= 1
    stored_turn = recent[-1]
    assert len(stored_turn.get("references", [])) == 2


def test_worker_updates_widgets_only_on_ui_thread(tmp_path):
    """A real worker must never touch Tk, including its scheduling methods."""
    import threading
    from warp2.ask.window import ActionCentre
    centre = ActionCentre(tmp_path / "state")
    owner = threading.get_ident()
    calls = []
    class Root:
        """Fail if a worker uses Tk to schedule its own update."""
        def after(self, *args):
            assert threading.get_ident() == owner
    class Note:
        """Stand in for a thread-affine Tk label."""
        def configure(self, **kwargs):
            assert threading.get_ident() == owner
            calls.append(kwargs["text"])
        def update_idletasks(self):
            assert threading.get_ident() == owner
    centre.root, centre.note = Root(), Note()
    worker = threading.Thread(target=lambda: centre._say("finished"))
    worker.start()
    worker.join(2)
    assert not worker.is_alive()
    assert calls == []
    centre._drain_ui()
    assert calls == ["finished"]


def test_chat_returns_while_model_is_waiting_and_reuses_worker(tmp_path):
    """Typing remains responsive and SQLite owners stay on the same worker."""
    import threading
    from warp2.ask.window import ActionCentre
    entered, release, finished = threading.Event(), threading.Event(), threading.Event()
    owners = []
    class Talk:
        """Hold inference until the test releases it."""
        def reply(self, *args):
            owners.append(threading.get_ident())
            entered.set()
            assert release.wait(3)
            return {"said": "a real reply"}
    class Entry:
        """Keep pending text available if another operation is busy."""
        def get(self, *args):
            return "hello"
        def delete(self, *args):
            pass
    centre = ActionCentre(tmp_path / "state", talk=Talk())
    centre.root, centre.said = object(), Entry()
    try:
        assert centre.send()["status"] == "working in background"
        assert entered.wait(2)
        assert centre._busy
        assert centre.send()["status"] == "busy"
    finally:
        release.set()
    centre._background(lambda: (owners.append(threading.get_ident()), finished.set()))
    assert finished.wait(3)
    assert owners[0] == owners[1] != threading.get_ident()
    assert any(t["said"] == "a real reply" for t in centre.thread.recent())


def test_background_failure_releases_guard_and_reports_error(tmp_path):
    """Unexpected failures must leave the window usable and explain the failure."""
    from warp2.ask.window import ActionCentre
    centre = ActionCentre(tmp_path / "state")
    messages = []
    centre._say = messages.append
    centre._busy = True
    def fail():
        """Simulate a failed network or model operation."""
        raise OSError("reader unavailable")
    centre._background(fail)
    assert not centre._busy
    assert "reader unavailable" in messages[-1]


def test_action_centre_reads_the_workers_canonical_store(tmp_path, monkeypatch):
    """Chat and the worker must report the same projects and queue."""
    from warp2.run import build
    from warp2.ask import window
    root = tmp_path / "tree"
    root.mkdir()
    state = root / "state"
    machine = build(root, state)
    machine.projects.open("Shared Project", intention="share real work with chat")
    monkeypatch.setattr(window, "_a_model", lambda *args: None)
    talk = window.assemble(root, state)
    report = talk.knowing.overview()
    assert [p["name"] for p in report["projects"]] == ["Shared Project"]
    assert talk.knowing.store.state == machine.store.state
    assert report["open_work"] == len(machine.queue.open_items())
