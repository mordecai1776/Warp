# WARP2/warp2/ask/tests/test_asking_for_things.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_asking_for_things.py
#  Used by   : pytest.
#  Uses      : warp2/ask/inbox.py, warp2/ask/taking.py, warp2/ask/window.py.
#  Description:
#    The four things a person can ask for, what each one becomes, and that
#    asking survives the window being closed.
#  User intention (Andrew, 2026-09-07):
#    "Where I can ask for an image to be made or a project to be started or
#    comment on one and have changes made. I should also be able to drop in
#    files or images to it."
# ============================================================================
from __future__ import annotations

import json

import pytest

from warp2.ask.inbox import COMMENT, FILE, IMAGE, PROJECT, Inbox
from warp2.ask.taking import SAID, TAKES, Taking
from warp2.store.projects import Projects
from warp2.store.questions import Questions
from warp2.store.store import Store
from warp2.work.queue import WorkQueue


def _world(tmp_path):
    state = tmp_path / "state"
    root = tmp_path / "tree"
    root.mkdir()
    store = Store(state / "store", run="ask", view_path=tmp_path / "view.sqlite3")
    projects = Projects(store, root)
    taking = Taking(store, projects, Questions(store), WorkQueue(store), state)
    return store, projects, taking, state, root


def test_what_was_asked_for_outlives_the_window(tmp_path):
    """Intention: a person types something and shuts the laptop. The asking has
    to outlive the window it was typed into, and be readable by a loop that
    starts hours later knowing nothing."""
    box = Inbox(tmp_path / "state")
    made = box.put(IMAGE, said="a red apple on a table")
    assert (tmp_path / "state" / "asked" / f"{made['id']}.json").is_file()
    # a completely new Inbox, as a later run would build
    assert [row["said"] for row in Inbox(tmp_path / "state").waiting()] \
        == ["a red apple on a table"]


def test_a_kind_nothing_can_take_is_refused_at_the_door(tmp_path):
    """Intention: a request nothing knows how to take is worse than no request —
    it sits in the folder looking answered."""
    box = Inbox(tmp_path / "state")
    with pytest.raises(ValueError):
        box.put("teleport", said="somewhere nice")


def test_asking_to_start_a_project_starts_one(tmp_path):
    """Intention: what a person typed in a window is the same thing as what a
    person typed at the command line. There is no second way to have a
    project."""
    store, projects, taking, state, root = _world(tmp_path)
    Inbox(state).put(PROJECT, about="Colour Sorter",
                     said="sort things by colour and say why")
    got = taking.take()
    assert got["took"] == 1
    assert projects.names() == ["Colour Sorter"]
    assert projects.state("Colour Sorter")["intention"] == \
        "sort things by colour and say why"


def test_asking_for_a_picture_reaches_the_project_that_makes_them(tmp_path):
    """Intention: this does not know the name of the project that draws. The
    project SAYS where it takes requests, the same way it says where it
    publishes, and the request is written in the shape that project already
    reads."""
    store, projects, taking, state, root = _world(tmp_path)
    projects.open("Centering Image", intention="make pictures")
    store.assert_fact("project:centering_image", "has", attr=TAKES,
                      value="centering_image/inbox")
    Inbox(state).put(IMAGE, said="a snowy mountain")
    got = taking.take()
    assert got["took"] == 1
    dropped = list((state / "centering_image" / "inbox").glob("*.json"))
    assert len(dropped) == 1
    body = json.loads(dropped[0].read_text(encoding="utf-8"))
    assert body["subject"] == "a snowy mountain"


def test_a_comment_is_kept_as_his_words_and_raises_work(tmp_path):
    """HIS WORDS ARE KEPT AS HIS WORDS.

    Intention: a comment is stated as `user_said` and NOT as `user_intention`.
    A remark about a thing is not the same as what the thing is for, and writing
    it over the intention would be the header-carry defect arriving through a
    window.
    """
    store, projects, taking, state, root = _world(tmp_path)
    store.assert_fact("projects/thing/shrink.py", "has", attr="user_intention",
                      value="hold the number at one")
    Inbox(state).put(COMMENT, about="projects/thing/shrink.py",
                     said="it should hold at two, not one")
    taking.take()
    assert store.current(subject="projects/thing/shrink.py",
                         attr=SAID)[0]["value"] == "it should hold at two, not one"
    assert store.current(subject="projects/thing/shrink.py",
                         attr="user_intention")[0]["value"] == "hold the number at one"
    assert [row["kind"] for row in WorkQueue(store).open_items()] == ["revise"]


def test_a_dropped_file_is_copied_in_and_tied_to_what_it_is_about(tmp_path):
    """Intention: the thing a person dragged in may be on a stick or in a
    downloads folder they empty. What was asked about has to still be there when
    the loop gets to it, so the bytes come in and the copy is named by what it
    holds."""
    store, projects, taking, state, root = _world(tmp_path)
    dropped = tmp_path / "photo.png"
    dropped.write_bytes(b"not really a png, but bytes all the same")
    made = Inbox(state).put_file(dropped, said="this is what I mean",
                                 about="projects/thing/shrink.py")
    assert made["kind"] == FILE and made["bytes"] == 40
    taking.take()
    kept = f"state/{made['kept']}"
    assert store.current(subject=kept, attr="kind")[0]["value"] == "dropped_file"
    assert store.current(subject=kept, attr="name")[0]["value"] == "photo.png"
    assert [f["object"] for f in store.current(subject=kept, relation="supports")] \
        == ["projects/thing/shrink.py"]
    # and the bytes came with it, so deleting the original changes nothing
    dropped.unlink()
    assert (state / "asked" / "files").exists()
    assert any(p.read_bytes() == b"not really a png, but bytes all the same"
               for p in (state / "asked" / "files").iterdir())


def test_what_became_of_a_request_is_written_beside_it_not_over_it(tmp_path):
    """Intention: a person can read what they asked for and what happened, side
    by side, a week later. A request is never rewritten after it is written, so
    what was asked cannot be edited by the thing that answers it."""
    store, projects, taking, state, root = _world(tmp_path)
    box = Inbox(state)
    box.put(PROJECT, about="Colour Sorter", said="sort by colour")
    taking.take()
    assert box.waiting() == []
    rows = box.recent()
    assert rows[0]["said"] == "sort by colour"
    assert rows[0]["answer"]["how"] == "started it"
    assert rows[0]["answer"]["made"] == "project:colour_sorter"


def test_one_bad_request_does_not_stop_the_others(tmp_path):
    """Intention: this runs inside a loop pass. A request that cannot be taken
    is an answer about that request, not a reason the pass fails."""
    store, projects, taking, state, root = _world(tmp_path)
    box = Inbox(state)
    box.put(PROJECT, about="", said="")            # a project with no name
    box.put(PROJECT, about="Good One", said="this one is fine")
    got = taking.take()
    assert got["took"] == 2
    assert projects.names() == ["Good One"]
    hows = [row["answer"]["how"] for row in box.recent()]
    assert "a project needs a name" in hows


def test_the_window_can_be_built_and_driven_without_a_screen(tmp_path):
    """Intention: the cockpit has no seam and cannot be tested beyond "it
    imports". This one is built in one method that reads and writes nothing, so
    what the buttons do can be proven."""
    from warp2.ask.thread import ANDREW, Thread
    from warp2.ask.window import ActionCentre, colours

    assert {"page", "panel", "ink", "quiet", "good"} <= set(colours())
    centre = ActionCentre(tmp_path / "state")
    assert centre.refresh() == []
    Thread(tmp_path / "state").add(ANDREW, "a red apple")
    assert [turn["said"] for turn in centre.refresh()] == ["a red apple"]


def test_the_action_centre_can_be_opened_on_its_own(tmp_path):
    """Intention: Andrew ran the bat and got one window. The launcher starts
    this the same way it starts the cockpit — `python -m warp2.ask.window
    <root>` — so it needs a main that takes a root and finds the state beside
    it, exactly as the observer's does."""
    from warp2.ask import window

    seen = {}

    def instead(state, root=None, root_dir="."):
        seen["state"] = state
        return None                      # as a machine with no screen answers

    window.open_the_action_centre, real = instead, window.open_the_action_centre
    try:
        assert window.main([str(tmp_path)]) == 1
        assert seen["state"] == tmp_path / "state"
        assert window.main([str(tmp_path), str(tmp_path / "elsewhere")]) == 1
        assert seen["state"] == tmp_path / "elsewhere"
    finally:
        window.open_the_action_centre = real


def test_the_cockpit_offers_a_way_in(tmp_path):
    """Intention: "it should either always open the user part or have a button
    to open it in the cockpit, do both." Both. The launcher opens it; this is
    the other half, for when the action centre has been closed and the cockpit
    is still up."""
    import ast
    from pathlib import Path

    source = Path(__file__).resolve().parents[3] / "warp2" / "ui" / "observer.py"
    text = source.read_text(encoding="utf-8")
    tree = ast.parse(text)
    names = {node.name for node in ast.walk(tree)
             if isinstance(node, ast.FunctionDef)}
    assert "_on_ask_clicked" in names
    assert "btn_ask" in text and "ASK FOR SOMETHING" in text
    # It opens a window OF the cockpit, so closing it leaves the cockpit alone
    # and no second process is started.
    assert "tk.Toplevel(self.tk_root)" in text
    # And pressing it twice raises the one that is open rather than making two.
    assert "winfo_exists()" in text and "lift()" in text


def test_the_launcher_opens_both_windows(tmp_path):
    """Intention: show both GUI surfaces without opening console sidecars."""
    from pathlib import Path

    bat = (Path(__file__).resolve().parents[3] / "WARP2.bat").read_text(encoding="utf-8")
    assert "-m warp2.ui.observer" in bat
    assert "-m warp2.ask.window" in bat
    assert bat.count('start "" /B %WARP_GUI_PY%') == 3
    assert "pyw -3.11" in bat and "where pythonw" in bat
