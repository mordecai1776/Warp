# WARP2/warp2/ask/tests/test_subconcept_guessing.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_subconcept_guessing.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/subconcepts.py, warp2/ask/subconcept_tries.py,
#              warp2/ask/picture_round.py; (stdlib) json, types, pathlib.
#  Description:
#    The models guess a concept's types and parts; every guess is kept with
#    who said it; guesses are registered as Eye networks, given pictures, and
#    tried; a part is asked for its own parts; and the picture round's
#    `parts` part does all this instead of skipping it.
#  User intention (Andrew, muse-476, 2026-10-23): "number one is the ability for
#    the models to sit there and guess at sub-concepts ... types of cats ...
#    the feet the paw the paw pads the claws". BUILD_LOG 585.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

from warp2.ask.subconcepts import AnswerNames, GuessBook, LocalAsker, SubconceptGuesser


class FakeAsker:
    """Intention: answers like a small model, by question; counts what it was asked."""

    def __init__(self) -> None:
        self.asked = []

    def models(self):
        return ["small-a", "small-b"]

    def ask(self, model, prompt):
        self.asked.append((model, prompt))
        if "kinds or types of cat" in prompt:
            return "<think>hmm</think>\n1. Tabby\n2. Siamese cat\n- Persian"
        if "parts of a cat paw" in prompt:
            return "paw pads, claws, toes"
        if "parts of a cat" in prompt:
            return "* paw\n* tail\n* whiskers\n* the image"
        return ""


class FakeConcepts:
    def __init__(self) -> None:
        self.pairs = {}

    def measured(self, name):
        return True


class FakeEye:
    """Intention: an Eye that records what was defined."""

    def __init__(self) -> None:
        self.concepts = FakeConcepts()

    def define(self, name, description, by):
        self.concepts.pairs[name] = {"description": description, "by": by}


class FakeData:
    """Intention: data for a name without the network; every name gets one picture."""

    def __init__(self) -> None:
        self.fetched = []

    def fetch(self, name, references, round_no):
        self.fetched.append(name)
        references["references"][f"ref-{name}"] = {"subject": name, "status": "pending"}
        return {"dataset": "", "from_dataset": 0, "from_search": 1, "error": ""}


def _learning(tmp_path):
    state = tmp_path / "state"
    state.mkdir()
    return SimpleNamespace(root=tmp_path, state=state,
                           _load=lambda: {"references": {}, "attempts": {}, "subjects": {}})


def test_answers_are_read_into_short_names():
    """Intention: bullets, numbers and thinking are stripped; the subject and non-parts are dropped."""
    names = AnswerNames().read("<think>x</think>\n1. Tabby\n- the image\n* cat\n* Paw pads (front)", "cat")
    assert names == ["tabby", "paw pads"]


def test_types_and_parts_are_guessed_once_and_every_answer_is_kept(tmp_path):
    """Intention: two models asked per kind, their answers kept with their names, and not asked again."""
    asker = FakeAsker()
    guesser = SubconceptGuesser(tmp_path, tmp_path, asker=asker)
    new = guesser.guess("cat")
    assert "tabby" in new["types"] and "siamese cat" in new["types"]
    assert new["parts"] == ["paw", "tail", "whiskers"]
    kept = json.loads((tmp_path / "visual_learning" / "subconcept_guesses.json").read_text(encoding="utf-8"))
    assert {row["model"] for row in kept["cat"]["asked"]} == {"small-a", "small-b"}
    count = len(asker.asked)
    guesser.guess("cat")
    assert len(asker.asked) == count


def test_names_are_made_whole():
    """Intention: a part carries its whole, a type its kind; no doubled word."""
    guesser = SubconceptGuesser(".", ".", asker=FakeAsker())
    assert guesser.full_name("cat", "paw", "parts") == "cat paw"
    assert guesser.full_name("cat paw", "paw pads", "parts") == "cat paw pads"
    assert guesser.full_name("cat", "tabby", "types") == "tabby cat"
    assert guesser.full_name("cat", "siamese cat", "types") == "siamese cat"


def test_guesses_become_networks_get_pictures_and_go_a_level_deeper(tmp_path):
    """Intention: types and parts registered on the Eye; three tried with pictures; a tried part's parts registered."""
    from warp2.ask.subconcept_tries import SubconceptTries
    learning = _learning(tmp_path)
    tries = SubconceptTries(learning, guesser=SubconceptGuesser(tmp_path, learning.state, asker=FakeAsker()))
    tries.data = FakeData()
    model = SimpleNamespace(eye=FakeEye(), warp=None)
    first = tries.turn(model, "cat", 1)
    pairs = model.eye.concepts.pairs
    assert "tabby cat" in pairs and "cat paw" in pairs and "cat whiskers" in pairs
    assert "cat sharp image" not in pairs, "no hand-table extras (BUILD_LOG 643)"
    assert len(first["tried"]) == 3 and len(first["added"]) == 3
    for _ in range(3):
        tries.turn(model, "cat", 2)
    assert "cat paw pads" in pairs and "cat paw claws" in pairs
    assert pairs["cat paw claws"]["description"] == "part of cat paw"
    book = GuessBook(learning.state)
    assert "paw" in book.entry("cat")["tried"]


def test_the_round_guesses_sub_concepts_instead_of_skipping(tmp_path, monkeypatch):
    """Intention: the `parts` part runs the guessing and keeps its pictures (it used to say 'skipped')."""
    from warp2.ask import picture_round, subconcept_tries

    class FakeTries:
        def __init__(self, learning, search=None):
            pass

        def turn(self, model, subject, round_no):
            return {"guessed": {"types": ["tabby"], "parts": ["paw"]}, "registered": {"registered": 2},
                    "tried": [{"name": "cat paw", "from_dataset": 0, "from_search": 1}],
                    "added": {"ref-cat paw": {"subject": "cat paw"}}}

    monkeypatch.setattr(subconcept_tries, "SubconceptTries", FakeTries)
    learning = _learning(tmp_path)
    learning.stop = SimpleNamespace(raised=lambda: False)
    monkeypatch.setattr(picture_round, "_model", lambda _learning: SimpleNamespace(eye=None))
    state = picture_round.start("cat", 1)
    state["part"] = "parts"
    said = picture_round.PictureRound(learning)._parts(state)
    assert "skipped" not in said["said"] and "guessed" in said["said"]
    assert state["sub_added"] == {"ref-cat paw": {"subject": "cat paw"}}
    assert state["part"] == "practice"


def test_blocks_go_on_to_the_parts():
    """Intention: the round no longer jumps from blocks straight to practice."""
    source = Path(__file__).resolve().parents[1].joinpath("picture_round.py").read_text(encoding="utf-8")
    body = source[source.index("    def _blocks("):source.index("    def _parts(")]
    assert 'state["part"] = "parts"' in body


def test_the_local_asker_reads_the_roster(tmp_path):
    """Intention: only switched-on Ollama practice models, the small preferred ones first."""
    (tmp_path / "models.json").write_text(json.dumps({"models": [
        {"name": "hermes3:8b", "how": "ollama", "kinds": ["practice"]},
        {"name": "gemma2:2b", "how": "ollama", "kinds": ["practice"]},
        {"name": "codegemma:2b", "how": "ollama", "kinds": ["practice"], "enabled": False},
        {"name": "moondream:latest", "how": "ollama", "kinds": ["describe"]}]}), encoding="utf-8")
    assert LocalAsker(tmp_path).models() == ["gemma2:2b", "hermes3:8b"]


def test_parts_lead_the_tries():
    """Intention: a part, then a type, in turn, parts first (muse-471: built up from the pieces)."""
    book = GuessBook(Path(".") / "unused")
    page = book.entry("cat")
    page["types"], page["parts"] = ["tabby", "siamese", "persian"], ["paw", "tail"]
    assert book.untried("cat") == ["paw", "tabby", "tail", "siamese", "persian"]


def test_only_guessed_names_become_networks_and_the_extras_are_retired(tmp_path):
    """Intention (BUILD_LOG 643): types and parts the models guessed, once each — no hand-table extras, no task copies; extras retired, not deleted; a network the readers made first is never retired."""
    from warp2.ask.subconcept_tries import ExtraNetworks, SubconceptRegistrar

    class Concept:
        def __init__(self, by):
            self.defined_by = by

    class Layer:
        def __init__(self):
            self.retired = set()

        def retire(self, name):
            self.retired.add(name)

    class Eye:
        def __init__(self):
            self.concepts = FakeConcepts()
            self.concept_activation = Layer()

        def define(self, name, description, by):
            self.concepts.pairs[name] = Concept(by)

    eye = Eye()
    eye.concepts.pairs.update({"cat sharp image": Concept("quality taxonomy"), "parts: cat: cat ears": Concept("the WARP"),
                               "tabby cat": Concept("the WARP's picture requests"), "dog": Concept("the WARP")})
    guesser = SubconceptGuesser(tmp_path, tmp_path, asker=FakeAsker())
    guesser.guess("cat")
    warp = SimpleNamespace(parts={"qualities: cat": {}, "pictures": {"classes": ["cat", "cat sharp image"]}})
    got = SubconceptRegistrar(tmp_path).register(SimpleNamespace(eye=eye, warp=warp), "cat", guesser,
                                                 guesser.book.entry("cat"))
    assert "cat paw" in eye.concepts.pairs and "siamese cat" in eye.concepts.pairs
    assert eye.concepts.pairs["cat paw"].defined_by == "guessed by a local model"
    assert eye.concept_activation.retired == {"cat sharp image", "parts: cat: cat ears"}
    assert "cat sharp image" in eye.concepts.pairs, "retired, not deleted"
    assert "tabby cat" not in eye.concept_activation.retired, "a network made before is never retired"
    assert "qualities: cat" not in warp.parts and warp.parts["pictures"]["classes"] == ["cat"]
    assert got["retired"] == 2


def test_a_resumed_round_retires_the_extras_at_its_first_part():
    """Intention (BUILD_LOG 643): a round resumed past _weigh still retires them before any cascade."""
    source = (Path(__file__).resolve().parents[1] / "picture_round.py").read_text(encoding="utf-8")
    step = source[source.index("    def step("):source.index("    def run(")]
    assert "_retire_extras_once(self.learning, state)" in step
    assert step.index("_retire_extras_once") < step.index('getattr(self, "_" + part)(state)')
