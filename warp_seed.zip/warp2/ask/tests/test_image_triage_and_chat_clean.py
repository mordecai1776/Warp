# WARP2/warp2/ask/tests/test_image_triage_and_chat_clean.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_image_triage_and_chat_clean.py
#  Used by   : pytest.
#  Uses      : warp2/ask/{image_triage,window,thread}.py, warp2/train/training_blocks.py
#  Description:
#    Unit test suite verifying:
#    1. Images are not rendered inline in the chat paper (transcript stays text-clean).
#    2. "I Don't Know" button exists on image review and enqueues to ImageTriageHandler.
#    3. Clicking confirm, retry, or I don't know stages training blocks into ingestor
#       and does NOT trigger blocking model training at the moment of click.
#    4. Automated and manual triage workflow (analyze, resolve, discard) works end-to-end.
#  User intention (Andrew, 2026-09-17):
#    "also the images should not be in the chat and there needs to be a I dont know
#     button for the images. It should also just add to something and not trigger a
#     training at the moment I click the buttons. There also needs to be something to
#     handel the I dont know images"
# ============================================================================
from __future__ import annotations

import time
import tkinter as tk
from pathlib import Path
from PIL import Image
import pytest

from warp2.ask.thread import Thread, ANDREW, WARP
from warp2.ask.window import ActionCentre, colours
from warp2.ask.image_triage import ImageTriageHandler, UncertainImageEntry
from warp2.train.training_blocks import TrainingBlockIngestor


def _create_sample_png(path: Path, color: str = "red", size: tuple[int, int] = (64, 64)) -> Path:
    im = Image.new("RGB", size, color=color)
    im.save(path, format="PNG")
    return path


def test_image_triage_enqueue_and_list(tmp_path):
    """Test enqueuing uncertain images and retrieving them from persistent JSONL."""
    state = tmp_path / "state"
    triage = ImageTriageHandler(state)

    img_file = _create_sample_png(tmp_path / "test_unknown.png", color="orange")
    entry = triage.enqueue_uncertain(
        path=img_file,
        kind="created",
        initial_subject="orange cat",
        reader_scores={"reader_score": 0.45, "tags": ["animal", "fur", "feline"]},
        notes="User clicked I Don't Know",
    )

    assert entry.id.startswith("unc_")
    assert entry.status == "pending_triage"
    assert entry.initial_subject == "orange cat"

    # Verify retrieval
    listed = triage.list_uncertain()
    assert len(listed) == 1
    assert listed[0].id == entry.id
    assert listed[0].path == str(img_file)

    # Verify get by ID
    fetched = triage.get_uncertain(entry.id)
    assert fetched is not None
    assert fetched.initial_subject == "orange cat"


def test_image_triage_analyze_and_hypotheses(tmp_path):
    """Test multi-perspective visual and textual analysis for concept hypotheses."""
    state = tmp_path / "state"
    triage = ImageTriageHandler(state)

    img_file = _create_sample_png(tmp_path / "blue_sphere.png", color="blue", size=(80, 40))
    entry = triage.enqueue_uncertain(
        path=img_file,
        kind="reference",
        initial_subject="sphere",
        reader_scores={"reader_score": 0.5, "observation": "round blue object with shading"},
    )

    analyzed = triage.analyze_image(entry.id)
    assert analyzed.status == "analyzed"
    assert "width" in analyzed.features
    assert analyzed.features["width"] == 80
    assert analyzed.features["height"] == 40
    assert analyzed.features["aspect_ratio"] == 2.0
    assert analyzed.features["dominant_tint"] == "cool"
    assert len(analyzed.hypotheses) > 0

    # Top hypothesis should be related to sphere or blue
    top_concepts = [h["concept"] for h in analyzed.hypotheses]
    assert any("sphere" in c or "blue" in c for c in top_concepts)


def test_image_triage_resolve_and_discard_decoupled(tmp_path):
    """Resolving or discarding an uncertain image records training blocks without blocking."""
    state = tmp_path / "state"
    triage = ImageTriageHandler(state)
    ingestor = TrainingBlockIngestor(state)

    img_pos = _create_sample_png(tmp_path / "apple.png", color="red")
    e_pos = triage.enqueue_uncertain(img_pos, kind="created", initial_subject="fruit")

    # Resolve positive
    res_pos = triage.resolve_uncertain(e_pos.id, resolved_concept="red delicious apple", make_positive=True)
    assert res_pos["status"] == "resolved"
    assert res_pos["resolved_as"] == "red delicious apple"
    assert res_pos["training_block_id"]

    # Verify training block was recorded in blocks.jsonl
    blocks = ingestor.load_blocks()
    assert any(b.block_id == res_pos["training_block_id"] for b in blocks)

    # Discard negative
    img_neg = _create_sample_png(tmp_path / "glitch.png", color="gray")
    e_neg = triage.enqueue_uncertain(img_neg, kind="reference", initial_subject="glitch")
    res_neg = triage.discard_uncertain(e_neg.id, reason="noisy artifact")
    assert res_neg["status"] == "discarded"
    assert res_neg["training_block_id"]


def test_auto_triage_pending(tmp_path):
    """Background autonomous triage analyzes pending images."""
    state = tmp_path / "state"
    triage = ImageTriageHandler(state)

    f1 = _create_sample_png(tmp_path / "item1.png", color="green")
    f2 = _create_sample_png(tmp_path / "item2.png", color="yellow")
    triage.enqueue_uncertain(f1, kind="created", initial_subject="leaf")
    triage.enqueue_uncertain(f2, kind="reference", initial_subject="lemon")

    results = triage.auto_triage_pending(limit=2)
    assert len(results) == 2
    assert all("top_hypothesis" in r for r in results)

    # Pending list should now be empty
    assert len(triage.list_uncertain(status="pending_triage")) == 0
    assert len(triage.list_uncertain(status="analyzed")) == 2


def test_chat_has_no_inline_image_pixels(tmp_path, tk_root):
    """Verify turns with references and generated images do NOT inject PhotoImage pixels into chat."""
    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    ref_img = _create_sample_png(tmp_path / "ref_car.png")
    gen_img = _create_sample_png(tmp_path / "gen_car.png")

    # Add turn with both reference and generated image
    centre.thread.add(
        WARP,
        "Here is a sports car concept",
        subject="sports car",
        references=[str(ref_img)],
        reference_reviews=[{"path": str(ref_img), "reader_score": 0.82, "tags": ["car", "vehicle"]}],
        image=str(gen_img),
    )
    centre.refresh()

    # Chat paper must contain NO PhotoImage objects!
    assert len(centre.paper.image_names()) == 0

    paper_text = centre.paper.get("1.0", "end")
    assert "Here is a sports car concept" in paper_text
    assert "[ref_car.png]" in paper_text
    assert "[gen_car.png]" in paper_text

    # Both images should be queued in pending confirmations deck outside chat
    assert str(ref_img.resolve()) in centre.pending_image_confirmations
    assert str(gen_img.resolve()) in centre.pending_image_confirmations


def test_i_dont_know_button_enqueues_triage_and_removes_from_chat(tmp_path, tk_root):
    """Clicking 'I Don't Know' button marks uncertain, enqueues to triage, and removes from chat."""
    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    img_path = _create_sample_png(tmp_path / "mystery.png")
    centre.thread.add(WARP, "What is this?", image=str(img_path))
    centre.refresh()

    assert str(img_path.resolve()) in centre.pending_image_confirmations

    # Simulate user clicking [ 🤷 I Don't Know ]
    entry = centre._mark_image_unknown_from_panel(str(img_path))
    assert entry is not None
    assert entry["status"] == "pending_triage"
    assert entry["path"] == str(img_path)

    # Removed from pending confirmations
    assert str(img_path.resolve()) not in centre.pending_image_confirmations

    # Image is removed from turn transcript
    turn = centre.thread.recent()[0]
    assert turn.get("image") is None

    # Triage handler has it recorded
    triage = ImageTriageHandler(state)
    assert triage.get_uncertain(entry["id"]) is not None


def test_decoupled_buttons_stage_training_blocks_without_stall(tmp_path, tk_root):
    """Clicking Confirm, Retrain, or Discard immediately stages blocks without eager retraining."""
    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    img1 = _create_sample_png(tmp_path / "car1.png")
    centre.thread.add(WARP, "Car 1", image=str(img1))
    centre.refresh()

    # 1. Confirm & Store: stages positive block and stores to gallery
    res_confirm = centre._confirm_image_action(str(img1))
    assert res_confirm["status"] in ("stored", "already_present")

    # 2. Downvote & Retry: stages negative block
    img2 = _create_sample_png(tmp_path / "car2.png")
    centre.thread.add(WARP, "Car 2", image=str(img2))
    centre.refresh()

    res_down = centre._downvote_and_retry(str(img2))
    assert res_down["status"] == "downvoted"
    assert res_down["training_block_id"]

    # Ingestor contains both blocks
    ingestor = TrainingBlockIngestor(state)
    blocks = ingestor.load_blocks()
    assert len(blocks) >= 2


def test_triage_deck_ui_resolution(tmp_path, tk_root):
    """Triage panel UI resolution properly resolves items into positive or negative blocks."""
    state = tmp_path / "state"
    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    img = _create_sample_png(tmp_path / "unknown_flower.png")
    triage = ImageTriageHandler(state)
    entry = triage.enqueue_uncertain(img, kind="reference", initial_subject="flower")

    # Switch right deck to Triage
    centre._switch_right_view("triage")
    assert centre.right_view_mode == "triage"

    # Resolve from triage UI action
    centre._resolve_triage_action(entry.id, "sunflower", make_positive=True)

    updated = triage.get_uncertain(entry.id)
    assert updated.status == "resolved"
    assert updated.resolved_as == "sunflower"
