# WARP2/warp2/ask/tests/test_logic_rules_are_proven_by_truth_table.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_logic_rules_are_proven_by_truth_table.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/ask/logic_rules.py, warp2/ask/logic_learning.py
#              (LOGIC_DOMAINS, LogicProver), warp2/work/side/logic.py (LogicStep._backed).
#  Description:
#    A rule topic is proven by its own truth table (BUILD_LOG 1118): every
#    rule holds on every row and its fallacy fails on one; a checker that
#    called everything valid proves nothing; every rule is a real logic
#    topic; CNF is proven by a converter that keeps truth and shape; the
#    proof's text is the rule, its fallacy and the check; and the KG claim
#    is backed for its own topic only.
#  User intention (Andrew, 2026-11-02): "make sure they have proper datasets
#    and that they are given proper leaning methods and test".
# ============================================================================
"""Tests that each rule of reasoning is proven by its truth table, against its fallacy."""
from __future__ import annotations

from warp2.ask import logic_rules
from warp2.ask.logic_learning import LOGIC_DOMAINS, LogicProver
from warp2.ask.logic_rules import (RULES, RuleProofs, atom, both, counter_row, either, entails, imp, is_cnf,
                                   neg, same_on_every_row, to_cnf)


def test_every_rule_holds_and_its_fallacy_fails():
    """Intention: each rule proven under its own name, for every rule."""
    for topic in RULES:
        ok, name, msg, ms = RuleProofs.prove(topic)
        assert ok is True and name == f"Truth table proof of {topic}", msg


def test_the_check_reads_the_whole_table():
    """Intention: modus ponens has no counter row; affirming the consequent has p false, q true."""
    p, q = atom("p"), atom("q")
    assert entails([imp(p, q), p], q)
    assert counter_row([imp(p, q), q], p) == {"p": False, "q": True}
    assert entails([], either(p, neg(p))) and not entails([], p)


def test_a_checker_that_calls_everything_valid_proves_nothing(monkeypatch):
    """Intention: the fallacy must fail, so a broken check cannot prove a rule."""
    monkeypatch.setattr(logic_rules, "counter_row", lambda premises, conclusion: None)
    ok, _, msg, _ = RuleProofs.prove("Modus ponens")
    assert ok is False and "cannot tell them apart" in msg


def test_every_rule_is_a_real_logic_topic():
    """Intention: one line per topic, by its exact name; CNF is a topic too."""
    topics = {t for ts in LOGIC_DOMAINS.values() for t in ts}
    assert set(RULES) <= topics and "Conjunctive normal form" in topics


def test_cnf_keeps_truth_and_shape():
    """Intention: the converter's output is CNF and equal on every row; the proof says so."""
    p, q, r = atom("p"), atom("q"), atom("r")
    f = imp(either(p, both(q, r)), neg(both(p, q)))
    g = to_cnf(f)
    assert is_cnf(g) and same_on_every_row(f, g)
    assert not is_cnf(either(p, both(q, r)))
    assert LogicProver.prove_logic_for("Conjunctive normal form")[0] is True


def test_the_proof_text_is_the_rule_its_fallacy_and_the_check():
    """Intention: what trains is the statement and the code that checked it."""
    text = LogicProver.proof_source("Truth table proof of Modus ponens")
    assert "(p -> q) ; p |- q" in text and "affirming the consequent" in text and "def counter_row" in text


def test_a_rule_proof_backs_its_own_topic_only():
    """Intention: the KG claim "<proof> supports <topic>" stands for its own topic, and is taken back for another."""
    from warp2.work.side.logic import LogicStep
    proof = "Truth table proof of Modus ponens"
    assert LogicStep._backed(None, proof, "Modus ponens") is True
    assert RuleProofs.covers("Modus tollens", proof) is False
