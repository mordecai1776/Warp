# WARP2/warp2/ask/tests/test_until.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_until.py
#  Used by   : pytest.
#  Uses      : warp2/ask/until.py, warp2/train/mistakes.py, warp2/store/store.py.
#  Description:
#    That it keeps going until a reader says yes, that each round goes after
#    what the last one was told was missing, and that it never pretends.
#  User intention (Andrew, 2026-09-12):
#    "it should just keep retraining with new internet data and retraining
#    until it gives one that the reader says is what was asked for."
# ============================================================================
from __future__ import annotations

from warp2.ask.until import SUBJECT, Until
from warp2.store.store import Store
from warp2.train.mistakes import Mistakes


class Learning:
    """A generator that answers from a script and remembers what it was asked.

    Intention: the real one talks to a local image model, two vision readers
    and Wikimedia. Standing that up would be testing those, not this.
    """

    def __init__(self, script) -> None:
        self.script = list(script)
        self.asked = []

    def generate(self, subject, wanted=None, round_no=0, **rest):
        self.asked.append({"subject": subject, "wanted": list(wanted or []),
                           "round": round_no})
        answer = self.script[min(round_no - 1, len(self.script) - 1)]
        return dict(answer)


def missed(score=0.4, missing=("wheel",), status="awaiting_reference_confirmation"):
    return {"approved": False, "status": status, "image_path": "miss.png",
            "evidence": {"score": score}, "missing": list(missing),
            "readers": [{"name": "r1", "difference": f"missing {list(missing)}"}]}


def hit():
    return {"approved": True, "status": "approved", "image_path": "hit.png",
            "evidence": {"score": 1.0}, "readers": []}


def test_it_stops_the_moment_a_reader_says_yes():
    """Intention: the ending Andrew named, and the only one that is success."""
    learning = Learning([missed(), missed(), hit()])
    got = Until(learning, rounds=6).make("red bicycle")
    assert got["how"] == "approved"
    assert got["approved"] is True
    assert got["image_path"] == "hit.png"
    assert got["rounds"] == 3
    assert len(learning.asked) == 3


def test_each_round_goes_after_what_the_last_one_was_told_was_missing():
    """Intention: Andrew — "it should also be able to break that down when
    parts need to be trained." The first round has nothing to go on; every
    round after it does, and it comes from the readers rather than from a
    counter bolting adjectives onto the subject."""
    learning = Learning([missed(missing=("wheel",)), missed(missing=("frame",)), hit()])
    Until(learning, rounds=6).make("red bicycle")
    assert [one["wanted"] for one in learning.asked] == [[], ["wheel"], ["frame"]]
    assert [one["round"] for one in learning.asked] == [1, 2, 3]


def test_a_round_that_says_nothing_new_keeps_the_last_thing_it_knew():
    """Intention: a reader that gives no difference this time has not withdrawn
    the one it gave last time, and dropping back to searching for the bare
    subject would throw away the only lead there is."""
    learning = Learning([missed(missing=("wheel",)), missed(missing=()), hit()])
    Until(learning, rounds=6).make("bicycle")
    assert learning.asked[2]["wanted"] == ["wheel"]


def test_it_gives_back_the_best_it_saw_not_the_last_one():
    """Intention: six tries and handing back number six is a queue, not a
    search. If the budget runs out the person gets the nearest miss."""
    learning = Learning([missed(score=0.9), missed(score=0.2), missed(score=0.3)])
    got = Until(learning, rounds=3).make("bicycle")
    assert got["how"] == "out_of_rounds"
    assert got["score"] == 0.9


def test_it_never_pretends_it_succeeded():
    """Intention: a loop like this failing quietly is how somebody ends up
    looking at the fourth-best picture believing it was the answer."""
    got = Until(Learning([missed()]), rounds=2).make("bicycle")
    assert got["approved"] is False
    assert got["how"] == "out_of_rounds"
    assert "wheel" in got["said"]
    assert len(got["tried"]) == 2


def test_no_reader_is_not_a_no():
    """Intention: going round again with nothing able to look can never end in
    a yes however many rounds are left — and every one of those rounds would
    search the internet and train the model on nobody's opinion."""
    learning = Learning([missed(status="reader_unavailable")])
    got = Until(learning, rounds=6).make("bicycle")
    assert got["how"] == "no_reader"
    assert len(learning.asked) == 1


def test_being_asked_to_stop_is_not_getting_it_wrong():
    """Intention: counting a halt as the model failing would poison the tally
    that decides how much of the machine's time goes to training."""
    learning = Learning([{"status": "stopped"}])
    got = Until(learning, rounds=6).make("bicycle")
    assert got["how"] == "stopped"
    assert len(learning.asked) == 1


def test_a_failed_picture_counts_in_the_same_tally_as_everything_else(tmp_path):
    """Intention: two separate notions of "how well is it doing" would be two
    answers to one question. A picture the readers turned away is a refusal
    like any other and lifts training's share by the same rule."""
    seen = Mistakes(Store(tmp_path / "state"))
    Until(Learning([missed(), missed(), hit()]), mistakes=seen, rounds=6).make("bicycle")
    assert seen.repeats(SUBJECT + "bicycle") == 2
    tally = seen.door()
    assert tally["refused"] > 0 and tally["accepted"] > 0


def test_what_gets_counted_is_what_the_reader_actually_said(tmp_path):
    """Intention: the complaint has to be the reader's own difference, because
    the difference is the thing that can be searched for next round. A number
    cannot be."""
    seen = Mistakes(Store(tmp_path / "state"))
    Until(Learning([missed(missing=("wheel",))]), mistakes=seen, rounds=1).make("bike")
    assert seen.repeats(SUBJECT + "bike", "missing ['wheel']") == 1


def test_the_whole_of_the_best_round_comes_back():
    """Intention: callers built on the old single-cycle answer read fields off
    it — how many references were trained, which are waiting for review. A loop
    that returns its own tidy shape and drops the rest breaks every one."""
    rich = dict(missed(score=0.8), trained_refs=4, references=["a", "b"], updates=9)
    got = Until(Learning([rich]), rounds=1).make("bicycle")
    assert got["best"]["trained_refs"] == 4
    assert got["best"]["references"] == ["a", "b"]
    assert got["best"]["updates"] == 9


class Ledger:
    """A `VisualLearning` standing in with a ledger and nothing else.

    Intention: `practice` is mostly a decision about WHICH subject, made off
    the ledger. The generating half is covered above.
    """

    def __init__(self, subjects, references) -> None:
        from warp2.record.stop import Stop
        self.data = {"subjects": dict(subjects), "references": dict(references),
                     "attempts": {}, "last_practice": 0}
        self.stop = Stop(mirror=None)
        self.chosen = None

    def _load(self):
        return self.data

    # Intention: practice now enrolls new subjects first (09-15). The stand-in
    # enrolls none, so these tests stay about WHICH subject is chosen — and
    # stay off the network.
    def discover_new_subjects(self, data, count=1, search_online=True):
        return []

    def _save(self, data):
        self.data = data

    def user_asked_subjects(self):
        return set(self.data.get("subjects", {}).keys())

    def generate(self, subject, wanted=None, round_no=0, **rest):
        self.chosen = subject
        return {"approved": True, "status": "approved", "image_path": "hit.png",
                "evidence": {"score": 1.0}, "readers": []}

    # Intention: the real one, because keeping a split job's place IS what is
    # under test here — a stand-in that quietly forgot would pass every time.
    def _remember(self, subject, resume):
        from warp2.ask.visual import VisualLearning
        return VisualLearning._remember(self, subject, resume)


def test_a_reference_nobody_clicked_no_longer_blocks_the_subject(tmp_path, monkeypatch):
    """MEASURED ON ANDREW'S OWN STATE, 2026-09-12.

    Intention: practice skipped any subject with even one reference sitting at
    `pending`. His state had exactly one subject and four pending references,
    so practice answered `waiting_for_references` on every pass and the image
    side never ran at all — waiting on a click that was never coming. The
    reader is the gate now; a pending reference is one the reader has not
    passed, and the answer to that is to go and get better data.
    """
    from warp2.ask.visual import VisualLearning
    from warp2.record.locks import Lock

    ledger = Ledger({"a red bicycle": "needs_references"},
                    {"r1": {"subject": "a red bicycle", "status": "pending"},
                     "r2": {"subject": "a red bicycle", "status": "pending"}})
    ledger.path = tmp_path / "learning.json"
    ledger.state = tmp_path
    ledger._readers = lambda: []

    said = VisualLearning.practice(ledger, now=1000.0, every=0)
    assert ledger.chosen == "a red bicycle"
    assert said["status"] == "approved"


def test_nothing_to_practise_is_said_plainly(tmp_path):
    """Intention: no subjects at all is a different thing from a subject that
    is waiting on somebody, and calling both "waiting for references" is how
    the first one went unnoticed for so long."""
    from warp2.ask.visual import VisualLearning

    ledger = Ledger({}, {})
    ledger.path = tmp_path / "learning.json"
    ledger.state = tmp_path
    said = VisualLearning.practice(ledger, now=1000.0, every=0)
    assert said["status"] == "nothing_to_practise"


def test_the_caller_may_be_the_only_gate(tmp_path):
    """Intention: `every=0` hands the timing to the caller, because the loop
    now decides training's share from how much work is being refused — and a
    fixed thirty-minute clock in here would quietly overrule that."""
    from warp2.ask.visual import VisualLearning

    ledger = Ledger({"x": "ready"}, {})
    ledger.path = tmp_path / "learning.json"
    ledger.state = tmp_path
    ledger.data["last_practice"] = 999.0
    assert VisualLearning.practice(ledger, now=1000.0, every=0)["status"] == "approved"
    ledger.data["last_practice"] = 999.0
    assert VisualLearning.practice(ledger, now=1000.0, every=1800)["status"] == "not_due"


def test_the_window_can_read_while_a_round_is_running(tmp_path):
    """WHAT ANDREW HIT: HE REJECTED AN IMAGE AND THE WINDOW FROZE.

    Intention: `generate` holds the learning ledger's lock for about a minute
    at a time — across the model, both readers at forty-five seconds each, and
    a search of Wikimedia. The window calls `references` and `approved` every
    time it draws, and those took the same lock, so drawing queued behind a
    network call. They are reads, and `_save` replaces the file atomically, so
    a reader sees the whole old file or the whole new one and never needs the
    writer's lock at all.
    """
    import json
    from warp2.ask.visual import VisualLearning
    from warp2.record.locks import Lock

    learning = VisualLearning(tmp_path, tmp_path / "state")
    learning._save({"references": {"r1": {"subject": "cat", "status": "confirmed",
                                          "path": str(tmp_path / "gone.png"),
                                          "digest": "x"}},
                    "attempts": {}, "subjects": {}, "last_practice": 0})

    # exactly the position a round leaves the window in
    with Lock(learning.path, forever=True):
        assert learning.references() == []          # the file is gone, so none survive
        assert learning.approved(tmp_path / "gone.png") is False


def test_writing_the_ledger_still_takes_the_lock(tmp_path):
    """Intention: the reads were freed, not the writes. Two writers on one
    ledger is the thing the lock is for, and loosening that would trade a
    frozen window for a lost confirmation."""
    import inspect
    from warp2.ask.visual import VisualLearning

    for writer in (VisualLearning.confirm, VisualLearning.approve_attempt, VisualLearning.practice):
        assert "with Lock(self.path" in inspect.getsource(writer), writer.__name__
    # Intention (2026-10-02): a round is run in parts (warp2/ask/picture_round.py);
    # its read and its write are the parts that take the lock.
    from warp2.ask.picture_round import PictureRound
    for part in (PictureRound._weigh, PictureRound._record):
        assert "with Lock(learning.path" in inspect.getsource(part), part.__name__


def test_the_machine_takes_one_round_and_hands_the_loop_back(tmp_path):
    """ANDREW'S RULE, 2026-09-12.

    "it is fine if it spends the entire process if it is a user need just not
    if it is on its own work that should be split up."

    Intention: one practice turn held the whole loop for 338 seconds doing six
    rounds nobody was waiting on. Its own work now takes one round and gives
    the loop back, and picks up where it stopped next turn.
    """
    from warp2.ask.visual import VisualLearning

    ledger = Ledger({"cat": "needs_references"}, {})
    ledger.path = tmp_path / "learning.json"
    ledger.state = tmp_path
    ledger.rounds = []

    def one_round(subject, wanted=None, round_no=0, **rest):
        ledger.rounds.append((round_no, list(wanted or [])))
        return {"approved": False, "status": "awaiting_reference_confirmation",
                "image_path": "miss.png", "evidence": {"score": 0.3},
                "missing": ["wheel"],
                "readers": [{"name": "r", "difference": "missing ['wheel']"}]}

    ledger.generate = one_round
    first = VisualLearning.practice(ledger, now=1000.0, every=0)
    assert first["status"] == "more_to_do"
    assert len(ledger.rounds) == 1
    assert ledger.data["progress"]["cat"] == {"round": 1, "wanted": ["wheel"]}

    second = VisualLearning.practice(ledger, now=2000.0, every=0)
    assert second["status"] == "more_to_do"
    assert ledger.rounds[1] == (2, ["wheel"]), "it must pick up where it stopped"
    assert ledger.data["progress"]["cat"]["round"] == 2


def test_a_finished_subject_stops_looking_part_way_through(tmp_path):
    """Intention: a subject part way through is picked first, so one that
    finished and kept its marker would be chosen every single turn for ever."""
    from warp2.ask.visual import VisualLearning

    ledger = Ledger({"cat": "needs_references"}, {})
    ledger.path = tmp_path / "learning.json"
    ledger.state = tmp_path
    ledger.data["progress"] = {"cat": {"round": 4, "wanted": ["wheel"]}}
    ledger.generate = lambda subject, wanted=None, round_no=0, **rest: {
        "approved": True, "status": "approved", "image_path": "hit.png",
        "evidence": {"score": 1.0}, "readers": []}

    said = VisualLearning.practice(ledger, now=1000.0, every=0)
    assert said["status"] == "approved"
    assert ledger.data["progress"].get("cat") is None


def test_a_person_asking_still_gets_the_whole_budget():
    """Intention: the other half of the rule. Somebody who asked for a picture
    and is waiting may have all six rounds in one call."""
    learning = Learning([missed(), missed(), missed(), missed(), missed(), missed()])
    got = Until(learning, rounds=6).make("cat")
    assert got["how"] == "out_of_rounds"
    assert got["rounds"] == 6
    assert len(learning.asked) == 6


def test_the_ledger_lock_is_not_held_while_the_slow_work_runs():
    """ANDREW, 2026-09-12: he clicked to say an image was not a cat, and the
    program froze.

    `references` and `approved` were freed from this lock already, and the
    docstring there names the cause exactly — `generate` held it "across the
    model, both readers at forty-five seconds each, and a search of Wikimedia".
    Only the reading side was fixed. A CLICK IS A WRITE: `confirm` waits sixty
    seconds for the same lock, raises `Held`, and the one serial worker behind
    the window has done nothing in all that time. Which is a frozen program,
    from where he is sitting.

    So this reads the method itself and asks where the four slow calls sit. It
    is a structural test on purpose: standing up the image model, two vision
    readers and Wikimedia to prove a lock is not held would be testing those.
    """
    import ast
    import inspect
    import textwrap
    from warp2.ask.visual import VisualLearning

    tree = ast.parse(textwrap.dedent(inspect.getsource(VisualLearning.generate)))

    def takes_the_lock(node):
        return isinstance(node, ast.With) and any(
            isinstance(item.context_expr, ast.Call)
            and getattr(item.context_expr.func, "id", "") == "Lock"
            for item in node.items)

    def called_in(node):
        names = set()
        for inner in ast.walk(node):
            if isinstance(inner, ast.Call):
                names.add(getattr(inner.func, "attr", "")
                          or getattr(inner.func, "id", ""))
        return names

    SLOW = {"train_example", "read", "_search", "_checkpoint"}
    for node in ast.walk(tree):
        if takes_the_lock(node):
            held = called_in(node) & SLOW
            assert not held, (f"{sorted(held)} runs while the ledger is locked; "
                              f"a person's click waits sixty seconds and then fails")

    # and the model's own generate, which is the other forty-five seconds
    for node in ast.walk(tree):
        if takes_the_lock(node):
            for inner in ast.walk(node):
                if (isinstance(inner, ast.Call)
                        and getattr(inner.func, "attr", "") == "generate"
                        and getattr(getattr(inner.func, "value", None), "id", "") == "model"):
                    raise AssertionError("the image is painted while the ledger "
                                         "is locked")


def test_the_ledger_is_still_read_and_written_under_the_lock():
    """Intention: THE OTHER HALF OF THE SAME FIX. Freeing the slow middle is
    only safe if the two ends still take the lock — and if the write re-reads
    first, so a person confirming a reference mid-round keeps their answer
    instead of being overwritten by a snapshot taken a minute ago.
    """
    import inspect
    from warp2.ask.visual import VisualLearning

    # Intention (2026-10-02): the round is in parts — the read is `_weigh`, the
    # write is `_record`, and nothing in between holds the lock.
    from warp2.ask.picture_round import PictureRound
    assert "with Lock(learning.path" in inspect.getsource(PictureRound._weigh), "one lock to read"
    said = inspect.getsource(PictureRound._record)
    assert said.count("with Lock(learning.path") == 1, "one lock to write"
    after = said.split("with Lock(learning.path", 1)[1]
    assert "data = learning._load()" in after, "the write must re-read the ledger first"
    assert "learning._save(data)" in after
    for middle in (PictureRound._teach, PictureRound._practice, PictureRound._draw,
                   PictureRound._read, PictureRound._search):
        assert "Lock(" not in inspect.getsource(middle), middle.__name__


def test_a_reader_that_is_not_there_ends_the_job():
    """NO READER IS NOT A NO. Another round with nothing able to look can
    never end in a yes, and every one would search the internet and train the
    model on the strength of nobody's opinion."""
    learning = Learning([{"approved": False, "status": "reader_unavailable",
                          "image_path": "a.png", "evidence": {}, "readers": []}])
    got = Until(learning, rounds=6).make("cat")
    assert got["how"] == "no_reader"
    assert len(learning.asked) == 1


def test_a_reader_that_timed_out_buys_another_round():
    """ANDREW'S CAT, 2026-09-12.

    He asked for one fourteen minutes into a LoRA round. The nine-billion
    parameter vision model on the same machine ran out of its flat forty-five
    seconds, and that was read as "nothing can look" — so he got an unjudged
    picture after a single round. It was there. It was busy.
    """
    busy = {"approved": False, "status": "reader_busy", "image_path": "a.png",
            "evidence": {}, "missing": [], "readers": [{"name": "r1", "error": "timed out"}]}
    learning = Learning([busy, busy, hit()])
    got = Until(learning, rounds=6).make("cat")
    assert got["how"] == "approved"
    assert got["rounds"] == 3
    assert len(learning.asked) == 3


def test_a_reader_that_stays_busy_still_runs_out_of_rounds():
    """Going round again is bounded, like everything else here."""
    busy = {"approved": False, "status": "reader_busy", "image_path": "a.png",
            "evidence": {}, "missing": [], "readers": [{"name": "r1", "error": "timed out"}]}
    learning = Learning([busy])
    got = Until(learning, rounds=3).make("cat")
    assert got["how"] == "out_of_rounds"
    assert len(learning.asked) == 3


def test_the_readers_deadline_is_measured_not_picked():
    """A FIXED FORTY-FIVE SECONDS, in a tree whose deadline file opens with
    "No fixed timeouts". That constant is what cost Andrew his cat."""
    import inspect
    from warp2.ask.visual import VisualLearning

    said = inspect.getsource(VisualLearning._readers)
    assert "timeout=45" not in said
    assert "budget(READ_VERB)" in said


def test_a_read_that_answered_is_measured_and_one_that_timed_out_is_not():
    """A deadline learned from measurement only learns if somebody records the
    measurement — and a read that timed out measures the deadline, not the
    work."""
    import inspect
    from warp2.ask.visual import VisualLearning

    from warp2.ask.picture_round import PictureRound
    said = inspect.getsource(PictureRound._read)
    body = said.split("for reader in selected:", 1)[1]
    answered, failed = body.split("except Exception as exc:", 1)
    assert "observe(READ_VERB" in answered
    assert "observe(READ_VERB" not in failed.split("if measured:", 1)[0]


def test_the_stand_in_answers_everything_practice_asks_of_it():
    """A STAND-IN THAT FALLS BEHIND FAILS HERE, BY NAME, NOT FIVE TESTS LATER.

    Intention: found 2026-09-18. `practice` started calling
    `self.discover_new_subjects` on 09-15; this stand-in did not have it, and
    five tests failed with an AttributeError that said nothing about why.
    Every `self.<method>(...)` that `practice` calls must exist on the stand-in.
    """
    import ast
    import inspect
    import textwrap
    from warp2.ask.visual import VisualLearning
    tree = ast.parse(textwrap.dedent(inspect.getsource(VisualLearning.practice)))
    called = {n.func.attr for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
              and isinstance(n.func.value, ast.Name) and n.func.value.id == "self"}
    missing = sorted(name for name in called if not hasattr(Ledger, name))
    assert not missing, "the stand-in has fallen behind practice(): " + ", ".join(missing)


def test_its_own_practice_does_not_run_out_of_rounds():
    """Andrew, 2026-09-23: "it should not be able to stop until it passes."
    Past the six-round budget, the machine's own practice is still a job in
    progress, carried to the next turn — never "out_of_rounds"."""
    until = Until(Learning([missed()]), rounds=6, until_it_passes=True)
    went = until.make("bicycle", resume={"round": 6, "wanted": ["wheel"]}, at_a_time=1)
    assert went["how"] == "more_to_do"
    assert went["resume"]["round"] == 7


def test_its_own_practice_keeps_the_subject_when_no_reader_is_there():
    """Intention: no reader this turn is a turn taken, not the end of the subject."""
    until = Until(Learning([missed(status="reader_unavailable")]), until_it_passes=True)
    went = until.make("bicycle", at_a_time=1)
    assert went["how"] == "more_to_do" and went["resume"]["round"] == 1


def test_its_own_practice_still_ends_on_a_yes():
    """Intention: the reader's yes is the ending, as it always was."""
    until = Until(Learning([{"approved": True, "status": "approved", "image_path": "yes.png",
                             "score": 0.9}]), until_it_passes=True)
    assert until.make("bicycle", at_a_time=1)["how"] == "approved"


def test_one_part_at_a_time_carries_on_where_it_stopped():
    """Intention (Andrew, 2026-10-02): "split it out into more small directed
    parts". Each call runs one part, says what it did, and carries where the
    round got to; the round is judged only when its last part ends."""
    class Parted:
        def __init__(self):
            self.calls = []

        def step(self, subject, state=None, wanted=None, round_no=0):
            state = dict(state or {"round": round_no, "part": 0})
            self.calls.append((state["round"], state["part"]))
            state["part"] += 1
            report = {"subject": subject, "round": state["round"], "part": f"p{state['part']}", "seconds": 0.1}
            if state["part"] < 3:
                return state, report, None
            return state, report, {"approved": False, "status": "awaiting_reference_confirmation",
                                   "image_path": "a.png", "evidence": {"score": 0.0},
                                   "missing": ["ears"], "readers": [{"difference": "no ears"}]}
    told = []
    learning = Parted()
    until = Until(learning, rounds=6, until_it_passes=True, one_part=True, each_part=told.append)
    first = until.make("cat")
    assert first["how"] == "more_to_do" and first["resume"]["part_state"]["part"] == 1
    second = until.make("cat", resume=first["resume"])
    third = until.make("cat", resume=second["resume"])
    assert third["how"] == "more_to_do" and third["resume"] == {"round": 1, "wanted": ["ears"]}
    assert [c[1] for c in learning.calls] == [0, 1, 2] and len(told) == 3
    nxt = until.make("cat", resume=third["resume"])
    assert learning.calls[-1] == (2, 0), "the next round starts at its first part"
