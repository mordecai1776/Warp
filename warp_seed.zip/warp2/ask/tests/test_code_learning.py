# WARP2/warp2/ask/tests/test_code_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_code_learning.py
#  Used by   : pytest
#  Uses      : warp2/ask/code_learning.py
#  Description:
#    Tests for warp2/ask/code_learning.py.
#  User intention:
#    The same as the file it tests: see the header of
#    warp2/ask/code_learning.py.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest

from warp2.ask.code_learning import (
    CodeLearning,
    RecipeProver,
    CodeConcept,
    ProvenRecipe,
    ALGORITHM_DOMAINS,
    RECIPES,
)


def test_recipe_prover_astar():
    ok, msg, ms = RecipeProver.prove_astar_pathfinding()
    assert ok is True
    assert "A* successfully computed optimal obstacle-avoiding path" in msg
    assert ms > 0.0


def test_recipe_prover_cellular_automata():
    ok, msg, ms = RecipeProver.prove_cellular_automata_caves()
    assert ok is True
    assert "Cellular automata generated smoothed" in msg
    assert ms > 0.0


def test_recipe_prover_flood_fill():
    ok, msg, ms = RecipeProver.prove_flood_fill()
    assert ok is True
    assert "Flood fill accurately bounded and colored" in msg
    assert ms > 0.0


def test_recipe_prover_bresenham():
    ok, msg, ms = RecipeProver.prove_bresenham_line()
    assert ok is True
    assert "Bresenham rasterized line across" in msg
    assert ms > 0.0


def test_recipe_prover_lru_cache():
    ok, msg, ms = RecipeProver.prove_lru_cache()
    assert ok is True
    assert "LRU cache evicted least recently used key" in msg
    assert ms > 0.0


def test_recipe_prover_state_machine():
    ok, msg, ms = RecipeProver.prove_state_machine()
    assert ok is True
    assert "Finite State Machine cleanly transitioned" in msg
    assert ms > 0.0


def test_recipe_prover_dispatch():
    ok, name, msg, sig, ms = RecipeProver.prove_recipe_for("A* search algorithm")
    assert ok is True
    assert "A* Pathfinding" in name

    ok, name, msg, sig, ms = RecipeProver.prove_recipe_for("Cellular automaton")
    assert ok is True
    assert "Cellular Automata" in name

    ok, name, msg, sig, ms = RecipeProver.prove_recipe_for("Flood fill")
    assert ok is True
    assert "Flood Fill" in name

    ok, name, msg, sig, ms = RecipeProver.prove_recipe_for("Bresenham's line algorithm")
    assert ok is True
    assert "Bresenham Line" in name

    ok, name, msg, sig, ms = RecipeProver.prove_recipe_for("LRU cache")
    assert ok is True
    assert "LRU Eviction" in name

    ok, name, msg, sig, ms = RecipeProver.prove_recipe_for("State pattern")
    assert ok is True
    assert "Finite State Machine" in name

    # Intention: a topic with no recipe of its own gets none. Dijkstra was
    # "proven" by A*, and Bellman-Ford by a state machine, 367 times.
    for topic in ("Dijkstra's algorithm", "Bellman-Ford algorithm", "Trie", "anything else"):
        assert RecipeProver.prove_recipe_for(topic) is None


def test_every_recipe_topic_is_real_and_carries_its_code():
    """Intention: each table line names a real topic and a method whose code can be read."""
    topics = {t for ts in ALGORITHM_DOMAINS.values() for t in ts}
    for topic in RECIPES:
        assert topic in topics
        assert RecipeProver.recipe_source(topic).lstrip().startswith(("def ", "@"))


def test_every_code_topic_is_looked_at_once_before_any_twice(tmp_path: Path):
    """Intention: keyed by topic, so an en dash in a web title cannot trap the picker."""
    cl = CodeLearning(tmp_path / "root", tmp_path / "state")
    cl.search_online_concept = lambda topic, timeout=4.0: CodeConcept(
        name=topic.replace("-", "\u2013"), domain="computer_science", summary="s")
    topics = [t for ts in ALGORITHM_DOMAINS.values() for t in ts]
    seen = [cl.learn_pass()["topic"] for _ in topics]
    assert sorted(seen) == sorted(topics)


def test_code_learning_init_and_pick(tmp_path: Path):
    root = tmp_path / "root"
    state = tmp_path / "state"
    cl = CodeLearning(root, state)

    domain, topic = cl.pick_next_concept_to_learn()
    assert domain in ALGORITHM_DOMAINS
    assert topic in ALGORITHM_DOMAINS[domain]


def test_code_learning_learn_pass(tmp_path: Path):
    root = tmp_path / "root"
    state = tmp_path / "state"
    cl = CodeLearning(root, state)

    result = cl.learn_pass()
    assert result["status"] == "proven"
    assert result["concept"]
    assert result["recipe_name"]
    assert result["execution_time_ms"] >= 0

    # Verify files created on disk
    ledger_file = state / "knowledge" / "code_learning.json"
    assert ledger_file.is_file()
    ledger_data = json.loads(ledger_file.read_text(encoding="utf-8"))
    assert ledger_data["total_passes"] == 1
    assert len(ledger_data["concepts"]) == 1
    assert len(ledger_data["proven_recipes"]) == 1

    recipes_file = state / "knowledge" / "recipes.jsonl"
    assert recipes_file.is_file()
    lines = [json.loads(line) for line in recipes_file.read_text(encoding="utf-8").strip().splitlines()]
    assert len(lines) == 1
    assert lines[0]["proven"] is True


def test_code_learning_search_online_mocked(tmp_path: Path):
    root = tmp_path / "root"
    state = tmp_path / "state"
    cl = CodeLearning(root, state)

    mock_resp_data = {
        "title": "A* search algorithm",
        "extract": "A* is a graph traversal and path search algorithm.",
        "content_urls": {"desktop": {"page": "https://en.wikipedia.org/wiki/A*_search_algorithm"}},
    }

    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(mock_resp_data).encode("utf-8")
    mock_resp.__enter__.return_value = mock_resp

    with patch("urllib.request.urlopen", return_value=mock_resp):
        concept = cl.search_online_concept("A* search algorithm")
        assert concept is not None
        assert concept.name == "A* search algorithm"
        assert "graph traversal" in concept.summary
        assert concept.source_url == "https://en.wikipedia.org/wiki/A*_search_algorithm"
