# WARP2/warp2/ask/tests/test_math_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_math_learning.py
#  Used by   : pytest.
#  Uses      : warp2/ask/math_learning.py.
#  Description:
#    Every hand-written maths proof holds and carries its own code; every
#    proof name has its method; a pass proves a topic with a proof, says
#    "no_proof" for one without, and keeps its own ledger apart from logic's.
#  User intention (Andrew, 2026-10-08):
#    "we need to add in math in the same way as logic is in there."
# ============================================================================
from __future__ import annotations

import json

import pytest

from warp2.ask.math_learning import (MATH_DOMAINS, PROOF_METHODS, TOPIC_PROOFS, MathLearning,
                                     MathProver)


@pytest.mark.parametrize("name", sorted(PROOF_METHODS))
def test_every_hand_written_proof_holds(name):
    """Intention: a proof in the table that does not hold would teach a wrong thing as proven."""
    ok, msg, ms = PROOF_METHODS[name]()
    assert ok is True, msg
    assert ms > 0.0


def test_the_proof_table_is_whole():
    """Intention: every topic's proof has a method, and every proven topic is a real topic."""
    topics = {t for group in MATH_DOMAINS.values() for t in group}
    assert set(TOPIC_PROOFS) <= topics
    assert set(TOPIC_PROOFS.values()) == set(PROOF_METHODS)
    assert topics - set(TOPIC_PROOFS), "some topics must be left for the build lane"


def test_a_passed_proof_carries_its_own_code():
    """Intention: the proof's code is the training text."""
    assert "def prove_prime_sieve" in MathProver.proof_source("Prime Sieve Verifier")
    assert MathProver.proof_source("not a proof") == ""
    assert MathProver.prove_math_for("Derivative") is None


def _learner(tmp_path, monkeypatch, topic):
    """Intention: a learner that does not reach the web and is given its topic."""
    monkeypatch.setattr(MathLearning, "search_online_concept", lambda self, t, timeout=4.0: None)
    learner = MathLearning(tmp_path / "root", tmp_path / "state")
    monkeypatch.setattr(learner, "pick_next_concept_to_learn", lambda: ("algebra", topic))
    return learner


def test_a_topic_with_a_proof_is_proven(tmp_path, monkeypatch):
    """Intention: proven, with the proof's name, its code and its message."""
    got = _learner(tmp_path, monkeypatch, "Euclidean algorithm").learn_pass()
    assert got["status"] == "proven"
    assert got["proof_name"] == "Euclidean GCD and Bezout Prover"
    assert "def prove_euclid_gcd" in got["proof_text"]
    rows = (tmp_path / "state" / "knowledge" / "math_proofs.jsonl").read_text(encoding="utf-8")
    assert json.loads(rows.splitlines()[-1])["proven"] is True


def test_a_topic_with_no_proof_says_so(tmp_path, monkeypatch):
    """Intention: never proven by some other proof's pass — handed back to be built."""
    got = _learner(tmp_path, monkeypatch, "Taylor series").learn_pass()
    assert got["status"] == "no_proof" and got["proof_name"] == "" and got["proof_text"] == ""


def test_the_ledger_is_its_own(tmp_path, monkeypatch):
    """Intention: maths never writes over the logic ledger."""
    _learner(tmp_path, monkeypatch, "Geometric series").learn_pass()
    knowledge = tmp_path / "state" / "knowledge"
    assert (knowledge / "math_learning.json").is_file()
    assert not (knowledge / "logic_learning.json").exists()


def test_topics_go_round_never_seen_first(tmp_path, monkeypatch):
    """Intention: every topic is looked at before any is looked at twice."""
    monkeypatch.setattr(MathLearning, "search_online_concept", lambda self, t, timeout=4.0: None)
    learner = MathLearning(tmp_path / "root", tmp_path / "state")
    count = sum(len(group) for group in MATH_DOMAINS.values())
    seen = [learner.learn_pass()["topic"] for _ in range(count)]
    assert len(set(seen)) == count
