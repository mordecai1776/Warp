# WARP2/warp2/ask/tests/test_online_concepts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_online_concepts.py
#  Used by   : pytest
#  Uses      : warp2/ask/online_concepts.py, warp2/ask/visual.py
#  Description:
#    Tests for warp2/ask/online_concepts.py, warp2/ask/visual.py.
#  User intention:
#    The same as the file it tests: see the header of
#    warp2/ask/online_concepts.py and warp2/ask/visual.py.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest

from warp2.ask.online_concepts import OnlineConceptSearcher, OnlineConcept, _clean_subject_tag
from warp2.ask.visual import VisualLearning, DIRECTIONAL_DOMAINS


def test_clean_subject_tag():
    assert _clean_subject_tag("Barn owl (bird)") == "owl"
    assert _clean_subject_tag("Great horned owl") == "owl"
    # Intention (2026-09-24): a title with a number is an event, not a thing.
    assert _clean_subject_tag("1952 Football Championship") == ""
    assert _clean_subject_tag("Wrestling at the 2004 Summer Olympics - Men's 57 kg") == ""
    assert _clean_subject_tag("Wrestling at the") == ""
    assert _clean_subject_tag("Golden Eagle") == "eagle"
    assert _clean_subject_tag("") == "object"


def test_fallback_concepts_across_domains():
    searcher = OnlineConceptSearcher()
    concepts = searcher._fallback_concepts(5)
    assert len(concepts) == 5
    for c in concepts:
        assert isinstance(c, OnlineConcept)
        assert c.subject
        assert c.title
        assert c.source == "taxonomy_fallback"

    # Specific category hint
    animals = searcher._fallback_concepts(3, query_hint="animals")
    assert len(animals) == 3
    for a in animals:
        assert a.subject in DIRECTIONAL_DOMAINS["animals"]


def test_fetch_random_concepts_mocked():
    mock_payload = {
        "query": {
            "pages": {
                "101": {
                    "title": "Red fox (Vulpes vulpes)",
                    "extract": "The red fox is the largest of the true foxes and one of the most widely distributed members of the order Carnivora.",
                    "thumbnail": {"source": "https://upload.wikimedia.org/wikipedia/commons/thumb/fox.jpg"},
                    "fullurl": "https://en.wikipedia.org/wiki/Red_fox",
                },
                "102": {
                    "title": "Medieval castle",
                    "extract": "A castle is a type of fortified structure built during the Middle Ages predominantly by the nobility.",
                    "fullurl": "https://en.wikipedia.org/wiki/Castle",
                }
            }
        }
    }

    searcher = OnlineConceptSearcher()
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(mock_payload).encode("utf-8")
    mock_resp.__enter__.return_value = mock_resp

    with patch("urllib.request.urlopen", return_value=mock_resp):
        concepts = searcher.fetch_random_concepts(count=2)

    assert len(concepts) == 2
    assert concepts[0].subject == "fox"
    assert concepts[0].image_url == "https://upload.wikimedia.org/wikipedia/commons/thumb/fox.jpg"
    assert concepts[1].subject == "castle"
    assert concepts[1].image_url is None


def test_visual_learning_discover_new_subjects(tmp_path: Path):
    vl = VisualLearning(root=tmp_path, state=tmp_path / "state")
    data = {"subjects": {"cat": "ready"}, "references": {}}

    mock_concepts = [
        OnlineConcept(
            title="Great horned owl",
            subject="owl",
            summary="A large owl native to the Americas.",
            image_url=None,
            page_url="https://en.wikipedia.org/wiki/Owl",
        )
    ]

    with patch.object(OnlineConceptSearcher, "fetch_random_concepts", return_value=mock_concepts):
        enrolled = vl.discover_new_subjects(data, count=2, search_online=True)

    assert "owl" in enrolled
    assert len(enrolled) == 2
    for s in enrolled:
        assert s in data["subjects"]
        assert data["subjects"][s] == "needs_references"
