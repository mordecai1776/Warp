# WARP2/warp2/ask/tests/test_images_stay_out_of_the_chat.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_images_stay_out_of_the_chat.py
#  Used by   : pytest.
#  Uses      : warp2/ask/thread.py (image_feed), warp2/ask/window.py.
#  Description:
#    The machine's own image practice is reported to the image feed, not the
#    conversation, and the window takes it from there into the Confirmations
#    panel only.
#  User intention (Andrew, 2026-09-18):
#    "the image stuff should not go in the conversation unless I have asked
#    for an image in the conversation."
# ============================================================================
from __future__ import annotations

from pathlib import Path

from warp2.ask.thread import WARP, Thread, image_feed
from warp2.ask.window import ActionCentre


def test_practice_reports_go_to_the_feed_and_the_panel_not_the_chat(tmp_path):
    """Intention: the chat stays empty; the found reference waits in the panel."""
    state = tmp_path / "state"
    ref = tmp_path / "fox_ref.png"
    ref.write_bytes(b"not really a png")
    image_feed(state).add(WARP, "Centering practice: fox — rejected", subject="fox",
                          references=[str(ref)],
                          reference_reviews=[{"path": str(ref), "subject": "fox", "id": "r1"}])
    assert Thread(state).recent() == []
    centre = ActionCentre(state, root_dir=tmp_path)
    assert centre._take_image_feed() == 1
    held = centre.pending_image_confirmations[str(ref.resolve())]
    assert held["is_reference"] is True and held["review"]["subject"] == "fox"
    assert centre._take_image_feed() == 0


def test_a_picture_viewer_needs_a_screen(tmp_path):
    """Intention: with no window there is nothing to open, and nothing breaks."""
    centre = ActionCentre(tmp_path / "state", root_dir=tmp_path)
    assert centre._view_image(tmp_path / "missing.png") is None
