# WARP2/warp2/ask/tests/test_normal_resolution_and_display.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_normal_resolution_and_display.py
#  Used by   : pytest.
#  Uses      : warp2/ask/picture_round.py,
#              projects/behemoth_eye/eye/organic_scale.py.
#  Description:
#    Tests for normal resolution progression, 1:1 native canvas output,
#    resolution-aware candidate drawing in picture_round, and window display.
#  User intention (Andrew, 2026-10-05):
#    "also we need the picture it shows be the resolution of what it makes
#    and have it go all the way up to normal resolutions."
# ============================================================================
from __future__ import annotations

from pathlib import Path
import numpy as np
from PIL import Image

import warp2.ask.picture_round as picture_round
from projects.behemoth_eye.eye.organic_scale import NORMAL_RUNGS, ALL_RUNGS, OrganicScaleScheduler


def test_organic_scale_scheduler_includes_normal_resolutions():
    """Organic scale scheduler supports normal resolutions up to 512."""
    assert 192 in NORMAL_RUNGS
    assert 256 in NORMAL_RUNGS
    assert 384 in NORMAL_RUNGS
    assert 512 in NORMAL_RUNGS
    assert all(r in ALL_RUNGS for r in NORMAL_RUNGS)

    scheduler = OrganicScaleScheduler()
    # At early steps without allow_normal, it stays in base
    size_early = scheduler.choose_size(trials={}, errors={}, step=1, allow_extended=False, allow_normal=False)
    assert size_early in (32, 48, 64, 128)

    # With allow_normal enabled, it can sample normal rungs
    sizes = {scheduler.choose_size(trials={str(r): 2 for r in ALL_RUNGS}, errors={}, step=15, allow_extended=True, allow_normal=True)
             for _ in range(50)}
    assert any(s in NORMAL_RUNGS for s in sizes), f"Expected normal resolutions in {sizes}"


def test_native_resolution_saved_without_artificial_resizing(tmp_path):
    """The saved image must match the exact dimensions painted without forced 256 upscaling."""
    from projects.behemoth_eye.eye.warp_pictures import EyePictures

    eye_pics = EyePictures(tmp_path / "state", longest=128)
    dest_128 = tmp_path / "test_128.png"
    eye_pics.generate("cube", dest_128, seed=42, wide=128, high=128)
    assert dest_128.is_file()
    with Image.open(dest_128) as img:
        assert img.size == (128, 128), f"Expected native (128, 128), got {img.size}"

    dest_192 = tmp_path / "test_192.png"
    eye_pics.generate("cube", dest_192, seed=42, wide=192, high=192)
    assert dest_192.is_file()
    with Image.open(dest_192) as img:
        assert img.size == (192, 192), f"Expected native (192, 192), got {img.size}"


def test_picture_round_draw_uses_measure_size_and_plan_fallback(tmp_path, monkeypatch):
    """When state['size'] is empty, _draw uses measure_size or painter_plan size."""
    class MockModel:
        def __init__(self):
            self.drawn = []
        def generate(self, tag, destination, seed=0, **dimensions):
            self.drawn.append(dimensions)
            Image.new("RGB", (dimensions.get("wide", 64), dimensions.get("high", 64))).save(destination)
            return {}
        def subject_of(self, tag):
            return "cat"

    model = MockModel()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)

    class DummyLearning:
        def __init__(self, p):
            self.home = p
            self.state = p
        def _samples_out(self, holder):
            pass

    learning = DummyLearning(tmp_path)
    round_ = picture_round.PictureRound(learning)

    # Case 1: measure_size in state
    state1 = {
        "subject": "cat",
        "round": 2,
        "part": "draw",
        "size": [],
        "measure_size": [192, 192],
    }
    round_._draw(state1)
    assert model.drawn[-1] == {"wide": 192, "high": 192}

    # Case 2: painter_plan in state
    state2 = {
        "subject": "cat",
        "round": 3,
        "part": "draw",
        "size": [],
        "painter_plan": {"training_size": 256, "validation_paths": []},
    }
    round_._draw(state2)
    assert model.drawn[-1] == {"wide": 256, "high": 256}


def test_window_view_image_displays_native_resolution(tmp_path):
    """ActionCentre._view_image sets title with native resolution and adds 1:1 / fit controls."""
    from warp2.ask.window import ActionCentre
    import tkinter as tk

    try:
        root = tk.Tk()
        root.withdraw()
    except Exception:
        # Headless environment without display server
        return

    try:
        centre = ActionCentre(tmp_path / "state", root_dir=Path("."))
        centre.root = root

        # Create a test image at 192x128
        img_path = tmp_path / "sample_192.png"
        Image.new("RGB", (192, 128), color=(100, 150, 200)).save(img_path)

        win = centre._view_image(img_path)
        assert win is not None
        assert "192×128 px" in win.title()
        win.destroy()
    finally:
        root.destroy()
