# WARP2/warp2/ask/tests/test_what_still_asked_the_disk_asks_the_small_form.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_what_still_asked_the_disk_asks_the_small_form.py
#  Used by   : pytest.
#  Uses      : warp2/ask/media.py (into_kept), warp2/ask/dedup.py
#              (ImageDeduplicator.scan_directories, find_duplicates),
#              warp2/tags/media/{pictures,door,originals,state_walk}.py;
#              numpy, PIL.
#  Description:
#    The last places that asked the disk about a picture, each shown on a
#    picture whose original has gone to deep storage:
#      - a confirmed picture is put into the kept set from its own bytes when
#        it has no file to move, and moved as before when it has; a name
#        already in the kept set is never written over;
#      - the duplicate finder still looks at a folder's sent pictures;
#      - the kept set is walked by the keeping turn, so its pictures are
#        kept small;
#      - a picture kept small where it lay takes its small form with it into
#        the kept set (BUILD_LOG 1606c);
#      - pictures opened from FILES are counted by their folder, said from
#        the state folder, so what does not read the small form yet is found
#        by its number; a new picture in a folder the walk keeps is kept as
#        it is opened (BUILD_LOG 1610c), so what is counted so is a folder
#        the walk does not keep.
#  User intention (Andrew, 2026-11-13 10:06): "Stop it do all of it". Before:
#    "everything should run from dehydrated forms". BUILD_LOG 1601c.
# ============================================================================
"""Intention: the confirmations, the duplicate finder and the keeping walk work on pictures the small form holds."""
from pathlib import Path

import numpy as np
from PIL import Image

import projects.behemoth_eye.eye.heads.readers  # noqa: F401  (this part carries the Eye's reader, as a lesson does)
from warp2.tags.media import pictures
from warp2.tags.media.door import media_door_of, media_home
from warp2.tags.media.originals import MediaOriginals
from warp2.tags.media.state_walk import StatePictures


def _picture(path: Path, shade: int = 0) -> bytes:
    """Intention: one small picture written at this path; its file's bytes."""
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = (np.arange(64, dtype=np.uint8)[:, None, None] + shade) % 255
    Image.fromarray(np.tile(rows, (1, 64, 3)).astype(np.uint8), mode="RGB").save(path)
    return path.read_bytes()


def _sent(state: Path, tmp_path: Path, picture: Path) -> None:
    """Intention: this picture kept small and its original sent to deep storage - no file of it left in the warp."""
    door = media_door_of(media_home(state))
    door.keep_picture(picture, subject="hypersim")
    originals = MediaOriginals(door, state)
    originals.set(folder=tmp_path / "deep", ready=[name for name, _s, _f, _d in StatePictures(state).collections()])
    assert originals.send_ready()["sent"] >= 1 and not picture.exists() and pictures.is_there(picture)


def test_a_confirmed_picture_goes_into_the_kept_set_with_or_without_its_file(tmp_path: Path):
    """Intention: moved when it has a file; written from its own bytes when its original was sent; never over a name."""
    from warp2.ask.media import into_kept, kept_home
    state = tmp_path / "state"
    loose = state / "images" / "made.png"
    was_loose = _picture(loose, shade=7)
    there = into_kept(state, loose)
    assert there == kept_home(state) / "made.png" and there.read_bytes() == was_loose and not loose.exists()
    sent = state / "visual_learning" / "real_world" / "hypersim" / "a.png"
    was_sent = _picture(sent)
    _sent(state, tmp_path, sent)
    kept = into_kept(state, sent)
    assert kept == kept_home(state) / "a.png" and kept.read_bytes() == was_sent, "its own bytes, though it had no file"
    other = state / "images" / "elsewhere" / "a.png"
    was_other = _picture(other, shade=40)
    beside = into_kept(state, other)
    assert beside.parent == kept_home(state) and beside.name != "a.png" and beside.read_bytes() == was_other
    assert kept.read_bytes() == was_sent, "the one already kept was not written over"
    assert into_kept(state, state / "images" / "never.png") is None
    media_door_of(media_home(state)).close()


def test_a_moved_picture_takes_its_small_form_with_it(tmp_path: Path):
    """Intention (BUILD_LOG 1606c): a picture kept small where it lay, then confirmed: its small form is under the name
    it has now - the place it left says no picture is there, and the one in the kept set is read from the small form
    at once, with no keeping turn in between and nothing kept a second time."""
    from warp2.ask.media import into_kept, kept_home
    state = tmp_path / "state"
    made = state / "images" / "references" / "fox.png"
    was = _picture(made, shade=11)
    door = media_door_of(media_home(state))
    door.keep_picture(made, subject="fox")
    held = door.book.count()
    said = door.read_media(made)[1]["id"]
    there = into_kept(state, made)
    assert there == kept_home(state) / "fox.png" and there.read_bytes() == was
    assert not door.has(made) and not pictures.is_there(made), "the place it left says nothing is there"
    assert door.has(there) and door.book.count() == held, "the same tensors, under the name it has now"
    kept = door.read_media(there)[1]
    assert kept["id"] == door.said_from_the_root(there) != said
    assert kept["dehydrated"][0] == ["s", "media:" + door.item_file(there).stem], "its tag tree names it as it is now"
    pictures.write_counts()
    before = pictures.read_counts(door.home)
    with pictures.open_picture(there) as opened:
        assert opened.size == (64, 64)
    pictures.write_counts()
    after = pictures.read_counts(door.home)
    assert after["from_small"] == before["from_small"] + 1 and after["from_files"] == before["from_files"]
    assert door.ingest_state_media(state)["pictures_kept"] == 0, "it is not kept a second time"
    assert not pictures.moved(made, there), "nothing to take along twice"
    door.close()


def test_the_duplicate_finder_looks_at_a_folders_sent_pictures(tmp_path: Path):
    """Intention: a picture whose original was sent is still found in its folder, and found to be a copy of a file."""
    from warp2.ask.dedup import ImageDeduplicator
    state = tmp_path / "state"
    sent = state / "visual_learning" / "real_world" / "hypersim" / "a.png"
    was = _picture(sent)
    copy = state / "images" / "copy_of_a.png"
    copy.parent.mkdir(parents=True)
    copy.write_bytes(was)
    _sent(state, tmp_path, sent)
    finder = ImageDeduplicator()
    found = finder.scan_directories([sent.parent])
    assert [Path(row["path"]).name for row in found] == ["a.png"] and found[0]["size_bytes"] == len(was)
    report = finder.find_duplicates(dirs=[sent.parent, copy.parent])
    assert report["has_duplicates"] and report["duplicate_count"] == 1
    media_door_of(media_home(state)).close()


def test_the_kept_set_is_walked_and_file_reads_are_counted_by_folder(tmp_path: Path):
    """Intention: the keeping walk reaches images/kept. A picture in a folder the walk does NOT keep is counted as
    opened from a file, under its folder's name. BUILD_LOG 1610c: a new picture in the kept set is kept as it is
    opened - read from the small form at once - and the next keeping turn joins it and keeps nothing twice."""
    state = tmp_path / "state"
    kept = state / "images" / "kept" / "cat.png"
    loose = state / "images" / "working" / "draft.png"
    _picture(kept)
    _picture(loose, shade=30)
    door = media_door_of(media_home(state))
    door.home.mkdir(parents=True, exist_ok=True)   # the small form's folder is there, as in a warp that has kept any
    assert ("kept_images", "kept_images", state / "images" / "kept", True) in StatePictures(state).collections()
    for picture in (loose, kept):
        with pictures.open_picture(picture) as opened:
            assert opened.size == (64, 64)
    pictures.write_counts()
    assert pictures.files_from(door.home) == {"images/working": 1}
    assert pictures.read_counts(door.home) == {"from_small": 1, "from_files": 1}
    assert pictures.kept_as_opened(door.home) == 1
    said = door.ingest_state_media(state)
    assert said["pictures_kept"] == 0 and said["joined_after_opening"] == 1
    with pictures.open_picture(kept) as opened:
        assert opened.size == (64, 64)
    pictures.write_counts()
    assert pictures.read_counts(door.home) == {"from_small": 2, "from_files": 1}
    assert pictures.files_from(door.home) == {"images/working": 1}
    door.close()
