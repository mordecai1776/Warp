# WARP2/warp2/ask/tests/test_blender_held_apart.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_blender_held_apart.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/blender_held_apart.py, warp2/ask/all_pictures.py,
#              projects/behemoth_eye/eye/errors/faint_held_apart.py; PIL.
#  Description:
#    The fixed Blender faint set: five pictures, one per shape, from the end
#    of the list; kept on disk so it never moves; never handed out for
#    teaching; handed out for the faint reading; nothing held out while the
#    source is small; and the faint flags filed per frame by source.
#  User intention (Andrew, 2026-10-27 23:09): "we need to leave some parts
#    unknown so we dont have it feed weird answers at times". BUILD_LOG 855.
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from warp2.ask.all_pictures import AllPictures  # noqa: E402
from warp2.ask.blender_held_apart import FEWEST  # noqa: E402
from projects.behemoth_eye.eye.errors.faint_held_apart import FaintHeldApart  # noqa: E402

SHAPES = ("cone", "cube", "sphere", "cylinder", "monkey_head", "torus")


def _blender(state: Path, count: int) -> list:
    """Intention: `count` small Blender renders named as the real ones are, shapes in turn."""
    folder = state / "datasets/local/blender/set"
    folder.mkdir(parents=True, exist_ok=True)
    names = []
    for k in range(count):
        name = f"random_{k:04d}_{SHAPES[k % len(SHAPES)]}_red_matte.png"
        Image.fromarray(np.full((20, 20, 3), 100, dtype=np.uint8)).save(folder / name)
        names.append(f"set/{name}")
    return names


def test_five_one_per_shape_from_the_end_never_taught(tmp_path):
    """Intention: the set is 5 pictures of 5 different shapes from the list's end; teaching never hands one out."""
    state = tmp_path / "state"
    _blender(state, FEWEST + 20)
    pictures = AllPictures(state, tmp_path / "home")
    held = [name for _, _, name in pictures.held_apart_blender(5)]
    assert len(held) == 5 and all("never taught" in name for name in held)
    shapes = {name.split("_", 2)[2].rsplit("_red", 1)[0] for name in held}
    assert len(shapes) == 5
    assert held[0].startswith(f"blender set/random_{FEWEST + 19:04d}")
    taught = {pictures.next()[2] for _ in range(4 * (FEWEST + 20))}
    assert not any(name.replace(" (never taught)", "") in taught for name in held)


def test_the_set_is_kept_and_never_moves(tmp_path):
    """Intention: chosen once and kept on disk; more pictures joining later do not move it."""
    state = tmp_path / "state"
    _blender(state, FEWEST + 10)
    first = [n for _, _, n in AllPictures(state, tmp_path / "home").held_apart_blender(5)]
    _blender(state, FEWEST + 40)
    (tmp_path / "home/lists/blender.json").unlink()
    again = [n for _, _, n in AllPictures(state, tmp_path / "home").held_apart_blender(5)]
    assert first == again and (tmp_path / "home/blender_faint_set.json").is_file()


def test_nothing_held_out_while_the_source_is_small(tmp_path):
    """Intention: a small Blender source keeps every picture for teaching."""
    state = tmp_path / "state"
    _blender(state, 7)
    pictures = AllPictures(state, tmp_path / "home")
    assert pictures.held_apart_blender(5) == []
    assert len(pictures.blender.source.pictures()) == 7


def test_faint_flags_per_frame_by_source():
    """Intention: each frame flagged faint under the mark, its own numbers kept, labelled by source; thin when few."""
    measured = {"frames": [{"frame": "a", "had": True, "off_shown": 0.01, "off_corrected": 0.008},
                           {"frame": "b", "had": True, "off_shown": 0.05, "off_corrected": 0.06},
                           {"frame": "c", "had": False}], "avg_off_shown": 0.03, "avg_off_corrected": 0.034}
    out = FaintHeldApart.of_source("blender", measured, 0.02)
    assert out["source"] == "blender" and out["faint"] == 1 and out["had"] == 2
    assert [r["faint"] for r in out["frames"]] == [True, False, None]
    assert out["helped"] == 1 and out["made_worse"] == 1 and "thin" in out["said"]
    assert FaintHeldApart.of_source("blender", measured, None)["frames"][0]["faint"] is None
