# WARP2/warp2/ask/tests/test_inbox_same_tick.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_inbox_same_tick.py
#  Used by   : pytest.
#  Uses      : warp2/ask/inbox.py.
#  Description:
#    The same ask made twice in one clock tick is kept as two asks.
#  User intention (Andrew, 2026-10-08): "check the old finished test" — the
#    Windows failure where a second "cat" overwrote the first.
# ============================================================================
from __future__ import annotations

from warp2.ask.inbox import IMAGE, Inbox


def test_two_identical_asks_in_one_tick_are_both_kept(tmp_path, monkeypatch):
    """Intention: the clock frozen, as a Windows tick is; both asks still wait."""
    import warp2.ask.inbox as inbox
    monkeypatch.setattr(inbox, "now_iso", lambda: "2026-10-08T21:00:00.000000+00:00")
    box = Inbox(tmp_path / "state")
    first = box.put(IMAGE, said="cat", about="project:centering_image")
    second = box.put(IMAGE, said="cat", about="project:centering_image")
    assert first["id"] != second["id"]
    assert len(box.waiting()) == 2
