# WARP2/warp2/ask/tests/test_video_and_search_go_through_the_loop.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_video_and_search_go_through_the_loop.py
#  Used by   : pytest.
#  Uses      : warp2/ask/window.py (ActionCentre), warp2/ask/inbox.py,
#              warp2/ask/taking.py, warp2/work/side/asked.py, warp2/work/loop.py,
#              warp2/ask/thread.py, warp2/ask/media.py (stubbed).
#  Description:
#    Asking for a video or a search & research in the window only adds it to
#    the work; the loop makes it on its own turn and shows it in the thread.
#  User intention (Andrew, 2026-09-18): window actions add to the work instead
#    of acting like a trigger. 2026-10-09, "ok lets get it done" — fix 3.7 of
#    claude/warp2_fix_plan_2026_10_09.md (check B10).
# ============================================================================
from __future__ import annotations

import pytest

import warp2.ask.media as media
from warp2.ask.inbox import RESEARCH, VIDEO, Inbox


class _Said:
    """Intention: the typing box, holding one line."""

    def __init__(self, text):
        self.text = text

    def get(self, *a):
        return self.text

    def delete(self, *a):
        self.text = ""


@pytest.fixture
def nothing_at_the_click(monkeypatch):
    """Intention: making a video or researching at the click fails the test."""
    def _no(*a, **k):
        raise AssertionError("made at the click")
    monkeypatch.setattr(media, "make_project_video", _no)
    monkeypatch.setattr(media, "search_and_research_subject", _no)


def _centre(tmp_path, said=""):
    """Intention: the window's logic with no window."""
    from warp2.ask.window import ActionCentre
    centre = ActionCentre(tmp_path / "state", root_dir=tmp_path)
    centre.said = _Said(said)
    return centre


def _kinds(tmp_path):
    """Intention: what the inbox now holds, by kind and words."""
    return [(row["kind"], row["said"]) for row in Inbox(tmp_path / "state").waiting()]


def test_asking_for_a_video_in_the_chat_adds_it_to_the_work(tmp_path, nothing_at_the_click):
    """Intention: check B10 — a typed video ask generated and trained in the window."""
    _centre(tmp_path, "make a video of a cat").send()
    assert (VIDEO, "cat") in _kinds(tmp_path)


def test_the_video_button_adds_it_to_the_work(tmp_path, nothing_at_the_click):
    """Intention: check B10 — the Make Video button did the same."""
    _centre(tmp_path, "a cat").generate_video_action()
    assert (VIDEO, "cat") in _kinds(tmp_path)


def test_search_and_research_adds_it_to_the_work(tmp_path, nothing_at_the_click):
    """Intention: check B10 — search & research ran at the click."""
    _centre(tmp_path).search_research_action("/search cat")
    assert (RESEARCH, "cat") in _kinds(tmp_path)


def _loop_takes(tmp_path, monkeypatch, kind):
    """Intention: one ask of `kind` put in, taken, and the asked step run once in this process; the thread's last turn."""
    from warp2.ask.thread import Thread
    from warp2.work.cadence import Cadence
    from warp2.work.loop import Loop
    from warp2.work.side.turns import SideTurns
    monkeypatch.setenv("WARP2_ASKED_INLINE", "1")
    root = tmp_path / "tree"
    (root / "pkg").mkdir(parents=True)
    (root / "pkg" / "thing.py").write_text("# Intention: x.\ndef hold(n):\n    return n\n", encoding="utf-8")
    state = tmp_path / "state"
    (state / "centering_image").mkdir(parents=True)
    machine = Loop(root, state, run_id="media")
    try:
        machine.projects.open("centering_image", intention="makes pictures", source="test")
        Inbox(state).put(kind, said="cat", about="project:centering_image")
        machine.taking.take()
        cadence = Cadence(share=1.0)
        cadence.due = lambda verb: False
        done = SideTurns(machine, score=200).take(cadence)
    finally:
        machine.close()
    return done["value"], Thread(state).recent()[-1]


def test_the_loop_makes_the_asked_video(tmp_path, monkeypatch):
    """Intention: the video is made on the loop's turn and shown in the thread."""
    clip = tmp_path / "cat.gif"
    clip.write_bytes(b"GIF89a")
    monkeypatch.setattr(media, "make_project_video",
                        lambda root, state, subject, **k: {"video_path": str(clip), "trained_refs": 0})
    value, last = _loop_takes(tmp_path, monkeypatch, VIDEO)
    assert value["done"] and last.get("video") == str(clip)


def test_the_loop_does_the_asked_search(tmp_path, monkeypatch):
    """Intention: the search is made on the loop's turn and its references shown for review."""
    found = tmp_path / "found.png"
    found.write_bytes(b"x")
    monkeypatch.setattr(media, "search_and_research_subject", lambda root, state, subject, **k: {
        "results": [{"image_path": str(found), "id": "r1", "reader_score": 0.8, "reader_verdict": "verified"}],
        "providers_used": ["commons"], "concepts_discovered": []})
    value, last = _loop_takes(tmp_path, monkeypatch, RESEARCH)
    assert value["done"] and [r["id"] for r in last.get("reference_reviews")] == ["r1"]
