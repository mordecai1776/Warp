# WARP2/warp2/ask/tests/test_picture_judge.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_picture_judge.py
#  Used by   : pytest.
#  Uses      : warp2/ask/picture_round.py (PictureRound._judge, _held_before,
#              _HELD) with a stand-in picture model; no Eye, no GPU.
#  Description:
#    The judge part: a round that left the drawing worse than at its start
#    puts the painter back when the held one draws better now; a round that
#    left it better (or equal) keeps it; a round resumed with nothing held is
#    only measured; a model that cannot be measured is passed through.
#  User intention (Andrew, 2026-10-02): "we need to make sure that everything
#    does steady improvements".
# ============================================================================
from __future__ import annotations

import warp2.ask.picture_round as picture_round
from warp2.ask.picture_round import PictureRound


class Learning:
    """Intention: just what the judge touches — the state folder and a checkpoint counter."""
    def __init__(self, tmp_path):
        self.state = tmp_path
        self.saved = 0

    def _checkpoint(self, model):
        self.saved += 1


class Painting:
    """Intention: a picture model whose painter is a number (its drawing error with the Eye as it is now)."""
    def __init__(self, error):
        self.error = error

    def draw_error(self, tag, paths):
        return self.error if paths else None

    def hold_painter(self):
        return self.error

    def put_back_painter(self, held):
        self.error = held


def _round(tmp_path, model, monkeypatch):
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)
    picture_round._HELD.clear()
    learning = Learning(tmp_path)
    state = {"subject": "cat", "tag": "cat", "measured_on": ["p.png"], "part": "judge"}
    state["error_before"] = picture_round._held_before(learning, state)
    return PictureRound(learning), learning, state


def test_a_round_that_made_drawing_worse_puts_the_painter_back(tmp_path, monkeypatch):
    model = Painting(0.04)
    round_, learning, state = _round(tmp_path, model, monkeypatch)
    model.error = 0.06
    said = round_._judge(state)
    assert model.error == 0.04 and state["error_after"] == 0.04 and learning.saved == 1
    assert "put back" in said["said"] and state["part"] == "draw" and not picture_round._HELD


def test_a_round_that_made_drawing_better_keeps_it(tmp_path, monkeypatch):
    model = Painting(0.04)
    round_, learning, state = _round(tmp_path, model, monkeypatch)
    model.error = 0.03
    said = round_._judge(state)
    assert model.error == 0.03 and learning.saved == 0 and "0.04 -> 0.03" in said["said"]


def test_a_held_painter_that_is_no_better_now_is_not_put_back(tmp_path, monkeypatch):
    class Shifted(Painting):
        """Intention: the Eye moved, so the held painter now draws worse than the taught one."""
        def put_back_painter(self, held):
            self.error = held + 0.05 if held == 0.04 else held
    model = Shifted(0.04)
    round_, learning, state = _round(tmp_path, model, monkeypatch)
    model.error = 0.06
    said = round_._judge(state)
    assert model.error == 0.06 and "kept" in said["said"] and learning.saved == 0


def test_a_resumed_round_restores_the_durable_held_painter(tmp_path, monkeypatch):
    model = Painting(0.04)
    round_, learning, state = _round(tmp_path, model, monkeypatch)
    picture_round._HELD.clear()
    model.error = 0.06
    said = round_._judge(state)
    assert model.error == 0.04 and "put back" in said["said"] and state["part"] == "draw"
    assert not list((tmp_path / "transactions").glob("painter-round-*.bin"))


def test_a_model_that_cannot_be_measured_goes_straight_to_draw(tmp_path, monkeypatch):
    monkeypatch.setattr(picture_round, "_model", lambda learning: object())
    state = {"subject": "cat", "part": "judge"}
    assert picture_round._held_before(Learning(tmp_path), state) is None
    said = PictureRound(Learning(tmp_path))._judge(state)
    assert state["part"] == "draw" and "cannot be measured" in said["said"]


class Two:
    """Intention: a picture model with two painters, each a number (its drawing error now), and the best drawing so far kept apart."""
    def __init__(self, pop, plain):
        self.errors = {"pop": pop, "plain": plain}
        self.warp = type("Warp", (), {"drawing": "pop", "best_error": None})()
        self.best = None

    def draw_errors(self, tag, paths, size=None):
        return {**self.errors, **({"best": self.best} if self.best is not None else {})}

    def draw_error(self, tag, paths, size=None):
        return self.errors[self.warp.drawing]

    def hold_painter(self):
        raise AssertionError("the Eye's painters are never held")

    def choose_painter(self, errors):
        learners = {k: v for k, v in errors.items() if k != "best"}
        closest = min(learners, key=learners.get)
        if errors.get("best") is None or learners[closest] < errors["best"]:
            self.best, self.warp.drawing, self.warp.best_error = learners[closest], closest, learners[closest]
        else:
            self.warp.best_error = errors["best"]
        return self.warp.drawing


def test_painters_keep_their_lessons_and_the_best_drawing_is_kept_apart(tmp_path, monkeypatch):
    """Intention (Andrew, 2026-10-03: "This is the first bar we need to pass"; build log 242)."""
    model = Two(0.03, 0.05)
    round_, learning, state = _round(tmp_path, model, monkeypatch)
    assert state["errors_before"] == {"pop": 0.03, "plain": 0.05} and state["error_before"] == 0.03
    model.errors = {"pop": 0.04, "plain": 0.02}
    said = round_._judge(state)
    assert model.errors == {"pop": 0.04, "plain": 0.02}  # nothing put back
    assert model.warp.drawing == "plain" and model.best == 0.02 and state["error_after"] == 0.02
    assert "best drawing so far now from plain (0.02)" in said["said"] and learning.saved == 1
    # Intention: a later round that leaves both learners worse than the best keeps the best drawing.
    state = dict(state, part="judge", errors_before={"pop": 0.04, "plain": 0.02})
    model.errors = {"pop": 0.05, "plain": 0.03}
    said = round_._judge(state)
    assert model.best == 0.02 and state["error_after"] == 0.02
    assert "best drawing so far kept (0.02)" in said["said"] and learning.saved == 1


def test_frozen_quality_is_measured_separately_without_choosing_the_painter(tmp_path, monkeypatch):
    model = Two(0.03, 0.05)
    measured = []
    def assess(tag, paths, size=None):
        measured.append(list(paths))
        return {'pop': 0.4, 'plain': 0.5} if paths == ['frozen.png'] else dict(model.errors)
    model.assess_painters = assess
    round_, _, state = _round(tmp_path, model, monkeypatch)
    state['painter_plan'] = {'training_size': 64, 'validation_paths': ['p.png'],
                             'frozen_paths': ['frozen.png']}
    round_._judge(state)
    assert measured[-2:] == [['p.png'], ['frozen.png']]
    assert state['frozen_quality'] == {'pop': 0.4, 'plain': 0.5}
    assert model.warp.drawing == 'pop'
