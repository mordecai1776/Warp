# WARP2/warp2/ask/tests/test_painter_quality_is_retained.py
# Pathway   : WARP2 / picture-round measurement retention.
# Used by   : pytest.
# Uses      : picture_round.py, visual.py, readers and analysis stubs.
# Description: existing measured painter errors survive the real save boundary.
# User intention: measure and store painter progress without changing training direction.
"""Measured painter errors survive the real round -> VisualLearning save boundary."""
from types import SimpleNamespace

import pytest

from warp2.ask import picture_round
from warp2.ask.visual import VisualLearning


@pytest.mark.parametrize("measured", [True, False])
def test_round_retains_existing_painter_metrics_without_fabricating_them(tmp_path, monkeypatch, measured):
    import readers
    import visual_operations
    from projects.behemoth_eye.eye.taxonomy import AbilityBalancer

    monkeypatch.setattr(readers, "combine", lambda *a, **k: {"score": 0.4})
    monkeypatch.setattr(readers, "fully_recognised", lambda *a, **k: False)
    monkeypatch.setattr(visual_operations.VisualOperationsAnalyzer, "analyze", lambda *a, **k: {})
    monkeypatch.setattr(AbilityBalancer, "current", lambda *a, **k:
                        SimpleNamespace(record_visual_operations=lambda *a, **k: None))
    monkeypatch.setattr(picture_round, "_model", lambda *a: SimpleNamespace(updates=0))
    learning = VisualLearning(tmp_path, tmp_path / "state")
    state = picture_round.start("square", 1)
    state.update(ident="attempt", part="record")
    quality = {"pop": {"pixel": 0.1, "edge": 0.2, "coarse": 0.3,
                       "structure": 0.225, "reader": None, "score": 0.225, "size": [16, 16],
                       "evaluation": {"record_kind": "painter_diagnostic", "evaluation_split": "unspecified",
                                      "seeds": [7], "references": [{"path": "fixture.png", "sha256": "fixture-digest"}],
                                      "per_seed": [{"seed": 7, "reference": {"path": "fixture.png", "sha256": "fixture-digest"},
                                                    "errors": {"pixel": 0.1, "edge": 0.2}}]}}}
    if measured:
        state["painter_quality"] = quality
    picture_round.PictureRound(learning)._record(state)
    saved = learning._load()["attempts"]["attempt"]
    assert saved["approved"] is False
    assert state["result"]["updates"] == 0
    if measured:
        assert saved["painter_quality"] == quality
        quality["pop"]["size"][0] = 999
        quality["pop"]["evaluation"]["per_seed"][0]["reference"]["sha256"] = "changed"
        assert learning._load()["attempts"]["attempt"]["painter_quality"]["pop"]["size"] == [16, 16]
        assert learning._load()["attempts"]["attempt"]["painter_quality"]["pop"]["evaluation"]["per_seed"][0]["reference"]["sha256"] == "fixture-digest"
    else:
        assert "painter_quality" not in saved
