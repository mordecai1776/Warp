# WARP2/warp2/ask/tests/test_image_removal_and_clean_chat.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_image_removal_and_clean_chat.py
#  Used by   : pytest.
#  Uses      : warp2/ask/{window,thread,dedup}.py.
#  Description:
#    Verifies that confirming or removing an image strips the large visual canvas
#    from the chat paper while keeping the file stored safely in the gallery
#    sidebar, with a clean "✓ Stored to Gallery" badge.
#    Also verifies /strip_images, /duplicates, and /prune_duplicates.
#  User intention (Andrew, 2026-09-08):
#    "The images should be removed from the chat and there needs to be a system
#     to look for ducplicates and we need more options for image search and research."
# ============================================================================
from __future__ import annotations

import io
import tkinter as tk
from pathlib import Path
from PIL import Image
import pytest

from warp2.ask.thread import Thread, ANDREW, WARP
from warp2.ask.window import ActionCentre, colours



def _create_sample_png(path: Path, color: str = "blue", size: tuple[int, int] = (64, 64)) -> Path:
    im = Image.new("RGB", size, color=color)
    im.save(path, format="PNG")
    return path


def test_thread_remove_image_from_turn(tmp_path):
    """Thread.remove_image_from_turn cleanly replaces turn image with stored_image badge."""
    state = tmp_path / "state"
    thread = Thread(state)

    img_file = _create_sample_png(tmp_path / "sample.png")
    thread.add(WARP, "Here is your picture", image=str(img_file))

    recent = thread.recent()
    assert len(recent) == 1
    assert recent[0]["image"] == str(img_file)
    assert "stored_image" not in recent[0]

    # Remove image from turn
    res = thread.remove_image_from_turn(str(img_file))
    assert res is True
    assert img_file.is_file()  # File on disk is NOT deleted!

    updated = thread.recent()
    assert updated[0]["image"] is None
    assert Path(updated[0]["stored_image"]).name == "sample.png"


def test_thread_strip_all_images(tmp_path):
    """Thread.strip_all_images strips all image references across turns."""
    state = tmp_path / "state"
    thread = Thread(state)

    img1 = _create_sample_png(tmp_path / "one.png")
    img2 = _create_sample_png(tmp_path / "two.png")

    thread.add(WARP, "Turn 1", image=str(img1))
    thread.add(WARP, "Turn 2", image=str(img2))
    thread.add(WARP, "Turn 3 without image")

    count = thread.strip_all_images()
    assert count == 2

    turns = thread.recent()
    assert turns[0]["image"] is None
    assert Path(turns[0]["stored_image"]).name == "one.png"
    assert turns[1]["image"] is None
    assert Path(turns[1]["stored_image"]).name == "two.png"
    assert turns[2].get("image") is None

    # Calling again strips 0
    assert thread.strip_all_images() == 0


def test_action_centre_confirm_image_removes_from_chat_and_stores_in_gallery(tmp_path, tk_root):
    """Confirming an image stores it in the gallery and removes the embed from the chat paper."""
    state = tmp_path / "state"
    images_dir = state / "images"
    images_dir.mkdir(parents=True)

    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    # Create candidate image in state/images
    candidate = _create_sample_png(images_dir / "candidate_01.png")
    centre.thread.add(WARP, "Candidate visual", image=str(candidate))
    centre.refresh()

    # Initial paper content contains the image turn
    paper_text_before = centre.paper.get("1.0", "end")
    assert "Candidate visual" in paper_text_before
    # An embedded window exists for the image
    assert len(centre.paper.window_names()) > 0

    # User clicks Confirm & Store
    res = centre._confirm_image_action(str(candidate))
    assert res is not None
    assert Path(res["image_path"]).is_file()

    # Verify chat paper has been refreshed: image embed is removed, and badge is shown
    paper_text_after = centre.paper.get("1.0", "end")
    assert "Stored to Gallery: candidate_01.png" in paper_text_after

    # Verify thread record
    turn = centre.thread.recent()[0]
    assert turn["image"] is None
    assert Path(turn["stored_image"]).name == "candidate_01.png"


def test_action_centre_confirm_reference_removes_from_chat_and_stores_in_gallery(tmp_path, tk_root):
    """When a user confirms what an image/reference is, it gets stored and removed from chat.

    User intention (Andrew, 2026-09-08):
    "images still stay in the conversation when I comferm what they are"
    "when I conferm a image it needs to get stored and go away"
    "The images should be removed from the chat"
    """
    state = tmp_path / "state"
    ref_dir = state / "images" / "references"
    ref_dir.mkdir(parents=True)

    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    ref_path = _create_sample_png(ref_dir / "apple_ref.png")
    review = {
        "id": "ref_apple_123",
        "subject": "red apple",
        "path": str(ref_path),
        "source": "commons",
    }
    centre.thread.add(WARP, "Check this reference", subject="red apple", references=[str(ref_path)], reference_reviews=[review])
    centre.refresh()

    # Images should NOT be in the chat (rendered as text/action badge and registered in right deck)
    assert len(centre.paper.image_names()) == 0
    paper_before = centre.paper.get("1.0", "end")
    assert "apple_ref.png" in paper_before

    # User clicks Confirm for red apple
    centre._confirm_reference(review, accepted=True)

    # Image embed is completely removed from chat
    assert len(centre.paper.image_names()) == 0
    paper_after = centre.paper.get("1.0", "end")
    assert "✓ Stored Reference: apple_ref.png" in paper_after

    # Turn in thread has references cleared and stored_references set
    recent = centre.thread.recent()
    assert len(recent[0].get("references", [])) == 0
    assert any("apple_ref.png" in s for s in recent[0].get("stored_references", []))

    # File preserved and cataloged
    assert ref_path.is_file()
    from warp2.ask.media import list_created_images
    catalog = list_created_images(state)
    assert any("apple_ref.png" in item.get("image_path", "") for item in catalog)


def test_action_centre_remove_image_action(tmp_path, tk_root):
    """Clicking Remove on an image card strips it immediately from the chat paper."""
    state = tmp_path / "state"
    images_dir = state / "images"
    images_dir.mkdir(parents=True)

    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    img_path = _create_sample_png(images_dir / "scratch_image.png")
    centre.thread.add(WARP, "Testing image removal", image=str(img_path))
    centre.refresh()

    assert len(centre.paper.window_names()) > 0

    # User clicks Remove
    res = centre._remove_image_action(str(img_path))
    assert res is True
    assert img_path.is_file()  # File still preserved on disk

    # Chat paper refreshed without the image
    turn = centre.thread.recent()[0]
    assert turn["image"] is None
    assert "Stored to Gallery" in centre.paper.get("1.0", "end")


def test_action_centre_strip_images_command(tmp_path, tk_root):
    """Typing /strip_images strips embeds from all turns and updates paper."""
    state = tmp_path / "state"
    images_dir = state / "images"
    images_dir.mkdir(parents=True)

    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    img1 = _create_sample_png(images_dir / "img1.png")
    img2 = _create_sample_png(images_dir / "img2.png")
    centre.thread.add(WARP, "Visual 1", image=str(img1))
    centre.thread.add(WARP, "Visual 2", image=str(img2))
    centre.refresh()

    centre.said.insert("1.0", "/strip_images")
    res = centre.send()

    assert res.get("stripped") == 2
    paper_content = centre.paper.get("1.0", "end")
    assert "Stored to Gallery: img1.png" in paper_content
    assert "Stored to Gallery: img2.png" in paper_content
    # Visual canvases have been stripped from chat paper
    assert len(centre._img_refs) == 0


def test_action_centre_duplicate_scanner_and_commands(tmp_path, tk_root):
    """ActionCentre scan_duplicates_action and /duplicates command identify duplicates."""
    state = tmp_path / "state"
    images_dir = state / "images"
    images_dir.mkdir(parents=True)

    # Create two identical files and one different
    im1 = _create_sample_png(images_dir / "gemini_a.png", color="red")
    im2 = _create_sample_png(images_dir / "gemini_b.png", color="red")
    im3 = _create_sample_png(images_dir / "gemini_c.png", color="blue")

    centre = ActionCentre(state)
    centre.build(tk, tk_root, colours())

    # Test synchronous scan action
    report = centre.scan_duplicates_action(sync=True)
    assert report.get("duplicate_count") >= 1
    paper_text = centre.paper.get("1.0", "end")
    assert "DUPLICATE IMAGE SCAN REPORT" in paper_text
    assert "gemini_b.png" in paper_text or "gemini_a.png" in paper_text

    # Test /duplicates command via send()
    centre.said.delete("1.0", "end")
    centre.said.insert("1.0", "/duplicates")
    res_cmd = centre.send()
    assert res_cmd.get("status") in ("scanning in background", "busy") or res_cmd.get("duplicate_count") >= 1
