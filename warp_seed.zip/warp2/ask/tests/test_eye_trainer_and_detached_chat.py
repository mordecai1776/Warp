# WARP2/warp2/ask/tests/test_eye_trainer_and_detached_chat.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_eye_trainer_and_detached_chat.py
#  Used by   : pytest.
#  Uses      : warp2/ask/eye_trainer.py, warp2/ask/window.py, warp2/ask/media.py.
#  Description:
#    Tests for the continuous Eye trainer ("train until it passes") and the
#    detached, clean Action Centre chat interface.
#  User intention (Andrew, 2026-09-22):
#    "train a the eye right there for said image or video where it just retrains until it passes...
#    detach the chat from the warp functions and not have warp thing pop up there"
# ============================================================================
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from unittest.mock import MagicMock
from PIL import Image
import pytest

from warp2.ask.eye_trainer import EyePersistentTrainer
from warp2.ask.media import train_eye_until_pass, IMAGE_CHECKPOINT
from warp2.ask.thread import ANDREW, WARP, Thread
from warp2.ask.window import ActionCentre, colours


def _make_dummy_image(path: Path, size: tuple[int, int] = (64, 64), color=(100, 150, 200)) -> Path:
    """Create and save a new RGB image to the given path."""
    img = Image.new("RGB", size, color=color)
    img.save(path, "PNG")
    return path


def test_eye_persistent_trainer_train_until_pass(tmp_path, monkeypatch):
    """EyePersistentTrainer continuously generates, scores, and retrains until passing."""
    root = tmp_path
    state = tmp_path / "state"
    state.mkdir(parents=True, exist_ok=True)

    class MockModel:
        def __init__(self):
            self.train_calls = []
            self.saved_destinations = []

        def generate(self, tag, destination, seed=0, **kwargs):
            return {"wide": 64, "high": 64, "image_path": _make_dummy_image(Path(destination))}

        def train_example(self, example, weight=1.0, **kwargs):
            self.train_calls.append((example, weight))
            return {"trained": 1}

        def save(self, destination):
            self.saved_destinations.append(str(destination))
            Path(destination).parent.mkdir(parents=True, exist_ok=True)
            Path(destination).write_text("{}", encoding="utf-8")

    mock_model = MockModel()
    monkeypatch.setattr("warp2.ask.eye_trainer.get_or_load_eye_model", lambda r, s: mock_model)

    # Simulate scores: round 1 fails (0.4), round 2 passes (0.90)
    score_sequence = [
        {"score": 0.40, "passed": False, "difference": "missing wheels and headlamps"},
        {"score": 0.90, "passed": True, "difference": ""},
    ]

    def mock_test_searched_image(path, tag, readers=None):
        if score_sequence:
            return score_sequence.pop(0)
        return {"score": 0.95, "passed": True, "difference": ""}

    monkeypatch.setattr("readers.test_searched_image", mock_test_searched_image)

    ref_dummy = _make_dummy_image(tmp_path / "ref_wheel.png")
    monkeypatch.setattr(
        EyePersistentTrainer,
        "_find_verified_references",
        lambda self, subj, parts, tag, readers, limit=3: [
            {"path": str(ref_dummy), "score": 0.88, "passed": True}
        ]
    )

    trainer = EyePersistentTrainer(root, state, default_target=0.85)
    # Intention (2026-10-09, fix 3.4): a reader is running; with none the
    # trainer now says "not judged" and draws nothing.
    monkeypatch.setattr(trainer, "_get_readers", lambda: ["a reader"])
    progress_events = []

    res = trainer.train_until_pass(
        subject="sports car",
        target_score=0.85,
        max_rounds=5,
        on_progress=lambda p: progress_events.append(p)
    )

    assert res["approved"] is True
    assert res["status"] == "approved"
    assert res["rounds"] == 2
    assert res["score"] == 0.90
    assert len(mock_model.train_calls) >= 1
    assert len(mock_model.saved_destinations) >= 1
    assert any(p.get("stage") == "evaluated" for p in progress_events)
    assert any(p.get("stage") == "retrained" for p in progress_events)


def test_train_eye_until_pass_helper(tmp_path, monkeypatch):
    """media.train_eye_until_pass invokes EyePersistentTrainer and returns result."""
    called = {}

    def mock_train(self, subject, target_score, max_rounds, on_progress, is_video):
        called["subject"] = subject
        called["target"] = target_score
        return {"approved": True, "score": target_score, "subject": subject}

    monkeypatch.setattr(EyePersistentTrainer, "train_until_pass", mock_train)

    res = train_eye_until_pass(tmp_path, tmp_path / "state", "airplane", target_score=0.90)
    assert res["approved"] is True
    assert called["subject"] == "airplane"
    assert called["target"] == 0.90


def test_detached_clean_chat_ui(tmp_path):
    """The Action Centre chat is detached from WARP runner ticker and header controls."""
    state = tmp_path / "state"
    centre = ActionCentre(state, root_dir=tmp_path)

    # Headless build with Tk dummy
    root = tk.Tk()
    root.withdraw()
    try:
        col = colours()
        centre.build(tk, root, col)

        # 1. lbl_warp_doing is NOT packed into the sidebar
        assert centre.lbl_warp_doing is not None
        assert not centre.lbl_warp_doing.winfo_ismapped()

        # 2. btn_halt and btn_raptor_map are NOT packed into the chat top bar
        assert centre.btn_halt is not None
        assert not centre.btn_halt.winfo_ismapped()
        assert centre.btn_raptor_map is not None
        assert not centre.btn_raptor_map.winfo_ismapped()

        # 3. _show_proposal does NOT pop up offer frame across user screen
        proposal_dict = {"kind": "project", "words": "new work", "about": "proj_a"}
        centre._show_proposal(proposal_dict)
        assert centre.proposal == proposal_dict
        assert not centre.offer.winfo_ismapped()

        # 4. Background engine messages are filtered and NOT rendered onto chat paper
        centre.paper.config(state="normal")
        centre.paper.delete("1.0", "end")
        centre.paper.config(state="disabled")

        # Conversational user message
        centre._render_turn({"who": ANDREW, "said": "Hello assistant"})
        # Background engine messages & telemetry
        centre._render_turn({"who": WARP, "said": "Chat: 3 conversations acted out", "system": True})
        centre._render_turn({"who": WARP, "said": "Fleet Test: qwen3-1.7b — 5/5 passed"})
        centre._render_turn({"who": WARP, "said": "Proof Hunter: master [code] — PROVEN"})
        centre._render_turn({"who": WARP, "said": "Training Web Inflation: 2 added"})
        centre._render_turn({"who": WARP, "said": "Code Skill: A* Grid Solver — PROVEN"})
        centre._render_turn({"who": WARP, "said": "Logic Skill: DPLL SAT — PROVEN"})
        centre._render_turn({"who": WARP, "said": "Eye blocks: taught 4 blocks (2 of 2 walked)"})
        centre._render_turn({"who": WARP, "said": "Game: snake — won 2 of 3 this turn"})
        centre._render_turn({"who": WARP, "said": "Triage: staged 2 unknown image(s)"})
        centre._render_turn({"who": WARP, "said": "14 of my own files changed since the last run.\nThe build log was not updated with them.", "grounds": "source check 2026-09-22T21:00:00"})
        # Conversational reply with grounds
        centre._render_turn({"who": WARP, "said": "Hello! How can I assist you today?", "grounds": "internal store grounds: 42 facts"})

        content = centre.paper.get("1.0", "end")
        assert "Hello assistant" in content
        assert "Hello! How can I assist you today?" in content
        assert "Assistant\n" in content
        # Ensure engine clutter, telemetry, and raw debug grounds are NOT drawn
        assert "Fleet Test" not in content
        assert "Proof Hunter" not in content
        assert "Training Web Inflation" not in content
        assert "conversations acted out" not in content
        assert "Code Skill" not in content
        assert "Logic Skill" not in content
        assert "Eye blocks" not in content
        assert "of my own files changed" not in content
        assert "internal store grounds" not in content
    finally:
        root.destroy()
