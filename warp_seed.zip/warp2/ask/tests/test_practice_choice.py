# WARP2/warp2/ask/tests/test_practice_choice.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_practice_choice.py
#  Used by   : pytest (RUN_TESTS.bat).
#  Uses      : warp2/ask/practice_choice.py.
#  Description:
#    The Eye practises real things it has pictures of, keeps one while it is
#    getting better, and rests one that has stopped.
#  User intention (Andrew):
#    2026-09-24: "lets get this fixed" — after seven rounds on "wrestling_at".
# ============================================================================
from warp2.ask.practice_choice import candidates, choose, still_improving


def _data(subjects, refs, attempts, progress=None):
    """Intention: the smallest ledger the choice reads."""
    return {"subjects": subjects,
            "references": {f"r{i}": {"subject": s, "status": st} for i, (s, st) in enumerate(refs)},
            "attempts": {f"a{i}": {"subject": s, "time": t, "evidence": {"score": sc}}
                         for i, (s, t, sc) in enumerate(attempts)},
            "progress": progress or {}}


def test_a_confirmed_subject_is_chosen_over_a_scrap_of_a_title():
    """Intention: a person's yes stands behind "cup"; nothing stands behind the scrap."""
    data = _data({"cup": "ready", "wrestling_at": "needs_references"},
                 [("cup", "confirmed"), ("wrestling_at", "pending"), ("wrestling_at", "pending")], [])
    assert candidates(data) == ["cup"]
    assert choose(data) == "cup"


def test_a_subject_that_stopped_improving_is_rested():
    """Intention: best on round one and nothing better in the two after it."""
    assert still_improving([0.3, 0.3])
    assert not still_improving([0.3, 0.0, 0.3, 0.3])
    assert still_improving([0.0, 0.1, 0.2, 0.3, 0.3, 0.3])
    data = _data({"cup": "ready", "dam": "ready"}, [("cup", "confirmed"), ("dam", "confirmed")],
                 [("cup", 1, 0.3), ("cup", 2, 0.0), ("cup", 3, 0.3), ("cup", 4, 0.2)],
                 progress={"cup": {"round": 4}})
    assert choose(data) == "dam"
    # Intention (2026-10-09, fix 4.8, check E3): rested, its progress kept.
    assert data["progress"]["cup"] == {"round": 4} and "cup" in data["resting"]


def test_the_one_in_progress_keeps_its_turn_while_it_improves():
    """Intention: a job part way through is finished before another is started."""
    data = _data({"cup": "ready", "dam": "ready"}, [("cup", "confirmed"), ("dam", "confirmed")],
                 [("cup", 1, 0.1), ("cup", 2, 0.3)], progress={"cup": {"round": 2}})
    assert choose(data) == "cup"
