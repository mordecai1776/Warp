# WARP2/warp2/ask/tests/test_conversations_as_intentions.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_conversations_as_intentions.py
#  Used by   : pytest.
#  Uses      : warp2/ask/taking.py, warp2/ask/thread.py, warp2/ask/inbox.py,
#              warp2/store/store.py, warp2/store/overgraph.py.
#  Description:
#    Tests that conversations are placed under user intentions at the loop pass
#    known point, tagging things related to them via Overgraph, and triggering
#    GUI/project revisions.
#  User intention (Andrew, 2026-09-10):
#    "The conversations should be placed under user intentions. That should cause
#    them to tag things related to them. Lets try to squeeze it in in that route
#    it does not have to be instant just done at some known point"
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.ask.inbox import COMMENT, Inbox
from warp2.ask.taking import INTENTION, SAID, Taking
from warp2.ask.thread import ANDREW, WARP, Thread
from warp2.store.overgraph import Overgraph
from warp2.store.projects import Projects
from warp2.store.questions import Questions
from warp2.store.store import Store
from warp2.work.queue import WorkQueue


def _setup_world(tmp_path):
    state = tmp_path / "state"
    root = tmp_path / "tree"
    root.mkdir(parents=True, exist_ok=True)
    state.mkdir(parents=True, exist_ok=True)

    store = Store(state / "store", run="test_conv", view_path=tmp_path / "view.sqlite3")
    overgraph = Overgraph(store)
    store.distiller = overgraph

    projects = Projects(store, root)
    queue = WorkQueue(store)
    questions = Questions(store)
    taking = Taking(store, projects, questions, queue, state)
    thread = Thread(state)

    return store, projects, taking, thread, queue, overgraph, state, root


def test_user_conversation_turns_are_placed_under_user_intentions(tmp_path):
    """Andrew's words in chat are placed under user_intention in the store at the known point."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    # Andrew says something in the chat thread
    thread.add(ANDREW, "The navigation bar should be sticky and responsive")

    # Before taking, the turn is only on disk in the thread
    assert len(store.current(attr=INTENTION)) == 0

    # The loop takes what was asked for at the known point
    report = taking.take()
    assert report["conversations"] == 1
    assert report["took"] >= 1

    # Stored under user_intention in the fact lane
    intentions = store.current(attr=INTENTION)
    assert len(intentions) >= 1
    turn_fact = next(f for f in intentions if f["subject"].startswith("conversation:turn:"))
    assert turn_fact["value"] == "The navigation bar should be sticky and responsive"

    # Speaker is marked as you (Andrew)
    speakers = store.current(subject=turn_fact["subject"], attr="speaker")
    assert len(speakers) == 1
    assert speakers[0]["value"] == "you"

    # Overgraph automatically tagged the turn with points and phrases
    terms = overgraph.terms_of(turn_fact["subject"])
    assert any("navigation" in t for t in terms)
    assert any("responsive" in t for t in terms)


def test_model_words_never_become_user_intentions(tmp_path):
    """Model turns (who == 'warp') must never masquerade as user intention."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    # Warp speaks in the conversation
    thread.add(WARP, "I propose we make the layout blue and centered.")
    thread.add(ANDREW, "Keep the layout dark and clean")

    report = taking.take()
    assert report["conversations"] == 1

    # Only Andrew's turn received user_intention
    intentions = store.current(attr=INTENTION)
    user_values = [f["value"] for f in intentions]
    assert "Keep the layout dark and clean" in user_values
    assert "I propose we make the layout blue and centered." not in user_values


def test_conversation_about_gui_resolves_and_tags_gui_component(tmp_path):
    """A conversation mentioning GUI for a project tags the project GUI and offers revision work."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    # Create a project with a gui.py file
    projects.open("Centering Image", intention="draw pictures and show progress")
    proj_dir = root / "projects" / "centering_image"
    proj_dir.mkdir(parents=True, exist_ok=True)
    gui_file = proj_dir / "gui.py"
    gui_file.write_text("class Observer:\n    def __init__(self):\n        self.title = 'Observer'\n", encoding="utf-8")

    # Andrew mentions the GUI in conversation
    thread.add(ANDREW, "centering_image: make the gui buttons bigger and center the canvas preview")

    report = taking.take()
    assert report["conversations"] == 1

    # Resolved to centering_image GUI file
    gui_rel = "projects/centering_image/gui.py"
    assert store.current(subject=gui_rel, attr=INTENTION)
    assert store.current(subject=gui_rel, attr=SAID)[0]["value"] == "centering_image: make the gui buttons bigger and center the canvas preview"

    # The Overgraph automatically tagged the GUI file with the terms from Andrew's conversation
    gui_terms = overgraph.terms_of(gui_rel)
    assert any("canvas" in t for t in gui_terms)
    assert any("buttons" in t for t in gui_terms)

    # Revision work was offered to the queue for the GUI
    open_work = queue.open_items()
    assert any(item["item"] == f"work:revise:{gui_rel}" for item in open_work)


def test_comment_on_project_with_gui_keywords_resolves_gui_and_offers_revision(tmp_path):
    """An inbox comment on a project referring to the window/ui resolves gui.py and raises work."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    projects.open("Centering Image", intention="draw pictures")
    proj_dir = root / "projects" / "centering_image"
    proj_dir.mkdir(parents=True, exist_ok=True)
    gui_file = proj_dir / "gui.py"
    gui_file.write_text("class Observer:\n    pass\n", encoding="utf-8")

    # Submit an inbox comment about project:centering_image
    Inbox(state).put(COMMENT, about="project:centering_image",
                     said="the observer window needs a dark theme and larger font")

    report = taking.take()
    assert report["took"] >= 1

    gui_rel = "projects/centering_image/gui.py"
    # Overgraph tagged the GUI file
    gui_terms = overgraph.terms_of(gui_rel)
    assert any("observer" in t for t in gui_terms)
    assert any("dark" in t for t in gui_terms)

    # Work offered for the GUI file
    assert any(item["item"] == f"work:revise:{gui_rel}" for item in queue.open_items())


def test_conversation_ingestion_is_idempotent(tmp_path):
    """Taking across multiple loop passes does not duplicate conversation turn facts."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    thread.add(ANDREW, "First request to improve performance")

    r1 = taking.take()
    assert r1["conversations"] == 1
    count1 = len(store.current(attr=INTENTION))

    # Second pass without new turns
    r2 = taking.take()
    assert r2["conversations"] == 0
    count2 = len(store.current(attr=INTENTION))
    assert count1 == count2


def test_general_font_comment_resolves_gui_and_offers_revision(tmp_path):
    """Andrew's comment asking to change the general font resolves the window GUI and offers revision."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    thread.add(ANDREW, "change the general font to a bit bigger")

    report = taking.take()
    assert report["conversations"] == 1

    # Stored under user_intention
    intentions = store.current(attr=INTENTION)
    assert any("change the general font to a bit bigger" in f["value"] for f in intentions)

    # Resolved to window.py
    gui_target = "warp2/ask/window.py"
    assert store.current(subject=gui_target, attr=INTENTION)
    terms = overgraph.terms_of(gui_target)
    assert any("font" in t for t in terms)
    assert any("bigger" in t for t in terms)

    # Work offered for revision
    assert any(item["item"] == f"work:revise:{gui_target}" for item in queue.open_items())


def test_conversation_color_theme_change(tmp_path):
    """Conversational requests to change color/theme adapt live and queue window revision."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    thread.add(ANDREW, "change the color to green")

    report = taking.take()
    assert report["conversations"] == 1

    gui_target = "warp2/ask/window.py"
    assert store.current(subject=gui_target, attr=INTENTION)
    assert any(item["item"] == f"work:revise:{gui_target}" for item in queue.open_items())

    # Verify talk response recognizes desired change and proposes intention
    from warp2.ask.talk import Talk
    from warp2.ask.knowing import Knowing
    knowing = Knowing(store, projects, Questions(state))
    talk = Talk(knowing)
    ans = talk.reply("change the color to green")
    assert ans["proposes"] is not None
    assert ans["proposes"]["about"] == gui_target
    assert "change the color to green" in ans["proposes"]["words"]


def test_conversation_language_change(tmp_path):
    """Conversational requests to change language update personality and queue revision."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    thread.add(ANDREW, "speak in Spanish")

    report = taking.take()
    assert report["conversations"] == 1

    pers_target = "warp2/ask/personality.py"
    assert store.current(subject=pers_target, attr=INTENTION)
    assert any(item["item"] == f"work:revise:{pers_target}" for item in queue.open_items())

    # Verify talk response proposes intention for personality adaptation
    from warp2.ask.talk import Talk
    from warp2.ask.knowing import Knowing
    from warp2.ask.personality import Personality
    knowing = Knowing(store, projects, Questions(state))
    pers = Personality(state)
    talk = Talk(knowing, personality=pers)
    ans = talk.reply("speak in Spanish")
    assert ans["proposes"] is not None
    assert ans["proposes"]["about"] == pers_target
    assert "speak in Spanish" in ans["proposes"]["words"]


def test_conversation_change_all_to_different_language(tmp_path):
    """Conversational request to change interface language targets window and queues revision."""
    store, projects, taking, thread, queue, overgraph, state, root = _setup_world(tmp_path)

    # 1. User asks to change interface to Spanish
    from warp2.ask.talk import Talk
    from warp2.ask.knowing import Knowing
    from warp2.ask.personality import Personality
    knowing = Knowing(store, projects, Questions(state))
    pers = Personality(state)
    talk = Talk(knowing, personality=pers)

    r1 = talk.reply("change all of it to Spanish")
    assert r1["proposes"] is not None
    assert r1["proposes"]["about"] == "warp2/ask/window.py"
    assert "change all of it to Spanish" in r1["proposes"]["words"]

    # 2. Conversation turn recorded in thread
    thread.add(ANDREW, "change all of it to Spanish")
    report = taking.take()
    assert report["conversations"] == 1

    # Stored under user_intention and targets window.py for revision
    gui_target = "warp2/ask/window.py"
    assert store.current(subject=gui_target, attr=INTENTION)
    assert any(item["item"] == f"work:revise:{gui_target}" for item in queue.open_items())



