# WARP2/warp2/ask/tests/test_the_next_reference_hashes_only_what_it_uses.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_the_next_reference_hashes_only_what_it_uses.py
#  Used by   : pytest.
#  Uses      : warp2/ask/visual.py.
#  Description:
#    That the first usable confirmed reference is found by checking the rows
#    that could be used, one at a time, not by hashing every picture; and that
#    a picture whose bytes changed is still passed over.
#  User intention (2026-11-01): the Eye turn hashed 31,607 confirmed pictures to
#    use one, and that time came out of the turn's training.
# ============================================================================
from __future__ import annotations

import hashlib
import json

import warp2.ask.visual as visual
from warp2.ask.visual import VisualLearning


def _ledger(tmp_path):
    pics = tmp_path / "pics"
    pics.mkdir()
    rows = {}
    for name in ("learned", "changed", "good", "later"):
        path = pics / f"{name}.png"
        path.write_bytes(name.encode())
        rows[name] = {"subject": "cat", "status": "confirmed", "path": str(path),
                      "digest": hashlib.sha256(name.encode()).hexdigest()}
    (pics / "changed.png").write_bytes(b"other bytes")
    rows["pending"] = dict(rows["later"], status="pending")
    state = tmp_path / "state"
    learning = VisualLearning(tmp_path, state)
    learning.path.write_text(json.dumps({"references": rows, "attempts": {}, "subjects": {}, "last_practice": 0}),
                             encoding="utf-8")
    return learning, rows


def test_only_the_rows_up_to_the_first_usable_one_are_hashed(tmp_path, monkeypatch):
    learning, rows = _ledger(tmp_path)
    hashed = []
    real = visual._digest
    monkeypatch.setattr(visual, "_digest", lambda path: hashed.append(path) or real(path))
    got = learning.first_reference(status="confirmed", skip={rows["learned"]["digest"]})
    assert got["digest"] == rows["good"]["digest"]
    assert hashed == [rows["changed"]["path"], rows["good"]["path"]]


def test_it_agrees_with_the_full_check(tmp_path):
    learning, rows = _ledger(tmp_path)
    full = [r for r in learning.references(status="confirmed") if r["digest"] != rows["learned"]["digest"]]
    assert learning.first_reference(status="confirmed", skip={rows["learned"]["digest"]}) == full[0]
    every = {r["digest"] for r in learning.references(status="confirmed")}
    assert learning.first_reference(status="confirmed", skip=every) is None
