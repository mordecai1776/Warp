# WARP2/warp2/ask/tests/test_picture_side.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_picture_side.py
#  Used by   : pytest.
#  Uses      : warp2/ask/picture_round.py (PictureRound._teach, _side) with a
#              stand-in picture model; no Eye, no GPU.
#  Description:
#    After its teach, a reference's one strongest other concept is taught in
#    its own short part (among equal ones, one the readers said was missing);
#    a model that cannot hand them back still teaches them all in its teach.
#  User intention (Andrew, 2026-10-02): "We need to split it out into more
#    small directed parts." / "one would be enough" (one other concept).
# ============================================================================
from __future__ import annotations

import warp2.ask.picture_round as picture_round
from warp2.ask.picture_round import PictureRound, start


class HandsBack:
    """Intention: a picture model like the Eye's — the subject in train_example, the rest through teach_side."""
    def __init__(self):
        self.subject_taught, self.side_taught = [], []

    def train_example(self, example, weight, longest=0, side=True):
        self.subject_taught.append(example["image_path"])
        others = [("tail", 0.9), ("fur", 0.5), ("ears", 0.7)]
        if side:
            self.side_taught.extend(c for c, _ in others)
            return {"side": []}
        return {"side": sorted(others, key=lambda item: -item[1])}

    def teach_side(self, path, concept, weight, longest=0):
        self.side_taught.append(concept)
        return {"trained": 1}


class Older:
    """Intention: a picture model from before — no side parameter, teaches everything at once."""
    def __init__(self):
        self.calls = 0

    def train_example(self, example, weight, longest=0):
        self.calls += 1
        return {}


def _state(n=2):
    state = start("cat", 1)
    state["queue"] = [{"id": f"r{i}", "weight": 1.0, "example": {"image_path": f"p{i}.png"}} for i in range(n)]
    state["of"] = n
    state["part"] = "teach"
    return state


def test_only_the_strongest_other_concept_is_taught(monkeypatch):
    """Intention (Andrew, 2026-10-02): "one would be enough" — one other concept per reference, the heaviest."""
    model = HandsBack()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)
    round_ = PictureRound(learning=None)
    state = _state(2)
    seen_parts = []
    while state["part"] in ("teach", "side"):
        seen_parts.append(state["part"])
        getattr(round_, "_" + state["part"])(state)
    assert seen_parts == ["teach", "side", "teach", "side"]
    assert model.subject_taught == ["p0.png", "p1.png"]
    assert model.side_taught == ["tail", "tail"]
    assert state["part"] == "blocks" and state["side"] == []  # then the round's blocks (build log 250)


def test_among_equal_ones_a_missing_one_is_chosen():
    items = [["p", "fur", 1.0], ["p", "tail", 1.0], ["p", "ears", 0.4]]
    assert picture_round._one_side(items, ["Tail"]) == [["p", "tail", 1.0]]
    assert picture_round._one_side(items, []) == [["p", "fur", 1.0]]


def test_a_round_saved_with_many_teaches_just_one(monkeypatch):
    model = HandsBack()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)
    state = _state(0)
    state["part"] = "side"
    state["side"] = [["p", "fur", 0.5], ["p", "tail", 0.9], ["p", "ears", 0.7]]
    said = PictureRound(learning=None)._side(state)
    assert model.side_taught == ["tail"] and state["side"] == [] and "tail" in said["said"]
    assert state["part"] == "blocks"


def test_an_older_model_still_teaches_everything_in_its_teach(monkeypatch):
    model = Older()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)
    round_ = PictureRound(learning=None)
    state = _state(1)
    round_._teach(state)
    assert model.calls == 1 and state["part"] == "blocks"


def test_a_round_saved_before_side_existed_carries_on(monkeypatch):
    model = HandsBack()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)
    state = _state(1)
    state.pop("side")
    PictureRound(learning=None)._teach(state)
    assert state["part"] == "side" and len(state["side"]) == 1


class PaintsLater(HandsBack):
    """Intention: a picture model that leaves the painter lesson for the practice (as EyePictures does)."""
    def __init__(self):
        super().__init__()
        self.practised = []

    def train_example(self, example, weight, longest=0, side=True, paint=True):
        said = super().train_example(example, weight, longest, side)
        said["paint later"] = None if paint else [example["image_path"], weight, 0.5]
        return said

    def practice(self, subject, seconds=0.0, longest=0, fresh=None):
        self.practised.append(list(fresh or []))
        return {"master": {"by": "fit", "fit": 0.5, "rounds": 3}, "painted fresh": len(fresh or []), "drawn again": 0}


def test_the_rounds_pictures_are_painted_in_the_practice(monkeypatch, tmp_path):
    """Intention (2026-10-03): each teach hands its painter lesson on; the practice part paints them all, after the master."""
    model = PaintsLater()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)

    class Learning:
        state = tmp_path

        def _checkpoint(self, model):
            pass
    round_ = PictureRound(learning=Learning())
    state = _state(2)
    while state["part"] in ("teach", "side"):
        getattr(round_, "_" + state["part"])(state)
    assert [f[0] for f in state["fresh"]] == ["p0.png", "p1.png"]
    said = round_._practice(state)
    assert [f[0] for f in model.practised[0]] == ["p0.png", "p1.png"]
    assert state["fresh"] == [] and "painted 2 new" in said["said"]
