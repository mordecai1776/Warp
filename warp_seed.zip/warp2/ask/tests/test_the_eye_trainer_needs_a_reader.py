# WARP2/warp2/ask/tests/test_the_eye_trainer_needs_a_reader.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_the_eye_trainer_needs_a_reader.py
#  Used by   : pytest.
#  Uses      : warp2/ask/eye_trainer.py (EyePersistentTrainer).
#  Description:
#    With no vision reader running, the eye trainer says "not judged" and
#    neither draws nor trains; a score at the target with a reader saying the
#    subject is not there is not a pass.
#  User intention (Andrew, 2026-10-09): "ok lets get it done" — fix 3.4 of
#    claude/warp2_fix_plan_2026_10_09.md (check B4).
# ============================================================================
from __future__ import annotations

import pytest

import readers


@pytest.fixture
def trainer(tmp_path, monkeypatch):
    """Intention: a trainer with no dataset search and a model that must not be touched."""
    from warp2.ask import eye_trainer
    monkeypatch.setattr(eye_trainer, "DatasetCurator", lambda *a, **k: None)

    def _no_model(*a, **k):
        raise AssertionError("the model was loaded with nobody to judge it")
    monkeypatch.setattr(eye_trainer, "get_or_load_eye_model", _no_model)
    return eye_trainer.EyePersistentTrainer(tmp_path, tmp_path)


def test_no_reader_running_is_not_judged_and_nothing_is_drawn(trainer, monkeypatch):
    """Intention: the stand-in reader passed anything; now nothing runs without a reader."""
    monkeypatch.setattr(readers, "available_readers", lambda *a, **k: [])
    got = trainer.train_until_pass("cat", max_rounds=3)
    assert got["status"] == "not_judged" and got["approved"] is False


def test_a_score_at_the_target_is_not_a_pass_by_itself(trainer, monkeypatch):
    """Intention: `passed or score >= target` let a refused picture through on its number."""
    from warp2.ask import eye_trainer

    class _Model:
        def generate(self, tag, path, seed=0):
            from PIL import Image
            Image.new("RGB", (8, 8)).save(path)

        def train_example(self, *a, **k):
            pass

        def save(self, *a, **k):
            pass
    monkeypatch.setattr(eye_trainer, "get_or_load_eye_model", lambda *a: _Model())
    monkeypatch.setattr(trainer, "_get_readers", lambda: ["a reader"])
    monkeypatch.setattr(trainer, "_find_verified_references", lambda *a, **k: [])
    monkeypatch.setattr(readers, "test_searched_image", lambda *a, **k: {
        "score": 0.9, "passed": False, "absent": "the cat is not visibly present"})
    got = trainer.train_until_pass("cat", target_score=0.85, max_rounds=1)
    assert got["approved"] is False
