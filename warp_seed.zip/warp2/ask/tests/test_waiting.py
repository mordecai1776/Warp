# WARP2/warp2/ask/tests/test_waiting.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_waiting.py
#  Used by   : pytest.
#  Uses      : warp2/ask/waiting.py.
#  Description:
#    That a person waiting is visible to the loop, that the mark cannot outlive
#    the process that raised it, and that one window cannot lower another's.
#  User intention (Andrew, 2026-09-12):
#    "it is fine if it spends the entire process if it is a user need just not
#    if it is on its own work that should be split up."
#
#    He then asked for a picture of a cat fourteen minutes into a LoRA round,
#    the vision reader timed out on the busy machine, and he got back an
#    unjudged picture.
# ============================================================================
from __future__ import annotations

import json
import os

from warp2.ask.waiting import Waiting


def test_nobody_is_waiting_on_a_fresh_machine(tmp_path):
    waiting = Waiting(tmp_path)
    assert waiting.someone() == {}
    assert waiting.says() == ""


def test_a_raised_mark_is_visible_and_says_what_for(tmp_path):
    waiting = Waiting(tmp_path)
    waiting.begin("an image of a cat")
    mark = waiting.someone()
    assert mark["what"] == "an image of a cat"
    assert mark["pid"] == os.getpid()
    assert "an image of a cat" in waiting.says()


def test_lowering_the_mark_ends_the_stand_down(tmp_path):
    waiting = Waiting(tmp_path)
    waiting.begin("an image of a cat")
    assert waiting.done() is True
    assert waiting.someone() == {}
    assert waiting.says() == ""


def test_it_lowers_itself_when_the_job_ends(tmp_path):
    """The job is what holds the mark up, not a caller remembering to."""
    with Waiting(tmp_path) as waiting:
        waiting.begin("an image of a cat")
        assert waiting.someone() != {}
    assert Waiting(tmp_path).someone() == {}


def test_the_mark_ends_when_it_ends_even_if_the_job_throws(tmp_path):
    waiting = Waiting(tmp_path)
    try:
        with waiting:
            waiting.begin("an image of a cat")
            raise ValueError("the round fell over")
    except ValueError:
        pass
    assert Waiting(tmp_path).someone() == {}


def test_a_mark_from_a_dead_window_is_not_a_person_waiting(tmp_path):
    """A STAND-DOWN RULE THAT CAN WEDGE THE MACHINE FOR EVER IS WORSE THAN
    THE STARVATION IT FIXES.

    A window that crashes mid-job would otherwise leave a file saying somebody
    is waiting, and the machine would never train again.
    """
    waiting = Waiting(tmp_path)
    waiting.begin("an image of a cat")
    gone = json.loads(waiting.path.read_text(encoding="utf-8"))
    gone["pid"] = 999999999          # no such process
    waiting.path.write_text(json.dumps(gone), encoding="utf-8")
    assert Waiting(tmp_path).someone() == {}


def test_a_recycled_pid_is_not_the_process_that_raised_the_mark(tmp_path):
    """A pid alone is not an identity — the start time is what makes it one."""
    waiting = Waiting(tmp_path)
    waiting.begin("an image of a cat")
    mark = json.loads(waiting.path.read_text(encoding="utf-8"))
    mark["started"] = "some other moment entirely"
    waiting.path.write_text(json.dumps(mark), encoding="utf-8")
    assert Waiting(tmp_path).someone() == {}


def test_one_window_cannot_lower_anothers_mark(tmp_path):
    """Two windows, two people; the second finishing does not free the first."""
    waiting = Waiting(tmp_path)
    waiting.begin("an image of a cat")
    theirs = json.loads(waiting.path.read_text(encoding="utf-8"))
    theirs["pid"] = os.getpid() - 1 if os.getpid() > 1 else 2
    waiting.path.write_text(json.dumps(theirs), encoding="utf-8")
    assert Waiting(tmp_path).done() is False


def test_a_ruined_mark_is_read_as_nobody(tmp_path):
    """A ledger this small must never be the reason the machine stops."""
    waiting = Waiting(tmp_path)
    waiting.path.parent.mkdir(parents=True, exist_ok=True)
    waiting.path.write_text("{not json", encoding="utf-8")
    assert waiting.someone() == {}
