# WARP2/warp2/ask/tests/test_logic_problems_are_checked.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_logic_problems_are_checked.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/ask/logic_problems.py, warp2/ask/logic_rules.py,
#              warp2/train/block_sides.py (sides — what the Eye is taught),
#              warp2/work/side/logic.py (LogicStep, read as text).
#  Description:
#    The logic dataset (BUILD_LOG 1118): the same seed gives the same
#    problems and another seed new ones; every valid side has no counter
#    row and every invalid side has one; the two sides are worded alike;
#    as a block the Eye is taught the valid side right and the invalid
#    side wrong, with nothing but the words to tell them apart; and the
#    logic step writes them each turn.
#  User intention (Andrew, 2026-11-02): "make sure they have proper datasets
#    and that they are given proper leaning methods and test".
# ============================================================================
"""Tests that the logic problems are checked by truth table and taught right and wrong by their words alone."""
from __future__ import annotations

from pathlib import Path

from warp2.ask.logic_problems import STATEMENTS, LogicProblems, block_of, put_in
from warp2.ask.logic_rules import RULES, atom, counter_row, imp


def test_the_same_seed_gives_the_same_problems_and_another_new_ones():
    """Intention: any turn's problems can be made again; the next turn's are new."""
    first = [(p.valid, p.invalid) for p in LogicProblems(3).some(8)]
    assert first == [(p.valid, p.invalid) for p in LogicProblems(3).some(8)]
    assert first != [(p.valid, p.invalid) for p in LogicProblems(4).some(8)]


def test_a_put_in_keeps_a_valid_rule_valid_and_the_pairs_are_checked(monkeypatch):
    """Intention: every made pair is valid on one side and invalid on the other, checked after the put-in."""
    p, q = atom("p"), atom("q")
    subs = {"p": ("and", atom("a"), atom("b")), "q": ("not", atom("c"))}
    assert counter_row([put_in(imp(p, q), subs), put_in(p, subs)], put_in(q, subs)) is None
    made = LogicProblems(11)
    seen = set()
    for _ in range(40):
        problem = made.one()
        if problem is None:
            continue
        seen.add(problem.rule)
        assert problem.valid != problem.invalid
        said = [{s for s in STATEMENTS if s in side.split("[")[0].lower()} for side in (problem.valid, problem.invalid)]
        assert said[0] == said[1], "worded alike: the same statements on both sides"
    assert len(seen) >= len(RULES) // 2, "many rules, not one"


def test_as_a_block_only_the_words_differ():
    """Intention: valid right, invalid wrong; the same tags on both sides but the words."""
    from warp2.train.block_sides import sides
    problem = LogicProblems(5).some(1)[0]
    block = block_of(problem)
    (right_tags, right, _), (wrong_tags, wrong, _) = sides(block)
    assert (right, wrong) == ("right", "wrong") and block.domain == "logic"

    def words(tag) -> str:
        """Intention (BUILD_LOG 1593c): the words a tag holds as a tag tree, read back; "" when it holds none."""
        from warp2.tags.dehydrated.text_tree import text_of
        return "".join(text_of(inner["dehydrated_tags"]) for inner in tag.get("holds", []) if "dehydrated_tags" in inner)

    def without_words(tags):
        return sorted((t["name"], t["weight"]) for t in tags if not words(t))

    assert without_words(right_tags) == without_words(wrong_tags)
    assert [words(t) for t in right_tags if words(t)] == [problem.valid]
    assert [words(t) for t in wrong_tags if words(t)] == [problem.invalid]
    assert problem.rule not in str(block.positive) and problem.rule not in str(block.negative)


def test_the_logic_step_writes_them_each_turn():
    """Intention: as many as one turn of block teaching takes, seeded by the pass."""
    text = (Path(__file__).resolve().parents[2] / "work" / "side" / "logic.py").read_text(encoding="utf-8")
    assert "LogicProblems(seed).some(int(BLOCKS_PER_TURN))" in text
    assert "self.shared.ingestor.record_block(block_of(problem))" in text
