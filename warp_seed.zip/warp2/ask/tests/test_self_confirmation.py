# WARP2/warp2/ask/tests/test_self_confirmation.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_self_confirmation.py
#  Used by   : pytest.
#  Uses      : warp2/ask/media.py, warp2/ask/window.py, warp2/train/training_blocks.py.
#  Description:
#    Tests autonomous and user-directed self-confirmation for images & references.
#  User intention (Andrew, 2026-09-27):
#    "the system should have a way to self comferm as well that should be in there if it is not."
# ============================================================================
from __future__ import annotations

from pathlib import Path
from PIL import Image

from warp2.ask.media import kept_home, list_created_images, self_confirm_image, self_confirm_reference
from warp2.ask.thread import WARP, image_feed
from warp2.ask.visual import VisualLearning
from warp2.ask.window import ActionCentre
from warp2.train.training_blocks import TrainingBlockIngestor


def _make_png(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.new("RGB", (32, 32), color=(100, 150, 200))
    img.save(path, format="PNG")
    return path


def test_self_confirm_image(tmp_path):
    root = tmp_path
    state = tmp_path / "state"
    img_path = _make_png(tmp_path / "cache" / "nebula_attempt_1.png")

    res = self_confirm_image(root, state, img_path, score=0.92, subject="nebula")

    assert res["status"] == "self_confirmed"
    assert res["confirmed_by"] == "system"
    assert res["subject"] == "nebula"

    # Must be moved to kept set
    kept_file = Path(res["image_path"])
    assert kept_file.is_file()
    assert kept_file.parent == kept_home(state)
    assert not img_path.exists()

    # Catalog record verified
    images = list_created_images(state)
    assert any(i.get("confirmed_by") == "system" and i.get("subject") == "nebula" for i in images)

    # Universal training block verified
    ingestor = TrainingBlockIngestor(state)
    blocks = ingestor.load_blocks(modality="visual")
    assert any(b.subject == "nebula" and b.positive for b in blocks)


def test_self_confirm_reference(tmp_path):
    root = tmp_path
    state = tmp_path / "state"
    ref_path = _make_png(tmp_path / "ref" / "star_ref.png")

    from warp2.ask.visual import _digest
    learning = VisualLearning(root, state)
    data = learning._load()
    data["references"]["star_1"] = {
        "id": "star_1", "path": str(ref_path), "subject": "star",
        "digest": _digest(ref_path), "status": "pending", "added_at": 0.0,
    }
    data["subjects"]["star"] = "needs_references"
    learning._save(data)

    res = self_confirm_reference(root, state, {"id": "star_1", "path": str(ref_path), "subject": "star", "reader_score": 0.88})

    assert res["status"] == "self_confirmed"
    assert res["confirmed_by"] == "system"

    # VisualLearning status verified
    updated = learning._load()
    assert updated["references"]["star_1"]["status"] == "confirmed"
    assert updated["references"]["star_1"]["confirmed_by"] == "system"


def test_action_centre_self_confirm_pending(tmp_path):
    root = tmp_path
    state = tmp_path / "state"
    img1 = _make_png(tmp_path / "img1.png")
    ref1 = _make_png(tmp_path / "ref1.png")

    centre = ActionCentre(state, root_dir=root)
    centre.pending_image_confirmations[str(img1.resolve())] = {
        "path": str(img1), "is_reference": False, "review": {"reader_score": 0.82, "subject": "planet"}
    }
    centre.pending_image_confirmations[str(ref1.resolve())] = {
        "path": str(ref1), "is_reference": True, "review": {"id": "r1", "path": str(ref1), "reader_score": 0.91, "subject": "planet"}
    }

    assert len(centre.pending_image_confirmations) == 2

    confirmed = centre.self_confirm_pending(threshold=0.75)
    assert len(confirmed) == 2
    assert len(centre.pending_image_confirmations) == 0


def test_autonomous_feed_self_confirm_high_score(tmp_path):
    root = tmp_path
    state = tmp_path / "state"
    ref = _make_png(tmp_path / "high_score_ref.png")

    # Add reference review with 90% score into image feed
    image_feed(state).add(
        WARP, "Practice: comet", subject="comet",
        references=[str(ref)],
        # Intention (2026-10-09, fix 3.5): the readers passed it, not only scored it.
        reference_reviews=[{"path": str(ref), "subject": "comet", "id": "c1", "reader_score": 0.90,
                            "reader_verdict": "verified"}]
    )

    centre = ActionCentre(state, root_dir=root)
    centre._take_image_feed()

    # High score reference was autonomously self-confirmed, not left pending
    assert str(ref.resolve()) not in centre.pending_image_confirmations
