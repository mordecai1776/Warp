# WARP2/warp2/ask/tests/test_model_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_model_learning.py
#  Used by   : pytest
#  Uses      : warp2/ask/model_learning.py
#  Description:
#    Tests for warp2/ask/model_learning.py.
#  User intention:
#    The same as the file it tests: see the header of
#    warp2/ask/model_learning.py.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest

from warp2.ask.model_learning import (
    ModelLearning,
    ModelBenchmarkTask,
    _extract_code,
    _verify_is_palindrome,
    _verify_reverse_words,
    _verify_logic_deduction,
    _verify_gate_json_contract,
    _verify_binary_search,
    STANDARD_TASKS,
)


def test_extract_code_fences_and_thinking():
    # Markdown fence extraction
    raw = "Here is the code:\n```python\ndef is_prime(n):\n    return n > 1\n```\nHope this helps!"
    assert _extract_code(raw) == "def is_prime(n):\n    return n > 1"

    # Thinking tags stripped
    raw_thinking = "<think>Let's write palindrome code</think>def is_palindrome(s):\n    return s == s[::-1]"
    assert _extract_code(raw_thinking) == "def is_palindrome(s):\n    return s == s[::-1]"


def test_verify_is_palindrome():
    # Valid implementation
    valid_code = "def is_palindrome(s: str) -> bool:\n    return s == s[::-1]\n"
    ok, syn, gate, flaw, score = _verify_is_palindrome(valid_code)
    assert ok is True
    assert syn is True
    assert gate is True
    assert flaw == ""
    assert score == 1.0

    # Syntax error
    bad_syntax = "def is_palindrome(s:\n    return"
    ok, syn, gate, flaw, score = _verify_is_palindrome(bad_syntax)
    assert ok is False
    assert syn is False
    assert "syntax_error" in flaw

    # Logic failure
    wrong_logic = "def is_palindrome(s: str) -> bool:\n    return False\n"
    ok, syn, gate, flaw, score = _verify_is_palindrome(wrong_logic)
    assert ok is False
    assert syn is True
    assert flaw == "assertion_failure"


def test_verify_reverse_words():
    valid = "def reverse_words(s: str) -> str:\n    return ' '.join(s.split()[::-1])\n"
    ok, syn, gate, flaw, score = _verify_reverse_words(valid)
    assert ok is True
    assert syn is True
    assert score == 1.0

    empty = ""
    ok, syn, gate, flaw, score = _verify_reverse_words(empty)
    assert ok is False
    assert flaw == "empty_response"


def test_verify_logic_deduction():
    correct = "No, it did not rain because if it had rained, the ground would be wet."
    ok, syn, gate, flaw, score = _verify_logic_deduction(correct)
    assert ok is True
    assert score == 1.0

    fallacy = "Yes, it must have rained earlier."
    ok, syn, gate, flaw, score = _verify_logic_deduction(fallacy)
    assert ok is False
    assert "logical_fallacy" in flaw


def test_verify_gate_json_contract():
    valid_json = '{"status": "ok", "count": 42}'
    ok, syn, gate, flaw, score = _verify_gate_json_contract(valid_json)
    assert ok is True
    assert gate is True

    bad_schema = '{"status": "error", "count": 0}'
    ok, syn, gate, flaw, score = _verify_gate_json_contract(bad_schema)
    assert ok is False
    assert "contract_violation_wrong_schema" in flaw

    not_json = "I am a language model and cannot output json."
    ok, syn, gate, flaw, score = _verify_gate_json_contract(not_json)
    assert ok is False
    assert "contract_violation_no_json" in flaw


def test_verify_binary_search():
    valid = """
def binary_search(arr: list[int], target: int) -> int:
    low, high = 0, len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1
"""
    ok, syn, gate, flaw, score = _verify_binary_search(valid)
    assert ok is True
    assert syn is True
    assert score == 1.0


def test_model_learning_lifecycle(tmp_path):
    root_dir = tmp_path / "root"
    state_dir = tmp_path / "state"
    root_dir.mkdir(parents=True)
    state_dir.mkdir(parents=True)

    # Write a test models.json
    roster_file = root_dir / "models.json"
    roster_file.write_text(json.dumps({
        "models": [
            {
                "name": "test_model_mock",
                "how": "ollama",
                "path": "http://127.0.0.1:11434/api/chat",
                "enabled": True,
            }
        ]
    }), encoding="utf-8")

    learner = ModelLearning(root_dir=root_dir, state_dir=state_dir)
    assert len(learner.get_roster_models()) == 1

    # Mock query_model to return a valid response for is_palindrome
    with patch.object(learner, "query_model", return_value=("def is_palindrome(s): return s == s[::-1]", 12.5, "")):
        res = learner.evaluate_pass()

    assert res["model"] == "test_model_mock"
    assert res["outcome"] == "ok"
    assert res["syntax_ok"] is True
    assert res["gate_ok"] is True
    assert res["trials"] == 1
    assert res["success_rate"] == 1.0

    # Verify fact stored in store
    facts = learner.store.current(subject="eval:test_model_mock")
    assert len(facts) == 1
    stored_val = json.loads(facts[0]["value"])
    assert stored_val["model"] == "test_model_mock"
    assert stored_val["outcome"] == "ok"

    # Now simulate a failure (e.g. timeout)
    with patch.object(learner, "query_model", return_value=("", 5000.0, "timeout")):
        res2 = learner.evaluate_pass()

    assert res2["outcome"] == "refused"
    assert res2["failure_type"] == "timeout"
    assert res2["trials"] == 2
    assert res2["success_rate"] == 0.5
    assert "timeout" in res2["flaws_summary"]
