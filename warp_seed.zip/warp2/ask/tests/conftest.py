# WARP2/warp2/ask/tests/conftest.py
# Pathway   : WARP2/warp2/ask/tests/conftest.py
# Used by   : pytest Action Centre tests.
# Uses      : tkinter, pytest, sys, pathlib.
# Description: Shared Tk fixture and project import paths for GUI tests.
# User intention: Verify the interactive surface reliably on Windows.
from __future__ import annotations

import sys
import tkinter as tk
from pathlib import Path
import pytest

_warp2_root = Path(__file__).resolve().parents[3]
if str(_warp2_root) not in sys.path:
    sys.path.insert(0, str(_warp2_root))
_ci_root = _warp2_root / "projects" / "centering_image"
if str(_ci_root) not in sys.path:
    sys.path.insert(0, str(_ci_root))


@pytest.fixture(scope="session")
def tk_root():
    """Session-scoped Tk root to avoid repeated creation and teardown crashes on Windows."""
    try:
        root = tk.Tk()
        root.withdraw()
    except Exception:
        pytest.skip("Tkinter display not available in environment")
        return
    yield root
    try:
        root.destroy()
    except Exception:
        pass
