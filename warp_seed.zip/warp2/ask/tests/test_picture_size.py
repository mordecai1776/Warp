# WARP2/warp2/ask/tests/test_picture_size.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_picture_size.py
#  Used by   : pytest.
#  Uses      : warp2/ask/picture_size.py, warp2/ask/media.py
#              (extract_visual_subject), warp2/ask/picture_round.py (start,
#              _draw, _judge, _weigh's learn size) with a stand-in model.
#  Description:
#    A size asked for in the words is read (width first; one number is a
#    square), left out of the subject, and carried by the round: it teaches
#    at it, draws at exactly it and is measured at it. No size asked for
#    leaves everything as it was.
#  User intention (Andrew, 2026-10-03): "it should be able to make images of
#    any size requested".
# ============================================================================
from __future__ import annotations

import warp2.ask.picture_round as picture_round
from warp2.ask.media import extract_visual_subject
from warp2.ask.picture_size import requested_size, without_size


def test_sizes_are_read_from_the_words():
    assert requested_size("a cat 512x512") == [512, 512]
    assert requested_size("draw a tree 1920 by 1080") == [1920, 1080]
    assert requested_size("a sphere at 800 px") == [800, 800]
    assert requested_size("a dog, 300 pixels wide") == [300, 300]
    assert requested_size("a boat 640 × 480 px") == [640, 480]
    assert requested_size("a car size 256") == [256, 256]
    assert requested_size("a cat") == [] and requested_size("3 cats") == []
    assert requested_size("a cat 0x10") == []


def test_the_size_is_not_part_of_the_subject():
    assert without_size("a cat 512x512") == "a cat"
    assert extract_visual_subject("draw a cat at 512x512") == extract_visual_subject("draw a cat")
    assert extract_visual_subject("make an image of a tree 1920 by 1080") == extract_visual_subject("make an image of a tree")


class Sized:
    """Intention: a picture model that records the sizes it is asked for."""
    def __init__(self):
        self.drawn, self.measured = [], []

    def generate(self, tag, destination, seed=0, **sized):
        from PIL import Image
        self.drawn.append(sized)
        Image.new("RGB", (sized.get("wide", 8), sized.get("high", 8)), (200, 10, 10)).save(destination)
        return {}

    def draw_error(self, tag, paths, size=None):
        self.measured.append(size)
        return 0.1


class Learning:
    def __init__(self, tmp_path):
        self.state = tmp_path
        self.home = tmp_path

    def _samples_out(self, holder):
        pass

    def _checkpoint(self, model):
        pass


def test_a_round_draws_and_is_measured_at_the_size_asked_for(tmp_path, monkeypatch):
    model = Sized()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)
    state = picture_round.start("cat", 1, size=[48, 32])
    assert state["size"] == [48, 32]
    state.update(part="draw", tag="cat", measured_on=["p.png"])
    round_ = picture_round.PictureRound(Learning(tmp_path))
    round_._draw(state)
    assert model.drawn[-1] == {"wide": 48, "high": 32}
    state["part"] = "judge"
    round_._judge(state)
    assert model.measured[-1] == [48, 32]


def test_no_size_asked_for_leaves_the_round_as_it_was(tmp_path, monkeypatch):
    model = Sized()
    monkeypatch.setattr(picture_round, "_model", lambda learning: model)
    state = picture_round.start("cat", 1)
    assert state["size"] == []
    state.update(part="draw", tag="cat", measured_on=["p.png"])
    round_ = picture_round.PictureRound(Learning(tmp_path))
    round_._draw(state)
    round_._judge(state)
    assert model.drawn[-1] == {} and model.measured[-1] is None
