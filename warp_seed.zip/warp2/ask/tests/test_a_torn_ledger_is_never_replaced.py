# WARP2/warp2/ask/tests/test_a_torn_ledger_is_never_replaced.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_a_torn_ledger_is_never_replaced.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/ask/code_learning.py, logic_learning.py, model_learning.py, math_learning.py (the ledgers),
#              projects/behemoth_eye/eye/taxonomy.py (ConceptTaxonomy, AbilityBalancer),
#              projects/behemoth_eye/eye/reactive_policy.py; warp2/record/kept_file.py.
#  Description:
#    The four learning ledgers, the taxonomy's two stores and the reactive policy file: a torn one stops the
#    reader with the reason and stays as it is; it is never read as empty and then written over.
#  User intention (Andrew, 2026-11-06 00:06): "Clean is nothing left behind."
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
for extra in (ROOT, ROOT / "projects"):
    sys.path.insert(0, str(extra))

from warp2.record.kept_file import UnreadableKept  # noqa: E402


@pytest.mark.parametrize("module, cls, name", [
    ("warp2.ask.code_learning", "CodeLearning", "code_learning.json"),
    ("warp2.ask.logic_learning", "LogicLearning", "logic_learning.json"),
    ("warp2.ask.model_learning", "ModelLearning", "model_learning.json"),
    ("warp2.ask.math_learning", "MathLearning", "math_learning.json"),
])
def test_a_torn_learning_ledger_stops_and_stays(tmp_path, module, cls, name):
    """Intention: each ledger: a fresh one is made when none exists; a torn one raises and is untouched."""
    import importlib
    made = getattr(importlib.import_module(module), cls)
    made(tmp_path, tmp_path)
    file = tmp_path / "knowledge" / name
    assert file.is_file()
    file.write_text("{torn", encoding="utf-8")
    with pytest.raises(UnreadableKept):
        made(tmp_path, tmp_path)
    assert file.read_text(encoding="utf-8") == "{torn"


def test_a_torn_taxonomy_store_stops_and_stays(tmp_path):
    """Intention: ConceptTaxonomy.load and AbilityBalancer.load raise on a torn file; save() never follows."""
    from projects.behemoth_eye.eye.taxonomy import AbilityBalancer, ConceptTaxonomy
    tax = ConceptTaxonomy(state_dir=tmp_path) if "state_dir" in ConceptTaxonomy.__init__.__code__.co_varnames else ConceptTaxonomy(tmp_path)
    tax.taxonomy_path.parent.mkdir(parents=True, exist_ok=True)
    tax.taxonomy_path.write_text("{torn", encoding="utf-8")
    with pytest.raises(UnreadableKept):
        tax.load()
    assert tax.taxonomy_path.read_text(encoding="utf-8") == "{torn"
    bal = AbilityBalancer(state_dir=tmp_path) if "state_dir" in AbilityBalancer.__init__.__code__.co_varnames else AbilityBalancer(tmp_path)
    bal.store_path.parent.mkdir(parents=True, exist_ok=True)
    bal.store_path.write_text("{torn", encoding="utf-8")
    with pytest.raises(UnreadableKept):
        bal.load()


def test_a_torn_policy_file_stops_and_is_written_whole(tmp_path):
    """Intention: ReactivePolicy.load raises on a torn file; save goes through a temporary name."""
    from projects.behemoth_eye.eye.reactive_policy import ReactivePolicy
    policy = ReactivePolicy()
    file = tmp_path / "policy.json"
    policy.save(file)
    assert file.is_file() and not file.with_name("policy.json.tmp").exists()
    file.write_text("{torn", encoding="utf-8")
    with pytest.raises(UnreadableKept):
        policy.load(file)
