# WARP2/warp2/ask/tests/test_thread_writes_safely.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_thread_writes_safely.py
#  Used by   : pytest.
#  Uses      : warp2/ask/thread.py, warp2/record/locks.py.
#  Description:
#    The conversation file is never emptied before a rewrite, and a turn added
#    while another process holds the file waits for it instead of being lost.
#  User intention (Andrew): the conversation is something he can close and
#    come back to (check G2, 2026-10-09).
# ============================================================================
from __future__ import annotations

import threading
import time
from pathlib import Path

from warp2.ask.thread import WARP, Thread
from warp2.record.locks import Lock


def test_a_rewrite_never_empties_the_file_first(tmp_path, monkeypatch):
    thread = Thread(tmp_path)
    thread.add(WARP, "a picture", image="x.png")
    monkeypatch.setattr(Path, "write_text", lambda *a, **k: (_ for _ in ()).throw(AssertionError("write_text")))
    assert thread.strip_all_images() == 1
    assert thread.recent()[-1]["stored_image"] == "x.png"
    assert thread.reset()["turns"] == 1 and thread.recent() == []


def test_a_turn_added_while_the_file_is_held_waits_and_is_kept(tmp_path):
    thread = Thread(tmp_path)
    thread.add(WARP, "first")
    added = []
    with Lock(thread.path, seconds=30):
        worker = threading.Thread(target=lambda: added.append(thread.add(WARP, "second")))
        worker.start()
        time.sleep(0.3)
        assert added == []          # it waits for the holder
    worker.join(10)
    assert [t["said"] for t in thread.recent()] == ["first", "second"]
