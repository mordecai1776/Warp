# WARP2/warp2/ask/tests/test_confirm_does_not_freeze.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/tests/test_confirm_does_not_freeze.py
#  Used by   : pytest.
#  Uses      : warp2/ask/visual.py (VisualLearning._save, _samples_out).
#  Description:
#    The visual-learning ledger keeps claims, not samples: each attempt's
#    generated sample is written to its own file and named by path, so the
#    ledger stays small enough to read and write on every click.
#  User intention (Andrew, 2026-09-18):
#    "The action center still freezes when I conferm images."
# ============================================================================
from __future__ import annotations

import json

from warp2.ask.visual import VisualLearning


def test_a_sample_is_kept_beside_the_ledger_not_in_it(tmp_path):
    """Intention: after a save, no attempt carries its sample inline, and none is lost."""
    learning = VisualLearning(tmp_path / "root", tmp_path / "state")
    data = {"references": {}, "subjects": {}, "last_practice": 0,
            "attempts": {"a1": {"id": "a1", "subject": "cat", "sample": {"pixels": [1, 2, 3]}}}}
    learning._save(data)
    stored = json.loads(learning.path.read_text(encoding="utf-8"))
    attempt = stored["attempts"]["a1"]
    assert "sample" not in attempt
    assert json.loads((tmp_path / "state" / attempt["sample_path"]).read_text()) == {"pixels": [1, 2, 3]}
    learning._save(stored)
    assert json.loads(learning.path.read_text(encoding="utf-8")) == stored
