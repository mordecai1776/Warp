# WARP2/warp2/ask/model_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/model_learning.py
#  Used by   : warp2/ask/tests/test_model_learning.py, warp2/run.py,
#              warp2/work/side/fleet.py
#  Uses      : warp2/models/analysis.py, warp2/store/problem_web.py,
#              warp2/store/store.py, warp2/store/tagnet.py, warp2/util.py
#  Description:
#    ModelLearning: Tests fleet models, analyzes competence, tracks flaws,
#    and writes evaluation receipts.
#  User intention:
#    Not written down in this file yet; noted to ask Andrew (2026-09-18).
# ============================================================================
"""ModelLearning: Tests fleet models, analyzes competence, tracks flaws, and writes evaluation receipts."""
from __future__ import annotations

import ast
import json
import os
import re
import time
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from warp2.models.analysis import ModelAnalyzer, ModelFingerprint
from warp2.store.store import Store
from warp2.util import now_iso
from warp2.record.swallowed import noted


@dataclass
class ModelBenchmarkTask:
    """A standardized test task evaluating a model capability."""
    name: str
    domain: str
    prompt: str
    verifier: Callable[[str], tuple[bool, bool, bool, str, float]]


def _extract_code(text: str) -> str:
    """Extract python code from raw model response, handling markdown fences or raw code."""
    fence_matches = re.findall(r"```(?:python)?\s*\n(.*?)\n```", text, flags=re.DOTALL)
    if fence_matches:
        return fence_matches[0].strip()
    # Fallback: remove thinking tags if present
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
    return cleaned


def _verify_is_palindrome(response: str) -> tuple[bool, bool, bool, str, float]:
    """Verify python is_palindrome function."""
    code = _extract_code(response)
    if not code:
        return False, False, False, "empty_response", 0.0

    try:
        parsed = ast.parse(code)
    except SyntaxError as err:
        return False, False, False, f"syntax_error: {err.msg}", 0.0

    func_found = any(isinstance(node, ast.FunctionDef) and "palindrome" in node.name.lower()
                     for node in ast.walk(parsed))
    if not func_found:
        return False, True, False, "missing_required_function", 0.3

    # Safe execution in isolated dictionary
    env: dict[str, Any] = {}
    try:
        compiled = compile(parsed, filename="<eval>", mode="exec")
        exec(compiled, env)
        func = None
        for k, v in env.items():
            if callable(v) and "palindrome" in k.lower():
                func = v
                break
        if not func:
            return False, True, False, "function_not_callable", 0.3

        t1 = func("racecar") is True
        t2 = func("radar") is True
        t3 = func("hello") is False
        t4 = func("a") is True
        t5 = func("") is True

        if all([t1, t2, t3, t4, t5]):
            return True, True, True, "", 1.0
        return False, True, False, "assertion_failure", 0.6
    except Exception as exc:
        return False, True, False, f"runtime_exception: {exc}", 0.2


def _verify_reverse_words(response: str) -> tuple[bool, bool, bool, str, float]:
    """Verify python reverse_words function."""
    code = _extract_code(response)
    if not code:
        return False, False, False, "empty_response", 0.0

    try:
        parsed = ast.parse(code)
    except SyntaxError as err:
        return False, False, False, f"syntax_error: {err.msg}", 0.0

    env: dict[str, Any] = {}
    try:
        exec(code, env)
        func = None
        for k, v in env.items():
            if callable(v) and ("reverse" in k.lower() or "words" in k.lower()):
                func = v
                break
        if not func:
            return False, True, False, "missing_required_function", 0.3

        t1 = func("hello world").strip() == "world hello"
        t2 = func("warp2 engine ready").strip() == "ready engine warp2"
        if t1 and t2:
            return True, True, True, "", 1.0
        return False, True, False, "assertion_failure", 0.6
    except Exception as exc:
        return False, True, False, f"runtime_exception: {exc}", 0.2


def _verify_logic_deduction(response: str) -> tuple[bool, bool, bool, str, float]:
    """Verify modus tollens deduction."""
    cleaned = re.sub(r"<think>.*?</think>", "", response, flags=re.DOTALL).strip().lower()
    if not cleaned:
        return False, True, False, "empty_response", 0.0

    # In "If P then Q; not Q -> therefore not P" (Did it rain? No.)
    has_no = bool(re.search(r"\bno\b", cleaned))
    has_yes = bool(re.search(r"\byes\b", cleaned))

    if has_no and not has_yes:
        return True, True, True, "", 1.0
    elif has_yes:
        return False, True, False, "logical_fallacy_denying_antecedent", 0.0
    return False, True, False, "ambiguous_reasoning", 0.4


def _verify_gate_json_contract(response: str) -> tuple[bool, bool, bool, str, float]:
    """Verify strict JSON output contract adherence."""
    cleaned = re.sub(r"<think>.*?</think>", "", response, flags=re.DOTALL).strip()
    json_match = re.search(r"\{.*?\}", cleaned, flags=re.DOTALL)
    if not json_match:
        return False, False, False, "contract_violation_no_json", 0.0

    try:
        parsed = json.loads(json_match.group(0))
        if parsed.get("status") == "ok" and parsed.get("count") == 42:
            return True, True, True, "", 1.0
        return False, True, False, "contract_violation_wrong_schema", 0.5
    except Exception as err:
        return False, False, False, f"json_syntax_error: {err}", 0.0


def _verify_binary_search(response: str) -> tuple[bool, bool, bool, str, float]:
    """Verify binary search implementation."""
    code = _extract_code(response)
    if not code:
        return False, False, False, "empty_response", 0.0

    try:
        parsed = ast.parse(code)
    except SyntaxError as err:
        return False, False, False, f"syntax_error: {err.msg}", 0.0

    env: dict[str, Any] = {}
    try:
        exec(code, env)
        func = None
        for k, v in env.items():
            if callable(v) and "binary" in k.lower():
                func = v
                break
        if not func:
            return False, True, False, "missing_required_function", 0.3

        arr = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91]
        t1 = func(arr, 23) == 5
        t2 = func(arr, 2) == 0
        t3 = func(arr, 91) == 9
        t4 = func(arr, 50) == -1
        t5 = func([], 10) == -1

        if all([t1, t2, t3, t4, t5]):
            return True, True, True, "", 1.0
        return False, True, False, "assertion_failure_bounds", 0.5
    except Exception as exc:
        return False, True, False, f"runtime_exception: {exc}", 0.2


STANDARD_TASKS = [
    ModelBenchmarkTask(
        name="is_palindrome_syntax",
        domain="syntax",
        prompt="Write a Python function `def is_palindrome(s: str) -> bool:` that returns True if s is a palindrome and False otherwise. Output only the code.",
        verifier=_verify_is_palindrome,
    ),
    ModelBenchmarkTask(
        name="reverse_words_algorithm",
        domain="algorithm",
        prompt="Write a Python function `def reverse_words(s: str) -> str:` that returns the words in reverse order separated by a single space. Output only the code.",
        verifier=_verify_reverse_words,
    ),
    ModelBenchmarkTask(
        name="modus_tollens_deduction",
        domain="logic",
        prompt="Premise 1: If it rains, the ground is wet. Premise 2: The ground is NOT wet. Question: Did it rain? Answer ONLY 'YES' or 'NO' followed by one sentence explanation.",
        verifier=_verify_logic_deduction,
    ),
    ModelBenchmarkTask(
        name="strict_json_gate_contract",
        domain="gate",
        prompt="Return a strict JSON object with exact keys 'status' set to 'ok' and 'count' set to 42. Output raw JSON only, no markdown, no other words.",
        verifier=_verify_gate_json_contract,
    ),
    ModelBenchmarkTask(
        name="binary_search_bounds",
        domain="algorithm",
        prompt="Write a Python function `def binary_search(arr: list[int], target: int) -> int:` returning index of target in sorted arr, or -1 if not found. Handle empty lists. Output code only.",
        verifier=_verify_binary_search,
    ),
]


class ModelLearning:
    """Evaluates fleet models, analyzes competence, tracks signature flaws, and records empirical facts."""

    def __init__(self, root_dir: Path | str, state_dir: Path | str) -> None:
        """Intention: set up the ledger and analysis paths, the store and the model analyzer, load the
        ledger and seed the trials.
        """
        self.root_dir = Path(root_dir)
        self.state_dir = Path(state_dir)
        self.knowledge_dir = self.state_dir / "knowledge"
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)
        self.models_state_dir = self.state_dir / "models"
        self.models_state_dir.mkdir(parents=True, exist_ok=True)

        self.ledger_path = self.knowledge_dir / "model_learning.json"
        self.analysis_path = self.models_state_dir / "analysis.json"

        self.store = Store(self.state_dir)
        self.analyzer = ModelAnalyzer(store=self.store)
        self._load_ledger()
        self._seed_tagnet_trials()

    def _load_ledger(self) -> dict[str, Any]:
        """Intention: read the ledger, or start (and save) an empty one; a broken file is read as empty."""
        if not self.ledger_path.is_file():
            self.data: dict[str, Any] = {
                "models": {},
                "total_evaluations": 0,
                "last_model_index": 0,
            }
            self._save_ledger()
        else:
            # Intention (2026-11-07): a ledger that cannot be read stops here (warp2/record/kept_file.py) - it used to
            # be read as empty and the next save wrote the empty one over the whole learning history.
            from warp2.record.kept_file import read_kept
            self.data = read_kept(self.ledger_path, {"models": {}, "total_evaluations": 0, "last_model_index": 0})
        return self.data

    def _save_ledger(self) -> None:
        """Intention: write the ledger whole through a temp file, so a crash never leaves half a file."""
        temp = self.ledger_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(self.ledger_path)

    def _seed_tagnet_trials(self) -> None:
        """Seed baseline evaluation facts from historical tagnet standing if no trials exist."""
        try:
            from warp2.store.tagnet import TagNet
            tagnet = TagNet(self.store)
            models = self.get_roster_models()
            for m in models:
                m_name = m.get("name") if isinstance(m, dict) else str(m)
                existing = self.store.current(subject=f"eval:{m_name}")
                if not existing:
                    trials = sum(tagnet.trials(m_name, f"work:{k}") for k in ("build", "test", "revise", "connect"))
                    if trials > 0:
                        weights = [tagnet.weight(m_name, f"work:{k}") for k in ("build", "test", "revise", "connect") if tagnet.trials(m_name, f"work:{k}") > 0]
                        avg_w = sum(weights) / len(weights) if weights else 500
                        success = avg_w >= 500
                        for idx in range(min(trials, 3)):
                            self.analyzer.record_trial(
                                model=m_name,
                                outcome="ok" if success else "refused",
                                syntax_ok=True,
                                gate_accepted=success,
                                failure_type="" if success else "historical_low_weight",
                                task_kind="historical_fleet_standing",
                                score=round(avg_w / 1000.0, 2),
                                details={"source": "tagnet_seed", "trials": trials},
                            )
        except Exception as exc:
            noted("warp2/ask/model_learning.py:ModelLearning._seed_tagnet_trials", exc)

    def get_roster_models(self) -> list[dict[str, Any]]:
        """Get all enabled models defined in models.json."""
        roster_path = self.root_dir / "models.json"
        if not roster_path.is_file():
            return []
        try:
            data = json.loads(roster_path.read_text(encoding="utf-8"))
            models = data.get("models", [])
            return [m for m in models if m.get("enabled", True) is not False]
        except Exception:
            return []

    def query_model(self, model_entry: dict[str, Any], prompt: str, timeout: float = 30.0) -> tuple[str, float, str]:
        """Query a model backend with a strict deadline and error capture.

        Returns (response_text, elapsed_ms, error_kind).
        """
        how = str(model_entry.get("how", "")).lower()
        name = str(model_entry.get("ollama_model") or model_entry.get("name", ""))
        path = str(model_entry.get("path", ""))

        t0 = time.perf_counter()

        if how == "ollama" and path:
            try:
                tokens_budget = min(int(model_entry.get("max_tokens") or 512), 1024)
                req_data = json.dumps({
                    "model": name,
                    "stream": False,
                    "think": False,
                    "options": {"num_predict": tokens_budget, "temperature": 0.0},
                    "messages": [{"role": "user", "content": prompt}],
                }).encode("utf-8")
                req = urllib.request.Request(
                    path,
                    headers={"Content-Type": "application/json"},
                    data=req_data,
                )
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    payload = json.loads(resp.read().decode("utf-8"))
                elapsed_ms = (time.perf_counter() - t0) * 1000.0
                msg = payload.get("message", {})
                content = msg.get("content", "") or msg.get("thinking", "")
                return content, elapsed_ms, ""
            except urllib.error.URLError as err:
                elapsed_ms = (time.perf_counter() - t0) * 1000.0
                if "timed out" in str(err).lower() or isinstance(getattr(err, "reason", None), TimeoutError):
                    return "", elapsed_ms, "timeout"
                return "", elapsed_ms, f"endpoint_offline: {err.reason}"
            except TimeoutError:
                elapsed_ms = (time.perf_counter() - t0) * 1000.0
                return "", elapsed_ms, "timeout"
            except Exception as exc:
                elapsed_ms = (time.perf_counter() - t0) * 1000.0
                if "timed out" in str(exc).lower():
                    return "", elapsed_ms, "timeout"
                return "", elapsed_ms, f"error: {exc}"

        elif how == "direct":
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            return "", elapsed_ms, "direct_weights_offline"

        elif how == "external":
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            return "", elapsed_ms, "external_advisor_idle"

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return "", elapsed_ms, f"unsupported_how: {how}"

    def evaluate_pass(self, model_name: str | None = None, task_name: str | None = None) -> dict[str, Any]:
        """Run one model evaluation and analysis pass."""
        models = self.get_roster_models()
        if not models:
            return {
                "model": "none",
                "task": "none",
                "kind": "none",
                "outcome": "skipped",
                "syntax_ok": False,
                "gate_ok": False,
                "failure_type": "no_models_in_roster",
                "success_rate": 0.0,
                "syntax_rate": 0.0,
                "trials": 0,
                "flaws_summary": "none",
                "summary": "No models configured in models.json",
                "execution_time_ms": 0.0,
            }

        # Select model (target model if specified, otherwise round-robin)
        if model_name:
            matching = [m for m in models if m.get("name") == model_name]
            target_model = matching[0] if matching else models[0]
        else:
            idx = self.data.get("last_model_index", 0) % len(models)
            target_model = models[idx]
            self.data["last_model_index"] = (idx + 1) % len(models)

        chosen_model_name = str(target_model.get("name", "unknown"))

        # Select benchmark task (target task if specified, otherwise round-robin)
        if task_name:
            matching_tasks = [t for t in STANDARD_TASKS if t.name == task_name]
            task = matching_tasks[0] if matching_tasks else STANDARD_TASKS[0]
        else:
            task_idx = self.data.get("total_evaluations", 0) % len(STANDARD_TASKS)
            task = STANDARD_TASKS[task_idx]

        # Execute query with configured model timeout (default 30s)
        timeout = float(target_model.get("seconds") or 30.0)
        raw_output, elapsed_ms, query_err = self.query_model(target_model, task.prompt, timeout=timeout)

        if query_err:
            outcome_ok = False
            syntax_ok = False
            gate_accepted = False
            failure_type = query_err
            score = 0.0
        else:
            outcome_ok, syntax_ok, gate_accepted, failure_type, score = task.verifier(raw_output)

        outcome_str = "ok" if outcome_ok else "refused"

        # Assert trial fact into append-only store
        self.analyzer.record_trial(
            model=chosen_model_name,
            outcome=outcome_str,
            syntax_ok=syntax_ok,
            gate_accepted=gate_accepted,
            failure_type=failure_type,
            task_kind=task.domain,
            score=score,
            details={"task": task.name, "elapsed_ms": round(elapsed_ms, 2)},
        )

        if failure_type:
            try:
                from warp2.store.problem_web import ProblemWeb
                pweb = ProblemWeb(store=self.store, state_dir=self.state_dir)
                pweb.record_incident(
                    source=f"model:{chosen_model_name}",
                    error_text=failure_type,
                    context={"task": task.name, "domain": task.domain},
                )
            except Exception as exc:
                noted("warp2/ask/model_learning.py:ModelLearning.evaluate_pass", exc)

        # Derive updated fingerprint
        fp = self.analyzer.fingerprint(chosen_model_name)
        prescriptions = self.analyzer.prescribe_remediation(chosen_model_name, fingerprint=fp)

        # Update local ledger
        self.data["total_evaluations"] = self.data.get("total_evaluations", 0) + 1
        self.data["models"][chosen_model_name] = {
            "fingerprint": fp.as_dict(),
            "prescriptions": prescriptions,
            "last_evaluated": now_iso(),
            "last_task": task.name,
            "last_outcome": outcome_str,
        }
        self._save_ledger()

        # Update analysis snapshot for UI
        analysis_snapshot = {
            "updated_at": now_iso(),
            "models": {m: info["fingerprint"] for m, info in self.data["models"].items()},
            "prescriptions": {m: info.get("prescriptions", []) for m, info in self.data["models"].items()},
        }
        try:
            self.analysis_path.write_text(json.dumps(analysis_snapshot, indent=2), encoding="utf-8")
        except Exception as exc:
            noted("warp2/ask/model_learning.py:ModelLearning.evaluate_pass", exc)

        flaws_summary = ", ".join(fp.signature_flaws) or "none observed"
        summary_str = f"{fp.total_trials} observed runs | {fp.success_rate:.0%} success | syntax {fp.syntax_rate:.0%} | gate {fp.gate_pass_rate:.0%}"

        return {
            "model": chosen_model_name,
            "task": task.name,
            "kind": task.domain,
            "outcome": outcome_str,
            "syntax_ok": syntax_ok,
            "gate_ok": gate_accepted,
            "failure_type": failure_type,
            "success_rate": fp.success_rate,
            "syntax_rate": fp.syntax_rate,
            "gate_rate": fp.gate_pass_rate,
            "trials": fp.total_trials,
            "flaws_summary": flaws_summary,
            "summary": summary_str,
            "execution_time_ms": round(elapsed_ms, 2),
        }

    def evaluate_fleet_round(self) -> list[dict[str, Any]]:
        """Evaluate ALL enabled fleet models on the current rotating benchmark task.

        Called on regular passes of the continuous runner so every model
        is continuously tested, benchmarked, and tracked on the regular.
        """
        models = self.get_roster_models()
        if not models:
            return []

        task_idx = self.data.get("total_fleet_rounds", 0) % len(STANDARD_TASKS)
        task = STANDARD_TASKS[task_idx]
        self.data["total_fleet_rounds"] = self.data.get("total_fleet_rounds", 0) + 1
        self._save_ledger()

        round_results: list[dict[str, Any]] = []
        for m in models:
            m_name = str(m.get("name", "unknown"))
            res = self.evaluate_pass(model_name=m_name, task_name=task.name)
            round_results.append(res)

        return round_results

    def evaluate_all_models(self) -> list[dict[str, Any]]:
        """Run all enabled fleet models across every standard benchmark task.

        Guarantees that every model goes through all trials and produces
        comprehensive competence cards, flaw signatures, and remediation paths.
        """
        models = self.get_roster_models()
        results: list[dict[str, Any]] = []
        for m in models:
            m_name = m.get("name", "")
            for task in STANDARD_TASKS:
                res = self.evaluate_pass(model_name=m_name, task_name=task.name)
                results.append(res)
        return results
