# WARP2/warp2/ask/image_asks.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/image_asks.py
#  Used by   : warp2/ask/window.py (the image queue in the sidebar).
#  Uses      : warp2/ask/inbox.py (what was asked), warp2/ask/request_folder.py
#              (what the project did with it), state/images/catalog.jsonl
#              (read again only when it changes).
#  Description:
#    Where each picture a person asked for stands, read from the records the
#    window and the loop already write. The window keeps no queue of its own.
#  User intention (Andrew, 2026-09-18):
#    "detach the immediate change that image user stuff works and place that
#    into something that adds to the work instead of acting like a trigger."
#    The sidebar queue now shows the work, not a thread in the window.
# ============================================================================
from __future__ import annotations

from pathlib import Path

from warp2.ask.inbox import IMAGE, Inbox
from warp2.ask.request_folder import RequestFolder
from warp2.record.swallowed import noted

# Intention: the four words the sidebar already draws icons for.
PENDING, QUEUED, DONE, FAILED = "pending", "rendering", "completed", "failed"


# Intention (2026-11-01, measured): THE CATALOG IS READ ONCE PER CHANGE. The sidebar asks every two seconds for each
# picture still being made; each ask read and parsed the whole 24.6 MB catalog, which kept the window's own thread at
# half a core. The answer for one subject only changes when the catalog does, so it is kept until the file changes.
_CATALOG_SEEN: dict = {}


def _catalog_image(cat_file: Path, subject: str) -> str:
    """Intention: the newest catalog picture whose subject matches, read again only when the catalog changes."""
    try:
        st = cat_file.stat()
    except OSError:
        return ""
    key = (str(cat_file), st.st_mtime_ns, st.st_size, subject)
    if key in _CATALOG_SEEN:
        return _CATALOG_SEEN[key]
    found = ""
    try:
        import json
        lines = cat_file.read_text(encoding="utf-8", errors="replace").splitlines()
        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            entry = json.loads(line)
            ent_sub = str(entry.get("subject") or "").strip().lower()
            if subject and (ent_sub == subject or subject in ent_sub):
                img_p = entry.get("image_path")
                if img_p and Path(img_p).is_file():
                    found = str(img_p)
                    break
    except Exception as exc:
        noted("warp2/ask/image_asks.py:_catalog_image", exc)
        found = ""
    if len(_CATALOG_SEEN) > 64:
        _CATALOG_SEEN.clear()
    _CATALOG_SEEN[key] = found
    return found


def _newest_preview(previews_dir: Path) -> str:
    """Intention: the newest training preview, looked for again only when the folder's listing changes.

    Sorting every preview by its time was most of what the window's thread did between readings (the folder is under
    OneDrive, where each file's time is a slow ask); a file added or removed changes the folder's own time.
    """
    try:
        key = ("previews", str(previews_dir), previews_dir.stat().st_mtime_ns)
    except OSError:
        return ""
    found = _CATALOG_SEEN.get(key)
    if found is None:
        found = ""
        try:
            pngs = sorted(previews_dir.glob("*.png"), key=lambda f: f.stat().st_mtime, reverse=True)
            if pngs:
                found = str(pngs[0].resolve())
        except Exception:  # Intention: a preview can be removed while the folder is sorted; the next place is looked at right after.
            found = ""
        if len(_CATALOG_SEEN) > 64:
            _CATALOG_SEEN.clear()
        _CATALOG_SEEN[key] = found
    if found and not Path(found).is_file():
        _CATALOG_SEEN.pop(key, None)
        return ""
    return found


class ImageAsks:
    """Every picture asked for, newest first, with where it stands."""

    def __init__(self, state, folder=None) -> None:
        """Intention: `folder` is the project's request folder; by default the picture project's."""
        self.state = Path(state)
        self.inbox = Inbox(state)
        self.requests = RequestFolder(folder or self.state / "centering_image" / "inbox")

    def rows(self, limit: int = 20) -> list:
        """Intention: one row per image ask, in the shape the sidebar draws."""
        out = []
        for asked in self.inbox.recent(limit=int(limit) * 3):
            if asked.get("kind") != IMAGE:
                continue
            out.append({"id": asked.get("id", ""), "subject": asked.get("said", ""),
                        **self.standing(asked)})
            if len(out) >= int(limit):
                break
        return out

    def standing(self, asked: dict) -> dict:
        """Where one ask stands.

        Intention: waiting in the inbox is pending; passed to the project and
        not yet made is queued in the work; made is done, with its picture.
        """
        answer = asked.get("answer") or {}
        if not answer:
            return {"status": PENDING, "image_path": "", "error": ""}
        if answer.get("how") != "asked for it":
            return {"status": FAILED, "image_path": "", "error": str(answer.get("how") or "")}
        made = self.requests.answer(str(asked.get("id") or ""))
        if made is None:
            preview = self._latest_preview(asked)
            return {"status": QUEUED, "image_path": preview, "error": ""}
        result = made.get("result") or {}
        picture = str(result.get("image_path") or "")
        return {"status": DONE if picture else FAILED, "image_path": picture,
                "error": "" if picture else "could not make it"}

    def _latest_preview(self, asked: dict) -> str:
        """Find the latest candidate or preview image path for an in-progress ask."""
        ask_id = str(asked.get("id") or "")
        subject = str(asked.get("said") or asked.get("subject") or "").strip().lower()
        # 1. Check in-progress request file
        req_file = self.requests.folder / f"{ask_id}.json"
        if req_file.is_file():
            try:
                import json
                data = json.loads(req_file.read_text(encoding="utf-8"))
                resume = data.get("resume") or {}
                p = (resume.get("best") or {}).get("image_path") or (resume.get("part_state") or {}).get("image_path")
                if p and Path(p).is_file():
                    return str(p)
            except Exception as exc:
                noted("warp2/ask/image_asks.py:ImageAsks._latest_preview", exc)

        # 2. Check catalog.jsonl for latest image with matching subject
        cat_file = self.state / "images" / "catalog.jsonl"
        if cat_file.is_file():
            img_p = _catalog_image(cat_file, subject)
            if img_p and Path(img_p).is_file():
                return str(img_p)

        # 3. Check training_previews directory
        previews_dir = self.state / "visual_learning" / "training_previews"
        if previews_dir.is_dir():
            newest = _newest_preview(previews_dir)
            if newest:
                return newest

        # 4. Check visual_learning root for current snapshots
        vl_dir = self.state / "visual_learning"
        if vl_dir.is_dir():
            snap = vl_dir / f"current_{subject}_snapshot.png"
            if snap.is_file():
                return str(snap.resolve())
            smooth = vl_dir / f"new_{subject}_smooth.png"
            if smooth.is_file():
                return str(smooth.resolve())
        return ""

    def cancel(self, ask_id: str) -> bool:
        """Take back an ask the loop has not reached yet.

        Intention: only while it is still pending. Once the loop has it, it is
        work in progress, and pulling it out of the middle helps nobody.
        """
        for asked in self.inbox.waiting():
            if asked.get("id") == ask_id and asked.get("kind") == IMAGE:
                self.inbox.handled(ask_id, "cancelled by you")
                return True
        return False
