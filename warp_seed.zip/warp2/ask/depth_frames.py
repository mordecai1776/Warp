# WARP2/warp2/ask/depth_frames.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/depth_frames.py
#  Used by   : warp2/work/side/depth_lessons.py; warp2/ask/tests/test_depth_frames.py.
#  Uses      : warp2/ask/hub_pictures.py (_get, fetch — the Hugging Face hub,
#              as the picture pull uses it); (stdlib) json, pathlib.
#  Description:
#    Exact depth maps to learn from: the Hypersim frames (photo-real rendered
#    rooms, so every pixel's depth is exact — no holes, no sensor noise), a
#    full-size 1024 x 768 colour picture and its depth in millimetres per
#    frame. Fetched one frame at a time as the lessons need them, kept in
#    state/visual_learning/real_world/hypersim/, the place in the list kept
#    on disk so a restart goes on where it was. One frame of the dataset's
#    own validation part is kept apart, never taught, for the drawings shown;
#    the first frame of each of the next validation scenes (a fixed set,
#    never the named frame) is kept apart beside it (BUILD_LOG 746).
#    peek() (BUILD_LOG 810): the coming frames read without moving the place.
#  User intention (Andrew, 2026-10-25): "we need to have a exact depth map
#    dataset that we train on with the eye and learn it at full color and
#    resolution". BUILD_LOG 659.
# ============================================================================
"""Exact depth frames (Hypersim), one at a time."""
from __future__ import annotations

import json
from pathlib import Path

DATASET = "omrastogi/Hypersim-Processed"
TREE = f"https://huggingface.co/api/datasets/{DATASET}/tree/main"
FILE = f"https://huggingface.co/datasets/{DATASET}/resolve/main"
PHOTO, DEPTH = "rgb_cam_00", "depth_plane_cam_00"


class HypersimFrames:
    """Intention: the next exact frame to learn from, fetched when asked for; the place kept on disk."""

    def __init__(self, state, get=None, fetch=None) -> None:
        """Intention: `get` and `fetch` are the hub calls (passed in by tests; the hub's own otherwise)."""
        from warp2.ask import hub_pictures
        self.home = Path(state) / "visual_learning" / "real_world" / "hypersim"
        self.get = get or (lambda url: hub_pictures._get(url, 30.0))
        self.fetch = fetch or (lambda url: hub_pictures.fetch(url, 60.0))
        self.place_file = self.home / "place.json"

    def _read(self, path: Path, default):
        """Intention: a kept list or place read back from disk; `default` when it is missing or broken."""
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return default

    def _write(self, path: Path, value) -> None:
        """Intention: keep a list or place on disk so a restart goes on where it was."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value), encoding="utf-8")

    def scenes(self, split: str = "train") -> list:
        """Intention: the dataset's scenes for a split, listed once and kept."""
        kept = self.home / f"scenes_{split}.json"
        found = self._read(kept, None)
        if not found:
            found = sorted(str(x["path"]).split("/")[-1] for x in self.get(f"{TREE}/{split}") if x.get("type") == "directory")
            self._write(kept, found)
        return found

    def frames(self, split: str, scene: str) -> list:
        """Intention: a scene's frame numbers (those with both a photo and its depth), listed once and kept."""
        kept = self.home / "frames" / f"{split}_{scene}.json"
        found = self._read(kept, None)
        if found is None:
            names = [str(x["path"]).split("/")[-1] for x in self.get(f"{TREE}/{split}/{scene}?recursive=true")]
            photos = {n[len(PHOTO) + 3:-4] for n in names if n.startswith(PHOTO + "_fr") and n.endswith(".png")}
            depths = {n[len(DEPTH) + 3:-4] for n in names if n.startswith(DEPTH + "_fr") and n.endswith(".png")}
            found = sorted(photos & depths)
            self._write(kept, found)
        return found

    def fetched(self, split: str, scene: str, frame: str) -> tuple:
        """Intention: one frame's photo and depth files on disk (fetched the first time)."""
        folder = self.home / split / scene
        folder.mkdir(parents=True, exist_ok=True)
        out = []
        for kind in (PHOTO, DEPTH):
            path = folder / f"{kind}_fr{frame}.png"
            if not path.is_file():
                data = self.fetch(f"{FILE}/{split}/{scene}/{kind}_fr{frame}.png")
                temporary = path.with_suffix(".part")
                temporary.write_bytes(data)
                temporary.replace(path)
            out.append(path)
        return tuple(out)

    def next(self) -> tuple:
        """Intention: the next training frame (photo path, depth path, its name), and the place moved on."""
        scenes = self.scenes("train")
        place = self._read(self.place_file, {"scene": 0, "frame": 0})
        for _ in range(len(scenes)):
            scene = scenes[place["scene"] % len(scenes)]
            frames = self.frames("train", scene)
            if place["frame"] < len(frames):
                frame = frames[place["frame"]]
                photo, depth = self.fetched("train", scene, frame)
                place["frame"] += 1
                self._write(self.place_file, place)
                return photo, depth, f"{scene} frame {frame}"
            place = {"scene": place["scene"] + 1, "frame": 0}
        raise LookupError("no Hypersim frame could be listed")

    def peek(self, count: int, skip: int = 0) -> list:
        """Intention (Muse-705/710; BUILD_LOG 810): the next `count` training frames, (photo, depth, name) each, read
        from one snapshot of the place and WITHOUT moving it — the frames the coming lessons will be taught, so they
        can be read before teaching. The place on disk is left as it was.
        Intention (Muse-713/714; BUILD_LOG 817): `skip` frames first are passed over in the same order — counted from
        the scene lists, never fetched or opened — so frames far past the turn (the look-ahead's controls) are cheap."""
        scenes = self.scenes("train")
        place = dict(self._read(self.place_file, {"scene": 0, "frame": 0}))
        out, skipped = [], 0
        for _ in range(len(scenes) + count + int(skip)):
            if len(out) >= count:
                break
            scene = scenes[place["scene"] % len(scenes)]
            frames = self.frames("train", scene)
            if place["frame"] < len(frames) and skipped < int(skip):
                place["frame"] += 1
                skipped += 1
                continue
            if place["frame"] < len(frames):
                frame = frames[place["frame"]]
                photo, depth = self.fetched("train", scene, frame)
                place["frame"] += 1
                out.append((photo, depth, f"{scene} frame {frame}"))
                continue
            place = {"scene": place["scene"] + 1, "frame": 0}
        return out

    def held_apart(self) -> tuple:
        """Intention: the one frame never taught — the validation part's first frame — for the drawings shown."""
        scene = self.scenes("val")[0]
        frame = self.frames("val", scene)[0]
        photo, depth = self.fetched("val", scene, frame)
        return photo, depth, f"{scene} frame {frame} (never taught)"

    def held_apart_beside(self, count: int) -> list:
        """Intention: (BUILD_LOG 746; Muse-657/659) a fixed set of `count` more frames never taught — the first frame
        of each of the next validation scenes, never the named frame's scene — to check the named line is no fluke.
        Each is (photo, depth, name), or (None, None, name) with the reason when it could not be had."""
        out = []
        for scene in self.scenes("val")[1:1 + count]:
            try:
                frame = self.frames("val", scene)[0]
                photo, depth = self.fetched("val", scene, frame)
                out.append((photo, depth, f"{scene} frame {frame} (never taught)"))
            except Exception as error:  # noqa: BLE001 — one frame missing must not stop the named check
                out.append((None, None, f"{scene}: not had ({type(error).__name__}: {error})"))
        return out
