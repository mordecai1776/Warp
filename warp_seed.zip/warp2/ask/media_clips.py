# WARP3/warp2/ask/media_clips.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/ask/media_clips.py
#  Used by   : warp2/work/side/sound_lessons.py (SoundClips), warp2/work/side/video_lessons.py (VideoClips),
#              warp2/ask/tests/test_media_clips.py.
#  Uses      : warp2/ask/hub_pictures.py (_get, fetch - the same web calls the picture and depth pulls use),
#              warp2/record/kept_file.py (read_kept, write_kept); (stdlib) csv, io, pathlib.
#  Description:
#    Real sound and real video to learn from, one clip at a time, fetched when a lesson needs it and kept on disk
#    (nothing thrown away), the place in the list kept so a restart goes on where it was.
#    ClipList: the shared part - the list of (where it comes from, its name, its label) made once and kept, the
#    place, the next clip fetched and kept, and the clips held apart (never taught) for measuring.
#    SoundClips: ESC-50 - 2,000 five-second WAV recordings of 50 kinds of everyday sound (dog, rain, siren ...),
#    from its own GitHub home; its fifth fold is held apart, as its makers intend.
#    VideoClips: Kinetics-mini on the Hugging Face hub - short clips of people doing things (archery, bowling ...),
#    one folder a label; its "val" part is held apart.
#  User intention (Andrew, 2026-11-23 10:57, "suere" - to: a sound step feeding real audio to the Eye, and a video
#    reader with a step that teaches from it).
# ============================================================================
"""Real sound and video clips to learn from, one at a time."""
from __future__ import annotations

import csv
import io
from pathlib import Path

ESC50 = "https://raw.githubusercontent.com/karolpiczak/ESC-50/master"
KINETICS = "nateraw/kinetics-mini"
KINETICS_TREE = f"https://huggingface.co/api/datasets/{KINETICS}/tree/main"
KINETICS_FILE = f"https://huggingface.co/datasets/{KINETICS}/resolve/main"


class ClipList:
    """Intention: a list of clips made once and kept, the place in it, and each clip fetched once and kept. A
    source is a ClipList with its own `make_list(split)` (SoundClips, VideoClips)."""

    def __init__(self, home: Path, get=None, fetch=None) -> None:
        """Intention: where the clips are kept; `get` (JSON) and `fetch` (bytes) are the web calls (tests pass
        their own)."""
        from warp2.ask import hub_pictures
        self.home = Path(home)
        self.get = get or (lambda url: hub_pictures._get(url, 30.0))
        self.fetch = fetch or (lambda url: hub_pictures.fetch(url, 120.0))

    def _kept(self, name: str, default):
        """Intention: a kept list or place, or `default` when there is none yet."""
        from warp2.record.kept_file import read_kept
        return read_kept(self.home / name, lambda: default)

    def _keep(self, name: str, value) -> None:
        """Intention: a list or place written whole."""
        from warp2.record.kept_file import write_kept
        self.home.mkdir(parents=True, exist_ok=True)
        write_kept(self.home / name, value)

    def listed(self, split: str) -> list:
        """Intention: [address, name, label] for every clip of a split (the source's own list, `make_list`), the
        labels taken in turn so a lesson part meets every label early; made once and kept."""
        found = self._kept(f"list_{split}.json", None)
        if found is None:
            by_label: dict = {}
            for row in self.make_list(split):
                by_label.setdefault(row[2], []).append(row)
            longest = max((len(rows) for rows in by_label.values()), default=0)
            found = [rows[i] for i in range(longest) for rows in by_label.values() if i < len(rows)]
            self._keep(f"list_{split}.json", found)
        return found

    def fetched(self, address: str, name: str) -> Path:
        """Intention: the clip on disk, fetched the first time it is asked for."""
        path = self.home / "clips" / name
        if not path.is_file():
            path.parent.mkdir(parents=True, exist_ok=True)
            data = self.fetch(address)
            part = path.with_name(path.name + ".part")
            part.write_bytes(data)
            part.replace(path)
        return path

    def next(self) -> tuple:
        """Intention: (the clip's path, its label, its name) - the next clip to teach, going round again at the end."""
        clips = self.listed("taught")
        if not clips:
            raise LookupError("no clips listed")
        place = int(self._kept("place.json", {"at": 0}).get("at", 0))
        address, name, label = clips[place % len(clips)]
        path = self.fetched(address, name)
        self._keep("place.json", {"at": place + 1})
        return path, label, name

    def held_apart(self, count: int) -> list:
        """Intention: the first `count` clips held apart (never taught), spread over the labels, each (path, label,
        name)."""
        clips = self.listed("held")
        return [(self.fetched(address, name), label, name) for address, name, label in clips[:max(0, int(count))]]

    def labels(self) -> list:
        """Intention: every label the clips have, sorted - the classes a lesson part is taught."""
        return sorted({label for _, _, label in self.listed("taught")} | {label for _, _, label in self.listed("held")})


class SoundClips(ClipList):
    """ESC-50: five-second WAV clips of 50 kinds of everyday sound; fold 5 held apart."""

    def __init__(self, state, get=None, fetch=None, text=None) -> None:
        """Intention: kept in state/sound_learning/esc50; `text(url)` reads the list's CSV (tests pass their own)."""
        super().__init__(Path(state) / "sound_learning" / "esc50", get, fetch)
        self.text = text or (lambda url: self.fetch(url).decode("utf-8"))

    def make_list(self, split: str) -> list:
        """Intention: from the dataset's own meta/esc50.csv - folds 1-4 taught, fold 5 held apart."""
        rows = list(csv.DictReader(io.StringIO(self.text(f"{ESC50}/meta/esc50.csv"))))
        held = split == "held"
        return [[f"{ESC50}/audio/{row['filename']}", row["filename"], row["category"]] for row in rows
                if (str(row["fold"]) == "5") == held]


class VideoClips(ClipList):
    """Kinetics-mini: short clips of people doing things, a folder a label; "val" held apart."""

    def __init__(self, state, get=None, fetch=None) -> None:
        """Intention: kept in state/video_learning/kinetics_mini."""
        super().__init__(Path(state) / "video_learning" / "kinetics_mini", get, fetch)

    def make_list(self, split: str) -> list:
        """Intention: every clip in the hub's train (taught) or val (held apart) folders, a folder a label."""
        part = "val" if split == "held" else "train"
        out = []
        for folder in self.get(f"{KINETICS_TREE}/{part}"):
            if folder.get("type") != "directory":
                continue
            label = str(folder["path"]).rsplit("/", 1)[-1]
            for item in self.get(f"{KINETICS_TREE}/{folder['path']}"):
                if item.get("type") == "file" and str(item["path"]).lower().endswith(".mp4"):
                    out.append([f"{KINETICS_FILE}/{item['path']}", str(item["path"]).replace("/", "_"), label])
        return out
