# WARP2/warp2/ask/all_pictures.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/all_pictures.py
#  Used by   : warp2/work/side/true_image_lessons.py (the pictures the error
#              lessons are made from); warp2/ask/tests/test_all_pictures.py.
#  Uses      : warp2/ask/depth_frames.py (HypersimFrames, passed in);
#              warp2/ask/blender_held_apart.py (BUILD_LOG 855);
#              warp2/tags/media/pictures.py (pictures_in, open_picture - a
#              picture is listed by name and opened from its small form
#              first); PIL;
#              (stdlib) json, re, time, pathlib.
#  Description:
#    Every picture in every dataset, for the error lessons. The errors are
#    made by arithmetic on the picture (simulated), so any picture can be
#    the truth. Sources, each gone through in its own order, one picture
#    from each in turn so all of them are mined:
#      Hypersim (rendered rooms, fetched from the hub one frame at a time),
#      the Blender renders, the reference pictures, the pulled pictures,
#      the curated incoming pictures, the image references and the NYU
#      depth pictures.
#    Left out: the Eye's own drawings (previews, test pictures) and depth
#    maps — they are not pictures of anything. Each local source's list is
#    kept on disk and made again every RELIST_SECONDS, so new pictures join.
#    A file that does not open as a picture, or is too small, is passed by.
#    Where each source stands is kept on disk, so a restart goes on.
#    peek() (BUILD_LOG 810): the coming pictures read without moving the
#    place, for the look-ahead reading before teaching.
#    HubSource (BUILD_LOG 783): a hub dataset fetched one picture at a time
#    when its turn comes and kept on disk — DIV2K's clean 2K photos, mostly
#    outdoors, so the pictures cover more of the real world.
#  User intention (Andrew, 2026-10-26): "Lets change that for the errors to
#    use them all because it should all be simulated data"; (2026-10-27, on
#    covering the real world) "Then lets correct it". BUILD_LOG 726, 783.
#    BUILD_LOG 855 (Muse-743/746): a fixed set of five Blender pictures is
#    held out of teaching (warp2/ask/blender_held_apart.py) for the faint
#    reading; held_apart_blender() hands them out.
# ============================================================================
"""Every picture in every dataset, one from each source in turn."""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path

# Intention: the local sources — a name, the folder under state/, "**" for every folder below or "*" for the
# folder alone, and (when set) which names only.
SOURCES = (
    ("blender", "datasets/local/blender", "**", None),
    ("references", "visual_learning/references", "*", None),
    ("pulled", "visual_learning", "*", re.compile(r"^[0-9a-f]{32}\.png$")),
    ("curated incoming", "curated_media/incoming", "*", None),
    ("image references", "images/references", "*", None),
    ("nyu", "visual_learning/real_world/nyu_depth_v2/pictures", "*", None),
    # Intention (BUILD_LOG 863): what each kind of the picture head asked the dataset generation system for
    # (warp2/work/side/picture_needs.py), every kind's and topic's folder below.
    ("needs", "visual_learning/needs", "**", None),
)
# Intention: the picture file endings read.
ENDINGS = (".png", ".jpg", ".jpeg", ".webp", ".bmp")
# Intention: how often a local source's list is made again (new pictures join).
RELIST_SECONDS = 6 * 3600.0
# Intention: the smallest side a picture may have to be taught from.
SMALLEST = 16
# Intention: how many pictures in a row a source may fail to open before the next source has its turn.
TRIES = 20
# Intention (Andrew, 2026-10-27: "Then lets correct it"; BUILD_LOG 783): clean, high-resolution photos from the hub,
# mostly outdoors (DIV2K: 2K photos made as clean truths for this kind of training) — a name, the dataset, its folder.
HUB_SOURCES = (("div2k", "mAiello00/DIV2K", "DIV2K_train_HR"),
               # Intention (Andrew, 2026-10-28: "get a broader dataset on it"; BUILD_LOG 835): Flickr2K, 2,650 more 2K
               # photos (in DF2K, the six-digit names — the four-digit ones are DIV2K, already above), and Urban100's
               # 100 city photos, full of straight lines, the clearest place for a lens's bend to show (its HR ones).
               ("flickr2k", "pgtkhai/DF2K", "", r"^\d{6}\.png$"),
               ("urban100", "delta-prox/Urban100", "", r"_HR\.png$"))
# Intention: the hub's dataset listing and file addresses.
HUB_TREE = "https://huggingface.co/api/datasets/{repo}/tree/main/{folder}"
HUB_FILE = "https://huggingface.co/datasets/{repo}/resolve/main/{path}"
# Intention: the name the hub's rendered rooms go by in the turn.
HYPERSIM = "hypersim"


class LocalSource:
    """Intention: one local folder's pictures, listed (kept on disk, made again now and then), in order."""

    def __init__(self, state: Path, home: Path, name: str, folder: str, pattern: str, only=None) -> None:
        """Intention: the source's folder under state/, how far down it is read, its name rule, and where its list is kept."""
        self.name, self.folder, self.pattern, self.only = name, Path(state) / folder, pattern, only
        self.list_file = Path(home) / "lists" / (name.replace(" ", "_") + ".json")
        # Intention (Muse-743/746; BUILD_LOG 855): a fixed set held out of teaching (BlenderHeldApart), or None.
        self.held_out = None

    def pictures(self) -> list:
        """Intention: the pictures taught from — the full list less any fixed set held out of teaching (BUILD_LOG 855)."""
        files = self.listed()
        if self.held_out is None:
            return files
        drop = set(self.held_out.names())
        return [name for name in files if name not in drop] if drop else files

    def listed(self) -> list:
        """Intention: the source's picture files (relative paths, sorted); made again when older than RELIST_SECONDS."""
        try:
            kept = json.loads(self.list_file.read_text(encoding="utf-8"))
            if time.time() - float(kept["at"]) < RELIST_SECONDS:
                return kept["files"]
        except (OSError, ValueError, KeyError):
            pass
        files = []
        if self.folder.is_dir():
            # Intention: names read straight from the folder (a stat of each of 30,000 files took minutes).
            # Intention (BUILD_LOG 1586): listed through the one way in (warp2/tags/media/pictures.py), so a picture
            # whose original went to deep storage is still in the list - by name, as before, nothing opened.
            from warp2.tags.media import pictures
            found = pictures.pictures_in(self.folder, deep=self.pattern.startswith("**"))
            files = [path.relative_to(self.folder).as_posix() for path in found if self._wanted(path.name)]
        files.sort()
        self.list_file.parent.mkdir(parents=True, exist_ok=True)
        self.list_file.write_text(json.dumps({"at": time.time(), "files": files}), encoding="utf-8")
        return files

    def _wanted(self, name: str) -> bool:
        """Intention: a picture file this source takes (its ending, and its name rule when it has one); names starting
        with "." are files still being written (".tmp-..." downloads) and are left until they are whole."""
        return (not name.startswith(".") and name.lower().endswith(ENDINGS)
                and (self.only is None or bool(self.only.match(name))))

    def picture(self, number: int):
        """Intention: (path, name) of the picture at this number in the list (wrapping round), or None when the source is empty."""
        files = self.pictures()
        if not files:
            return None
        relative = files[int(number) % len(files)]
        return self.folder / relative, f"{self.name} {relative}"


class HubSource:
    """Intention: one hub dataset's pictures, listed once (made again now and then) and fetched one at a time when their turn comes, kept on disk."""

    def __init__(self, state: Path, home: Path, name: str, repo: str, folder: str, keep: str | None = None,
                 get=None, fetch=None) -> None:
        """Intention: where its pictures are kept (state/visual_learning/real_world/<name>/), its list, and the hub calls (passed in by tests).

        Intention (BUILD_LOG 835): `keep`, when given, is a pattern a file's name must match to be one of its pictures
        (one part of a dataset that holds two); the listing follows the hub's pages, so a dataset of more than a
        thousand files is listed whole."""
        from warp2.ask import hub_pictures
        self.name, self.repo, self.folder = name, repo, folder
        self.keep_name = re.compile(keep) if keep else None
        self.keep = Path(state) / "visual_learning" / "real_world" / name.replace(" ", "_")
        self.list_file = Path(home) / "lists" / (name.replace(" ", "_") + ".json")
        self.get = get or (lambda url: _all_pages(url, 30.0))
        self.fetch = fetch or (lambda url: hub_pictures.fetch(url, 120.0))

    def pictures(self) -> list:
        """Intention: the dataset's picture files (paths in the dataset, sorted); listed again when older than RELIST_SECONDS."""
        try:
            kept = json.loads(self.list_file.read_text(encoding="utf-8"))
            if time.time() - float(kept["at"]) < RELIST_SECONDS:
                return kept["files"]
        except (OSError, ValueError, KeyError):
            pass
        found = self.get(HUB_TREE.format(repo=self.repo, folder=self.folder))
        files = sorted(str(x["path"]) for x in found if x.get("type") == "file" and str(x["path"]).lower().endswith(ENDINGS)
                       and (self.keep_name is None or self.keep_name.search(Path(str(x["path"])).name)))
        self.list_file.parent.mkdir(parents=True, exist_ok=True)
        self.list_file.write_text(json.dumps({"at": time.time(), "files": files}), encoding="utf-8")
        return files

    def picture(self, number: int):
        """Intention: (path, name) of the picture at this number (wrapping round), fetched the first time; None when the list is empty."""
        files = self.pictures()
        if not files:
            return None
        relative = files[int(number) % len(files)]
        path = self.keep / Path(relative).name
        # Intention (BUILD_LOG 1594c): a picture whose original went to deep storage is still there; not fetched again.
        from warp2.tags.media import pictures
        if not pictures.is_there(path):
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(".part")
            temporary.write_bytes(self.fetch(HUB_FILE.format(repo=self.repo, path=relative)))
            temporary.replace(path)
        return path, f"{self.name} {Path(relative).name}"


def _all_pages(url: str, timeout: float, most: int = 50) -> list:
    """Intention (BUILD_LOG 835): a hub listing whole — each page, following its "next" link (at most `most` pages)."""
    import urllib.request

    from warp2.ask.hub_pictures import USER_AGENT
    out, pages = [], 0
    while url and pages < most:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": USER_AGENT}), timeout=timeout) as answer:
            out.extend(json.loads(answer.read().decode("utf-8")))
            found = re.search(r'<([^>]+)>;\s*rel="next"', answer.headers.get("Link", "") or "")
        url, pages = (found.group(1) if found else None), pages + 1
    return out


class AllPictures:
    """Intention: the next picture for an error lesson — one from each source in turn, each source in its own order."""

    def __init__(self, state, home, hypersim=None, hubs=None) -> None:
        """Intention: `hypersim` is the hub frames (HypersimFrames with its own place); `hubs` the other hub datasets
        (HubSource, BUILD_LOG 783; none unless given); local sources come from SOURCES. Hubs take their turns first."""
        self.home = Path(home)
        self.hypersim = hypersim
        self.locals = list(hubs or []) + [LocalSource(Path(state), self.home, *source) for source in SOURCES]
        self.place_file = self.home / "all_pictures_place.json"
        # Intention (Muse-743/746; BUILD_LOG 855): the fixed never-taught Blender pictures for the faint reading,
        # left out of the Blender source's teaching list.
        from warp2.ask.blender_held_apart import BlenderHeldApart
        self.blender = None
        for source in self.locals:
            if source.name == "blender" and isinstance(source, LocalSource):
                self.blender = BlenderHeldApart(
                    self.home, source, lambda: int(self._place().get("numbers", {}).get("blender", 0)))
                source.held_out = self.blender

    def _place(self) -> dict:
        """Intention: where the turn and each source stand, as kept; a fresh start when nothing is kept."""
        try:
            return json.loads(self.place_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {"turn": 0, "numbers": {}}

    def _keep(self, place: dict) -> None:
        """Intention: where each source stands, written whole through a temporary file so a restart goes on."""
        self.place_file.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.place_file.with_suffix(".part")
        temporary.write_text(json.dumps(place), encoding="utf-8")
        temporary.replace(self.place_file)

    def names(self) -> list:
        """Intention: the sources in the order they take turns (Hypersim first when it is given)."""
        return ([HYPERSIM] if self.hypersim is not None else []) + [source.name for source in self.locals]

    def next(self) -> tuple:
        """Intention: (picture path, None, name) — the next source's next picture that opens; the place moved on.

        A source whose picture does not open goes on to its own next picture
        (up to TRIES); an empty source is passed by.
        """
        place, names = self._place(), self.names()
        by_name = {source.name: source for source in self.locals}
        for _ in range(len(names)):
            name = names[place["turn"] % len(names)]
            place["turn"] += 1
            if name == HYPERSIM:
                try:
                    photo, _, said = self.hypersim.next()
                except Exception:
                    continue
                self._keep(place)
                return photo, None, said
            for _ in range(TRIES):
                number = int(place["numbers"].get(name, 0))
                try:
                    found = by_name[name].picture(number)
                except Exception:
                    # Intention: a hub that cannot be reached now gives its turn to the next source.
                    break
                if found is None:
                    break
                place["numbers"][name] = number + 1
                path, said = found
                if _opens(path):
                    self._keep(place)
                    return path, None, said
        self._keep(place)
        raise LookupError("no picture could be found in any source")

    def peek(self, count: int, skip: int = 0) -> list:
        """Intention (Muse-705/710; BUILD_LOG 810): the next `count` pictures, (path, None, name) each, in the order
        next() would give them, read from ONE snapshot of the place taken now and never written back — so the frames
        the coming lessons will be taught can be read before teaching, and the snapshot is not moved by the teaching
        that follows. A picture that does not open is passed by just as next() passes it by; fewer than `count`
        come back only when the sources run dry.
        Intention (Muse-713/714; BUILD_LOG 817): `skip` pictures first are passed over in the same turn order —
        counted, never fetched or opened (a skipped picture is taken to open, so past a broken file the order is
        near, not exact) — so the look-ahead's control frames far past the turn cost only what they read."""
        import copy
        place, names = copy.deepcopy(self._place()), self.names()
        place.setdefault("numbers", {})
        by_name = {source.name: source for source in self.locals}
        hypersim_skip = self._passed_over(place, names, by_name, int(skip))
        hypersim_ahead, out = [], []
        if self.hypersim is not None:
            try:
                hypersim_ahead = list(self.hypersim.peek(count, skip=hypersim_skip) if hypersim_skip
                                      else self.hypersim.peek(count))
            except Exception:
                hypersim_ahead = []
        empty = 0
        while len(out) < count and empty < len(names):
            name = names[place["turn"] % len(names)]
            place["turn"] += 1
            if name == HYPERSIM:
                if hypersim_ahead:
                    photo, _, said = hypersim_ahead.pop(0)
                    out.append((photo, None, said))
                    empty = 0
                else:
                    empty += 1
                continue
            for _ in range(TRIES):
                number = int(place["numbers"].get(name, 0))
                try:
                    found = by_name[name].picture(number)
                except Exception:
                    found = None
                if found is None:
                    empty += 1
                    break
                place["numbers"][name] = number + 1
                path, said = found
                if _opens(path):
                    out.append((path, None, said))
                    empty = 0
                    break
            else:
                empty += 1
        return out

    def _passed_over(self, place: dict, names: list, by_name: dict, skip: int) -> int:
        """Intention (BUILD_LOG 817): move the snapshot `place` past `skip` pictures in turn order without opening any;
        an empty source is passed by as next() passes it. Gives how many of them were Hypersim's turns."""
        hypersim, empty, sizes = 0, 0, {}
        while skip > 0 and empty < len(names):
            name = names[place["turn"] % len(names)]
            place["turn"] += 1
            if name == HYPERSIM:
                hypersim, skip, empty = hypersim + 1, skip - 1, 0
                continue
            if name not in sizes:
                try:
                    sizes[name] = len(by_name[name].pictures())
                except Exception:
                    sizes[name] = 0
            if not sizes[name]:
                empty += 1
                continue
            place["numbers"][name] = int(place["numbers"].get(name, 0)) + 1
            skip, empty = skip - 1, 0
        return hypersim

    def held_apart(self) -> tuple:
        """Intention: the picture never taught, for the drawings shown — Hypersim's held-apart frame."""
        return self.hypersim.held_apart()

    def held_apart_beside(self, count: int) -> list:
        """Intention: (BUILD_LOG 746) the fixed set of other never-taught frames beside the named one — Hypersim's."""
        return self.hypersim.held_apart_beside(count)

    def held_apart_blender(self, count: int) -> list:
        """Intention: (BUILD_LOG 855) the fixed never-taught Blender pictures, shaped like held_apart_beside's rows."""
        return self.blender.held_apart_beside(count) if self.blender is not None else []


def _opens(path: Path) -> bool:
    """Intention: whether the file opens as a picture with both sides at least SMALLEST pixels."""
    try:
        from warp2.tags.media import pictures
        with pictures.open_picture(path) as image:   # BUILD_LOG 1586: from its small form first
            return min(image.size) >= SMALLEST
    except Exception:
        return False
