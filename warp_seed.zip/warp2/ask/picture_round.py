# WARP2/warp2/ask/picture_round.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/picture_round.py
#  Used by   : warp2/ask/visual.py (`generate` runs a whole round; `step` runs
#              one part), warp2/ask/until.py (one part per turn).
#  Uses      : warp2/ask/visual.py (VisualLearning: its ledger, lock, model,
#              readers, weigher and search), warp2/ask/blank.py, warp2/ask/
#              reference.py (usable), warp2/ask/parts.py (what is missing),
#              warp2/ask/waiting.py, warp2/work/gpu_cache.py, warp2/ask/picture_datasets.py
#              (labelled dataset pictures), warp2/ask/concept_worth.py
#              (the concepts measured; those that learned nothing); centering_image generator/readers
#              (form_tag, combine, fully_recognised); warp2/work/memory_floor.py
#              (the memory floor before every part); warp2/control/inside.py
#              (this process's private memory around every part); stdlib time, uuid, pathlib.
#  Description:
#    One picture round, split into small directed parts that each finish in
#    minutes and say how long they took:
#      concepts — which picture concepts have learned anything, measured
#                 again when the pictures have doubled since the last report
#                 (warp2/ask/concept_worth.py)
#      weigh    — which references, at what weight (the weigher learns here):
#                 every one not yet taught, and the taught ones weighed at
#                 least the mean,
#                 and as many pictures a dataset labelled as something else
#      teach    — ONE reference taught to its subject (repeated until the
#                 batch is done)
#      side     — that reference's strongest other concept taught (one is
#                 enough — Andrew, 2026-10-02)
#      blocks   — each label's concept taught the round's pictures as one
#                 weighted block (its own "is", the rest and random "not")
#      parts    — the subject's sub-concepts (types and parts) guessed by a
#                 small local model, made Eye networks, and given pictures
#                 (warp2/ask/subconcept_tries.py; Andrew muse-476)
#      practice — the master practises; the draw action goes over the subject
#      judge    — the subject drawn from nothing and measured against its
#                 pictures; with one painter, when the round made the drawing
#                 worse it is put back; with the Eye's painters, the best
#                 drawing so far is kept apart and replaced only by a painter
#                 that now draws closer (build log 242)
#      draw     — one picture drawn; a blank one fails at once (no reader)
#      read     — the vision readers judge it (only a picture with something in it)
#      search   — references found for what the readers said was missing,
#                 and a page of a labelled picture dataset for the subject
#      record   — the ledger written, the round's answer made
#    Where a round got to is a small JSON-able dict, so a turn can end after
#    any part and the next turn carries on from there. A size asked for
#    ("size": [width, height]) is the size the round teaches at, draws at and
#    is measured at.
#  User intention (Andrew, 2026-10-02): "that is too long to wait for a
#    possible failure. We need to split it out into more small directed parts."
#    (2026-10-02) "we need to make sure that everything does steady
#    improvements" — the judge part. (2026-10-03) "it should be able to make
#    images of any size requested". (2026-10-05) "it should just be the pair
#    and the master" — skip unrelated parts training and keep focus on the pair and master.
# ============================================================================
"""A picture round in small parts, each one short, reported and resumable."""
from __future__ import annotations

import time
import uuid
import hashlib
import pickle
from copy import deepcopy
from pathlib import Path
from warp2.record.swallowed import noted

# Intention: the order of the parts. `concepts` measures first, so the round
# teaches by a report made on the pictures it has; `teach` repeats until its queue is empty,
# each followed by `side` (its one strongest other concept);
# `read` and `search` are skipped when the picture is blank or approved.
PARTS = ("concepts", "weigh", "teach", "side", "blocks", "parts", "practice", "judge", "draw", "read", "search", "record")


def start(subject: str, round_no: int, wanted=None, negative_path=None, size=None) -> dict:
    """Intention: a new round's state — nothing done yet; `size` [width, height] when one was asked for."""
    return {"subject": str(subject), "round": int(round_no), "wanted": [str(w) for w in (wanted or ())],
            "size": [int(v) for v in (size or [])],
            "part": "concepts", "was": str(Path(negative_path).resolve()) if negative_path else "",
            "queue": [], "taught": {}, "of": 0, "times": {}, "found": [],
            "ident": "", "image_path": "", "responses": [], "selected": 0, "missing": [],
            "search_error": "", "blank": False, "side": [], "fresh": []}


def _private_mb():
    """This process's private memory in MB, or None when the platform cannot say.

    Intention (BUILD_LOG 698): read the same way the memory request reads it
    (warp2/control/inside.py); a failed reading never stops a part.
    """
    try:
        from warp2.control.inside import _process_memory
        value = _process_memory().get("private_mb")
        return int(value) if isinstance(value, (int, float)) else None
    except Exception as exc:
        noted("warp2/ask/picture_round.py:_private_mb", exc)
        return None


def _part_memory(start_mb, end_mb, queued_before: int, queued_after: int) -> dict:
    """Intention (BUILD_LOG 698): one part's memory line — start, end, growth (unknown stays None), the pictures it took, and whose process."""
    import os
    growth = end_mb - start_mb if (start_mb is not None and end_mb is not None) else None
    return {"start_mb": start_mb, "end_mb": end_mb, "growth_mb": growth,
            "pictures_taken": max(0, int(queued_before) - int(queued_after)), "pid": os.getpid()}


class PictureRound:
    """Runs the parts of one round for a VisualLearning, one at a time."""

    def __init__(self, learning, readers=None, search=None) -> None:
        """Intention: `readers` and `search` are injected the same way `generate` takes them (tests, the window)."""
        self.learning = learning
        self.readers = readers
        self.search = search

    def step(self, state: dict) -> tuple:
        """Run the next part; returns (state, report, result) — result is the round's answer once `record` has run, else None."""
        part = state["part"]
        # Intention (2026-10-26, BUILD_LOG 693): THE MACHINE'S MEMORY FLOOR AT
        # EVERY PART. The floor was only read inside the painter and the
        # weigher, so the teach part ran on with no check: measured 10:52 UTC,
        # the runner at 52 GB private, 644 MB RAM and 4.9 GB commit free, one
        # round 65+ minutes in. Between parts is a safe point; under the floor
        # this stops with LowMemory, which until.py already turns into "more
        # to do", and the round is taken again on a later turn. The part is
        # not started, so `state` still says which part comes next.
        from warp2.work.memory_floor import above_floor
        above_floor(f"picture round: before the {part} part")
        began = time.monotonic()
        # Intention (2026-10-26, BUILD_LOG 698, muse-621/624): EVERY PART SAYS
        # WHAT IT DID TO THIS PROCESS'S MEMORY. The 52 GB case (10:52 UTC) had
        # no part to blame: memory was read only for the whole runner. Start
        # and end private memory, the growth, and how many pictures the part
        # took off the teach queue — so growth per picture points at the part
        # that grows. The part name is one of PARTS, the same every round.
        start_mb = _private_mb()
        queued = len(state.get("queue") or [])
        _retire_extras_once(self.learning, state)
        said = getattr(self, "_" + part)(state)
        took = round(time.monotonic() - began, 2)
        state["times"][part] = round(state["times"].get(part, 0.0) + took, 2)
        report = {"subject": state["subject"], "round": state["round"], "part": part, "seconds": took, **said}
        report["memory"] = _part_memory(start_mb, _private_mb(), queued, len(state.get("queue") or []))
        result = state.pop("result", None)
        # Intention (2026-10-03): what the part cached on the GPU and no longer
        # uses is given back (warp2/work/gpu_cache.py) — the parts run back to
        # back, and a painter lesson ran several times slower with the card
        # over-full.
        from warp2.work.gpu_cache import release
        release()
        return state, report, result

    def run(self, state: dict) -> dict:
        """Intention: every part in one go — the old single-call `generate`."""
        while True:
            state, _, result = self.step(state)
            if result is not None:
                return result

    # -- the parts ----------------------------------------------------------

    def _concepts(self, state: dict) -> dict:
        """Which picture concepts have learned anything — measured only when the pictures changed.

        Intention (Andrew, 2026-10-03: "These questions should be answered by
        testing what is best"): the measure is a side step too, but while a
        person waits the machine's own side steps stand down (turns.take), and
        an asked picture keeps a person waiting round after round — so the
        round that uses the report makes it. Every reading picture is read
        once; when the report was made on exactly these pictures, with the
        same names on them, nothing is read again.
        """
        from warp2.ask import concept_worth
        state["part"] = "weigh"
        if self.learning.stop.raised():
            return {"said": "stopped"}
        references = concept_worth.references_of(self.learning)
        if not references:
            return {"said": "concepts: no reference pictures to measure on"}
        if concept_worth.is_current(self.learning.state, concept_worth.mark_of(references), len(references)):
            return {"said": "concepts: measured on these pictures, or on at least half as many"}
        model = _model(self.learning)
        if not hasattr(model, "eye"):
            return {"said": "concepts: the picture model has no Eye to read with"}
        found = concept_worth.refresh(self.learning, model, references)
        return {"said": (f"concepts: {found['learned']} of {found['measured']} learned something, "
                         f"{found['everywhere']} named on every picture, {found['not_better_than_chance']} "
                         f"no better than chance ({found['pictures']} pictures)"), "concepts": found}

    def _weigh(self, state: dict) -> dict:
        """Which references this round teaches, in order, each at its weight; the weigher learns here."""
        from generator import form_tag
        from warp2.ask.media import extract_visual_subject
        from warp2.ask.reference import usable
        from warp2.ask.visual import _digest
        from warp2.record.locks import Lock
        learning = self.learning
        # Intention (2026-10-04, review): the ledger is read under its lock
        # (waited for — a tenth of a second failed the part whenever the web
        # lane was merging a page), and the weigher learns outside it, so the
        # web lane's merges are never held up by a minute of weighing.
        with Lock(learning.path, forever=True):
            if learning.stop.raised():
                state.update(part="record", stopped=True)
                return {"said": "stopped"}
            data = learning._load()
        subject = extract_visual_subject(state["subject"])
        state["subject"] = subject
        was = state["was"]
        if was and not any(a['image_path'] == was for a in data['attempts'].values()):
            raise ValueError('Unknown generated image')
        mine = [dict(ref) for ref in data['references'].values()
                if ref['subject'] == subject and usable(ref)
                and Path(ref['path']).is_file() and _digest(ref['path']) == ref['digest']]
        # Intention (2026-10-04, review): the round no longer keeps every
        # reference id in its state (rewritten after every part); the search
        # part reads the ledger as it is then.
        state.pop("known", None)
        weights = learning._weighed(data, mine, subject, state["round"], state["wanted"])
        tag = form_tag(subject)
        gap, last = _gap(data, subject)
        try:
            from concept_separation import ConceptSeparationStore
            sep_store = ConceptSeparationStore.instance(learning.state)
        except Exception:
            sep_store = None
        scored = []
        for ref, worth in zip(mine, weights):
            scores = ref.get('concept_scores') or {}
            tags = [str(t).lower() for t in (ref.get('tags') or [])]
            relevance = 1.0
            if state["wanted"]:
                matched = sum(1 for w in state["wanted"]
                              if any(w.lower() in t for t in tags) or float(scores.get(w.lower(), 0.0)) >= 0.3)
                relevance = relevance + 0.8 * matched if matched else relevance * 0.6
            apart = sep_store.disentanglement_weights(scores, subject) if (sep_store and scores) else 1.0
            scored.append((ref, float(worth.get('weight', 1.0)) * relevance * apart, apart))
        scored.sort(key=lambda item: item[1], reverse=True)
        batch = _this_round(scored)
        state["tag"] = tag
        state["queue"] = [{"id": ref['id'], "weight": weight, "example": dict(
            tag=tag, kind='reference', score=1, image_path=ref['path'], tags=ref.get('tags') or [],
            concept_scores=ref.get('concept_scores') or {}, concept_tags=ref.get('concept_tags') or [],
            attached_datasets=ref.get('attached_datasets') or [],
            preemptive_concepts=ref.get('preemptive_concepts') or [], gap=gap, last_score=last,
            separation_context={"disentanglement_weight": apart, "target_subject": subject})}
            for ref, weight, apart in batch]
        # Intention: the round's drawing is measured against the subject's own pictures only.
        state["measured_on"] = [item["example"]["image_path"] for item in state["queue"]]
        # Intention (Andrew, 2026-10-03: "It should also see if images fit any
        # other labels"): as many pictures that a dataset labelled as something
        # else beside the subject (a dog from a cats-and-dogs set) are taught
        # too, under their own labels, newest first — one for each of the
        # subject's, so "is" and "is not" come in equal numbers.
        state["queue"] += [{"id": ref['id'], "weight": float(ref.get('weight', 1.0)), "example": dict(
            tag=form_tag(ref['subject']), kind='reference', score=1, image_path=ref['path'],
            tags=ref.get('tags') or [], concept_scores=ref.get('concept_scores') or {},
            concept_tags=ref.get('concept_tags') or [], attached_datasets=ref.get('attached_datasets') or [],
            preemptive_concepts=ref.get('preemptive_concepts') or [], gap=gap, last_score=last,
            separation_context={"disentanglement_weight": 1.0, "target_subject": ref['subject']})}
            for ref in _told_apart(data, subject, len(batch))]
        # Intention (build log 250): the round's pictures by their label, for its block part.
        state["by_label"] = {subject: list(state["measured_on"])}
        for item in state["queue"][len(batch):]:
            state["by_label"].setdefault(item["example"]["separation_context"]["target_subject"], []).append(
                item["example"]["image_path"])
        # Intention (Andrew, muse-476; BUILD_LOG 637): the subject's tried
        # sub-concepts are trained too — each on its own usable pictures in the
        # block part — and never taught as "is not" each other or the subject.
        try:
            from warp2.ask.subconcept_tries import SubconceptPictures, SubconceptRegistrar
            # Intention (BUILD_LOG 643): networks nobody guessed are retired before this round's cascades.
            state["retired_extras"] = SubconceptRegistrar.retire_extras(_model(learning), subject, learning.state)
            subs = SubconceptPictures(learning.state)
            taught = getattr(getattr(_model(learning), "eye", None), "taught", {}) or {}
            more = subs.pictures(subject, data["references"], taught)
            for name, paths in more.items():
                state["by_label"].setdefault(name, []).extend(p for p in paths if p not in state["by_label"].get(name, []))
            state["kin"] = {k: sorted(v) for k, v in subs.kin(subject, more).items()}
            state["sub_taught"] = {name: len(paths) for name, paths in more.items()}
        except Exception as exc:
            noted("warp2/ask/picture_round.py:PictureRound._weigh(subconcepts)", exc)
        state["of"] = len(state["queue"])
        state["learn_at"] = max(state.get("size") or [0]) or _learn_at(learning)
        model = _model(learning)
        if hasattr(model, "prepare_practice") and _paints_later(model):
            more = {"subject": subject} if _takes(model.prepare_practice, "subject") else {}
            plan = model.prepare_practice(state["measured_on"], state["round"],
                                          max(state.get("size") or [0]), **more)
            state["painter_plan"] = plan
            state["measure_size"] = state.get("size") or [plan["training_size"]] * 2
            if plan["validation_paths"]:
                state["measured_on"] = list(plan["validation_paths"])
            # Eye/concept training still sees all references. Only the painter
            # withholds these from its fresh and replay lessons this round.
            state["painter_sources"] = {
                str(ref["path"]): _reference_source(ref)
                for ref in data["references"].values()
                if ref.get("path")}
        state["part"] = "teach" if state["queue"] else "parts"  # BUILD_LOG 585: never skip the sub-concept guessing
        state["error_before"] = _held_before(self.learning, state)
        before = "" if state["error_before"] is None else f"; drawing error {state['error_before']}"
        if state.get("errors_before"):
            before = "; drawing error " + ", ".join(f"{k} {v}" for k, v in sorted(state["errors_before"].items()))
        return {"said": f"{len(mine)} usable references, {state['of']} chosen{before}"}

    def _teach(self, state: dict) -> dict:
        """ONE reference taught to its subject; its other concepts are left for `side`."""
        item = state["queue"].pop(0)
        model = _model(self.learning)
        done = None
        if _hands_back_side(model):
            later = {"paint": False} if _paints_later(model) else {}
            # Intention (build log 252, measured: the fitted blocks alone did as
            # well as one-at-a-time whole lessons plus blocks — held-out cat
            # 0.68-0.75 against 0.63-0.73 — and the whole lesson was most of a
            # 4 s teach): when the round's `blocks` part will teach the
            # concepts, a picture's own lesson is only its subject.
            if hasattr(model, "block_lesson") and _takes(model.train_example, "whole"):
                later["whole"] = False
            done = model.train_example(item["example"], item["weight"], longest=state.get("learn_at", 0), side=False,
                                       **later)
            if (done or {}).get("paint later"):
                state.setdefault("fresh", []).append(list(done["paint later"]))
            path = item["example"].get("image_path", "")
            state["side"] = _one_side([[path, concept, weight] for concept, weight in (done or {}).get("side") or []],
                                      state.get("wanted") or [], _learned_nothing(self.learning))
        else:
            model.train_example(item["example"], item["weight"], longest=state.get("learn_at", 0))
        state["taught"][item["id"]] = item["weight"]
        state["part"] = _after_teaching(state)
        # Intention: where the teach's time went, when the model says (the
        # Eye's does: read, teach, see, paint, master), so a slow part can be
        # fixed where it is slow.
        steps = (done or {}).get("seconds") or {}
        where = " (" + ", ".join(f"{k} {v}s" for k, v in steps.items()) + ")" if steps else ""
        return {"said": f"taught {len(state['taught'])}/{state['of']}{where}"}

    def _side(self, state: dict) -> dict:
        """The reference's one strongest other concept taught, in its own short part.

        Intention (Andrew, 2026-10-02): "one would be enough" — a reference
        carried over a hundred other concepts and teaching them all made each
        teach take ten minutes. Its own part, so the teach part stays the
        subject's alone.
        """
        model = _model(self.learning)
        state["side"] = _one_side(state["side"], state.get("wanted") or [], _learned_nothing(self.learning))
        taught = []
        for path, concept, weight in state["side"]:
            model.teach_side(path, concept, weight, longest=state.get("learn_at", 0))
            taught.append(concept)
        state["side"] = []
        state["part"] = _after_teaching(state)
        return {"said": f"also taught '{taught[0]}'" if taught else "no other concept"}

    def _blocks(self, state: dict) -> dict:
        """The round's pictures taught once more as weighted blocks, one per label in the round.

        Intention (Andrew, 2026-10-03: "Then lets get it all in"; measured,
        build log 250): after the pictures were taught one at a time, each
        label's concept is taught them all together — its own as what it is,
        the others and random pictures as what it is not — each weighted by
        its mistake, the two sides weighing the same, until the mistake stops
        falling. On held-out pictures this lifted the mean over all subjects
        (0.49-0.55 to 0.52-0.61) and kept cat at 0.63-0.73.
        """
        # Intention (BUILD_LOG 585): on to `parts`, the sub-concept guessing (it was skipped).
        state["part"] = "parts"
        model = _model(self.learning)
        pictures = {k: v for k, v in (state.get("by_label") or {}).items() if v}
        if not hasattr(model, "block_lesson") or not pictures:
            return {"said": "no blocks this round"}
        kin = {k: set(v) for k, v in (state.get("kin") or {}).items()}
        if kin and _takes(model.block_lesson, "kin"):
            done = model.block_lesson(pictures, longest=state.get("learn_at", 0), kin=kin)
        else:
            done = model.block_lesson(pictures, longest=state.get("learn_at", 0))
        self.learning._checkpoint(model)
        if state.get("sub_taught"):
            try:
                from warp2.ask.subconcept_tries import SubconceptPictures
                SubconceptPictures(self.learning.state).trained(state["subject"], list(state["sub_taught"]))
            except Exception as exc:
                noted("warp2/ask/picture_round.py:PictureRound._blocks(subconcepts)", exc)
        said = "; ".join(f"{d['concept']} {d.get('before')} -> {d.get('after')} in {d.get('steps', 0)} steps"
                         f" over {d.get('pieces', 0)} pieces" for d in done if d.get("steps"))
        return {"said": "blocks: " + (said or "nothing to teach")}

    def _parts(self, state: dict) -> dict:
        """The subject's sub-concepts guessed, made networks of their own, and given pictures.

        Intention (Andrew, muse-476, 2026-10-23: "number one is the ability for
        the models to sit there and guess at sub-concepts ... types of cats ...
        the feet the paw the paw pads the claws"; muse-471: every piece trained
        as its own small model off the data the dataset system brings up):
        a small local model is asked what kinds and what parts the subject
        has; each guess becomes an Eye network (born at one node); up to three
        guesses a round get a dataset page or a web search of their own, kept
        as references with the guess as their subject, so `teach` trains them
        from the next round. This replaces "skipped during picture rounds"
        (Andrew, 2026-10-05, "just the pair and the master") — his newer order
        stands. BUILD_LOG 585.
        """
        state["part"] = "practice"
        if self.learning.stop.raised():
            return {"said": "stopped"}
        try:
            from warp2.ask.subconcept_tries import SubconceptTries
            got = SubconceptTries(self.learning, self.search).turn(_model(self.learning), state["subject"],
                                                                  state["round"])
        except Exception as exc:
            noted("warp2/ask/picture_round.py:PictureRound._parts", exc)
            return {"said": f"parts: sub-concept guessing failed: {type(exc).__name__}: {exc}"}
        state["sub_added"] = dict(state.get("sub_added") or {}, **got["added"])
        guessed = {kind: len(names) for kind, names in got["guessed"].items()}
        tried = ", ".join(f"{t['name']} ({t['from_dataset']} dataset, {t['from_search']} searched)"
                          for t in got["tried"]) or "nothing new to try"
        return {"said": (f"parts: guessed {guessed}, registered {got['registered'].get('registered', 0)}; "
                         f"tried {tried}"), "subconcepts": {"guessed": got["guessed"], "tried": got["tried"]}}

    def _practice(self, state: dict) -> dict:
        """The master practises everything it was taught; the draw action goes over the subject again; saved."""
        model = _model(self.learning)
        # A stopped run may resume a round weighed by the older code. Pin its
        # validation plan now and replace the incompatible old baseline.
        if not state.get("painter_plan") and hasattr(model, "prepare_practice") and _paints_later(model):
            more = {"subject": state.get("subject", "")} if _takes(model.prepare_practice, "subject") else {}
            plan = model.prepare_practice(state.get("measured_on") or [], state.get("round", 0),
                                          max(state.get("size") or [0]), **more)
            state["painter_plan"] = plan
            state["measure_size"] = state.get("size") or [plan["training_size"]] * 2
            if plan["validation_paths"]:
                state["measured_on"] = list(plan["validation_paths"])
            state["error_before"] = _held_before(self.learning, state)
        said = {}
        if state["taught"] and hasattr(model, 'practice'):
            practised = _practise(model, state)
            master = practised.get("master") or {}
            by = master.get("by", "apart")
            fresh = practised.get("painted fresh")
            state["painter_training"] = {k: v for k, v in practised.items() if k != "master"}
            scale_note = f" ({practised['scale_reason']})" if practised.get("scale_reason") else ""
            said = {"said": f"master {by} {master.get(by, '?')} after {master.get('rounds', 0)} rounds; "
                            + (f"painted {fresh} new; " if fresh else "")
                            + f"drawn again {practised.get('drawn again', 0)}; "
                            + f"size {practised.get('training_size', '?')}{scale_note}; "
                            + f"round validation {practised.get('validation_count', 0)}"}
        self.learning._checkpoint(model)
        state["part"] = "judge"
        return said or {"said": "nothing new to practise"}

    def _judge(self, state: dict) -> dict:
        """The subject drawn from nothing and measured; a painter the round made worse is put back.

        Intention (Andrew, 2026-10-02: "we need to make sure that everything
        does steady improvements"): the drawing error (EyePictures.draw_error,
        lower is better) is measured at the round's start and here. When it
        is worse now, the painter held at the start is measured with the Eye
        as it is now, and whichever of the two draws better is kept — so a
        round never leaves the drawing worse than it found it. The held
        painter is written beside the round state, so the same guarantee
        survives a process restart.
        """
        model = _model(self.learning)
        state["part"] = "draw"
        if not hasattr(model, "draw_error"):
            return {"said": "this picture model cannot be measured"}
        tag = state.get("tag") or state["subject"]
        paths = state.get("measured_on") or []
        if hasattr(model, "draw_errors"):
            return self._judge_each(model, state, tag, paths)
        before, now = state.get("error_before"), _measured(model, tag, paths, state)
        held = _take_held(self.learning, state)
        state["error_after"] = state["error_now"] = now
        if now is None or before is None or now <= before or held is None:
            return {"said": f"drawing error {before} -> {now}" + ("" if before is None or now is None or now <= before else " (nothing held to put back)")}
        taught = model.hold_painter()
        model.put_back_painter(held)
        old = _measured(model, tag, paths, state)
        if old is not None and old < now:
            state["error_after"] = old
            self.learning._checkpoint(model)
            return {"said": f"drawing error {before} -> {now}: worse, so the painter from the round's start was put back ({old})"}
        model.put_back_painter(taught)
        return {"said": f"drawing error {before} -> {now}: worse, but the painter from the round's start draws no better now ({old}); kept"}

    def _judge_each(self, model, state: dict, tag, paths: list) -> dict:
        """Every painter measured; the best drawing so far kept, or replaced by a painter that now draws closer.

        Intention (Andrew, 2026-10-05: "it should just be the pair and the
        master"): the Eye keeps the pop pair painter and, apart from it, a copy
        of the best drawing so far that is what draws. The painter is never put
        back: keeping every lesson and drawing with the best copy ensures drawing
        never goes backward and the learner goes forward.
        """
        before = dict(state.get("errors_before") or {})
        _HELD.pop(_key(self.learning), None)
        now = _measured_each(model, tag, paths, state)
        frozen = list((state.get("painter_plan") or {}).get("frozen_paths") or [])
        frozen_now = _measured_each(model, tag, frozen, state) if frozen else {}
        if frozen_now:
            state["frozen_quality"] = frozen_now
        if all(v is None for v in now.values()):
            state["errors_after"], state["error_after"] = now, None
            return {"said": "drawing error: no pictures to measure against"}
        was_best = now.get("best")
        drawing = model.choose_painter(now)
        warp = getattr(model, "warp", None)
        best = getattr(warp, "best_error", None)
        kept = was_best is None or (best is not None and best < was_best)
        said = [f"{name} {before.get(name)} -> {now.get(name)}" for name in sorted(now) if name != "best"]
        state["errors_after"] = now
        state["error_now"] = now.get(state.get("drawing_at_start") or drawing)
        state["error_after"] = best if best is not None else now.get(drawing)
        recorded = bool(state.get("painter_plan")) and hasattr(model, "record_size_error")
        if recorded:
            model.record_size_error(state["painter_plan"]["training_size"], state["error_after"])
            state["painter_quality"] = getattr(model, "quality_metrics", {})
        if kept or recorded:
            self.learning._checkpoint(model)
        if kept:
            said.append(f"best drawing so far now from {drawing} ({best})")
        else:
            said.append(f"best drawing so far kept ({was_best})")
        if frozen_now:
            said.append("frozen evaluation " + ", ".join(
                f"{name} {value}" for name, value in sorted(frozen_now.items())))
        return {"said": "drawing error: " + "; ".join(said)}

    def _draw(self, state: dict) -> dict:
        """Three fixed-seed round samples make progress visible; readers judge the first."""
        from warp2.ask.blank import blank_reading
        from warp2.ask.media import record_image_catalog
        model = _model(self.learning)
        ident = uuid.uuid4().hex
        destination = self.learning.home / (ident + '.png')
        size = state.get("size")
        if not size or not any(size):
            size = state.get("measure_size")
        if not size or not any(size):
            plan_size = (state.get("painter_plan") or {}).get("training_size")
            if plan_size:
                size = [plan_size, plan_size]
        wide, high = (size or [0, 0])[:2]
        subject = state.get("tag") or state["subject"]
        dimensions = {"wide": wide, "high": high} if wide and high else {}
        # Keep the reader-checked candidate diverse, then make two controlled
        # comparisons with fixed noise seeds and the oldest stable subject code.
        candidate_seed = int(ident[:8], 16)
        sample = model.generate(subject, destination, seed=candidate_seed, **dimensions)
        previews = [{"image": str(destination.resolve()), "seed": candidate_seed,
                     "role": "reader candidate"}]
        record_image_catalog(self.learning.state, {
            "id": ident, "subject": state["subject"], "image_path": str(destination.resolve()),
            "kind": "training_candidate", "round": int(state["round"]), "seed": candidate_seed,
            "reader_status": "pending", "time": time.time(),
        })
        subject_name = model.subject_of(subject) if hasattr(model, "subject_of") else (
            subject.get("name") if isinstance(subject, dict) else str(subject))
        known_codes = getattr(model, "seen", {}).get(subject_name, [])
        reference_code = known_codes[0] if known_codes else None
        for seed in (1, 2):
            preview_id = uuid.uuid4().hex
            preview = self.learning.home / "training_previews" / f"round-{int(state['round']):04d}-seed-{seed}-{preview_id[:8]}.png"
            preview.parent.mkdir(parents=True, exist_ok=True)
            extra = {"reference_code": reference_code} if reference_code is not None else {}
            model.generate(subject, preview, seed=seed, **extra, **dimensions)
            preview_path = str(preview.resolve())
            previews.append({"image": preview_path, "seed": seed})
            record_image_catalog(self.learning.state, {
                "id": preview_id, "subject": state["subject"], "image_path": preview_path,
                "kind": "training_preview", "round": int(state["round"]), "seed": seed,
                "reader_status": "not_checked", "time": time.time(),
            })
        holder = {"attempts": {ident: {"id": ident, "sample": sample}}}
        self.learning._samples_out(holder)
        state.update(ident=ident, image_path=str(destination.resolve()),
                     sample_path=holder["attempts"][ident].get("sample_path", ""))
        blank = blank_reading(destination)
        if blank is not None:
            state.update(responses=[blank], selected=1, blank=True, part="search")
            return {"said": f"blank ({blank.get('contrast')} contrast) — failed without a reader",
                    "image": state["image_path"], "images": previews}
        state["part"] = "read"
        return {"said": "reader candidate and two same-code, fixed-seed progress previews drawn",
                "image": state["image_path"], "images": previews}

    def _read(self, state: dict) -> dict:
        """The vision readers judge the picture; what each read costs is written down."""
        from warp2.ask.visual import READ_VERB
        learning = self.learning
        responses = []
        try:
            selected = learning._readers() if self.readers is None else self.readers
        except Exception as exc:
            selected = []
            responses.append({'error': str(exc)})
        told_cost = learning._deadlines()
        measured = False
        destination = Path(state["image_path"])
        asked = _with_real(state.get("tag") or state["subject"], _real_picture(learning, state["subject"]))
        for reader in selected:
            if learning.stop.raised():
                break
            began = time.monotonic()
            try:
                response = reader.read(destination, asked)
                if not isinstance(response, dict):
                    raise ValueError('Reader returned no usable evidence')
                responses.append(response)
                told_cost.observe(READ_VERB, time.monotonic() - began)
                measured = True
            except Exception as exc:
                responses.append({'name': getattr(reader, 'name', '?'), 'error': str(exc)})
        if measured:
            told_cost.save()
        state.update(responses=responses, selected=len(selected), part="search")
        scores = [r.get('score') for r in responses if not r.get('error')]
        return {"said": f"readers said {scores}"}

    def _search(self, state: dict) -> dict:
        """References found for what the readers said was missing — not when the picture was approved."""
        from readers import combine, fully_recognised
        from warp2.ask.parts import Parts
        learning = self.learning
        evidence = combine(state["responses"], state["selected"] or len(state["responses"]),
                           subject=state["subject"])
        progress = _progress_of(state)
        visual_ops = state.get("visual_operations")
        if not visual_ops and state.get("image_path"):
            try:
                from visual_operations import VisualOperationsAnalyzer
                visual_ops = VisualOperationsAnalyzer.analyze(state["image_path"], state["subject"])
                state["visual_operations"] = visual_ops
            except Exception as exc:
                noted("warp2/ask/picture_round.py:PictureRound._search", exc)
        accepted = fully_recognised(evidence, progress=progress, visual_ops=visual_ops)
        state["part"] = "record"
        if accepted or learning.stop.raised():
            return {"said": "approved — nothing to search" if accepted else "stopped"}
        state["missing"] = Parts().missing({"readers": state["responses"], "evidence": evidence,
                                            "subject": state["subject"]})
        data = learning._load()
        known = set(data['references'])
        mine_only = {'references': dict(data['references'])}
        refs, error = learning._search(mine_only, state["subject"], self.search,
                                       wanted=state["missing"] or state["wanted"], round_no=state["round"])
        # Intention (Andrew, 2026-10-03: "it should have pulled datasets why has
        # it not"): a page of a labelled picture dataset for the subject is
        # pulled too, its pictures admitted by the dataset's label
        # (warp2/ask/picture_datasets.py). A failed pull is said, not raised —
        # the web search's references still count.
        try:
            from warp2.ask.picture_datasets import PictureDatasets
            pulled = PictureDatasets(learning).pull(state["subject"], mine_only, state["round"])
        except Exception as exc:
            pulled = {"dataset": "", "added": 0, "why": f"pull failed: {exc}"}
        state["pulled"] = {k: v for k, v in pulled.items() if k != "ids"}
        state["found"] = [dict(r) for r in refs]
        state["added"] = {k: v for k, v in mine_only['references'].items() if k not in known}
        state["search_error"] = error
        took = (f"; {pulled['added']} from dataset {pulled['dataset']}" if pulled.get("dataset")
                else f"; no dataset pulled ({pulled.get('why', '')})")
        return {"said": f"{len(refs)} new references for {state['missing'] or state['wanted'] or [state['subject']]}" + took}

    def _record(self, state: dict) -> dict:
        """The ledger written under the lock for as long as a write takes; the round's answer made."""
        from readers import combine, fully_recognised
        from warp2.ask.visual import _digest
        from warp2.record.locks import Lock
        learning = self.learning
        if state.get("stopped"):
            state["result"] = {'status': 'stopped'}
            return {"said": "stopped"}
        responses = state["responses"]
        evidence = combine(responses, state["selected"] or len(responses), subject=state["subject"])
        progress = _progress_of(state)
        ident = state["ident"]
        visual_ops = {}
        try:
            from visual_operations import VisualOperationsAnalyzer
            visual_ops = VisualOperationsAnalyzer.analyze(state["image_path"], state["subject"])
            state["visual_operations"] = visual_ops
            from projects.behemoth_eye.eye.taxonomy import AbilityBalancer
            AbilityBalancer.current(learning.state).record_visual_operations(state["subject"], visual_ops)
        except Exception as exc:
            noted("warp2/ask/picture_round.py:PictureRound._record", exc)
        accepted = fully_recognised(evidence, progress=progress, visual_ops=visual_ops)
        failed = any(not r.get('error') and type(r.get('score')) in (int, float)
                     and r.get('score_kind') == 'explicit' and 0 <= r['score'] < 1 for r in responses)
        answered = [r for r in responses if not r.get('error')]
        busy = bool(responses) and not answered and any(
            'timed out' in str(r.get('error', '')).lower() or 'timeout' in str(r.get('error', '')).lower()
            for r in responses)

        row = dict(id=ident, subject=state["subject"], image_path=state["image_path"],
                   digest=_digest(state["image_path"]) if state["image_path"] else "",
                   sample_path=state.get("sample_path", ""), readers=responses, evidence=evidence,
                   visual_operations=visual_ops,
                   approved=accepted, negative_trained=False, time=time.time(), parts_seconds=dict(state["times"]))
        if state.get("painter_quality"):
            # Keep the measurements the judge part already made; no new verdict or score.
            row["painter_quality"] = deepcopy(state["painter_quality"])
        if failed:
            row['failed_at'] = time.time()
        with Lock(learning.path, forever=True):
            data = learning._load()
            if state["was"]:
                previous = next((a for a in data['attempts'].values() if a['image_path'] == state["was"]), None)
                if previous is not None:
                    previous['negative_trained'] = False
                    previous['rejected_at'] = time.time()
            for ref_id, worth in state["taught"].items():
                kept = data['references'].get(ref_id)
                if kept is not None:
                    kept['trained_at'] = time.time()
                    kept['last_weight'] = worth
            for ref_id, found in (state.get("added") or {}).items():
                data['references'].setdefault(ref_id, found)
            # Intention (BUILD_LOG 585): the pictures the sub-concept guesses got are kept too.
            for ref_id, found in (state.get("sub_added") or {}).items():
                data['references'].setdefault(ref_id, found)
            if ident:
                data['attempts'][ident] = row
            data['subjects'][state["subject"]] = 'prepared' if accepted else 'needs_references'
            learning._save(data)
            attempts_here = sum(a['subject'] == state["subject"] for a in data['attempts'].values())
        model = _model(learning)
        state["result"] = dict(
            image_path=row['image_path'], subject=state["subject"], approved=accepted, evidence=evidence,
            status=('approved' if accepted else 'awaiting_reference_confirmation' if failed else
                    'reader_busy' if busy else 'reader_unavailable'),
            negative_trained=False, reference_reviews=state["found"], readers=responses,
            missing=state["missing"], round=int(state["round"]),
            references=[r['path'] for r in state["found"]], search_error=state["search_error"],
            trained_refs=len(state["taught"]), updates=getattr(model, 'updates', 0),
            visual_operations=visual_ops,
            attempt=attempts_here, parts_seconds=dict(state["times"]), blank=state["blank"])
        state["part"] = "done"
        return {"said": "approved" if accepted else f"not yet (score {evidence.get('score')})"}


# Intention (2026-10-09, fix 3.1, check B2): what the pass rule reads as
# progress — the drawing error of the painter that was drawing at the round's
# start, before and after this round's training, on the same pictures — so a
# round that went by, or a best-ever number measured at another size, is not
# mistaken for one that improved.
# Intention (2026-10-09, fix 3.3): a real picture of the subject to compare
# the made one against — only one a person confirmed, the best-scored of them;
# a pending, rejected or only machine-read picture is not proof of the subject.
def _real_picture(learning, subject: str) -> str:
    """The path of the best confirmed picture of `subject`, or ""."""
    real = learning.references(subject=subject, status="confirmed")
    real.sort(key=lambda row: float(row.get("reader_score") or 0.0), reverse=True)
    return str(real[0]["path"]) if real else ""


# Intention: the tag the readers are handed, carrying the real picture when there is one.
def _with_real(tag, real: str):
    """`tag` as a mapping with data.reference set to `real`, or `tag` unchanged with none."""
    if not real:
        return tag
    shaped = dict(tag) if isinstance(tag, dict) else {"name": str(tag)}
    shaped["data"] = dict(shaped.get("data") or {}, reference=real)
    return shaped


def _progress_of(state: dict) -> dict:
    """The round and its measured drawing error before and after, for the pass rule."""
    return {"round": state.get("round", 1), "error_before": state.get("error_before"),
            "error_after": state.get("error_now")}


def _reference_source(ref: dict) -> str:
    """Dataset or website, not an individual image URL, is the sampling source."""
    from urllib.parse import urlparse
    source = ref.get("source") or {}
    if isinstance(source, dict):
        if source.get("dataset"):
            return "dataset:" + str(source["dataset"])
        url = source.get("url") or source.get("image_url") or ""
    else:
        url = str(source)
    return urlparse(url).netloc.lower() or "unknown"


def _gap(data: dict, subject: str) -> tuple:
    """Intention: how far the subject's latest picture was from passing (1 - its score), and that score."""
    recent = [a for a in data.get('attempts', {}).values() if a.get('subject') == subject]
    if not recent:
        return 1.0, 0.0
    last = float(max(recent, key=lambda a: a.get('time', 0)).get('evidence', {}).get('score', 0.0) or 0.0)
    last = last / 100.0 if last > 1.0 else last
    return max(0.0, min(1.0, 1.0 - last)), last


# Intention: THE PAINTER HELD AT A ROUND'S START, per state folder.  The
# in-memory copy avoids a read during an uninterrupted round; the durable copy
# preserves rollback across a crash or restart.
_HELD: dict = {}


def _key(learning) -> str:
    """Intention: one held painter per state folder, the same key the picture model is kept by."""
    return str(Path(learning.state).resolve())


def _held_path(learning, state: dict) -> Path:
    """A round-specific rollback file that cannot collide with another subject."""
    safe = "".join(c if c.isalnum() or c in "-_" else "-" for c in str(state.get("subject", "picture")))[:80]
    return Path(learning.state) / "transactions" / f"painter-round-{int(state.get('round', 0)):06d}-{safe}.bin"


def _persist_held(learning, state: dict, held) -> None:
    """Write a held painter atomically and record a digest in resumable state."""
    from warp2.util import atomic_write_bytes
    raw = b"bytes\0" + held if isinstance(held, bytes) else b"pickle\0" + pickle.dumps(held, protocol=5)
    path = _held_path(learning, state)
    atomic_write_bytes(path, raw)
    state["held_painter"] = {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}


def _take_held(learning, state: dict):
    """Take and retire the exact held painter, rejecting torn or replaced data."""
    held = _HELD.pop(_key(learning), None)
    note = state.pop("held_painter", None) or {}
    path = Path(note.get("path", "")) if note.get("path") else None
    if held is None and path is not None and path.is_file():
        try:
            raw = path.read_bytes()
            if hashlib.sha256(raw).hexdigest() != note.get("sha256"):
                held = None
            elif raw.startswith(b"bytes\0"):
                held = raw[6:]
            elif raw.startswith(b"pickle\0"):
                held = pickle.loads(raw[7:])
            else:
                held = None
        except (OSError, EOFError, ValueError, pickle.PickleError):
            held = None
    if path is not None:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
    return held


def _held_before(learning, state: dict):
    """The drawing error at the round's start, with the painter held to put back; None when the model cannot be measured.

    Intention: measured before anything is taught, so the judge part compares
    the round's end with its start.
    """
    model = _model(learning)
    _HELD.pop(_key(learning), None)
    if not hasattr(model, "draw_error"):
        return None
    tag, paths = state.get("tag") or state["subject"], state.get("measured_on") or []
    if hasattr(model, "draw_errors"):
        state["errors_before"] = _measured_each(model, tag, paths, state)
        # Intention (fix 3.1): which painter was drawing at the start, so the
        # round's end is compared with the same painter on the same pictures.
        state["drawing_at_start"] = getattr(getattr(model, "warp", None), "drawing", "")
        before = state["errors_before"].get(state["drawing_at_start"])
        # Intention (build log 242): nothing is held — the painters keep their
        # lessons, and the best drawing so far is kept apart by the Eye.
        return before
    before = _measured(model, tag, paths, state)
    if before is not None:
        held = model.hold_painter()
        _HELD[_key(learning)] = held
        _persist_held(learning, state, held)
    return before


def _measured(model, tag, paths: list, state: dict):
    """Intention: the drawing error at the size the round draws at (the model's own when none was asked for)."""
    size = state.get("measure_size") or state.get("size") or []
    return model.draw_error(tag, paths, size=size) if size else model.draw_error(tag, paths)


def _measured_each(model, tag, paths: list, state: dict) -> dict:
    """Intention: every painter's drawing error, at the size the round draws at."""
    size = state.get("measure_size") or state.get("size") or []
    measure = getattr(model, "assess_painters", model.draw_errors)
    return measure(tag, paths, size=size) if size else measure(tag, paths)


def _takes(method, name: str) -> bool:
    """Intention: whether a model's method takes this keyword (older picture models do not)."""
    import inspect
    try:
        return name in inspect.signature(method).parameters
    except (TypeError, ValueError):
        return False


def _paints_later(model) -> bool:
    """Intention: whether the model can leave a picture's painter lesson until after the master practises (EyePictures can)."""
    return _takes(model.train_example, "paint") and _takes(getattr(model, "practice", None), "fresh")


def _practise(model, state: dict) -> dict:
    """The practice at the size the round teaches at, with the round's painter lessons when they were left for it.

    Intention (2026-10-03): the round's pictures are painted after the master
    practises, with the answer the round will draw by (EyePictures.practice).
    """
    more = {}
    plan = state.get("painter_plan") or {}
    if plan and _takes(model.practice, "longest"):
        more["longest"] = int(plan["training_size"])
    elif state.get("size") and _takes(model.practice, "longest"):
        more["longest"] = int(state.get("learn_at") or 0)
    if _takes(model.practice, "validation"):
        more["validation"] = list(dict.fromkeys(
            list(plan.get("validation_paths", [])) + list(plan.get("frozen_paths", []))))
    if _takes(model.practice, "frozen"):
        more["frozen"] = plan.get("frozen_paths", [])
    if _takes(model.practice, "sources"):
        more["sources"] = state.get("painter_sources") or {}
    if state.get("fresh") and _takes(model.practice, "fresh"):
        more["fresh"] = list(state["fresh"])
    # Intention (2026-10-04, found live: round 101's master practice ran over
    # three hours — it goes over everything ever kept until it stops gaining,
    # and what is kept grows by every picture taught): the master practises
    # for as long as the round taught, as the parts do (`_parts`), and carries
    # on from where it is next round (MasterPractice.practice `seconds`).
    share = float(state["times"].get("teach", 0.0)) + float(state["times"].get("side", 0.0))
    if share > 0.0 and _takes(model.practice, "seconds"):
        more["seconds"] = share
    if _takes(model.practice, "round_no"):
        more["round_no"] = int(state.get("round", 0))
    said = model.practice(state["subject"], **more)
    state["fresh"] = []
    return said


def _hands_back_side(model) -> bool:
    """Intention: whether this picture model can leave a reference's other concepts to the `side` part (the Eye's can; an older model teaches them all in its teach)."""
    import inspect
    try:
        return "side" in inspect.signature(model.train_example).parameters and hasattr(model, "teach_side")
    except (TypeError, ValueError):
        return False


def _this_round(scored: list) -> list:
    """The references a round teaches: curriculum-balanced anchors and challenging boundary cases.

    Intention: keeping individual queue lessons bounded prevents multi-hour turn freezes;
    combining high-confidence anchors with harder edge cases accelerates feature learning.
    """
    if not scored:
        return []
    if len(scored) <= 10:
        return list(scored)
    try:
        from projects.behemoth_eye.eye.reactive_policy import ReactivePolicy
        hard_ratio = ReactivePolicy.current().hard_ratio
    except Exception:
        hard_ratio = 0.50
    n_hard = int(round(10 * hard_ratio))
    n_anchors = 10 - n_hard
    anchors = scored[:n_anchors]
    # Pick challenging boundary references from the middle pool
    pool = scored[n_anchors:min(len(scored), 40)]
    hard_cases = pool[-n_hard:] if len(pool) >= n_hard else pool[:n_hard]
    return list(anchors + hard_cases)


def _told_apart(data: dict, subject: str, count: int) -> list:
    """The newest usable references a dataset labelled as something other than `subject`, beside it; at most `count`.

    Intention: a reference pulled from a labelled dataset keeps the dataset's
    other label names (`not_labels`, warp2/ask/picture_datasets.py); those
    naming this subject are pictures the dataset says are not it.
    """
    from warp2.ask.reference import usable
    apart = [ref for ref in data['references'].values()
             if subject in (ref.get('not_labels') or []) and ref.get('subject') != subject
             and usable(ref) and Path(str(ref.get('path', ''))).is_file()]
    apart.sort(key=lambda ref: float(ref.get('found_at') or 0.0), reverse=True)
    return apart[:max(0, min(10, int(count)))]


def _learned_nothing(learning) -> set:
    """Intention: the picture concepts the last measurement found learned nothing (warp2/ask/concept_worth.py) — none when there is no state folder or no report."""
    state = getattr(learning, "state", None)
    if state is None:
        return set()
    from warp2.ask.concept_worth import learned_nothing
    return learned_nothing(state)


def _one_side(items: list, wanted: list, skip=()) -> list:
    """The one other concept a reference teaches: the heaviest; among equally heavy ones, one the readers said was missing.

    Intention (Andrew, 2026-10-02): a reference carried 128-145 other
    concepts and teaching them all made each teach take ten minutes —
    "one would be enough". Kept as a list so a round saved with more carries
    on with just the one.
    """
    # Intention (Andrew, 2026-10-03: "answered by testing what is best"): a
    # concept measured to have learned nothing is not given the side part's
    # time; its network is kept.
    items = [item for item in items if str(item[1]).lower() not in set(skip)]
    if len(items) <= 1:
        return list(items)
    missing = {str(w).lower() for w in wanted}
    best = max(float(item[2]) for item in items)
    heaviest = [item for item in items if float(item[2]) >= best]
    return [next((item for item in heaviest if str(item[1]).lower() in missing), heaviest[0])]


# Intention (BUILD_LOG 643): the subjects whose unguessed extra networks were
# retired in this process — once per subject, at its first part, so a round
# resumed in the middle (its _weigh already done) does not run its cascades
# with them.
_RETIRED_FOR: set = set()


def _retire_extras_once(learning, state: dict) -> None:
    """Intention: the subject's unguessed extras retired at this process's first part for it."""
    key = (_key(learning), str(state.get("subject", "")))
    if key in _RETIRED_FOR or not state.get("subject"):
        return
    _RETIRED_FOR.add(key)
    try:
        from warp2.ask.subconcept_tries import SubconceptRegistrar
        state["retired_extras"] = SubconceptRegistrar.retire_extras(_model(learning), state["subject"], learning.state)
    except Exception as exc:
        noted("warp2/ask/picture_round.py:_retire_extras_once", exc)


def _after_teaching(state: dict) -> str:
    """Intention: the reference's other concepts first, then the next reference, then the round's blocks."""
    if state.get("side"):
        return "side"
    return "teach" if state["queue"] else "blocks"


# Intention: ONE PICTURE MODEL PER STATE FOLDER FOR THE WHOLE ROUND. The Eye
# under it is already one per folder (WarpEye.for_state), but the picture
# model's own record — which pictures each subject was taught on, used when
# it practises — lives on the object, and loading a fresh one for every part
# lost it between parts (measured 2026-10-02: "drawn again 0").
_MODELS: dict = {}


def _model(learning):
    """Intention: the picture model for this state folder, kept between parts."""
    key = _key(learning)
    if key not in _MODELS:
        _MODELS[key] = learning._model()
    return _MODELS[key]


def _learn_at(learning) -> int:
    """Intention: full size when a person is waiting, small when the machine practises alone (Andrew, 2026-09-12)."""
    from warp2.ask.waiting import Waiting
    model = _model(learning)
    return int(getattr(model, 'longest', 0) if Waiting(learning.state).someone() else getattr(model, 'alone', 0))
