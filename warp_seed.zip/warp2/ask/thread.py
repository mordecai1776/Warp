# WARP2/warp2/ask/thread.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/thread.py
#  Used by   : warp2/ask/window.py, warp2/ask/talk.py, warp2/ask/visual.py
#              (practice reports go to the image feed).
#  Uses      : warp2/util.py (ensure_dir, now_iso, atomic_write_bytes),
#              warp2/record/journal.py (last_lines — the tail without the
#              whole file), warp2/record/locks.py (one writer at a time);
#              stdlib json, functools.
#  Description:
#    The conversation, kept on disk. Append only, one line a turn.
#  User intention (Andrew, 2026-09-07):
#    "We need to be able to talk and get feedback about projects and talk about
#    what and how I want things."
#    A conversation he can close and come back to. The window is not the
#    conversation, the same way the window was never the inbox.
# ============================================================================
from __future__ import annotations

import json
from functools import wraps
from pathlib import Path

from warp2.util import atomic_write_bytes, ensure_dir, now_iso


def _held(method):
    """One writer at a time on the conversation file, across every process.

    Intention (2026-10-09, check G2): the runner appends turns while the
    window rewrites the file (images taken out, a reset), and the rewrites
    used `write_text`, which empties the file first. A crash mid-rewrite lost
    the conversation, and a turn appended during it was lost. Every write now
    holds the same lock, and every rewrite is atomic.
    """
    @wraps(method)
    def guarded(self, *args, **kwargs):
        """Intention: run the wrapped method while holding the conversation file's lock."""
        from warp2.record.locks import Lock
        with Lock(self.path, seconds=60):
            return method(self, *args, **kwargs)
    return guarded

# Who said a thing. Intention: two speakers and no third, because a turn whose
# speaker is unclear is a turn nobody can weigh later.
ANDREW = "you"
WARP = "warp"

# Intention: where the machine's OWN image work is reported — practice
# pictures and the references it found — beside the conversation, not in it.
# Andrew, 2026-09-18: "the image stuff should not go in the conversation
# unless I have asked for an image in the conversation." The window reads this
# file only to put pictures in the Confirmations panel.
IMAGE_FEED = "image_feed.jsonl"


def image_feed(state) -> "Thread":
    """Intention: the machine's image reports, in their own file under state/asked."""
    return Thread(ensure_dir(Path(state) / "asked") / IMAGE_FEED)


class Thread:
    """What has been said, in order, kept between windows.

    Intention: APPEND ONLY. A conversation that can be edited after the fact is
    not evidence of anything, and this one decides what gets stored as his
    intention.
    """

    def __init__(self, state) -> None:
        """Intention: use the given .jsonl file, or asked/talking.jsonl under the state folder, as the
        conversation file.
        """
        p = Path(state)
        if p.name == "talking.jsonl" or p.suffix == ".jsonl":
            self.path = p
            p.parent.mkdir(parents=True, exist_ok=True)
        else:
            self.path = ensure_dir(p / "asked") / "talking.jsonl"

    # Intention: one line, one turn, written as it happens — so closing the
    # window mid-sentence loses the sentence and nothing else.
    @_held
    def add(self, who: str, said: str, **more) -> dict:
        """Write down one turn."""
        turn = {"who": str(who), "said": str(said), "at": now_iso()}
        turn.update({name: value for name, value in more.items() if value})
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(turn, ensure_ascii=False) + "\n")
        return turn

    # Intention: the last few, because a window shows the end of a conversation
    # and a model is given the end of it too. Reading the whole file to show
    # twenty lines is what makes a chat window slow after a month.
    def _rewrite(self, text: str) -> None:
        """Intention: the whole file replaced at once — never emptied first (check G2)."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_bytes(self.path, text.encode("utf-8"))

    def recent(self, limit: int = 40) -> list:
        """The last turns, oldest first."""
        if not self.path.is_file():
            return []
        # Intention: READ FROM THE END. The conversation file is 13 MB and
        # 2,336 turns (2026-09-18), and the window read and parsed all of it
        # on its own thread every two seconds to show the last forty — one of
        # the reasons it was too slow to use. Only the last lines are read.
        from warp2.record.journal import last_lines
        out = []
        for line in last_lines(self.path, int(limit)):
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
        return out[-int(limit):]

    @_held
    def reset(self) -> dict:
        """Archive the current conversation thread and start a fresh one.

        User intention (Andrew, 2026-09-07):
        "The conversation should be able to be reset"
        Preserves history by archiving the current talking.jsonl with a timestamp,
        leaving an empty talking.jsonl ready for new turns.
        """
        if not self.path.is_file():
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._rewrite("")
            return {"archived": "", "turns": 0}
        lines = [line for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()]
        if not lines:
            self._rewrite("")
            return {"archived": "", "turns": 0}

        import shutil
        archive_dir = ensure_dir(self.path.parent / "archive")
        stamp = now_iso().replace(":", "-").replace(".", "_")
        archive_path = archive_dir / f"talking_{stamp}.jsonl"
        # Intention: two resets inside one clock tick (Windows ticks ~15 ms)
        # must keep two archives, not write one over the other.
        again = 1
        while archive_path.exists():
            archive_path = archive_dir / f"talking_{stamp}_{again}.jsonl"
            again += 1
        shutil.copy2(self.path, archive_path)
        self._rewrite("")
        return {"archived": str(archive_path), "turns": len(lines)}

    def export_markdown(self, archive_path: str | Path | None = None) -> str:
        """Export the current or an archived conversation to readable Markdown.

        User intention:
        Allow easily reviewing, saving, or sharing conversational history.
        """
        turns = self.load_archive(archive_path) if archive_path else self.recent(limit=1000)
        lines = [
            "# WARP2 Conversation Export",
            f"*Generated: {now_iso()}*\n",
            "---",
        ]
        for turn in turns:
            who = "You (Andrew)" if turn.get("who") == ANDREW else "WARP"
            at = turn.get("at", "")
            said = turn.get("said", "")
            lines.append(f"\n### {who}  `{at}`\n")
            lines.append(said)
            if turn.get("grounds"):
                lines.append(f"\n> **Grounds:** {turn['grounds']}")
            if turn.get("image"):
                lines.append(f"\n*Generated Image:* `{turn['image']}`")
            if turn.get("references"):
                lines.append(f"\n*References:* " + ", ".join(f"`{r}`" for r in turn["references"]))
        return "\n".join(lines) + "\n"

    def list_archives(self) -> list[dict]:
        """List archived past conversations, newest first.

        User intention (Andrew, 2026-09-07):
        "We also need stuff for past conversations and folders for projects."
        """
        archive_dir = self.path.parent / "archive"
        if not archive_dir.is_dir():
            return []
        files = sorted(archive_dir.glob("talking_*.jsonl"), reverse=True)
        archives = []
        for file in files:
            turns = []
            try:
                for line in file.read_text(encoding="utf-8", errors="replace").splitlines():
                    line = line.strip()
                    if line:
                        turns.append(json.loads(line))
            except Exception:
                continue
            if not turns:
                continue
            first_user = next((t.get("said") for t in turns if t.get("who") == ANDREW), turns[0].get("said", ""))
            title = (first_user[:36] + ("…" if len(first_user) > 36 else "")) or "Conversation"
            time_str = turns[0].get("at", "")[:16].replace("T", " ")
            archives.append({
                "path": str(file),
                "filename": file.name,
                "title": title,
                "time": time_str,
                "turns_count": len(turns),
            })
        return archives

    def load_archive(self, file_path: str | Path) -> list[dict]:
        """Load turns from a specific archived conversation.

        User intention (Andrew, 2026-09-07):
        Allow viewing past conversations in the chat interface.
        """
        path = Path(file_path)
        if not path.is_file():
            return []
        out = []
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
        return out

    def save_session(self, title: str | None = None) -> dict:
        """Snapshot and save the current conversation session to archive.

        User intention (Andrew, 2026-09-07):
        "we need to have it always save the conversation"
        """
        if not self.path.is_file():
            return {"archived": "", "turns": 0}
        lines = [line for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()]
        if not lines:
            return {"archived": "", "turns": 0}

        import shutil
        archive_dir = ensure_dir(self.path.parent / "archive")
        stamp = now_iso().replace(":", "-").replace(".", "_")
        archive_path = archive_dir / f"talking_{stamp}.jsonl"
        shutil.copy2(self.path, archive_path)
        return {"archived": str(archive_path), "turns": len(lines)}

    def delete_archive(self, file_path: str | Path) -> bool:
        """Delete an archived conversation file.

        User intention (Andrew, 2026-09-07):
        "just have a way to delete conversations."
        Removes the specified past conversation archive file from disk.
        """
        path = Path(file_path).resolve()
        archive_dir = (self.path.parent / "archive").resolve()
        try:
            if path.is_file() and archive_dir in path.parents and path.name.startswith("talking_"):
                path.unlink(missing_ok=True)
                return True
        except Exception:
            return False
        return False

    @_held
    def delete_current(self) -> bool:
        """Clear and delete the active conversation without archiving.

        User intention (Andrew, 2026-09-07):
        "just have a way to delete conversations."
        Discards active thread turns immediately when requested.
        """
        if self.path.is_file():
            self._rewrite("")
            return True
        return False

    @_held
    def remove_image_from_turn(self, image_path: str | Path) -> bool:
        """Remove an image or reference embed from turns, marking it stored and preserving text.

        User intention (Andrew, 2026-09-08):
        "The images should be removed from the chat"
        "when I conferm a image it needs to get stored and go away"
        "images still stay in the conversation when I comferm what they are"
        """
        if not self.path.is_file():
            return False
        target_name = Path(image_path).name.lower()
        target_resolved = str(Path(image_path).resolve()).lower() if Path(image_path).exists() else str(Path(image_path)).lower()
        lines = self.path.read_text(encoding="utf-8", errors="replace").splitlines()
        modified = False
        new_lines = []
        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue
            try:
                turn = json.loads(line_str)
            except Exception:
                new_lines.append(line_str)
                continue

            # 1. Check generated image in turn
            img_in_turn = turn.get("image")
            if img_in_turn:
                p_img = Path(img_in_turn)
                p_img_resolved = str(p_img.resolve()).lower() if p_img.exists() else str(p_img).lower()
                if p_img.name.lower() == target_name or p_img_resolved == target_resolved:
                    turn["stored_image"] = img_in_turn
                    turn["image"] = None
                    modified = True
                    # If this turn has candidate references, clean them as well so all images in this turn go away
                    if turn.get("references"):
                        if not turn.get("stored_references"):
                            turn["stored_references"] = []
                        for r in turn["references"]:
                            if r not in turn["stored_references"]:
                                turn["stored_references"].append(r)
                        turn["references"] = []
                    if turn.get("reference"):
                        if not turn.get("stored_references"):
                            turn["stored_references"] = []
                        if turn["reference"] not in turn["stored_references"]:
                            turn["stored_references"].append(turn["reference"])
                        turn["reference"] = None

            # 2. Check singular reference
            ref_single = turn.get("reference")
            if ref_single:
                p_ref = Path(ref_single)
                p_ref_resolved = str(p_ref.resolve()).lower() if p_ref.exists() else str(p_ref).lower()
                if p_ref.name.lower() == target_name or p_ref_resolved == target_resolved:
                    if not turn.get("stored_references"):
                        turn["stored_references"] = []
                    if ref_single not in turn["stored_references"]:
                        turn["stored_references"].append(ref_single)
                    turn["reference"] = None
                    modified = True

            # 3. Check plural references
            refs = turn.get("references")
            if refs:
                matched_refs = []
                remaining_refs = []
                for r in refs:
                    p_r = Path(r)
                    p_r_resolved = str(p_r.resolve()).lower() if p_r.exists() else str(p_r).lower()
                    if p_r.name.lower() == target_name or p_r_resolved == target_resolved:
                        matched_refs.append(r)
                    else:
                        remaining_refs.append(r)
                if matched_refs:
                    if not turn.get("stored_references"):
                        turn["stored_references"] = []
                    for mr in matched_refs:
                        if mr not in turn["stored_references"]:
                            turn["stored_references"].append(mr)
                    turn["references"] = remaining_refs
                    modified = True

            # 4. Clean reference_reviews for this target
            revs = turn.get("reference_reviews")
            if revs:
                matched_revs = [r for r in revs if isinstance(r, dict) and (Path(r.get("path", "")).name.lower() == target_name or str(Path(r.get("path", "")).resolve()).lower() == target_resolved)]
                if matched_revs:
                    if not turn.get("stored_reference_reviews"):
                        turn["stored_reference_reviews"] = []
                    for mr in matched_revs:
                        if mr not in turn["stored_reference_reviews"]:
                            turn["stored_reference_reviews"].append(mr)
                    turn["reference_reviews"] = [r for r in revs if r not in matched_revs]
                    modified = True

            new_lines.append(json.dumps(turn, ensure_ascii=False))

        if modified:
            self._rewrite("\n".join(new_lines) + ("\n" if new_lines else ""))
        return modified

    @_held
    def strip_all_images(self) -> int:
        """Strip all image and reference embeds from active conversation turns.

        User intention (Andrew, 2026-09-08):
        "The images should be removed from the chat"
        Converts all embedded images to text records, leaving chat clean and compact.
        """
        if not self.path.is_file():
            return 0
        lines = self.path.read_text(encoding="utf-8", errors="replace").splitlines()
        count = 0
        new_lines = []
        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue
            try:
                turn = json.loads(line_str)
            except Exception:
                new_lines.append(line_str)
                continue

            if turn.get("image"):
                turn["stored_image"] = turn.get("image")
                turn["image"] = None
                count += 1
            if turn.get("references"):
                turn["stored_references"] = turn.get("references")
                turn["references"] = []
                count += 1

            new_lines.append(json.dumps(turn, ensure_ascii=False))

        if count > 0:
            self._rewrite("\n".join(new_lines) + ("\n" if new_lines else ""))
        return count


