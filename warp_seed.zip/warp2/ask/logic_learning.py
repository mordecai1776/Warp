# WARP2/warp2/ask/logic_learning.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/logic_learning.py
#  Used by   : warp2/ask/tests/test_logic_learning.py,
#              warp2/work/side/logic.py
#  Uses      : warp2/ask/logic_rules.py (RuleProofs — a rule topic's own
#              truth-table proof, BUILD_LOG 1118); the standard library
#  Description:
#    LogicLearning: Researches formal logic, automated reasoning, and proves
#    logical skills.
#  User intention:
#    Not written down in this file yet; noted to ask Andrew (2026-09-18).
# ============================================================================
"""LogicLearning: Researches formal logic, automated reasoning, and proves logical skills."""
from __future__ import annotations

import itertools
import json
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from warp2.record.swallowed import noted



USER_AGENT = "WARP2LogicLearning/0.4 (autonomous logic and formal reasoning engine)"


@dataclass
class LogicConcept:
    """A learned formal logic, deduction, or reasoning concept."""
    name: str
    domain: str
    summary: str
    source_url: str = ""
    discovered_at: float = field(default_factory=time.time)


@dataclass
class ProvenLogicSkill:
    """A proven formal reasoning rule, theorem, or constraint solver."""
    proof_name: str
    concept: str
    description: str
    proven: bool
    test_message: str
    execution_time_ms: float
    verified_at: float = field(default_factory=time.time)


# Taxonomy of formal logic, reasoning, and deduction domains
LOGIC_DOMAINS: dict[str, list[str]] = {
    "propositional_and_boolean": [
        "Boolean satisfiability problem",
        "De Morgan's laws",
        "Truth table",
        "Conjunctive normal form",
        "Resolution (logic)",
        "Boolean algebra",
    ],
    "deductive_and_syllogistic": [
        "Modus ponens",
        "Modus tollens",
        "Syllogism",
        "Hypothetical syllogism",
        "Reductio ad absurdum",
        "Principle of explosion",
    ],
    "inference_and_rules": [
        "Forward chaining",
        "Backward chaining",
        "Horn clause",
        "First-order logic",
        "Inference rule",
        "Automated theorem proving",
    ],
    "constraint_satisfaction": [
        "Constraint satisfaction problem",
        "Backtracking",
        "Arc consistency",
        "Graph coloring",
        "Sudoku solving algorithms",
    ],
    "higher_inverse_logic": [
        "Contraposition",
        "Dual (category theory)",
        "Negation",
        "Logical biconditional",
        "Material implication",
    ],
}


# Intention: WHICH TOPIC EACH HAND-WRITTEN PROOF REALLY IS. One line per
# topic, by its exact name in LOGIC_DOMAINS. It replaced a substring guess
# that sent every topic it did not recognise to a test of the tag registry
# and called the topic proven. MEASURED 2026-09-19: "Rule of inference" was
# recorded proven 350 times that way; Modus tollens, Reductio and First-order
# logic were "proven" by tests that do not touch them. A topic not in this
# table has no proof; it becomes build work (warp2/work/side/skill_work.py)
# and is proven only when that code is.
TOPIC_PROOFS: dict[str, str] = {
    "Boolean satisfiability problem": "DPLL Boolean SAT Solver",
    "De Morgan's laws": "De Morgan Boolean Algebra Prover",
    "Forward chaining": "Forward Chaining Deductive Reasoner",
    "Backward chaining": "Backward Chaining Goal Prover",
    "Constraint satisfaction problem": "CSP Constraint Backtracking Solver",
    "Backtracking": "CSP Constraint Backtracking Solver",
    "Graph coloring": "CSP Constraint Backtracking Solver",
    "Syllogism": "Aristotelian Syllogism Engine",
}


class LogicProver:
    """Executes and mathematically verifies formal logic rules, algorithms, and proofs."""

    @staticmethod
    def prove_boolean_sat() -> tuple[bool, str, float]:
        """Verify Boolean SAT solving via DPLL backtracking on Conjunctive Normal Form (CNF).

        Formula: (x1 or x2) and (not x1 or x3) and (not x2 or not x3) and (x1 or not x3)
        Variables: x1, x2, x3
        """
        t0 = time.perf_counter()

        def solve_cnf(clauses: list[list[int]], assignment: dict[int, bool]) -> dict[int, bool] | None:
            """Intention: the SAT solver under test: try values one variable at a time until every
            clause holds, or None.
            """
            # Check clause satisfactions
            all_satisfied = True
            for clause in clauses:
                clause_satisfied = False
                unassigned = False
                for lit in clause:
                    var = abs(lit)
                    if var in assignment:
                        val = assignment[var] if lit > 0 else not assignment[var]
                        if val:
                            clause_satisfied = True
                            break
                    else:
                        unassigned = True
                if not clause_satisfied:
                    if not unassigned:
                        return None  # Clause is definitely False
                    all_satisfied = False

            if all_satisfied:
                return assignment

            # Pick an unassigned variable
            all_vars = {abs(lit) for clause in clauses for lit in clause}
            unassigned_vars = sorted(list(all_vars - set(assignment.keys())))
            if not unassigned_vars:
                return None

            var_to_try = unassigned_vars[0]
            # Try True then False
            for val in (True, False):
                new_assign = dict(assignment)
                new_assign[var_to_try] = val
                res = solve_cnf(clauses, new_assign)
                if res is not None:
                    return res
            return None

        # CNF Clauses over variables 1, 2, 3:
        # (x1 or x2) & (~x1 or x3) & (~x2 or ~x3) & (x1 or ~x3)
        test_clauses = [
            [1, 2],
            [-1, 3],
            [-2, -3],
            [1, -3],
        ]
        solution = solve_cnf(test_clauses, {})
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        if solution is not None:
            # Verify the solution satisfies every single clause
            for clause in test_clauses:
                satisfied = any(
                    (solution[abs(lit)] if lit > 0 else not solution[abs(lit)])
                    for lit in clause
                )
                if not satisfied:
                    return False, f"SAT solver proposed invalid assignment {solution}", elapsed_ms

            model_str = ", ".join(f"x{k}={v}" for k, v in sorted(solution.items()))
            return True, f"Boolean SAT solver proved satisfiability with verified model: [{model_str}]", elapsed_ms

        return False, "SAT solver failed to find satisfying assignment", elapsed_ms

    @staticmethod
    def prove_forward_chaining() -> tuple[bool, str, float]:
        """Verify Forward Chaining inference deriving new knowledge from axioms and rules.

        Axioms: A, B
        Rules:
          A and B -> C
          C and D -> E
          C -> F
          F -> G
        Goal: G
        """
        t0 = time.perf_counter()

        axioms = {"A", "B"}
        rules = [
            ({"A", "B"}, "C"),
            ({"C", "D"}, "E"),
            ({"C"}, "F"),
            ({"F"}, "G"),
        ]
        goal = "G"

        known_facts = set(axioms)
        inferred = []
        changed = True
        while changed:
            changed = False
            for premises, conclusion in rules:
                if premises.issubset(known_facts) and conclusion not in known_facts:
                    known_facts.add(conclusion)
                    inferred.append(conclusion)
                    changed = True

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        if goal in known_facts and "C" in known_facts and "F" in known_facts and "E" not in known_facts:
            return True, f"Forward chaining cleanly inferred chain: {' -> '.join(inferred)} to prove goal '{goal}'", elapsed_ms
        return False, "Forward chaining failed to deduce goal", elapsed_ms

    @staticmethod
    def prove_backward_chaining() -> tuple[bool, str, float]:
        """Verify Goal-Directed Backward Chaining resolving queries against Horn clauses.

        Knowledge base:
          Croaks(X) and EatsFlies(X) -> Frog(X)
          Frog(X) -> Green(X)
          Facts: Croaks(Fritz), EatsFlies(Fritz)
        Goal: Green(Fritz)
        """
        t0 = time.perf_counter()

        facts = {("Croaks", "Fritz"), ("EatsFlies", "Fritz")}
        # Rule: (head_pred, head_arg) <= list of (body_pred, body_arg)
        # Using variable 'X'
        rules = [
            (("Frog", "X"), [("Croaks", "X"), ("EatsFlies", "X")]),
            (("Green", "X"), [("Frog", "X")]),
        ]

        def prove_goal(pred: str, arg: str, stack: set[tuple[str, str]]) -> bool:
            """Intention: the backward chainer under test: a goal holds if it is a fact or some rule's body can be proven.
            Goals already on the stack are refused, so a loop of rules cannot recurse for ever.
            """
            query = (pred, arg)
            if query in facts:
                return True
            if query in stack:
                return False  # Loop prevention
            new_stack = stack | {query}

            for (head_pred, var), body in rules:
                if head_pred == pred:
                    # Ground the rule with arg
                    ground_body = [(b_pred, arg if b_var == var else b_var) for b_pred, b_var in body]
                    if all(prove_goal(b_pred, b_arg, new_stack) for b_pred, b_arg in ground_body):
                        return True
            return False

        proved = prove_goal("Green", "Fritz", set())
        disproved = prove_goal("Green", "Garfield", set())
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        if proved and not disproved:
            return True, "Backward chaining proved hypothesis Green(Fritz) and correctly rejected Green(Garfield)", elapsed_ms
        return False, "Backward chaining theorem prover failed", elapsed_ms

    @staticmethod
    def prove_constraint_satisfaction() -> tuple[bool, str, float]:
        """Verify Constraint Satisfaction Problem (CSP) solver for graph coloring.

        Variables: Regions WA, NT, SA, Q, NSW, V
        Colors: Red, Green, Blue
        Constraint: Adjacent regions must not have the same color.
        """
        t0 = time.perf_counter()

        neighbors = {
            "WA": ["NT", "SA"],
            "NT": ["WA", "SA", "Q"],
            "SA": ["WA", "NT", "Q", "NSW", "V"],
            "Q": ["NT", "SA", "NSW"],
            "NSW": ["Q", "SA", "V"],
            "V": ["SA", "NSW"],
        }
        colors = ["Red", "Green", "Blue"]

        def backtrack(assignment: dict[str, str]) -> dict[str, str] | None:
            """Intention: the map-colouring search under test: give each region a colour no neighbour
            has, undoing on dead ends.
            """
            if len(assignment) == len(neighbors):
                return assignment

            unassigned = [v for v in neighbors if v not in assignment]
            var = unassigned[0]

            for col in colors:
                # Check consistency
                conflict = False
                for n in neighbors[var]:
                    if n in assignment and assignment[n] == col:
                        conflict = True
                        break
                if not conflict:
                    assignment[var] = col
                    res = backtrack(assignment)
                    if res is not None:
                        return res
                    del assignment[var]
            return None

        sol = backtrack({})
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        if sol is not None:
            # Verify no adjacent regions have identical color
            for r1, adj_list in neighbors.items():
                for r2 in adj_list:
                    if sol[r1] == sol[r2]:
                        return False, f"CSP conflict between {r1} and {r2} (both {sol[r1]})", elapsed_ms

            summary = ", ".join(f"{k}:{v}" for k, v in sorted(sol.items()))
            return True, f"CSP solver found conflict-free 3-coloring across 6 regions: [{summary}]", elapsed_ms

        return False, "CSP solver failed to color graph", elapsed_ms

    @staticmethod
    def prove_syllogistic_deduction() -> tuple[bool, str, float]:
        """Verify Aristotelian Syllogisms and Fallacy Detection.

        Valid Barbara Syllogism:
          All M are P  (All Humans are Mortal)
          All S are M  (All Greeks are Humans)
          => All S are P (All Greeks are Mortal)

        Invalid Fallacy (Affirming the Consequent):
          P -> Q, Q => P (Invalid)
        """
        t0 = time.perf_counter()

        class SyllogismEngine:
            """Intention: the small syllogism checker under test: one valid deduction and one fallacy it must refuse."""
            @staticmethod
            def deduce_all(major_premise: tuple[str, str], minor_premise: tuple[str, str]) -> str | None:
                """Intention: from All M are P and All S are M, conclude All S are P; None when the
                middle terms differ.
                """
                # major: (M, P) means All M are P
                # minor: (S, M) means All S are M
                m1, p = major_premise
                s, m2 = minor_premise
                if m1 == m2:
                    return f"All {s} are {p}"
                return None

            @staticmethod
            def check_implication(p_implies_q: bool, q: bool) -> bool | None:
                """Intention: knowing P -> Q and Q says nothing about P (affirming the consequent), so always None."""
                # If P -> Q is true, knowing Q does NOT prove P (Affirming the consequent fallacy)
                return None  # Indeterminate

        res_valid = SyllogismEngine.deduce_all(("Human", "Mortal"), ("Greek", "Human"))
        res_fallacy = SyllogismEngine.check_implication(True, True)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        if res_valid == "All Greek are Mortal" and res_fallacy is None:
            return True, "Syllogistic engine verified valid deduction 'All Greek are Mortal' and rejected affirmation of consequent fallacy", elapsed_ms
        return False, "Syllogistic deduction test failed", elapsed_ms

    @staticmethod
    def prove_demorgan_laws() -> tuple[bool, str, float]:
        """Exhaustively verify De Morgan's dual laws across all truth valuations.

        Law 1: not (A and B) <=> (not A) or (not B)
        Law 2: not (A or B) <=> (not A) and (not B)
        """
        t0 = time.perf_counter()

        verified_cases = 0
        for a, b in itertools.product([True, False], repeat=2):
            law1_lhs = not (a and b)
            law1_rhs = (not a) or (not b)
            if law1_lhs != law1_rhs:
                return False, f"De Morgan Law 1 failed for A={a}, B={b}", 0.0

            law2_lhs = not (a or b)
            law2_rhs = (not a) and (not b)
            if law2_lhs != law2_rhs:
                return False, f"De Morgan Law 2 failed for A={a}, B={b}", 0.0

            verified_cases += 1

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return True, f"De Morgan's dual laws exhaustively proved across all {verified_cases} Boolean valuations", elapsed_ms

    @classmethod
    def proof_source(cls, proof_name: str) -> str:
        """The code of the proof that ran under this name, or "".

        Intention: THE PROOF ITSELF IS THE TRAINING TEXT. The side step read a
        `proof_text` this file never returned, so every logic training block
        carried an empty proof (found 2026-09-18). The code of a proof that
        passed is verified code — Andrew's rule for what is trained on.
        """
        import inspect
        method = PROOF_METHODS.get(str(proof_name))
        if method is None:
            # Intention (BUILD_LOG 1118): a rule's truth-table proof — the rule, its fallacy, and the check.
            from warp2.ask.logic_rules import RuleProofs
            return RuleProofs.source(str(proof_name))
        try:
            return inspect.getsource(method)
        except (OSError, TypeError):
            return ""

    @classmethod
    def prove_logic_for(cls, topic: str) -> tuple[bool, str, str, float] | None:
        """Run the proof written for this exact topic, or None when there is none.

        Intention: None is the honest answer for a topic with no proof. It is
        never answered with some other proof's pass.
        """
        name = TOPIC_PROOFS.get(str(topic))
        if name is None:
            # Intention (BUILD_LOG 1118): a rule topic is proven by its own truth table against its fallacy
            # (logic_rules.py); any other topic still has none.
            from warp2.ask.logic_rules import RuleProofs
            return RuleProofs.prove(str(topic))
        ok, msg, ms = PROOF_METHODS[name]()
        return ok, name, msg, ms


# Intention: which proof runs under each name, so the code of a passed proof
# can be kept with it. After the class, because the proofs are named here
# directly rather than as strings. One line per name; the test in
# ask/tests/test_logic_learning.py checks every name has its method.
PROOF_METHODS = {
    "CSP Constraint Backtracking Solver": LogicProver.prove_constraint_satisfaction,
    "DPLL Boolean SAT Solver": LogicProver.prove_boolean_sat,
    "Forward Chaining Deductive Reasoner": LogicProver.prove_forward_chaining,
    "Backward Chaining Goal Prover": LogicProver.prove_backward_chaining,
    "Aristotelian Syllogism Engine": LogicProver.prove_syllogistic_deduction,
    "De Morgan Boolean Algebra Prover": LogicProver.prove_demorgan_laws,
}

class LogicLearning:
    """Discovers formal logic concepts online, learns reasoning rules, and proves logical skills."""

    def __init__(self, root_dir: Path | str, state_dir: Path | str) -> None:
        """Intention: set where the logic learning ledger and proofs live under state/knowledge, and load the ledger."""
        self.root_dir = Path(root_dir)
        self.state_dir = Path(state_dir)
        self.knowledge_dir = self.state_dir / "knowledge"
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)
        self.ledger_path = self.knowledge_dir / "logic_learning.json"
        self.proofs_path = self.knowledge_dir / "logic_proofs.jsonl"
        self._load_ledger()

    def _load_ledger(self) -> dict[str, Any]:
        """Intention: read the ledger, or start (and save) an empty one; a broken file is read as empty."""
        if not self.ledger_path.is_file():
            self.data: dict[str, Any] = {
                "concepts": {},
                "proven_skills": {},
                "total_passes": 0,
                "last_domain": "",
            }
            self._save_ledger()
        else:
            # Intention (2026-11-07): a ledger that cannot be read stops here (warp2/record/kept_file.py) - it used to
            # be read as empty and the next save wrote the empty one over the whole learning history.
            from warp2.record.kept_file import read_kept
            self.data = read_kept(self.ledger_path, {"concepts": {}, "proven_skills": {}, "total_passes": 0, "last_domain": ""})
        return self.data

    def _save_ledger(self) -> None:
        """Intention: write the ledger whole through a temp file, so a crash never leaves half a file."""
        temp = self.ledger_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(self.ledger_path)

    def search_online_concept(self, topic: str, timeout: float = 4.0) -> LogicConcept | None:
        """Search Wikipedia API for clean definitions and principles of a logic topic."""
        clean_topic = topic.strip()
        encoded = urllib.parse.quote(clean_topic)
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{encoded}"
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                extract = data.get("extract", "")
                page_url = data.get("content_urls", {}).get("desktop", {}).get("page", "")
                title = data.get("title", clean_topic)
                if extract:
                    return LogicConcept(
                        name=title,
                        domain="formal_logic",
                        summary=extract[:250] + "...",
                        source_url=page_url,
                    )
        except Exception as exc:
            noted("warp2/ask/logic_learning.py:LogicLearning.search_online_concept", exc)
        return None

    def pick_next_concept_to_learn(self) -> tuple[str, str]:
        """The next topic: one never looked at, else the one looked at longest ago.

        Intention: KEYED BY THE TOPIC, NOT BY WHAT THE WEB CALLS IT. The ledger
        used the page title, and Wikipedia titles "Inference rule" as "Rule of
        inference". So the topic never counted as known and was picked again
        on every one of 350 passes. Once all are known it goes round them
        evenly, oldest first, instead of at random.
        """
        seen = self.data.get("checked", {})
        order = [(domain, t) for domain, topics in LOGIC_DOMAINS.items() for t in topics]
        for domain, t in order:
            if t not in seen:
                return domain, t
        return min(order, key=lambda pair: float(seen.get(pair[1], 0.0)))

    def learn_pass(self) -> dict[str, Any]:
        """Look one topic up, and prove it if a proof for exactly it exists.

        Intention: three honest answers. "proven" / "unproven" when a proof
        for this topic ran; "no_proof" when none exists, so the caller can
        have it built. Nothing is called proven by a proof of something else.
        """
        self.data["total_passes"] = self.data.get("total_passes", 0) + 1
        domain, topic = self.pick_next_concept_to_learn()
        self.data.setdefault("checked", {})[topic] = time.time()

        # Step 1: Online research
        concept = self.search_online_concept(topic)
        if not concept:
            concept = LogicConcept(
                name=topic,
                domain=domain,
                summary=f"Formal logic and deductive reasoning concept in the {domain} domain.",
                source_url=f"https://en.wikipedia.org/wiki/{urllib.parse.quote(topic)}",
            )

        self.data["concepts"][topic.lower()] = {
            "name": concept.name,
            "topic": topic,
            "domain": domain,
            "summary": concept.summary,
            "source_url": concept.source_url,
            "learned_at": concept.discovered_at,
        }

        # Step 2: the proof for exactly this topic, if there is one
        ran = LogicProver.prove_logic_for(topic)
        if ran is None:
            self._save_ledger()
            return {"status": "no_proof", "topic": topic, "concept": concept.name,
                    "domain": domain, "summary": concept.summary, "proof_name": "",
                    "proof_text": "", "message": f"no proof written for {topic}",
                    "execution_time_ms": 0.0}
        ok, proof_name, msg, ms = ran
        skill = ProvenLogicSkill(
            proof_name=proof_name,
            concept=concept.name,
            description=msg,
            proven=ok,
            test_message=msg,
            execution_time_ms=round(ms, 3),
        )

        self.data["proven_skills"][proof_name] = {
            "proof_name": skill.proof_name,
            "concept": skill.concept,
            "topic": topic,
            "proven": skill.proven,
            "test_message": skill.test_message,
            "time_ms": skill.execution_time_ms,
            "verified_at": skill.verified_at,
        }

        # Append to logic_proofs.jsonl
        try:
            with open(self.proofs_path, "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "proof": skill.proof_name,
                    "concept": skill.concept,
                    "topic": topic,
                    "proven": skill.proven,
                    "time_ms": skill.execution_time_ms,
                    "verified_at": skill.verified_at,
                    "message": skill.test_message,
                }) + "\n")
        except OSError:
            pass

        self._save_ledger()

        return {
            "status": "proven" if ok else "unproven",
            "topic": topic,
            "concept": concept.name,
            "domain": domain,
            "summary": concept.summary,
            "proof_name": skill.proof_name,
            # Intention: only a proof that passed carries its code.
            "proof_text": LogicProver.proof_source(skill.proof_name) if ok else "",
            "message": skill.test_message,
            "execution_time_ms": skill.execution_time_ms,
        }
