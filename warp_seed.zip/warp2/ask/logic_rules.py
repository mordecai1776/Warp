# WARP2/warp2/ask/logic_rules.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/logic_rules.py
#  Used by   : warp2/ask/logic_learning.py (LogicProver.prove_logic_for and
#              proof_source — the proof for a rule topic), warp2/work/side/
#              logic.py (LogicStep._backed — RuleProofs.covers), warp2/ask/
#              logic_problems.py (the forms and the checker),
#              warp2/ask/tests/test_logic_rules_are_proven_by_truth_table.py.
#  Uses      : stdlib inspect, itertools, random, time.
#  Description:
#    Propositional formulas, the truth-table check of an argument, and the
#    rules of reasoning the logic topics name, each with the fallacy it is
#    most often mistaken for. A rule's proof is exactly its own: the rule
#    holds on every row of its truth table AND its fallacy fails on at
#    least one — so a checker that called everything valid could never
#    prove one. Conjunctive normal form is proven by a converter whose
#    output has the CNF shape and agrees with its input on every row.
#    Measured 2026-11-02 (BUILD_LOG 1118): every logic topic without a
#    hand-written proof waited on the build lane for a module, and the
#    build lane had written none since September (projects/skills/logic/
#    did not exist): 20 of 28 logic passes said BEING_BUILT.
#  User intention (Andrew, 2026-11-02): "make sure they have proper datasets
#    and that they are given proper leaning methods and test". (2026-09-19:
#    "proven" only by a proof of exactly that topic.)
# ============================================================================
"""Truth-table proofs of the rules of reasoning, each against its fallacy."""
from __future__ import annotations

import inspect
import itertools
import random
import time

# -- formulas -------------------------------------------------------------------
# Intention: a formula is a tuple — ("atom", name), ("not", f), and
# (op, a, b) for op in and / or / imp / iff. Plain data, so a rule is read
# as it is written.


def atom(name: str) -> tuple:
    """Intention: a statement letter."""
    return ("atom", str(name))


def neg(f: tuple) -> tuple:
    """Intention: not f."""
    return ("not", f)


def both(a: tuple, b: tuple) -> tuple:
    """Intention: a and b."""
    return ("and", a, b)


def either(a: tuple, b: tuple) -> tuple:
    """Intention: a or b."""
    return ("or", a, b)


def imp(a: tuple, b: tuple) -> tuple:
    """Intention: if a then b."""
    return ("imp", a, b)


def iff(a: tuple, b: tuple) -> tuple:
    """Intention: a if and only if b."""
    return ("iff", a, b)


def atoms_of(f: tuple, out: set | None = None) -> set:
    """Intention: every statement letter in a formula."""
    out = set() if out is None else out
    if f[0] == "atom":
        out.add(f[1])
    else:
        for part in f[1:]:
            atoms_of(part, out)
    return out


def holds(f: tuple, row: dict) -> bool:
    """Intention: a formula's truth on one row of the table."""
    op = f[0]
    if op == "atom":
        return bool(row[f[1]])
    if op == "not":
        return not holds(f[1], row)
    a, b = holds(f[1], row), holds(f[2], row)
    return {"and": a and b, "or": a or b, "imp": (not a) or b, "iff": a == b}[op]


def rows_of(letters) -> list:
    """Intention: every row of the truth table over these letters, in order."""
    names = sorted(letters)
    return [dict(zip(names, values)) for values in itertools.product((True, False), repeat=len(names))]


def counter_row(premises: list, conclusion: tuple) -> dict | None:
    """The first row where every premise holds and the conclusion does not; None when there is none.

    Intention: THE WHOLE TABLE. An argument is valid exactly when no row makes
    its premises true and its conclusion false; every row is looked at.
    """
    letters = set()
    for f in [*premises, conclusion]:
        atoms_of(f, letters)
    for row in rows_of(letters):
        if all(holds(p, row) for p in premises) and not holds(conclusion, row):
            return row
    return None


def entails(premises: list, conclusion: tuple) -> bool:
    """Intention: whether the premises entail the conclusion — no counter row."""
    return counter_row(premises, conclusion) is None


def shown(f: tuple) -> str:
    """Intention: a formula in symbols — ~ & | -> <->, brackets around every pair."""
    op = f[0]
    if op == "atom":
        return f[1]
    if op == "not":
        return "~" + shown(f[1])
    sign = {"and": "&", "or": "|", "imp": "->", "iff": "<->"}[op]
    return f"({shown(f[1])} {sign} {shown(f[2])})"


# -- the rules ------------------------------------------------------------------

P, Q, R = atom("p"), atom("q"), atom("r")


class Rule:
    """One rule of reasoning and the fallacy it is mistaken for: premises and conclusion of each."""

    def __init__(self, name: str, premises: list, conclusion: tuple, fallacy: str,
                 fallacy_premises: list, fallacy_conclusion: tuple) -> None:
        """Intention: the rule as written, and its look-alike that does not hold."""
        self.name, self.premises, self.conclusion = name, premises, conclusion
        self.fallacy, self.fallacy_premises, self.fallacy_conclusion = fallacy, fallacy_premises, fallacy_conclusion

    def text(self) -> str:
        """Intention: the rule and its fallacy in symbols — the proof's own statement."""
        rule = " ; ".join(shown(p) for p in self.premises) + " |- " + shown(self.conclusion)
        bad = " ; ".join(shown(p) for p in self.fallacy_premises) + " |- " + shown(self.fallacy_conclusion)
        return f"{self.name}: {rule}\nnot to be mistaken for {self.fallacy}: {bad}"


# Intention: ONE LINE PER TOPIC, by its exact name in logic_learning.LOGIC_DOMAINS.
# Each rule is the textbook form; each fallacy the textbook look-alike.
RULES: dict[str, Rule] = {
    "Modus ponens": Rule("Modus ponens", [imp(P, Q), P], Q,
                         "affirming the consequent", [imp(P, Q), Q], P),
    "Modus tollens": Rule("Modus tollens", [imp(P, Q), neg(Q)], neg(P),
                          "denying the antecedent", [imp(P, Q), neg(P)], neg(Q)),
    "Hypothetical syllogism": Rule("Hypothetical syllogism", [imp(P, Q), imp(Q, R)], imp(P, R),
                                   "reversing the chain", [imp(P, Q), imp(Q, R)], imp(R, P)),
    "Contraposition": Rule("Contraposition", [imp(P, Q)], imp(neg(Q), neg(P)),
                           "the converse", [imp(P, Q)], imp(Q, P)),
    "Principle of explosion": Rule("Principle of explosion", [P, neg(P)], Q,
                                   "anything from one truth", [P], Q),
    "Reductio ad absurdum": Rule("Reductio ad absurdum", [imp(P, Q), imp(P, neg(Q))], neg(P),
                                 "keeping what led to a contradiction", [imp(P, Q), imp(P, neg(Q))], P),
    "Negation": Rule("Negation", [neg(neg(P))], P,
                     "a single negation dropped", [neg(P)], P),
    "Logical biconditional": Rule("Logical biconditional", [iff(P, Q), Q], P,
                                  "one way taken as both ways", [imp(P, Q), Q], P),
    "Material implication": Rule("Material implication", [imp(P, Q)], either(neg(P), Q),
                                 "the wrong side negated", [imp(P, Q)], either(P, neg(Q))),
    "Boolean algebra": Rule("Boolean algebra", [either(P, both(P, Q))], P,
                            "absorption without the shared term", [either(P, Q)], P),
    "Inference rule": Rule("Inference rule", [either(P, Q), neg(P)], Q,
                           "affirming a disjunct", [either(P, Q), P], neg(Q)),
    "Resolution (logic)": Rule("Resolution (logic)", [either(P, Q), either(neg(P), R)], either(Q, R),
                               "resolving to both", [either(P, Q), either(neg(P), R)], both(Q, R)),
    "Truth table": Rule("Truth table", [], either(P, neg(P)),
                        "a letter taken as always true", [], P),
}


# -- conjunctive normal form ------------------------------------------------------


def no_arrows(f: tuple) -> tuple:
    """Intention: -> and <-> written with not / and / or only."""
    op = f[0]
    if op == "atom":
        return f
    if op == "not":
        return neg(no_arrows(f[1]))
    a, b = no_arrows(f[1]), no_arrows(f[2])
    if op == "imp":
        return either(neg(a), b)
    if op == "iff":
        return both(either(neg(a), b), either(neg(b), a))
    return (op, a, b)


def inward(f: tuple) -> tuple:
    """Intention: every not pushed down onto a letter (De Morgan, double negation)."""
    op = f[0]
    if op == "atom":
        return f
    if op == "not":
        g = f[1]
        if g[0] == "atom":
            return f
        if g[0] == "not":
            return inward(g[1])
        if g[0] == "and":
            return either(inward(neg(g[1])), inward(neg(g[2])))
        return both(inward(neg(g[1])), inward(neg(g[2])))
    return (op, inward(f[1]), inward(f[2]))


def spread(f: tuple) -> tuple:
    """Intention: or spread over and, until every and is above every or."""
    op = f[0]
    if op in ("atom", "not"):
        return f
    a, b = spread(f[1]), spread(f[2])
    if op == "and":
        return both(a, b)
    if a[0] == "and":
        return both(spread(either(a[1], b)), spread(either(a[2], b)))
    if b[0] == "and":
        return both(spread(either(a, b[1])), spread(either(a, b[2])))
    return either(a, b)


def to_cnf(f: tuple) -> tuple:
    """Intention: a formula in conjunctive normal form — an and of ors of letters and negated letters."""
    return spread(inward(no_arrows(f)))


def is_cnf(f: tuple, under_or: bool = False) -> bool:
    """Intention: the CNF shape — no arrow anywhere, not only on a letter, no and under an or."""
    op = f[0]
    if op == "atom":
        return True
    if op == "not":
        return f[1][0] == "atom"
    if op == "and":
        return not under_or and is_cnf(f[1]) and is_cnf(f[2])
    if op == "or":
        return is_cnf(f[1], True) and is_cnf(f[2], True)
    return False


def same_on_every_row(a: tuple, b: tuple) -> bool:
    """Intention: two formulas equal on every row of their shared table."""
    return all(holds(a, row) == holds(b, row) for row in rows_of(atoms_of(a) | atoms_of(b)))


def some_formula(rng: random.Random, depth: int, letters=("p", "q", "r")) -> tuple:
    """Intention: a formula drawn at random over the letters, no deeper than `depth`."""
    if depth <= 0 or rng.random() < 1.0 / (depth + 1):
        f = atom(rng.choice(letters))
        return neg(f) if rng.random() < 0.5 else f
    op = rng.choice(("not", "and", "or", "imp", "iff"))
    if op == "not":
        return neg(some_formula(rng, depth - 1, letters))
    return (op, some_formula(rng, depth - 1, letters), some_formula(rng, depth - 1, letters))


# Intention: how many formulas the CNF proof converts — every formula over three letters to depth 3 cannot be listed,
# so as many as there are rows in a three-letter table, squared (64): each one checked on all its rows.
CNF_CASES = len(rows_of("pqr")) ** 2


def prove_cnf(seed: int = 0) -> tuple[bool, str]:
    """Intention: the converter's output has the CNF shape and agrees with its input on every row, for every case."""
    rng = random.Random(seed)
    for _ in range(CNF_CASES):
        f = some_formula(rng, 3)
        g = to_cnf(f)
        if not is_cnf(g):
            return False, f"{shown(f)} became {shown(g)}, which is not in CNF"
        if not same_on_every_row(f, g):
            return False, f"{shown(f)} and its CNF {shown(g)} differ on a row"
    return True, f"{CNF_CASES} formulas converted to CNF; each has the CNF shape and agrees on every row"


# -- the proofs --------------------------------------------------------------------


class RuleProofs:
    """The proof for a rule topic: the rule holds on every row; its fallacy fails on one."""

    @staticmethod
    def name_of(topic: str) -> str:
        """Intention: the proof's name — the topic's own, so no other topic can borrow it."""
        return f"Truth table proof of {topic}"

    @classmethod
    def covers(cls, topic: str, proof_name: str) -> bool:
        """Intention: whether this is the rule proof written for exactly this topic — what backs its KG claim."""
        return (str(topic) in RULES or str(topic) == "Conjunctive normal form") and proof_name == cls.name_of(topic)

    @classmethod
    def prove(cls, topic: str) -> tuple[bool, str, str, float] | None:
        """(ok, proof name, message, ms) for a rule topic or CNF; None for any other topic."""
        began = time.perf_counter()
        if topic == "Conjunctive normal form":
            ok, msg = prove_cnf()
            return ok, cls.name_of(topic), msg, (time.perf_counter() - began) * 1000.0
        rule = RULES.get(str(topic))
        if rule is None:
            return None
        broken = counter_row(rule.premises, rule.conclusion)
        refuted = counter_row(rule.fallacy_premises, rule.fallacy_conclusion)
        size = len(rows_of(set().union(*(atoms_of(f) for f in [*rule.premises, rule.conclusion]))))
        if broken is not None:
            msg = f"{topic} fails on the row {broken}"
        elif refuted is None:
            msg = f"{topic} holds, but so does {rule.fallacy}: the check cannot tell them apart"
        else:
            msg = (f"{topic} holds on all {size} rows of its truth table; {rule.fallacy} fails on "
                   f"{ {k: ('T' if v else 'F') for k, v in refuted.items()} }")
        return broken is None and refuted is not None, cls.name_of(topic), msg, (time.perf_counter() - began) * 1000.0

    @classmethod
    def source(cls, proof_name: str) -> str:
        """Intention: the proof as training text — the rule and its fallacy, and the check that ran."""
        for topic in [*RULES, "Conjunctive normal form"]:
            if cls.name_of(topic) == proof_name:
                said = RULES[topic].text() if topic in RULES else "to_cnf(f) is in CNF and equals f on every row"
                code = inspect.getsource(prove_cnf) if topic not in RULES else inspect.getsource(counter_row)
                return said + "\n\n" + code
        return ""
