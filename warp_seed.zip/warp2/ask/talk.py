# WARP2/warp2/ask/talk.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/talk.py
#  Used by   : warp2/ask/window.py, one call a turn.
#  Uses      : warp2/ask/{knowing,thread,personality}.py,
#              warp2/projects/capabilities.py, warp2/chat_learning/turns.py
#              (every turn kept for the Eye), warp2/chat_learning/speaker.py
#              (who speaks, when `ask` is one). A model is optional and is passed
#              in as `ask`. warp2/decide/{ladder,turn_kind}.py when it is
#              handed the machine's decisions.
#  Description:
#    One turn of a conversation. Answers out of the store, lets a model talk
#    around that when there is one, and turns anything he settles on into a
#    proposal he has to approve before it is written.
#  User intention (Andrew, 2026-09-07):
#    "We need to be able to talk and get feedback about projects and talk about
#    what and how I want things... and if it cant do something that needs to
#    become a project. We need to have a evolveing system of what it can and
#    cant do. Through that project system. We also need a way it should act and
#    a evolving personality system that adapts to the user."
#  Principles: Clean — a model may phrase, suggest and argue, and may never
#    write. What is stored is what Andrew approved, word for word.
# ============================================================================
from __future__ import annotations

import re

from warp2.ask.personality import Personality
from warp2.decide import turn_kind
from warp2.decide.ladder import ACTION_MODEL, Ladder
from warp2.projects.capabilities import Capabilities
from warp2.record.swallowed import noted

# What a proposal can be. Intention: a small closed list, because the point of
# a proposal is that a person knows exactly what pressing yes does.
INTENTION = "intention"     # this is what that thing is for
PROJECT = "project"         # start this
COMMENT = "comment"         # this is what I think about that thing
IMAGE = "image"             # make me a picture of this using a project
VIDEO = "video"             # make me a video clip of this using a project
PROPOSALS = (INTENTION, PROJECT, COMMENT, IMAGE, VIDEO)

# How a model must come back if it wants to propose. Intention: one line, at the
# end, in a shape that cannot be confused with prose. Anything else it writes is
# conversation and is never stored.
PROPOSE = re.compile(r"(?m)^\s*PROPOSE:\s*(\w+)\s*\|\s*([^|]*)\|\s*(.+?)\s*$")

# What a person types when they mean it themselves, with no model involved.
PLAINLY = re.compile(
    r"(?i)^\s*(?:make|set)\s+(?:the\s+)?intention\s+(?:for|of)\s+(.+?)\s+(?:to|as)\s+(.+)$")

PLAINLY_IMAGE = re.compile(
    r"(?i)^\s*(?:(?:can|could|would|will)\s+you\s+)?(?:please\s+)?(?:make|create|generate|render|show|draw|paint)\s+(?:me\s+)?(?:a|an|the)?\s*(?:picture|image|drawing|photo)\s+(?:of\s+)?(.+?)(?:\s+(?:for\s+me|please))*[.\?!]*$")

PLAINLY_VIDEO = re.compile(
    r"(?i)^\s*(?:(?:can|could|would|will)\s+you\s+)?(?:please\s+)?(?:make|create|generate|render|show|animate)\s+(?:me\s+)?(?:a|an|the)?\s*(?:video|clip|animation)\s+(?:of|showing\s+)?(.+?)(?:\s+(?:for\s+me|please))*[.\?!]*$")

def detect_image_request(text: str) -> str | None:
    """Robustly detect and extract image subject from natural language requests."""
    raw = str(text or "").strip().strip(".?!").strip()
    cleaned = re.sub(r"^(?:can\s+you|could\s+you|would\s+you|will\s+you|please|i\s+want(?:\s+you\s+to)?|i\s+would\s+like(?:\s+you\s+to)?|let\'?s\s+have\s+you)\s+", "", raw, flags=re.I).strip()
    cleaned = re.sub(r"^(?:please\s+)?(?:try\s+to\s+)?", "", cleaned, flags=re.I).strip()

    m1 = re.match(r"^(?:make|create|generate|render|show|draw|paint)\s+(?:me\s+)?(?:a|an|the)?\s*(?:picture|image|drawing|photo|portrait|sketch|illustration)\s+(?:of\s+)?(.+?)(?:\s+(?:for\s+me|please))*$", cleaned, flags=re.I)
    if m1:
        return m1.group(1).strip()
    m2 = re.match(r"^(?:draw|paint|sketch)\s+(?:me\s+)?(?:a|an|the\s+)?(.+?)(?:\s+(?:for\s+me|please))*$", cleaned, flags=re.I)
    if m2:
        return m2.group(1).strip()
    m3 = re.match(r"^(?:a|an|the)?\s*(?:picture|image|photo|drawing|illustration)\s+of\s+(.+?)(?:\s+(?:for\s+me|please))*$", cleaned, flags=re.I)
    if m3:
        return m3.group(1).strip()
    m4 = re.match(r"^(?:make|create|generate|render)\s+(?:me\s+)?(?:a|an|the\s+)?(.+?)\s+(?:picture|image|photo|drawing)(?:\s+(?:for\s+me|please))*$", cleaned, flags=re.I)
    if m4:
        return m4.group(1).strip()
    m5 = PLAINLY_IMAGE.match(text)
    if m5:
        return m5.group(1).strip()
    return None

def detect_video_request(text: str) -> str | None:
    """Robustly detect and extract video subject from natural language requests."""
    raw = str(text or "").strip().strip(".?!").strip()
    cleaned = re.sub(r"^(?:can\s+you|could\s+you|would\s+you|will\s+you|please|i\s+want(?:\s+you\s+to)?|i\s+would\s+like(?:\s+you\s+to)?|let\'?s\s+have\s+you)\s+", "", raw, flags=re.I).strip()
    cleaned = re.sub(r"^(?:please\s+)?(?:try\s+to\s+)?", "", cleaned, flags=re.I).strip()

    m1 = re.match(r"^(?:make|create|generate|render|show|animate)\s+(?:me\s+)?(?:a|an|the)?\s*(?:video|clip|animation|movie)\s+(?:of|showing\s+)?(.+?)(?:\s+(?:for\s+me|please))*$", cleaned, flags=re.I)
    if m1:
        return m1.group(1).strip()
    m2 = re.match(r"^(?:animate)\s+(?:me\s+)?(?:a|an|the\s+)?(.+?)(?:\s+(?:for\s+me|please))*$", cleaned, flags=re.I)
    if m2:
        return m2.group(1).strip()
    m3 = re.match(r"^(?:a|an|the)?\s*(?:video|clip|animation)\s+of\s+(.+?)(?:\s+(?:for\s+me|please))*$", cleaned, flags=re.I)
    if m3:
        return m3.group(1).strip()
    m4 = re.match(r"^(?:make|create|generate|render)\s+(?:me\s+)?(?:a|an|the\s+)?(.+?)\s+(?:video|clip|animation)(?:\s+(?:for\s+me|please))*$", cleaned, flags=re.I)
    if m4:
        return m4.group(1).strip()
    m5 = PLAINLY_VIDEO.match(text)
    if m5:
        return m5.group(1).strip()
    return None

PLAINLY_PROJECT = re.compile(
    r"(?i)^\s*(?:start|create|make|open)\s+(?:a\s+)?(?:new\s+)?project\s+(?:called\s+|named\s+)?([a-zA-Z0-9_\-]+)(?:\s+(?:for|to|with intention)\s+(.+))?$")

HOW_TO_PROPOSE = """CAPABILITY & PROPOSAL RULES:
1. Speak naturally to Andrew in English first. Be helpful, direct, concise, and clear.
2. NEVER pretend to have created an image, executed a test, or performed any action. You are a conversational voice that proposes.
3. If Andrew asks for an image or picture, propose using centering_image:
   PROPOSE: image | project:centering_image | <the visual subject>
4. If Andrew asks for a video or animation, propose using centering_image:
   PROPOSE: video | project:centering_image | <the motion subject>
5. If Andrew makes a comment, request, or suggestion to change, adapt, or improve the GUI or window interface (such as fonts, scaling, layout, styling, controls, buttons, or language), acknowledge it and propose storing it as an intention:
   PROPOSE: intention | warp2/ask/window.py | <Andrew's desired change>
6. If Andrew wants to change, fix, or improve an existing project file or module, propose:
   PROPOSE: intention | <the target file or project> | <Andrew's desired change>
7. If Andrew asks for something that NO project currently supports or asks to create a new thing/tool/capability, propose creating a project for it:
   PROPOSE: project | <suggested_project_slug> | <clear intention for the project>
8. If Andrew has settled on what a project or area is for, propose:
   PROPOSE: intention | <the thing it is about> | <the sentence to store>
9. If he is just chatting, asking a question, or discussing, answer conversationally and do NOT propose.
10. If you propose, place the proposal as the very last line: PROPOSE: <kind> | <about> | <words>."""


class Talk:
    """One turn: what the facts say, what a model adds, and what is proposed.

    Intention: THE MODEL IS A VOICE, NOT A HAND. It reads what is true, talks
    about it, and can offer a sentence — and the sentence only becomes a fact
    when Andrew presses yes. Nothing here writes to the store at all.
    """

    def __init__(self, knowing, ask=None, capabilities=None, personality=None,
                 decisions=None, state=None) -> None:
        """Intention: hold what a turn reads from (knowing, capabilities, personality) and the
        turn-kind ladder when decisions are given.
        """
        from pathlib import Path
        self.knowing = knowing
        self.state = Path(state) if state is not None else (
            Path(getattr(knowing, "state", "")) if getattr(knowing, "state", None) else None
        )
        # Intention: THE SMALLEST RUNG FIRST (Andrew, 2026-09-18). The keyword
        # rules below are the automation; the turn_kind action model sits
        # under the language model and answers alone once its record says it
        # can. Without the machine's decisions there is no action model, and
        # nothing is recorded.
        self.turns = Ladder(decisions.get(turn_kind.POINT, turn_kind.CHOICES)) if decisions is not None else None
        self.turn_open = None
        self._turn = None
        self.ask = ask
        self.capabilities = capabilities if capabilities is not None else (
            Capabilities(knowing.store, knowing.projects) if hasattr(knowing, "projects") and knowing.projects else None
        )
        home = self.state or getattr(knowing, "state", None)
        self.personality = personality if personality is not None else (
            Personality(home) if home else None
        )

    # Intention: FACTS FIRST, ALWAYS. Whatever else happens in a turn, anything
    # the store can answer is answered from the store, so the window is never
    # wrong about his own work even when a model is talking.
    def reply(self, said: str, history=()) -> dict:
        """Answer one thing he said, and keep what kind of turn it was open.

        Intention: whichever rung answered, the turn stays open until he says
        yes or no to what was offered, or talks on — that is the outcome the
        action model learns from.
        """
        self.turn_heard("talk")
        self._turn = None
        answer = self._reply(said, history)
        self._keep_for_the_eye(said, answer)
        if self.turns is None or not str(said or "").strip() or answer.get("reset"):
            return answer
        if self._turn is None:
            # Intention: an automation answered; the action model is asked
            # beside it, so it learns what the automation already knows.
            kind = (answer.get("proposes") or {}).get("kind") or "talk"
            self._turn = self.turns.climb(turn_kind.features(said), automation=kind)
        self.turn_open = self._turn["id"]
        answer.setdefault("rung", self._turn["rung"])
        return answer

    def _keep_for_the_eye(self, said: str, answer: dict) -> None:
        """Intention: every real turn is kept for the chat's learning (warp2/chat_learning), where the models act it out again and the Eye learns from it — one line written, nothing more in the turn; with no state folder nothing is written."""
        home = self.state or getattr(self.knowing, "state", None)
        if home and not answer.get("reset"):
            from warp2.chat_learning.turns import ChatTurns
            ChatTurns(home).add(said, answer.get("said", ""))

    def turn_heard(self, kind: str) -> None:
        """Intention: what the last turn turned out to be; the action model learns it."""
        if self.turns is not None and self.turn_open:
            self.turns.settle(self.turn_open, kind if kind in turn_kind.CHOICES else "talk")
        self.turn_open = None

    def _reply(self, said: str, history=()) -> dict:
        """Answer one thing he said: automations, then the action model, then a model."""
        said = str(said or "").strip()
        if not said:
            return {"said": "", "grounds": "", "proposes": None}

        # Update personality observation with the user's input
        if self.personality:
            self.personality.observe("andrew", said)

        # 0. Conversational reset
        if said.lower() in ("/reset", "reset", "/clear", "clear conversation"):
            return {"said": "Conversation reset.", "grounds": "", "proposes": None, "reset": True}

        # 0a. Instant greetings & check-ins fast-path (<5ms)
        lower_said = said.lower()
        cleaned_words = re.sub(r"[^\w\s]", "", lower_said).strip()
        if cleaned_words in ("hello", "hi", "hey", "howdy", "good morning", "good afternoon", "good evening", "greetings"):
            return {
                "said": "Hello! I'm here. How can I help with your projects or work today?",
                "grounds": "",
                "proposes": None,
            }
        if cleaned_words in ("how are you", "how are things", "whats up", "what's up", "status"):
            return {
                "said": "I'm running well and ready. Ask about any project, request an image, or tell me what to build.",
                "grounds": "",
                "proposes": None,
            }

        # 0b. Direct instruction: make an image or video
        img_subj = detect_image_request(said)
        if img_subj and not self.ask:
            return {"said": f"I'm on it! I've queued generating a picture of '{img_subj}'. The background engine is working on it until it passes.",
                    "grounds": self.knowing.say("centering_image") if hasattr(self.knowing, "say") else "",
                    "proposes": {"kind": IMAGE, "about": "project:centering_image",
                                 "words": img_subj,
                                 "why": "you asked for a picture"}}

        vid_subj = detect_video_request(said)
        if vid_subj and not self.ask:
            return {"said": f"I'm on it! I've queued generating an animated video of '{vid_subj}'.",
                    "grounds": self.knowing.say("centering_image") if hasattr(self.knowing, "say") else "",
                    "proposes": {"kind": VIDEO, "about": "project:centering_image",
                                 "words": vid_subj,
                                 "why": "you asked for a video"}}

        # 0b2. Image status or progress inquiry
        img_inquiry = self._handle_image_inquiry(said)
        if img_inquiry is not None:
            return img_inquiry

        # 0c. General UI / interface or personality desired change recognition
        if any(term in lower_said for term in ("speak in", "talk in", "reply in")):
            target = "warp2/ask/personality.py"
            return {
                "said": f"I see your desired change to communicate in that language: \"{said}\". Adapting conversational language.",
                "grounds": "personality language intention",
                "proposes": {"kind": INTENTION, "about": target,
                             "words": said,
                             "why": "you asked to adapt conversational language"},
            }

        ui_keywords = (
            "font", "text", "size", "color", "colour", "theme", "palette",
            "window", "gui", "ui", "button", "layout", "language", "lauangue",
            "locale", "interface", "spanish", "french", "german", "italian", "all of it"
        )
        if any(k in lower_said for k in ui_keywords) and any(w in lower_said for w in ("change", "make", "set", "turn", "switch", "bigger", "smaller", "increase", "decrease", "reduce", "larger", "add", "different", "scale", "zoom")):
            return {
                "said": f"I see your desired change for the interface: \"{said}\". Queueing the change now.",
                "grounds": "interface modification intention",
                "proposes": {"kind": INTENTION, "about": "warp2/ask/window.py",
                             "words": said,
                             "why": "you asked to change the interface"},
            }

        # 1. Direct instruction: set intention
        direct_intention = PLAINLY.match(said)
        if direct_intention:
            about = self.knowing.find(direct_intention.group(1)) or direct_intention.group(1).strip()
            return {"said": f"Stored intention for {about}: \"{direct_intention.group(2).strip()}\".",
                    "grounds": self.knowing.say(direct_intention.group(1)),
                    "proposes": {"kind": INTENTION, "about": about,
                                 "words": direct_intention.group(2).strip(),
                                 "why": "you said it in as many words"}}


        # 3. Direct instruction: start project
        direct_project = PLAINLY_PROJECT.match(said)
        if direct_project:
            proj_name = direct_project.group(1).strip()
            proj_intent = (direct_project.group(2) or proj_name).strip()
            return {"said": f"Started project '{proj_name}' for '{proj_intent}'. Work has been queued.",
                    "grounds": "",
                    "proposes": {"kind": PROJECT, "about": proj_name,
                                 "words": proj_intent,
                                 "why": "you asked to start a project"}}

        grounds = self.knowing.say(said) if hasattr(self.knowing, "say") else ""
        small = self._action_model(said, grounds)
        if small:
            return small
        if self.ask is None:
            # Check capabilities directly when no model is available
            if self.capabilities:
                match = self.capabilities.match(said)
                if not match["supported"] and match.get("is_action") and "suggested_project" in match:
                    return {
                        "said": f"I cannot do that yet. None of our current projects provide that capability.\n"
                                f"Queueing project:{match['suggested_project']} to build it.",
                        "grounds": grounds,
                        "proposes": {"kind": PROJECT, "about": match["suggested_project"],
                                     "words": match["suggested_intention"],
                                     "why": match["reason"]},
                    }
            return {"said": grounds or self._nothing_known(),
                    "grounds": grounds, "proposes": None}

        try:
            # Intention: a speaker that can choose who answers (the chat's
            # learning, warp2/chat_learning/speaker.py) is told what was said.
            speak = getattr(self.ask, "speak", None)
            prompt = self._prompt(said, grounds, history)
            spoke = str((speak(prompt, said) if speak is not None else self.ask(prompt)) or "")
            if not spoke.strip() and grounds:
                return {"said": grounds, "grounds": grounds, "proposes": None}
        except Exception as exc:
            # Intention: HE STILL GETS WHAT THE MACHINE KNOWS, AND IS TOLD THE
            # MODEL FELL OVER. Swallowing the failure made a dead model look
            # like a model with nothing to add (found 2026-09-18: the test that
            # guards this had been failing since 09-15).
            fell = f"(the model could not answer: {type(exc).__name__}: {exc})"
            body = grounds or self._nothing_known()
            return {"said": f"{body}\n\n{fell}", "grounds": grounds, "proposes": None}
        cleaned = self._without_the_proposal(spoke)
        proposed = self._proposed(spoke)
        if not cleaned and proposed:
            kind = proposed.get("kind", "task")
            words = proposed.get("words", "")
            if kind == IMAGE:
                cleaned = f"I've queued generating a picture of '{words}'."
            elif kind == VIDEO:
                cleaned = f"I've queued generating a video of '{words}'."
            elif kind == PROJECT:
                cleaned = f"I've started project '{proposed.get('about', words)}'."
            elif kind == INTENTION:
                cleaned = f"I've noted that intention for {proposed.get('about', 'the interface')}: '{words}'."
            else:
                cleaned = f"Understood. I've noted: '{words}'."
        elif not cleaned:
            if grounds and self._is_factual_project_inquiry(said):
                cleaned = grounds
            else:
                cleaned = "I'm here. How can I help with your projects or work?"
        if self._turn is not None:
            # Intention: the bigger rung's answer is what the smaller one is
            # measured against.
            self.turns.bigger_said(self._turn["id"], (proposed or {}).get("kind") or "talk")
        return {"said": cleaned, "grounds": grounds, "proposes": proposed}

    # -- the action model's rung ---------------------------------------------

    def _action_model(self, said: str, grounds: str):
        """The action model's answer when it has earned it, else None.

        Intention: it only speaks for kinds whose target it can work out
        without reading — a picture or clip goes to centering_image, a comment
        or intention to the thing it names. For anything else, and whenever it
        has not taken over, the language model is asked as before.
        """
        if self.turns is None:
            return None
        self._turn = self.turns.climb(turn_kind.features(said))
        if self._turn["rung"] != ACTION_MODEL:
            return None
        offered = self._offer(self._turn["choice"], said)
        if offered is None:
            self._turn["rung"] = None
            return None
        return {"said": f"I will offer this as {offered['kind']} on {offered['about']}, if you say yes.",
                "grounds": grounds, "proposes": offered}

    def _offer(self, kind: str, said: str):
        """Intention: the proposal for a kind, or None when its target is not known."""
        if kind in (IMAGE, VIDEO):
            return {"kind": kind, "about": "project:centering_image",
                    "words": turn_kind.subject(said), "why": "the action model read it as that"}
        if kind in (COMMENT, INTENTION):
            about = self.knowing.find(said) if hasattr(self.knowing, "find") else None
            if about:
                return {"kind": kind, "about": about, "words": said,
                        "why": "the action model read it as that"}
        return None

    # -- what the model is given ---------------------------------------------

    def _prompt(self, said: str, grounds: str, history) -> str:
        """Intention: build the prompt for the model: the persona, what is true right now, the grounds
        and the recent talk.
        """
        overview = self.knowing.overview()
        lines = [
            "You are the warp talking with Andrew, who built you.",
            "",
            self.personality.guidance() if self.personality else "Answer in plain, simple words. Short sentences.",
            "",
            "You cannot change anything yourself directly without his approval. You propose actions, and your conversation turns become user intentions that guide both live UI adjustments and continuous background improvements.",
            "",
            "What is true right now:",
        ]
        for row in overview["projects"]:
            lines.append(f"  {row['name']}: {row['built']} of {row['areas']} parts built."
                         + (f" For: {row['intention']}" if row["intention"] else ""))
        lines.append(f"  {overview['open_work']} pieces of work are open.")
        home = self.state or getattr(self.knowing, "state", None)
        if home:
            try:
                from warp2.ask.image_asks import ImageAsks
                asks = ImageAsks(home).rows(limit=5)
                if asks:
                    lines.append("  Active image requests in work queue:")
                    for a in asks:
                        lines.append(f"    - '{a.get('subject')}': status is {a.get('status')}")
            except Exception as exc:
                noted("warp2/ask/talk.py:Talk._prompt", exc)
        if self.capabilities:
            lines += ["", "What this machine can currently do across projects:", self.capabilities.summary()]
        if grounds:
            lines += ["", "About what he just mentioned:", grounds]
        recent = [turn for turn in list(history)[-8:] if turn.get("said")]
        if recent:
            lines += ["", "How the conversation has gone:"]
            for turn in recent:
                lines.append(f"  {turn.get('who', '?')}: {turn['said'][:300]}")
        lines += ["", f"He now says: {said}", "", HOW_TO_PROPOSE]
        return "\n".join(lines)

    def _handle_image_inquiry(self, said: str) -> dict | None:
        """Answer direct questions about open or completed image requests from facts."""
        raw = str(said or "").strip().lower()
        has_img_word = any(w in raw for w in ("image", "picture", "photo", "drawing", "render"))
        has_status_word = any(w in raw for w in (
            "worked on", "working on", "is it done", "is it finished", "is it ready",
            "finished", "ready", "still being", "where is", "how is", "how are",
            "see it", "seen it", "look like", "looking", "haven't seen", "havent seen",
            "status of", "status", "progress", "before", "asked for"
        ))
        if not (has_img_word and has_status_word):
            return None

        # If the phrase specifically names an existing project (e.g., "centering image", "behemoth eye")
        # let the project facts answer rather than treating it as an image ask inquiry.
        if hasattr(self.knowing, "projects") and self.knowing.projects:
            for p_name in self.knowing.projects.names():
                p_slug = self.knowing.projects.home(p_name).name.lower()
                if p_slug.replace("_", " ") in raw or p_name.lower() in raw:
                    return None

        subj_target = ""
        m = re.search(r"(?:about|of|on|for)?\s*(?:the|a|an)?\s*([a-zA-Z0-9_\-]+)\s*(?:image|picture|photo|drawing)", raw)
        if m and m.group(1) not in ("this", "that", "my", "the", "an", "a", "one", "new"):
            subj_target = m.group(1).strip()
        if not subj_target:
            m2 = re.search(r"(?:image|picture|photo|drawing)\s+(?:of|for)?\s*(?:the|a|an)?\s*([a-zA-Z0-9_\-]+)", raw)
            if m2 and m2.group(1) not in ("this", "that", "my", "the", "an", "a", "one", "new"):
                subj_target = m2.group(1).strip()

        home = self.state or getattr(self.knowing, "state", None)
        if not home:
            return None

        from warp2.ask.image_asks import ImageAsks
        asks = ImageAsks(home).rows(limit=10)
        match = None
        if subj_target:
            for a in asks:
                if subj_target in str(a.get("subject", "")).lower():
                    match = a
                    break
        if not match and asks:
            match = next((a for a in asks if a.get("status") in ("rendering", "pending")), asks[0])

        if not match:
            return {
                "said": f"I don't have an active image request for '{subj_target or 'that'}' in the queue right now. You can ask me to make one by typing 'make an image of {subj_target or 'something'}' or using the Pictures tab.",
                "grounds": "", "proposes": None
            }

        subject = match.get("subject", "")
        status = match.get("status", "")
        img_p = match.get("image_path", "")
        ask_id = match.get("id", "")

        round_info = ""
        req_file = home / "centering_image" / "inbox" / f"{ask_id}.json"
        if req_file.is_file():
            try:
                import json
                data = json.loads(req_file.read_text(encoding="utf-8"))
                resume = data.get("resume") or {}
                part_st = resume.get("part_state") or {}
                r_num = part_st.get("round") or resume.get("round")
                if r_num:
                    round_info = f" (round {r_num})"
            except Exception:  # Intention: the inbox file may be mid-write; the round number is only an extra on the reply.
                pass

        from pathlib import Path
        if status == "rendering":
            reply_msg = (
                f"Yes! The picture of '{subject}' is actively being worked on! "
                f"It is currently rendering in the background{round_info}. "
                "The engine continuously refines subject contours, contrast, and color balance until the vision reader scores pass."
            )
            if img_p and Path(img_p).is_file():
                reply_msg += (
                    f"\n\nYou can see the latest in-progress preview on disk at:\n{img_p}\n"
                    "It is also shown in the Pictures tab under 'Pictures asked for' and 'Needs your eye', where you can double-click it to inspect."
                )
            else:
                reply_msg += "\nYou can track its live progress in the Pictures tab under 'Pictures asked for'."
            return {"said": reply_msg, "grounds": f"image_ask:{subject} ({status})", "proposes": None}
        elif status == "completed":
            reply_msg = f"The picture of '{subject}' is finished!"
            if img_p and Path(img_p).is_file():
                reply_msg += f"\nIt is saved at: {img_p}. You can view it in the Pictures tab or Gallery."
            return {"said": reply_msg, "grounds": f"image_ask:{subject} (completed)", "proposes": None}
        elif status == "pending":
            return {
                "said": f"Your request for a picture of '{subject}' is waiting in the queue and will begin rendering on the next pass.",
                "grounds": f"image_ask:{subject} (pending)", "proposes": None
            }
        return None

    @staticmethod
    def _is_factual_project_inquiry(said: str) -> bool:
        """True only if the user specifically asked what a project is or does."""
        lower = str(said or "").lower().strip()
        return any(q in lower for q in ("what is", "tell me about", "describe", "explain", "how does", "what does", "show me project"))

    # -- reading what came back ----------------------------------------------

    @staticmethod
    def _without_the_proposal(spoke: str) -> str:
        """Intention: the model's words with any PROPOSE line taken out, so the person sees only the talk."""
        return PROPOSE.sub("", spoke).strip()

    @staticmethod
    def _proposed(spoke: str):
        """Intention: the PROPOSE line in the model's words as {kind, about, words, why}, or None if
        there is none or it is not allowed.
        """
        found = PROPOSE.search(spoke or "")
        if not found:
            return None
        kind, about, words = (part.strip() for part in found.groups())
        if kind.lower() not in PROPOSALS or not words:
            return None
        return {"kind": kind.lower(), "about": about, "words": words,
                "why": "the warp suggested it"}

    @staticmethod
    def _nothing_known() -> str:
        """Intention: the answer given when nothing is known about what was said and no model can add to it."""
        return ("I do not know anything about that yet. Name a project, or tell "
                "me what you want and I will keep it.")
