# WARP2/warp2/ask/hub_pictures.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/hub_pictures.py
#  Used by   : warp2/ask/picture_datasets.py (finding and reading labelled
#              picture datasets for a subject).
#  Uses      : (stdlib) json, re, urllib.
#  Description:
#    The Hugging Face hub, read for labelled pictures:
#      * datasets_for(subject) — picture-labelling datasets whose search
#        matches the subject, most downloaded first;
#      * class_of(dataset, subject) — where in a dataset the subject is a
#        label of its own (config, split, label column, label number), or
#        None: a dataset only matches when one of its label names IS the
#        subject (so "cat" never takes "cattle" or "cataract"), with all its
#        label names;
#      * rows(...) — one page of a dataset's rows: (row number, label,
#        picture address).
#    Read through the public dataset viewer; nothing is signed in.
#  User intention (Andrew, 2026-10-03): "it should have pulled datasets why has
#    it not"; a dataset's label is enough to train on, a reader checks a sample.
# ============================================================================
"""Labelled picture datasets on the Hugging Face hub."""
from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request

HUB = "https://huggingface.co/api/datasets"
VIEWER = "https://datasets-server.huggingface.co"
USER_AGENT = "WARP2 picture datasets (research)"
# Intention: the most rows the dataset viewer gives in one page (its own limit).
PAGE = 100


def _get(url: str, timeout: float) -> dict | list:
    """Intention: one JSON answer, or an error raised for the caller to note."""
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=timeout) as answer:
        return json.loads(answer.read().decode("utf-8"))


def _same(name: str, subject: str) -> bool:
    """Intention: a label name is the subject when its words are the subject's words, one-or-many alike ("cat", "cats", "Cat")."""
    words = lambda text: [w[:-1] if len(w) > 3 and w.endswith("s") else w
                          for w in re.findall(r"[a-z0-9]+", str(text).lower())]
    return bool(words(subject)) and words(name) == words(subject)


def datasets_for(subject: str, timeout: float = 20.0) -> list:
    """Intention: picture-labelling dataset names for a subject, most downloaded first."""
    # Keep a broad candidate pool.  The viewer's label inspection below is
    # the authoritative filter; a short hub result list can exhaust on a few
    # poor datasets before we have tried the other useful sources.
    query = urllib.parse.urlencode({"search": subject, "filter": "task_categories:image-classification",
                                    "sort": "downloads", "direction": "-1", "limit": "100"})
    return [str(d.get("id")) for d in _get(f"{HUB}?{query}", timeout) if d.get("id")]


def class_of(dataset: str, subject: str, timeout: float = 20.0) -> dict | None:
    """Where the subject is a label of its own in this dataset: {config, split, column, label, names, rows}, or None.

    Intention: `names` are all the dataset's label names, so its other
    pictures can be kept under their own labels; `rows` is how many rows the
    split has (0 when the viewer does not say), so pages can be read spread
    across it.
    """
    info = _get(f"{VIEWER}/info?dataset={urllib.parse.quote(dataset)}", timeout)
    for config, about in (info.get("dataset_info") or {}).items():
        features = about.get("features") or {}
        if not any((f or {}).get("_type") == "Image" for f in features.values() if isinstance(f, dict)):
            continue
        splits = list((about.get("splits") or {}).keys()) or ["train"]
        split = "train" if "train" in splits else splits[0]
        for column, feature in features.items():
            names = (feature or {}).get("names") if isinstance(feature, dict) else None
            if (feature or {}).get("_type") == "ClassLabel" and names:
                for number, name in enumerate(names):
                    if _same(name, subject):
                        rows = int(((about.get("splits") or {}).get(split) or {}).get("num_examples") or 0)
                        return {"config": config, "split": split, "column": column, "label": number,
                                "names": [str(n) for n in names], "rows": rows}
    return None


def rows(dataset: str, where: dict, offset: int, timeout: float = 30.0) -> list:
    """One page of rows from `offset`: [(row number, label, picture address)]."""
    query = urllib.parse.urlencode({"dataset": dataset, "config": where["config"], "split": where["split"],
                                    "offset": int(offset), "length": PAGE})
    page = _get(f"{VIEWER}/rows?{query}", timeout)
    out = []
    for item in page.get("rows") or []:
        row = item.get("row") or {}
        picture = next((v for v in row.values() if isinstance(v, dict) and v.get("src")), None)
        if picture:
            out.append((int(item.get("row_idx", 0)), row.get(where["column"]), str(picture["src"])))
    return out


def fetch(address: str, timeout: float = 30.0) -> bytes:
    """Intention: a picture's bytes."""
    request = urllib.request.Request(address, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=timeout) as answer:
        return answer.read()
