# WARP2/warp2/ask/concept_worth.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/concept_worth.py
#  Used by   : warp2/work/side/picture_concepts.py (measures and writes the
#              report), warp2/ask/picture_round.py (its `concepts` part
#              measures when the pictures changed; its teach and side parts
#              skip concepts the report shows learned nothing).
#  Uses      : warp2/train/ranks.py (rank score, beats chance); the picture
#              model's Eye (readings); warp2/ask/reference.py (usable);
#              (stdlib) hashlib, json, time, pathlib.
#  Description:
#    Which of the Eye's picture concepts have learned anything. A concept is
#    named on some reference pictures (their tags and what the readers said
#    was in them) and not on others. Each picture is read by the Eye, and a
#    concept that has learned something fires more on the pictures it was
#    named on than on the others — measured as a rank score with its
#    standard error (warp2/train/ranks.py). A concept named on every picture
#    tells nothing apart, so it carries no information either.
#  User intention (Andrew, 2026-10-03): "These questions should be answered by
#    testing what is best" — whether the tag-made concepts are worth their
#    training. Andrew, 2026-09-27: "always keep networks for each concept" —
#    nothing here removes a network; a concept that learned nothing is only
#    not given the side part's time.
# ============================================================================
"""Which picture concepts have learned anything."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

from warp2.train.ranks import beats_chance, rank_score

REPORT = Path("reports") / "picture_concepts.json"
PER_CLASS = 64


def clean(name) -> str:
    """Intention: a concept name as the picture model makes it (lower case, single spaces)."""
    return " ".join(str(name or "").lower().split())


def named_on(reference: dict) -> set:
    """Intention: the concepts a reference picture was named with — its tags and what the readers said was in it (above a quarter, as teaching uses)."""
    names = {clean(t) for t in (reference.get("tags") or []) if isinstance(t, str) and clean(t)}
    names |= {clean(c) for c, s in (reference.get("concept_scores") or {}).items() if float(s or 0.0) > 0.25}
    return names


def measure(model, references: list, progress=None, stopped=None) -> dict:
    """Every concept named on these pictures: how it ranks them, read by the Eye now.

    At most 64 labelled positives and 64 negatives per concept, picked by
    stable content/id hashes. This diagnostic never removes training images.
    Universal labels need no inference: their lack of negatives is exact.
    """
    named = [(ref, named_on(ref)) for ref in references]
    known = set(model.eye.concepts.pairs)
    names = sorted({n for _, ns in named for n in ns} & known)
    scored = {n: [] for n in names}
    populations, plan = {}, {}
    ordered = sorted(range(len(named)), key=lambda i: hashlib.sha256(str(
        references[i].get("digest") or references[i].get("id") or references[i]["path"]
    ).encode("utf-8")).digest())
    for n in names:
        positive = [i for i in ordered if n in named[i][1]]
        negative = [i for i in ordered if n not in named[i][1]]
        populations[n] = (len(positive), len(negative))
        if not negative:
            continue
        for i in positive[:PER_CLASS] + negative[:PER_CLASS]:
            plan.setdefault(i, []).append(n)
    done, checks = 0, 0
    total_checks = sum(map(len, plan.values()))
    if progress:
        progress(done, len(plan), checks, total_checks)
    for i in sorted(plan):
        if stopped and stopped():
            raise InterruptedError("concept measurement stopped")
        ref, ns = named[i]
        taken = model._picture(ref["path"])[0]
        strengths = model.eye.readings(taken, plan[i])[0]
        for n in plan[i]:
            scored[n].append([round(float(strengths.get(n, 0.0)), 6), 1.0 if n in ns else 0.0])
        done += 1
        checks += len(plan[i])
        if progress:
            progress(done, len(plan), checks, total_checks)
    out = {}
    for n, rows in scored.items():
        said = rank_score(rows)
        positive, negative = populations[n]
        out[n] = {"named": positive, "not_named": negative, "auc": round(said["auc"], 4),
                  "se": None if said["se"] == float("inf") else round(said["se"], 4),
                  "learned": beats_chance(rows), "everywhere": negative == 0,
                  "measured_named": said["good"], "measured_not_named": said["bad"],
                  "sampled": bool(negative and len(rows) < positive + negative)}
    return out


def save(state_dir, concepts: dict, pictures: int, mark: str = "") -> Path:
    """Intention: the report written whole, with when, over how many pictures, and which ones (`mark`)."""
    path = Path(state_dir) / REPORT
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps({"at": time.time(), "pictures": pictures, "mark": mark, "concepts": concepts},
                                    ensure_ascii=False), encoding="utf-8")
    temporary.replace(path)
    return path


def learned_nothing(state_dir) -> set:
    """Concepts the last report measured as telling nothing apart: named on every picture it was read on.

    Intention: only what is certain. A concept named on every picture
    cannot tell one picture from another, however long it is taught. One
    that does not yet beat chance is reported, not skipped: few namings give
    a wide error, and skipping it would stop the teaching it may only be
    short of (what to do with those is decided from the report — Andrew,
    2026-10-03: "answered by testing what is best"). A concept with no
    report yet, or named on one picture only, is not judged.
    """
    path = Path(state_dir) / REPORT
    try:
        concepts = json.loads(path.read_text(encoding="utf-8")).get("concepts") or {}
    except (OSError, ValueError):
        return set()
    return {n for n, c in concepts.items() if c.get("everywhere") and c.get("named", 0) > 1}


def references_of(learning) -> list:
    """Intention: every reference picture that can be read now — usable, and its file there."""
    from warp2.ask.reference import usable
    return [r for r in learning._load()["references"].values()
            if usable(r) and Path(str(r.get("path", ""))).is_file()]


def mark_of(references: list) -> str:
    """Intention: which pictures, with what named on each — the same set gives the same mark."""
    rows = sorted(f"{r.get('id', '')}|{r.get('digest', '')}|{','.join(sorted(named_on(r)))}" for r in references)
    return hashlib.sha256("\n".join(rows).encode("utf-8")).hexdigest()


def is_current(state_dir, mark: str, pictures: int = 0) -> bool:
    """Whether the last report still stands for these pictures.

    Intention: exactly these pictures — or, when pictures only arrive
    (2026-10-03, measured: labelled datasets bring about two hundred a round,
    and reading every picture again each round took longer than the round),
    until there are twice as many as it was measured on. Reading doubles
    each time, so all the reading done stays within twice the last reading:
    the cost of measuring grows with the pictures, not with the rounds.
    """
    try:
        report = json.loads((Path(state_dir) / REPORT).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    if report.get("mark") == mark:
        return True
    # Intention (2026-10-04, review): only while pictures only ARRIVE — fewer
    # pictures than were measured (some removed or renamed) measures again.
    was = int(report.get("pictures") or 0)
    return 0 < was <= int(pictures) < 2 * was


def refresh(learning, model, references: list) -> dict:
    """The report measured again and saved; what it found.

    Intention: the one way the report is made, for the side step and the
    picture round alike.
    """
    from warp2.work.lane_progress import Progress
    progress = Progress(learning.state, "measure_picture_concepts", "reference image recognition")
    last = [0, 0, 0, 0]

    def tell(*counts):
        """Intention: pass the measuring counts on to the progress file and keep the last ones, so a
        failure can report them.
        """
        last[:] = counts
        progress.write(*counts)

    try:
        concepts = measure(model, references, progress=tell,
                           stopped=getattr(getattr(learning, "stop", None), "raised", None))
        save(learning.state, concepts, len(references), mark_of(references))
    except Exception as exc:
        progress.write(*last, status="failed", error=str(exc))
        raise
    progress.write(*last, status="done")
    learned = sum(1 for c in concepts.values() if c["learned"])
    everywhere = sum(1 for c in concepts.values() if c["everywhere"])
    return {"measured": len(concepts), "pictures": len(references), "learned": learned,
            "everywhere": everywhere, "not_better_than_chance": len(concepts) - learned - everywhere}
