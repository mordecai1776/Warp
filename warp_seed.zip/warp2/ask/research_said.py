# WARP2/warp2/ask/research_said.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/ask/research_said.py
#  Used by   : warp2/work/side/asked.py (the loop's turn on a search &
#              research someone asked for).
#  Uses      : stdlib pathlib.
#  Description:
#    What the thread says about one search & research: the sources asked, what
#    was found, the concepts and tags, and each found picture as a reference
#    to review — its id in the picture ledger, its reader score and verdict.
#  User intention (Andrew, 2026-09-08): "we need more options for image search
#    and research"; 2026-09-18: window actions add to the work instead of
#    acting like a trigger. Moved here from warp2/ask/window.py
#    (search_research_action) on 2026-10-09, fix 3.7 of
#    claude/warp2_fix_plan_2026_10_09.md (check B10), so the loop says it.
# ============================================================================
from __future__ import annotations

from pathlib import Path


def research_said(subject: str, res: dict) -> dict:
    """The thread turn for a search & research: {"said", "references", "reference_reviews"}."""
    items = res.get("results") or []
    lines = [f"🔎 Visual Research & Multi-Source Search: '{subject}'",
             f"Queried: {', '.join(res.get('providers_used', []))} | Found: {len(items)} reference(s)"]
    if res.get("duplicates_in_results", 0) > 0:
        lines.append(f"🛡️ Suppressed {res['duplicates_in_results']} duplicate image(s) from results.")
    concepts = res.get("concepts_discovered") or []
    if concepts:
        lines.append(f"Discovered Concepts & Training Tags ({res.get('total_tags_extracted', len(concepts))} tags): "
                     f"{', '.join(concepts[:10])}")
    lines.append("\nReference Candidates (reader-tested and kept; trained on once a reader passes it or you confirm it):")
    refs, reviews = [], []
    for idx, item in enumerate(items, 1):
        if item.get("image_path"):
            refs.append(item["image_path"])
            reviews.append(_review(subject, item))
            lines.extend(_listed(idx, item))
    return {"said": "\n".join(lines), "references": refs, "reference_reviews": reviews}


# Intention: one found picture as the window's review buttons read it; its id
# is its row in the picture ledger, so confirming it reaches a real row.
def _review(subject: str, item: dict) -> dict:
    """The review fields for one found picture."""
    path = item["image_path"]
    return {"id": item.get("id") or Path(path).stem, "subject": subject, "path": path,
            "source": item.get("source", "web"), "reader_score": item.get("reader_score"),
            "reader_verdict": item.get("reader_verdict", ""),
            "reader_observation": item.get("reader_observation", ""), "tags": item.get("tags", [])}


# Intention: one found picture as a line or two of the turn.
def _listed(idx: int, item: dict) -> list:
    """Its title, size, source and reader score; then its tags."""
    score = item.get("reader_score")
    shown = f" | 👁️ Reader: {int(score * 100)}%" if type(score) in (int, float) else ""
    size = f"{item.get('width', '')}x{item.get('height', '')}"
    lines = [f"  {idx}. [{str(item.get('source', 'source')).upper()}] {item.get('title', f'Image {idx}')} ({size}{shown})"]
    if item.get("tags"):
        lines.append(f"      🏷️ Tags: {', '.join(item['tags'][:6])}")
    return lines
