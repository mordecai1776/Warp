# WARP2/warp2/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/__init__.py
#  Used by   : every module in the tree; the test suite.
#  Uses      : nothing. Deliberately empty of logic.
#  Description:
#    The import root. It stays empty so that importing any part of WARP2 never
#    drags in the whole of it — the first tree grew a package __init__ that
#    imported six subsystems, and a broken one of them made every import fail.
#  User intention (Andrew):
#    Modular. The smallest coherent parts, and nothing loaded that was not asked
#    for.
# ============================================================================
