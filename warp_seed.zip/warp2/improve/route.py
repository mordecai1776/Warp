# WARP2/warp2/improve/route.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/route.py
#  Used by   : warp2/work/sources.py (derive: a change to the warp becomes
#              improve work instead of being dropped),
#              warp2/work/side/self_repair.py (a broken step's file is offered
#              as improve work, governing parts too).
#  Uses      : warp2/improve/home.py.
#  Description:
#    Which kind a unit of work that changes code should be. A change to any
#    part of the warp itself is `improve`: written into the self project,
#    proven in a copy of the warp, and swapped in at the next restart.
#  User intention (Andrew, 2026-09-25): "make sure that the models can improve
#    all the parts of the warp itself".
# ============================================================================
from __future__ import annotations

from warp2.improve.home import is_warp_part

IMPROVE = "improve"

# Intention: the kinds of work that change code that already exists. Building
# something new and writing a test are left as they are.
CHANGES_CODE = frozenset({"revise", "connect", "update", "split"})


def kind_for(kind: str, target) -> str:
    """Intention: `improve` for a change to a part of the warp, the kind unchanged otherwise."""
    return IMPROVE if str(kind) in CHANGES_CODE and is_warp_part(target) else str(kind)


def rerouted(item: dict) -> dict:
    """Intention: a derived item with its kind set by kind_for, and its id following its kind."""
    kind = kind_for(item.get("kind"), item.get("target"))
    if kind == item.get("kind"):
        return item
    ident = str(item.get("id") or "")
    head, _sep, rest = ident.partition(":")
    return {**item, "kind": kind, "id": f"{IMPROVE}:{rest}" if rest else f"{IMPROVE}:{ident}",
            "was": str(item.get("kind") or "")}
