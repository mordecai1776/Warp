# WARP2/warp2/improve/proving_tests.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/proving_tests.py
#  Used by   : warp2/improve/proof.py.
#  Uses      : warp2/record/guards.py (GOVERNED_PATHS), stdlib pathlib.
#  Description:
#    Which tests a new version of a warp part must pass: every test named for
#    it (test_<name>.py, in the warp's own tests and in projects/warp2_checks),
#    any test the model wrote with it, and — for a part that governs change —
#    the whole record and gate suites as well.
#  User intention (Andrew, 2026-09-25): "they just have to prove the new parts".
# ============================================================================
from __future__ import annotations

from pathlib import Path, PurePosixPath

# Intention: the suites a change to a governing part must also pass — the
# record (the pathway, lanes, locks, the stop) and the gate. A change there
# is only proven when everything that guards change still holds.
GOVERNING_SUITES = ("warp2/record/tests", "warp2/gate/tests")

# Intention: where the tests for warp parts are kept outside the warp itself.
CHECKS = "projects/warp2_checks/tests"


def named_for(root, live: str) -> list:
    """Intention: every test file in the tree named for this part, as paths from the root."""
    root = Path(root)
    stem = PurePosixPath(str(live)).stem
    found = []
    for base in (root / "warp2", root / CHECKS):
        if base.is_dir():
            found += [p.relative_to(root).as_posix() for p in base.rglob(f"test_{stem}.py")
                      if "__pycache__" not in p.parts]
    return sorted(set(found))


def governing(live: str) -> bool:
    """Intention: whether this part is one that governs change (the guard's own list)."""
    from warp2.record.guards import GOVERNED_PATHS
    low = str(live).replace("\\", "/").lower()
    return any(mark in low for mark in GOVERNED_PATHS)


def suites(root) -> list:
    """Intention: every test file in the governing suites."""
    root = Path(root)
    found = []
    for folder in GOVERNING_SUITES:
        base = root / folder
        if base.is_dir():
            found += [p.relative_to(root).as_posix() for p in base.glob("test_*.py")]
    return sorted(found)


def proving_tests(root, files: dict) -> list:
    """The tests the candidate files must pass together.

    Intention: a test the model sent with its change counts; so does every
    test already named for each part it changed; and a governing part brings
    the governing suites. Empty means nothing can prove it yet.
    """
    wanted = [path for path in files if PurePosixPath(str(path)).name.startswith("test_")]
    for path in files:
        if not PurePosixPath(str(path)).name.startswith("test_"):
            wanted += named_for(root, str(path))
            if governing(str(path)):
                wanted += suites(root)
    return sorted(set(wanted))
