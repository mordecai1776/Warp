# WARP2/warp2/improve/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/tests/__init__.py
#  Used by   : pytest, as a package.
#  Uses      : nothing.
#  Description:
#    The tests of the models improving the warp itself.
#  User intention (Andrew, 2026-09-25): "prove the new parts in a project first".
# ============================================================================
