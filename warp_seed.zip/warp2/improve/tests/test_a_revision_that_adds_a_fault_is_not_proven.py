# WARP2/warp2/improve/tests/test_a_revision_that_adds_a_fault_is_not_proven.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/tests/test_a_revision_that_adds_a_fault_is_not_proven.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/improve/proof.py (prove), warp2/builders/faults.py, warp2/work/side/self_repair.py.
#  Description:
#    The warp's own repair lane follows the same rules as every worker: a candidate file with more faults of the
#    known kinds than the live file is not proven (before any test runs), and the sentence a repair has to meet
#    says "at the cause, not by catching the error" and names the rules page.
#  User intention (Andrew, 2026-11-07 04:01): "make sure that all of the automations follow that."
# ============================================================================
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))


def test_a_candidate_with_a_new_fault_is_refused_before_the_tests(tmp_path):
    """Intention: the live file has no fault; the candidate catches an error and returns {}: not proven, why names it."""
    from warp2.improve.proof import prove
    live = ROOT / "warp2/improve/__init__.py"
    candidate = live.read_text(encoding="utf-8") + "\n\ndef read(path):\n    try:\n        return path.read_text()\n    except Exception:\n        return {}\n"
    said = prove(ROOT, {"warp2/improve/__init__.py": candidate})
    assert said["passed"] is False and "except_default" in said["why"] and "RULES_FOR_EVERY_WORKER" in said["why"]


def test_the_repair_sentence_asks_for_the_cause(tmp_path):
    """Intention: the verification sentence names the rules and forbids the crash-site patch."""
    from warp2.work.side.self_repair import SelfRepair
    offered = {}

    class _Queue:
        def offer(self, **kw):
            offered.update(kw)
    repair = SelfRepair.__new__(SelfRepair)
    repair.loop = SimpleNamespace(store=None, queue=_Queue())
    repair.shared = SimpleNamespace(tell=lambda *a, **k: None)
    repair._raw = lambda item, attr: {}
    repair._mark = lambda item, verb, before=None: None
    said = repair.offer("train_chat", {"path": "warp2/ask/talk.py", "line": 12, "function": "say"}, "KeyError: 'loss'", 1.0)
    assert said["offered"] is True
    assert "at the cause" in offered["verification"] and "RULES_FOR_EVERY_WORKER" in offered["verification"]
    assert "catching the error" in offered["verification"]
