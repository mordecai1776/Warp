# WARP2/warp2/improve/tests/test_improve.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/tests/test_improve.py
#  Used by   : pytest (run_tests.py, RUN_TESTS.bat).
#  Uses      : warp2/improve/{home,route,proving_tests,proof,promote}.py,
#              warp2/record/guards.py, warp2/work/governed.py.
#  Description:
#    A change to any warp part is improve work; the guard lets a candidate in
#    the self project through but not a trick path; a candidate is proven in
#    a copy of the warp (a good one passes, a bad one fails, the live file is
#    untouched); a proven one is swapped in at start with the old one
#    archived, and refused when the live file changed after the proof.
#  User intention (Andrew, 2026-09-25): "make sure that the models can improve
#    all the parts of the warp itself they just have to prove the new parts in
#    a project first."
# ============================================================================
from __future__ import annotations

from pathlib import Path

from warp2.improve import home, promote, route
from warp2.improve.proof import prove
from warp2.improve.proving_tests import proving_tests

PART = "warp2/demo_part.py"
TEST = "warp2/tests/test_demo_part.py"
GOOD = "def floor(n):\n    return max(1, n)\n"
BAD = "def floor(n):\n    return n\n"


def _tree(tmp_path) -> Path:
    """Intention: a tiny warp — one part and the test named for it."""
    root = tmp_path / "tree"
    (root / "warp2" / "tests").mkdir(parents=True)
    (root / "warp2" / "__init__.py").write_text("", encoding="utf-8")
    (root / "warp2" / "tests" / "__init__.py").write_text("", encoding="utf-8")
    (root / PART).write_text(GOOD, encoding="utf-8")
    (root / TEST).write_text("from warp2.demo_part import floor\n\n\ndef test_floor():\n"
                             "    assert floor(0) == 1 and floor(5) == 5\n", encoding="utf-8")
    return root


def test_a_change_to_any_warp_part_is_improve_work():
    """Intention: revise, connect, update and split of a warp part — governing ones too — become improve."""
    assert route.kind_for("revise", "warp2/record/journal.py") == "improve"
    assert route.kind_for("connect", "warp2/work/loop.py::thing") == "improve"
    assert route.kind_for("revise", "projects/game_builder/rules.py") == "revise"
    assert route.kind_for("build", "warp2/new.py") == "build"
    moved = route.rerouted({"id": "revise:warp2/record/journal.py", "kind": "revise",
                            "target": "warp2/record/journal.py"})
    assert moved["kind"] == "improve" and moved["id"] == "improve:warp2/record/journal.py"


def test_the_guard_lets_a_candidate_through_but_not_a_trick_path():
    """Intention: a governing part's candidate may be written; a path that climbs out of the self project may not."""
    import pytest
    from warp2.record.guards import Guards
    from warp2.record.pathway import Refusal
    from warp2.work.governed import governed
    assert home.candidate_of("warp2/record/journal.py") == "projects/_warp_self/warp2/record/journal.py"
    assert home.live_of("projects/_warp_self/warp2/record/journal.py") == "warp2/record/journal.py"
    assert governed("projects/_warp_self/warp2/record/journal.py") == ""
    assert governed("projects/_warp_self/../warp2/record/journal.py")
    assert not home.in_self_project("projects/_warp_self/../warp2/record/journal.py")
    guard = Guards.__new__(Guards)
    guard.governed_paths({"verb": "write_file", "target": "projects/_warp_self/warp2/record/journal.py",
                          "writes": ("projects/_warp_self/warp2/record/journal.py",)})
    with pytest.raises(Refusal):
        guard.governed_paths({"verb": "write_file", "target": "warp2/record/journal.py",
                              "writes": ("warp2/record/journal.py",)})


def test_a_candidate_is_proven_in_a_copy_and_the_live_part_is_untouched(tmp_path):
    """Intention: the good version passes, the bad one fails, and neither reaches the live file."""
    root = _tree(tmp_path)
    assert proving_tests(root, {PART: GOOD}) == [TEST]
    assert prove(root, {PART: GOOD})["passed"] is True
    failed = prove(root, {PART: BAD})
    assert failed["passed"] is False and failed["tests"] == [TEST]
    assert (root / PART).read_text(encoding="utf-8") == GOOD
    assert "nothing can prove" in prove(root, {"warp2/untested.py": GOOD})["why"]


def test_a_proven_candidate_is_swapped_in_at_start_and_the_old_one_kept(tmp_path):
    """Intention: swapped once, old file archived, the waiting list emptied; a live change after the proof refuses the swap."""
    root, state = _tree(tmp_path), tmp_path / "state"
    better = "def floor(n):\n    return n if n > 1 else 1\n"
    candidate = root / home.candidate_of(PART)
    candidate.parent.mkdir(parents=True)
    candidate.write_text(better, encoding="utf-8")
    row = promote.wait(root, state, PART, "work:improve:" + PART, [TEST])
    assert (state / "locks" / "reload.flag").is_file() and row["candidate_sha256"]
    done = promote.apply_waiting(root, state)
    assert done[0]["swapped"] is True
    assert (root / PART).read_text(encoding="utf-8") == better
    assert (root / done[0]["old_kept_at"]).read_text(encoding="utf-8") == GOOD
    assert promote.apply_waiting(root, state) == []
    promote.wait(root, state, PART)
    (root / PART).write_text(GOOD, encoding="utf-8")
    refused = promote.apply_waiting(root, state)
    assert refused[0]["swapped"] is False and "changed after the proof" in refused[0]["why"]


def test_the_loop_proves_an_improvement_and_puts_it_on_the_waiting_list(tmp_path):
    """Intention: a model's change to a warp part goes through the loop: proven, kept in the self project, waiting; the live part unchanged."""
    from warp2.work.loop import Loop
    root, state = _tree(tmp_path), tmp_path / "state"
    better = "def floor(n):\n    return n if n > 1 else 1\n"
    worker = lambda item, sliced: {"outcome": "ok",
                                   "value": {"model": "m1", "files": {PART: better}}}
    loop = Loop(root, state, run_id="improve_test", worker=worker)
    loop.queue.offer("improve:" + PART, "improve", PART,
                     verification=f"a proven change to {PART} waits for the next start", rank=0.9)
    report = loop.pass_once()
    assert report["item"] == "work:improve:" + PART
    assert report["improve"]["proof"]["passed"] is True, report["improve"]
    assert report["improve"]["waiting"] == [PART]
    assert (root / home.candidate_of(PART)).read_text(encoding="utf-8") == better
    assert (root / PART).read_text(encoding="utf-8") == GOOD
    assert report["settled"]["passed"] is True
    loop.close()
