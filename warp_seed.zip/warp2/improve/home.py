# WARP2/warp2/improve/home.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/home.py
#  Used by   : warp2/improve/{route,proof,promote}.py, warp2/record/guards.py
#              (a path in the self project is not a governed path).
#  Uses      : stdlib pathlib.
#  Description:
#    Where an improvement of the warp lives before it is swapped in: the self
#    project, projects/_warp_self/, holding each candidate at the same path it
#    will have in the tree (projects/_warp_self/warp2/work/loop.py is the
#    candidate for warp2/work/loop.py). And where the list of proven
#    candidates waiting for the restart is kept.
#  User intention (Andrew, 2026-09-25): "prove the new parts in a project first".
# ============================================================================
from __future__ import annotations

from pathlib import Path, PurePosixPath

# Intention: the self project. One folder, so a candidate is always found by
# its live path and a live path always by its candidate. Its name starts with
# "_" because the index and project adoption set such folders aside — a copy
# of warp code here is a candidate, not a project with work of its own.
SELF_PROJECT = "projects/_warp_self"


def _posix(path) -> str:
    """Intention: one spelling of a path — forward slashes, no leading ./"""
    text = str(path or "").replace("\\", "/")
    return text[2:] if text.startswith("./") else text


def is_warp_part(path) -> bool:
    """Intention: True for a file of the warp itself (under warp2/)."""
    return _posix(path).split("::", 1)[0].startswith("warp2/")


def in_self_project(path) -> bool:
    """True for a path inside the self project, relative or absolute.

    Intention: the path is normalised first, so "projects/_warp_self/../warp2/
    record/x.py" is the live governing file it really is, not a candidate.
    """
    from posixpath import normpath
    text = normpath("/" + _posix(path)).lower()
    return f"/{SELF_PROJECT}/" in text


def candidate_of(live) -> str:
    """Intention: the self-project path a candidate for this live path is written to."""
    return f"{SELF_PROJECT}/{_posix(live).split('::', 1)[0]}"


def live_of(candidate) -> str:
    """Intention: the live path a self-project candidate is for, or "" when it is not one."""
    text = _posix(candidate)
    return text[len(SELF_PROJECT) + 1:] if text.startswith(SELF_PROJECT + "/") and in_self_project(text) else ""


def waiting_file(state) -> Path:
    """Intention: the list of proven candidates waiting for the restart."""
    return Path(state) / "improve" / "waiting.jsonl"


def done_file(state) -> Path:
    """Intention: every swap that was made, kept, so any one can be traced and undone."""
    return Path(state) / "improve" / "swapped.jsonl"


def archive_of(root, live, stamp: str) -> Path:
    """Intention: where the old file goes when a proven one replaces it — archive/<day>_improved/<path>."""
    return Path(root) / "archive" / f"{stamp[:10]}_improved" / PurePosixPath(_posix(live))
