# WARP2/warp2/improve/proof.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/proof.py
#  Used by   : warp2/work/loop.py (improve work: proven before it is kept).
#  Uses      : warp2/record/sandbox.py (a copy of the warp to prove it in),
#              warp2/record/children.py (run_watched — a run bounded by silence),
#              warp2/record/bytecode.py (no stale bytecode in the proof),
#              warp2/improve/proving_tests.py (which tests must pass),
#              warp2/gate/proof.py (TIMEOUT_SECONDS — the same silence bound).
#  Description:
#    Proves a new version of warp parts: the whole warp's code is copied into
#    a sandbox, the candidate files are put in at their real paths, and the
#    tests that belong to them run there. The live tree is never touched.
#  User intention (Andrew, 2026-09-25): "they just have to prove the new
#    parts in a project first."
# ============================================================================
from __future__ import annotations

import os
import sys
from pathlib import Path

from warp2.improve.proving_tests import CHECKS, proving_tests

# Intention: what is copied besides the warp's own package — the tests kept
# for warp parts outside it, and the two root files pytest reads.
ALSO_PROJECTS = (CHECKS.rsplit("/tests", 1)[0],)
ROOT_FILES = ("conftest.py", "pyproject.toml")


def _staged(shadow, root: Path, files: dict) -> None:
    """Intention: the warp's code first, the candidate over the top, so the tests import the new version."""
    shadow.stage_project("warp2")
    for project in ALSO_PROJECTS:
        shadow.stage_project(project)
    for name in ROOT_FILES:
        shadow.stage_mirror(name)
    for path, content in sorted(files.items()):
        shadow.stage(str(path), str(content))


def _run(shadow_root: Path, tests: list, stop=None) -> dict:
    """Run the tests in the copy. Says how it ended.

    Intention: bounded by SILENCE, not by a clock (Andrew: no timeouts, just
    checks that it is still running) — pytest reports each test as it goes,
    so a run that keeps talking keeps going; the outer bound grows with the
    number of test files.
    """
    from warp2.gate.proof import TIMEOUT_SECONDS
    from warp2.record import bytecode
    from warp2.record.children import FINISHED, run_watched
    with bytecode.honest_cache(dict(os.environ)) as env:
        env["PYTHONPATH"] = os.pathsep.join([str(shadow_root)] + [
            p for p in env.get("PYTHONPATH", "").split(os.pathsep) if p])
        command = [sys.executable, "-u", "-m", "pytest", "-q", "-p", "no:cacheprovider"] + list(tests)
        done = run_watched(command, float(TIMEOUT_SECONDS) * max(1, len(tests)), stop=stop,
                           cwd=str(shadow_root), env=env, quiet_seconds=float(TIMEOUT_SECONDS))
    ended = done.get("how")
    return {"finished": ended == FINISHED, "how": ended,
            "code": done.get("code"), "said": str(done.get("said") or "")[-4000:]}


def faults_added(root: Path, files: dict) -> list:
    """Intention: for each candidate .py, the kinds it has more of than the live file, with the lines - [] when none."""
    from warp2.builders import faults
    out = []
    for path, content in files.items():
        if not str(path).endswith(".py"):
            continue
        live = root / path
        before = faults.counted({path: faults.faults_in(live)}).get(path, {}) if live.is_file() else {}
        now_rows = faults.faults_in_text(str(content).splitlines())
        now = faults.counted({path: now_rows}).get(path, {})
        for kind, count in now.items():
            if count > int(before.get(kind, 0)):
                lines = [f"{line}: {text}" for k, line, text in now_rows if k == kind][:4]
                out.append(f"{path} {kind} {count} (live {before.get(kind, 0)}): " + " | ".join(lines))
    return out


def prove(root, files: dict, stop=None, cell: str = "") -> dict:
    """Prove candidate warp files in a copy of the warp. The verdict.

    Intention: passed only when the tests ran to the end and every one
    passed (pytest exit 0). No test to run is not a pass — it says so, and
    names what would prove it.
    """
    from warp2.record.sandbox import Sandbox
    root = Path(root)
    files = {str(path): content for path, content in (files or {}).items()}
    # Intention (Andrew, 2026-11-07 04:01: "make sure that all of the automations follow that"): a candidate with
    # more faults of the known kinds than the live file (warp2/builders/faults.py) is not proven, whatever its tests
    # say - the repair lane is the one automation that patched live errors at the crash site.
    added = faults_added(root, files)
    if added:
        return {"attempted": True, "passed": False, "tests": [],
                "why": "the candidate adds a fault of a known kind (design/RULES_FOR_EVERY_WORKER.md): " + "; ".join(added)}
    tests = proving_tests(root, files)
    if not tests:
        parts = ", ".join(sorted(files)) or "nothing"
        return {"attempted": True, "passed": False, "tests": [],
                "why": (f"nothing can prove {parts} yet: no test is named for it — "
                        f"write one beside it (test_<name>.py) with the change")}
    with Sandbox(root, cell_id=cell or "improve") as shadow:
        _staged(shadow, root, files)
        present = [test for test in tests if (shadow.root / test).is_file()]
        ran = _run(shadow.root, present, stop=stop)
    passed = bool(ran["finished"] and ran["code"] == 0)
    return {"attempted": True, "passed": passed, "tests": present,
            "why": "every test passed in a copy of the warp" if passed
                   else f"the tests did not all pass in a copy of the warp ({ran['how']}, exit {ran['code']})",
            "said": ran["said"]}
