# WARP2/warp2/improve/promote.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/promote.py
#  Used by   : warp2/work/loop.py (a proven candidate is put on the waiting
#              list and a restart is asked for),
#              warp2/run.py (at the start of a run, before anything is built,
#              the waiting candidates are swapped in).
#  Uses      : warp2/improve/home.py, warp2/util.py (hashing, atomic writes).
#  Description:
#    The swap. A proven candidate waits in state/improve/waiting.jsonl with
#    the digest of its own bytes and of the live file it was proven against.
#    At the next start, before the warp is built, each is swapped in only if
#    both digests still hold; the old file goes to archive/<day>_improved/,
#    and every swap is kept in state/improve/swapped.jsonl.
#  User intention (Andrew, 2026-09-25): "prove the new parts in a project
#    first". He chose: swapped in at restart, never under a running warp — the
#    guard's reason (no change to what governs change from inside a run)
#    still holds, because no run is live when the swap is made.
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

from warp2.improve.home import archive_of, candidate_of, done_file, waiting_file
from warp2.util import atomic_write_bytes, ensure_dir, now_iso, sha256_hex


def _digest(path: Path) -> str:
    """Intention: the file's sha256, or "" when there is no file."""
    return sha256_hex(path.read_bytes()) if path.is_file() else ""


def _read(path: Path) -> list:
    """Intention: the rows of a jsonl file; a line that will not read is skipped, never fatal."""
    if not path.is_file():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            rows.append(json.loads(line))
        except ValueError:
            continue
    return rows


def _append(path: Path, row: dict) -> None:
    """Intention: one row added to a jsonl file."""
    ensure_dir(path.parent)
    with path.open("a", encoding="utf-8") as out:
        out.write(json.dumps(row, sort_keys=True) + "\n")


def wait(root, state, live: str, item: str = "", tests=()) -> dict:
    """Put a proven candidate on the waiting list and ask for a restart.

    Intention: the digests are taken now — of the candidate as proven and of
    the live file it was proven against — so the swap can refuse anything
    that changed after the proof.
    """
    root = Path(root)
    candidate = candidate_of(live)
    row = {"live": str(live), "candidate": candidate,
           "candidate_sha256": _digest(root / candidate),
           "proven_against_sha256": _digest(root / str(live)),
           "item": str(item), "tests": list(tests), "at": now_iso()}
    _append(waiting_file(state), row)
    # Intention: THE RESTART IS ASKED FOR, not waited for — the runner takes
    # it at the next clean boundary between passes (run.py _Reload).
    flag = Path(state) / "locks" / "reload.flag"
    ensure_dir(flag.parent)
    flag.write_text(f"improve: {live}\n", encoding="utf-8")
    return row


def _swap_one(root: Path, row: dict) -> dict:
    """Intention: one waiting candidate swapped in, or the reason it was not."""
    live, candidate = root / row["live"], root / row["candidate"]
    if _digest(candidate) != row.get("candidate_sha256"):
        return {"swapped": False, "why": "the candidate changed after it was proven"}
    if _digest(live) != row.get("proven_against_sha256", ""):
        return {"swapped": False, "why": "the live file changed after the proof — prove it again"}
    stamp = now_iso()
    kept = ""
    if live.is_file():
        old = archive_of(root, row["live"], stamp)
        atomic_write_bytes(ensure_dir(old.parent) / old.name, live.read_bytes())
        kept = old.relative_to(root).as_posix()
    atomic_write_bytes(ensure_dir(live.parent) / live.name, candidate.read_bytes())
    return {"swapped": True, "old_kept_at": kept, "at": stamp}


def apply_waiting(root, state) -> list:
    """Swap in every waiting candidate. What happened to each.

    Intention: called only at the start of a run, before the warp is built.
    The newest candidate for a path is the one swapped; the list is emptied
    afterwards, and what happened to every row is kept in swapped.jsonl.
    """
    root, waiting = Path(root), waiting_file(state)
    rows = _read(waiting)
    if not rows:
        return []
    newest = {}
    for row in rows:
        newest[row["live"]] = row
    said = []
    for live, row in sorted(newest.items()):
        result = {**row, **_swap_one(root, row)}
        _append(done_file(state), result)
        said.append(result)
    atomic_write_bytes(waiting, b"")
    return said
