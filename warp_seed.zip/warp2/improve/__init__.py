# WARP2/warp2/improve/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/improve/__init__.py
#  Used by   : the modules below, as a package.
#  Uses      : nothing.
#  Description:
#    The models improving the warp itself. A change to any part of warp2 is
#    written into the self project (projects/_warp_self/), proven in a full copy
#    of the warp with the new part in place, and swapped into the live tree
#    only at the next restart, with the old file archived.
#  User intention (Andrew, 2026-09-25):
#    "make sure that the models can improve all the parts of the warp itself
#    they just have to prove the new parts in a project first." He chose: the
#    swap happens at restart, never under a running warp.
# ============================================================================
