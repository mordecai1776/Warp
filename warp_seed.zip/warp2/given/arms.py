# WARP3/warp2/given/arms.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/arms.py
#  Used by   : warp2/given/giver.py (one Arms per sub-task, part and model),
#              warp2/given/rule.py, warp2/given/tags.py (read it).
#  Uses      : nothing.
#  Description:
#    The two arms of one skill part for one model at one sub-task: the tries
#    where the part was given and the tries where it was held, each counted
#    as passed or failed. Newer tries count more: the i-th try of n weighs
#    (i + 1) / (n + 1), so the newest weighs nearly one and the oldest
#    nearly nothing. That is what lets the count notice a model that has
#    since learned the skill - old tries fade as new ones come in, and the
#    arm with old tries grows unsure again and is tried again.
#    Each arm's pass rate is read as a Beta(1 + passes, 1 + fails): a rate
#    and how unsure it is, with no try at all reading as one half, unsure.
#  User intention (Andrew, 2026-11-14): measure each skill with and without,
#    per model (research: SKILL0, arXiv 2604.02268 - a skill's help rises,
#    peaks and falls as the model learns it; Beyond Gain, arXiv 2610.32322 -
#    the verdict belongs to the skill and the model together).
# ============================================================================
"""Given and held tries of one skill part, newer counting more."""
from __future__ import annotations


class Arms:
    """Passed and failed tries with a part given and with it held, newer tries weighing more."""

    def __init__(self) -> None:
        """Intention: no tries yet; each arm's weighted passes and fails start at nought."""
        self.n = 0
        self.sums = {True: [0.0, 0.0], False: [0.0, 0.0]}

    def add(self, given: bool, passed: bool) -> None:
        """Intention: one more try. It carries its place (i + 1); dividing by (n + 1) when read gives every try its weight."""
        self.sums[bool(given)][0 if passed else 1] += self.n + 1.0
        self.n += 1

    def counts(self, given: bool) -> tuple:
        """Intention: the arm's weighted (passes, fails) now - each try's place over (n + 1)."""
        passes, fails = self.sums[bool(given)]
        return passes / (self.n + 1.0), fails / (self.n + 1.0)

    def tries(self, given: bool) -> float:
        """Intention: how much the arm has been tried, weighted the same way."""
        return sum(self.counts(given))

    def rate(self, given: bool) -> tuple:
        """The arm's pass rate and its variance, read as Beta(1 + passes, 1 + fails).

        Intention: no tries reads as one half, as unsure as a rate can be;
        the more an arm is tried, the surer its rate.
        """
        passes, fails = self.counts(given)
        mean = (1.0 + passes) / (2.0 + passes + fails)
        return mean, mean * (1.0 - mean) / (3.0 + passes + fails)
