# WARP3/warp2/given/label.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/label.py
#  Used by   : warp2/given/giver.py (what the give-or-hold action pair is
#              taught after each try).
#  Uses      : nothing.
#  Description:
#    THE CHANCE HOLDING WAS RIGHT FOR ONE TRY. Holding is right when the
#    model passes without the part: it saves the room and adds no noise.
#      held, passed  -> 1   (it did without it)
#      held, failed  -> 0   (it needed it)
#      given, either -> the held rate before this try - a given try says
#                       nothing about this piece without the part, so the
#                       best that is known is how often the model passes
#                       without it.
#  User intention (Andrew, 2026-11-14): the action pair (give or hold, a
#    thing the computer does) is taught by what the try showed.
# ============================================================================
"""The chance holding the part back was right for one try."""
from __future__ import annotations


def hold_right(given: bool, passed: bool, held_rate: float) -> float:
    """Intention: as in the file's heading - certain for a held try, the held rate for a given one."""
    if not given:
        return 1.0 if passed else 0.0
    return float(held_rate)
