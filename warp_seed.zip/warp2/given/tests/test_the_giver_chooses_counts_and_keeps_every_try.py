# WARP3/warp2/given/tests/test_the_giver_chooses_counts_and_keeps_every_try.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/tests/test_the_giver_chooses_counts_and_keeps_every_try.py
#  Used by   : pytest.
#  Uses      : warp2/given/giver.py (Giver), warp2/decide/ (Decisions - the
#              action pairs), the WARP's Eye (skills done kept).
#  Description:
#    The giver with simulated models: one that passes only with the part is
#    given it; one that passes only without it soon has it held; one that
#    passes either way has it held once it costs room. Every try is written
#    and counted back in by a new giver. With the machine's decision points,
#    each part has its own action pair (asked and settled, reading the
#    work), and each skill done is kept at every skill on its path - parent
#    over child - and for the master. A model that was never reached is let
#    go and counts nothing.
#  User intention (Andrew, 2026-11-14): "this should happen and work in the
#    models like the concept pairs and they should all have their own
#    concept pairs"; "Action pairs are meant to be things that the computer
#    does"; 20:56 "the concept side should be a hierarchy of of skills done".
# ============================================================================
from __future__ import annotations

import json
import random

from warp2.given.giver import Giver


def _run(giver: Giver, passes, tries: int, cost_room=(0, 0), key="build", part="coding rules", model="m",
         item=None) -> list:
    """Each try: choose, then pass by the simulated model's rule (given -> passes?), and tell the giver."""
    chosen = []
    chars, room = cost_room
    for _ in range(tries):
        ticket = giver.choose(key, part, model, chars, room, item=item)
        giver.saw([ticket], passes(ticket["given"]))
        chosen.append(ticket["given"])
    return chosen


def test_a_model_that_needs_the_part_is_given_it(tmp_path):
    giver = Giver(tmp_path, rng=random.Random(1))
    chosen = _run(giver, lambda given: given, 200)
    last = chosen[-len(chosen) // 4:]
    assert sum(last) >= 0.9 * len(last), sum(last)


def test_a_model_the_part_hurts_soon_has_it_held(tmp_path):
    giver = Giver(tmp_path, rng=random.Random(2))
    chosen = _run(giver, lambda given: not given, 200)
    last = chosen[-len(chosen) // 4:]
    assert sum(last) <= 0.2 * len(last), sum(last)
    row = giver.says()[0]
    assert row["state"] == "hurts" and row["hold"] > 0.8


def test_a_part_the_model_has_taken_in_is_held_once_it_costs_room(tmp_path):
    giver = Giver(tmp_path, rng=random.Random(3))
    chosen = _run(giver, lambda given: True, 300, cost_room=(400, 2000))
    last = chosen[-len(chosen) // 4:]
    assert sum(last) <= 0.33 * len(last), sum(last)
    assert giver.says()[0]["state"] == "taken in"


def test_every_try_is_written_and_a_new_giver_counts_it_back_in(tmp_path):
    giver = Giver(tmp_path, rng=random.Random(4))
    _run(giver, lambda given: given, 30, model="a")
    _run(giver, lambda given: not given, 30, model="b")
    lines = (tmp_path / "practice" / "given.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 60
    row = json.loads(lines[0])
    assert {"key", "part", "model", "given", "passed", "hold", "by", "at"} <= set(row)
    again = Giver(tmp_path)
    assert again.says() == giver.says()
    assert {r["model"] for r in again.says()} == {"a", "b"}


def test_with_the_machine_s_decisions_each_part_has_its_own_action_pair_and_skills_done_form_a_tree(tmp_path):
    from warp2.decide import Decisions
    decisions = Decisions(tmp_path)
    giver = Giver(tmp_path, decisions, rng=random.Random(5))
    item = {"kind": "practice", "target": "skill:architecture"}
    _run(giver, lambda given: given, 6, key="practice: architecture", part="skill line", model="m", item=item)
    ledger = (tmp_path / "decisions" / "give_practice_architecture_skill_line.jsonl").read_text(encoding="utf-8")
    rows = [json.loads(line) for line in ledger.splitlines()]
    events = [row["event"] for row in rows]
    assert events.count("asked") == 6 and events.count("settled") == 6
    assert rows[0]["features"]["kind: practice"] == 1.0 and rows[0]["features"]["target: architecture"] == 1.0
    assert not decisions.get("give_practice_architecture_skill_line", ("give", "hold")).open
    warp = giver.skills.warp
    assert warp is not None
    # The hierarchy of skills done: syntax over testing over architecture, each its own concept pairs.
    assert "testing" in warp.parts["skill: syntax"]["classes"]
    assert "architecture" in warp.parts["skill: testing"]["classes"]
    assert warp.parts["skill: architecture"]["classes"] == ["architecture"]
    assert {kept[2] for kept in warp.pending["skill: syntax"]} == {"testing"}
    masters = {kept[2] for kept in warp.pending["everything: web"]}
    assert {"skill: syntax: testing", "skill: testing: architecture",
            "skill: architecture: architecture"} <= masters
    # A second skill done under syntax joins the same parent as a new class.
    _run(giver, lambda given: given, 1, key="build", part="coding rules", model="m",
         item={"kind": "build", "target": "projects/shrink.py"})
    assert {"testing", "build"} <= set(warp.parts["skill: syntax"]["classes"])


def test_a_model_never_reached_counts_nothing_and_its_asks_are_let_go(tmp_path):
    from warp2.decide import Decisions
    decisions = Decisions(tmp_path)
    giver = Giver(tmp_path, decisions, rng=random.Random(6))
    ticket = giver.choose("build", "coding rules", "m", 100, 1000)
    assert ticket["id"]
    giver.dropped([ticket])
    assert not decisions.get("give_build_coding_rules", ("give", "hold")).open
    assert giver.says()[0]["given"] == 0.0 and giver.says()[0]["held"] == 0.0
    assert not (tmp_path / "practice" / "given.jsonl").exists()
