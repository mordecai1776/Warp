# WARP3/warp2/given/tests/test_the_worker_gives_or_holds_skill_parts_and_says_how_the_try_went.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/tests/test_the_worker_gives_or_holds_skill_parts_and_says_how_the_try_went.py
#  Used by   : pytest.
#  Uses      : warp2/models/worker.py (Worker), warp2/models/fleet.py,
#              warp2/gate/guard.py, warp2/store/; warp2/given/giver.py.
#  Description:
#    The worker with a Giver: a held part is left out of the prompt and a
#    given one is in; the obligations are always there; how the gate judged
#    the try is told back and written; the second model's try is its own;
#    a model that raises counts nothing; with no Giver, or no model named,
#    every part is given exactly as before.
#  User intention (Andrew, 2026-11-14): skill parts given only while they
#    help - and the model is still always told what it will be judged by.
# ============================================================================
from __future__ import annotations

import json

from warp2.gate.contracts import contract_for
from warp2.gate.guard import Gate
from warp2.given.giver import Giver
from warp2.models.fleet import Fleet
from warp2.models.worker import Worker
from warp2.store.store import Store
from warp2.store.tagnet import TagNet

GOOD = ("# path: projects/shrink.py\n"
        "def hold(number):\n"
        "    return max(1, number)\n")
BROKEN = "# path: projects/shrink.py\ndef hold(:\n"
ITEM = {"item": "work:build:projects/shrink.py", "kind": "build", "target": "projects/shrink.py"}
SLICE = {"text": "# context for projects/shrink.py\nit holds the number at one",
         "context": {"proves_intention": "hold the number at one"}, "obligations": ""}
CODING = "rules: write clean, executable Python code"


class Always:
    """A stand-in for random.Random: always the same draw, so a part is always given (1.0) or always held (0.0)."""

    def __init__(self, draw: float) -> None:
        self.draw = draw

    def random(self) -> float:
        return self.draw


def _world(tmp_path):
    store = Store(tmp_path / "state", run="given", view_path=tmp_path / "view.sqlite3")
    return Fleet(TagNet(store)), Gate(store)


def _tries(tmp_path) -> list:
    path = tmp_path / "state" / "practice" / "given.jsonl"
    if not path.is_file():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    return [json.loads(line) for line in lines]


def _held_once_tried(giver: Giver) -> None:
    """Give the part a history in which the model passed without it, so the rule holds it."""
    for given, passed in [(True, True)] * 20 + [(False, True)] * 20:
        giver.saw([{"key": "build", "part": "coding rules", "model": "steady", "given": given,
                    "hold": 0.0, "by": "count", "cost": 0.0, "id": ""}], passed)


def test_a_held_part_is_left_out_and_the_obligations_stay(tmp_path):
    fleet, gate = _world(tmp_path)
    worker = Worker(fleet, gate=gate)
    worker.given = Giver(tmp_path / "state", rng=Always(0.0))
    _held_once_tried(worker.given)
    chose = []
    prompt = worker.prompt(ITEM, SLICE, name="steady", chose=chose)
    assert CODING not in prompt
    for clause in contract_for("build").clauses:
        assert clause.line(SLICE["context"]) in prompt
    assert [t["part"] for t in chose] == ["coding rules"] and not chose[0]["given"]


def test_without_a_giver_or_a_named_model_every_part_is_given(tmp_path):
    fleet, gate = _world(tmp_path)
    worker = Worker(fleet, gate=gate)
    assert CODING in worker.prompt(ITEM, SLICE)
    worker.given = Giver(tmp_path / "state", rng=Always(0.0))
    _held_once_tried(worker.given)
    assert CODING in worker.prompt(ITEM, SLICE)


def test_how_the_gate_judged_the_try_is_told_back_and_written(tmp_path):
    fleet, gate = _world(tmp_path)
    fleet.enlist("steady", ask=lambda prompt: "```python\n" + GOOD + "```", kinds=("build",))
    worker = Worker(fleet, gate=gate)
    worker.given = Giver(tmp_path / "state", rng=Always(1.0))
    result = worker.do(ITEM, SLICE)
    rows = _tries(tmp_path)
    assert rows and rows[-1]["model"] == "steady" and rows[-1]["part"] == "coding rules"
    assert rows[-1]["given"] is True
    assert rows[-1]["passed"] is (not result.get("issues"))


def test_the_second_model_s_try_is_its_own(tmp_path):
    fleet, gate = _world(tmp_path)
    fleet.enlist("first", ask=lambda prompt: "```python\n" + BROKEN + "```", kinds=("build",))
    fleet.enlist("second", ask=lambda prompt: "```python\n" + GOOD + "```", kinds=("build",))
    # Which model goes first is drawn by weight; pinned, as test_worker.py does.
    fleet.choose = lambda kind, stream="": "first"
    worker = Worker(fleet, gate=gate)
    worker.given = Giver(tmp_path / "state", rng=Always(1.0))
    worker.do(ITEM, SLICE)
    rows = _tries(tmp_path)
    by_model = {row["model"]: row["passed"] for row in rows}
    assert by_model == {"first": False, "second": True}


def test_a_model_that_raises_counts_nothing(tmp_path):
    fleet, gate = _world(tmp_path)

    def broken(prompt):
        raise RuntimeError("the model server is not there")
    fleet.enlist("gone", ask=broken, kinds=("build",))
    worker = Worker(fleet, gate=gate)
    worker.given = Giver(tmp_path / "state", rng=Always(1.0))
    worker.do(ITEM, SLICE)
    assert _tries(tmp_path) == []
