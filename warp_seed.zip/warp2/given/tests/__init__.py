# WARP3/warp2/given/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/tests/__init__.py
#  Used by   : pytest (the package of the tests of what a model is given).
#  Uses      : nothing.
#  Description:
#    The tests of warp2/given/: the counting rule across the four states,
#    the giver choosing, counting and keeping every try, the action pairs and
#    the hierarchy of skills done in the Eye, and the worker giving or holding
#    each skill part and telling how the try went.
#  User intention (Andrew, 2026-11-14): skills given only while they help the
#    model; each sub-task with its own concept pairs; action pairs for what
#    the computer does. BUILD_LOG 1648c.
# ============================================================================
