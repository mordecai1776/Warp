# WARP3/warp2/given/tries.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/tries.py
#  Used by   : warp2/given/giver.py (every try written; read back at start).
#  Uses      : warp2/util.py (now_iso), warp2/record/swallowed.py (noted);
#              stdlib json, pathlib.
#  Description:
#    Every try of a skill part, one line each, in state/practice/given.jsonl,
#    beside the skills table: the sub-task, the part, the model, whether the
#    part was given, whether the work passed, and how often it was being
#    held then. Appended, never rewritten; a torn line is skipped and said.
#  User intention (Andrew, 2026-09-25): "nothing the warp does is ever just
#    thrown away" - every try is kept, so the counts can always be rebuilt
#    and every try can be trained on.
# ============================================================================
"""Every try of a skill part, kept."""
from __future__ import annotations

import json
from pathlib import Path

from warp2.record.swallowed import noted
from warp2.util import now_iso


class Tries:
    """state/practice/given.jsonl - one line a try."""

    def __init__(self, state) -> None:
        """Intention: one file per state folder, beside the skills table."""
        self.path = Path(state) / "practice" / "given.jsonl"

    def add(self, row: dict) -> None:
        """Intention: one try, appended with the time."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({**row, "at": now_iso()}, default=str) + "\n")

    def rows(self) -> list:
        """Intention: every try in the order written; a torn line is skipped and said, never fatal."""
        if not self.path.is_file():
            return []
        text = self.path.read_text(encoding="utf-8", errors="replace")
        out = []
        for line in text.splitlines():
            if not line.strip():
                continue
            try:
                out.append(json.loads(line))
            except ValueError as exc:
                noted("warp2/given/tries.py:Tries.rows", exc)
        return out
