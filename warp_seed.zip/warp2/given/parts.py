# WARP3/warp2/given/parts.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/given/parts.py
#  Used by   : warp2/models/worker.py (names the parts it may hold, and the
#              sub-task each unit is), warp2/given/giver.py (point names).
#  Uses      : stdlib re.
#  Description:
#    The prompt parts that are skill text, and the sub-task a unit is.
#      skill line     - "the skill: <name> - <intention>" (practice)
#      rule hint      - the worked examples are the rule for every input
#      coding rules   - the general rules for writing python
#      test rules     - how a test is written
#      connection web - what the part being worked on connects to
#    Never held: the obligations (what the work is judged by - the model is
#    always told them, and checks are what research found helps), the
#    target, why the last try was refused, a split's size, an owed rule,
#    where it may write, how to answer, and the context.
#    The sub-task is the kind of work; practice is split by its skill, so
#    each skill is measured on its own.
#  User intention (Andrew, 2026-11-14): "while we speclize to task and break
#    them down into smaller task" - every part is measured per sub-task,
#    per model. Research: The Regression Tax (arXiv 2607.22520) - a skill's
#    name and description alone change answers, generic steps hurt most,
#    and checks help; SkillsBench (arXiv 2602.12670) - small, focused
#    skills help, long all-covering ones hurt.
# ============================================================================
"""The prompt parts that may be held, and the sub-task a unit is."""
from __future__ import annotations

import re

SKILL_LINE = "skill line"
RULE_HINT = "rule hint"
CODING_RULES = "coding rules"
TEST_RULES = "test rules"
CONNECTION_WEB = "connection web"


def key_of(item: dict) -> str:
    """Intention: the unit's sub-task - its kind, and for practice the skill it practises."""
    kind = str(item.get("kind") or "")
    target = str(item.get("target") or "")
    if kind == "practice":
        return "practice: " + (target.split(":", 1)[1] if target.startswith("skill:") else target)
    return kind


def slug(text: str) -> str:
    """Intention: a name safe in a file name on any system - small letters, digits and underscores."""
    return re.sub(r"[^a-z0-9]+", "_", str(text).lower()).strip("_")


def point_name(key: str, part: str) -> str:
    """Intention: the decision point (and Eye part) for one part at one sub-task, e.g. give_build_coding_rules.

    Written without an f-string on purpose: on Python 3.11 an f-string is one
    string token, and the tree's audit of who calls what (which reads code
    with strings taken out) would not see `slug` called here.
    """
    return "give_" + slug(key) + "_" + slug(part)
