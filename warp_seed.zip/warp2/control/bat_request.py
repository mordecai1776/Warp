# WARP2/warp2/control/bat_request.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/bat_request.py
#  Used by   : warp2/control/watcher.py (each look),
#              warp2/control/tests/test_the_watcher_runs_a_bat_it_is_asked_to.py.
#  Uses      : warp2/control/files.py (ControlFiles), warp2/util.py
#              (atomic_write_bytes); stdlib json, os, subprocess, time.
#  Description:
#    The watcher runs one of the WARP2 folder's own .bat files when asked:
#    write the .bat's name (only a name, no folder) into
#    state/control/bat.request. The .bat is started on its own, with no
#    keyboard (so a closing `pause` ends at once), its words go to
#    state/diagnostics/bat_<name>_<time>.txt, and what was started is written
#    to state/control/bat.last.json. The watcher never waits on it.
#    Only a .bat that sits directly in the WARP2 folder is run; anything else
#    is refused and the refusal written down.
#  User intention (Andrew, 2026-11-02 00:21): "I need you to have the warp run
#    that bat." Andrew, 2026-10-16: "I will only run a bat only put things
#    into those" — so what the warp runs for him is a .bat too.
# ============================================================================
from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path

# Intention: no window for the .bat, and it does not end with the watcher.
NO_WINDOW = 0x08000000
DETACHED = 0x00000008 | 0x00000200


class BatAsk:
    """What was asked: one .bat name, checked against the WARP2 folder.

    Intention: the name is the only thing read from the request, and it must
    be a plain file name ending in .bat that exists in the root, so nothing
    outside Andrew's own .bat files can be run this way.
    """

    def __init__(self, root: Path, text: str) -> None:
        """Intention: the first non-empty line of the request is the name."""
        self.root = Path(root).resolve()
        lines = [line.strip() for line in str(text).splitlines() if line.strip()]
        self.name = lines[0] if lines else ""

    def refused(self) -> str:
        """Intention: why this name will not be run, or "" when it will."""
        if not self.name:
            return "no .bat name in the request"
        if Path(self.name).name != self.name or "/" in self.name or "\\" in self.name:
            return f"only a name in the WARP2 folder, not a path: {self.name}"
        if not self.name.lower().endswith(".bat"):
            return f"not a .bat: {self.name}"
        if not (self.root / self.name).is_file():
            return f"no such .bat in the WARP2 folder: {self.name}"
        return ""

    def path(self) -> Path:
        """Intention: the .bat itself, in the root."""
        return self.root / self.name


class BatStart:
    """Starts a checked .bat with no keyboard and its words going to a log.

    Intention: `popen` is subprocess.Popen unless a test gives a stand-in.
    """

    def __init__(self, state: Path, popen=None) -> None:
        """Intention: logs go under state/diagnostics."""
        self.state = Path(state)
        self.popen = popen or subprocess.Popen

    def log_for(self, name: str) -> Path:
        """Intention: one log per run, named by the .bat and the time it started."""
        stamp = time.strftime("%Y%m%d-%H%M%S")
        folder = self.state / "diagnostics"
        folder.mkdir(parents=True, exist_ok=True)
        return folder / f"bat_{Path(name).stem}_{stamp}.txt"

    def start(self, ask: BatAsk) -> dict:
        """Intention: start it and return what was started; the watcher goes on at once."""
        log = self.log_for(ask.name)
        flags = (NO_WINDOW | DETACHED) if os.name == "nt" else 0
        with open(log, "wb") as out, open(os.devnull, "rb") as nothing:
            process = self.popen(["cmd", "/c", str(ask.path())], cwd=str(ask.root), stdin=nothing,
                                 stdout=out, stderr=subprocess.STDOUT, creationflags=flags, close_fds=True)
        return {"outcome": "started", "bat": ask.name, "pid": getattr(process, "pid", None), "log": str(log)}


def answer_bat(files, root: Path, popen=None) -> bool:
    """Intention: if a .bat was asked for, the ask is removed, the .bat started or refused, and the answer written."""
    asked = files.dir / "bat.request"
    if not asked.exists():
        return False
    try:
        text = asked.read_text(encoding="utf-8", errors="replace")
        asked.unlink()
    except OSError:
        return False
    from warp2.util import atomic_write_bytes
    ask = BatAsk(root, text)
    why = ask.refused()
    try:
        answer = {"outcome": "refused", "bat": ask.name, "why": why} if why else BatStart(files.state, popen).start(ask)
    except Exception as exc:
        answer = {"outcome": "failed", "bat": ask.name, "why": f"{type(exc).__name__}: {exc}"}
    answer["when"] = time.strftime("%Y-%m-%d %H:%M:%S")
    atomic_write_bytes(files.dir / "bat.last.json", json.dumps(answer, indent=1).encode("utf-8"))
    return True
