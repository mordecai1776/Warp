# WARP2/warp2/control/supervisor.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/supervisor.py
#  Used by   : warp2/control/watcher.py (expected-runner liveness checks).
#  Uses      : warp2.util atomic writes; stdlib JSON, time, pathlib.
#  Description:
#    Restart an expected runner only after repeated independent observations.
#  User intention (Andrew, 2026-10-07): keep intended runs recoverable without
#    resurrecting work the user deliberately stopped.
#  2026-10-25 (BUILD_LOG 593): a start whose regression gate is still running
#    is waited for, not launched again. Seen: the gate took over 10 minutes,
#    the watcher gave up at 5 and started three more, each gate holding
#    ~3.6 GB, with no runner for half an hour.
#  2026-10-28 (BUILD_LOG 824): a gate hung past its patience is ended (whole
#    tree, by force) before the new start goes, so a hung gate no longer keeps
#    its memory beside the new start's.
# ============================================================================
"""Conservative runner supervision for the restart watcher."""
from __future__ import annotations

import json
import time
from pathlib import Path

from warp2.util import atomic_write_bytes

STALE_SECONDS = 120.0
MISSING_OBSERVATIONS = 3
MAX_BACKOFF = 900.0
BASE_BACKOFF = 30.0
ATTEMPT_WINDOW_SECONDS = 1800.0
MAX_ATTEMPTS = 3
STABLE_SECONDS = 300.0
# Intention: how long a start still in its regression gate is waited for
# before a new start is allowed (a gate normally takes 3-5 minutes; one hung
# past this is not trusted to finish).
GATE_PATIENCE_SECONDS = 1200.0


class RunnerSupervisor:
    """Restart an expected runner only after repeated independent observations."""

    def __init__(self, clock=time.time) -> None:
        """Intention: start with no misses, no retries and no history; the saved history is loaded on first use."""
        self.clock = clock
        self.missing = 0
        self.next_at = 0.0
        self.attempt_history: list[float] = []
        self.healthy_since: float | None = None
        self.gate_seen_since: float | None = None
        self.gates_ended: list = []
        self._loaded = False

    def _fresh(self, path: Path) -> bool:
        """Intention: is this beat file recent enough to count the runner as alive; a missing file is not fresh."""
        try:
            return self.clock() - path.stat().st_mtime <= STALE_SECONDS
        except OSError:
            return False

    def healthy(self, files, hands) -> bool:
        """Intention: the runner is healthy when one is registered and its beat is fresh."""
        runners = [row for row in hands.registered() if row.get("role") == "run"]
        return bool(runners) and self._fresh(files.runner_beat)

    def observe(self, files, hands) -> dict | None:
        """Return a governed restart request, or None while healthy/not expected."""
        self._load(files)
        if not files.expected.is_file() or files.stop_flag.is_file():
            self.missing = 0
            self.healthy_since = None
            # An intentionally idle run must replace any old restart report;
            # time spent stopped also cannot count as sustained runner health.
            self._record(files, "stopped" if files.stop_flag.is_file() else "not_expected")
            return None
        now = self.clock()
        runners = [row for row in hands.registered() if row.get("role") == "run"]
        if runners and self._fresh(files.runner_beat):
            self.missing = 0
            if self.healthy_since is None:
                self.healthy_since = now
            if now - self.healthy_since >= STABLE_SECONDS:
                self.attempt_history.clear()
                self.next_at = 0.0
            self._record(files, "healthy")
            return None
        if runners:
            # A live runner with a stale beat may be doing long work or stuck.
            # Restarting it automatically could discard user work, so fail
            # closed and wait for its process to exit or its beat to recover.
            self.missing = 0
            self.healthy_since = None
            self._record(files, "stale_runner_alive")
            return None
        self.healthy_since = None
        self.attempt_history = [at for at in self.attempt_history
                                if 0.0 <= now - at < ATTEMPT_WINDOW_SECONDS]
        self.missing += 1
        self._record(files, "missing")
        if self.missing < MISSING_OBSERVATIONS:
            return None
        if len(self.attempt_history) >= MAX_ATTEMPTS:
            self._record(files, "circuit_open")
            return None
        if now < self.next_at:
            self._record(files, "backoff")
            return None
        if self._waiting_on_gate(hands, now):
            self.missing = 0
            self._record(files, "starting")
            return None
        self.missing = 0
        self.attempt_history.append(now)
        attempt = len(self.attempt_history)
        self.next_at = now + min(BASE_BACKOFF * (2 ** (attempt - 1)), MAX_BACKOFF)
        self._record(files, "restarting")
        return {"why": "supervisor: expected runner process is absent", "automatic": True}

    def _waiting_on_gate(self, hands, now: float) -> bool:
        """Intention: a start still in its regression gate is waited for, up to
        GATE_PATIENCE_SECONDS from when it was first seen; past that, or with no
        gate running, a new start may go ahead. Asked only when a restart is
        about to be made, because looking at the process list is slow."""
        look = getattr(hands, "starting", None)
        gates = look() if callable(look) else []
        if not gates:
            self.gate_seen_since = None
            return False
        if self.gate_seen_since is None:
            self.gate_seen_since = now
        if now - self.gate_seen_since < GATE_PATIENCE_SECONDS:
            return True
        self.gates_ended = HungGate.end(hands, gates)
        self.gate_seen_since = None
        return False

    def _load(self, files) -> None:
        """Intention: read the saved retry history once, keeping only attempts inside the window, so a restart of
        the watcher does not forget how often it already tried. A bad file starts clean."""
        if self._loaded:
            return
        self._loaded = True
        try:
            prior = json.loads(files.supervision.read_text(encoding="utf-8"))
            now = self.clock()
            history = prior.get("attempt_history", [])
            self.attempt_history = [float(at) for at in history
                                    if 0.0 <= now - float(at) < ATTEMPT_WINDOW_SECONDS]
            self.next_at = max(0.0, float(prior.get("next_retry", 0.0)))
            since = prior.get("healthy_since")
            self.healthy_since = float(since) if since is not None else None
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            self.attempt_history = []
            self.next_at = 0.0
            self.healthy_since = None

    def _record(self, files, state: str) -> None:
        """Intention: write the supervisor's state and retry history to supervision.json, so it survives a restart
        and a person can see it."""
        row = {"state": state, "when": self.clock(), "missing_observations": self.missing,
               "attempts": len(self.attempt_history), "attempt_history": self.attempt_history,
               "healthy_since": self.healthy_since, "next_retry": self.next_at}
        if self.gates_ended:
            row["gates_ended"] = self.gates_ended
        if state == "healthy":
            # Intention (2026-10-31, Remy for Andrew): a fresh beat is not a step that is moving; a step far past
            # its own usual time is said here too. Said only — it restarts nothing (a long step may be real work).
            try:
                from warp2.control.overdue import step_in_flight
                step = step_in_flight(files.state)
                if step.get("overdue"):
                    row["step_overdue"] = step
            except Exception:  # noqa: BLE001
                pass
        atomic_write_bytes(files.supervision, json.dumps(row, indent=1).encode("utf-8"))


class HungGate:
    """Ends regression gates that hung past their patience.

    Intention (BUILD_LOG 824; open item "the watcher ends a start-up test run
    that has hung past its patience"): before, past the patience a new start
    was let go while the hung gate kept running beside it (~3.6 GB each).
    """

    @staticmethod
    def end(hands, pids) -> list:
        """Intention: each gate pid ended with its children, by force; what was asked and what Windows said."""
        stop = getattr(hands, "end", None)
        if not callable(stop):
            return []
        ended = []
        for pid in pids:
            try:
                said = stop(int(pid), True, True)
            except Exception as exc:  # one gate that will not end must not stop the restart
                said = f"{type(exc).__name__}: {exc}"
            ended.append({"pid": int(pid), "said": str(said)[:200]})
        return ended
