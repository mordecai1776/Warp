# WARP2/warp2/control/status.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/status.py
#  Used by   : warp2/control/watcher.py (when state/control/status.request
#              appears).
#  Uses      : warp2/control/files.py, warp2/control/regions.py (when asked
#              for "regions"), warp2/control/memory_samples.py; stdlib json, subprocess, time.
#  Description:
#    How the machine is doing, from outside it: free and total memory, how
#    much memory Windows can still promise programs (commit), the ten
#    biggest other programs, and
#    each Python process's memory and command line, written to
#    state/control/status.json. Asked for by writing status.request, so it
#    costs nothing until someone asks.
#  User intention (Andrew, 2026-10-02): Claude runs the warp alone while he is
#    away — and needs to see what a person at the machine would see. (Measured
#    the same day: the cat's practice failed with a MemoryError and nothing
#    said how full the memory was.)
# ============================================================================
"""Memory and processes, written down on request."""
from __future__ import annotations

import json
import subprocess
import time

QUIET = 0x08000000


def _powershell(script: str):
    """Intention: one PowerShell question, answered as JSON; None if it cannot answer."""
    try:
        done = subprocess.run(["powershell", "-NoProfile", "-Command", script + " | ConvertTo-Json -Compress"],
                              capture_output=True, text=True, timeout=60, creationflags=QUIET)
        return json.loads(done.stdout or "null")
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def status(state=None) -> dict:
    """Intention: free and total memory in MB, and every Python process with its memory and command line."""
    system = _powershell("Get-CimInstance Win32_OperatingSystem | "
                         "Select-Object FreePhysicalMemory,TotalVisibleMemorySize,"
                         "FreeVirtualMemory,TotalVirtualMemorySize") or {}
    found = _powershell("Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^pyw?(thonw?)?(\\.exe)?$' } | "
                        "Select-Object ProcessId,ParentProcessId,WorkingSetSize,PrivatePageCount,CommandLine") or []
    found = [found] if isinstance(found, dict) else found
    started = _starts()
    # Intention (2026-10-17, BUILD_LOG 302): the biggest OTHER programs too.
    # Measured that night: 39.6 of 40.8 GB of commit promised while the Python
    # processes held about 12 GB — the rest was invisible here.
    others = _powershell("Get-CimInstance Win32_Process | Where-Object { $_.Name -notmatch '^pyw?(thonw?)?(\\.exe)?$' } | "
                         "Sort-Object PrivatePageCount -Descending | Select-Object -First 10 "
                         "ProcessId,ParentProcessId,Name,WorkingSetSize,PrivatePageCount,CommandLine") or []
    others = [others] if isinstance(others, dict) else others
    workload = {}
    if state is not None:
        from pathlib import Path
        from warp2.control.files import ControlFiles, beat_pid
        from warp2.record.processes import identity
        files = ControlFiles(Path(state))
        def lane(path):
            """Intention: one lane's beat read as pid, fresh (beat within 120 s) and alive, for the workload report."""
            pid = beat_pid(path)
            try:
                fresh = path.is_file() and time.time() - path.stat().st_mtime <= 120
            except OSError:
                fresh = False
            return {"pid": pid, "fresh": fresh, "alive": bool(pid and identity(pid))}
        runner, web = lane(files.runner_beat), lane(files.lane_beat)
        expected = files.expected.is_file()
        workload = {"expected": expected, "runner": runner, "web": web,
                    "overall": ("healthy" if runner["fresh"] and runner["alive"] else
                                "critical" if expected else "idle")}
        # Intention (2026-10-31, Remy for Andrew: "fix everything that is wrong"): the beat comes from a side
        # thread, so a runner stuck inside one step still beat and read "healthy" — train_chat ran two hours
        # against a usual twenty minutes. The step in flight is said beside it, and a step past its own measured
        # usual time (mean plus spread, deadline.py) reads "overdue" rather than "healthy".
        try:
            from warp2.control.overdue import step_in_flight
            workload["step"] = step_in_flight(Path(state))
            if workload["overall"] == "healthy" and workload["step"].get("overdue"):
                workload["overall"] = "overdue"
        except Exception as exc:  # noqa: BLE001 — a reading that fails says so and changes nothing else
            workload["step"] = {"failed": type(exc).__name__}
    return {"when": time.strftime("%Y-%m-%d %H:%M:%S"),
            "memory_free_mb": round(int(system.get("FreePhysicalMemory") or 0) / 1024),
            "memory_total_mb": round(int(system.get("TotalVisibleMemorySize") or 0) / 1024),
            # Intention (2026-10-17, BUILD_LOG 302): free RAM is not the whole
            # story. Windows refuses memory once what it has PROMISED programs
            # (RAM plus page file — "commit") is used up, even with RAM free,
            # and code that does not check the refusal crashes with an access
            # violation. This shows how much can still be promised.
            "commit_free_mb": round(int(system.get("FreeVirtualMemory") or 0) / 1024),
            "commit_total_mb": round(int(system.get("TotalVirtualMemorySize") or 0) / 1024),
            "workload": workload,
            "python": sorted(({"pid": p.get("ProcessId"), "parent": p.get("ParentProcessId"),
                               "working_mb": round(int(p.get("WorkingSetSize") or 0) / 2**20),
                               "private_mb": round(int(p.get("PrivatePageCount") or 0) / 2**20),
                               # Intention (2026-10-29, BUILD_LOG 925): when each
                               # process started, so a memory sample says how long
                               # the process had run (epoch seconds; None if unknown).
                               "started": started.get(p.get("ProcessId")),
                               "command": str(p.get("CommandLine") or "")[:160]} for p in found),
                              key=lambda row: -row["private_mb"]),
            "biggest_others": [{"pid": p.get("ProcessId"), "name": str(p.get("Name") or ""),
                                "working_mb": round(int(p.get("WorkingSetSize") or 0) / 2**20),
                                "private_mb": round(int(p.get("PrivatePageCount") or 0) / 2**20),
                                # Intention (2026-11-02, BUILD_LOG 1074): who started it and how, so a
                                # big outside program (three llama-server.exe, ~11 GB, none of them the
                                # warp's) can be traced to what launched it.
                                "parent": p.get("ParentProcessId"),
                                "command": str(p.get("CommandLine") or "")[:240]}
                               for p in others]}


def _starts() -> dict:
    """Intention: pid -> start time (epoch seconds) of each Python process, asked separately so a failure here
    loses only the start times, never the memory rows; {} when PowerShell cannot answer."""
    rows = _powershell("Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^pyw?(thonw?)?(\\.exe)?$' "
                       "-and $_.CreationDate } | Select-Object ProcessId,"
                       "@{n='Started';e={[int64](([DateTimeOffset]$_.CreationDate).ToUnixTimeSeconds())}}") or []
    rows = [rows] if isinstance(rows, dict) else rows
    out = {}
    for row in rows:
        try:
            out[int(row.get("ProcessId"))] = int(row.get("Started"))
        except (TypeError, ValueError, AttributeError):
            continue
    return out


def answer_status(files) -> bool:
    """Intention: if status was asked for, the answer is written and the ask removed; whether it was asked."""
    asked = files.dir / "status.request"
    if not asked.exists():
        return False
    try:
        text = asked.read_text(encoding="utf-8", errors="replace")
        asked.unlink()
    except OSError:
        return False
    from warp2.util import atomic_write_bytes
    found = status(files.state)
    atomic_write_bytes(files.dir / "status.json", json.dumps(found, indent=1).encode("utf-8"))
    # Intention (2026-10-29, BUILD_LOG 925): status.json is overwritten each
    # time; every answer also keeps one line in diagnostics/memory_samples.jsonl
    # tied to the warp step in flight, so samples can be compared like for like.
    from warp2.control.memory_samples import MemorySamples
    MemorySamples(files.state).keep(found)
    # Intention (2026-10-23, BUILD_LOG 488): a request that says "regions"
    # also gets one process's memory map (warp2/control/regions.py) — the
    # pid it names, or the biggest Python process — so where a big child's
    # memory sits can be read from outside it, before and after a restart.
    pid = _regions_asked(text, found)
    if pid:
        from warp2.control.regions import walk
        row = walk(pid)
        atomic_write_bytes(files.dir / "regions.json", json.dumps(row, indent=1).encode("utf-8"))
        try:
            (files.state / "diagnostics").mkdir(parents=True, exist_ok=True)
            with (files.state / "diagnostics" / "regions.jsonl").open("a", encoding="utf-8") as out:
                out.write(json.dumps(row) + "\n")
        except OSError as exc:
            from warp2.record.swallowed import noted
            noted("control.status.regions_log", exc)
    return True


def _regions_asked(text: str, found: dict):
    """Intention: the pid whose memory map was asked for — {"regions": pid}, or {"regions": true} for the
    biggest Python process; None when the request did not ask (an empty request is a plain status ask)."""
    try:
        asked = json.loads(text) if text.strip() else {}
    except ValueError:
        return None
    want = asked.get("regions") if isinstance(asked, dict) else None
    if want is True:
        biggest = found.get("python") or []
        return biggest[0].get("pid") if biggest else None
    return int(want) if isinstance(want, int) and not isinstance(want, bool) and want > 0 else None
