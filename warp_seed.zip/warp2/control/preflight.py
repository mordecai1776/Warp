# WARP2/warp2/control/preflight.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/preflight.py
#  Used by   : warp2/control/windows.py (`launch` — the watcher's automatic
#              restart), warp2/ui/runner.py (`main` — the window's Start and
#              Resume).
#  Uses      : warp2/builders/triage.py (a failed gate, set right by score — BUILD_LOG 1005),
#              run_tests.py (`--preflight` — the same fast regression gate
#              WARP2.bat runs), warp2/record/quiet.py (no console window),
#              warp2/run.py (`main` — the continuous run, after the gate);
#              stdlib subprocess, sys, pathlib.
#  Description:
#    The prestart regression gate for every way a continuous run can start.
#    WARP2.bat already runs it; a restart by the watcher and a Start from the
#    window now run it too, and a failed gate means no runner.
#    A gate that hangs is ended past its patience (BUILD_LOG 915): patience is
#    a multiple of the gate's own last measured time (tests.out.txt), so one
#    stuck test cannot hold the warp down for good; the hung test is named in
#    state/diagnostics/preflight_hung.txt and the gate counts as failed.
#    Only a FINISHED gate's closing score counts as its measured time
#    (BUILD_LOG 1016): the running score printed every 50 tests is not the
#    gate's length, and a cut-off gate leaves only that one behind.
#    A FAILED gate's output is kept before triage runs again (BUILD_LOG 1475):
#    the rerun writes over tests.out.txt, so the failing test and its reason
#    are copied to tests.failed.txt and a dated copy under
#    state/diagnostics/failed_gates/, which no later run writes over.
#    PATIENCE BOUNDS STILLNESS (BUILD_LOG 1490): a gate past its patience is
#    read for work (warp2/record/working.py) and waited for while it works;
#    it is ended as hung only after a whole patience with none, or once it
#    has used its set amount of compute (its patience on every processor).
#  User intention (Andrew): the bat's own note says a continuous run "starts
#    only when the fast, CPU-safe regression gate passes". Found 2026-10-09
#    (check F5): the watcher's restarts and the window's Start skipped it.
#    Open item from the hourly prompt: "the watcher ends a start-up test run
#    that has hung past its patience".
#    2026-11-09 22:41: "make the time constraints more adaptive and have it do
#    checks for freezes. We should allow for long times." 22:53: "All work on
#    the warp should use a set amount of compute." (BUILD_LOG 1490.)
# ============================================================================
"""The fast regression gate, run before any continuous start."""
from __future__ import annotations

import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

# Intention: how many times its own last measured length the gate may take
# before it is called hung, and the patience when no length is measured yet.
PATIENCE_TIMES = 5.0
UNMEASURED_PATIENCE_S = 1800.0

# Intention: the gate's own summary line, "[  3.3 min] 108 passed, ...".
_MEASURED = re.compile(r"\[\s*([0-9]+(?:\.[0-9]+)?) min\]")
# Intention (BUILD_LOG 1016): run_tests.py writes this rule of "=" just before
# its closing score, and only when the gate ran to its end.
_CLOSING_RULE = "=" * 60


class Patience:
    """Intention: how long this gate may run, from how long it last took."""

    def __init__(self, root: Path) -> None:

        """Intention: keep the root the gate runs in, and the files it reads under state/diagnostics."""
        self.out = Path(root) / "state" / "diagnostics" / "tests.out.txt"

    def last_minutes(self) -> float | None:
        """Intention: the last FINISHED gate's length in minutes, or None when none is on file.

        Intention (BUILD_LOG 1016): only the closing score, the line right
        after the closing rule, is the gate's length. The running score every
        50 tests ("[  0.2 min] 50 passed") is not: a gate cut off past its
        patience leaves only that one, and reading it gave the next start 60 s,
        so the slow chat test was cut every time and the warp stayed down
        (2026-10-31 11:35-11:44 UTC, circuit open after three tries).
        """
        try:
            text = self.out.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None
        lines = [line.strip() for line in text.splitlines()]
        for at in range(len(lines) - 2, -1, -1):
            if lines[at] == _CLOSING_RULE:
                found = _MEASURED.findall(lines[at + 1])
                return float(found[0]) if found else None
        return None

    def seconds(self) -> float:
        """Intention: PATIENCE_TIMES its last length; unmeasured, the wide first patience."""
        minutes = self.last_minutes()
        if not minutes:
            return UNMEASURED_PATIENCE_S
        return max(60.0, minutes * 60.0 * PATIENCE_TIMES)


class Hung:
    """Intention: a gate past its patience ended with all its children, and the test it hung on named."""

    def __init__(self, root: Path) -> None:

        """Intention: keep the root the gate runs in, and the files it reads under state/diagnostics."""
        self.root = Path(root)
        self.diagnostics = self.root / "state" / "diagnostics"

    def end(self, process) -> None:
        """Intention: the gate and its pytest child ended; Windows by taskkill /T, elsewhere the group."""
        try:
            if os.name == "nt":
                from warp2.record.quiet import quiet
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(int(process.pid))],
                               capture_output=True, timeout=30, check=False, **quiet())
            else:
                os.killpg(process.pid, signal.SIGKILL)
        except (OSError, subprocess.SubprocessError):
            process.kill()
        try:
            process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass

    def note(self, waited: float) -> str:
        """Intention: which test it hung on and how long it was given, in preflight_hung.txt."""
        try:
            test = (self.diagnostics / "test_now.txt").read_text(encoding="utf-8").strip()
        except OSError:
            test = "unknown"
        said = (f"{time.strftime('%Y-%m-%d %H:%M:%S')} the prestart gate ran past its patience "
                f"({waited:.0f} s) and was ended; it was on: {test}\n")
        try:
            self.diagnostics.mkdir(parents=True, exist_ok=True)
            with open(self.diagnostics / "preflight_hung.txt", "a", encoding="utf-8") as out:
                out.write(said)
        except OSError:
            pass
        return said


class FailedGate:
    """Intention: keep a failed gate's output where no later gate run can write over it.

    Found 2026-11-09 (BUILD_LOG 1473/1474): the gate failed, triage set 15
    files aside and ran the gate again; the passing rerun wrote over
    tests.out.txt, so the failing test and its reason were lost and the set-
    aside could not be checked afterwards. Keep everything (Andrew).
    """

    def __init__(self, root: Path) -> None:
        """Intention: know where the gate writes its output and where the kept copies go."""
        diagnostics = Path(root) / "state" / "diagnostics"
        self.out = diagnostics / "tests.out.txt"
        self.latest = diagnostics / "tests.failed.txt"
        self.folder = diagnostics / "failed_gates"

    def keep(self) -> Path | None:
        """Intention: copy the failed output to tests.failed.txt and a dated copy; never raise."""
        try:
            text = self.out.read_bytes()
        except OSError:  # fault: ok - no gate output to keep; None tells the caller nothing was kept (BUILD_LOG 1477)
            return None
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            dated = self.folder / time.strftime("tests.failed-%Y%m%d-%H%M%S.txt")
            n = 1
            while dated.exists():
                dated = self.folder / time.strftime(f"tests.failed-%Y%m%d-%H%M%S-{n}.txt")
                n += 1
            dated.write_bytes(text)
            self.latest.write_bytes(text)
            print(f"[WARP2] gate failed; its output is kept in {dated}", flush=True)
            return dated
        except OSError as exc:
            print(f"[WARP2] gate failed; could not keep its output: {exc}", flush=True)
            return None


def passes(root: Path, state: Path | None = None) -> bool:
    """Whether the prestart regression gate passes in this tree.

    Intention: the very command the bat runs, from the tree's own folder, with
    no console window; its full output is already kept by run_tests.py in
    state/diagnostics/tests.out.txt, so nothing more is written here.
    Intention (BUILD_LOG 1005; Andrew, 2026-10-31: "reduce ability based of of
    said scores"): a gate that fails is tried again with the changes since the
    last good start set aside, the lowest-scoring builder's first
    (warp2/builders/triage.py); the gate passes if that makes it pass.
    """
    root = Path(root)
    if _gate_once(root):
        return True
    FailedGate(root).keep()
    try:
        from warp2.builders.triage import Triage
        report = Triage(root, Path(state) if state else root / "state").run(lambda: _gate_once(root))
        if report.get("set_aside"):
            print("[WARP2] gate: set aside " + "; ".join(
                f"{row['by']} ({', '.join(row['files'])})" for row in report["set_aside"])
                  + (" — gate passes now." if report["passed"] else " — gate still fails."), flush=True)
        return bool(report.get("passed"))
    except Exception as exc:  # noqa: BLE001 — the triage never makes a failed gate worse
        print(f"[WARP2] gate triage could not run: {type(exc).__name__}: {exc}", flush=True)
        return False


def _gate_once(root: Path) -> bool:
    """Intention: the gate run once, as the bat runs it."""
    from warp2.record.quiet import quiet
    root = Path(root)
    patience = Patience(root).seconds()
    group = {} if os.name == "nt" else {"start_new_session": True}
    process = subprocess.Popen([sys.executable, "-B", str(root / "run_tests.py"), "--preflight"],
                               cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, **group, **quiet())
    return _waited(root, process, patience)


def _waited(root: Path, process, patience: float, last_work=None) -> bool:
    """Intention (Andrew, 2026-11-09 22:41: "make the time constraints more adaptive and have it do checks for
    freezes. We should allow for long times"; BUILD_LOG 1490): PATIENCE BOUNDS STILLNESS, NOT WORK. The gate is
    waited for one patience; past it, it is read for work (warp2/record/working.py) and waited for again while it
    works, and ended as hung only once it has done none for a whole patience - or has used its set amount of
    compute (22:53: "All work on the warp should use a set amount of compute"): its patience on every processor."""
    work = None
    while True:
        try:
            return process.wait(timeout=patience) == 0
        except subprocess.TimeoutExpired:
            if work is None:
                if last_work is None:
                    from warp2.record.working import LastWork as last_work
                work = last_work(process.pid)
                continue
            from warp2.record.working import compute_for
            if work.still_for() < patience and work.spent() < compute_for(patience):
                print(f"[WARP2] the prestart gate is past its patience ({patience:.0f} s) and still working; "
                      "waiting on.", flush=True)
                continue
            hung = Hung(root)
            hung.end(process)
            print("[WARP2] " + hung.note(patience).strip(), flush=True)
            return False


def main(argv: list | None = None) -> int:
    """`python -m warp2.control.preflight ROOT [STATE]`: the gate, then the continuous run.

    Intention: one command a restart can start, so the gate cannot be
    skipped by whoever starts it. A failed gate returns 1 and starts nothing.
    """
    args = list(sys.argv[1:] if argv is None else argv)
    root = Path(args[0]) if args else Path.cwd()
    if not passes(root):
        print("[WARP2] Prestart regression failed. Runner was not started; "
              "see state\\diagnostics\\tests.failed.txt (first failure) "
              "and tests.out.txt (last try).", flush=True)
        return 1
    from warp2 import run
    where = ["--root", str(root)] + (["--state", str(args[1])] if len(args) > 1 else [])
    return int(run.main(["go", "--continuous"] + where) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
