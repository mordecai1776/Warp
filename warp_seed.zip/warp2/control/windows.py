# WARP2/warp2/control/windows.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/windows.py
#  Used by   : warp2/control/restart.py (the real hands of a restart).
#  Uses      : warp2/record/processes.py (who is registered, and alive),
#              warp2/control/preflight.py (what an automatic restart starts);
#              stdlib ctypes, json, os, subprocess.
#  Description:
#    What a restart needs from Windows, and nothing more: which of the warp's
#    own processes are running (from the registry, verified by start time, not
#    by name), the WARP2.bat loop a runner was started from, ending a process
#    politely or by force, and recovering the runner without touching the
#    user's desktop.
#    Kept apart so the restart's order can be tested with a stand-in.
#  User intention (Andrew, 2026-10-02): a full restart Claude can do alone
#    while he is away from home.
# ============================================================================
"""Windows process work for a remote restart."""
from __future__ import annotations

import ctypes
import json
import os
import subprocess

# Intention: the runner and its web lane are found in the process registry
# (verified by start time). The window does not register, so it is found by
# what it was told to run — only these exact module names, nothing broader.
RUNNER_ROLES = ("run",)
LANE_ROLES = ("web",)
WINDOW_COMMANDS = ("-m warp2.app", "-m warp2.ui.observer", "-m warp2.ask.window")
# Intention (BUILD_LOG 940): the web lane's own command, so a restart finds a lane that is there but no longer
# registered (one whose run ended and whose process stayed), not only the one on the register.
LANE_COMMANDS = ("-m warp2.run web",)

# Intention: the launcher's own settings are rebuilt by WARP2.bat; the
# watcher's copies are not handed down, so the new warp starts as a
# double-click would start it.
NOT_HANDED_DOWN = ("PYTHONPATH", "PYTHONPYCACHEPREFIX", "PYTHONDONTWRITEBYTECODE", "PYTHONHOME")

# Intention: the watcher has no window, and the small tools it asks
# (taskkill, powershell) must not flash one open each time.
QUIET = 0x08000000 if os.name == "nt" else 0
NEW_GROUP = 0x00000200

# Intention (Codex, 2026-11-01): tasklist timed out during a real restart.
# A zero-time handle wait reads liveness without a shell or a terminating right.
SYNCHRONIZE = 0x00100000
WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 0x102
ERROR_INVALID_PARAMETER = 87


def _process_api():
    """Intention: declare pointer-sized Windows handles before asking about a PID."""
    from ctypes import wintypes
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    api.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    api.OpenProcess.restype = wintypes.HANDLE
    api.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    api.WaitForSingleObject.restype = wintypes.DWORD
    api.CloseHandle.argtypes = (wintypes.HANDLE,)
    api.CloseHandle.restype = wintypes.BOOL
    return api


class WindowsHands:
    """Intention: each method is one thing a person at the machine would do."""

    def registered(self) -> list:
        """Running processes the warp registered: [{"pid", "role"}].

        Intention (2026-10-17): one the machine would not answer about in time
        (UNSURE) still counts — a slow answer under memory pressure made the
        watcher force-restart a live runner. Its beat still decides health.
        """
        from warp2.record.processes import Processes, RUNNING, UNSURE
        return [{"pid": int(r["pid"]), "role": str(r.get("role", ""))}
                for r in Processes().snapshot() if r.get("state") in (RUNNING, UNSURE)]

    def alive(self, pid: int) -> bool:
        """Intention: read process state immediately; an uncertain answer is never an exit."""
        pid = int(pid)
        if pid <= 0:
            return False
        api = _process_api()
        handle = api.OpenProcess(SYNCHRONIZE, False, pid)
        if not handle:
            error = ctypes.get_last_error()
            if error == ERROR_INVALID_PARAMETER:
                return False
            raise ctypes.WinError(error)
        try:
            waited = api.WaitForSingleObject(handle, 0)
            if waited == WAIT_TIMEOUT:
                return True
            if waited == WAIT_OBJECT_0:
                return False
            raise ctypes.WinError()
        finally:
            api.CloseHandle(handle)

    def _process(self, pid: int) -> dict | None:
        """Intention: one process's pid, parent, name and command line from PowerShell, or None if not found."""
        script = (f"Get-CimInstance Win32_Process -Filter 'ProcessId={int(pid)}' | "
                  "Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress")
        done = subprocess.run(["powershell", "-NoProfile", "-Command", script],
                              capture_output=True, text=True, timeout=30, creationflags=QUIET)
        try:
            found = json.loads(done.stdout or "null")
        except ValueError:
            return None
        return found if isinstance(found, dict) else None

    def by_command(self, fragments) -> list:
        """Pids of python processes whose command line holds one of `fragments`."""
        script = ("Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^pyw?(thonw?)?(\\.exe)?$' } | "
                  "Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress")
        done = subprocess.run(["powershell", "-NoProfile", "-Command", script],
                              capture_output=True, text=True, timeout=60, creationflags=QUIET)
        try:
            found = json.loads(done.stdout or "[]")
        except ValueError:
            return []
        found = [found] if isinstance(found, dict) else (found or [])
        return [int(p["ProcessId"]) for p in found
                if any(f in str(p.get("CommandLine") or "") for f in fragments)]

    def starting(self) -> list:
        """Pids of starts still in their regression gate (warp2/control/preflight.py).

        Intention (2026-10-25, BUILD_LOG 593): the supervisor waits for these
        instead of launching another start on top of them.
        """
        return self.by_command(("-m warp2.control.preflight",))

    def launcher_of(self, pid: int) -> int | None:
        """The cmd.exe running WARP2.bat that this process came from, or None.

        Intention: that loop restarts the runner when it ends, so it is ended
        first, or a restart would race it. Walks up at most a few parents
        (python.exe <- py.exe <- cmd.exe).
        """
        seen = self._process(pid)
        for _ in range(4):
            if not seen or not seen.get("ParentProcessId"):
                return None
            seen = self._process(int(seen["ParentProcessId"]))
            if not seen:
                return None
            name = str(seen.get("Name") or "").lower()
            line = str(seen.get("CommandLine") or "").lower()
            if name == "cmd.exe" and "warp2.bat" in line:
                return int(seen["ProcessId"])
        return None

    def end(self, pid: int, force: bool, tree: bool) -> str:
        """Intention: taskkill, politely (a window gets asked to close) or by force."""
        args = ["taskkill"] + (["/F"] if force else []) + (["/T"] if tree else []) + ["/PID", str(int(pid))]
        done = subprocess.run(args, capture_output=True, text=True, timeout=30, creationflags=QUIET)
        return (done.stdout or done.stderr or "").strip()[:200]

    def open_window(self, root) -> int:
        """Open the window alone, as WARP2.bat opens it; returns its pid.

        Intention: the same Python, module and search path the launcher
        uses (WARP2.bat sets PYTHONPATH to the tree and the two projects).
        """
        import sys
        from pathlib import Path
        root = Path(root)
        env = {k: v for k, v in os.environ.items() if k.upper() not in NOT_HANDED_DOWN}
        env["PYTHONPATH"] = os.pathsep.join(str(p) for p in (root, root / "projects" / "centering_image",
                                                             root / "projects" / "behemoth_eye"))
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        python = pythonw if pythonw.exists() else Path(sys.executable)
        child = subprocess.Popen([str(python), "-B", "-m", "warp2.app", str(root)],
                                 cwd=str(root), env=env, creationflags=QUIET | NEW_GROUP, close_fds=True)
        return int(child.pid)

    def launch(self, root, *, headless: bool = False) -> int:
        """Launch a restart; automatic recovery is runner-only and windowless."""
        from pathlib import Path
        import sys

        root = Path(root)
        env = {k: v for k, v in os.environ.items() if k.upper() not in NOT_HANDED_DOWN}
        diagnostics = root / "state" / "diagnostics"
        diagnostics.mkdir(parents=True, exist_ok=True)
        if headless:
            paths = (root, root / "projects" / "centering_image", root / "projects" / "behemoth_eye")
            env["PYTHONPATH"] = os.pathsep.join(
                [*(str(path) for path in paths), *([env["PYTHONPATH"]] if env.get("PYTHONPATH") else [])]
            )
            env["PYTHONDONTWRITEBYTECODE"] = "1"
            if env.get("LOCALAPPDATA"):
                env.setdefault("PYTHONPYCACHEPREFIX", str(Path(env["LOCALAPPDATA"]) / "WARP2" / "pycache"))
            python = Path(sys.executable).with_name("python.exe")
            if not python.exists():
                python = Path(sys.executable)
            with (diagnostics / "restart-launch.stderr.log").open("ab") as errors:
                # Intention (2026-10-09, check F5): the restart runs the same
                # prestart regression gate the bat runs, then the continuous
                # run; a failed gate starts nothing (warp2/control/preflight.py).
                child = subprocess.Popen(
                    [str(python), "-B", "-m", "warp2.control.preflight", str(root)],
                    cwd=str(root), env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                    stderr=errors, creationflags=QUIET | NEW_GROUP, close_fds=True,
                )
            return int(child.pid)

        with (diagnostics / "restart-launch.stderr.log").open("ab") as errors:
            child = subprocess.Popen(["cmd.exe", "/d", "/c", "WARP2.bat"], cwd=str(root), env=env,
                                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=errors,
                                     creationflags=QUIET | NEW_GROUP, close_fds=True)
        return int(child.pid)
