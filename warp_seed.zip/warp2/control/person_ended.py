# WARP2/warp2/control/person_ended.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/person_ended.py
#  Used by   : warp2/run.py (`_go_owned`: a continuous run says a person ended
#              it — Ctrl+C or the console closed).
#  Uses      : warp2/control/files.py (ControlFiles.expected); stdlib signal,
#              sys.
#  Description:
#    When a person ends a continuous run, the "a runner is expected" mark is
#    taken down, so the restart watcher does not start a hidden runner again.
#    A crash leaves the mark up, so the watcher still recovers from that.
#  User intention (Andrew, 2026-10-08 and 10-09): "I closed it out" — closed
#    means closed. Found 2026-10-09 (check F1): WARP2.bat writes
#    state/control/run.expected and nothing removed it, so after Ctrl+C or a
#    closed console the watcher restarted a hidden runner 10-15 s later.
# ============================================================================
"""Taking down the "runner expected" mark when a person ends the run."""
from __future__ import annotations

import signal
import sys
from pathlib import Path

from warp2.control.files import ControlFiles


def withdraw(state: Path) -> bool:
    """Take down the "runner expected" mark; whether one was there.

    Intention: the one thing a person ending the run must change, so the
    watcher's next look finds nothing expected and starts nothing.
    """
    mark = ControlFiles(Path(state)).expected
    try:
        mark.unlink()
        return True
    except FileNotFoundError:
        return False


class ConsoleClose:
    """Withdraw the mark when the console window is closed (Windows).

    Intention: closing the console sends CTRL_CLOSE_EVENT, which Python turns
    into SIGBREAK on Windows; the process has a few seconds before it is
    ended, enough to take the mark down. Elsewhere there is no such event and
    this does nothing. The handler it replaced is put back on `restore`.
    """

    def __init__(self, state: Path) -> None:
        """Intention: keep the state folder, room for the handler it replaces, and the console-close signal (Windows only)."""
        self.state = Path(state)
        self.before = None
        self.signal = getattr(signal, "SIGBREAK", None) if sys.platform == "win32" else None

    def watch(self) -> "ConsoleClose":
        """Intention: start listening for the console closing; safe to call where there is no console."""
        if self.signal is not None:
            try:
                self.before = signal.signal(self.signal, self._closed)
            except (ValueError, OSError):  # not the main thread, or no console
                self.signal = None
        return self

    def restore(self) -> None:
        """Intention: put back whatever handled the event before, so nothing outlives the run."""
        if self.signal is not None and self.before is not None:
            signal.signal(self.signal, self.before)

    def _closed(self, *_unused) -> None:
        """Intention: the console is closing — withdraw the mark, then end as a person asked."""
        withdraw(self.state)
        raise KeyboardInterrupt("the console was closed")
