# WARP2/warp2/control/watcher_service.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/watcher_service.py
#  Used by   : the WARP2 Restart Watcher scheduled task.
#  Uses      : warp2/control/watcher.py; stdlib subprocess, sys, time, pathlib.
#  Description:
#    Keep the watcher worker under the scheduled task's process supervision,
#    restarting it after source changes or unexpected exits with bounded waits.
#  User intention: restart assistance must remain alive across watcher updates
#    and ordinary worker failures without creating detached orphan processes.
#    (2026-10-18) A worker that will not die after a kill must not hold the
#    service too: the wait after a kill is bounded, the worker is let go and
#    noted in state/control/watcher-abandoned.jsonl, and a new worker starts.
#    (2026-10-18) The service leaves its own trace (warp2/control/
#    service_trace.py): a lives log and a rolling beat, so its own death is
#    on the record (BUILD_LOG 334).
#    (2026-10-25) A worker whose last beat says "restarting" gets its own,
#    longer window (RESTARTING_STALE) before it is ended: the restart is the
#    cure for paging, and under paging even the side-thread beat can stall
#    past 60 s (17:00 UTC try lost, BUILD_LOG 630/633). The window has a hard
#    end, and each window is written to the lives log (Muse-578).
#    (2026-10-25) Before a stale worker is ended, the runner's own beat is
#    read once and the lives log says whether the warp was alive then, as its
#    own line — so a watcher replacement is never misread as a warp failure,
#    and a silent warp is never hidden inside a watcher line. The check only
#    writes the record; it never holds the ending back (Muse-579).
# ============================================================================
"""Supervise the watcher worker for the lifetime of its scheduled task."""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

from warp2.control.service_trace import ServiceTrace
from warp2.util import atomic_write_bytes

MAX_BACKOFF = 60.0
HEARTBEAT_STALE = 60.0
# A beat whose note is "restarting" may be silent this long before the worker
# is ended. Hard end; the silence is logged so the real gaps get measured.
RESTARTING_STALE = 300.0
START_GRACE = 60.0
POLL_SECONDS = 5.0
RESTART_WATCHER = 75
MAX_FAILURES = 3
FAILURE_WINDOW_SECONDS = 1800.0
STABLE_SECONDS = 300.0
# How long to wait for a killed worker to go. On Windows a process stuck in a
# file call (OneDrive) cannot finish dying until that call returns; waiting
# with no limit held the service as well (seen 2026-10-17, 22:57-00:35 UTC).
KILL_WAIT = 30.0


def _note_abandoned(root: Path, child) -> None:
    """Intention: a worker that did not die after a kill is let go, and the record says so,
    so a later new worker is not a mystery. The kill stays queued; Windows ends it when its call returns."""
    line = json.dumps({"when": round(time.time(), 3), "pid": getattr(child, "pid", None),
                       "waited_s": KILL_WAIT, "what": "killed worker did not exit; started a new one"})
    try:
        path = root / "state" / "control" / "watcher-abandoned.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as out:
            out.write(line + "\n")
    except OSError:
        pass


class _RestartWindow:
    """Intention: remember one silent "restarting" beat window, so the lives
    log records when it opened and how it ended (beat back, or worker ended)."""

    def __init__(self, trace: ServiceTrace):
        """Intention: retain the service trace and begin with no silent restart window."""
        self._trace = trace
        self._since: float | None = None

    def limit(self, note: str) -> float:
        """Intention: how long this beat may stay silent, by what it says it is doing."""
        return RESTARTING_STALE if note == "restarting" else HEARTBEAT_STALE

    def see(self, note: str, age: float, at: float, pid) -> None:
        """Intention: open the window when a restarting beat passes the normal limit;
        close it, with the measured silence, when the beat comes back."""
        if note == "restarting" and age >= HEARTBEAT_STALE:
            if self._since is None:
                self._since = at
                self._trace.line("restarting beat silent; window open", worker_pid=pid,
                                 silent_since=round(at, 3), window_s=RESTARTING_STALE)
        elif self._since is not None and age < HEARTBEAT_STALE:
            self._trace.line("restarting beat back", worker_pid=pid,
                             silent_s=round(at - self._since, 1))
            self._since = None

    def ending(self, pid) -> None:
        """Intention: a window that ran out is on the record as such."""
        if self._since is not None:
            self._trace.line("restarting window ran out; ending worker", worker_pid=pid,
                             silent_s=round(time.time() - self._since, 1))


def _note_warp_at_end(root: Path, trace: ServiceTrace, worker_pid) -> None:
    """Intention: one read of the runner's beat (state/lanes/card.beat) when a
    stale watcher is about to be ended, written as its own lives-log line:
    "warp alive" when that beat is fresh, "runner beat stale too" when it is
    not, "runner beat unreadable" when it cannot be read. Record only."""
    try:
        parts = (root / "state" / "lanes" / "card.beat").read_text(encoding="utf-8").split()
        runner_pid, age = int(parts[0]), round(time.time() - float(parts[1]), 1)
    except (OSError, ValueError, IndexError) as exc:
        trace.line("runner beat unreadable as watcher is ended", worker_pid=worker_pid,
                   error=type(exc).__name__)
        return
    what = ("warp alive as watcher is ended" if 0.0 <= age < HEARTBEAT_STALE
            else "runner beat stale too as watcher is ended")
    trace.line(what, worker_pid=worker_pid, runner_pid=runner_pid, runner_beat_age_s=age)


def _read_beat(beat: Path):
    """Intention: the worker's beat as (pid, epoch, note); note is "" if absent."""
    parts = beat.read_text(encoding="utf-8").split()
    return int(parts[0]), float(parts[1]), (parts[2] if len(parts) > 2 else "")


def _watch_worker(child, root: Path, *, sleep, clock, trace: ServiceTrace | None = None) -> int:
    """Wait for the child, terminating it if its heartbeat stops advancing.
    Intention (2026-10-18): the service beats its own trace while it waits.
    (2026-10-25) A "restarting" beat gets the longer, logged window."""
    trace = trace or ServiceTrace(root, clock=clock)
    poll = getattr(child, "poll", None)
    if not callable(poll):
        return int(child.wait())
    started = clock()
    beat = root / "state" / "control" / "watcher.beat"
    window = _RestartWindow(trace)
    while True:
        trace.beat_now()
        code = poll()
        if code is not None:
            return int(code)
        try:
            pid, at, note = _read_beat(beat)
            age = time.time() - at
            mine = pid == int(child.pid)
            if mine:
                window.see(note, age, at, pid)
            fresh = mine and 0.0 <= age < window.limit(note)
        except (OSError, ValueError, TypeError, IndexError):
            fresh = False
        if not fresh and clock() - started >= START_GRACE:
            window.ending(getattr(child, "pid", None))
            _note_warp_at_end(root, trace, getattr(child, "pid", None))
            trace.line("worker beat stale; ending it", worker_pid=getattr(child, "pid", None))
            child.terminate()
            try:
                child.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                child.kill()
                try:
                    child.wait(timeout=KILL_WAIT)
                except subprocess.TimeoutExpired:
                    _note_abandoned(root, child)
            return 1
        sleep(POLL_SECONDS)


def supervise(root: Path | str, *, popen=None, sleep=time.sleep,
              clock=time.monotonic, once: bool = False) -> int:
    """Run a managed worker with bounded retries; stop cleanly if it keeps failing."""
    root = Path(root).resolve()
    spawn = popen or subprocess.Popen
    backoff = 1.0
    failures: list[float] = []
    trace = ServiceTrace(root, clock=clock)
    trace.line("service started")
    while True:
        started = clock()
        try:
            child = spawn([sys.executable, "-B", "-m", "warp2.control.watcher",
                           str(root), "--managed"], cwd=str(root), close_fds=True)
            trace.line("worker started", worker_pid=getattr(child, "pid", None))
            code = _watch_worker(child, root, sleep=sleep, clock=clock, trace=trace)
            trace.line("worker ended", worker_pid=getattr(child, "pid", None), code=code)
        except OSError as exc:
            trace.line("worker could not start", why=f"{type(exc).__name__}: {exc}")
            code = 1
        if code == RESTART_WATCHER:
            backoff = 1.0
            continue
        if code == 0:
            trace.line("service stopped", why="worker ended cleanly")
            return 0
        if once:
            trace.line("service stopped", why="ran once", code=code)
            return code
        now = clock()
        if now - started >= STABLE_SECONDS:
            backoff = 1.0
            failures.clear()
        failures = [at for at in failures if 0.0 <= now - at < FAILURE_WINDOW_SECONDS]
        failures.append(now)
        if len(failures) >= MAX_FAILURES:
            control = root / "state" / "control"
            atomic_write_bytes(
                control / "watcher-service.json",
                (f'{{"state":"circuit_open","failures":{len(failures)},'
                 f'"window_seconds":{int(FAILURE_WINDOW_SECONDS)},"when":{time.time():.3f}}}\n')
                .encode("utf-8"),
            )
            trace.line("service stopped", why="circuit open", failures=len(failures))
            return 0
        sleep(backoff)
        backoff = min(MAX_BACKOFF, backoff * 2.0)


if __name__ == "__main__":
    args = [value for value in sys.argv[1:] if not value.startswith("--")]
    raise SystemExit(supervise(args[0] if args else Path.cwd(), once="--once" in sys.argv))
