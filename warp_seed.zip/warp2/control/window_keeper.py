# WARP2/warp2/control/window_keeper.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/window_keeper.py
#  Used by   : warp2/control/watcher.py (each look),
#              warp2/control/tests/test_the_window_is_kept_open_on_a_nexus.py.
#  Uses      : warp2/control/windows.py (WINDOW_COMMANDS; WindowsHands.by_command
#              — which window processes are running), warp2/control/bat_request.py
#              (BatAsk, BatStart — the window started through OPEN_WINDOW.bat,
#              so a crash's words reach state/diagnostics/window.out.txt),
#              warp2/util.py (atomic_write_bytes); (stdlib) json, time, pathlib.
#  Description:
#    On a nexus the window is always open. The watcher asks this each look:
#    when this machine is a nexus (state/seed/bloom.json, written by the seed's
#    hardware fit) and no window process is running, OPEN_WINDOW.bat is
#    started. The process list is read at most once a watcher's STALE time
#    (the watcher's own measure of "gone"), because one read can take seconds.
#    A window that keeps dying is not started in a tight loop: each start that
#    did not leave a window running doubles the wait before the next, and the
#    first time a window is seen running the count starts again.
#    What it did is kept in state/control/window_keeper.json.
#    A process list that does not answer in time (Windows under low memory;
#    BUILD_LOG 1251) is a look that found nothing to act on: it is written
#    down and counted as a look, so the next read waits a STALE as any read
#    does, instead of a raised error and a new 60 s read on every look.
#    BUILD_LOG 1585: a window process that shows no window is not an open
#    window. It is waited for (a STALE, doubled for each start that did not
#    stay), then ended, and a new window is started.
#  User intention (Andrew, 2026-11-02 01:01): "I always want the window open
#    on a nexus."
# ============================================================================
from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path

WINDOW_BAT = "OPEN_WINDOW.bat"


class Nexus:
    """Intention: whether this machine is a nexus, as the seed's hardware fit recorded it."""

    def __init__(self, state: Path) -> None:
        """Intention: the state folder; the fit is in state/seed/bloom.json."""
        self.path = Path(state) / "seed" / "bloom.json"

    def here(self) -> bool:
        """Intention: True when the recorded plan says nexus; no record is no nexus (a nexus has always bloomed)."""
        try:
            plan = json.loads(self.path.read_text(encoding="utf-8")).get("plan") or {}
        except (OSError, ValueError, AttributeError):
            return False
        return bool(plan.get("is_nexus")) or str(plan.get("tier") or "") == "nexus"


class KeeperRecord:
    """Intention: state/control/window_keeper.json — when it last looked, last started a window, and how many in a row did not stay."""

    def __init__(self, control: Path) -> None:
        """Intention: the control folder."""
        self.path = Path(control) / "window_keeper.json"

    def read(self) -> dict:
        """Intention: the record, or a fresh one."""
        try:
            return {"looked": 0.0, "started": 0.0, "seen": 0.0, "failed": 0, **json.loads(self.path.read_text("utf-8"))}
        except (OSError, ValueError, TypeError):
            return {"looked": 0.0, "started": 0.0, "seen": 0.0, "failed": 0}

    def write(self, row: dict) -> None:
        """Intention: written whole."""
        from warp2.util import atomic_write_bytes
        atomic_write_bytes(self.path, json.dumps(row, indent=1).encode("utf-8"))


class WindowKeeper:
    """Keeps the window open on a nexus.

    Intention: `hands` lists window processes (WindowsHands); `start` starts
    OPEN_WINDOW.bat (BatStart unless a test gives one); `clock` is time.time.
    """

    def __init__(self, root: Path, files, hands=None, start=None, clock=None) -> None:
        """Intention: the tree, the control files, and the three things it acts through."""
        self.root = Path(root)
        self.files = files
        self.hands = hands
        self.start = start
        self.clock = clock or time.time
        self.record = KeeperRecord(files.dir)

    def every(self) -> float:
        """Intention: how often the process list is read — the watcher's own STALE, its measure of "gone"."""
        from warp2.control.watcher import STALE
        return float(STALE)

    def look(self) -> dict:
        """Intention: on a nexus with no window, start one, no sooner than the doubling wait allows; what it did."""
        if not Nexus(self.files.state).here():
            return {"did": "not a nexus"}
        row = self.record.read()
        now = self.clock()
        if now - float(row["looked"]) < self.every():
            return {"did": "waited", "next_look_in": round(self.every() - (now - float(row["looked"])), 1)}
        row["looked"] = now
        try:
            running = self._windows()
        except subprocess.TimeoutExpired:
            # Intention (BUILD_LOG 1251): a slow process list is not a missing window; nothing is started on it.
            row.update({"slow": int(row.get("slow") or 0) + 1, "last_slow": now})
            self.record.write(row)
            return {"did": "process list too slow", "slow": row["slow"]}
        if running:
            # Intention (BUILD_LOG 1585): A WINDOW PROCESS IS NOT A WINDOW. On 2026-11-12 one had run for 33 hours
            # with nothing on the screen, and was counted as open the whole time. It is open when it can be seen.
            if self._showing(running):
                row.update({"seen": now, "failed": 0, "hidden_since": 0.0})
                self.record.write(row)
                return {"did": "open", "pids": running}
            # Intention: a window just started has nothing to show yet, so one that cannot be seen is waited for -
            # one STALE, doubled for each start that did not stay (the same wait a dying window gets) - then ended,
            # and a new one is started below.
            hidden_since = float(row.get("hidden_since") or 0.0) or now
            patience = self.every() * (2 ** int(row["failed"]))
            if now - hidden_since < patience:
                row["hidden_since"] = hidden_since
                self.record.write(row)
                return {"did": "waiting for the window to show", "pids": running, "patience": patience}
            row.update({"hidden_since": 0.0, "ended_unseen": self._end(running), "ended_unseen_at": now})
        # Intention: the last start did not stay when no window has been seen since it; it counts once, when the next
        # start is made, so the count is starts that did not stay, not looks.
        failed = int(row["failed"]) + (1 if float(row["started"]) > float(row["seen"]) else 0)
        wait = self.every() * (2 ** (failed - 1)) if failed else 0.0
        if now - float(row["started"]) < wait:
            self.record.write(row)
            return {"did": "waiting to start again", "failed": failed, "wait": wait}
        said = self._start()
        row.update({"started": now, "failed": failed, "last": said})
        self.record.write(row)
        return {"did": "started", **said}

    def _windows(self) -> list:
        """Intention: the pids of window processes running now."""
        from warp2.control.windows import WINDOW_COMMANDS
        return list(self._hands().by_command(WINDOW_COMMANDS))

    def _hands(self):
        """Intention: the hands given, or the real ones."""
        if self.hands is None:
            from warp2.control.windows import WindowsHands
            self.hands = WindowsHands()
        return self.hands

    def _showing(self, running: list) -> list:
        """Intention: of the window processes, the ones with a window on the screen. Hands that cannot say (a
        stand-in, or a machine that is not Windows) leave every running one counted as showing, as before."""
        showing = getattr(self._hands(), "showing", None)
        return list(showing(running)) if callable(showing) else list(running)

    def _end(self, running: list) -> list:
        """Intention: each window process that showed nothing ended, by force, with what it started; what was ended."""
        ended = []
        for pid in running:
            try:
                self._hands().end(int(pid), force=True, tree=True)
                ended.append(int(pid))
            except (OSError, subprocess.SubprocessError):
                continue
        return ended

    def _start(self) -> dict:
        """Intention: OPEN_WINDOW.bat started, as the watcher starts any .bat it is asked to run."""
        from warp2.control.bat_request import BatAsk, BatStart
        ask = BatAsk(self.root, WINDOW_BAT)
        why = ask.refused()
        if why:
            return {"outcome": "refused", "why": why}
        if self.start is not None:
            return self.start(ask)
        return BatStart(self.files.state).start(ask)
