# WARP2/warp2/control/ending.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/ending.py
#  Used by   : warp2/run.py (_go_owned: started the moment the run is over,
#              before the closing-down begins).
#  Uses      : warp2/record/heartbeat.py (SILENT_SECONDS — the one silence
#              bound the warp already has), stdlib faulthandler, os,
#              threading, time.
#  Description:
#    THE END OF THE RUN IS THE END OF THE PROCESS. When the run is over the
#    process closes down (the keeper, the beat, the machine, the ownership
#    lock) and then Python ends — unless something in that closing-down waits
#    for ever, or a thread that is not a daemon keeps the interpreter alive.
#    Measured 2026-10-29 18:32 UTC: the run ended ("the source changed",
#    Codex 933), the session sealed, the runner unregistered — and the
#    process stayed. The restart watcher saw a process still running the
#    start command and waited on it as a start-in-gate (20 minutes), with
#    both lanes down. Every restart in the log says "forced": the runner has
#    never once ended on its own.
#    This is the last thing a run does: a daemon thread that, once the run is
#    over, gives the closing-down the silence bound, then writes where every
#    thread is (state/diagnostics/exit_stacks.txt — so the next hang says
#    where it is) and ends the process with the run's own exit code. A normal
#    end gets there first and the thread dies with the interpreter.
#  User intention (Andrew, 2026-10-29): "hey fix the warp first something is
#    wrong with it." Andrew (2026-09-24): "there should not be a time out just
#    a check to make sure it is still running" — this is not a time out on
#    work: the work is over; it is the check that an ended run ends.
# ============================================================================
"""An ended run ends its process."""
from __future__ import annotations

import faulthandler
import os
import threading
import time
from pathlib import Path


def stacks_path(state) -> Path:
    """Intention: where the threads of a process that would not end are written."""
    return Path(state) / "diagnostics" / "exit_stacks.txt"


class Ending:
    """Intention: once the run is over, the process ends — on its own if it can, by this if it cannot."""

    def __init__(self, state, code: int) -> None:
        """Intention: keep where to write the stacks and the exit code the run chose."""
        self.state = Path(state)
        self.code = int(code)

    def _patience(self) -> float:
        """Intention: the closing-down gets the warp's one silence bound, no number of its own."""
        from warp2.record.heartbeat import SILENT_SECONDS
        return float(SILENT_SECONDS)

    def _write_stacks(self, waited: float) -> None:
        """Intention: every thread, as it is, so the hang can be read — a failed write never stops the end."""
        try:
            path = stacks_path(self.state)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "wb") as out:
                out.write((f"the run ended but process {os.getpid()} was still here {waited:.0f} s later; "
                           f"every thread, as it was at {time.strftime('%Y-%m-%d %H:%M:%S')}:\n\n").encode())
                faulthandler.dump_traceback(file=out, all_threads=True)
                out.flush()
        except Exception:  # noqa: BLE001 — the end comes whether or not it could be written down
            pass

    def _wait_then_end(self) -> None:
        """Intention: the body of the thread — wait the bound, write the stacks, end the process."""
        began = time.monotonic()
        time.sleep(self._patience())
        self._write_stacks(time.monotonic() - began)
        os._exit(self.code)

    def start(self) -> threading.Thread:
        """Intention: the thread, a daemon, so a normal end is not held up by it."""
        thread = threading.Thread(target=self._wait_then_end, name="run-ending", daemon=True)
        thread.start()
        return thread
