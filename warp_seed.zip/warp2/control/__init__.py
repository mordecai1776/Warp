# WARP2/warp2/control/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/__init__.py
#  Used by   : warp2/control/watcher.py and its parts.
#  Uses      : nothing.
#  Description:
#    Remote control of the warp from outside the machine: a small watcher on
#    Windows takes a request file and does a full restart (runner, window,
#    fresh bytecode), then writes down what happened.
#  User intention (Andrew, 2026-10-02): "we need to make a program that you
#    can run from here that will cause a full restart for tomorrow I will be
#    working away from home and need you to be able to do that on your own"
# ============================================================================
