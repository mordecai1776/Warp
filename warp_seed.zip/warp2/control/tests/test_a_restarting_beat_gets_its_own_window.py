# WARP2/warp2/control/tests/test_a_restarting_beat_gets_its_own_window.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_a_restarting_beat_gets_its_own_window.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs with a plain runner.
#  Uses      : warp2/control/watcher_service.py (_watch_worker, RESTARTING_STALE).
#  Description:
#    2026-10-25 17:01 UTC: watcher 18548 was in the middle of a restart, the
#    machine was paging, its "restarting" beat went silent past 60 s, and
#    watcher_service ended it; the restart was lost. A beat that says
#    "restarting" now gets a longer window with a hard end, and the window is
#    written to the lives log (BUILD_LOG 633, Muse-578).
#  User intention (Andrew, 2026-10-02): a restart watcher he can trust while
#    he is away; (2026-10-16) the warp must never stay down.
# ============================================================================
from __future__ import annotations

import tempfile
import time
from pathlib import Path

import warp2.control.watcher_service as service


class _Worker:
    """Intention: a live worker that exits cleanly after a set number of polls,
    and whose beat file can be rewritten between polls."""
    pid = 5151

    def __init__(self, exit_after: int, on_poll=None):
        self.polls = 0
        self.exit_after = exit_after
        self.on_poll = on_poll
        self.terminated = False

    def poll(self):
        self.polls += 1
        if self.on_poll:
            self.on_poll(self.polls)
        return 0 if self.polls > self.exit_after else None

    def terminate(self):
        self.terminated = True

    def kill(self):
        self.terminated = True

    def wait(self, timeout=None):
        return 1


def _root(tmp_path) -> Path:
    """Intention: a fresh folder per test, pytest's or our own."""
    root = Path(tmp_path) if tmp_path else Path(tempfile.mkdtemp(prefix="w2_window_"))
    (root / "state" / "control").mkdir(parents=True, exist_ok=True)
    return root


def _beat(root: Path, age: float, note: str, pid: int = 5151) -> None:
    """Intention: write the worker's beat as if it was last written `age` seconds ago."""
    (root / "state" / "control" / "watcher.beat").write_text(
        f"{pid} {time.time() - age:.3f} {note}\n", encoding="utf-8")


def _run(root: Path, child) -> int:
    """Intention: run the check on a clock that moves only when it sleeps."""
    now = [0.0]

    def sleep(seconds):
        now[0] += seconds

    return service._watch_worker(child, root, sleep=sleep, clock=lambda: now[0])


def _lives(root: Path) -> str:
    """Intention: everything the service wrote to its lives log."""
    path = root / "state" / "control" / "watcher-service.lives.jsonl"
    return path.read_text(encoding="utf-8") if path.exists() else ""


def test_a_restarting_beat_silent_for_two_minutes_is_not_ended(tmp_path=None):
    """Intention: the 17:01 case — 120 s silent while restarting — the worker lives on."""
    root = _root(tmp_path)
    _beat(root, 120.0, "restarting")
    child = _Worker(exit_after=40)
    assert _run(root, child) == 0
    assert not child.terminated
    assert "window open" in _lives(root)


def test_the_window_has_a_hard_end(tmp_path=None):
    """Intention: a restarting beat silent past the window is still ended, and logged as such."""
    root = _root(tmp_path)
    _beat(root, service.RESTARTING_STALE + 60.0, "restarting")
    child = _Worker(exit_after=1000)
    assert _run(root, child) == 1
    assert child.terminated
    assert "window ran out" in _lives(root)


def test_a_normal_beat_keeps_the_short_limit(tmp_path=None):
    """Intention: only "restarting" gets the window; a stale "watching" beat is ended as before."""
    root = _root(tmp_path)
    _beat(root, 120.0, "watching")
    child = _Worker(exit_after=1000)
    assert _run(root, child) == 1
    assert child.terminated


def test_the_measured_silence_is_logged_when_the_beat_comes_back(tmp_path=None):
    """Intention: a window that closes because the beat came back records how long it was silent."""
    root = _root(tmp_path)
    _beat(root, 120.0, "restarting")

    def back(polls):
        if polls == 10:
            _beat(root, 0.0, "restarting")

    child = _Worker(exit_after=20, on_poll=back)
    assert _run(root, child) == 0
    assert "restarting beat back" in _lives(root)
    assert "silent_s" in _lives(root)
