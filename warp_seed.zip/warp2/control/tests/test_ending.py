# WARP2/warp2/control/tests/test_ending.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_ending.py
#  Used by   : pytest (warp2/run_tests.py).
#  Uses      : warp2/control/ending.py (Ending).
#  Description: an ended run that is still here past the silence bound writes its threads and ends the process
#    with the run's code; a normal end is not held up (the thread is a daemon) (BUILD_LOG 934).
#  User intention (Andrew, 2026-10-29): "hey fix the warp first something is wrong with it."
# ============================================================================
"""The end of the run is the end of the process."""
import subprocess
import sys
import textwrap

from warp2.control import ending


def test_the_thread_is_a_daemon_so_a_normal_end_is_not_held(tmp_path, monkeypatch):
    monkeypatch.setattr(ending.Ending, "_patience", lambda self: 60.0)
    thread = ending.Ending(tmp_path, 3).start()
    assert thread.daemon and thread.is_alive()


def test_a_process_that_will_not_end_is_ended_with_the_stacks_written(tmp_path):
    """Intention: a child whose non-daemon thread would hold the interpreter for ever ends with code 3 and
    leaves exit_stacks.txt — run as a real process, because os._exit is the thing under test."""
    code = textwrap.dedent(f"""
        import threading, time, sys
        sys.path.insert(0, {str(ending.Path(__file__).resolve().parents[3])!r})
        from warp2.control.ending import Ending
        Ending._patience = lambda self: 0.2
        threading.Thread(target=lambda: time.sleep(600)).start()   # not a daemon: holds the interpreter
        Ending({str(tmp_path)!r}, 3).start()
    """)
    done = subprocess.run([sys.executable, "-c", code], timeout=60, capture_output=True)
    assert done.returncode == 3, done.stderr.decode(errors="replace")
    text = ending.stacks_path(tmp_path).read_text(encoding="utf-8", errors="replace")
    assert "was still here" in text and "Thread" in text
