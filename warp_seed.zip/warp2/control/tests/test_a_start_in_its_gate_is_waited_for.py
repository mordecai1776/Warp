# WARP2/warp2/control/tests/test_a_start_in_its_gate_is_waited_for.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_a_start_in_its_gate_is_waited_for.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/control/{files,supervisor}.py with a stand-in for Windows
#              (no process is touched).
#  Description:
#    While a start is still in its regression gate, the supervisor waits for
#    it instead of launching another start; a gate hung past the patience no
#    longer holds a restart back, and is ended (whole tree, by force) before
#    the new start goes (BUILD_LOG 824).
#  User intention (Andrew, 2026-10-07 / 2026-10-16): keep the warp running
#    and recoverable on its own. Found 2026-10-25 (BUILD_LOG 593): a 10-minute
#    gate made the watcher start three more on top of it (~3.6 GB each), with
#    no runner for half an hour.
# ============================================================================
from __future__ import annotations

import json

from warp2.control.files import ControlFiles


class _Clock:
    """Intention: time that moves only when told."""
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now


class _Hands:
    """Intention: a pretend Windows with no runner and, if asked, one start in its gate."""
    def __init__(self, gates):
        self.gates = list(gates)
        self.ended = []

    def registered(self):
        return []

    def starting(self):
        return list(self.gates)

    def end(self, pid, force, tree):
        """Intention: a pretend taskkill that remembers what it was asked to end."""
        self.ended.append((pid, force, tree))
        self.gates = [g for g in self.gates if g != pid]
        return "ended"


def _files(tmp_path, monkeypatch):
    """Intention: control files for a run that is expected but has no runner."""
    monkeypatch.setenv("WARP2_RUNTIME_DIR", str(tmp_path / "runtime"))
    files = ControlFiles(tmp_path / "state")
    files.ready()
    files.expected.write_text("expected", encoding="utf-8")
    return files


def _observe_until_due(supervisor, files, hands):
    """Intention: the answer once enough misses were seen to decide."""
    from warp2.control.supervisor import MISSING_OBSERVATIONS
    asked = None
    for _ in range(MISSING_OBSERVATIONS):
        asked = supervisor.observe(files, hands)
    return asked


def test_a_start_in_its_gate_is_not_started_again(tmp_path, monkeypatch):
    from warp2.control.supervisor import RunnerSupervisor
    files = _files(tmp_path, monkeypatch)
    clock = _Clock()
    supervisor = RunnerSupervisor(clock=clock)
    assert _observe_until_due(supervisor, files, _Hands([3436])) is None
    saved = json.loads(files.supervision.read_text(encoding="utf-8"))
    assert saved["state"] == "starting" and saved["attempts"] == 0


def test_a_gate_hung_past_the_patience_lets_a_restart_go(tmp_path, monkeypatch):
    from warp2.control.supervisor import GATE_PATIENCE_SECONDS, RunnerSupervisor
    files = _files(tmp_path, monkeypatch)
    clock = _Clock()
    supervisor = RunnerSupervisor(clock=clock)
    hands = _Hands([3436])
    assert _observe_until_due(supervisor, files, hands) is None
    clock.now += GATE_PATIENCE_SECONDS + 1
    asked = _observe_until_due(supervisor, files, hands)
    assert asked and asked["why"].startswith("supervisor:")


def test_with_no_gate_running_the_restart_goes_as_before(tmp_path, monkeypatch):
    from warp2.control.supervisor import RunnerSupervisor
    files = _files(tmp_path, monkeypatch)
    supervisor = RunnerSupervisor(clock=_Clock())
    asked = _observe_until_due(supervisor, files, _Hands([]))
    assert asked and asked["automatic"] is True


def test_a_gate_hung_past_the_patience_is_ended_before_the_new_start(tmp_path, monkeypatch):
    """Intention (BUILD_LOG 824): the hung gate does not keep running beside the new start."""
    from warp2.control.supervisor import GATE_PATIENCE_SECONDS, RunnerSupervisor
    files = _files(tmp_path, monkeypatch)
    clock = _Clock()
    supervisor = RunnerSupervisor(clock=clock)
    hands = _Hands([3436])
    assert _observe_until_due(supervisor, files, hands) is None
    assert hands.ended == []
    clock.now += GATE_PATIENCE_SECONDS + 1
    asked = _observe_until_due(supervisor, files, hands)
    assert asked and hands.ended == [(3436, True, True)]
    saved = json.loads(files.supervision.read_text(encoding="utf-8"))
    assert saved["gates_ended"][0]["pid"] == 3436
