# WARP2/warp2/control/tests/test_the_window_is_kept_open_on_a_nexus.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_window_is_kept_open_on_a_nexus.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/control/window_keeper.py (WindowKeeper, Nexus),
#              warp2/control/watcher.py (read as text: the keeper is asked each look).
#  Description:
#    On a nexus the window is kept open (BUILD_LOG 1078): with no window
#    running, OPEN_WINDOW.bat is started; a running window is left alone;
#    the process list is read at most once a STALE; a window that keeps dying
#    waits twice as long before each new start; a machine that is not a
#    nexus is left alone; a process list that does not answer in time
#    starts nothing and still counts as a look (BUILD_LOG 1251). A window
#    process that shows no window is waited for, then ended and started
#    again (BUILD_LOG 1585).
#  User intention (Andrew, 2026-11-02): "I always want the window open on a nexus."
# ============================================================================
"""Tests that the watcher keeps the window open on a nexus, and does not start it in a tight loop."""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

from warp2.control.window_keeper import Nexus, WindowKeeper


def _tree(root, tier="nexus"):
    """Intention: a tree with OPEN_WINDOW.bat, a control folder and the seed's fit."""
    (root / "OPEN_WINDOW.bat").write_text("@echo off\r\n", encoding="utf-8")
    state = root / "state"
    (state / "control").mkdir(parents=True)
    (state / "seed").mkdir(parents=True)
    (state / "seed" / "bloom.json").write_text(json.dumps({"plan": {"tier": tier, "is_nexus": tier == "nexus"}}),
                                               encoding="utf-8")
    return SimpleNamespace(dir=state / "control", state=state)


class _Hands:
    """Intention: a stand-in process list — the pids it is told are running."""

    def __init__(self):
        self.running = []
        self.reads = 0

    def by_command(self, fragments):
        self.reads += 1
        assert "-m warp2.app" in fragments
        return list(self.running)


class _Clock:
    """Intention: a clock the test moves."""

    def __init__(self):
        self.now = 1_000_000.0

    def __call__(self):
        return self.now


def test_a_nexus_with_no_window_starts_one_and_leaves_a_running_one_alone(tmp_path):
    """Intention: no window -> OPEN_WINDOW.bat started; next look a window runs -> nothing started."""
    files, hands, clock, started = _tree(tmp_path), _Hands(), _Clock(), []
    keeper = WindowKeeper(tmp_path, files, hands=hands, start=lambda ask: started.append(ask.name) or {"pid": 1},
                          clock=clock)
    assert keeper.look()["did"] == "started" and started == ["OPEN_WINDOW.bat"]
    hands.running = [77]
    clock.now += keeper.every()
    assert keeper.look() == {"did": "open", "pids": [77]}
    assert started == ["OPEN_WINDOW.bat"]


def test_the_process_list_is_read_at_most_once_a_stale(tmp_path):
    """Intention: a second look inside STALE reads nothing."""
    files, hands, clock = _tree(tmp_path), _Hands(), _Clock()
    keeper = WindowKeeper(tmp_path, files, hands=hands, start=lambda ask: {"pid": 1}, clock=clock)
    keeper.look()
    clock.now += keeper.every() / 2
    assert keeper.look()["did"] == "waited" and hands.reads == 1


def test_a_window_that_keeps_dying_waits_twice_as_long_each_time(tmp_path):
    """Intention: starts that do not stay wait 1, 2, 4 STALEs; a window seen running resets the count."""
    files, hands, clock, started = _tree(tmp_path), _Hands(), _Clock(), []
    keeper = WindowKeeper(tmp_path, files, hands=hands, start=lambda ask: started.append(clock.now) or {},
                          clock=clock)
    stale = keeper.every()
    keeper.look()                                   # start 1
    clock.now += stale
    assert keeper.look()["did"] == "started"        # start 1 did not stay: wait 1 stale -> start 2
    clock.now += stale
    said = keeper.look()                            # start 2 did not stay: wait 2 stales
    assert said["did"] == "waiting to start again" and said["wait"] == 2 * stale
    clock.now += stale
    assert keeper.look()["did"] == "started"        # 2 stales after start 2 -> start 3
    assert len(started) == 3
    hands.running = [5]
    clock.now += stale
    keeper.look()
    assert json.loads((files.dir / "window_keeper.json").read_text(encoding="utf-8"))["failed"] == 0


def test_a_machine_that_is_not_a_nexus_is_left_alone(tmp_path):
    """Intention: a light tier, or no fit recorded, starts nothing and reads nothing."""
    files, hands = _tree(tmp_path, tier="light"), _Hands()
    keeper = WindowKeeper(tmp_path, files, hands=hands, start=lambda ask: {"pid": 1})
    assert keeper.look() == {"did": "not a nexus"} and hands.reads == 0
    assert Nexus(tmp_path / "nowhere").here() is False


def test_the_watcher_asks_the_keeper_each_look():
    """Intention: the watcher's loop calls the keeper beside status, window and .bat requests."""
    text = (Path(__file__).resolve().parents[1] / "watcher.py").read_text(encoding="utf-8")
    assert "WindowKeeper(root, files).look()" in text


class _SlowHands(_Hands):
    """Intention: a process list that does not answer in time, as Windows under low memory."""

    def by_command(self, fragments):
        import subprocess
        self.reads += 1
        raise subprocess.TimeoutExpired("powershell", 60)


def test_a_slow_process_list_starts_nothing_and_waits_a_stale(tmp_path):
    """Intention (BUILD_LOG 1251): a timed-out list is said and counted, not raised; the next read waits a STALE."""
    files, hands, clock, started = _tree(tmp_path), _SlowHands(), _Clock(), []
    keeper = WindowKeeper(tmp_path, files, hands=hands, start=lambda ask: started.append(1) or {}, clock=clock)
    assert keeper.look() == {"did": "process list too slow", "slow": 1}
    clock.now += keeper.every() / 2
    assert keeper.look()["did"] == "waited" and hands.reads == 1 and started == []
    row = json.loads((files.dir / "window_keeper.json").read_text(encoding="utf-8"))
    assert row["slow"] == 1 and row["looked"] == clock.now - keeper.every() / 2


class _SeeingHands(_Hands):
    """Intention: a process list that can also say which windows are on the screen, and end one."""

    def __init__(self):
        super().__init__()
        self.on_screen = []
        self.ended = []

    def showing(self, pids):
        return [pid for pid in pids if pid in self.on_screen]

    def end(self, pid, force, tree):
        assert force and tree
        self.ended.append(pid)
        self.running = [p for p in self.running if p != pid]
        return "ended"


def test_a_window_process_that_shows_nothing_is_waited_for_then_ended_and_a_new_one_started(tmp_path):
    """Intention (BUILD_LOG 1585): a process with no window on the screen is not an open window."""
    files, hands, clock, started = _tree(tmp_path), _SeeingHands(), _Clock(), []
    keeper = WindowKeeper(tmp_path, files, hands=hands, start=lambda ask: started.append(clock.now) or {"pid": 2},
                          clock=clock)
    hands.running = [77]
    said = keeper.look()
    assert said["did"] == "waiting for the window to show" and hands.ended == [] and started == []
    clock.now += keeper.every()
    assert keeper.look()["did"] == "started" and hands.ended == [77] and len(started) == 1
    row = json.loads((files.dir / "window_keeper.json").read_text(encoding="utf-8"))
    assert row["ended_unseen"] == [77] and row["hidden_since"] == 0.0


def test_a_window_that_comes_onto_the_screen_in_time_is_left_alone(tmp_path):
    """Intention: a window still opening is not ended; once seen it is open, and the wait is forgotten."""
    files, hands, clock, started = _tree(tmp_path), _SeeingHands(), _Clock(), []
    keeper = WindowKeeper(tmp_path, files, hands=hands, start=lambda ask: started.append(1) or {}, clock=clock)
    hands.running = [88]
    assert keeper.look()["did"] == "waiting for the window to show"
    hands.on_screen = [88]
    clock.now += keeper.every()
    assert keeper.look() == {"did": "open", "pids": [88]} and hands.ended == [] and started == []
    assert json.loads((files.dir / "window_keeper.json").read_text(encoding="utf-8"))["hidden_since"] == 0.0


def test_the_real_hands_say_which_processes_show_a_window():
    """Intention: asked about a process that has no window, the real hands answer with none (and do not raise)."""
    import os
    from warp2.control.windows import WindowsHands
    said = WindowsHands().showing([os.getpid()])
    assert said in ([], [os.getpid()])
    assert WindowsHands().showing([]) == []
