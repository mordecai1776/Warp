# WARP2/warp2/control/tests/test_the_watcher_says_where_it_hangs.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_watcher_says_where_it_hangs.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs with a plain runner.
#  Uses      : warp2/control/watcher.py (StallDump).
#  Description:
#    A watcher loop turn that outlives its clock must leave every thread's
#    stack in a file; a turn that ends in time, or work the clock was stopped
#    for, must leave none. Seen 2026-10-17: the watcher's beat went stale for
#    54 minutes while its process stayed up, and nothing said where it was.
#  User intention (Andrew, 2026-10-02): a restart watcher he can trust while
#    he is away; (2026-10-16) every failure becomes something that is checked.
# ============================================================================
from __future__ import annotations

import tempfile
import time
from pathlib import Path

import warp2.control.watcher as watcher


def _scratch() -> Path:
    """Intention: a fresh folder for one test when no pytest tmp_path is given."""
    return Path(tempfile.mkdtemp(prefix="w2_stall_"))


def test_a_turn_past_its_clock_leaves_the_stacks(tmp_path=None):
    """Intention: armed for 0.2 s and stuck for 0.8 s, the file names this test as where it was."""
    path = Path(tmp_path or _scratch()) / "watcher_stuck_stacks.txt"
    stall = watcher.StallDump(path, after=0.2)
    stall.arm()
    time.sleep(0.8)
    stall.disarm()
    text = path.read_text(encoding="utf-8")
    assert "most recent call first" in text
    assert "test_a_turn_past_its_clock_leaves_the_stacks" in text


def test_a_turn_in_time_or_disarmed_leaves_none(tmp_path=None):
    """Intention: re-armed before its clock runs out, then disarmed, there is only the opening line."""
    path = Path(tmp_path or _scratch()) / "watcher_stuck_stacks.txt"
    stall = watcher.StallDump(path, after=0.4)
    for _ in range(3):
        stall.arm()
        time.sleep(0.2)
    stall.disarm()
    time.sleep(0.6)
    text = path.read_text(encoding="utf-8")
    assert "most recent call first" not in text
    assert text.startswith("watcher ")


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print("PASS", name)
