# WARP2/warp2/control/tests/test_the_restart_names_the_new_lane.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_restart_names_the_new_lane.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs as plain functions.
#  Uses      : warp2/control/restart.py with a stand-in for Windows.
#  Description:
#    The runner starts the web lane only after its start-up tests, so the
#    lane beats later than the runner. The restart answer must still name the
#    new lane (Muse-435: a receipt with the new PIDs), and must not wait for
#    ever when no lane comes.
#  User intention (Andrew, 2026-10-02): a restart Claude can trust to do alone.
# ============================================================================
from __future__ import annotations

from pathlib import Path

from warp2.control.restart import Restart


class Clock:
    """Intention: time that moves only when slept, so waits are instant and exact."""
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now

    def sleep(self, seconds):
        self.now += seconds


class LateLaneHands:
    """Intention: a pretend Windows with no old warp, whose new web lane beats `lane_after` seconds after launch."""
    def __init__(self, state: Path, clock: Clock, lane_after):
        self.state, self.clock, self.lane_after, self.launched_at = state, clock, lane_after, None

    def registered(self):
        return []

    def by_command(self, fragments):
        return []

    def launcher_of(self, pid):
        return None

    def alive(self, pid):
        self._lane()
        return False

    def end(self, pid, force, tree):
        return ""

    def launch(self, root, *, headless=False):
        self.launched_at = self.clock()
        (self.state / "lanes").mkdir(parents=True, exist_ok=True)
        (self.state / "lanes" / "card.beat").write_text("99 1.0")
        return 77

    def _lane(self):
        """Intention: the lane's beat appears once its time has come."""
        if self.launched_at is not None and self.lane_after is not None \
                and self.clock() >= self.launched_at + self.lane_after:
            (self.state / "lanes" / "web.beat").write_text("98 1.0")


class LateLaneClock(Clock):
    """Intention: a clock that lets the stand-in lane appear as time is slept through."""
    def __init__(self):
        super().__init__()
        self.hands = None

    def sleep(self, seconds):
        self.now += seconds
        if self.hands:
            self.hands._lane()


def _restart(tmp_path: Path, lane_after):
    state = tmp_path / "state"
    (state / "lanes").mkdir(parents=True)
    (state / "lanes" / "card.beat").write_text("11 0.0")
    (state / "lanes" / "web.beat").write_text("12 0.0")
    clock = LateLaneClock()
    hands = LateLaneHands(state, clock, lane_after)
    clock.hands = hands
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why": "test", "background": True})
    return said, [s for s in said["steps"] if s["step"] == "beats"][0]


def test_a_lane_that_beats_after_the_runner_is_named(tmp_path):
    said, beats = _restart(tmp_path, lane_after=40.0)
    assert said["outcome"] == "restarted"
    assert beats["runner"] == 99
    assert beats["lane"] == 98


def test_no_lane_is_reported_as_none_and_the_wait_ends(tmp_path):
    said, beats = _restart(tmp_path, lane_after=None)
    assert said["outcome"] == "restarted"
    assert beats["lane"] is None
    assert said["seconds"] <= 130.0


def test_the_old_lane_is_not_taken_for_the_new_one(tmp_path):
    said, beats = _restart(tmp_path, lane_after=10_000.0)
    assert beats["lane"] is None
