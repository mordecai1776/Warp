# WARP2/warp2/control/tests/test_the_runner_keeps_the_watcher_up.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_runner_keeps_the_watcher_up.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs with a plain runner.
#  Uses      : warp2/control/watcher_alive.py; warp2/run.py (_Reload).
#  Description:
#    With no watcher beating, the runner asks the watcher's task to start (at
#    most once per RETRY_EVERY) and a watcher-started runner does not leave
#    for a reload; with a fresh beat, or under WARP2.bat, the reload goes on
#    as before. Seen 2026-10-18: the runner left for a reload at 00:05 while
#    the watcher was gone, and the warp stayed down until a PC restart.
#  User intention (Andrew, 2026-10-16): the catastrophic failure is the whole
#    system stopping.
# ============================================================================
from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path

from warp2.control import watcher_alive
from warp2.control.watcher_alive import WatcherKeeper


def _state(tmp_path=None) -> Path:
    """Intention: a fresh state folder with a control folder in it."""
    state = Path(tmp_path or tempfile.mkdtemp(prefix="w2_keep_")) / "state"
    (state / "control").mkdir(parents=True)
    return state


def _beat(state: Path, age: float) -> None:
    """Intention: a watcher beat written `age` seconds ago."""
    (state / "control" / "watcher.beat").write_text(f"1234 {time.time() - age:.3f} watching\n", encoding="utf-8")


class Calls:
    """Intention: a stand-in for schtasks that only counts what it was asked."""
    def __init__(self):
        self.asked = []

    def __call__(self, args):
        """Intention: remember the arguments; say it worked."""
        self.asked.append(list(args))
        return {"code": 0, "said": "ok"}


def test_no_beat_asks_the_task_once_per_wait(tmp_path=None):
    """Intention: a stale beat starts the task (run + query) once; asked again at once, it waits."""
    state = _state(tmp_path)
    _beat(state, 3600)
    calls = Calls()
    keeper = WatcherKeeper(state, headless=True, call=calls, windows=True)
    assert keeper.check() is False
    assert calls.asked[0] == ["/Run", "/TN", watcher_alive.TASK]
    assert len(calls.asked) == 2
    assert keeper.check() is False
    assert len(calls.asked) == 2
    assert "asked_task_to_start" in (state / "control" / "watcher-revived.jsonl").read_text(encoding="utf-8")


def test_a_fresh_beat_asks_nothing_and_holds_nothing(tmp_path=None):
    """Intention: with a watcher beating, nothing is started and a reload is not held."""
    state = _state(tmp_path)
    _beat(state, 1)
    calls = Calls()
    keeper = WatcherKeeper(state, headless=True, call=calls, windows=True)
    assert keeper.check() is True
    assert keeper.hold_reload("the source changed") is False
    assert calls.asked == []


def test_a_watcher_started_runner_holds_its_reload_but_a_bat_runner_does_not(tmp_path=None):
    """Intention: headless and no watcher -> hold (said once); started by the bat -> go on."""
    state = _state(tmp_path)
    _beat(state, 3600)
    held = WatcherKeeper(state, headless=True, call=Calls(), windows=True)
    assert held.hold_reload("the source changed") is True
    assert held.hold_reload("the source changed") is True
    text = (state / "control" / "watcher-revived.jsonl").read_text(encoding="utf-8")
    assert text.count("reload_held") == 1
    bat = WatcherKeeper(state, headless=False, call=Calls(), windows=True)
    assert bat.hold_reload("the source changed") is False


def test_the_reload_boundary_waits_for_a_watcher(tmp_path=None):
    """Intention: _Reload says "" for a changed source while no watcher beats, and the reason once one does."""
    from warp2.run import _Reload
    base = Path(tmp_path or tempfile.mkdtemp(prefix="w2_keep_"))
    (base / "warp2").mkdir()
    source = base / "warp2" / "a.py"
    source.write_text("x = 1\n", encoding="utf-8")
    state = _state(base)
    _beat(state, 3600)
    reload = _Reload(base, state)
    reload.watcher = WatcherKeeper(state, headless=True, call=Calls(), windows=True)
    source.write_text("x = 22\n", encoding="utf-8")
    os.utime(source, ns=(time.time_ns() + 5_000_000_000,) * 2)
    assert reload.asked() == "", "just changed: wait a pass for the burst to end (BUILD_LOG 914)"
    assert reload.asked() == "", "settled, but no watcher beats"
    assert reload.fired is False
    _beat(state, 1)
    assert reload.asked() == "the source changed"
    assert reload.fired is True


def test_a_burst_of_edits_restarts_once_after_it_ends_and_a_test_file_never_does(tmp_path=None):
    """Intention (BUILD_LOG 914): while files keep landing the runner goes on; it leaves once the source has stood
    still for a pass. A test file is not the running code and changes nothing."""
    from warp2.run import _Reload
    base = Path(tmp_path or tempfile.mkdtemp(prefix="w2_burst_"))
    (base / "warp2" / "tests").mkdir(parents=True)
    source = base / "warp2" / "a.py"
    source.write_text("x = 1\n", encoding="utf-8")
    state = _state(base)
    _beat(state, 1)
    reload = _Reload(base, state)
    reload.watcher = WatcherKeeper(state, headless=True, call=Calls(), windows=True)
    test_file = base / "warp2" / "tests" / "test_a.py"
    test_file.write_text("def test_it():\n    assert True\n", encoding="utf-8")
    assert reload.asked() == "" and reload.asked() == "", "a test file never restarts the runner"
    for step in range(1, 4):
        source.write_text(f"x = {step + 1}\n", encoding="utf-8")
        os.utime(source, ns=(time.time_ns() + step * 5_000_000_000,) * 2)
        assert reload.asked() == "", "still being edited"
    assert reload.asked() == "the source changed", "the burst ended: one restart"


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print("PASS", name)
