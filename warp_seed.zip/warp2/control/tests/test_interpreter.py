# WARP2/warp2/control/tests/test_interpreter.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_interpreter.py
#  Used by   : pytest.
#  Uses      : warp2/control/interpreter.py, WARP2.bat, warp2/run.py.
#  Description:
#    Another tool's environment, or no usable graphics card, is a reason not to
#    start; a person can say they mean it; the launcher and the runner both ask.
#  User intention (Andrew, 2026-10-08): lock which Python runs the warp.
# ============================================================================
from __future__ import annotations

from pathlib import Path

from warp2.control.interpreter import problem


def test_the_right_python_is_fine():
    """Intention: own Python, card usable — nothing to say."""
    assert problem(venv="", card=True) == ""


def test_another_tools_environment_is_refused(monkeypatch):
    """Intention: the 10-06 shape — a venv — is named, unless a person allows it."""
    monkeypatch.delenv("WARP2_ALLOW_VENV", raising=False)
    said = problem(venv=r"C:\hermes-agent\venv", card=True)
    assert "hermes-agent" in said and "WARP2.bat" in said
    monkeypatch.setenv("WARP2_ALLOW_VENV", "1")
    assert problem(venv=r"C:\hermes-agent\venv", card=True) == ""


def test_no_card_is_refused_unless_allowed(monkeypatch):
    """Intention: no CUDA is a reason to stop; WARP2_ALLOW_CPU=1 says the person means it."""
    monkeypatch.delenv("WARP2_ALLOW_CPU", raising=False)
    assert "graphics card" in problem(venv="", card=False)
    monkeypatch.setenv("WARP2_ALLOW_CPU", "1")
    assert problem(venv="", card=False) == ""


def test_the_launcher_and_the_runner_both_ask():
    """Intention: wired in both doors — the batch file and the continuous run."""
    root = Path(__file__).resolve().parents[3]
    bat = (root / "WARP2.bat").read_text(encoding="ascii")
    assert "-m warp2.control.interpreter" in bat and 'set "VIRTUAL_ENV="' in bat
    run = (root / "warp2" / "run.py").read_text(encoding="utf-8")
    assert "from warp2.control.interpreter import problem" in run
