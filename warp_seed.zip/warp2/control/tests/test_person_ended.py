# WARP2/warp2/control/tests/test_person_ended.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_person_ended.py
#  Used by   : pytest.
#  Uses      : warp2/control/person_ended.py, warp2/run.py (`_go_owned`).
#  Description:
#    A person ending a continuous run takes down the watcher's "runner
#    expected" mark; a crash does not.
#  User intention (Andrew, 2026-10-09): closed means closed — the watcher must
#    not start a hidden runner after Ctrl+C or a closed console (check F1).
# ============================================================================
from __future__ import annotations

import contextlib
from pathlib import Path
from types import SimpleNamespace

import pytest

import warp2.run as run
from warp2.control.files import ControlFiles
from warp2.control.person_ended import withdraw


def _expect(state: Path) -> Path:
    mark = ControlFiles(state).expected
    mark.parent.mkdir(parents=True, exist_ok=True)
    mark.write_text("expected", encoding="utf-8")
    return mark


def test_withdraw_takes_the_mark_down_once(tmp_path):
    mark = _expect(tmp_path)
    assert withdraw(tmp_path) is True and not mark.exists()
    assert withdraw(tmp_path) is False


def _machine(tmp_path, fails_with):
    """A stand-in for the built machine whose run ends the way a test says."""
    journal = tmp_path / "journal.jsonl"
    journal.write_text("", encoding="utf-8")

    def _run(**_):
        raise fails_with

    return SimpleNamespace(pathway=SimpleNamespace(journal=SimpleNamespace(path=journal),
                                                   act=lambda *a, **k: {}),
                           fleet=None, queue=None, store=None, run=_run, close=lambda: None)


def _quiet_go(monkeypatch, tmp_path, fails_with):
    monkeypatch.setattr(run, "_swap_proven_improvements", lambda *a, **k: None)
    monkeypatch.setattr(run, "build", lambda *a, **k: _machine(tmp_path, fails_with))
    monkeypatch.setattr(run, "_say_what_changed_since", lambda *a, **k: {})
    monkeypatch.setattr(run, "Session", lambda *a, **k: contextlib.nullcontext(SimpleNamespace(because=lambda *_: None)))
    monkeypatch.setattr("warp2.work.web_lane.WebKeeper",
                        lambda *a, **k: SimpleNamespace(check=lambda: False, stop=lambda: None))
    monkeypatch.setattr("warp2.work.card_beat.CardBeat",
                        lambda *a, **k: SimpleNamespace(keep_beating=lambda: None, stop=lambda: None))


def test_ctrl_c_in_a_continuous_run_takes_the_mark_down(tmp_path, monkeypatch):
    state = tmp_path / "state"
    mark = _expect(state)
    _quiet_go(monkeypatch, tmp_path, KeyboardInterrupt())
    with pytest.raises(KeyboardInterrupt):
        run._go_owned(tmp_path, state, passes=0)
    assert not mark.exists()


def test_a_crash_leaves_the_mark_so_the_watcher_recovers(tmp_path, monkeypatch):
    state = tmp_path / "state"
    mark = _expect(state)
    _quiet_go(monkeypatch, tmp_path, RuntimeError("crashed"))
    with pytest.raises(RuntimeError):
        run._go_owned(tmp_path, state, passes=0)
    assert mark.exists()
