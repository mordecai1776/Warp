# WARP2/warp2/control/tests/test_restart.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_restart.py
#  Used by   : pytest.
#  Uses      : warp2/control/{files,restart,watcher}.py with a stand-in for
#              Windows (no process is touched).
#  Description:
#    The restart does its steps in the order that loses nothing, never acts
#    under ALL_STOP, forces only past the grace, and the request is taken once.
#  User intention (Andrew, 2026-10-02): a restart Claude can trust to do alone.
# ============================================================================
from __future__ import annotations

import json

import pytest

from warp2.control.files import ControlFiles
from warp2.control.restart import Restart
from warp2.control.watcher import watch


@pytest.fixture
def process_probe(monkeypatch):
    """Intention: a process query stays read-only even when the shell tool is stuck."""
    from types import SimpleNamespace
    from warp2.control import windows

    def configure(handle=17, waited=0x102, error=0):
        closed, waits = [], []

        def wait(process, milliseconds):
            waits.append((process, milliseconds))
            return waited

        api = SimpleNamespace(OpenProcess=lambda *args: handle,
                              WaitForSingleObject=wait, CloseHandle=closed.append)
        monkeypatch.setattr(windows, "_process_api", lambda: api, raising=False)
        monkeypatch.setattr(windows, "ctypes", SimpleNamespace(
            get_last_error=lambda: error,
            WinError=lambda code=None: OSError(error if code is None else code, "query failed")),
            raising=False)

        def stuck(*args, **kwargs):
            import subprocess
            raise subprocess.TimeoutExpired("tasklist", 20)

        monkeypatch.setattr(windows.subprocess, "run", stuck)
        return windows.WindowsHands(), closed, waits

    return configure


@pytest.mark.parametrize("waited, alive", [(0x102, True), (0, False)])
def test_process_liveness_does_not_wait_for_tasklist(process_probe, waited, alive):
    """Intention: a live or exited process answers immediately, with its handle closed."""
    hands, closed, waits = process_probe(waited=waited)
    assert hands.alive(123) is alive
    assert waits == [(17, 0)] and closed == [17]


def test_missing_process_is_not_alive(process_probe):
    """Intention: a PID Windows says no longer exists is the one safe negative answer."""
    hands, closed, waits = process_probe(handle=0, error=87)
    assert hands.alive(123) is False
    assert not waits and not closed


def test_access_denied_is_not_mistaken_for_an_exited_process(process_probe):
    """Intention: uncertainty must still abort a restart, never authorize a replacement."""
    hands, closed, waits = process_probe(handle=0, error=5)
    with pytest.raises(OSError):
        hands.alive(123)
    assert not waits and not closed


def test_failed_process_wait_stays_unknown_and_closes_the_handle(process_probe):
    """Intention: even a failed query releases its handle without claiming an exit."""
    hands, closed, waits = process_probe(waited=0xFFFFFFFF, error=6)
    with pytest.raises(OSError):
        hands.alive(123)
    assert waits == [(17, 0)] and closed == [17]


def test_nonpositive_pid_is_not_a_process(process_probe):
    """Intention: the absence of a recorded PID does not become a Windows query."""
    hands, closed, waits = process_probe()
    assert hands.alive(0) is False
    assert hands.alive(-1) is False
    assert not waits and not closed


class Clock:
    """Intention: time that moves only when slept, so waits are instant and exact."""
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now

    def sleep(self, seconds):
        self.now += seconds


class Hands:
    """Intention: a pretend Windows — processes, who started them, and what was done to them."""
    def __init__(self, state, runner_quits_after=None, clock=None):
        self.state, self.clock, self.done = state, clock, []
        self.live = {11: "run", 12: "web", 20: "window", 30: "loop"}
        self.runner_quits_after = runner_quits_after

    def registered(self):
        return [{"pid": p, "role": r} for p, r in self.live.items() if r in ("run", "web")]

    def by_command(self, fragments):
        # Intention (BUILD_LOG 940): the stand-in answers by what was asked — windows for the window commands,
        # web lanes for the lane command — as the real hands do.
        if any("warp2.run web" in str(f) for f in fragments):
            return [p for p, r in self.live.items() if r in ("web", "stray")]
        return [p for p, r in self.live.items() if r == "window"]

    def launcher_of(self, pid):
        return 30 if pid == 11 else None

    def alive(self, pid):
        if pid == 11 and self.runner_quits_after is not None and self.clock() >= self.runner_quits_after:
            self.live.pop(11, None)
        return pid in self.live

    def end(self, pid, force, tree):
        self.done.append(("end", pid, force, tree))
        if force or self.live.get(pid) in ("window", "web"):
            self.live.pop(pid, None)
        return ""

    def open_window(self, root):
        self.done.append(("open_window",))
        self.live[21] = "window"
        return 21

    def launch(self, root, *, headless=False):
        self.done.append(("launch", headless))
        (self.state / "lanes").mkdir(parents=True, exist_ok=True)
        (self.state / "lanes" / "card.beat").write_text("99 1.0")
        (self.state / "lanes" / "web.beat").write_text("98 1.0")
        return 77


def _setup(tmp_path, monkeypatch):
    monkeypatch.setenv("WARP2_RUNTIME_DIR", str(tmp_path / "runtime"))
    state = tmp_path / "state"
    (state / "lanes").mkdir(parents=True)
    (state / "lanes" / "card.beat").write_text("11 0.0")
    (state / "lanes" / "web.beat").write_text("12 0.0")
    return state


def test_fresh_beat_from_ended_watcher_does_not_stop_replacement(tmp_path):
    """Intention: a just-terminated worker can leave a fresh beat; it no longer owns startup."""
    import time
    from warp2.control.watcher import another_is_watching
    files = ControlFiles(tmp_path / "state")
    files.ready()
    files.beat.write_text(f"987654 {time.time()} watching")
    asked = []
    assert not another_is_watching(files, alive=lambda pid: asked.append(pid) or False)
    assert asked == [987654]
    assert another_is_watching(files, alive=lambda pid: True)


def test_unanswered_owner_query_preserves_duplicate_protection(tmp_path):
    """Intention: a query failure must not be used to launch a duplicate watcher."""
    import time
    import subprocess
    from warp2.control.watcher import another_is_watching
    files = ControlFiles(tmp_path / "state")
    files.ready()
    files.beat.write_text(f"987654 {time.time()} watching")
    def unanswered(pid):
        raise subprocess.TimeoutExpired("tasklist", 20)
    assert another_is_watching(files, alive=unanswered)


def test_invalid_or_stale_watcher_beat_does_not_query_process(tmp_path):
    """Intention: malformed and expired beats cannot claim a current owner."""
    import time
    from warp2.control.watcher import another_is_watching
    files = ControlFiles(tmp_path / "state")
    files.ready()
    def unexpected(pid):
        raise AssertionError("no process query needed")
    for beat in ("", "bad bad", f"987654 {time.time()-120}"):
        files.beat.write_text(beat)
        assert not another_is_watching(files, alive=unexpected)


def test_polite_restart_in_order(tmp_path, monkeypatch):
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()
    hands = Hands(state, runner_quits_after=30.0, clock=clock)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why": "test"})
    assert said["outcome"] == "restarted"
    assert hands.done[0] == ("end", 30, True, False)          # the bat loop first
    assert ("end", 11, True, True) not in hands.done            # the runner was not forced
    assert hands.done[-1] == ("launch", False)
    assert not (state / "locks" / "reload.flag").exists()
    assert json.loads((state / "control" / "restart.last.json").read_text())["outcome"] == "restarted"


def test_runner_forced_only_past_the_grace(tmp_path, monkeypatch):
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()
    hands = Hands(state, runner_quits_after=None, clock=clock)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"grace_seconds": 60})
    assert ("end", 11, True, True) in hands.done
    step = [s for s in said["steps"] if s["step"] == "runner_stopped"][0]
    assert step["forced"] == [11] and step["at_s"] >= 60


def test_all_stop_is_never_crossed(tmp_path, monkeypatch):
    state = _setup(tmp_path, monkeypatch)
    (state / "locks").mkdir()
    (state / "locks" / "stop.flag").write_text("x")
    clock = Clock()
    hands = Hands(state, clock=clock)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({})
    assert said["outcome"] == "refused" and hands.done == []
    assert (state / "locks" / "stop.flag").exists()


@pytest.mark.parametrize("encoding", ["utf-8", "utf-8-sig"])
def test_restart_request_keeps_json_settings_with_or_without_a_bom(tmp_path, encoding):
    """Intention: a Windows writer's UTF-8 marker must not turn settings into a plain reason."""
    files = ControlFiles(tmp_path / "state")
    files.ready()
    asked = {"why": "load the current source", "background": False, "grace_seconds": 12}
    files.request.write_text(json.dumps(asked), encoding=encoding)
    assert files.take() == asked
    assert not files.request.exists()
    assert files.take() is None


def test_a_request_is_taken_once(tmp_path):
    files = ControlFiles(tmp_path / "state")
    files.ready()
    files.request.write_text('{"why": "now"}')
    assert files.take() == {"why": "now"}
    assert files.take() is None


def test_watcher_once_answers_a_request(tmp_path, monkeypatch):
    state = _setup(tmp_path, monkeypatch)
    files = ControlFiles(state)
    files.ready()
    files.request.write_text("")
    import warp2.control.restart as restart
    received = []

    def answer(self, asked):
        received.append(dict(asked))
        return self._answer("restarted", "t")

    monkeypatch.setattr(restart.Restart, "run", answer)
    assert watch(tmp_path, once=True) == 0
    assert json.loads(files.last.read_text())["outcome"] == "restarted"
    assert received == [{"background": True}]
    assert files.beat.exists() and not files.request.exists()


def test_watcher_handoff_signal_releases_its_beat(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    files = ControlFiles(tmp_path / "state")
    files.ready()
    (files.dir / "watcher.handoff").write_text("scheduled task takeover")
    assert watch(tmp_path, once=True) == 0
    assert not files.beat.exists()
    assert not (files.dir / "watcher.handoff").exists()


def test_managed_watcher_handoff_restarts_inside_its_supervisor(tmp_path, monkeypatch):
    from warp2.control import watcher_service

    class Child:
        def __init__(self, code):
            self.code = code

        def wait(self):
            return self.code

    children = iter((Child(75), Child(0)))
    calls = []

    def spawn(args, **kwargs):
        calls.append((args, kwargs))
        return next(children)

    assert watcher_service.supervise(tmp_path, popen=spawn, once=True) == 0
    assert len(calls) == 2
    assert calls[0][0][-1] == "--managed"


def test_watcher_service_restarts_a_worker_with_a_stale_heartbeat(tmp_path):
    from warp2.control.watcher_service import supervise

    class Child:
        pid = 123

        def __init__(self):
            self.code = None
            self.terminated = False

        def poll(self):
            return self.code

        def terminate(self):
            self.terminated = True
            self.code = 1

        def wait(self, timeout=None):
            return self.code

    child = Child()
    now = [0.0]

    def sleep(seconds):
        now[0] += seconds

    assert supervise(tmp_path, popen=lambda *_a, **_k: child,
                     sleep=sleep, clock=lambda: now[0], once=True) == 1
    assert child.terminated


def test_watcher_service_stops_after_three_worker_failures(tmp_path):
    from warp2.control.watcher_service import MAX_FAILURES, supervise

    class FailedChild:
        def poll(self):
            return 1

    now = [0.0]
    calls = []

    def spawn(*_args, **_kwargs):
        calls.append(1)
        return FailedChild()

    def sleep(seconds):
        now[0] += seconds

    assert supervise(tmp_path, popen=spawn, sleep=sleep,
                     clock=lambda: now[0]) == 0
    assert len(calls) == MAX_FAILURES
    report = json.loads((tmp_path / "state" / "control" / "watcher-service.json").read_text())
    assert report["state"] == "circuit_open"
    assert report["failures"] == MAX_FAILURES


def test_explicit_restart_launcher_does_not_create_or_show_a_console(tmp_path, monkeypatch):
    import subprocess
    from pathlib import Path
    from warp2.control import windows

    calls = []

    class Child:
        pid = 456

    def spawn(args, **kwargs):
        calls.append((args, kwargs))
        return Child()

    monkeypatch.setattr(windows.subprocess, "Popen", spawn)
    assert windows.WindowsHands().launch(tmp_path, headless=False) == 456
    args, options = calls[0]
    assert args == ["cmd.exe", "/d", "/c", "WARP2.bat"]
    assert options["creationflags"] & windows.QUIET
    assert not options["creationflags"] & 0x00000010  # CREATE_NEW_CONSOLE
    assert options["stdin"] == subprocess.DEVNULL
    assert options["stdout"] == subprocess.DEVNULL
    assert Path(options["stderr"].name) == tmp_path / "state" / "diagnostics" / "restart-launch.stderr.log"


def test_automatic_restart_starts_only_a_hidden_continuous_runner(tmp_path, monkeypatch):
    import subprocess
    import sys
    from pathlib import Path
    from warp2.control import windows

    calls = []

    class Child:
        pid = 457

    def spawn(args, **kwargs):
        calls.append((args, kwargs))
        return Child()

    monkeypatch.setattr(windows.subprocess, "Popen", spawn)
    assert windows.WindowsHands().launch(tmp_path, headless=True) == 457
    args, options = calls[0]
    expected_python = Path(sys.executable).with_name("python.exe")
    if not expected_python.exists():
        expected_python = Path(sys.executable)
    # Intention (2026-10-09, check F5): the restart runs the prestart gate first.
    assert args == [str(expected_python), "-B", "-m", "warp2.control.preflight", str(tmp_path)]
    assert options["creationflags"] & windows.QUIET
    assert not options["creationflags"] & 0x00000010  # CREATE_NEW_CONSOLE
    assert options["stdin"] == subprocess.DEVNULL
    assert options["stdout"] == subprocess.DEVNULL
    assert Path(options["stderr"].name) == tmp_path / "state" / "diagnostics" / "restart-launch.stderr.log"


def test_opening_the_gui_does_not_spawn_a_console(tmp_path, monkeypatch):
    import sys
    from pathlib import Path
    from warp2.control import windows

    calls = []

    class Child:
        pid = 789

    def spawn(args, **kwargs):
        calls.append((args, kwargs))
        return Child()

    monkeypatch.setattr(windows.subprocess, "Popen", spawn)
    assert windows.WindowsHands().open_window(tmp_path) == 789
    args, options = calls[0]
    expected_python = Path(sys.executable).with_name("pythonw.exe")
    if not expected_python.exists():
        expected_python = Path(sys.executable)
    assert Path(args[0]) == expected_python
    assert options["creationflags"] & windows.QUIET
    assert not options["creationflags"] & 0x00000010  # CREATE_NEW_CONSOLE


def test_status_is_written_only_when_asked(tmp_path, monkeypatch):
    """Intention: status.request answered once into status.json; nothing written when not asked."""
    import warp2.control.status as status
    monkeypatch.setattr(status, "status", lambda state=None: {"memory_free_mb": 100, "python": []})
    files = ControlFiles(tmp_path / "state")
    files.ready()
    assert status.answer_status(files) is False and not (files.dir / "status.json").exists()
    (files.dir / "status.request").write_text("")
    assert status.answer_status(files) is True
    assert json.loads((files.dir / "status.json").read_text())["memory_free_mb"] == 100
    assert not (files.dir / "status.request").exists()


def test_supervisor_requires_expectation_and_multiple_missing_observations(tmp_path, monkeypatch):
    from warp2.control.supervisor import MISSING_OBSERVATIONS, RunnerSupervisor
    state = _setup(tmp_path, monkeypatch)
    files = ControlFiles(state)
    files.ready()
    hands = Hands(state)
    hands.live.clear()
    clock = Clock()
    supervisor = RunnerSupervisor(clock=clock)
    assert supervisor.observe(files, hands) is None
    files.expected.write_text("expected", encoding="utf-8")
    for _ in range(MISSING_OBSERVATIONS - 1):
        assert supervisor.observe(files, hands) is None
    assert supervisor.observe(files, hands)["why"].startswith("supervisor:")
    assert json.loads(files.supervision.read_text())["state"] == "restarting"


def test_supervisor_does_not_restart_a_healthy_or_stopped_runner(tmp_path, monkeypatch):
    from warp2.control.supervisor import RunnerSupervisor
    state = _setup(tmp_path, monkeypatch)
    files = ControlFiles(state)
    files.ready()
    files.expected.write_text("expected", encoding="utf-8")
    hands = Hands(state)
    # Test beats use synthetic mtimes, so make this one current.
    files.runner_beat.touch()
    assert RunnerSupervisor().observe(files, hands) is None
    hands.live.clear()
    (state / "locks").mkdir(exist_ok=True)
    files.stop_flag.write_text("stopped", encoding="utf-8")
    supervisor = RunnerSupervisor()
    for _ in range(5):
        assert supervisor.observe(files, hands) is None


@pytest.mark.parametrize("stopped, expected_state", [(False, "not_expected"), (True, "stopped")])
def test_supervisor_replaces_old_status_when_a_run_is_not_requested(
        tmp_path, monkeypatch, stopped, expected_state):
    """A stop or withdrawn run must not leave the last restart/healthy report on display."""
    from warp2.control.supervisor import RunnerSupervisor

    state = _setup(tmp_path, monkeypatch)
    files = ControlFiles(state)
    files.ready()
    clock = Clock()
    clock.now = 1000.0
    files.supervision.write_text(json.dumps({
        "state": "restarting", "when": 900.0, "attempt_history": [900.0],
        "next_retry": 1030.0, "healthy_since": 800.0,
    }), encoding="utf-8")
    if stopped:
        files.expected.write_text("expected", encoding="utf-8")
        files.stop_flag.parent.mkdir(exist_ok=True)
        files.stop_flag.write_text("stopped", encoding="utf-8")
    hands = Hands(state)
    supervisor = RunnerSupervisor(clock=clock)
    supervisor.missing = 2

    assert supervisor.observe(files, hands) is None
    saved = json.loads(files.supervision.read_text(encoding="utf-8"))
    assert saved["state"] == expected_state
    assert saved["when"] == 1000.0
    assert saved["missing_observations"] == 0
    assert saved["healthy_since"] is None
    assert saved["attempt_history"] == [900.0]
    assert saved["next_retry"] == 1030.0
    assert hands.done == []


def test_supervisor_does_not_interrupt_a_live_runner_with_a_stale_beat(tmp_path, monkeypatch):
    from warp2.control.supervisor import RunnerSupervisor

    state = _setup(tmp_path, monkeypatch)
    files = ControlFiles(state)
    files.ready()
    files.expected.write_text("expected", encoding="utf-8")
    hands = Hands(state)
    clock = Clock()
    clock.now = files.runner_beat.stat().st_mtime + 1000
    supervisor = RunnerSupervisor(clock=clock)
    for _ in range(5):
        assert supervisor.observe(files, hands) is None
    assert json.loads(files.supervision.read_text())["state"] == "stale_runner_alive"


def test_supervisor_persists_a_three_attempt_circuit_breaker(tmp_path, monkeypatch):
    from warp2.control.supervisor import MAX_ATTEMPTS, MISSING_OBSERVATIONS, RunnerSupervisor

    state = _setup(tmp_path, monkeypatch)
    files = ControlFiles(state)
    files.ready()
    files.expected.write_text("expected", encoding="utf-8")
    hands = Hands(state)
    hands.live.clear()
    clock = Clock()
    clock.now = 1000.0

    supervisor = RunnerSupervisor(clock=clock)
    for _ in range(MISSING_OBSERVATIONS):
        request = supervisor.observe(files, hands)
    assert request["automatic"] is True

    for _ in range(1, MAX_ATTEMPTS):
        # Recreate the watcher supervisor to prove retry state is durable.
        supervisor = RunnerSupervisor(clock=clock)
        clock.now = json.loads(files.supervision.read_text())["next_retry"]
        for _ in range(MISSING_OBSERVATIONS):
            request = supervisor.observe(files, hands)
        assert request["automatic"] is True

    supervisor = RunnerSupervisor(clock=clock)
    clock.now = json.loads(files.supervision.read_text())["next_retry"] + 1
    for _ in range(MISSING_OBSERVATIONS * 2):
        assert supervisor.observe(files, hands) is None
    saved = json.loads(files.supervision.read_text())
    assert saved["state"] == "circuit_open"
    assert saved["attempts"] == MAX_ATTEMPTS


def test_automatic_recovery_leaves_user_windows_and_web_lane_alone(tmp_path, monkeypatch):
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()
    hands = Hands(state, clock=clock)
    hands.live = {12: "web", 20: "window"}
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run(
        {"why": "automatic recovery", "automatic": True}
    )
    assert said["outcome"] == "restarted"
    assert hands.done == [("launch", True)]
    assert hands.live == {12: "web", 20: "window"}
    assert (state / "control" / "run.expected").exists()
    assert "desktop_left_untouched" in [step["step"] for step in said["steps"]]


def test_batch_loop_retries_only_a_clean_reload(tmp_path):
    from pathlib import Path

    bat = (Path(__file__).resolve().parents[3] / "WARP2.bat").read_text(encoding="utf-8")
    assert "if errorlevel 4 goto unexpected_runner_exit" in bat
    assert "if errorlevel 3 goto clean_reload" in bat
    assert "if errorlevel 1 goto unexpected_runner_exit" in bat
    assert "goto continuous_loop" in bat
    assert "bounded retries" in bat


def test_memory_is_reported_only_when_asked(tmp_path):
    """Intention: memory.<lane>.request answered once into memory.<lane>.json, with totals and the biggest things."""
    from warp2.control.inside import answer_memory
    (tmp_path / "control").mkdir()
    assert answer_memory(tmp_path, "card") is False
    (tmp_path / "control" / "memory.card.request").write_text("")
    assert answer_memory(tmp_path, "card") is True
    said = json.loads((tmp_path / "control" / "memory.card.json").read_text())
    assert "totals_mb" in said and "biggest" in said
    assert not (tmp_path / "control" / "memory.card.request").exists()


def test_closing_the_window_leaves_the_work_running(tmp_path, monkeypatch):
    """Intention: window.request closes the window processes only — politely, then by force — and says so."""
    from warp2.control.window import answer_window
    import warp2.control.window as window
    monkeypatch.setattr(window.time, "sleep", lambda s: None)
    state = tmp_path / "state"
    hands = Hands(state)
    files = ControlFiles(state)
    files.ready()
    assert answer_window(files, hands) is False
    (files.dir / "window.request").write_text("")
    assert answer_window(files, hands) is True
    assert ("end", 20, False, False) in hands.done
    assert 11 in hands.live and 30 in hands.live and 20 not in hands.live
    assert json.loads((files.dir / "window.json").read_text())["closed"] == [20]


def test_environment_receipt_is_atomic_and_has_a_repeatable_fingerprint(tmp_path):
    from warp2.control.environment import fingerprint, record
    first = fingerprint(tmp_path)
    second = fingerprint(tmp_path)
    assert first["sha256"] == second["sha256"]
    path = record(tmp_path)
    row = json.loads(path.read_text(encoding="utf-8"))
    assert row["sha256"] == first["sha256"]
    assert row["python"] and "torch" in row["packages"]
    assert not list(path.parent.glob("*.tmp"))


def test_the_window_can_be_opened_alone(tmp_path):
    """Intention: {"open": true} opens only the window; the runner is not touched."""
    from warp2.control.window import answer_window
    state = tmp_path / "state"
    hands = Hands(state)
    files = ControlFiles(state)
    files.ready()
    (files.dir / "window.request").write_text('{"open": true}')
    assert answer_window(files, hands) is True
    assert hands.done == [("open_window",)] and 11 in hands.live
    assert json.loads((files.dir / "window.json").read_text())["opened"] == 21


def test_a_restart_whose_start_up_tests_take_over_five_minutes_is_reported_restarted(tmp_path, monkeypatch):
    """Intention (BUILD_LOG 811): the new runner beats only after the start-up tests (4.4-4.6 min, more on a slow
    day); a beat 400 s after launch is still a good restart, never "launched_no_beat_yet"."""
    state = _setup(tmp_path, monkeypatch)

    class LateClock(Clock):
        """Intention: the new runner's first beat lands 400 s after launch."""
        launched_at = None

        def sleep(self, seconds):
            self.now += seconds
            if self.launched_at is not None and self.now - self.launched_at >= 400.0:
                (state / "lanes" / "card.beat").write_text("99 1.0")

    clock = LateClock()

    class LateHands(Hands):
        """Intention: launch starts the warp, but its runner has not beaten yet."""
        def launch(self, root, *, headless=False):
            self.done.append(("launch", headless))
            clock.launched_at = clock.now
            (self.state / "lanes" / "web.beat").write_text("98 1.0")
            return 77
    hands = LateHands(state, runner_quits_after=30.0, clock=clock)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why": "slow start-up tests"})
    assert said["outcome"] == "restarted"


# Intention (BUILD_LOG 875; seen 2026-10-28 22:48-22:58 UTC): a start whose start-up tests failed ends with no runner;
# the restart sees that within a minute and says so, instead of waiting all 600 s for "launched_no_beat_yet".
# Fails on the code before 875 (it waited the whole wait and answered launched_no_beat_yet).
def test_a_start_whose_tests_failed_is_answered_at_once_not_after_the_whole_wait(tmp_path, monkeypatch):
    """Intention: no start left in its gate, no new beat: answered start_ended_no_beat well inside the wait."""
    from warp2.control.restart import WAIT_STARTED
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()

    class FailedGateHands(Hands):
        """Intention: the launch's gate fails at once — no runner beat, and no start left running."""
        def launch(self, root, *, headless=False):
            self.done.append(("launch", headless))
            return 77

        def starting(self):
            return []
    hands = FailedGateHands(state, runner_quits_after=30.0, clock=clock)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why": "a failed gate"})
    assert said["outcome"] == "start_ended_no_beat"
    assert any(step["step"] == "start_ended" for step in said["steps"])
    assert clock.now < 200.0 < WAIT_STARTED


def test_a_start_still_in_its_gate_is_waited_for_and_a_failing_look_is_not_an_ending(tmp_path, monkeypatch):
    """Intention: while a start is still in its gate (or the look fails) the wait runs on to the beat as before."""
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()
    looks = []

    class SlowGateHands(Hands):
        """Intention: the gate is running for 300 s (one look fails), then the runner beats."""
        def launch(self, root, *, headless=False):
            self.done.append(("launch", headless))
            self.launched_at = clock.now
            return 77

        def starting(self):
            looks.append(clock.now)
            if len(looks) == 2:
                raise TimeoutError("powershell")
            if clock.now - self.launched_at >= 300.0:
                (self.state / "lanes" / "card.beat").write_text("99 1.0")
                (self.state / "lanes" / "web.beat").write_text("98 1.0")
            return [77]
    hands = SlowGateHands(state, runner_quits_after=30.0, clock=clock)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why": "slow gate"})
    assert said["outcome"] == "restarted" and len(looks) >= 3


# BUILD_LOG 879 (Muse-772): an ended start's receipt names the first failed start-up test and how many more failed,
# so a reader sees why without opening tests.out.txt (which the next start writes over).
# Fails on the code before 879 (the start_ended step carried only the file's path).
def test_an_ended_start_names_its_first_failed_test_and_counts_the_rest(tmp_path, monkeypatch):
    """Intention: two failed tests in this start's tests.out.txt -> first named, one more counted, once each."""
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()

    class FailedGateHands(Hands):
        """Intention: the gate fails at once and writes its tests file, as run_tests.py does."""
        def launch(self, root, *, headless=False):
            out = self.state / "diagnostics" / "tests.out.txt"
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text("design/tests/test_a.py::test_one PASSED [ 1%]\n"
                           "design/tests/test_a.py::test_two FAILED [ 2%]\n"
                           "warp2/x/tests/test_b.py::test_three FAILED [ 3%]\n"
                           "FAILED design/tests/test_a.py::test_two - AssertionError\n", encoding="utf-8")
            return 77

        def starting(self):
            return []
    hands = FailedGateHands(state, runner_quits_after=30.0, clock=clock)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run({"why": "a failed gate"})
    step = next(s for s in said["steps"] if s["step"] == "start_ended")
    assert step["first_failed"] == "design/tests/test_a.py::test_two"
    assert step["more_failed"] == 1


def test_an_old_tests_file_is_not_named_as_this_starts_failure(tmp_path):
    """Intention: a tests file written before the launch belongs to an earlier start: no name is read from it."""
    import os
    from warp2.control.restart import FailedTests
    out = tmp_path / "tests.out.txt"
    out.write_text("design/tests/test_a.py::test_two FAILED [ 2%]\n", encoding="utf-8")
    os.utime(out, (1000.0, 1000.0))
    assert FailedTests(out, since=5000.0).said() == {"first_failed": None, "more_failed": 0}
    assert FailedTests(out, since=900.0).said()["first_failed"] == "design/tests/test_a.py::test_two"


def test_a_stray_web_lane_off_the_register_is_ended_in_an_automatic_restart(tmp_path, monkeypatch):
    """Intention (BUILD_LOG 940): a lane process that is in the process list but not registered (its run ended,
    its process stayed) is ended even in an automatic recovery; the registered, working lane is left alone."""
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()
    hands = Hands(state, clock=clock)
    hands.live = {12: "web", 13: "stray", 20: "window"}
    hands.end = lambda pid, force, tree: (hands.done.append(("end", pid, force, tree)), hands.live.pop(pid, None))
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run(
        {"why": "automatic recovery", "automatic": True})
    assert said["outcome"] == "restarted"
    assert 13 not in hands.live and 12 in hands.live and 20 in hands.live
    found = next(step for step in said["steps"] if step["step"] == "found")
    assert found["stray_lanes"] == [13] and found["lanes"] == [12, 13]
