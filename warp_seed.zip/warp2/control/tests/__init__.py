# WARP2/warp2/control/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/__init__.py
#  Used by   : pytest (marks the folder as a package).
#  Uses      : nothing.
#  Description:
#    Tests for the remote restart watcher (warp2/control/).
#  User intention (Andrew, 2026-10-02): a restart Claude can trust to do alone.
# ============================================================================
