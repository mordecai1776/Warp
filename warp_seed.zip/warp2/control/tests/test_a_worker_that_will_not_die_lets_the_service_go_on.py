# WARP2/warp2/control/tests/test_a_worker_that_will_not_die_lets_the_service_go_on.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_a_worker_that_will_not_die_lets_the_service_go_on.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs with a plain runner.
#  Uses      : warp2/control/watcher_service.py (_watch_worker, KILL_WAIT).
#  Description:
#    A watcher worker whose beat went stale and that does not exit even after
#    a kill must not hold the service: the wait after the kill is bounded, the
#    worker is noted in state/control/watcher-abandoned.jsonl, and the service
#    is free to start a new one. Seen 2026-10-17: the watcher beat froze at
#    22:57 UTC and nothing restarted the warp until 00:35.
#  User intention (Andrew, 2026-10-02): a restart watcher he can trust while
#    he is away; (2026-10-16) the catastrophic failure is the whole system stopping.
# ============================================================================
from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path

import warp2.control.watcher_service as service


class _Unkillable:
    """Intention: a worker stuck in a call; it never exits, so any wait that has no limit would last for ever."""
    pid = 4242

    def __init__(self):
        self.killed = False
        self.waits = []

    def poll(self):
        return None

    def terminate(self):
        pass

    def kill(self):
        self.killed = True

    def wait(self, timeout=None):
        self.waits.append(timeout)
        if timeout is None:
            raise RuntimeError("waited with no limit on a worker that cannot exit")
        raise subprocess.TimeoutExpired("watcher", timeout)


def _scratch() -> Path:
    """Intention: a fresh folder for one test when no pytest tmp_path is given."""
    return Path(tempfile.mkdtemp(prefix="w2_unkillable_"))


def _run(root: Path, child) -> int:
    """Intention: run the worker check on a clock that moves only when it sleeps."""
    now = [0.0]

    def sleep(seconds):
        now[0] += seconds

    return service._watch_worker(child, root, sleep=sleep, clock=lambda: now[0])


def test_the_service_does_not_wait_for_ever_on_a_killed_worker(tmp_path=None):
    """Intention: the stuck worker is killed, every wait has a limit, and the check returns a failure."""
    root = Path(tmp_path) if tmp_path else _scratch()
    child = _Unkillable()
    assert _run(root, child) == 1
    assert child.killed
    assert None not in child.waits
    assert service.KILL_WAIT in child.waits


def test_a_let_go_worker_is_on_the_record(tmp_path=None):
    """Intention: the worker that was let go is written down with its pid."""
    root = Path(tmp_path) if tmp_path else _scratch()
    _run(root, _Unkillable())
    lines = (root / "state" / "control" / "watcher-abandoned.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    assert json.loads(lines[0])["pid"] == 4242
