# WARP2/warp2/control/tests/test_a_watcher_death_says_why.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_a_watcher_death_says_why.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs with a plain runner.
#  Uses      : WARP2/FREE_STUCK_WATCHER.ps1 (read as text; PowerShell is not
#              on the Linux VM).
#  Description:
#    When Andrew frees a dead watcher, the diagnosis also writes why it may
#    have gone: the scheduled task's last result and stop settings, the Task
#    Scheduler log rows for the task, and the System log's sleep, power-source
#    and logoff rows. Seen 2026-10-18 06:33 and 08:51: service and watcher
#    both gone, nothing said why.
#  User intention (Andrew, 2026-10-16): the catastrophic failure is the whole
#    system stopping; a failure must leave something to learn from.
# ============================================================================
from __future__ import annotations

from pathlib import Path

_SCRIPT = Path(__file__).resolve().parents[3] / "FREE_STUCK_WATCHER.ps1"


def _text() -> str:
    """Intention: the free-the-watcher script as text."""
    return _SCRIPT.read_text(encoding="utf-8")


def test_the_diagnosis_reads_the_task_and_its_stop_settings():
    """Intention: the task's last result and the settings that can stop it are written down."""
    text = _text()
    for part in ("Get-ScheduledTaskInfo", "LastTaskResult", "StopIfGoingOnBatteries",
                 "StopOnIdleEnd", "ExecutionTimeLimit", "LogonType"):
        assert part in text, part


def test_the_diagnosis_reads_the_logs_that_name_a_stop():
    """Intention: the Task Scheduler log and the System log's power and logoff rows are read."""
    text = _text()
    assert "Microsoft-Windows-TaskScheduler/Operational" in text
    assert "Id=42,105,107,1074,7002" in text


def test_the_death_reason_is_part_of_the_written_diagnosis():
    """Intention: the reason goes into the same watcher_freeze file, and a failure to read it is noted."""
    text = _text()
    assert "$lines += Get-DeathReason $since" in text
    assert "death reason not read" in text


def test_the_diagnosis_reads_low_memory_rows():
    """Intention: the System log's low-memory rows (event 2004) are read, to tell memory pressure from a task stop."""
    text = _text()
    assert "Resource-Exhaustion-Detector" in text
    assert "Id=2004" in text


def test_the_diagnosis_writes_each_process_parents():
    """Intention: each watcher, service and runner line carries its chain of parents, so it shows
    whether the runner is under the scheduled task's tree (Muse, muse-60)."""
    text = _text()
    assert "function Get-Ancestry" in text
    assert "parents: $(Get-Ancestry" in text
    assert "parents not read" in text


def test_the_diagnosis_writes_the_overlap_rule_and_triggers():
    """Intention: the registered task's multiple-instances rule and each trigger are written down, so a
    scheduled "stop the existing instance" kill can be seen or ruled out (Muse, muse-61)."""
    text = _text()
    assert "multiple instances $($set.MultipleInstances)" in text
    assert "foreach ($t in @($task.Triggers))" in text
    assert "$t.Repetition.Interval" in text
