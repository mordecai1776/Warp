# WARP2/warp2/control/tests/test_preflight.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_preflight.py
#  Used by   : pytest.
#  Uses      : warp2/control/preflight.py, warp2/ui/runner.py.
#  Description:
#    A start that is not the bat runs the prestart gate too, and a failed gate
#    starts nothing.
#    A gate that hangs past its patience is ended, names the test it hung on,
#    and counts as failed (BUILD_LOG 915).
#    Only a finished gate's closing score sets the patience; the running
#    score every 50 tests does not (BUILD_LOG 1016).
#  User intention (Andrew): a continuous run starts only when the fast
#    regression gate passes (check F5, 2026-10-09).
# ============================================================================
from __future__ import annotations

import time

from warp2.control import preflight


def test_a_failed_gate_starts_nothing(tmp_path, monkeypatch):
    started = []
    monkeypatch.setattr(preflight, "passes", lambda root: False)
    monkeypatch.setattr("warp2.run.main", lambda argv: started.append(argv) or 0)
    assert preflight.main([str(tmp_path)]) == 1
    assert started == []


def test_a_passed_gate_starts_the_continuous_run(tmp_path, monkeypatch):
    started = []
    monkeypatch.setattr(preflight, "passes", lambda root: True)
    monkeypatch.setattr("warp2.run.main", lambda argv: started.append(argv) or 0)
    assert preflight.main([str(tmp_path), str(tmp_path / "state")]) == 0
    assert started == [["go", "--continuous", "--root", str(tmp_path), "--state", str(tmp_path / "state")]]


def test_the_window_start_runs_the_gate_first(tmp_path, monkeypatch):
    from warp2.ui import runner
    ran = []
    monkeypatch.setattr("warp2.control.preflight.passes", lambda root: False)
    monkeypatch.setattr(runner.subprocess, "run", lambda *a, **k: ran.append(a))
    assert runner.main([str(tmp_path), str(tmp_path / "state")]) == 1
    assert ran == []


def test_the_gate_is_the_bats_own_command(tmp_path, monkeypatch):
    seen = {}

    class Done:
        pid = 1

        def __init__(self, command, **kwargs):
            seen["command"], seen["cwd"] = command, kwargs.get("cwd")

        def wait(self, timeout=None):
            return 0

    monkeypatch.setattr(preflight.subprocess, "Popen", Done)
    assert preflight.passes(tmp_path)
    assert seen["command"][-2:] == [str(tmp_path / "run_tests.py"), "--preflight"]
    assert seen["cwd"] == str(tmp_path)


def _gate_tree(tmp_path, body: str, last: str = ""):
    """Intention: a tree whose run_tests.py is `body`, with a last measured gate line when given."""
    (tmp_path / "run_tests.py").write_text(body, encoding="utf-8")
    diagnostics = tmp_path / "state" / "diagnostics"
    diagnostics.mkdir(parents=True)
    (diagnostics / "test_now.txt").write_text("design/tests/test_stuck.py::test_forever", encoding="utf-8")
    if last:
        (diagnostics / "tests.out.txt").write_text(last, encoding="utf-8")
    return tmp_path


_RULE = "=" * 60


def test_patience_is_a_multiple_of_the_gates_own_last_time(tmp_path):
    root = _gate_tree(tmp_path, "", "lots\n[  0.2 min] 50 passed, 0 failed, 0 skipped\nmore\n\n"
                      + _RULE + "\n[  3.3 min] 108 passed, 0 failed, 0 skipped\nALL TESTS PASSED\n")
    assert preflight.Patience(root).last_minutes() == 3.3
    assert abs(preflight.Patience(root).seconds() - 3.3 * 60 * preflight.PATIENCE_TIMES) < 1e-6


def test_unmeasured_gate_gets_the_wide_first_patience(tmp_path):
    root = _gate_tree(tmp_path, "")
    assert preflight.Patience(root).seconds() == preflight.UNMEASURED_PATIENCE_S


def test_a_hung_gate_is_ended_named_and_failed(tmp_path, monkeypatch):
    root = _gate_tree(tmp_path, "import time\ntime.sleep(120)\n")
    monkeypatch.setattr(preflight.Patience, "seconds", lambda self: 2.0)
    began = time.monotonic()
    assert preflight.passes(root) is False
    assert time.monotonic() - began < 60
    said = (root / "state" / "diagnostics" / "preflight_hung.txt").read_text(encoding="utf-8")
    assert "test_stuck.py::test_forever" in said and "past its patience" in said


def test_a_quick_gate_still_answers_by_its_exit(tmp_path):
    assert preflight.passes(_gate_tree(tmp_path, "raise SystemExit(0)\n")) is True
    other = tmp_path / "other"
    other.mkdir()
    assert preflight.passes(_gate_tree(other, "raise SystemExit(3)\n")) is False


def test_a_cut_off_gates_running_score_is_not_its_length(tmp_path):
    # Intention (BUILD_LOG 1016): 2026-10-31 a cut-off gate left only the
    # every-50-tests score "[  0.2 min] 50 passed"; read as the gate's length
    # it gave the next start 60 s, the slow chat test was cut each time, and
    # the warp stayed down. A gate with no closing score is unmeasured.
    cut = ("design/tests/test_a.py::test_x PASSED [ 45%]\n"
           "[  0.2 min] 50 passed, 0 failed, 0 skipped\n"
           "warp2/chat_learning/tests/test_chat_learning.py::test_slow\n"
           "... still running after 1.1 min: warp2/chat_learning/tests/test_chat_learning.py::test_slow\n")
    root = _gate_tree(tmp_path, "", cut)
    assert preflight.Patience(root).last_minutes() is None
    assert preflight.Patience(root).seconds() == preflight.UNMEASURED_PATIENCE_S
