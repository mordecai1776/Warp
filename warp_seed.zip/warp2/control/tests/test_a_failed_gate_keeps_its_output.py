# WARP2/warp2/control/tests/test_a_failed_gate_keeps_its_output.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_a_failed_gate_keeps_its_output.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/control/preflight.py (`passes`, `FailedGate`).
#  Description:
#    A gate that fails keeps its output in tests.failed.txt and a dated copy
#    before triage runs the gate again, so the passing rerun cannot write
#    over the failing test and its reason (BUILD_LOG 1475).
#  User intention (Andrew): keep everything, even from a failed run.
# ============================================================================
from __future__ import annotations

import sys
import types

from warp2.control import preflight


def test_the_failing_output_survives_a_passing_rerun(tmp_path, monkeypatch):
    """Intention: fails on the old preflight (nothing kept), passes on the new."""
    diagnostics = tmp_path / "state" / "diagnostics"
    diagnostics.mkdir(parents=True)
    runs = iter([("FAILED test_x - AssertionError: the reason", False),
                 ("108 passed", True)])

    def gate_once(root):
        text, ok = next(runs)
        (diagnostics / "tests.out.txt").write_text(text, encoding="utf-8")
        return ok

    class Triage:
        def __init__(self, root, state):
            pass

        def run(self, again):
            return {"set_aside": [], "passed": again()}

    monkeypatch.setattr(preflight, "_gate_once", gate_once)
    monkeypatch.setitem(sys.modules, "warp2.builders.triage",
                        types.SimpleNamespace(Triage=Triage))
    assert preflight.passes(tmp_path) is True
    assert (diagnostics / "tests.out.txt").read_text(encoding="utf-8") == "108 passed"
    assert "the reason" in (diagnostics / "tests.failed.txt").read_text(encoding="utf-8")
    dated = list((diagnostics / "failed_gates").glob("tests.failed-*.txt"))
    assert len(dated) == 1 and "test_x" in dated[0].read_text(encoding="utf-8")


def test_a_passing_gate_keeps_nothing(tmp_path, monkeypatch):
    """Intention: a gate that passes the first time leaves no failed copy."""
    monkeypatch.setattr(preflight, "_gate_once", lambda root: True)
    assert preflight.passes(tmp_path) is True
    assert not (tmp_path / "state" / "diagnostics" / "tests.failed.txt").exists()


def test_two_failures_in_one_second_are_both_kept(tmp_path):
    """Intention: a second failure never writes over the first dated copy."""
    diagnostics = tmp_path / "state" / "diagnostics"
    diagnostics.mkdir(parents=True)
    (diagnostics / "tests.out.txt").write_text("first", encoding="utf-8")
    one = preflight.FailedGate(tmp_path).keep()
    (diagnostics / "tests.out.txt").write_text("second", encoding="utf-8")
    two = preflight.FailedGate(tmp_path).keep()
    assert one != two
    assert one.read_text(encoding="utf-8") == "first"
    assert two.read_text(encoding="utf-8") == "second"


def test_no_output_yet_is_not_an_error(tmp_path):
    """Intention: a gate that wrote nothing keeps nothing and does not raise."""
    assert preflight.FailedGate(tmp_path).keep() is None
