# WARP2/warp2/control/tests/test_the_memory_map_is_read_on_request.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_memory_map_is_read_on_request.py
#  Used by   : CHECK_FIXES.bat, the start-up tests.
#  Uses      : warp2/control/regions.py, warp2/control/status.py.
#  Description:
#    A status request that says "regions" also writes one process's memory
#    map (summed by kind and allocation size, resident vs not), into
#    regions.json and a line in diagnostics/regions.jsonl; a plain request
#    does not; a failed read is said, not raised. Fails on the code before
#    BUILD_LOG 488 (no regions module; the request text was never read).
#  User intention (Andrew, 2026-10-16): get everything in working order —
#    here, see where the picture child's ~14 GB sits.
# ============================================================================
import json


def _files(tmp_path):
    """Intention: control files over a fresh state folder."""
    from warp2.control.files import ControlFiles
    files = ControlFiles(tmp_path / "state")
    files.ready()
    return files


class _FakeMap:
    """Intention: a process with one Python arena (half in RAM), one big buffer (none in RAM) and an image."""
    def __init__(self, pid):
        from warp2.control.regions import Region
        self.rows = [Region(0x10000, 0x10000, 1 << 20, "private", 4, 1 << 19),
                     Region(0x200000, 0x200000, 100 << 20, "private", 4, 0),
                     Region(0x9000000, 0x9000000, 2 << 20, "image", 2, 2 << 20)]

    def regions(self):
        """Intention: the fake regions."""
        return iter(self.rows)

    def close(self):
        """Intention: nothing to give back."""


def test_summary_splits_arenas_buffers_and_resident():
    """Intention: 1 MiB private allocations are their own band; resident and not-resident add up."""
    from warp2.control.regions import walk
    row = walk(7, opener=_FakeMap)
    assert row["committed_mb"] == 103.0 and row["resident_mb"] == 2.5 and row["not_resident_mb"] == 100.5
    bands = row["private_by_allocation_size"]
    assert bands["exactly 1 MiB (Python small-object arenas)"] == {"allocations": 1, "committed_mb": 1.0, "resident_mb": 0.5}
    assert bands["64 MiB-1 GiB"]["committed_mb"] == 100.0
    assert row["biggest_allocations"][0]["committed_mb"] == 100.0 and "failed" not in row


def test_a_failed_read_is_said():
    """Intention: a process that cannot be opened gives an answer with "failed", not an exception."""
    from warp2.control.regions import walk
    def broken(pid):
        raise OSError("no such process")
    row = walk(9, opener=broken)
    assert row["failed"].startswith("OSError") and row["pid"] == 9


def test_regions_written_only_when_asked(tmp_path, monkeypatch):
    """Intention: {"regions": true} maps the biggest Python process; an empty request writes no map."""
    import warp2.control.status as status
    import warp2.control.regions as regions
    monkeypatch.setattr(status, "status", lambda state=None: {"python": [{"pid": 42, "private_mb": 9}]})
    seen = []
    monkeypatch.setattr(regions, "walk", lambda pid: seen.append(pid) or {"pid": pid, "committed_mb": 1.0})
    files = _files(tmp_path)
    (files.dir / "status.request").write_text("")
    assert status.answer_status(files) and not (files.dir / "regions.json").exists() and seen == []
    (files.dir / "status.request").write_text(json.dumps({"regions": True}))
    assert status.answer_status(files) and seen == [42]
    assert json.loads((files.dir / "regions.json").read_text())["pid"] == 42
    (files.dir / "status.request").write_text(json.dumps({"regions": 77}))
    assert status.answer_status(files) and seen == [42, 77]
    lines = (files.state / "diagnostics" / "regions.jsonl").read_text().splitlines()
    assert [json.loads(x)["pid"] for x in lines] == [42, 77]
