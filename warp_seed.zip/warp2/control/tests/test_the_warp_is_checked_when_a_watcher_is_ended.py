# WARP2/warp2/control/tests/test_the_warp_is_checked_when_a_watcher_is_ended.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_warp_is_checked_when_a_watcher_is_ended.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs with a plain runner.
#  Uses      : warp2/control/watcher_service.py (_watch_worker, HEARTBEAT_STALE).
#  Description:
#    When the service ends a stale watcher, it first reads the runner's beat
#    once and writes whether the warp was alive then, as its own lives-log
#    line (BUILD_LOG 636, Muse-579). The check never holds the ending back.
#  User intention (Andrew, 2026-10-02): a restart watcher he can trust while
#    he is away; the record must say what really happened.
# ============================================================================
from __future__ import annotations

import tempfile
import time
from pathlib import Path

import warp2.control.watcher_service as service


class _Worker:
    """Intention: a live worker that never exits by itself and records being ended."""
    pid = 6161

    def __init__(self):
        self.terminated = False

    def poll(self):
        return None

    def terminate(self):
        self.terminated = True

    def kill(self):
        self.terminated = True

    def wait(self, timeout=None):
        return 1


def _root(tmp_path, runner_age=None) -> Path:
    """Intention: a fresh folder with a stale watcher beat and, if asked, a runner beat `runner_age` seconds old."""
    root = Path(tmp_path) if tmp_path else Path(tempfile.mkdtemp(prefix="w2_warpcheck_"))
    (root / "state" / "control").mkdir(parents=True, exist_ok=True)
    (root / "state" / "lanes").mkdir(parents=True, exist_ok=True)
    (root / "state" / "control" / "watcher.beat").write_text(
        f"6161 {time.time() - 400.0:.3f} watching\n", encoding="utf-8")
    if runner_age is not None:
        (root / "state" / "lanes" / "card.beat").write_text(
            f"4242 {time.time() - runner_age:.3f}\n", encoding="utf-8")
    return root


def _run(root: Path, child) -> int:
    """Intention: run the check on a clock that moves only when it sleeps."""
    now = [0.0]

    def sleep(seconds):
        now[0] += seconds

    return service._watch_worker(child, root, sleep=sleep, clock=lambda: now[0])


def _lives(root: Path) -> str:
    """Intention: everything the service wrote to its lives log."""
    path = root / "state" / "control" / "watcher-service.lives.jsonl"
    return path.read_text(encoding="utf-8") if path.exists() else ""


def test_a_fresh_runner_is_logged_alive_and_the_watcher_still_ends(tmp_path=None):
    """Intention: world 1 — warp alive; the stale watcher is ended anyway, and the log says the warp was alive."""
    root = _root(tmp_path, runner_age=2.0)
    child = _Worker()
    assert _run(root, child) == 1
    assert child.terminated
    log = _lives(root)
    assert "warp alive as watcher is ended" in log
    assert '"runner_pid": 4242' in log
    assert log.index("warp alive") < log.index("worker beat stale; ending it")


def test_a_stale_runner_gets_its_own_line(tmp_path=None):
    """Intention: world 2 — both silent; the warp's silence is its own line, not hidden in the watcher line."""
    root = _root(tmp_path, runner_age=service.HEARTBEAT_STALE + 100.0)
    child = _Worker()
    assert _run(root, child) == 1
    assert child.terminated
    assert "runner beat stale too as watcher is ended" in _lives(root)


def test_no_runner_beat_is_said_and_does_not_stop_the_ending(tmp_path=None):
    """Intention: an unreadable runner beat is written as such; the ending goes on."""
    root = _root(tmp_path, runner_age=None)
    child = _Worker()
    assert _run(root, child) == 1
    assert child.terminated
    assert "runner beat unreadable as watcher is ended" in _lives(root)


if __name__ == "__main__":
    for test in (test_a_fresh_runner_is_logged_alive_and_the_watcher_still_ends,
                 test_a_stale_runner_gets_its_own_line,
                 test_no_runner_beat_is_said_and_does_not_stop_the_ending):
        test()
    print("ok")
