# WARP2/warp2/control/tests/test_the_card_counts_every_4096_row_tensor.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_card_counts_every_4096_row_tensor.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/control/inside.py (report); numpy.
#  Description:
#    A memory card (runner or child) says exactly how many tensors/arrays have
#    4096 rows and how many of them are [4096, 512] probe copies — even when
#    there is only one, too small to reach the top-20 shape list.
#  User intention (Andrew, 2026-10-02): "Then do so" — find what fills the
#    memory. Muse-1034 (2026-11-01): add the exact count to the child card so
#    "none at all" can be told from "not big enough to list".
# ============================================================================
from __future__ import annotations

import numpy as np

from warp2.control.inside import report


def test_one_small_probe_is_counted_exactly():
    """Intention: the fix — the old card had no exact count, only the top-20 groups."""
    # Intention: held in a list, as the warp's own parts hold them.
    held = [np.zeros((4096, 512), dtype=np.uint8), np.zeros((4096, 3), dtype=np.uint8)]
    said = report()
    assert "rows_4096" in said, sorted(said)
    rows = said["rows_4096"]
    assert rows["probe_count"] >= 1
    assert rows["count"] >= rows["probe_count"] + 1
    assert "of them are [4096, 512]" in rows["in_words"]
    del held


def test_no_probe_says_zero():
    """Intention: a clean process says 0 in words, not nothing."""
    from warp2.control.inside import _probe_rows
    found = {1: (None, 10, "array", (4095, 512), "uint8", "cpu")}
    rows = _probe_rows(found)
    assert rows["count"] == 0 and rows["probe_count"] == 0
    assert rows["in_words"].startswith("0 tensors/arrays")
