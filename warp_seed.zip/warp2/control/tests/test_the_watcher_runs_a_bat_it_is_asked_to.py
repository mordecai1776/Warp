# WARP2/warp2/control/tests/test_the_watcher_runs_a_bat_it_is_asked_to.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_watcher_runs_a_bat_it_is_asked_to.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/control/bat_request.py (answer_bat, BatAsk),
#              warp2/control/watcher.py (the look calls answer_bat).
#  Description:
#    The watcher runs a WARP2-folder .bat named in state/control/bat.request
#    (BUILD_LOG 1075): started with no keyboard and its words logged, the
#    request removed, the answer written; a path, a non-.bat or a missing
#    file is refused and nothing is started.
#  User intention (Andrew, 2026-11-02): "I need you to have the warp run that bat."
# ============================================================================
"""Tests that the watcher runs only the WARP2 folder's own .bat files when asked."""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

from warp2.control.bat_request import BatAsk, answer_bat


def _files(root):
    """Intention: a stand-in ControlFiles — the control folder and the state folder."""
    state = root / "state"
    (state / "control").mkdir(parents=True, exist_ok=True)
    return SimpleNamespace(dir=state / "control", state=state)


class _Popen:
    """Intention: a stand-in for subprocess.Popen that records what it was asked to start."""

    def __init__(self):
        self.calls = []

    def __call__(self, args, **kwargs):
        self.calls.append((args, kwargs))
        return SimpleNamespace(pid=4242)


def test_a_named_bat_in_the_root_is_started_with_no_keyboard(tmp_path):
    """Intention: the .bat is started through cmd /c, stdin from nothing, words into a log; the ask is gone."""
    (tmp_path / "OLLAMA_ONE_MODEL.bat").write_text("@echo off\r\n", encoding="utf-8")
    files, popen = _files(tmp_path), _Popen()
    (files.dir / "bat.request").write_text("OLLAMA_ONE_MODEL.bat\n", encoding="utf-8")
    assert answer_bat(files, tmp_path, popen=popen) is True
    assert not (files.dir / "bat.request").exists()
    args, kwargs = popen.calls[0]
    assert args == ["cmd", "/c", str((tmp_path / "OLLAMA_ONE_MODEL.bat").resolve())]
    assert kwargs["cwd"] == str(tmp_path.resolve()) and kwargs["stdin"] is not None
    answer = json.loads((files.dir / "bat.last.json").read_text(encoding="utf-8"))
    assert answer["outcome"] == "started" and answer["pid"] == 4242
    assert Path(answer["log"]).parent == files.state / "diagnostics"
    assert Path(answer["log"]).name.startswith("bat_OLLAMA_ONE_MODEL_")


def test_a_path_a_non_bat_or_a_missing_bat_is_refused(tmp_path):
    """Intention: only a plain .bat name that exists in the root is run; nothing is started otherwise."""
    (tmp_path / "run.py").write_text("", encoding="utf-8")
    assert "not a path" in BatAsk(tmp_path, "..\\evil.bat").refused()
    assert "not a path" in BatAsk(tmp_path, "sub/thing.bat").refused()
    assert "not a .bat" in BatAsk(tmp_path, "run.py").refused()
    assert "no such .bat" in BatAsk(tmp_path, "GONE.bat").refused()
    assert "no .bat name" in BatAsk(tmp_path, "\n  \n").refused()
    files, popen = _files(tmp_path), _Popen()
    (files.dir / "bat.request").write_text("GONE.bat", encoding="utf-8")
    assert answer_bat(files, tmp_path, popen=popen) is True
    assert popen.calls == []
    assert json.loads((files.dir / "bat.last.json").read_text(encoding="utf-8"))["outcome"] == "refused"


def test_no_request_does_nothing(tmp_path):
    """Intention: without bat.request nothing is started and nothing written."""
    files, popen = _files(tmp_path), _Popen()
    assert answer_bat(files, tmp_path, popen=popen) is False
    assert popen.calls == [] and not (files.dir / "bat.last.json").exists()


def test_the_watcher_look_asks_for_bats():
    """Intention: the watcher's loop calls answer_bat each look, beside status and window."""
    text = (Path(__file__).resolve().parents[1] / "watcher.py").read_text(encoding="utf-8")
    assert "from warp2.control.bat_request import answer_bat" in text
    assert "answer_bat(files, root)" in text
