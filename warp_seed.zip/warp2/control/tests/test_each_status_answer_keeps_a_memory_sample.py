# WARP2/warp2/control/tests/test_each_status_answer_keeps_a_memory_sample.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_each_status_answer_keeps_a_memory_sample.py
#  Used by   : CHECK_FIXES.bat.
#  Uses      : warp2/control/status.py, warp2/control/memory_samples.py,
#              warp2/control/files.py.
#  Description:
#    Each status answer keeps one line in diagnostics/memory_samples.jsonl:
#    sample time, RAM, commit, each Python process with its start time, age,
#    private MB and a short label, and the warp step in flight (the last
#    journal entry's seq and verb, and how long since it was written). Two
#    answers keep two lines; an unreadable journal still keeps the sample.
#    Other-process PID and memory rows survive the next status overwrite.
#    Fails on the code before BUILD_LOG 925 (no memory_samples module; the
#    answer kept nothing but the overwritten status.json).
#  User intention (Andrew, 2026-10-16): get everything in working order; keep
#    everything.
# ============================================================================
import json
import time


def _files(tmp_path):
    """Intention: control files over a fresh state folder."""
    from warp2.control.files import ControlFiles
    files = ControlFiles(tmp_path / "state")
    files.ready()
    return files


def _found(now):
    """Intention: a status answer with a runner that started an hour ago and a picture child."""
    return {"when": "2026-10-29 10:06:57", "memory_free_mb": 6012, "commit_free_mb": 7810,
            "workload": {"runner": {"pid": 24968, "fresh": True, "alive": True}},
            "python": [{"pid": 24968, "parent": 25288, "started": int(now) - 3600, "private_mb": 5648,
                        "working_mb": 106, "command": "C:\\Python311\\python.exe -B -m warp2.control.preflight C:\\WARP2"},
                       {"pid": 18444, "parent": 24968, "started": None, "private_mb": 1289, "working_mb": 153,
                        "command": "C:\\Python311\\python.exe C:\\Temp\\tmpor\\look.py C:\\Temp\\x"}]}


def test_each_answer_keeps_one_sample_tied_to_the_step(tmp_path, monkeypatch):
    """Intention: two answers give two lines, each naming the step that finished last and the processes."""
    import warp2.control.status as status
    now = time.time()
    monkeypatch.setattr(status, "status", lambda state=None: _found(now))
    files = _files(tmp_path)
    journal = files.state / "journals" / "continuous.jsonl"
    journal.parent.mkdir(parents=True, exist_ok=True)
    journal.write_text(json.dumps({"seq": 11764, "verb": "wire_the_kg"}) + "\n" +
                       json.dumps({"seq": 11765, "verb": "take_what_was_asked_for"}) + "\n")
    for _ in range(2):
        (files.dir / "status.request").write_text("")
        assert status.answer_status(files)
    lines = (files.state / "diagnostics" / "memory_samples.jsonl").read_text().splitlines()
    assert len(lines) == 2
    row = json.loads(lines[-1])
    assert row["step"]["after_seq"] == 11765 and row["step"]["after_verb"] == "take_what_was_asked_for"
    assert row["step"]["running_seconds"] >= 0 and row["runner_pid"] == 24968 and row["commit_free_mb"] == 7810
    runner, child = row["python"]
    assert runner["label"] == "warp2.control.preflight" and runner["private_mb"] == 5648
    assert 3590 <= runner["age_seconds"] <= 3700
    assert child["label"] == "look.py" and child["age_seconds"] is None


def test_a_missing_journal_still_keeps_the_sample(tmp_path):
    """Intention: no journal means an empty step, not a lost sample or an exception."""
    from warp2.control.memory_samples import MemorySamples
    files = _files(tmp_path)
    assert MemorySamples(files.state).keep(_found(time.time()))
    row = json.loads((files.state / "diagnostics" / "memory_samples.jsonl").read_text())
    assert row["step"] == {} and len(row["python"]) == 2
    assert row["biggest_others"] == []


def test_other_process_rows_survive_the_next_status_answer(tmp_path, monkeypatch):
    """Intention: retain the old dip's other-process identities and memory after status.json changes."""
    import warp2.control.status as status
    first = _found(time.time())
    first["biggest_others"] = [{"pid": 101, "name": "llama-server.exe", "private_mb": 4792,
                                "working_mb": 512},
                               {"pid": 102, "name": "llama-server.exe", "private_mb": 3329,
                                "working_mb": 256}]
    second = _found(time.time())
    second["biggest_others"] = [{"pid": 103, "name": "vmmem", "private_mb": 4104,
                                 "working_mb": 121}]
    answers = iter([first, second])
    monkeypatch.setattr(status, "status", lambda state=None: next(answers))
    files = _files(tmp_path)
    for _ in range(2):
        (files.dir / "status.request").write_text("{}")
        assert status.answer_status(files)
    rows = [json.loads(line) for line in
            (files.state / "diagnostics" / "memory_samples.jsonl").read_text().splitlines()]
    assert rows[0]["biggest_others"] == first["biggest_others"]
    assert rows[1]["biggest_others"] == second["biggest_others"]
    assert json.loads((files.dir / "status.json").read_text())["biggest_others"] == second["biggest_others"]


def test_start_times_are_read_apart_from_the_memory_rows(monkeypatch):
    """Intention: when the start-time question fails, the memory rows still come back, with started None."""
    import warp2.control.status as status
    def fake(script):
        """Intention: answer the memory questions, fail the start-time one."""
        if "Started" in script:
            return None
        if "Win32_OperatingSystem" in script:
            return {"FreePhysicalMemory": 1024, "TotalVisibleMemorySize": 2048}
        if "-notmatch" in script:
            return []
        return [{"ProcessId": 5, "ParentProcessId": 1, "WorkingSetSize": 2**20, "PrivatePageCount": 2**21,
                 "CommandLine": "python -m warp2.run web"}]
    monkeypatch.setattr(status, "_powershell", fake)
    rows = status.status()["python"]
    assert rows == [{"pid": 5, "parent": 1, "working_mb": 1, "private_mb": 2, "started": None,
                     "command": "python -m warp2.run web"}]
    monkeypatch.setattr(status, "_powershell", lambda s: [{"ProcessId": 5, "Started": 1793280000}]
                        if "Started" in s else fake(s))
    assert status.status()["python"][0]["started"] == 1793280000
