# WARP2/warp2/control/tests/test_the_service_leaves_its_own_trace.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_service_leaves_its_own_trace.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs with a plain runner.
#  Uses      : warp2/control/watcher_service.py (supervise, _watch_worker),
#              warp2/control/service_trace.py (ServiceTrace).
#  Description:
#    The watcher service writes a lives log (its start, each worker's start
#    and end, its stop) and a rolling beat at most every 30 s. Seen
#    2026-10-18: watcher and service both gone, nothing said when or why.
#  User intention (Andrew, 2026-10-16): the catastrophic failure is the whole
#    system stopping; a failure must leave something to learn from.
# ============================================================================
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import warp2.control.watcher_service as service


class _Child:
    """Intention: a worker that runs for `turns` polls and then exits with `code`."""

    def __init__(self, code: int, turns: int = 0, pid: int = 5151):
        self.code, self.turns, self.pid = code, turns, pid

    def poll(self):
        if self.turns > 0:
            self.turns -= 1
            return None
        return self.code

    def wait(self, timeout=None):
        return self.code


def _scratch() -> Path:
    """Intention: a fresh folder for one test when no pytest tmp_path is given."""
    return Path(tempfile.mkdtemp(prefix="w2_service_trace_"))


def _clock():
    """Intention: a clock that moves only when the code sleeps."""
    now = [0.0]

    def sleep(seconds):
        now[0] += seconds
    return now, sleep, (lambda: now[0])


def _lives(root: Path) -> list:
    """Intention: the lives log, as rows."""
    path = root / "state" / "control" / "watcher-service.lives.jsonl"
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def test_a_service_life_is_on_the_record(tmp_path=None):
    """Intention: start, worker start with its pid, worker end with its code, and stop are written."""
    root = Path(tmp_path) if tmp_path else _scratch()
    _, sleep, clock = _clock()
    assert service.supervise(root, popen=lambda *a, **k: _Child(0), sleep=sleep, clock=clock) == 0
    rows = _lives(root)
    assert [r["what"] for r in rows] == ["service started", "worker started", "worker ended", "service stopped"]
    assert rows[1]["worker_pid"] == 5151 and rows[2]["code"] == 0
    assert all("service_pid" in r and "when" in r for r in rows)


def test_the_service_beats_while_its_worker_runs(tmp_path=None):
    """Intention: a beat file with the service's pid exists while it waits on a worker."""
    root = Path(tmp_path) if tmp_path else _scratch()
    _, sleep, clock = _clock()
    service._watch_worker(_Child(service.RESTART_WATCHER, turns=3), root, sleep=sleep, clock=clock)
    import os
    pid, at, note = (root / "state" / "control" / "watcher-service.beat").read_text(encoding="utf-8").split()
    assert int(pid) == os.getpid() and float(at) > 0 and note == "serving"


def test_the_beat_is_paced(tmp_path=None):
    """Intention: no more than one beat every 30 s of the service's clock."""
    from warp2.control.service_trace import BEAT_EVERY, ServiceTrace
    root = Path(tmp_path) if tmp_path else _scratch()
    now = [0.0]
    trace = ServiceTrace(root, clock=lambda: now[0])
    trace.beat_now()
    first = trace.beat.read_text(encoding="utf-8")
    trace.beat.write_text("x", encoding="utf-8")
    now[0] += BEAT_EVERY / 2
    trace.beat_now()
    assert trace.beat.read_text(encoding="utf-8") == "x"
    now[0] += BEAT_EVERY
    trace.beat_now()
    assert trace.beat.read_text(encoding="utf-8").endswith("serving\n") and first


def test_a_stale_worker_ending_is_said(tmp_path=None):
    """Intention: when the service ends a silent worker, the lives log says so."""
    root = Path(tmp_path) if tmp_path else _scratch()
    _, sleep, clock = _clock()

    class _Silent(_Child):
        def terminate(self):
            self.turns = 0
    assert service._watch_worker(_Silent(1, turns=10**6), root, sleep=sleep, clock=clock) == 1
    assert _lives(root)[-1]["what"] == "worker beat stale; ending it"


def test_the_watcher_task_is_not_stopped_on_battery():
    """Intention: the scheduled task that runs the service is not ended by the PC going on battery
    or by idle ending — either would end service and watcher together with no trace."""
    script = (Path(__file__).resolve().parents[3] / "INSTALL_RESTART_WATCHER.ps1").read_text(encoding="utf-8")
    for switch in ("-AllowStartIfOnBatteries", "-DontStopIfGoingOnBatteries", "-DontStopOnIdleEnd"):
        assert switch in script, switch
