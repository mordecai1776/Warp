# WARP3/warp2/control/tests/test_a_restart_says_how_the_runner_ended.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/control/tests/test_a_restart_says_how_the_runner_ended.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/control/{files,supervisor}.py with a stand-in for Windows
#              (no process is touched).
#  Description:
#    The supervisor's restart says how the runner ended: it sealed its sitting
#    (and why - "the source changed" is the planned reload), or it wrote no
#    seal and ended mid-step (BUILD_LOG 2346).
#  User intention (Andrew, 2026-10-07 / 2026-10-16): keep the warp running
#    and recoverable on its own. Found 2026-11-28: every "runner absent"
#    restart since 11-23 followed a seal for a source change, and was hunted
#    as a silent crash because the record did not say so.
# ============================================================================
from __future__ import annotations

import json

from warp2.control.files import ControlFiles


class _Hands:
    """Intention: a pretend Windows with no runner and no start in its gate."""
    def registered(self):
        return []

    def starting(self):
        return []


def _files(tmp_path, monkeypatch, last_rows):
    """Intention: control files for an expected run whose runner is gone, its journal ending in `last_rows`."""
    monkeypatch.setenv("WARP3_RUNTIME_DIR", str(tmp_path / "runtime"))
    files = ControlFiles(tmp_path / "state")
    files.ready()
    files.expected.write_text("expected", encoding="utf-8")
    journal = files.state / "journals" / "continuous.jsonl"
    journal.parent.mkdir(parents=True, exist_ok=True)
    journal.write_text("".join(json.dumps(row) + "\n" for row in last_rows) + '{"half a li', encoding="utf-8")
    return files


def _asked(files):
    """Intention: the supervisor's answer once enough misses were seen to decide."""
    from warp2.control.supervisor import MISSING_OBSERVATIONS, RunnerSupervisor
    supervisor, asked = RunnerSupervisor(clock=lambda: 1000.0), None
    for _ in range(MISSING_OBSERVATIONS):
        asked = supervisor.observe(files, _Hands())
    return asked


def test_a_runner_that_sealed_for_a_source_change_is_named_a_reload(tmp_path, monkeypatch):
    files = _files(tmp_path, monkeypatch, [
        {"verb": "mine_while_quiet", "ts": "2026-11-28T00:43:24+00:00"},
        {"verb": "seal_session", "ts": "2026-11-28T00:44:01+00:00", "ended_because": "the source changed"}])
    why = _asked(files)["why"]
    assert why.startswith("supervisor: expected runner process is absent")
    assert "it sealed its sitting at 2026-11-28T00:44:01+00:00 because the source changed" in why


def test_a_runner_that_ended_mid_step_is_named_so(tmp_path, monkeypatch):
    files = _files(tmp_path, monkeypatch, [{"verb": "train_eye", "ts": "2026-11-27T23:04:43+00:00"}])
    why = _asked(files)["why"]
    assert "it wrote no seal; its last line was train_eye at 2026-11-27T23:04:43" in why


def test_no_journal_keeps_the_plain_why(tmp_path, monkeypatch):
    monkeypatch.setenv("WARP3_RUNTIME_DIR", str(tmp_path / "runtime"))
    files = ControlFiles(tmp_path / "state")
    files.ready()
    files.expected.write_text("expected", encoding="utf-8")
    assert _asked(files)["why"] == "supervisor: expected runner process is absent"
