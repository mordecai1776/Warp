# WARP3/warp2/control/tests/test_a_planned_restart_waits_for_the_open_step.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/control/tests/test_a_planned_restart_waits_for_the_open_step.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/control/restart.py with the stand-ins of test_restart.py
#              (no process is touched); the step in flight is stood in.
#  Description:
#    A planned restart waits for the open step up to its measured usual time;
#    past it the runner is forced and the cut step is filed as its own receipt.
#    An automatic recovery, or a request that says it cannot wait, keeps the
#    short grace. (BUILD_LOG 2191, muse-2191.)
#  User intention (Andrew, keep-everything, muse-503): everything is kept,
#    even from a failed run - a forced stop must not drop a receipt silently.
# ============================================================================
from __future__ import annotations

import json

from warp2.control import overdue
from warp2.control.restart import Restart
from warp2.control.tests.test_restart import Clock, Hands, _setup

OPEN = {"verb": "train_chat", "lane": "main", "since": 0.0, "running_seconds": 100.0,
        "usual_seconds": 600.0, "basis": "measured", "overdue": False}


def _run(tmp_path, monkeypatch, asked, quits_after, step=OPEN):
    """Intention: one restart with a stood-in open step; returns the answer and the hands."""
    monkeypatch.setattr(overdue, "step_in_flight", lambda state, now=None: dict(step))
    state = _setup(tmp_path, monkeypatch)
    clock = Clock()
    hands = Hands(state, runner_quits_after=quits_after, clock=clock)
    said = Restart(tmp_path, state, hands, clock=clock, sleep=clock.sleep).run(asked)
    return said, hands, state


def _step(said, name):
    return [s for s in said["steps"] if s["step"] == name]


def test_planned_restart_lets_the_open_step_end(tmp_path, monkeypatch):
    """Intention: the step ends at 300 s, inside its usual time - the runner is not forced."""
    said, hands, state = _run(tmp_path, monkeypatch, {"why": "planned", "grace_seconds": 60}, quits_after=300.0)
    assert ("end", 11, True, True) not in hands.done
    waited = _step(said, "waiting_for_open_step")[0]
    assert waited["verb"] == "train_chat" and waited["wait_s"] == 500.0
    assert not (state / "control" / "restart_losses.jsonl").exists()


def test_past_its_usual_time_it_is_forced_and_the_loss_is_filed(tmp_path, monkeypatch):
    """Intention: a step still open past its usual time is forced, and the cut is its own receipt."""
    said, hands, state = _run(tmp_path, monkeypatch, {"why": "planned", "grace_seconds": 60}, quits_after=None)
    assert ("end", 11, True, True) in hands.done
    assert _step(said, "runner_stopped")[0]["at_s"] >= 500
    cut = _step(said, "open_step_cut")[0]
    assert cut["verb"] == "train_chat" and cut["ran_seconds"] >= 600
    lines = (state / "control" / "restart_losses.jsonl").read_text(encoding="utf-8").splitlines()
    loss = json.loads(lines[-1])
    assert loss["verb"] == "train_chat" and loss["why_forced"] == "ran past its measured usual time"


def test_automatic_recovery_keeps_the_short_grace(tmp_path, monkeypatch):
    """Intention: a recovery is not a planned restart - forced at the grace, the loss still filed."""
    said, hands, state = _run(tmp_path, monkeypatch, {"why": "auto", "automatic": True, "grace_seconds": 60},
                              quits_after=None)
    assert not _step(said, "waiting_for_open_step")
    assert _step(said, "runner_stopped")[0]["at_s"] < 120


def test_a_request_that_cannot_wait_says_so(tmp_path, monkeypatch):
    """Intention: "wait_for_open_step": false keeps the short grace."""
    said, hands, state = _run(tmp_path, monkeypatch,
                              {"why": "urgent", "grace_seconds": 60, "wait_for_open_step": False}, quits_after=None)
    assert not _step(said, "waiting_for_open_step")
    assert _step(said, "runner_stopped")[0]["at_s"] < 120


def test_an_unmeasured_step_is_not_waited_for_but_its_cut_is_filed(tmp_path, monkeypatch):
    """Intention: with no measured usual time there is nothing to wait up to; the cut is still not silent."""
    step = dict(OPEN, basis="default")
    said, hands, state = _run(tmp_path, monkeypatch, {"why": "planned", "grace_seconds": 60}, quits_after=None,
                              step=step)
    assert _step(said, "runner_stopped")[0]["at_s"] < 120
    assert _step(said, "open_step_cut")[0]["why_forced"].startswith("no measured usual time")


def test_a_side_lane_step_is_not_waited_for_but_its_cut_is_filed(tmp_path, monkeypatch):
    """Intention (BUILD_LOG 2192, muse-2193): a planned restart during a side-lane pass (assemble_webs, usual ~4 h)
    keeps the short grace; the cut pass is still filed with its reason."""
    step = dict(OPEN, verb="assemble_webs", lane="side", usual_seconds=14400.0)
    said, hands, state = _run(tmp_path, monkeypatch, {"why": "planned", "grace_seconds": 60}, quits_after=None,
                              step=step)
    assert not _step(said, "waiting_for_open_step")
    assert _step(said, "not_waiting_for_open_step")[0]["verb"] == "assemble_webs"
    assert _step(said, "runner_stopped")[0]["at_s"] < 120
    loss = json.loads((state / "control" / "restart_losses.jsonl").read_text(encoding="utf-8").splitlines()[-1])
    assert loss["verb"] == "assemble_webs" and loss["why_forced"].startswith("a side-lane step")


def test_an_automatic_recovery_files_the_cut_it_makes(tmp_path, monkeypatch):
    """Intention (BUILD_LOG 2192): a recovery keeps the short grace, but a step it cuts is never a silent loss."""
    said, hands, state = _run(tmp_path, monkeypatch, {"why": "auto", "automatic": True, "grace_seconds": 60},
                              quits_after=None)
    loss = json.loads((state / "control" / "restart_losses.jsonl").read_text(encoding="utf-8").splitlines()[-1])
    assert loss["verb"] == "train_chat" and loss["why_forced"].startswith("an automatic recovery")
