# WARP2/warp2/control/tests/test_the_watcher_beats_while_busy.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_watcher_beats_while_busy.py
#  Used by   : pytest (CHECK_FIXES.bat); also runs with a plain runner.
#  Uses      : warp2/control/{files,watcher}.py; a stand-in status answer.
#  Description:
#    A slow status answer must not leave the watcher's beat stale. Before
#    2026-10-17 the watcher beat only at the top of its loop; the process list
#    behind status took ~40 s on a busy machine, and watcher_service ends a
#    watcher whose beat is 60 s old.
#  User intention (Andrew, 2026-10-02): a restart watcher he can trust while
#    he is away — asking it for status must not kill it.
# ============================================================================
from __future__ import annotations

import time
from pathlib import Path

import warp2.control.status as status_module
import warp2.control.watcher as watcher
from warp2.control.files import ControlFiles


class CountingFiles(ControlFiles):
    """Intention: real control files that also count every beat."""
    def __init__(self, state):
        super().__init__(state)
        self.beats = 0

    def beat_now(self, note: str = "watching") -> None:
        """Intention: count, then beat as normal."""
        self.beats += 1
        super().beat_now(note)


def test_keep_beating_beats_during_a_slow_call(tmp_path=None):
    """Intention: a 0.5 s call with a 0.05 s beat gets several beats, and none after it ends."""
    state = Path(tmp_path or _scratch()) / "state"
    files = CountingFiles(state)
    files.ready()
    with watcher.KeepBeating(files, every=0.05):
        time.sleep(0.5)
    during = files.beats
    time.sleep(0.2)
    assert during >= 3, during
    assert files.beats == during


def test_a_slow_status_answer_keeps_the_watcher_beating(tmp_path=None):
    """Intention: through the real loop (once), a slow status answer is beaten through."""
    root = Path(tmp_path or _scratch())
    files = ControlFiles(root / "state")
    files.ready()
    (files.dir / "status.request").write_text("{}", encoding="utf-8")
    seen = []

    def slow_answer(f):
        start = files.beat.read_text(encoding="utf-8").split()[1]
        time.sleep(0.5)
        seen.append(start != files.beat.read_text(encoding="utf-8").split()[1])
        return True

    old_answer, old_every = status_module.answer_status, watcher.BEAT_WHILE_BUSY
    status_module.answer_status = slow_answer
    watcher.BEAT_WHILE_BUSY = 0.05
    try:
        watcher.watch(root, once=True)
    finally:
        status_module.answer_status, watcher.BEAT_WHILE_BUSY = old_answer, old_every
    assert seen == [True]


def _scratch() -> str:
    """Intention: a fresh folder when run without pytest."""
    import tempfile
    return tempfile.mkdtemp()
