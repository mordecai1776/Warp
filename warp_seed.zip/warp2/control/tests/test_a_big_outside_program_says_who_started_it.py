# WARP2/warp2/control/tests/test_a_big_outside_program_says_who_started_it.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_a_big_outside_program_says_who_started_it.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/control/status.py (status, _powershell).
#  Description:
#    The biggest other programs in the status answer carry their parent
#    process and command line (BUILD_LOG 1074), so a big program that is not
#    the warp's can be traced to what started it.
#  User intention (Andrew, 2026-11-02): "take a look and see what is causing
#    the slowdown."
# ============================================================================
"""Tests that a big outside program in the status answer says who started it."""
from __future__ import annotations

from warp2.control import status


def test_a_big_outside_program_carries_its_parent_and_command(monkeypatch):
    """Intention: the others query asks for ParentProcessId and CommandLine, and both reach the row."""
    asked = []

    def fake(script):
        asked.append(script)
        if "Win32_OperatingSystem" in script:
            return {"FreePhysicalMemory": 1024, "TotalVisibleMemorySize": 2048,
                    "FreeVirtualMemory": 1024, "TotalVirtualMemorySize": 4096}
        if "-notmatch" in script:
            return [{"ProcessId": 28544, "ParentProcessId": 900, "Name": "llama-server.exe",
                     "WorkingSetSize": 2**30, "PrivatePageCount": 5 * 2**30,
                     "CommandLine": "llama-server.exe -m big.gguf --port 8081"}]
        return []

    monkeypatch.setattr(status, "_powershell", fake)
    found = status.status()
    others_query = [s for s in asked if "-notmatch" in s][0]
    assert "ParentProcessId" in others_query and "CommandLine" in others_query
    row = found["biggest_others"][0]
    assert row["parent"] == 900 and row["command"] == "llama-server.exe -m big.gguf --port 8081"
    assert row["name"] == "llama-server.exe" and row["private_mb"] == 5120
