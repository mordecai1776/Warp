# WARP2/warp2/control/tests/test_a_command_file_runs_like_a_shell.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_a_command_file_runs_like_a_shell.py
#  Used by   : pytest (RUN_TESTS.bat, CHECK_FIXES.bat).
#  Uses      : warp2/control/commands.py (CommandLane, Commands, CommandAsk,
#              Callers, CommandHome), warp2/control/watcher.py (read as text).
#  Description:
#    The command lane (BUILD_LOG 1079): a command file from a known sender is
#    started in its shell with no keyboard, inside WARP2, and answered with
#    its exit code and words when it ends; one past its deadline has its tree
#    ended; an unknown sender, a path outside WARP2, an unknown shell or
#    nothing to run is refused; a Python command runs from a file; a command
#    a former watcher started is followed by its pid; used ids are refused
#    without replacing their files or running children; the watcher looks.
#  User intention (Andrew, 2026-11-02): "a file that you can run that would
#    act as shell access for when you don't have it ... accessible for every model."
# ============================================================================
"""Tests that a command file is run like a shell for a model that has none, and answered."""
from __future__ import annotations

import json
import pytest
from pathlib import Path
from types import SimpleNamespace

from warp2.control.commands import Callers, CommandAsk, CommandHome, CommandLane, Commands


def _tree(root):
    """Intention: a tree with a roster, builder scores and a callers file."""
    (root / "models.json").write_text(json.dumps({"models": [{"name": "qwen3:1.7b"}]}), encoding="utf-8")
    (root / "state" / "builders").mkdir(parents=True)
    (root / "state" / "builders" / "scores.json").write_text(
        json.dumps({"builders": {"Claude": {}, "Antigravity, hourly run": {}}}), encoding="utf-8")
    (root / "sub").mkdir()
    home = CommandHome(root / "state")
    home.callers.write_text(json.dumps({"names": ["Remy"]}), encoding="utf-8")
    return root


class _Child:
    """Intention: a stand-in process — running until told its code."""

    def __init__(self, pid):
        self.pid, self.code = pid, None

    def poll(self):
        return self.code


class _Popen:
    """Intention: a stand-in for subprocess.Popen that records each start and writes the words it is told."""

    def __init__(self):
        self.calls, self.children = [], []

    def __call__(self, argv, **kwargs):
        self.calls.append((argv, kwargs))
        kwargs["stdout"].write(b"hello from the command\r\n")
        child = _Child(100 + len(self.children))
        self.children.append(child)
        return child


class _Hands:
    """Intention: a stand-in for WindowsHands — which pids are alive, and which were ended."""

    def __init__(self):
        self.alive_pids, self.ended = set(), []

    def alive(self, pid):
        return pid in self.alive_pids

    def end(self, pid, force, tree):
        self.ended.append((pid, force, tree))
        return "ended"


def _lane(root, clock):
    """Intention: a lane on stand-ins, with a STALE of 60."""
    popen, hands = _Popen(), _Hands()
    return CommandLane(root, root / "state", hands=hands, popen=popen, clock=clock, stale=60.0), popen, hands


def test_a_known_sender_s_command_runs_and_is_answered(tmp_path):
    """Intention: Claude's cmd command starts with no keyboard in WARP2; when it ends the answer has its code and words."""
    root = _tree(tmp_path)
    now = [1000.0]
    lane, popen, _ = _lane(root, lambda: now[0])
    cid = Commands(root / "state").send("Claude", "echo hello", seconds=30)
    assert lane.look() == {"started": 1, "finished": 0}
    argv, kwargs = popen.calls[0]
    assert argv == ["cmd", "/c", "echo hello"] and kwargs["cwd"] == str(root.resolve()) and kwargs["stdin"] is not None
    assert "PYTHONPATH" in kwargs["env"]
    assert Commands(root / "state").result(cid) is None, "no answer while it runs"
    popen.children[0].code = 0
    lane.look()
    answer = Commands(root / "state").result(cid)
    assert answer["outcome"] == "finished" and answer["exit_code"] == 0 and "hello from the command" in answer["said"]
    journal = (root / "state" / "control" / "commands" / "journal.jsonl").read_text(encoding="utf-8").splitlines()
    assert [json.loads(line)["outcome"] for line in journal] == ["started", "finished"]


def test_a_command_past_its_deadline_has_its_tree_ended(tmp_path):
    """Intention: still running past its seconds -> its whole tree ended by force, and said so."""
    root = _tree(tmp_path)
    now = [1000.0]
    lane, popen, hands = _lane(root, lambda: now[0])
    cid = Commands(root / "state").send("Antigravity", "ping -n 99 127.0.0.1", seconds=10)
    lane.look()
    now[0] += 11
    lane.look()
    assert hands.ended == [(100, True, True)]
    assert Commands(root / "state").result(cid)["outcome"] == "ended at its deadline"


def test_what_is_refused_is_answered_and_never_started(tmp_path):
    """Intention: an unknown sender, no sender, an unknown shell, nothing to run, a folder outside WARP2."""
    root = _tree(tmp_path)
    lane, popen, _ = _lane(root, lambda: 1000.0)
    send = Commands(root / "state")
    ids = [send.send("Stranger", "dir"), send.send("", "dir"), send.send("Claude", "dir", shell="bash"),
           send.send("Claude", "   "), send.send("Claude", "dir", cwd="..")]
    lane.look()
    assert popen.calls == []
    whys = [send.result(i)["why"] for i in ids]
    assert "not a model, a builder" in whys[0] and "who sent it" in whys[1] and "shell must be" in whys[2]
    assert "nothing to run" in whys[3] and "inside the WARP2 folder" in whys[4]


def test_the_callers_are_the_roster_the_builders_and_the_listed_names(tmp_path):
    """Intention: a roster model, a builder and its first word, and a name Andrew listed are known; case does not matter."""
    root = _tree(tmp_path)
    known = Callers(root, CommandHome(root / "state")).known()
    assert {"qwen3:1.7b", "claude", "antigravity", "antigravity, hourly run", "remy"} <= known
    assert CommandAsk(root, {"by": "REMY", "run": "dir"}, 60).refused(known) == ""


def test_a_python_command_runs_from_its_own_file_in_a_folder_inside_warp2(tmp_path):
    """Intention: the program is written to scripts/<id>.py and run there, from the folder named."""
    root = _tree(tmp_path)
    lane, popen, _ = _lane(root, lambda: 1000.0)
    cid = Commands(root / "state").send("Claude", "print('hi')\n", shell="python", cwd="sub")
    lane.look()
    argv, kwargs = popen.calls[0]
    script = Path(argv[-1])
    assert script.name == f"{cid}.py" and script.read_text(encoding="utf-8") == "print('hi')\n"
    assert kwargs["cwd"] == str((root / "sub").resolve())


def test_a_command_a_former_watcher_started_is_followed_by_its_pid(tmp_path):
    """Intention: a new lane (a reloaded watcher) finds the running record; alive waits, gone is finished with no code."""
    root = _tree(tmp_path)
    now = [1000.0]
    first, _, _ = _lane(root, lambda: now[0])
    cid = Commands(root / "state").send("Claude", "dir", seconds=100)
    first.look()
    second, _, hands = _lane(root, lambda: now[0])
    hands.alive_pids = {100}
    assert second.look()["finished"] == 0
    hands.alive_pids = set()
    second.look()
    answer = Commands(root / "state").result(cid)
    assert answer["outcome"] == "finished" and answer["exit_code"] is None


def test_the_watcher_runs_the_lane_each_look():
    """Intention: one lane for the watcher's life, looked at each turn of its loop."""
    text = (Path(__file__).resolve().parents[1] / "watcher.py").read_text(encoding="utf-8")
    assert "commands = commands or CommandLane(root, files.state)" in text and "commands.look()" in text


@pytest.mark.parametrize("folder,suffix", [("scripts", ".py"), ("out", ".txt"), ("done", ".json")])
def test_a_used_command_id_is_refused_without_touching_its_files(tmp_path, folder, suffix):
    """Intention: the cp1 incident cannot recur: an old script, output or answer reserves its id across watchers."""
    root = _tree(tmp_path)
    lane, popen, _ = _lane(root, lambda: 1000.0)
    old = getattr(lane.home, folder) / ("cp1" + suffix)
    old.write_bytes(b"the original command's evidence")
    lane.home.write(lane.home.inbox / "cp1.json", {"by": "Claude", "shell": "python", "run": "print('new')"})
    assert lane.look() == {"started": 0, "finished": 0}
    assert not popen.calls and old.read_bytes() == b"the original command's evidence"
    refused = json.loads(lane.home.journal.read_text(encoding="utf-8").splitlines()[-1])
    assert refused["outcome"] == "refused" and refused["requested_id"] == "cp1"
    assert "already used" in refused["why"] and refused["id"] != "cp1"
    assert Commands(root / "state").result(refused["id"]) == {k: v for k, v in refused.items() if k != "at"}


def test_a_duplicate_does_not_replace_a_running_command(tmp_path):
    """Intention: a second request with a running id starts nothing and leaves its child and eventual result intact."""
    root = _tree(tmp_path)
    lane, popen, _ = _lane(root, lambda: 1000.0)
    cid = Commands(root / "state").send("Claude", "echo first")
    lane.look()
    original = (lane.home.running / f"{cid}.json").read_bytes()
    lane.home.write(lane.home.inbox / "duplicate.json", {"id": cid, "by": "Claude", "run": "echo second"})
    assert lane.look() == {"started": 0, "finished": 0}
    assert len(popen.calls) == 1 and (lane.home.running / f"{cid}.json").read_bytes() == original
    assert lane.children[cid] is popen.children[0]
    popen.children[0].code = 0
    assert lane.look()["finished"] == 1
    assert Commands(root / "state").result(cid)["outcome"] == "finished"


def test_a_script_appearing_after_the_id_check_is_not_overwritten(tmp_path, monkeypatch):
    """Intention: exclusive script creation also preserves its output when a file appears after the lane checked."""
    root = _tree(tmp_path)
    lane, popen, _ = _lane(root, lambda: 1000.0)
    script, out = lane.home.scripts / "race.py", lane.home.out / "race.txt"
    script.write_text("old program", encoding="utf-8")
    out.write_text("old output", encoding="utf-8")
    monkeypatch.setattr(lane.home, "used", lambda cid: False)
    lane.home.write(lane.home.inbox / "race.json", {"by": "Claude", "shell": "python", "run": "new program"})
    assert lane.look() == {"started": 0, "finished": 0} and not popen.calls
    assert script.read_text(encoding="utf-8") == "old program" and out.read_text(encoding="utf-8") == "old output"
    assert "FileExistsError" in Commands(root / "state").result("race")["why"]
