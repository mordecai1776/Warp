# WARP2/warp2/control/tests/test_the_watcher_beats_through_a_restart.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/tests/test_the_watcher_beats_through_a_restart.py
#  Used by   : pytest (CHECK_FIXES.bat).
#  Uses      : warp2/control/{files,watcher,restart}.py; a stand-in Restart.
#  Description:
#    A restart whose slow calls never sleep must not leave the watcher's beat
#    stale. 2026-10-25 05:58 UTC: watcher 23216 took a restart request, wrote
#    the runner's reload flag, went 60 s without a beat, and watcher_service
#    ended it mid-restart — the restart was never done (BUILD_LOG 598).
#  User intention (Andrew, 2026-10-02): a restart watcher he can trust while
#    he is away.
# ============================================================================
from __future__ import annotations

import time
from pathlib import Path

import warp2.control.restart as restart_module
import warp2.control.watcher as watcher
from warp2.control.files import ControlFiles


def test_a_slow_restart_keeps_the_watcher_beating(tmp_path):
    """Intention: fails on the old watcher (no beat during Restart.run); passes when the restart is beaten through."""
    root = Path(tmp_path)
    files = ControlFiles(root / "state")
    files.ready()
    files.request.write_text('{"why": "test"}', encoding="utf-8")
    seen = []

    class SlowRestart:
        """Intention: stands in for Restart; one long call with no sleep, like a slow process list."""
        def __init__(self, *args, **kwargs):
            pass

        def run(self, asked):
            start = files.beat.read_text(encoding="utf-8").split()[1]
            time.sleep(0.5)
            seen.append(start != files.beat.read_text(encoding="utf-8").split()[1])
            return {"outcome": "restarted"}

    old_restart, old_every = restart_module.Restart, watcher.BEAT_WHILE_BUSY
    restart_module.Restart = SlowRestart
    watcher.BEAT_WHILE_BUSY = 0.05
    try:
        watcher.watch(root, once=True)
    finally:
        restart_module.Restart, watcher.BEAT_WHILE_BUSY = old_restart, old_every
    assert seen == [True]
