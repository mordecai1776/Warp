# WARP2/warp2/control/watcher.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/watcher.py
#  Used by   : warp2/control/watcher_service.py (scheduled task) or direct
#              manual launch through RESTART_WATCHER.bat.
#  Uses      : warp2/control/files.py, warp2/control/restart.py,
#              warp2/control/windows.py, warp2/control/status.py (memory and
#              processes on request), warp2/control/window.py (close the
#              window on request), warp2/control/bat_request.py (run one of
#              the WARP2 folder's .bat files on request),
#              warp2/control/window_keeper.py (the window kept open on a
#              nexus), warp2/control/commands.py (the command lane — a shell
#              by file for any model with no shell); stdlib faulthandler, os, subprocess, sys,
#              threading, time.
#  Description:
#    A small process that stays up beside the warp and does one thing: when
#    state/control/restart.request appears, it does a full restart and writes
#    the answer to state/control/restart.last.json. It beats into
#    state/control/watcher.beat so anyone can see it is alive. Only one runs:
#    a second one finds the first's fresh beat and leaves. When its own source
#    changes it starts its newer self and steps aside, so a fix to it does not
#    need someone at the machine.
#      Ask:    write state/control/restart.request (empty, or JSON with "why"
#              and "grace_seconds"); write state/control/status.request for
#              memory and processes in state/control/status.json; write
#              state/control/window.request to close the window.
#              Write a .bat's name into state/control/bat.request to have the
#              watcher run that .bat from the WARP2 folder (answer in
#              state/control/bat.last.json).
#    2026-11-02 (BUILD_LOG 1078): on a nexus it keeps the window open
#    (warp2/control/window_keeper.py), Andrew: "I always want the window
#    open on a nexus."
#    2026-11-02 (BUILD_LOG 1079): it runs the command lane — a command file
#    written into state/control/commands/inbox/ is run as its child, ended at
#    its deadline, and answered in commands/done/ (warp2/control/commands.py).
#      Run:    python -m warp2.control.watcher <WARP2 folder> [--once]
#    2026-10-17: it keeps beating while a slow look runs (the process list
#    for status, the window look, the supervisor's look). Asking for status
#    took ~40 s on a busy machine with no beat, and watcher_service ends a
#    watcher whose beat is 60 s old — so asking for status could kill it.
#    2026-10-18: when one turn of its loop takes longer than STALL_DUMP, every
#    thread's stack is written to state/diagnostics/watcher_stuck_stacks.txt
#    by faulthandler's own thread, so a watcher that hangs (seen: beat stale
#    54 min while its pid stayed up) says where.
#  User intention (Andrew, 2026-10-02): "a program that you can run from here
#    that will cause a full restart" while he is away from home.
# ============================================================================
"""Watch for restart requests and carry them out."""
from __future__ import annotations

import faulthandler
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from warp2.control.files import ControlFiles
from warp2.util import atomic_write_bytes

RESTART_WATCHER = 75

# Intention: how often it looks — often enough that a request is taken within
# seconds, rarely enough to cost nothing. A beat older than STALE means its
# watcher is gone.
LOOK_EVERY = 5.0
STALE = 60.0
DETACHED = 0x00000008 | 0x00000200
# Intention: how often it beats while a slow look runs — well inside the
# 60 s after which watcher_service takes a silent watcher for a dead one.
BEAT_WHILE_BUSY = 10.0
# Intention: a loop turn longer than this is a hang, not slow work — the
# longest honest turn is three 60 s process looks for status plus the
# supervisor's look. A restart is not timed (it is let wait as long as it needs).
STALL_DUMP = 300.0


class StallDump:
    """Intention: if one turn of the watcher loop runs past `after` seconds, write
    every thread's stack to a file. faulthandler writes it from its own thread,
    which runs even when every Python thread is stuck in a call."""

    def __init__(self, path: Path, after: float = STALL_DUMP):
        """Intention: open the dump file once (appending, with a line saying whose dumps follow); nothing is timed yet."""
        self._after = after
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._out = open(path, "a", encoding="utf-8")
        self._out.write(f"watcher {os.getpid()} started {time.strftime('%Y-%m-%d %H:%M:%S')}; "
                        f"a dump below means one loop turn took over {after:.0f} s\n")
        self._out.flush()

    def arm(self) -> None:
        """Intention: start (or restart) the clock for this turn; a dump comes only if the turn outlives it."""
        faulthandler.dump_traceback_later(self._after, repeat=False, file=self._out)

    def disarm(self) -> None:
        """Intention: stop the clock, for work that is allowed to take as long as it needs."""
        faulthandler.cancel_dump_traceback_later()


class KeepBeating:
    """Intention: beat on a side thread while one slow call runs, so a busy
    watcher is never mistaken for a dead one. Use as `with KeepBeating(files):`."""

    def __init__(self, files: ControlFiles, note: str = "watching", every: float | None = None):
        """Intention: hold the files to beat into, the note to beat with and how often; nothing starts yet."""
        self._files, self._note = files, note
        self._every = BEAT_WHILE_BUSY if every is None else every
        self._done = threading.Event()
        self._thread = threading.Thread(target=self._run, name="watcher-keep-beating", daemon=True)

    def __enter__(self) -> "KeepBeating":
        """Intention: start beating before the slow call begins."""
        self._thread.start()
        return self

    def __exit__(self, *exc) -> bool:
        """Intention: stop beating once the call ends, and let any error pass on as before."""
        self._done.set()
        self._thread.join(timeout=self._every + 1.0)
        return False

    def _run(self) -> None:
        """Intention: one beat every `every` seconds until told to stop; a failed beat is said, not fatal."""
        while not self._done.wait(self._every):
            try:
                self._files.beat_now(self._note)
            except Exception as exc:
                from warp2.record.swallowed import noted
                noted("control.watcher.keep_beating", exc)


def _own_source() -> tuple:
    """Intention: a fingerprint of the watcher's own files, to notice a fix to itself."""
    here = Path(__file__).resolve().parent
    return tuple(sorted((p.name, p.stat().st_mtime_ns) for p in here.glob("*.py")))


def another_is_watching(files: ControlFiles, alive=None) -> bool:
    """Intention: a fresh beat only owns the watcher while its process still exists."""
    try:
        pid, at = files.beat.read_text(encoding="utf-8").split()[:2]
        pid, age = int(pid), time.time() - float(at)
    except (OSError, ValueError):
        return False
    if pid == os.getpid() or not age < STALE:
        return False
    if alive is None:
        from warp2.control.windows import WindowsHands
        alive = WindowsHands().alive
    try:
        return bool(alive(pid))
    except (OSError, subprocess.TimeoutExpired):
        # An unanswered process query is not proof the owner died. Preserve
        # duplicate protection until the beat ages out, rather than guessing.
        return True


def _hand_over(root: Path) -> None:
    """Intention: start the newer watcher; this one cleared its beat first, so the new one does not mistake it for a live watcher."""
    flags = DETACHED if os.name == "nt" else 0
    subprocess.Popen([sys.executable, "-B", "-m", "warp2.control.watcher", str(root)],
                     cwd=str(root), creationflags=flags, close_fds=True)


def watch(root: Path, once: bool = False, managed: bool = False) -> int:
    """Intention: the watcher loop. Beat, answer window and status requests, carry out a restart request
    (or one the supervisor asks for), and hand over to a newer copy when its own source changes."""
    root = Path(root).resolve()
    files = ControlFiles(root / "state")
    files.ready()
    if another_is_watching(files):
        print("a restart watcher is already running.", flush=True)
        return 0
    source = _own_source()
    from warp2.control.supervisor import RunnerSupervisor
    supervisor = RunnerSupervisor()
    stall = StallDump(files.state / "diagnostics" / "watcher_stuck_stacks.txt")
    # Intention (BUILD_LOG 1079): one command lane for this watcher's life, so it knows the children it started.
    commands = None
    while True:
        stall.arm()
        files.beat_now()
        handoff = files.dir / "watcher.handoff"
        if handoff.exists():
            handoff.unlink(missing_ok=True)
            files.beat.unlink(missing_ok=True)
            return RESTART_WATCHER if managed else 0
        try:
            from warp2.control.window import answer_window
            with KeepBeating(files):
                answer_window(files)
        except Exception as exc:
            atomic_write_bytes(files.dir / "window.json",
                               f'{{"failed": "{type(exc).__name__}"}}'.encode())
        try:
            from warp2.control.status import answer_status
            with KeepBeating(files):
                answer_status(files)
        except Exception as exc:
            atomic_write_bytes(files.dir / "status.json",
                               f'{{"failed": "{type(exc).__name__}"}}'.encode())
        # Intention (Andrew, 2026-11-02: "have the warp run that bat"; BUILD_LOG 1075): a WARP2-folder .bat
        # named in bat.request is started on its own; the watcher does not wait for it.
        try:
            from warp2.control.bat_request import answer_bat
            answer_bat(files, root)
        except Exception as exc:
            atomic_write_bytes(files.dir / "bat.last.json",
                               f'{{"failed": "{type(exc).__name__}"}}'.encode())
        # Intention (Andrew, 2026-11-02: "a file that you can run that would act as shell access ... accessible for every
        # model"; BUILD_LOG 1079): waiting commands started, running ones finished or ended at their deadline.
        try:
            from warp2.control.commands import CommandLane
            commands = commands or CommandLane(root, files.state)
            with KeepBeating(files):
                commands.look()
        except Exception as exc:
            atomic_write_bytes(files.dir / "commands.failed.json",
                               f'{{"failed": "{type(exc).__name__}: {exc}"}}'.encode())
        # Intention (Andrew, 2026-11-02: "I always want the window open on a nexus"; BUILD_LOG 1078): on a nexus with no
        # window, one is started; reading the process list can take seconds, so it beats through it.
        try:
            from warp2.control.window_keeper import WindowKeeper
            with KeepBeating(files):
                WindowKeeper(root, files).look()
        except Exception as exc:
            atomic_write_bytes(files.dir / "window_keeper.failed.json",
                               f'{{"failed": "{type(exc).__name__}"}}'.encode())
        asked = files.take()
        if asked is None and not once:
            try:
                from warp2.control.windows import WindowsHands
                with KeepBeating(files):
                    asked = supervisor.observe(files, WindowsHands())
            except Exception as exc:
                files.answer({"outcome": "supervisor_failed", "why": f"{type(exc).__name__}: {exc}",
                              "when": time.strftime("%Y-%m-%d %H:%M:%S")})
        if asked is not None:
            # A restart request handled by the background watcher is not an
            # instruction to reopen the interactive desktop. The GUI is
            # launched only by the user's explicit WARP2.bat action.
            if not asked.get("automatic"):
                asked.setdefault("background", True)
            files.beat_now("restarting")
            stall.disarm()
            try:
                from warp2.control.restart import Restart
                from warp2.control.windows import WindowsHands
                # Intention: it keeps beating while it waits, so a long
                # restart is never mistaken for a dead watcher.
                def beating_sleep(seconds: float) -> None:
                    files.beat_now("restarting")
                    time.sleep(seconds)
                # Intention (2026-10-25, BUILD_LOG 598): a restart's slow calls
                # (the process list, tasklist) run with no sleep between them;
                # one took past watcher_service's 60 s and it ended this watcher
                # in the middle of a restart, leaving the restart undone. Beat
                # on a side thread through the whole restart.
                with KeepBeating(files, "restarting"):
                    Restart(root, files.state, WindowsHands(), sleep=beating_sleep).run(asked)
            except Exception as exc:
                files.answer({"outcome": "failed", "why": f"{type(exc).__name__}: {exc}",
                              "when": time.strftime("%Y-%m-%d %H:%M:%S")})
        if once:
            stall.disarm()
            return 0
        if _own_source() != source:
            files.beat.unlink(missing_ok=True)
            if managed:
                return RESTART_WATCHER
            _hand_over(root)
            return 0
        time.sleep(LOOK_EVERY)


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    sys.exit(watch(Path(args[0]) if args else Path.cwd(), once="--once" in sys.argv,
                   managed="--managed" in sys.argv))
