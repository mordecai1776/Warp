# WARP2/warp2/control/restart.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/restart.py
#  Used by   : warp2/control/watcher.py (one restart per request).
#  Uses      : warp2/control/files.py (paths, beats); warp2/control/windows.py
#              (the hands — or a stand-in in tests); warp2/record/stop.py
#              (is ALL_STOP raised); stdlib time.
#  Description:
#    An explicit restart, in the order that loses nothing; automatic recovery
#    is narrower and never closes, opens, or foregrounds a user window:
#      1. ALL_STOP raised -> nothing is done (a stop is never lifted by this).
#      2. An explicitly requested restart ends its old launcher loop; an
#         automatic recovery leaves the user's launcher and windows alone.
#      3. The runner is asked to stop at its next pass boundary (reload.flag),
#         and given time; only past that time is it ended by force.
#      4. For an explicit request, the web lane and window are closed politely
#         first, then forced. Automatic recovery leaves both alone.
#      5. A leftover reload.flag is removed (it would reload the new runner).
#      6. An automatic recovery starts only a hidden runner; an explicit
#         restart uses the normal launcher without a visible console.
#      7. The new runner's beat is waited for and reported; then the new web
#         lane's beat is looked for a short while so the answer names it too
#         (2026-10-23). A start whose start-up tests failed is seen to have
#         ended and answered "start_ended_no_beat" at once, not after the
#         whole wait (BUILD_LOG 875). That answer carries the first failed
#         start-up test's name and how many more failed, read from
#         tests.out.txt, so the receipt says why on its face (BUILD_LOG 879).
#    Every step is written into the answer with how long it took.
#  User intention (Andrew, 2026-10-02): "a program that you can run from here
#    that will cause a full restart ... I will be working away from home and
#    need you to be able to do that on your own"
# ============================================================================
"""One full, polite-first restart of the warp."""
from __future__ import annotations

import re
import time
from pathlib import Path

from warp2.util import atomic_write_bytes

from warp2.control.files import ControlFiles, beat_pid
from warp2.control.windows import LANE_COMMANDS, LANE_ROLES, RUNNER_ROLES, WINDOW_COMMANDS

# Intention: the defaults a request may change. The runner gets a short
# grace to end its pass cleanly, then is forced — a restart should be quick
# (Andrew, 2026-10-02: "it is not a long action"), and the warp already
# survives a forced end (ALL_STOP does the same). A request can ask for more
# with "grace_seconds". A window only needs a moment to close; the new warp
# gets a while to show its beats.
GRACE_RUNNER = 60.0
GRACE_WINDOW = 20.0
# Intention (BUILD_LOG 811): the start-up tests run before the new runner's first beat and now take 4.4-4.6 minutes;
# with 300 s a good restart was reported "launched_no_beat_yet" (2026-10-28 00:05). The wait covers the tests with room.
WAIT_STARTED = 600.0
LOOK_EVERY = 2.0
# Intention (BUILD_LOG 875; 2026-10-28 22:48-22:58 UTC): a start whose start-up tests failed starts no runner, yet the
# wait above ran its whole 600 s and then said only "launched_no_beat_yet". Every ENDED_LOOK_EVERY seconds the hands
# are asked whether any start is still in its gate or running (Windows: a "-m warp2.control.preflight" process); none
# there ENDED_SEEN times running, with no new beat, means the start ended — the wait stops and the answer says so.
ENDED_LOOK_EVERY = 20.0
ENDED_SEEN = 2
# Intention (2026-10-23, Muse-435): the answer should name the new web lane
# too, not only the runner. The runner starts the lane after its start-up
# tests, so once the runner beats the lane is looked for a little longer.
# The restart is already done by then; this only fills in the receipt.
WAIT_LANE = 120.0


class Restart:
    """Intention: the steps, each recorded; hands, clock and sleep are passed in so tests can stand in for Windows."""

    def __init__(self, root: Path, state: Path, hands, clock=time.monotonic, sleep=time.sleep) -> None:
        """Intention: hold the tools a restart needs (control files, process hands, clock, sleep) and start the step log."""
        self.root = Path(root)
        self.files = ControlFiles(state)
        self.hands = hands
        self.clock = clock
        self.sleep = sleep
        self.began = clock()
        self.steps = []

    def _note(self, step: str, **said) -> None:
        """Intention: add one step, with seconds since the restart began, to the log written in the answer."""
        self.steps.append({"step": step, "at_s": round(self.clock() - self.began, 1), **said})

    def _stopped(self) -> bool:
        """Intention: the bat's own test (stop.flag) and the authority's, either one is enough to stand down."""
        if self.files.stop_flag.exists():
            return True
        try:
            from warp2.record.stop import Halt
            return bool(Halt(self.files.state).raised())
        except Exception:
            return False

    def _wait_gone(self, pids: list, seconds: float) -> list:
        """Intention: look until every pid is gone or the time is up; returns the ones still there."""
        ends = self.clock() + seconds
        left = [p for p in pids if self.hands.alive(p)]
        while left and self.clock() < ends:
            self.sleep(LOOK_EVERY)
            left = [p for p in left if self.hands.alive(p)]
        return left

    def _end_politely(self, pids: list, grace: float, name: str) -> None:
        """Intention: ask these processes to close, wait the grace time, then force-end what is left and log it."""
        for pid in pids:
            self.hands.end(pid, force=False, tree=False)
        left = self._wait_gone(pids, grace)
        for pid in left:
            self.hands.end(pid, force=True, tree=True)
        self._note(f"{name}_closed", pids=pids, forced=left, still=self._wait_gone(left, 10.0))

    def run(self, asked: dict) -> dict:
        """Do the restart; returns the answer."""
        why = str(asked.get("why", "") or "asked")
        automatic = bool(asked.get("automatic"))
        background = automatic or bool(asked.get("background"))
        if self._stopped():
            self._note("refused", why="ALL_STOP is raised; only a person lifts it")
            return self._answer("refused", why)
        found = self.hands.registered()
        runners = [r["pid"] for r in found if r["role"] in RUNNER_ROLES]
        # Intention (BUILD_LOG 940): every web lane of this workspace, registered or not — a lane whose run ended
        # and whose process stayed is off the register and was never found; it sat beside each new lane.
        registered_lanes = [r["pid"] for r in found if r["role"] in LANE_ROLES]
        stray_lanes = sorted({int(p) for p in self._lanes_by_command()} - set(registered_lanes))
        lanes = sorted(set(registered_lanes) | set(stray_lanes))
        windows = [] if background else self.hands.by_command(WINDOW_COMMANDS)
        self._note("found", runners=runners, lanes=lanes, windows=windows, stray_lanes=stray_lanes)
        if not background:
            self._end_loops(runners)
        self._end_runners(runners, float(asked.get("grace_seconds", GRACE_RUNNER)))
        # Intention (BUILD_LOG 940): a stray lane — in the process list but off the register, so its run has ended
        # and only its process is left — is ended in every restart; a registered, working lane is left alone in an
        # automatic recovery (the new runner takes it up) and ended only when a person asked for the restart.
        self._end_politely([p for p in stray_lanes if self.hands.alive(p)], GRACE_WINDOW, "stray_lane")
        if background:
            self._note("desktop_left_untouched")
        else:
            self._end_politely([p for p in registered_lanes if self.hands.alive(p)], GRACE_WINDOW, "lane")
            self._end_politely(windows, GRACE_WINDOW, "window")
        if self.files.reload_flag.exists():
            self.files.reload_flag.unlink()
            self._note("leftover_reload_flag_removed")
        if self._stopped():
            self._note("not_started", why="ALL_STOP was raised during the restart")
            return self._answer("stopped_only", why)
        return self._start(why, headless=background)

    def _lanes_by_command(self) -> list:
        """Intention (BUILD_LOG 940): web lanes seen in the process list by their command; none where the hands
        cannot look (a stand-in without `by_command`, or a machine that will not answer)."""
        look = getattr(self.hands, "by_command", None)
        try:
            return list(look(LANE_COMMANDS)) if callable(look) else []
        except Exception:  # noqa: BLE001 — a process list that cannot be read finds no extra lanes
            return []

    def _end_loops(self, runners: list) -> None:
        """Intention: the bat's loop first — after this nothing will start the old runner again."""
        loops = [loop for loop in (self.hands.launcher_of(p) for p in runners) if loop]
        for loop in loops:
            self.hands.end(loop, force=True, tree=False)
        self._note("loops_ended", loops=loops)

    def _end_runners(self, runners: list, grace: float) -> None:
        """Intention: asked through the runner's own reload door, then forced only past the grace."""
        if not runners:
            self._note("no_runner")
            return
        self.files.reload_flag.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_bytes(self.files.reload_flag, b"full restart by control watcher\n")
        left = self._wait_gone(runners, grace)
        for pid in left:
            self.hands.end(pid, force=True, tree=True)
        self._note("runner_stopped", pids=runners, forced=left, still=self._wait_gone(left, 10.0))

    def _start(self, why: str, *, headless: bool = False) -> dict:
        """Intention: launch the warp again and wait until a new runner beat shows it really started, then answer."""
        old_run, old_web = beat_pid(self.files.runner_beat), beat_pid(self.files.lane_beat)
        if not self.files.expected.exists():
            atomic_write_bytes(self.files.expected,
                               f"expected since {time.strftime('%Y-%m-%d %H:%M:%S')}\n".encode("utf-8"))
        launched_at = time.time()
        console = self.hands.launch(self.root, headless=headless)
        self._note("launched", process=console, headless=headless)
        ends = self.clock() + WAIT_STARTED
        new_run = new_web = None
        ended = StartEnded(self.hands, self.clock)
        while self.clock() < ends:
            run, web = beat_pid(self.files.runner_beat), beat_pid(self.files.lane_beat)
            new_run = run if run and run != old_run else None
            new_web = web if web and web != old_web else None
            # Intention: the new runner beating is the restart done; the web
            # lane is started later by the runner, so it is reported if seen,
            # not waited for.
            if new_run:
                break
            if ended.seen():
                tests = self.files.state / "diagnostics" / "tests.out.txt"
                self._note("start_ended", process=console, tests=str(tests),
                           **FailedTests(tests, since=launched_at).said())
                return self._answer("start_ended_no_beat", why)
            self.sleep(LOOK_EVERY)
        if new_run and not new_web:
            new_web = self._wait_lane(old_web)
        self._note("beats", runner=new_run, lane=new_web)
        return self._answer("restarted" if new_run else "launched_no_beat_yet", why)

    def _wait_lane(self, old_web) -> int | None:
        """The new web lane's pid, looked for up to WAIT_LANE after the runner beat; None if not seen.

        Intention: a restart receipt that names every new process it can
        (runner and web lane), so a later reader can tell which process did
        what. Not seeing the lane is reported as None, never waited on forever.
        """
        ends = self.clock() + WAIT_LANE
        while self.clock() < ends:
            web = beat_pid(self.files.lane_beat)
            if web and web != old_web:
                return web
            self.sleep(LOOK_EVERY)
        return None

    def _answer(self, outcome: str, why: str) -> dict:
        """Intention: build the restart result with its steps, write it to the answer file, and return it."""
        result = {"outcome": outcome, "why": why, "when": time.strftime("%Y-%m-%d %H:%M:%S"),
                  "seconds": round(self.clock() - self.began, 1), "steps": self.steps}
        self.files.answer(result)
        return result


class StartEnded:
    """Intention (BUILD_LOG 875): has the launched start ended without a runner (its start-up tests failed)?

    Asks the hands' starting() — the starts in their gate or running — at most every ENDED_LOOK_EVERY seconds;
    ENDED_SEEN empty answers running is an ended start. Hands without starting() (tests' stand-ins), or a look that
    fails, never count as ended: the wait then runs as before.
    """

    def __init__(self, hands, clock) -> None:
        """Intention: the hands to ask, the clock, when it was last asked, and how many empty answers running."""
        self.look = getattr(hands, "starting", None)
        self.clock = clock
        self.asked_at = clock()
        self.empty = 0

    def seen(self) -> bool:
        """Intention: True once the start has been absent ENDED_SEEN looks running."""
        if not callable(self.look) or self.clock() - self.asked_at < ENDED_LOOK_EVERY:
            return False
        self.asked_at = self.clock()
        try:
            gone = not self.look()
        except Exception:  # noqa: BLE001 — a look that fails is not an answer; keep waiting
            return False
        self.empty = self.empty + 1 if gone else 0
        return self.empty >= ENDED_SEEN


class FailedTests:
    """Intention (BUILD_LOG 879; Muse-772, decided by protocol): the start-up tests that failed, for the receipt's face.

    The receipt stays; tests.out.txt is written over by the next start. So an ended start's answer carries the first
    failed test's name and how many more failed (short, and nothing hidden: the count says the rest exist, the file
    path says where). A file older than the launch is not this start's and is not read; no file, no names.
    """

    LINE = re.compile(r"^(?:(?P<a>\S+::\S+) (?:FAILED|ERROR)\b|(?:FAILED|ERROR) (?P<b>\S+::\S+))")
    COLOUR = re.compile(r"\x1b\[[0-9;]*m")

    def __init__(self, path: Path, since: float) -> None:
        """Intention: the tests file to read and the launch time it must be newer than (2 s slack for clocks)."""
        self.path = Path(path)
        self.since = since - 2.0

    def names(self) -> list:
        """Intention: every failed test's name once, in the order the file first shows it."""
        try:
            if self.path.stat().st_mtime < self.since:
                return []
            text = self.path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []
        seen = []
        for line in text.splitlines():
            hit = self.LINE.match(self.COLOUR.sub("", line).strip())
            name = hit and (hit.group("a") or hit.group("b"))
            if name and name not in seen:
                seen.append(name)
        return seen

    def said(self) -> dict:
        """Intention: {"first_failed": name, "more_failed": n} — or {"first_failed": None} when none was read."""
        names = self.names()
        return {"first_failed": names[0] if names else None, "more_failed": max(len(names) - 1, 0)}
