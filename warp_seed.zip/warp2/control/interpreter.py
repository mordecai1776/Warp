# WARP2/warp2/control/interpreter.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/interpreter.py
#  Used by   : warp2/run.py (_go_owned — a continuous run checks before it
#              builds anything), WARP2.bat (`python -m warp2.control.interpreter`
#              right after Python is found), warp2/control/tests/test_interpreter.py.
#  Uses      : stdlib os, sys; torch when it is installed.
#  Description:
#    Is this the Python the warp is meant to run on? Two things are checked:
#    that it is not running inside some other tool's virtual environment
#    (sys.prefix differs from sys.base_prefix), and that the graphics card is
#    usable (torch.cuda.is_available()). Either one wrong is a plain reason to
#    stop. WARP2_ALLOW_VENV=1 or WARP2_ALLOW_CPU=1 lets a person say they know.
#  User intention (Andrew, 2026-10-08): "go ahead" on locking which Python runs
#    the warp, after the run of 2026-10-06 was found running on the Hermes
#    agent's own Python (hermes-agent\venv) instead of Python311 with the card.
# ============================================================================
from __future__ import annotations

import os
import sys


def in_other_venv() -> str:
    """Intention: the venv's folder when this Python runs inside one, else ""."""
    return sys.prefix if sys.prefix != getattr(sys, "base_prefix", sys.prefix) else ""


def card_usable() -> bool:
    """Intention: whether torch is here and can use the graphics card."""
    try:
        import torch
    except Exception:
        return False
    try:
        return bool(torch.cuda.is_available())
    except Exception:
        return False


def problem(venv: str | None = None, card: bool | None = None) -> str:
    """The reason this Python should not run the warp, or "" when it is fine."""
    venv = in_other_venv() if venv is None else venv
    if venv and os.environ.get("WARP2_ALLOW_VENV") != "1":
        return (f"this Python runs inside another tool's environment ({venv}), not your own Python; "
                f"start the warp with WARP2.bat (or set WARP2_ALLOW_VENV=1 if you meant it)")
    card = card_usable() if card is None else card
    if not card and os.environ.get("WARP2_ALLOW_CPU") != "1":
        return (f"this Python ({sys.executable}) cannot use the graphics card (torch with CUDA); "
                f"start the warp with WARP2.bat (or set WARP2_ALLOW_CPU=1 to run on the processor)")
    return ""


def main() -> int:
    """Intention: for WARP2.bat — say the problem and return 2, or return 0."""
    said = problem()
    if said:
        print(f"[WARP2] Wrong Python: {said}")
        return 2
    print(f"[WARP2] Python checked: {sys.executable}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
