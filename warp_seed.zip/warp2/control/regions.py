# WARP2/warp2/control/regions.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/regions.py
#  Used by   : warp2/control/status.py (when status.request asks for
#              "regions").
#  Uses      : stdlib ctypes (Windows VirtualQueryEx, QueryWorkingSetEx),
#              json, time.
#  Description:
#    A map of one process's memory, read from outside it: every committed
#    region, grouped by the allocation it belongs to, with how much of it is
#    actually in RAM right now (resident) and how much is promised but not in
#    RAM (paged out or never touched). Sums by kind (private, mapped, image)
#    and by allocation size, and the biggest allocations. Exactly-1-MiB
#    private allocations are counted apart: that is the size Python 3.10+
#    asks Windows for when it makes room for small objects (its "arenas"), so
#    their total is an upper bound on Python's small-object heap. Read only;
#    the measured process is never changed or paused.
#  User intention (Andrew, 2026-10-16: get everything in working order; the
#    picture child reaches ~14 GB private and starves the machine): the
#    size lines account for ~3.5 GB of it (lists, tensors, tag objects,
#    BUILD_LOG 482/485). This says where the rest sits — Python's small
#    objects, big buffers, or promised pages nothing touches — without
#    touching the Eye's code (Muse-430's suggestion).
# ============================================================================
"""One process's memory map, summed, read from outside."""
from __future__ import annotations

import time

MEM_COMMIT = 0x1000
KINDS = {0x20000: "private", 0x40000: "mapped", 0x1000000: "image"}
PAGE = 4096
ARENA = 1 << 20
MIB = float(1 << 20)


class Region:
    """Intention: one committed region as the OS described it, plus how many of its pages are in RAM."""
    __slots__ = ("base", "allocation", "size", "kind", "protect", "resident")

    def __init__(self, base: int, allocation: int, size: int, kind: str, protect: int, resident: int):

        """Intention: one region of a process's memory as Windows reports it, kept as plain numbers."""
        self.base, self.allocation, self.size = base, allocation, size
        self.kind, self.protect, self.resident = kind, protect, resident


def size_class(size: int) -> str:
    """Intention: the name of the size band an allocation falls in; 1 MiB exactly is Python's arena size."""
    if size == ARENA:
        return "exactly 1 MiB (Python small-object arenas)"
    if size < ARENA:
        return "under 1 MiB"
    if size < 64 * ARENA:
        return "1-64 MiB"
    if size < 1024 * ARENA:
        return "64 MiB-1 GiB"
    return "1 GiB and more"


def summary(regions, top: int = 15) -> dict:
    """Intention: committed and resident MB by kind, by allocation size band (private only), and the biggest
    allocations; pure, so it is tested without Windows."""
    def mb(n):

        """Intention: bytes as megabytes, for a person to read."""
        return round(n / MIB, 1)
    allocations: dict = {}
    kinds: dict = {}
    for r in regions:
        k = kinds.setdefault(r.kind, [0, 0])
        k[0] += r.size
        k[1] += r.resident
        a = allocations.setdefault((r.kind, r.allocation), [0, 0, r.protect])
        a[0] += r.size
        a[1] += r.resident
    bands: dict = {}
    for (kind, _), (size, resident, _) in allocations.items():
        if kind != "private":
            continue
        b = bands.setdefault(size_class(size), [0, 0, 0])
        b[0] += 1
        b[1] += size
        b[2] += resident
    biggest = sorted(allocations.items(), key=lambda item: -item[1][0])[:top]
    total = sum(v[0] for v in kinds.values())
    held = sum(v[1] for v in kinds.values())
    return {"committed_mb": mb(total), "resident_mb": mb(held), "not_resident_mb": mb(total - held),
            "by_kind": {k: {"committed_mb": mb(v[0]), "resident_mb": mb(v[1])} for k, v in sorted(kinds.items())},
            "private_by_allocation_size": {k: {"allocations": v[0], "committed_mb": mb(v[1]), "resident_mb": mb(v[2])}
                                           for k, v in sorted(bands.items(), key=lambda kv: -kv[1][1])},
            "biggest_allocations": [{"kind": kind, "at": hex(base), "committed_mb": mb(v[0]),
                                     "resident_mb": mb(v[1]), "protect": hex(v[2])}
                                    for (kind, base), v in biggest]}


class WindowsMap:
    """Intention: the Windows calls that read another process's regions and which of their pages are in RAM."""

    def __init__(self, pid: int):

        """Intention: the process whose memory map is walked."""
        import ctypes
        from ctypes import wintypes
        self.ct = ctypes
        self.k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.k32.OpenProcess.restype = wintypes.HANDLE
        self.k32.VirtualQueryEx.restype = ctypes.c_size_t
        self.k32.VirtualQueryEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
        self.k32.K32QueryWorkingSetEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
        self.handle = self.k32.OpenProcess(0x0400 | 0x0010, False, int(pid))
        if not self.handle:
            raise OSError(f"cannot open process {pid}: error {ctypes.get_last_error()}")

        class Info(ctypes.Structure):

            """Intention: the layout Windows fills for one memory region (MEMORY_BASIC_INFORMATION)."""
            _fields_ = [("BaseAddress", ctypes.c_void_p), ("AllocationBase", ctypes.c_void_p),
                        ("AllocationProtect", wintypes.DWORD), ("PartitionId", wintypes.WORD),
                        ("RegionSize", ctypes.c_size_t), ("State", wintypes.DWORD),
                        ("Protect", wintypes.DWORD), ("Type", wintypes.DWORD)]

        class Page(ctypes.Structure):

            """Intention: the layout Windows fills for one page's working-set information."""
            _fields_ = [("VirtualAddress", ctypes.c_void_p), ("VirtualAttributes", ctypes.c_size_t)]
        self.Info, self.Page = Info, Page

    def resident(self, base: int, size: int, chunk: int = 65536) -> int:
        """Intention: bytes of [base, base+size) in this process's RAM now (the Valid bit), asked in chunks."""
        pages = size // PAGE
        held = 0
        for start in range(0, pages, chunk):
            n = min(chunk, pages - start)
            batch = (self.Page * n)()
            for i in range(n):
                batch[i].VirtualAddress = base + (start + i) * PAGE
            if not self.k32.K32QueryWorkingSetEx(self.handle, batch, self.ct.sizeof(batch)):
                raise OSError(f"QueryWorkingSetEx failed: error {self.ct.get_last_error()}")
            held += sum(1 for p in batch if p.VirtualAttributes & 1)
        return held * PAGE

    def regions(self):
        """Intention: every committed region of the process, in address order, with its resident bytes."""
        info = self.Info()
        at = 0
        while self.k32.VirtualQueryEx(self.handle, self.ct.c_void_p(at), self.ct.byref(info), self.ct.sizeof(info)):
            base, size = info.BaseAddress or 0, info.RegionSize
            if info.State == MEM_COMMIT:
                yield Region(base, info.AllocationBase or 0, size, KINDS.get(info.Type, hex(info.Type)),
                             info.Protect, self.resident(base, size))
            at = base + size

    def close(self) -> None:
        """Intention: the process handle given back."""
        self.k32.CloseHandle(self.handle)


def walk(pid: int, opener=WindowsMap) -> dict:
    """Intention: the summed map of one process, with when, which process and what it cost to read;
    a failure is said in the answer, never raised."""
    started = time.perf_counter()
    answer = {"when": time.strftime("%Y-%m-%d %H:%M:%S"), "pid": pid}
    try:
        reader = opener(pid)
        try:
            answer.update(summary(list(reader.regions())))
        finally:
            reader.close()
    except Exception as exc:
        answer["failed"] = f"{type(exc).__name__}: {exc}"
    answer["seconds"] = round(time.perf_counter() - started, 2)
    return answer
