# WARP2/warp2/control/commands.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/commands.py
#  Used by   : warp2/control/watcher.py (each look — CommandLane.look),
#              any model or builder that cannot reach a shell (Commands.send /
#              result, or by writing the inbox file itself),
#              warp2/control/tests/test_a_command_file_runs_like_a_shell.py.
#  Uses      : warp2/record/working.py (a command that asked to run while it
#              works is ended when it is still, not when it is slow),
#              warp2/control/windows.py (QUIET, NEW_GROUP, NOT_HANDED_DOWN;
#              WindowsHands.alive and end — a command's whole tree ended at its
#              deadline), warp2/util.py (atomic_write_bytes); (stdlib) json,
#              os, subprocess, sys, time, uuid, pathlib.
#  Description:
#    A shell by file, for any model or builder that has no shell. Write one
#    JSON file into state/control/commands/inbox/:
#        {"by": "Claude", "shell": "cmd" | "powershell" | "python",
#         "run": "the command, or the Python program", "seconds": 120,
#         "cwd": "a folder inside WARP2 (optional)"}
#    Within seconds the watcher starts it as a child of its own, in the WARP2
#    folder (or the folder named inside it), with the same search path the
#    window and the runner use, and no keyboard. Its words go to
#    commands/out/<id>.txt. When it ends, or reaches its seconds (the whole
#    tree is ended then — the watcher enforces it, as a parent does), the
#    answer is written to commands/done/<id>.json: the exit code, how long it
#    took, and the last of what it said. Every start and end is a line in
#    commands/journal.jsonl. A command still running when the watcher reloads
#    is picked up again by the next watcher from its record.
#    Kept light on purpose (Andrew, 2026-11-02: there are enough safeguards
#    already): a command must say who sent it, and the sender must be one the
#    warp knows — a model in the roster, a builder in the builders' scores, or
#    a name in commands/callers.json; it must have a deadline (the watcher's
#    STALE when it gives none); and it runs inside the WARP2 folder.
#    Commands.send / result do the same from Python for a model in the warp.
#    A used id is refused without replacing its script, output or answer;
#    the refusal has a fresh id and records requested_id in the journal.
#    WHILE IT WORKS (BUILD_LOG 1489). A command sent with "while_working":
#    true is not ended at its seconds while it is working: past them, each
#    look reads whether it wrote words or its tree did work
#    (warp2/record/working.py), and it is ended only once it has been still
#    for its seconds, or has used its set amount of compute - its seconds on
#    every processor (BUILD_LOG 1490). Without the mark a command is ended at
#    its seconds, as before - a sender that sets a bound keeps it.
#  User intention (Andrew, 2026-11-02 01:29): "a controlling file for when you
#    don't have shell access ... a file that you can run that would act as
#    shell access ... accessible for every model. Because there'll be certain
#    models that won't have shell access that will need certain capability
#    that provides."
#    2026-11-09 22:41: "make the time constraints more adaptive and have it do
#    checks for freezes. We should allow for long times for things ... the
#    warp seed is worth it." (BUILD_LOG 1489.)
# ============================================================================
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

SHELLS = ("cmd", "powershell", "python")
# Intention: how much of a command's words the answer carries; the whole is in its out file.
TAIL_CHARS = 4000


class CommandHome:
    """Every path of the command lane in one place, under state/control/commands."""

    def __init__(self, state: Path) -> None:
        """Intention: the folders made on first use."""
        self.dir = Path(state) / "control" / "commands"
        self.inbox, self.running, self.done = self.dir / "inbox", self.dir / "running", self.dir / "done"
        self.out, self.scripts = self.dir / "out", self.dir / "scripts"
        self.journal = self.dir / "journal.jsonl"
        self.callers = self.dir / "callers.json"
        for folder in (self.inbox, self.running, self.done, self.out, self.scripts):
            folder.mkdir(parents=True, exist_ok=True)

    def note(self, row: dict) -> None:
        """Intention: one line in the journal, with the time."""
        row = {"at": time.strftime("%Y-%m-%d %H:%M:%S"), **row}
        with self.journal.open("a", encoding="utf-8") as out:
            out.write(json.dumps(row, ensure_ascii=False) + "\n")

    def write(self, path: Path, row: dict) -> None:
        """Intention: a record written whole."""
        from warp2.util import atomic_write_bytes
        atomic_write_bytes(path, json.dumps(row, indent=1, ensure_ascii=False).encode("utf-8"))

    def used(self, cid: str) -> bool:
        """Intention (cp1 incident, 2026-11-05): a script or command record reserves its id across watcher reloads."""
        return any((folder / f"{cid}{suffix}").exists() for folder, suffix in (
            (self.scripts, ".py"), (self.out, ".txt"), (self.running, ".json"), (self.done, ".json")))


class Callers:
    """Who may send a command: the roster's models, the builders the record knows, and any name Andrew adds.

    Intention: no list is set here — the names come from models.json, the
    builders' scores (state/builders/scores.json) and commands/callers.json.
    """

    def __init__(self, root: Path, home: CommandHome) -> None:
        """Intention: the tree (its roster), and the lane (its callers file)."""
        self.root = Path(root)
        self.home = home

    def known(self) -> set:
        """Intention: every name that may send, lower case."""
        names = set()
        for path, read in ((self.root / "models.json", self._roster),
                           (self.root / "state" / "builders" / "scores.json", self._builders),
                           (self.home.callers, self._listed)):
            try:
                names |= {str(n).strip().lower() for n in read(json.loads(path.read_text(encoding="utf-8-sig")))}
            except (OSError, ValueError, TypeError, AttributeError):
                continue
        return {n for n in names if n}

    @staticmethod
    def _roster(data) -> list:
        """Intention: the model names in models.json, whichever shape it has."""
        rows = data.get("models", data) if isinstance(data, dict) else data
        rows = rows.values() if isinstance(rows, dict) else rows
        return [r.get("name") for r in rows if isinstance(r, dict) and r.get("name")]

    @staticmethod
    def _builders(data) -> list:
        """Intention: each builder the scores know, and the first word of each (\"Claude, hourly run\" is Claude)."""
        names = list((data.get("builders") or {}).keys())
        return names + [n.split(",")[0] for n in names]

    @staticmethod
    def _listed(data) -> list:
        """Intention: the names Andrew lists in commands/callers.json (a list, or {"names": [...]})."""
        return data.get("names", []) if isinstance(data, dict) else list(data)


class CommandAsk:
    """One command as asked, checked."""

    def __init__(self, root: Path, row: dict, stale: float) -> None:
        """Intention: the tree, the asked row, and the deadline used when the row gives none."""
        self.root = Path(root).resolve()
        self.row = row if isinstance(row, dict) else {}
        self.by = str(self.row.get("by") or "").strip()
        self.shell = str(self.row.get("shell") or "cmd").strip().lower()
        self.run = str(self.row.get("run") or "")
        try:
            self.seconds = float(self.row.get("seconds") or stale)
        except (TypeError, ValueError):
            self.seconds = float(stale)
        self.cwd = (self.root / str(self.row.get("cwd") or ".")).resolve()
        self.while_working = self.row.get("while_working") is True

    def refused(self, callers: set) -> str:
        """Intention: why it will not run, or "" when it will."""
        if not self.by:
            return "a command must say who sent it (\"by\")"
        if self.by.lower() not in callers:
            return f"{self.by!r} is not a model, a builder, or a name in commands/callers.json"
        if self.shell not in SHELLS:
            return f"shell must be one of {', '.join(SHELLS)}"
        if not self.run.strip():
            return "nothing to run"
        if self.seconds <= 0:
            return "seconds must be more than nothing"
        if self.cwd != self.root and self.root not in self.cwd.parents:
            return "cwd must be inside the WARP2 folder"
        if not self.cwd.is_dir():
            return "cwd is not a folder"
        return ""


class CommandStart:
    """Starts a checked command as a child with no keyboard, its words to its out file.

    Intention: `popen` is subprocess.Popen unless a test gives a stand-in.
    """

    def __init__(self, root: Path, home: CommandHome, popen=None) -> None:
        """Intention: the tree, the lane, and how a process is started."""
        self.root = Path(root)
        self.home = home
        self.popen = popen or subprocess.Popen
        # Intention: the last child started, so the lane can read its exit code.
        self.last = None

    def argv(self, cid: str, ask: CommandAsk) -> list:
        """Intention: the command line for its shell; a Python program is written to a file and run from it."""
        if ask.shell == "powershell":
            return ["powershell", "-NoProfile", "-NonInteractive", "-Command", ask.run]
        if ask.shell == "python":
            script = self.home.scripts / f"{cid}.py"
            # Intention: a script appearing after the lane's id check must not be overwritten either.
            with script.open("x", encoding="utf-8") as program:
                program.write(ask.run)
            python = Path(sys.executable).with_name("python.exe")
            return [str(python if python.exists() else Path(sys.executable)), "-B", str(script)]
        return ["cmd", "/c", ask.run]

    def env(self) -> dict:
        """Intention: the search path the window and the runner use, so a Python command can import the warp."""
        from warp2.control.windows import NOT_HANDED_DOWN
        env = {k: v for k, v in os.environ.items() if k.upper() not in NOT_HANDED_DOWN}
        env["PYTHONPATH"] = os.pathsep.join(str(p) for p in (self.root, self.root / "projects" / "centering_image",
                                                             self.root / "projects" / "behemoth_eye"))
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONUTF8"] = "1"
        return env

    def start(self, cid: str, ask: CommandAsk, now: float) -> dict:
        """Intention: the child started; its record (pid, when, deadline, where its words go), on the lane's clock."""
        from warp2.control.windows import NEW_GROUP, QUIET
        out = self.home.out / f"{cid}.txt"
        argv = self.argv(cid, ask)
        with open(out, "wb") as words, open(os.devnull, "rb") as nothing:
            child = self.popen(argv, cwd=str(ask.cwd), env=self.env(), stdin=nothing, stdout=words,
                               stderr=subprocess.STDOUT, creationflags=(QUIET | NEW_GROUP) if os.name == "nt" else 0,
                               close_fds=True)
        self.last = child
        return {"id": cid, "by": ask.by, "shell": ask.shell, "run": ask.run, "cwd": str(ask.cwd),
                "pid": int(getattr(child, "pid", 0) or 0), "started": now, "deadline": now + ask.seconds,
                "seconds": ask.seconds, "while_working": ask.while_working, "out": str(out)}


class StillFor:
    """How long each command that runs while it works has been still: no words written, no work done."""

    def __init__(self, working=None) -> None:
        """Intention: what reads a tree's work (a test hands in its own), and each command's reader and last sign."""
        self.working = working
        self.readers: dict = {}
        self.sign: dict = {}

    def seconds(self, record: dict, now: float) -> float:
        """Intention: one look at one command; the seconds since it last wrote words or did work. The first look
        starts the count, so a command is never ended by a look that had nothing to compare with."""
        cid = record["id"]
        if cid not in self.readers:
            make = self.working
            if make is None:
                from warp2.record.working import Working as make
            self.readers[cid] = make(int(record.get("pid") or 0))
            self.sign[cid] = now
            return 0.0
        if self.readers[cid].moved():
            self.sign[cid] = now
        try:
            wrote = os.path.getmtime(str(record.get("out") or ""))
        except OSError:  # fault: ok - no out file yet means no words were written, which is what nought says
            wrote = 0.0
        if self.sign[cid] < wrote <= now:
            self.sign[cid] = wrote
        return now - self.sign[cid]

    def spent(self, cid: str) -> float:
        """Intention (BUILD_LOG 1490): the processor seconds this command's tree was seen to use past its seconds."""
        return float(getattr(self.readers.get(cid), "total", 0.0))

    def forget(self, cid: str) -> None:
        """Intention: nothing kept for a command that has ended."""
        self.readers.pop(cid, None)
        self.sign.pop(cid, None)


class CommandLane:
    """The watcher's side: new commands started, running ones finished or ended at their deadline.

    Intention: `hands` is WindowsHands (alive, end); `popen` and `clock` let a
    test stand in. Children started by this watcher are kept in `children`
    so their exit codes can be read; a command a former watcher started is
    followed by its pid alone.
    """

    def __init__(self, root: Path, state: Path, hands=None, popen=None, clock=None, stale: float | None = None,
                 still=None):
        """Intention: the tree, its state, and what the lane acts through."""
        self.still = still or StillFor()
        self.root = Path(root)
        self.home = CommandHome(state)
        self.hands = hands
        self.start = CommandStart(root, self.home, popen)
        self.clock = clock or time.time
        self.stale = stale
        self.children: dict = {}

    def _stale(self) -> float:
        """Intention: the deadline a command gets when it names none — the watcher's own STALE."""
        if self.stale is not None:
            return float(self.stale)
        from warp2.control.watcher import STALE
        return float(STALE)

    def _hands(self):
        """Intention: the process hands, made when first needed."""
        if self.hands is None:
            from warp2.control.windows import WindowsHands
            self.hands = WindowsHands()
        return self.hands

    def look(self) -> dict:
        """Intention: one look — every waiting command started or refused, every running one checked."""
        return {"started": self._take(), "finished": self._follow()}

    def _take(self) -> int:
        """Intention: the inbox, oldest first; each file removed as it is taken."""
        callers = None
        count = 0
        for path in sorted(self.home.inbox.glob("*.json"), key=lambda p: p.stat().st_mtime):
            try:
                row = json.loads(path.read_text(encoding="utf-8-sig"))
            except (OSError, ValueError):
                row = {}
            try:
                path.unlink()
            except OSError:
                continue
            cid = str((row or {}).get("id") or path.stem)
            if self.home.used(cid):
                self._refuse_reuse(cid, row)
                continue
            if callers is None:
                callers = Callers(self.root, self.home).known()
            ask = CommandAsk(self.root, row, self._stale())
            why = ask.refused(callers)
            if why:
                answer = {"id": cid, "by": ask.by, "outcome": "refused", "why": why}
                self.home.write(self.home.done / f"{cid}.json", answer)
                self.home.note(answer)
                continue
            try:
                record = self.start.start(cid, ask, self.clock())
            except Exception as exc:
                answer = {"id": cid, "by": ask.by, "outcome": "failed to start", "why": f"{type(exc).__name__}: {exc}"}
                self.home.write(self.home.done / f"{cid}.json", answer)
                self.home.note(answer)
                continue
            self.children[cid] = self.start.last
            self.home.write(self.home.running / f"{cid}.json", record)
            self.home.note({"id": cid, "by": ask.by, "outcome": "started", "pid": record["pid"],
                            "shell": ask.shell, "run": ask.run[:300], "seconds": ask.seconds})
            count += 1
        return count

    def _refuse_reuse(self, cid: str, row: dict) -> None:
        """Intention: answer the duplicate under a fresh id, preserving the original command and its evidence."""
        answer = {"id": f"{cid}-refused-{uuid.uuid4().hex}", "requested_id": cid,
                  "by": row.get("by"), "outcome": "refused", "why": "command id already used; send a new id"}
        self.home.write(self.home.done / f"{answer['id']}.json", answer)
        self.home.note(answer)

    def _follow(self) -> int:
        """Intention: each running command — finished when its process has ended, ended when past its deadline."""
        count = 0
        for path in sorted(self.home.running.glob("*.json")):
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            cid, now = record["id"], self.clock()
            code = self._exit_code(cid, int(record.get("pid") or 0))
            if code is None and now < float(record["deadline"]):
                continue
            outcome = "finished"
            if code is None and record.get("while_working") is True:
                # Intention (BUILD_LOG 1489): SLOW IS NOT FROZEN. Past its seconds this command is ended only once
                # it has been still - no words, no work - for that long.
                # A SET AMOUNT OF COMPUTE (Andrew, 22:53; BUILD_LOG 1490): past its seconds it may use that many
                # seconds on every processor of this machine - a loop that never stops runs out of it.
                from warp2.record.working import compute_for
                still = self.still.seconds(record, now)
                spent, amount = self.still.spent(cid), compute_for(float(record["seconds"]))
                if still < float(record["seconds"]) and spent < amount:
                    continue
                self._hands().end(int(record["pid"]), force=True, tree=True)
                outcome = (f"ended: used its set amount of compute ({spent:.0f} of {amount:.0f} processor seconds)"
                           if spent >= amount else f"ended: still for {still:.0f} s (no words, no work)")
            elif code is None:
                self._hands().end(int(record["pid"]), force=True, tree=True)
                outcome = "ended at its deadline"
            answer = {"id": cid, "by": record.get("by"), "outcome": outcome,
                      "exit_code": None if code in (None, "gone") else code,
                      "seconds": round(now - float(record["started"]), 1), "out": record.get("out"),
                      "said": _tail(record.get("out"))}
            self.home.write(self.home.done / f"{cid}.json", answer)
            self.home.note({k: v for k, v in answer.items() if k != "said"})
            try:
                path.unlink()
            except OSError:
                pass
            self.children.pop(cid, None)
            self.still.forget(cid)
            count += 1
        return count

    def _exit_code(self, cid: str, pid: int):
        """Intention: the exit code when this watcher started it and it ended; "gone" when a former watcher's child
        is no longer alive (its code cannot be read); None while it runs."""
        child = self.children.get(cid)
        if child is not None:
            return child.poll()
        return None if pid and self._hands().alive(pid) else "gone"


def _tail(out) -> str:
    """Intention: the last of what a command said, from its out file."""
    try:
        return Path(out).read_text(encoding="utf-8", errors="replace")[-TAIL_CHARS:]
    except (OSError, TypeError):
        return ""


class Commands:
    """The sender's side, for a model in the warp (or anything in Python): send a command, read its answer."""

    def __init__(self, state: Path) -> None:
        """Intention: the lane's folders."""
        self.home = CommandHome(state)

    def send(self, by: str, run: str, shell: str = "cmd", seconds: float | None = None, cwd: str = "",
             while_working: bool = False) -> str:
        """Intention: one command into the inbox; its id, to read its answer by. `while_working` asks that its
        seconds bound how long it may be still, not how long it may work (BUILD_LOG 1489)."""
        cid = time.strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
        row = {"id": cid, "by": by, "shell": shell, "run": run}
        if seconds is not None:
            row["seconds"] = float(seconds)
        if cwd:
            row["cwd"] = cwd
        if while_working:
            row["while_working"] = True
        self.home.write(self.home.inbox / f"{cid}.json", row)
        return cid

    def result(self, cid: str) -> dict | None:
        """Intention: the answer once it is there; None while it waits or runs."""
        try:
            return json.loads((self.home.done / f"{cid}.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
