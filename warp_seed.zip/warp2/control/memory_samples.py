# WARP2/warp2/control/memory_samples.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/memory_samples.py
#  Used by   : warp2/control/status.py (answer_status, after status.json is
#              written).
#  Uses      : stdlib json, time, pathlib; warp2/record/swallowed.py.
#  Description:
#    Every status answer also leaves one line in
#    state/diagnostics/memory_samples.jsonl: when it was taken, free RAM and
#    commit, each Python process (pid, parent, when it started, private MB,
#    what it runs), and which warp step was in flight — the last finished
#    journal entry (seq and verb) and when it was written, so the step in
#    flight started at that time. One status.json is overwritten each time;
#    this keeps the samples, so a picture practice step's memory can be
#    compared with the next one like for like (same step, same workload, how
#    long it had run when sampled).
#    The already collected top-other-process rows are kept with it, so a
#    later status.json overwrite does not erase their PIDs and memory sizes.
#  User intention (Andrew, 2026-10-16): get everything in working order; keep
#    everything. (Muse-816, 2026-10-29, asked for the census to carry PID,
#    start time, sample time, private bytes and the workload label per
#    practice step; no record before held that.)
# ============================================================================
"""One kept line per memory sample, tied to the warp step in flight."""
from __future__ import annotations

import json
import time
from pathlib import Path

TAIL_BYTES = 65536


class StepInFlight:
    """Intention: which warp step was running when a sample was taken — read from the end of the journal only."""

    def __init__(self, state: Path) -> None:
        """Intention: the journal whose last line names the step that finished before the one in flight."""
        self.journal = Path(state) / "journals" / "continuous.jsonl"

    def read(self) -> dict:
        """Intention: after_seq, after_verb and since (the journal's last write, epoch seconds); {} if unreadable."""
        try:
            size = self.journal.stat().st_size
            since = self.journal.stat().st_mtime
            with self.journal.open("rb") as handle:
                handle.seek(max(0, size - TAIL_BYTES))
                lines = handle.read().splitlines()
        except OSError:
            return {}
        for raw in reversed(lines):
            try:
                row = json.loads(raw.decode("utf-8", errors="replace"))
            except ValueError:
                continue
            if isinstance(row, dict):
                return {"after_seq": row.get("seq"), "after_verb": row.get("verb") or row.get("role"),
                        "since": round(since, 3)}
        return {"since": round(since, 3)}


class MemorySamples:
    """Intention: append one sample line per status answer, never raising into the watcher."""

    def __init__(self, state: Path) -> None:
        """Intention: the kept sample file under state/diagnostics."""
        self.state = Path(state)
        self.path = self.state / "diagnostics" / "memory_samples.jsonl"

    def row(self, found: dict, now: float | None = None) -> dict:
        """Intention: the sample as one dict — time, RAM, commit, processes with their age, and the step in flight."""
        now = time.time() if now is None else now
        step = StepInFlight(self.state).read()
        if step.get("since") is not None:
            step["running_seconds"] = round(now - step["since"], 1)
        processes = []
        for p in found.get("python") or []:
            started = p.get("started")
            processes.append({"pid": p.get("pid"), "parent": p.get("parent"), "started": started,
                              "age_seconds": round(now - started, 1) if isinstance(started, (int, float)) else None,
                              "private_mb": p.get("private_mb"), "working_mb": p.get("working_mb"),
                              "label": _label(str(p.get("command") or ""))})
        workload = found.get("workload") or {}
        return {"sampled": round(now, 3), "when": found.get("when"),
                "memory_free_mb": found.get("memory_free_mb"), "commit_free_mb": found.get("commit_free_mb"),
                "runner_pid": (workload.get("runner") or {}).get("pid"), "step": step, "python": processes,
                "biggest_others": [dict(p) for p in found.get("biggest_others") or []]}

    def keep(self, found: dict) -> bool:
        """Intention: write the sample line; False (and noted) if the disk refused."""
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as out:
                out.write(json.dumps(self.row(found)) + "\n")
            return True
        except (OSError, TypeError, ValueError) as exc:
            from warp2.record.swallowed import noted
            noted("control.memory_samples.keep", exc)
            return False


def _label(command: str) -> str:
    """Intention: a short name for what a Python process runs — its -m module or script file, else the start."""
    parts = command.replace('"', " ").split()
    for i, part in enumerate(parts):
        if part == "-m" and i + 1 < len(parts):
            rest = parts[i + 2] if i + 2 < len(parts) and not parts[i + 2].startswith(("C:", "/", "-")) else ""
            return (parts[i + 1] + (" " + rest if rest else "")).strip()
        if part.endswith(".py"):
            return part.replace("\\", "/").rsplit("/", 1)[-1]
    return command[:40]
