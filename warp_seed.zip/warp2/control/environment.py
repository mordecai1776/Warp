# WARP2/warp2/control/environment.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/environment.py
#  Used by   : WARP2.bat (continuous launch preflight).
#  Uses      : stdlib platform, importlib.metadata, subprocess; warp2.util.
#  Description:
#    Record an atomic fingerprint of the environment used by a WARP2 launch.
#  User intention: keep failures attributable to the exact launch environment.
# ============================================================================
"""Record an atomic fingerprint of the environment used by a WARP2 launch."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
import subprocess
import sys
import time
from pathlib import Path

from warp2.util import atomic_write_bytes

PACKAGES = ("torch", "numpy", "Pillow", "PySide6", "pyqtgraph", "pytest", "ruff")


def fingerprint(root: str | Path) -> dict:
    """Capture interpreter, platform, dependency versions, and source revision."""
    root = Path(root).resolve()
    versions = {}
    for package in PACKAGES:
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    revision = None
    dirty = None
    try:
        revision = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"],
                                  check=True, capture_output=True, text=True,
                                  timeout=5).stdout.strip()
        dirty = bool(subprocess.run(["git", "-C", str(root), "status", "--porcelain"],
                                    check=True, capture_output=True, text=True,
                                    timeout=5).stdout.strip())
    except (OSError, subprocess.SubprocessError):
        pass
    result = {"python": sys.version, "executable": sys.executable,
              "platform": platform.platform(), "machine": platform.machine(),
              "packages": versions, "git_revision": revision, "git_dirty": dirty}
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["sha256"] = hashlib.sha256(canonical).hexdigest()
    return result


def record(root: str | Path) -> Path:
    """Atomically write the current environment receipt under state/control."""
    root = Path(root).resolve()
    destination = root / "state" / "control" / "environment.json"
    row = {"recorded_at": time.time(), **fingerprint(root)}
    atomic_write_bytes(destination, json.dumps(row, indent=1).encode("utf-8"))
    return destination


def main(argv=None) -> int:
    """Command-line entry point for writing the launch environment receipt.

    Intention: a later failure must be attributable to the interpreter,
    dependency versions, and source revision that actually launched WARP2.
    """
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", default=".")
    args = parser.parse_args(argv)
    try:
        path = record(args.root)
    except OSError as exc:
        print(f"[WARP2] Environment receipt could not be written: {exc}", file=sys.stderr)
        return 1
    print(f"[WARP2] Environment recorded: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
