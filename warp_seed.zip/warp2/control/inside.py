# WARP2/warp2/control/inside.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/inside.py
#  Used by   : warp2/work/card_beat.py (the runner's beat thread),
#              warp2/work/lanes.py (the web lane's beat thread),
#              warp2/app/main.py and warp2/app/feed.py (the window).
#  Uses      : stdlib collections, ctypes, gc, json, os, sys, time, warnings; numpy and torch only if
#              the process has already imported them.
#  Description:
#    What a live process holds in memory, written down on request. When
#    state/control/memory.<lane>.request appears, the lane's beat thread walks
#    everything the process holds, finds every tensor and array (once each,
#    however many places hold it), adds them up by kind and device, and
#    writes the biggest — with their shape and the chain of what holds them —
#    to state/control/memory.<lane>.json. It runs on the beat thread, so it
#    answers even while the lane's main work is busy, and costs nothing until
#    asked. Where every thread is at that moment goes beside it
#    (memory.<lane>.stacks.txt).
#  User intention (Andrew, 2026-10-02): "Then do so" — find what fills the
#    runner's and the web lane's memory (measured that day: 16.6 GB and
#    15.5 GB asked of a 16 GB machine), then cut it.
# ============================================================================
"""A live process's memory, by what holds it."""
from __future__ import annotations

import gc
import json
import os
import sys
import time
import warnings
from collections import deque
from pathlib import Path
from warp2.record.swallowed import noted

# Intention: how many of the biggest things are described with their holders.
# The walk to describe one is the costly part; the totals cover everything.
DESCRIBED = 25

# Intention: the rows and the shape of one let-go probe copy (entry 1052).
# Muse-1034 (2026-11-01): a clean card must say "none at all", not only "no
# group big enough to make the top 20" — so the card counts them exactly.
PROBE_ROWS = 4096
PROBE_SHAPE = (4096, 512)


def _process_memory() -> dict:
    """Intention: this process's private and working memory in MB (Windows), or what the platform can say."""
    try:
        import ctypes
        from ctypes import wintypes

        class Counters(ctypes.Structure):
            """Intention: the Windows memory-counters record that K32GetProcessMemoryInfo fills in, laid out field by field."""
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
                        ("PrivateUsage", ctypes.c_size_t)]
        counters = Counters()
        counters.cb = ctypes.sizeof(Counters)
        # Intention: the handle and the call typed, so a 64-bit handle is not
        # cut to an int (measured 2026-10-02: untyped, it read 0 MB).
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GetCurrentProcess.restype = wintypes.HANDLE
        kernel32.K32GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
        kernel32.K32GetProcessMemoryInfo.restype = wintypes.BOOL
        if not kernel32.K32GetProcessMemoryInfo(kernel32.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
            return {"failed": ctypes.get_last_error()}
        return {"private_mb": round(counters.PrivateUsage / 2**20), "working_mb": round(counters.WorkingSetSize / 2**20)}
    except Exception:
        try:
            import resource
            return {"max_resident_mb": round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024)}
        except Exception:
            return {}


def _sized(thing, np, torch):
    """Intention: (kind, key, bytes, shape, dtype, device) for a tensor or array — the key is its memory, so views of one block count once."""
    if torch is not None and isinstance(thing, torch.Tensor):
        try:
            storage = thing.untyped_storage()
            return ("tensor", ("t", storage.data_ptr(), str(thing.device)), int(storage.nbytes()),
                    tuple(thing.shape), str(thing.dtype), str(thing.device))
        except Exception:
            return None
    if np is not None and isinstance(thing, np.ndarray):
        base = thing
        while isinstance(getattr(base, "base", None), np.ndarray):
            base = base.base
        return ("array", ("a", id(base)), int(base.nbytes), tuple(thing.shape), str(thing.dtype), "cpu")
    return None


def _holders(thing, depth: int = 5, ignore=frozenset()) -> str:
    """Intention: the chain of what holds a thing — an object's attribute, a dict's key, a list — best effort, a few steps up; `ignore` is the report's own tables, never a holder."""
    chain, current, seen = [], thing, {id(thing)} | set(ignore)
    for _ in range(depth):
        found = None
        for holder in gc.get_referrers(current):
            if id(holder) in seen or type(holder).__name__ in ("frame", "function", "cell", "generator", "coroutine"):
                continue
            found = holder
            break
        if found is None:
            break
        seen.add(id(found))
        if isinstance(found, dict):
            key = next((repr(k)[:50] for k, v in found.items() if v is current), "?")
            owner = next((o for o in gc.get_referrers(found)
                          if getattr(o, "__dict__", None) is found), None)
            if owner is not None:
                chain.append(f"{type(owner).__name__}.{key.strip(chr(39))}")
                current = owner
                seen.add(id(owner))
                continue
            chain.append(f"[{key}]")
        elif isinstance(found, (list, tuple, set, deque)):
            chain.append(f"{type(found).__name__}({len(found)})")
        else:
            chain.append(type(found).__name__)
        current = found
    return " <- ".join(chain)


def _probe_rows(found: dict) -> dict:
    """Intention: an exact count of every tensor and array with PROBE_ROWS rows, and how many are PROBE_SHAPE — a number that does not depend on where a list is cut."""
    rows = [(shape, size) for _thing, size, _kind, shape, _dtype, _device in found.values()
            if len(shape) >= 1 and int(shape[0]) == PROBE_ROWS]
    probes = [size for shape, size in rows if tuple(int(n) for n in shape) == PROBE_SHAPE]
    return {"rows": PROBE_ROWS, "count": len(rows), "mb": round(sum(s for _, s in rows) / 2**20, 1),
            "probe_shape": list(PROBE_SHAPE), "probe_count": len(probes),
            "probe_mb": round(sum(probes) / 2**20, 1),
            "in_words": (f"{len(rows)} tensors/arrays have {PROBE_ROWS} rows; "
                         f"{len(probes)} of them are {list(PROBE_SHAPE)}.")}


def report() -> dict:
    """Every tensor and array the process holds, counted once each: totals, and the biggest with their holders."""
    np = sys.modules.get("numpy")
    torch = sys.modules.get("torch")
    began = time.monotonic()
    found = {}
    for holder in gc.get_objects():
        for thing in [holder] + gc.get_referents(holder):
            sized = _sized(thing, np, torch)
            if sized is None:
                continue
            kind, key, size, shape, dtype, device = sized
            if key not in found or found[key][1] < size:
                found[key] = (thing, size, kind, shape, dtype, device)
    # Intention: and everything else — plain Python objects by type, each
    # counted shallow (measured 2026-10-02: tensors were 6.3 GB of a 15.9 GB
    # runner, so the rest had to be named too).
    by_type = {}
    for holder in gc.get_objects():
        name = type(holder).__name__
        count, total = by_type.get(name, (0, 0))
        try:
            by_type[name] = (count + 1, total + sys.getsizeof(holder))
        except Exception:
            by_type[name] = (count + 1, total)
    python_objects = [{"type": k, "count": c, "mb": round(t / 2**20, 1)}
                      for k, (c, t) in sorted(by_type.items(), key=lambda item: -item[1][1])[:15]]
    # Intention: the longest lists and dicts, and what holds them — where
    # plain data piles up (the window held 640,000 dicts, 2026-10-02).
    longest = sorted((o for o in gc.get_objects() if isinstance(o, (list, dict, deque))),
                     key=len, reverse=True)[:12]
    containers = [{"type": type(o).__name__, "length": len(o), "held_by": _holders(o, depth=6, ignore={id(longest)})}
                  for o in longest]
    del longest
    totals = {}
    for thing, size, kind, shape, dtype, device in found.values():
        name = f"{kind} on {device}"
        count, total = totals.get(name, (0, 0))
        totals[name] = (count + 1, total + size)
    biggest = sorted(found.values(), key=lambda item: -item[1])[:DESCRIBED]
    ours = {id(found), id(biggest)} | {id(v) for v in found.values()}
    described = [{"mb": round(size / 2**20, 1), "kind": kind, "shape": list(shape), "dtype": dtype,
                  "device": device, "held_by": _holders(thing, ignore=ours)}
                 for thing, size, kind, shape, dtype, device in biggest]
    shapes, one_of = {}, {}
    for thing, size, kind, shape, dtype, device in found.values():
        name = f"{kind} {list(shape)} {dtype} {device}"
        count, total = shapes.get(name, (0, 0))
        shapes[name] = (count + 1, total + size)
        one_of.setdefault(name, thing)
    by_shape = sorted(shapes.items(), key=lambda item: -item[1][1])[:20]
    # Intention: who holds a shape that comes in thousands — one of them,
    # followed up, says which part of the system they belong to.
    mine = {id(found), id(one_of), id(shapes), id(biggest)} | {id(v) for v in found.values()}
    held = {k: _holders(one_of[k], depth=8, ignore=mine) for k, _ in by_shape[:10]}
    return {"when": time.strftime("%Y-%m-%d %H:%M:%S"), "pid": os.getpid(), "process": _process_memory(),
            "totals_mb": {k: {"count": c, "mb": round(t / 2**20, 1)} for k, (c, t) in
                          sorted(totals.items(), key=lambda item: -item[1][1])},
            "same_shape_mb": [{"what": k, "count": c, "mb": round(t / 2**20, 1), "one_held_by": held.get(k, "")}
                              for k, (c, t) in by_shape],
            "rows_4096": _probe_rows(found),
            "biggest": described, "python_objects": python_objects, "longest_containers": containers,
            "cuda": _cuda_memory(torch), "networks": _networks(),
            "seconds": round(time.monotonic() - began, 1)}


def _networks() -> dict:
    """Intention: every pop network the process holds (pairs/rest.py knows them all), counted by the first part of its name, with their weights' size — and which Eyes are open."""
    shared = sys.modules.get("_pop_rest_registry")
    out = {}
    if shared is not None:
        for net in list(shared.nets):
            name = str(getattr(net, "name", "?")).split(":")[0]
            try:
                size = sum(p.numel() * p.element_size() for p in net.model.parameters())
                size += sum(b.numel() * b.element_size() for b in net.model.buffers())
            except Exception:
                size = 0
            count, total = out.get(name, (0, 0))
            out[name] = (count + 1, total + size)
    eyes = []
    for module in ("behemoth_eye.eye.warp_eye", "projects.behemoth_eye.eye.warp_eye"):
        found = sys.modules.get(module)
        if found is not None:
            eyes += [str(k) for k in getattr(found, "_warp_eye_registry", {})]
    return {"by_name": [{"name": k, "count": c, "mb": round(t / 2**20, 1)}
                        for k, (c, t) in sorted(out.items(), key=lambda item: -item[1][1])[:20]],
            "eyes_open": eyes}


def _cuda_memory(torch) -> dict:
    """Intention: what torch holds on the card — in tensors, and reserved by its cache beyond them."""
    try:
        if torch is None or not torch.cuda.is_available():
            return {}
        return {"allocated_mb": round(torch.cuda.memory_allocated() / 2**20),
                "reserved_mb": round(torch.cuda.memory_reserved() / 2**20)}
    except Exception:
        return {}


def answer_memory(state, lane: str) -> bool:
    """Intention: if this lane's memory was asked for, the report is written and the ask removed; whether it was asked."""
    folder = Path(state) / "control"
    asked = folder / f"memory.{lane}.request"
    if not asked.exists():
        return False
    try:
        asked.unlink()
    except OSError:
        return False
    try:
        # Intention: looking at every object trips deprecation warnings in
        # modules that are only looked at, never used — they say nothing here.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            said = report()
    except Exception as exc:
        said = {"failed": f"{type(exc).__name__}: {exc}"}
    from warp2.util import atomic_write_bytes
    atomic_write_bytes(folder / f"memory.{lane}.json", json.dumps(said, indent=1).encode())
    # Intention: and where every thread is at that moment — what is building
    # the memory up, not only what it holds.
    try:
        import faulthandler
        import tempfile
        with tempfile.TemporaryFile(mode="w+b", dir=folder) as out:
            faulthandler.dump_traceback(file=out, all_threads=True)
            out.flush()
            out.seek(0)
            atomic_write_bytes(folder / f"memory.{lane}.stacks.txt", out.read())
    except Exception as exc:
        noted("warp2/control/inside.py:answer_memory", exc)
    return True
