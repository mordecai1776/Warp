# WARP2/warp2/control/overdue.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/overdue.py
#  Used by   : warp2/control/status.py (status.json's workload),
#              warp2/control/supervisor.py (supervision.json).
#  Uses      : warp2/record/deadline.py (Deadlines.budget — a verb's usual cost
#              plus its spread), warp2/work/lanes.py (WEB_STEPS),
#              state/work/side_turns.json (when each side step last started),
#              state/journals/continuous.jsonl (when the runner last wrote).
#  Description:
#    Whether the card lane's step in flight has run far past its usual time.
#    The runner's beat comes from a side thread, so a runner stuck inside one
#    step still beats and was called "healthy". The step in flight is the side
#    step that started after the journal's last line; its usual time is its
#    own measured budget (mean plus spread), never a number set here. Read
#    only; it changes nothing and restarts nothing.
#  User intention (Andrew, 2026-10-31: "I want you to fix everything that is
#    wrong"). Measured that night: train_chat ran two hours against a usual
#    twenty minutes while status said "healthy".
# ============================================================================
"""Is the step in flight far past its usual time."""
from __future__ import annotations

import json
import time
from pathlib import Path


def step_in_flight(state, now: float | None = None) -> dict:
    """Intention: the card lane's step in flight — verb (None when it is not a side step), since, running seconds,
    its usual seconds and whether it is past them ("overdue"); {} when the journal cannot be read."""
    state = Path(state)
    now = time.time() if now is None else float(now)
    journal = state / "journals" / "continuous.jsonl"
    try:
        wrote = journal.stat().st_mtime
    except OSError:
        return {}
    verb, since = None, wrote
    try:
        from warp2.work.lanes import WEB_STEPS
        book = json.loads((state / "work" / "side_turns.json").read_text(encoding="utf-8"))
        mine = {str(k): float(v) for k, v in (book or {}).items()
                if isinstance(v, (int, float)) and not str(k).startswith("phase:") and str(k) not in WEB_STEPS}
        if mine:
            latest = max(mine, key=mine.get)
            if mine[latest] >= wrote:
                verb, since = latest, mine[latest]
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    out = {"verb": verb, "since": round(since, 3), "running_seconds": round(max(0.0, now - since), 1)}
    if verb is None:
        return out
    try:
        from warp2.record.deadline import Deadlines
        budget = Deadlines(state / "deadlines.json").budget(verb)
    except Exception:  # noqa: BLE001 — no reading is no verdict
        return out
    out["usual_seconds"] = round(float(budget["seconds"]), 1)
    out["basis"] = budget.get("basis")
    out["overdue"] = bool(budget.get("basis") == "measured" and out["running_seconds"] > float(budget["seconds"]))
    if out["overdue"]:
        out["times_usual"] = round(out["running_seconds"] / max(float(budget["seconds"]), 1e-9), 2)
    return out
