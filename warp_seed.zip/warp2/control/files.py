# WARP2/warp2/control/files.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/files.py
#  Used by   : warp2/control/watcher.py (takes requests, beats, answers);
#              warp2/control/restart.py (writes the answer).
#  Uses      : stdlib json, os, time, pathlib.
#  Description:
#    The files the watcher and whoever asks for a restart talk through, all in
#    state/control/. A request is a file; it is removed the moment it is
#    taken, so one request is one restart. The answer goes to restart.last.json
#    and a short log that keeps only recent entries.
#  User intention (Andrew, 2026-10-02): a restart Claude can cause from away,
#    and see the result of. "Clean": nothing old is left to be taken again.
# ============================================================================
"""The request, beat and answer files for remote restarts."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

# Intention: the log is kept to the recent past only — an answer older than
# this many restarts is not one anyone will read.
KEEP_ANSWERS = 50


class ControlFiles:
    """Intention: every path in one place, so the asker and the watcher cannot disagree on a name."""

    def __init__(self, state: Path) -> None:
        """Intention: name every control file in one place, so the watcher, restart and status all use the same paths."""
        self.state = Path(state)
        self.dir = self.state / "control"
        self.request = self.dir / "restart.request"
        self.beat = self.dir / "watcher.beat"
        self.last = self.dir / "restart.last.json"
        self.log = self.dir / "restart.log.jsonl"
        self.expected = self.dir / "run.expected"
        self.supervision = self.dir / "supervision.json"
        self.stop_flag = self.state / "locks" / "stop.flag"
        self.reload_flag = self.state / "locks" / "reload.flag"
        self.runner_beat = self.state / "lanes" / "card.beat"
        self.lane_beat = self.state / "lanes" / "web.beat"

    def ready(self) -> None:
        """Intention: make the control folder if it is missing, so the first write into it does not fail."""
        self.dir.mkdir(parents=True, exist_ok=True)

    def take(self) -> dict | None:
        """The request, if there is one, removed as it is read — None when nobody asked.

        Intention: an empty or unreadable request still counts as a request
        (the asker may write an empty file); its settings fall back to defaults.
        """
        if not self.request.exists():
            return None
        try:
            # Intention (Codex, 2026-11-01): Windows writers may prefix UTF-8
            # with a BOM; it must not make JSON settings fall back to plain text.
            text = self.request.read_text(encoding="utf-8-sig").strip()
        except OSError:
            return None
        try:
            asked = json.loads(text) if text else {}
        except ValueError:
            asked = {"why": text[:200]}
        try:
            self.request.unlink()
        except OSError:
            return None
        return asked if isinstance(asked, dict) else {}

    def answer(self, result: dict) -> None:
        """Intention: the latest answer whole, and a log trimmed to the recent ones."""
        self.ready()
        from warp2.util import atomic_write_bytes
        atomic_write_bytes(self.last, json.dumps(result, indent=1).encode("utf-8"))
        lines = []
        if self.log.exists():
            lines = self.log.read_text(encoding="utf-8").splitlines()
        lines.append(json.dumps(result))
        atomic_write_bytes(self.log, ("\n".join(lines[-KEEP_ANSWERS:]) + "\n").encode("utf-8"))

    def beat_now(self, note: str = "watching") -> None:
        """Intention: proof the watcher is alive — its pid, the time, and what it is doing."""
        self.ready()
        from warp2.util import atomic_write_bytes
        atomic_write_bytes(self.beat, f"{os.getpid()} {time.time():.3f} {note}\n".encode("utf-8"))


def beat_pid(path: Path) -> int | None:
    """Intention: the pid at the start of a lane beat file ("pid epoch"), or None."""
    try:
        return int(Path(path).read_text(encoding="utf-8").split()[0])
    except (OSError, ValueError, IndexError):
        return None
