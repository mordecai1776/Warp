# WARP2/warp2/control/window.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/window.py
#  Used by   : warp2/control/watcher.py (when state/control/window.request
#              appears).
#  Uses      : warp2/control/windows.py (WindowsHands, WINDOW_COMMANDS);
#              stdlib json, time.
#  Description:
#    Closes the WARP's window on request (an empty request), or opens it
#    alone ({"open": true}), and leaves the runner and the web lane as they are. The window only shows things; the work goes on without it,
#    and the next restart (or WARP2.bat) opens it again. Asked politely first,
#    then ended. The answer goes to state/control/window.json.
#  User intention (Andrew, 2026-10-02): Claude keeps the warp running alone
#    while he is away. (Measured that day: the window held 21.5 GB of a 16 GB
#    machine two minutes after it opened, and the machine had 5 MB free.)
# ============================================================================
"""Close the window, keep the work running."""
from __future__ import annotations

import json
import os
import time

from warp2.util import atomic_write_bytes

_LAST_NEXUS_CHECK = 0.0


def _is_nexus_point(state) -> bool:
    """Intention: True when this machine has bloomed as a Nexus point (`tier == 'nexus'`)."""
    bloom_file = state / "seed" / "bloom.json"
    if not bloom_file.is_file():
        return False
    try:
        data = json.loads(bloom_file.read_text(encoding="utf-8"))
        return str((data.get("plan") or {}).get("tier") or "") == "nexus"
    except Exception:
        return False


def answer_window(files, hands=None) -> bool:
    """Intention: answer an explicit open/close request, and on a Nexus point keep the window open unless the user explicitly closed it."""
    global _LAST_NEXUS_CHECK
    asked = files.dir / "window.request"
    closed_mark = files.dir / "window.closed_by_user"
    if not asked.exists():
        now = time.monotonic()
        if (
            "PYTEST_CURRENT_TEST" not in os.environ
            and now - _LAST_NEXUS_CHECK >= 20.0
            and not closed_mark.exists()
            and not files.stop_flag.exists()
            and _is_nexus_point(files.state)
        ):
            _LAST_NEXUS_CHECK = now
            from warp2.control.windows import WINDOW_COMMANDS, WindowsHands
            hands = hands or WindowsHands()
            if not hands.by_command(WINDOW_COMMANDS):
                pid = hands.open_window(files.state.parent)
                atomic_write_bytes(files.dir / "window.json", json.dumps(
                    {"when": time.strftime("%Y-%m-%d %H:%M:%S"), "opened": pid, "why": "nexus_keep_open"}).encode())
                return True
        return False
    try:
        text = asked.read_text(encoding="utf-8").strip()
        asked.unlink()
    except OSError:
        return False
    from warp2.control.windows import WINDOW_COMMANDS, WindowsHands
    hands = hands or WindowsHands()
    if text and json.loads(text).get("open"):
        closed_mark.unlink(missing_ok=True)
        pid = hands.open_window(files.state.parent)
        atomic_write_bytes(files.dir / "window.json", json.dumps(
            {"when": time.strftime("%Y-%m-%d %H:%M:%S"), "opened": pid}).encode())
        return True
    closed_mark.write_text(f"closed at {time.strftime('%Y-%m-%d %H:%M:%S')}\n", encoding="utf-8")
    pids = hands.by_command(WINDOW_COMMANDS)
    for pid in pids:
        hands.end(pid, force=False, tree=False)
    ends = time.monotonic() + 20.0
    left = [p for p in pids if hands.alive(p)]
    while left and time.monotonic() < ends:
        time.sleep(2.0)
        left = [p for p in left if hands.alive(p)]
    for pid in left:
        hands.end(pid, force=True, tree=True)
    atomic_write_bytes(files.dir / "window.json", json.dumps(
        {"when": time.strftime("%Y-%m-%d %H:%M:%S"), "closed": pids, "forced": left}).encode())
    return True
