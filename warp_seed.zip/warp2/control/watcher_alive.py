# WARP2/warp2/control/watcher_alive.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/watcher_alive.py
#  Used by   : warp2/run.py (_Reload holds a reload while no watcher is up;
#              the card beat asks check() every beat).
#  Uses      : warp2/control/watcher.py (STALE), warp2/record/quiet.py (no
#              console window); stdlib json, subprocess, sys, time.
#  Description:
#    The runner's side of keeping the restart watcher up. The watcher starts
#    the runner when it is missing; this lets the runner start the watcher
#    when IT is missing, through its scheduled task, so neither can stay
#    down while the other lives. And a runner the watcher launched (headless,
#    through warp2.control.preflight) does not leave for a reload while no
#    watcher is beating — only the watcher would start it again, so it keeps
#    running on its old code instead of going down.
#    Every attempt is written to state/control/watcher-revived.jsonl with what
#    the task scheduler said about the task, to find out why the watcher went.
#  Seen (2026-10-17/18): the watcher and its service vanished twice with no
#    crash on record (22:57 and 03:54 UTC); after the first, the runner left
#    for a reload at 00:05 and the warp stayed down until a PC restart.
#  User intention (Andrew, 2026-10-16): the catastrophic failure is the whole
#    system stopping; Claude may restart the program on its own.
# ============================================================================
"""Keep the restart watcher up from the runner's side."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

# Intention: the name INSTALL_RESTART_WATCHER.ps1 registers the task under.
TASK = "WARP2 Restart Watcher"
# Intention: how long to leave the task scheduler between two attempts — long
# enough that a watcher starting slowly (start-up tests take ~2 min) is not
# asked for twice, short enough that the warp is never long without one.
RETRY_EVERY = 600.0
# Intention: one schtasks call may take this long, well inside the card beat's
# 120 s silence bound, since check() runs on the beat's thread.
CALL_SECONDS = 15.0


def launched_by_watcher() -> bool:
    """Intention: True when this process is the headless runner the watcher started (warp2.control.preflight);
    a runner started by WARP2.bat has the bat's own loop to start it again after a reload."""
    spec = getattr(sys.modules.get("__main__"), "__spec__", None)
    return getattr(spec, "name", "") == "warp2.control.preflight"


class WatcherKeeper:
    """Intention: say whether the watcher is beating, and when it is not, ask its scheduled task to start —
    at most once every RETRY_EVERY seconds, each attempt written down."""

    def __init__(self, state: Path, *, headless: bool | None = None, call=None,
                 clock=time.time, windows: bool | None = None) -> None:
        """Intention: hold where the beat and the log are, how to call schtasks and the clock; nothing runs yet."""
        self.beat = Path(state) / "control" / "watcher.beat"
        self.log = Path(state) / "control" / "watcher-revived.jsonl"
        self.headless = launched_by_watcher() if headless is None else headless
        self.windows = (os.name == "nt") if windows is None else windows
        self._call = call or self._schtasks
        self._clock = clock
        self._last_try = None
        self._holding = False

    def age(self) -> float | None:
        """Intention: seconds since the watcher last beat; None when there is no readable beat."""
        try:
            at = float(self.beat.read_text(encoding="utf-8").split()[1])
        except (OSError, ValueError, IndexError):
            return None
        return self._clock() - at

    def up(self) -> bool:
        """Intention: a beat younger than the watcher's own STALE means a watcher is alive."""
        from warp2.control.watcher import STALE
        seconds = self.age()
        return seconds is not None and 0.0 <= seconds < STALE

    def check(self) -> bool:
        """Intention: True when the watcher is up; otherwise ask the task to start (if due) and say False."""
        if self.up():
            self._holding = False
            return True
        if not self.windows:
            return False
        now = self._clock()
        if self._last_try is not None and now - self._last_try < RETRY_EVERY:
            return False
        self._last_try = now
        ran = self._call(["/Run", "/TN", TASK])
        asked = self._call(["/Query", "/TN", TASK, "/V", "/FO", "LIST"])
        self._write({"event": "asked_task_to_start", "beat_age_s": self.age(),
                     "run": ran, "task": asked})
        return False

    def hold_reload(self, why: str) -> bool:
        """Intention: True when a reload must wait — this runner was started by the watcher and no watcher
        is beating, so leaving now would leave the warp down. Said once per hold, in the log."""
        if not self.headless or self.check():
            return False
        if not self._holding:
            self._holding = True
            self._write({"event": "reload_held", "why": why, "beat_age_s": self.age()})
        return True

    def _write(self, row: dict) -> None:
        """Intention: one line per event, with the time; a failed write is said, never fatal."""
        try:
            self.log.parent.mkdir(parents=True, exist_ok=True)
            with self.log.open("a", encoding="utf-8") as out:
                out.write(json.dumps({"when": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), **row}) + "\n")
        except OSError as exc:
            from warp2.record.swallowed import noted
            noted("control.watcher_alive.write", exc)

    @staticmethod
    def _schtasks(args: list) -> dict:
        """Intention: run schtasks with no window and a time limit; its code and the end of what it said."""
        from warp2.record.quiet import quiet
        try:
            done = subprocess.run(["schtasks", *args], capture_output=True, text=True,
                                  timeout=CALL_SECONDS, **quiet())
        except (OSError, subprocess.SubprocessError) as exc:
            return {"failed": f"{type(exc).__name__}: {exc}"}
        return {"code": done.returncode, "said": (done.stdout + done.stderr)[-1500:]}
