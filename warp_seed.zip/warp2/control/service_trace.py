# WARP2/warp2/control/service_trace.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/control/service_trace.py
#  Used by   : warp2/control/watcher_service.py (supervise, _watch_worker).
#  Uses      : warp2/util.py (atomic_write_bytes), warp2/record/swallowed.py
#              (noted); stdlib json, os, time, pathlib.
#  Description:
#    The watcher service's own trace, so its death is on the record too.
#    Two parts: a lives log (state/control/watcher-service.lives.jsonl) with a
#    line at each service start, each worker start and end, and the service's
#    own stop; and a rolling beat (state/control/watcher-service.beat) written
#    at most every 30 s while it serves. A hard kill leaves a stale beat; a
#    clean end leaves a stop line; lives are counted from the start lines.
#  User intention (Andrew, 2026-10-16): the catastrophic failure is the whole
#    system stopping; every failure should leave something to learn from.
#    Seen 2026-10-18: watcher and service both gone with nothing written about
#    when or why (BUILD_LOG 332); Muse (muse-57) agreed: birth line plus beat.
# ============================================================================
"""The watcher service writes when it lives, what its workers did, and a beat."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from warp2.util import atomic_write_bytes

# Intention: 30 s is fine enough for a failure that left the warp down for
# hours, and well inside the 10-minute cadence of the runner's revive guard.
BEAT_EVERY = 30.0


class ServiceTrace:
    """Intention: one service's trace — lines for what happened, a beat for that it still lives.
    A failed write is noted and stepped past; the service must never stop for its trace."""

    def __init__(self, root: Path | str, clock=time.monotonic, every: float = BEAT_EVERY):
        """Intention: where the trace goes and the clock that paces the beat; nothing is written yet."""
        control = Path(root) / "state" / "control"
        self.lives = control / "watcher-service.lives.jsonl"
        self.beat = control / "watcher-service.beat"
        self._clock, self._every = clock, every
        self._last: float | None = None

    def line(self, what: str, **more) -> None:
        """Intention: one line in the lives log — when, which service, what happened."""
        row = {"when": round(time.time(), 3), "service_pid": os.getpid(), "what": what}
        row.update(more)
        try:
            self.lives.parent.mkdir(parents=True, exist_ok=True)
            with self.lives.open("a", encoding="utf-8") as out:
                out.write(json.dumps(row) + "\n")
        except OSError as exc:
            from warp2.record.swallowed import noted
            noted("control.service_trace.line", exc)

    def beat_now(self) -> None:
        """Intention: rewrite the beat if the last one is BEAT_EVERY old (or there is none)."""
        now = self._clock()
        if self._last is not None and now - self._last < self._every:
            return
        self._last = now
        try:
            self.beat.parent.mkdir(parents=True, exist_ok=True)
            atomic_write_bytes(self.beat, f"{os.getpid()} {time.time():.3f} serving\n".encode("utf-8"))
        except OSError as exc:
            from warp2.record.swallowed import noted
            noted("control.service_trace.beat", exc)
