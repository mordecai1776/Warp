# WARP2/warp2/house/tag_lessons.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tag_lessons.py
#  Used by   : warp2/house/tag_lora.py (what the house's language models are
#              taught).
#  Uses      : warp2/app/parts/eye_digest.py (read_digest: the Eye's hierarchy,
#              read small in a process of its own); stdlib hashlib, re.
#  Description:
#    LESSONS IN THE EYE'S TAGS, BOTH WAYS. A tag is a concept's name as the Eye
#    keeps it, short: "#" and the name with "_" for spaces. From what the Eye
#    last wrote:
#      - each concept's mix (what it is made of, strongest part first):
#          tags in, tags out:   "#cat ->parts"           -> "#paw #fur"
#                               "#paw #fur ->whole"      -> "#cat"
#          words in, tags out:  "Name the parts of cat as tags." -> "#paw #fur"
#          tags in, words out:  "Say in words: #cat #paw #fur"
#                                                -> "cat is made of paw, fur."
#      - each concept's strongest tie:  "#cat ~?" -> "#dog"
#    Every lesson has a key (its prompt's hash). Lessons alternate, by key,
#    between being learned and being held back to check that learning helped.
#  User intention (Andrew, 2026-11-09 19:05): "training those new models to give
#    adaptation to at least run from compressed tags like the eye" - chosen:
#    both ways. (BUILD_LOG 1484.)
# ============================================================================
"""Lessons in the Eye's tags, both ways, from what the Eye last wrote; half learned, half held back."""
from __future__ import annotations

import hashlib
import re


def tag(name: str) -> str:
    """Intention: a concept's name as a short tag."""
    return "#" + re.sub(r"\s+", "_", str(name).strip())


def key(prompt: str) -> str:
    """Intention: a lesson's key - the same prompt, the same key, on any machine."""
    return hashlib.sha256(str(prompt).encode("utf-8")).hexdigest()


class TagLessons:
    """The lessons the Eye's last write gives."""

    def __init__(self, state, digest=None) -> None:
        """Intention: where the Eye writes; a test hands in its own hierarchy."""
        self.state = state
        self._digest = digest

    def digest(self) -> dict:
        """Intention: the Eye's hierarchy, read small; {} when the Eye has written none."""
        if self._digest is None:
            from warp2.app.parts.eye_digest import read_digest
            self._digest = read_digest(self.state)
        return self._digest

    def lessons(self) -> list:
        """Intention: [{key, prompt, answer, kind}] from every mix and every strongest tie, in key order."""
        side = self.digest().get("concepts") or {}
        out = []
        for name, mix in sorted((side.get("mixes") or {}).items()):
            parts = [p for p, _w in sorted((mix.get("parts") or {}).items(), key=lambda kv: -abs(float(kv[1])))]
            if not parts:
                continue
            tags = " ".join(tag(p) for p in parts)
            out += [self._one(f"tags: {tag(name)} ->parts", tags, "tags to tags"),
                    self._one(f"tags: {tags} ->whole", tag(name), "tags to tags"),
                    self._one(f"Name the parts of {name} as tags.", tags, "words to tags"),
                    self._one(f"Say in words: {tag(name)} {tags}", f"{name} is made of {', '.join(parts)}.",
                              "tags to words")]
        relations = side.get("relations")
        for name in (relations.named() if hasattr(relations, "named") else []):
            ties = relations.ties(name, 1)
            if ties:
                out.append(self._one(f"tags: {tag(name)} ~?", tag(ties[0][0]), "tags to tags"))
        return sorted(out, key=lambda lesson: lesson["key"])

    @staticmethod
    def _one(prompt: str, answer: str, kind: str) -> dict:
        """Intention: one lesson with its key."""
        return {"key": key(prompt), "prompt": prompt, "answer": answer, "kind": kind}

    @staticmethod
    def halves(lessons: list) -> tuple:
        """Intention: (to learn, held back) - every other lesson in key order."""
        return lessons[0::2], lessons[1::2]
