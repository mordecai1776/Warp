# WARP2/warp2/house/fetch_model.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/fetch_model.py
#  Used by   : GET_PICTURE_MODEL.bat, GET_PICTURE_READER.bat (python -m
#              warp2.house.fetch_model <repo> <folder> [file patterns]).
#  Uses      : huggingface_hub (model_info, snapshot_download);
#              warp2/record/kept_file.py; stdlib sys, pathlib.
#  Description:
#    A MODEL FETCHED FOR THE HOUSE, ONLY WITH A LICENCE THAT LETS IT BE USED.
#    The repository's licence is read from its card first; a repository with
#    no licence, or one not on the list below, is refused and nothing is
#    downloaded. Only what the house loads is taken: the configs, the
#    tokenizer, and the half-size weights. Where it came from (the repository,
#    its licence, its author, when) is kept beside it in warp2_source.json.
#  User intention (Andrew, 2026-11-09 19:05): "holds models like ollama and
#    comfy could inside the warp" - chosen: SD 1.5. Standing rule: the fetcher
#    refuses repositories with no licence and records source, licence and
#    author. (BUILD_LOG 1484.)
# ============================================================================
"""A model fetched for the house - refused without a licence that lets it be used, kept with where it came from."""
from __future__ import annotations

import sys
import time
from pathlib import Path

# Intention: licences (as Hugging Face names them) that let a model be used here.
OPEN_LICENCES = frozenset({"mit", "apache-2.0", "bsd-2-clause", "bsd-3-clause", "openrail", "openrail++",
                           "creativeml-openrail-m", "bigscience-openrail-m", "cc-by-4.0", "cc0-1.0"})

# Intention: what the house loads from a diffusers or transformers folder - nothing more is downloaded.
TAKEN = ["*.json", "*.txt", "*.model", "*fp16.safetensors"]


class Refused(RuntimeError):
    """Intention: a repository not fetched, and why."""


def licence_of(info) -> str:
    """Intention: the repository's licence as its card names it; "" when it names none."""
    card = getattr(info, "card_data", None) or getattr(info, "cardData", None) or {}
    found = card.get("license") if isinstance(card, dict) else getattr(card, "license", None)
    return str(found or "").lower()


def fetch(repo: str, folder, hub=None, taken=None) -> dict:
    """Intention: the repository checked, then fetched into `folder` with its record; Refused without an open licence.
    `taken` names the files wanted when they are not the usual ones (BUILD_LOG 1485)."""
    taken = list(taken or TAKEN)
    from warp2.record.kept_file import write_kept
    if hub is None:
        import huggingface_hub as hub
    info = hub.model_info(repo)
    licence = licence_of(info)
    if licence not in OPEN_LICENCES:
        raise Refused(f"{repo}: licence {licence or 'none'!r} is not one that lets it be used here")
    folder = Path(folder)
    hub.snapshot_download(repo_id=repo, local_dir=str(folder), allow_patterns=taken)
    record = {"source": f"https://huggingface.co/{repo}", "licence": licence,
              "author": str(getattr(info, "author", "") or repo.split("/")[0]),
              "fetched": time.strftime("%Y-%m-%d %H:%M:%S"), "taken": taken}
    write_kept(folder / "warp2_source.json", record, indent=1)
    return record


def main(argv=None) -> int:
    """Intention: the .bat's door - says what was fetched, or why not."""
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        said = fetch(argv[0], argv[1], taken=argv[2:])
    except Refused as exc:
        print(f"Not fetched: {exc}")
        return 1
    print(f"Fetched {argv[0]} ({said['licence']}, by {said['author']}) into {argv[1]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
