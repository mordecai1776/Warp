# WARP2/warp2/house/text_runner.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/text_runner.py
#  Used by   : warp2/house/house.py (a language model the house holds).
#  Uses      : torch, transformers, peft (only when the model is loaded);
#              warp2/room/split_load.py (where its layers go).
#  Description:
#    ONE LANGUAGE MODEL, LOADED TO FIT. Its layers go where the room is
#    (the card, the card and memory, or read from disk a layer at a time -
#    warp2/room/split_load.py). Its tag adapter (a LoRA taught to read and
#    write the Eye's tags, warp2/house/tag_lora.py) is put on when there is
#    one, and the runner says when that adapter has been written again since
#    it was loaded, so the house loads the newer one. An answer is the
#    model's own words for one prompt, greedy, as long as asked - asked to
#    answer without thinking first, and with any <think> block set aside
#    (BUILD_LOG 1486).
#  User intention (Andrew, 2026-11-09 19:05): "holds models like ollama ...
#    inside the warp ... add back in loras and training those new models".
#    (BUILD_LOG 1484.)
# ============================================================================
"""One language model, loaded to fit the room, with its tag adapter when there is one."""
from __future__ import annotations

import re
from pathlib import Path


# Intention (BUILD_LOG 1486): thinking a model writes before its answer is not its answer.
_THINKING = re.compile(r"(?s)<think>.*?(?:</think>|\Z)")


def chat_text(tokenizer, prompt: str) -> str:
    """The prompt as the model's own chat form, asked to answer without thinking first.

    Intention (BUILD_LOG 1486, measured 2026-11-09 21:23: qwen3-1.7b's answer began "<think>\nOkay, the user is
    asking" and its 8 tokens ran out before any answer): Ollama was asked with think off; the house asks the same
    way - the chat form's own switch (enable_thinking), which forms without one ignore. A tokenizer with no chat
    form gets the prompt as it is.
    """
    if not getattr(tokenizer, "chat_template", None):
        return str(prompt)
    return tokenizer.apply_chat_template([{"role": "user", "content": str(prompt)}], tokenize=False,
                                         add_generation_prompt=True, enable_thinking=False)


def without_thinking(said: str) -> str:
    """Intention: an answer with any <think> block set aside (closed, or cut off by the end of its room)."""
    return _THINKING.sub("", str(said)).strip()


def adapter_mark(folder) -> float:
    """Intention: when the adapter was last written; nought when there is none."""
    config = Path(folder) / "adapter_config.json"
    return config.stat().st_mtime if config.is_file() else 0.0


class TextRunner:
    """A language model and its tokenizer, loaded once, answering prompts."""

    def __init__(self, path, adapter="", offload_home=None) -> None:
        """Intention: the model folder, its adapter folder, and where layers that fit nowhere wait on disk."""
        self.path = Path(path)
        self.adapter = Path(adapter) if adapter else None
        self.offload_home = Path(offload_home) if offload_home else self.path.parent / "warp2_offload"
        self.model = self.tokenizer = None
        self.where = ""
        self.adapter_at = 0.0

    def need(self) -> int:
        """Intention: the bytes this model takes as it will be loaded."""
        from warp2.room.split_load import loaded_bytes
        return loaded_bytes(self.path, self._type())

    @staticmethod
    def _type() -> str:
        """Intention: half precision on a card, full off it."""
        import torch
        return "bfloat16" if torch.cuda.is_available() else "float32"

    def load(self) -> "TextRunner":
        """Intention: tokenizer, model placed to fit, adapter on when there is one."""
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from warp2.room.split_load import placement
        load_as = self._type()
        placed = placement(self.path, load_as, self.offload_home)
        self.tokenizer = AutoTokenizer.from_pretrained(str(self.path))
        model = AutoModelForCausalLM.from_pretrained(str(self.path), torch_dtype=getattr(torch, load_as),
                                                     low_cpu_mem_usage=True, **placed["kwargs"])
        self.where = placed["where"]
        if self.adapter is not None and adapter_mark(self.adapter):
            from peft import PeftModel
            model = PeftModel.from_pretrained(model, str(self.adapter))
            self.adapter_at = adapter_mark(self.adapter)
        model.eval()
        self.model = model
        return self

    def stale(self) -> bool:
        """Intention: the adapter on disk is newer than the one loaded."""
        return self.adapter is not None and adapter_mark(self.adapter) > self.adapter_at

    def answer(self, prompt: str, tokens: int) -> str:
        """Intention: the model's words for one prompt, at most `tokens` new tokens."""
        import torch
        inputs = self.tokenizer(chat_text(self.tokenizer, prompt), return_tensors="pt")
        device = next(self.model.parameters()).device
        # Intention: only what every language model takes - a tokenizer's other outputs (token_type_ids) are refused
        # by generate on some versions of transformers.
        inputs = {k: inputs[k].to(device) for k in ("input_ids", "attention_mask") if k in inputs}
        pad = self.tokenizer.pad_token_id if self.tokenizer.pad_token_id is not None else self.tokenizer.eos_token_id
        with torch.no_grad():
            out = self.model.generate(**inputs, max_new_tokens=max(1, int(tokens)), do_sample=False,
                                      pad_token_id=pad)
        return without_thinking(self.tokenizer.decode(out[0][inputs["input_ids"].shape[1]:],
                                                      skip_special_tokens=True))

    def close(self) -> None:
        """Intention: the model and tokenizer let go."""
        self.model = self.tokenizer = None
