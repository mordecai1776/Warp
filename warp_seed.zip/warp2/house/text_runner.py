# WARP2/warp2/house/text_runner.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/text_runner.py
#  Used by   : warp2/house/house.py (a language model the house holds).
#  Uses      : torch, transformers, peft (only when the model is loaded);
#              warp2/room/split_load.py (where its layers go);
#              warp2/house/held_small/{text_base,adapter_on}.py (the base
#              and the adapter from their small forms, BUILD_LOG 1562 and BUILD_LOG 1563).
#  Description:
#    ONE LANGUAGE MODEL, LOADED TO FIT. Its layers go where the room is
#    (the card, the card and memory, or read from disk a layer at a time -
#    warp2/room/split_load.py). Its tag adapter (a LoRA taught to read and
#    write the Eye's tags, warp2/house/tag_lora.py) is put on when there is
#    one, and the runner says when that adapter has been written again since
#    it was loaded, so the house loads the newer one. An answer is the
#    model's own words for one prompt, greedy, as long as asked - asked to
#    answer without thinking first, and with any <think> block set aside
#    (BUILD_LOG 1486).
#  User intention (Andrew, 2026-11-09 19:05): "holds models like ollama ...
#    inside the warp ... add back in loras and training those new models".
#    (BUILD_LOG 1484.)
# ============================================================================
"""One language model, loaded to fit the room, with its tag adapter when there is one."""
from __future__ import annotations

import re
from pathlib import Path


# Intention (BUILD_LOG 1486): thinking a model writes before its answer is not its answer.
_THINKING = re.compile(r"(?s)<think>.*?(?:</think>|\Z)")


def chat_text(tokenizer, prompt: str) -> str:
    """The prompt as the model's own chat form, asked to answer without thinking first.

    Intention (BUILD_LOG 1486, measured 2026-11-09 21:23: qwen3-1.7b's answer began "<think>\nOkay, the user is
    asking" and its 8 tokens ran out before any answer): Ollama was asked with think off; the house asks the same
    way - the chat form's own switch (enable_thinking), which forms without one ignore. A tokenizer with no chat
    form gets the prompt as it is.
    """
    if not getattr(tokenizer, "chat_template", None):
        return str(prompt)
    return tokenizer.apply_chat_template([{"role": "user", "content": str(prompt)}], tokenize=False,
                                         add_generation_prompt=True, enable_thinking=False)


def without_thinking(said: str) -> str:
    """Intention: an answer with any <think> block set aside (closed, or cut off by the end of its room)."""
    return _THINKING.sub("", str(said)).strip()


def adapter_mark(folder) -> float:
    """Intention: when the adapter was last written; nought when there is none."""
    config = Path(folder) / "adapter_config.json"
    return config.stat().st_mtime if config.is_file() else 0.0


class TextRunner:
    """A language model and its tokenizer, loaded once, answering prompts."""

    def __init__(self, path, adapter="", offload_home=None, small_home=None) -> None:
        """Intention: the model folder, its adapter folder, where layers that fit nowhere wait on disk, and where the
        house's models are held small (BUILD_LOG 1562) - with none, the weight files are read."""
        self.path = Path(path)
        self.small_home = Path(small_home) if small_home else None
        self.adapter = Path(adapter) if adapter else None
        self.offload_home = Path(offload_home) if offload_home else self.path.parent / "warp2_offload"
        self.model = self.tokenizer = None
        self.where = ""
        self.adapter_at = 0.0
        self.small_use: dict = {}

    def need(self) -> int:
        """Intention: the bytes this model takes as it will be loaded."""
        if self.small_home is not None:
            from warp2.house.held_small.door import door_of
            door_of(self.small_home)
        from warp2.room.split_load import loaded_bytes
        return loaded_bytes(self.path, self._type())

    @staticmethod
    def _type() -> str:
        """Intention: half precision on a card, full off it."""
        import torch
        return "bfloat16" if torch.cuda.is_available() else "float32"

    def load(self) -> "TextRunner":
        """Intention: tokenizer, model placed to fit, adapter on when there is one."""
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from warp2.room.split_load import placement
        load_as = self._type()
        placed = placement(self.path, load_as, self.offload_home)
        # Intention: the HTTP caller must know which load failed, not guess from a device error.
        stage = "tokenizer"
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(str(self.path))
            stage = "base"
            # Intention (Andrew 2026-11-12 09:09, BUILD_LOG 1562): "stored and working from the dehydrated tag form" -
            # the base is filled from its small form; its weight files are read only when it has none that matches.
            from warp2.house.held_small.text_base import base_from_book
            # Intention (Andrew 2026-11-13 10:06, BUILD_LOG 1600c): "allowed the models to be used in a dehydrated
            # form" - a model that will carry no adapter has its layers run from the rows the book keeps them as,
            # where it keeps them so. With an adapter the layers stay whole: the adapter is put onto ordinary ones.
            has_adapter = self.adapter is not None and bool(adapter_mark(self.adapter))
            # Intention (BUILD_LOG 1605c): Andrew's design test (design/tests/test_andrews_design.py, BUILD_LOG 1562)
            # holds this ask in the words it was written in - the base asked of the book with the home of its small
            # form. 1600c had put `small=` into that one call, the test no longer found it, and the start gate runs
            # that test first: the warp would not have started. The ask stands as it was written again; a model that
            # will carry no adapter is the other branch, and that one is run from the rows the book keeps.
            if has_adapter:
                model = base_from_book(self.path, load_as, placed, self.small_home)
            else:
                model = base_from_book(self.path, load_as, placed, self.small_home, small=True)
            said = getattr(model, "small_use", None)
            self.small_use = dict(said) if isinstance(said, dict) else {}
            if model is None:
                model = AutoModelForCausalLM.from_pretrained(str(self.path), torch_dtype=getattr(torch, load_as),
                                                             low_cpu_mem_usage=True, **placed["kwargs"])
            self.where = placed["where"]
            if self.adapter is not None and adapter_mark(self.adapter):
                stage = "adapter"
                from peft import PeftModel
                from warp2.house.held_small.adapter_on import adapter_from_book
                # Intention (BUILD_LOG 1563): the adapter's weights from its small form; its file only when it has none.
                # Intention (BUILD_LOG 1572, measured in state/control/commands/out/chain_1825.txt): a model split
                # between the card and memory keeps its limits when its adapter is put on. Left to itself peft places
                # the whole model again by its own reckoning - it moved a split model wholly onto the card, and with
                # less room it asks for a disk folder nobody gave it ("device disk is invalid", the fault that
                # stopped the warp twice on 2026-11-12). Handed the same limits, the model stays where it was put.
                limits = {"max_memory": placed["kwargs"]["max_memory"]} if "max_memory" in placed["kwargs"] else {}
                with_adapter = adapter_from_book(model, self.adapter, self.small_home, **limits)
                model = with_adapter if with_adapter is not None else PeftModel.from_pretrained(
                    model, str(self.adapter), **limits)
                self.adapter_at = adapter_mark(self.adapter)
            stage = "evaluation"
            model.eval()
        except Exception as exc:  # fault: ok - add load context, then re-raise the original error and stack
            exc.add_note(f"house load: model={self.path.name}; stage={stage}; placement={placed['where']}")
            raise
        self.model = model
        return self

    def stale(self) -> bool:
        """Intention: the adapter on disk is newer than the one loaded."""
        return self.adapter is not None and adapter_mark(self.adapter) > self.adapter_at

    def answer(self, prompt: str, tokens: int) -> str:
        """Intention: the model's words for one prompt, at most `tokens` new tokens."""
        import torch
        inputs = self.tokenizer(chat_text(self.tokenizer, prompt), return_tensors="pt")
        device = next((p.device for p in self.model.parameters() if p.device.type != "meta"), torch.device("cpu"))
        # Intention: only what every language model takes - a tokenizer's other outputs (token_type_ids) are refused
        # by generate on some versions of transformers.
        inputs = {k: inputs[k].to(device) for k in ("input_ids", "attention_mask") if k in inputs}
        pad = self.tokenizer.pad_token_id if self.tokenizer.pad_token_id is not None else self.tokenizer.eos_token_id
        with torch.no_grad():
            out = self.model.generate(**inputs, max_new_tokens=max(1, int(tokens)), do_sample=False,
                                      pad_token_id=pad)
        return without_thinking(self.tokenizer.decode(out[0][inputs["input_ids"].shape[1]:],
                                                      skip_special_tokens=True))

    def close(self) -> None:
        """Intention: the model and tokenizer let go."""
        self.model = self.tokenizer = None
