# WARP2/warp2/house/shelf.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/shelf.py
#  Used by   : warp2/house/house.py (what can be loaded), warp2/house/tag_lora.py
#              (which models are taught tags), warp2/work/side/house_steps.py.
#  Uses      : models.json (entries with "how": "house"), warp2/models/roster.py
#              (read), warp2/record/kept_file.py; stdlib pathlib, re.
#  Description:
#    THE HOUSE'S SHELF: every model the roster puts in the house, with what
#    kind it is - "image" when its folder is a diffusers pipeline
#    (model_index.json), "reader" when it is a CLIP model (its config says
#    so; BUILD_LOG 1485), "text" otherwise - and where its tag adapter lives
#    (state/house/adapters/<name>/). A model switched off in the roster is
#    not on the shelf.
#  User intention (Andrew, 2026-11-09 19:05): "a system that holds models like
#    ollama and comfy could inside the warp". (BUILD_LOG 1484.)
# ============================================================================
"""The models the house can hold, from the roster, with their kind and their adapter's place."""
from __future__ import annotations

import re
from pathlib import Path

# Intention: how the roster names a model the house holds.
HOW = "house"


def safe(name: str) -> str:
    """Intention: a model's name as a folder name."""
    return re.sub(r"[^A-Za-z0-9._-]+", "_", str(name)).strip("_") or "model"


class Shelf:
    """The house's models, as the roster lists them."""

    def __init__(self, root, state, entries=None) -> None:
        """Intention: where the roster and the adapters are; a test hands in its own entries."""
        self.root, self.state = Path(root), Path(state)
        self._entries = entries

    def entries(self) -> list:
        """Intention: the switched-on house entries."""
        if self._entries is None:
            from warp2.models.roster import read
            listed = read(self.root)
        else:
            listed = self._entries
        return [e for e in listed if str(e.get("how") or "").lower() == HOW and e.get("enabled") is not False
                and e.get("name") and e.get("path")]

    def find(self, name: str) -> dict:
        """Intention: one model's entry with its kind and adapter folder; {} when it is not on the shelf."""
        for entry in self.entries():
            if str(entry["name"]) == str(name):
                return {**entry, "kind": self.kind(entry["path"]), "adapter": str(self.adapter(entry["name"]))}
        return {}

    def names(self, kind: str = "") -> list:
        """Intention: the names on the shelf, of one kind when asked."""
        return [e["name"] for e in self.entries() if not kind or self.kind(e["path"]) == kind]

    @staticmethod
    def kind(path) -> str:
        """Intention: "image" for a diffusers pipeline folder, "reader" for a CLIP model (BUILD_LOG 1485), "text" for
        anything else."""
        if (Path(path) / "model_index.json").is_file():
            return "image"
        from warp2.record.kept_file import UnreadableKept, read_kept
        try:
            config = read_kept(Path(path) / "config.json", {})
        except UnreadableKept:  # fault: ok - a config that cannot be read names no kind; the loader says why later
            config = {}
        return "reader" if isinstance(config, dict) and config.get("model_type") == "clip" else "text"

    def adapter(self, name: str) -> Path:
        """Intention: where this model's tag adapter is kept."""
        return self.state / "house" / "adapters" / safe(name)
