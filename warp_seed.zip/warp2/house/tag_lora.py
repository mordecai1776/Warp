# WARP2/warp2/house/tag_lora.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tag_lora.py
#  Used by   : warp2/work/side/house_steps.py (TagLoraStep, run in a fenced
#              child).
#  Uses      : warp2/house/{shelf,tag_lessons,text_runner}.py, warp2/room/split_load.py
#              (whether the model fits to be taught), warp2/train/lora.py
#              (carry_lora: the adapter carried on, or a new one),
#              warp2/train/finetune.py (LoRATrainer.train_epoch's learning rate,
#              the one the WARP's LoRA rounds use), warp2/record/kept_file.py;
#              torch, transformers, peft.
#  Description:
#    A LITTLE LEARNING IN THE EYE'S TAGS, KEPT ONLY WHEN IT HELPS. One house
#    language model is taught the tag lessons it has not been taught yet (half
#    of all lessons; the other half is held back), once each, on its LoRA
#    adapter carried on from the last turn. The held-back lessons the same
#    size as what was taught are scored before and after; the adapter is kept
#    only when that score did not get worse. The bulk of the learning stays
#    with the Eye: the model only learns the Eye's tags, and only what is new
#    since the last turn. A model too big to be taught whole in the room it
#    was given (it would need to be read from disk) is not taught, and says
#    so.
#  User intention (Andrew, 2026-11-09 19:05): "add back in loras and training
#    those new models to give adaptation to at least run from compressed tags
#    like the eye as well as some limited advancement but keep the bulk on the
#    eye still." (BUILD_LOG 1484.)
# ============================================================================
"""One house language model taught the new tag lessons on its LoRA adapter, kept only when held-back lessons agree."""
from __future__ import annotations

import inspect
from pathlib import Path


def learning_rate() -> float:
    """Intention: the rate the WARP's own LoRA rounds learn at - one source, not a second number."""
    from warp2.train.finetune import LoRATrainer
    return float(inspect.signature(LoRATrainer.train_epoch).parameters["learning_rate"].default)


class TagLora:
    """Teaching one model the tag lessons it has not had."""

    def __init__(self, root, state, entry: dict, lessons=None) -> None:
        """Intention: the model's roster entry (with its adapter folder) and the lessons to draw from."""
        from warp2.house.shelf import Shelf
        from warp2.house.tag_lessons import TagLessons
        self.root, self.state = Path(root), Path(state)
        self.entry = entry
        self.adapter = Shelf(root, state).adapter(entry["name"])
        self.lessons = lessons or TagLessons(state)

    def taught(self) -> set:
        """Intention: the keys of the lessons already taught to this adapter."""
        from warp2.record.kept_file import UnreadableKept, read_kept
        try:
            return set(read_kept(self.adapter / "taught.json", []))
        except UnreadableKept:  # fault: ok - an unreadable record teaches every lesson again; nothing is lost
            return set()

    def teach(self) -> dict:
        """Intention: the new lessons taught once each; the adapter kept only when the held-back lessons did not get
        worse. What was taught, the scores and whether it was kept."""
        from warp2.house.tag_lessons import TagLessons
        learn, held = TagLessons.halves(self.lessons.lessons())
        done = self.taught()
        new = [lesson for lesson in learn if lesson["key"] not in done]
        if not new:
            return {"model": self.entry["name"], "did": "nothing", "why": "no new tag lessons since the last turn"}
        from warp2.room.split_load import placement
        placed = placement(self.entry["path"], self._type(), Path(self.entry["path"]).parent / "warp2_offload")
        if placed["where"] == "split to disk":
            return {"model": self.entry["name"], "did": "nothing",
                    "why": f"too big to teach whole in this room ({placed['size'] >> 20} MB)"}
        model, tokenizer = self._load(placed["where"])
        check = held[:len(new)]
        before = self._score(model, tokenizer, check)
        self._learn(model, tokenizer, new)
        after = self._score(model, tokenizer, check)
        kept = after <= before
        if kept:
            from warp2.record.kept_file import write_kept
            model.save_pretrained(str(self.adapter))
            write_kept(self.adapter / "taught.json", sorted(done | {lesson["key"] for lesson in new}))
        return {"model": self.entry["name"], "did": "taught", "taught": len(new), "checked": len(check),
                "before": round(before, 4), "after": round(after, 4), "kept": kept, "where": placed["where"]}

    @staticmethod
    def _type() -> str:
        """Intention: half precision on a card, full off it."""
        import torch
        return "bfloat16" if torch.cuda.is_available() else "float32"

    def _load(self, where: str):
        """Intention: the base model on the card when it fits there, else in memory, with its adapter carried on."""
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from warp2.train.lora import carry_lora
        tokenizer = AutoTokenizer.from_pretrained(self.entry["path"])
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        model = AutoModelForCausalLM.from_pretrained(self.entry["path"], torch_dtype=getattr(torch, self._type()))
        if where == "card":
            model = model.to("cuda")
        carried = carry_lora(model, str(self.adapter) if (self.adapter / "adapter_config.json").is_file() else "")
        return carried["model"], tokenizer

    @staticmethod
    def _pair(tokenizer, lesson: dict):
        """Intention: (ids, labels) for one lesson - only the answer's tokens are learned."""
        # Intention (BUILD_LOG 1486): taught in the same form it is asked in (warp2/house/text_runner.py chat_text).
        from warp2.house.text_runner import chat_text
        asked = chat_text(tokenizer, lesson["prompt"])
        if not getattr(tokenizer, "chat_template", None):
            asked += "\n"
        head = tokenizer(asked, add_special_tokens=False)["input_ids"]
        tail = tokenizer(lesson["answer"] + (tokenizer.eos_token or ""), add_special_tokens=False)["input_ids"]
        return head + tail, [-100] * len(head) + tail

    def _loss(self, model, tokenizer, lesson: dict):
        """Intention: the model's loss on one lesson's answer."""
        import torch
        ids, labels = self._pair(tokenizer, lesson)
        device = next(model.parameters()).device
        return model(input_ids=torch.tensor([ids], device=device), labels=torch.tensor([labels], device=device)).loss

    def _score(self, model, tokenizer, lessons: list) -> float:
        """Intention: the mean loss on these lessons, with nothing learned."""
        import torch
        if not lessons:
            return 0.0
        model.eval()
        with torch.no_grad():
            total = sum(float(self._loss(model, tokenizer, lesson)) for lesson in lessons)
        return total / len(lessons)

    def _learn(self, model, tokenizer, lessons: list) -> None:
        """Intention: each lesson once, one at a time, on the adapter's own weights only."""
        import torch
        model.train()
        trainable = [p for p in model.parameters() if p.requires_grad]
        optimiser = torch.optim.AdamW(trainable, lr=learning_rate())
        for lesson in lessons:
            optimiser.zero_grad()
            self._loss(model, tokenizer, lesson).backward()
            optimiser.step()
        model.eval()
