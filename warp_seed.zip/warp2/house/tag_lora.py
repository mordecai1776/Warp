# WARP2/warp2/house/tag_lora.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tag_lora.py
#  Used by   : warp2/work/side/house_steps.py (TagLoraStep, run in a fenced
#              child).
#  Uses      : warp2/house/{shelf,tag_lessons,text_runner}.py, warp2/room/split_load.py
#              (whether the model fits to be taught), warp2/train/lora.py
#              (carry_lora: the adapter carried on, or a new one),
#              warp2/train/finetune.py (LoRATrainer.train_epoch's learning rate,
#              the one the WARP's LoRA rounds use), warp2/record/kept_file.py,
#              projects/behemoth_eye/eye/turn_clock.py (the turn it runs
#              inside); torch, transformers, peft.
#  Description:
#    A LITTLE LEARNING IN THE EYE'S TAGS, KEPT ONLY WHEN IT HELPS. One house
#    language model is taught the tag lessons it has not been taught yet (half
#    of all lessons; the other half is held back), once each, on its LoRA
#    adapter carried on from the last turn. The held-back lessons the same
#    size as what was taught are scored before and after; the adapter is kept
#    only when that score did not get worse. The bulk of the learning stays
#    with the Eye: the model only learns the Eye's tags, and only what is new
#    since the last turn. A model too big to be taught whole in the room it
#    was given (it would need to be read from disk) is not taught, and says
#    so. A turn teaches only as many new lessons as fit in it, at this
#    adapter's own measured cost (kept in turn_cost.json); the rest come
#    round next turn (BUILD_LOG 1513). Before the model is loaded, which
#    model and which lessons this turn is about to teach are written to the
#    adapter's turns.jsonl; the end of the turn writes a second line. A turn
#    cut off (machine down, child killed) leaves a "began" line with no
#    "ended" line, so it is known without a receipt (BUILD_LOG 1514). The
#    "began" line says the seconds the turn had left; the "ended" line the
#    seconds it ran and whether its time was up (BUILD_LOG 1518).
#  User intention (Andrew, 2026-11-09 19:05): "add back in loras and training
#    those new models to give adaptation to at least run from compressed tags
#    like the eye as well as some limited advancement but keep the bulk on the
#    eye still." (BUILD_LOG 1484.)
# ============================================================================
"""One house language model taught the new tag lessons on its LoRA adapter, kept only when held-back lessons agree."""
from __future__ import annotations

import inspect
import time
from pathlib import Path


def learning_rate() -> float:
    """Intention: the rate the WARP's own LoRA rounds learn at - one source, not a second number."""
    from warp2.train.finetune import LoRATrainer
    return float(inspect.signature(LoRATrainer.train_epoch).parameters["learning_rate"].default)


class TurnCost:
    """What one lesson costs this adapter, measured, and kept beside it for the next turn."""

    # Intention: with nothing measured yet, a lesson taught is taken to cost what three scorings do (a forward pass and
    # its backward pass); replaced by the measured seconds once one turn has taught.
    TEACH_PER_SCORE = 3.0

    def __init__(self, adapter) -> None:
        """Intention: the adapter's folder; its last turn's measure read from turn_cost.json, if any."""
        from warp2.record.kept_file import UnreadableKept, read_kept
        self.file = Path(adapter) / "turn_cost.json"
        try:
            kept = read_kept(self.file, {}) or {}
        except UnreadableKept:  # fault: ok - an unreadable measure is measured again this turn; nothing is lost
            kept = {}
        self.score_s = float(kept.get("score_seconds", 0.0))
        self.teach_s = float(kept.get("teach_seconds", 0.0))
        self._scores: list = []

    def scored(self, seconds: float) -> None:
        """Intention: one lesson scored took this long; this turn's own scorings are the measure."""
        self._scores.append(float(seconds))
        self.score_s = sum(self._scores) / len(self._scores)

    def needs(self, count: int) -> float:
        """Intention: seconds to teach `count` lessons and score them once more."""
        teach = self.teach_s if self.teach_s > 0.0 else self.score_s * self.TEACH_PER_SCORE
        return count * (teach + self.score_s)

    def learned(self, count: int, seconds: float) -> None:
        """Intention: `count` lessons were taught in `seconds`; kept for the next turn."""
        if count <= 0:
            return
        from warp2.record.kept_file import write_kept
        self.teach_s = float(seconds) / count
        self.file.parent.mkdir(parents=True, exist_ok=True)
        write_kept(self.file, {"score_seconds": self.score_s, "teach_seconds": self.teach_s})


class TurnLog:
    """Each teaching turn named before it starts and closed when it ends, in the adapter's turns.jsonl."""

    # Intention (Codex-423 via Muse-1619, BUILD_LOG 1514): on 2026-11-11 a turn ran 2 h 25 min and was lost in a
    # reboot with nothing saying which model and lessons it held. Lines are only added, never rewritten (keep
    # everything), so a cut-off turn stays readable as a "began" with no matching "ended".

    def __init__(self, adapter) -> None:
        """Intention: the adapter's folder; its log beside the adapter."""
        self.file = Path(adapter) / "turns.jsonl"
        self.started = time.monotonic()

    def write(self, line: dict) -> None:
        """Intention: one line added and flushed to disk at once, so a cut straight after still leaves it."""
        import json
        import os
        self.file.parent.mkdir(parents=True, exist_ok=True)
        with self.file.open("a", encoding="utf-8") as out:
            out.write(json.dumps(line) + "\n")
            out.flush()
            os.fsync(out.fileno())

    def began(self, entry: dict, adapter, lessons: list, held: int, where: str) -> str:
        """Intention: the model, its path, the adapter and the lesson keys offered, written before loading; the
        turn's id is returned so the end line can name it."""
        from datetime import datetime, timezone
        from projects.behemoth_eye.eye.turn_clock import current
        # Intention (Codex-424 via Muse-1626, BUILD_LOG 1518): the seconds this turn had left as it began, on the
        # turn's own clock; null with no turn open (no budget is never written as a number).
        clock = current()
        left = None if clock is None else clock.left()
        self.started = time.monotonic()
        at = datetime.now(timezone.utc).isoformat()
        self.write({"turn": at, "state": "began", "model": entry["name"], "path": str(entry["path"]),
                    "adapter": str(adapter), "where": where, "lessons": [lesson["key"] for lesson in lessons],
                    "held": int(held), "remaining_seconds_at_begin": None if left is None else round(left, 3)})
        return at

    def ended(self, turn: str, result: dict) -> None:
        """Intention: the same turn closed with what came of it."""
        from datetime import datetime, timezone
        from projects.behemoth_eye.eye.turn_clock import over
        # Intention (BUILD_LOG 1518): on the same clock as "began" - how long the turn ran, and whether its time was
        # up, so a turn that stopped on its clock reads apart from one that finished early.
        self.write({"turn": turn, "state": "ended", "at": datetime.now(timezone.utc).isoformat(),
                    "elapsed_seconds": round(time.monotonic() - self.started, 3), "clock_over": bool(over(None)),
                    **{k: v for k, v in result.items() if k != "adapter"}})


class TagLora:
    """Teaching one model the tag lessons it has not had."""

    def __init__(self, root, state, entry: dict, lessons=None) -> None:
        """Intention: the model's roster entry (with its adapter folder) and the lessons to draw from."""
        from warp2.house.shelf import Shelf
        from warp2.house.tag_lessons import TagLessons
        self.root, self.state = Path(root), Path(state)
        self.entry = entry
        self.adapter = Shelf(root, state).adapter(entry["name"])
        self.lessons = lessons or TagLessons(state)

    def taught(self) -> set:
        """Intention: the keys of the lessons already taught to this adapter."""
        from warp2.record.kept_file import UnreadableKept, read_kept
        try:
            return set(read_kept(self.adapter / "taught.json", []))
        except UnreadableKept:  # fault: ok - an unreadable record teaches every lesson again; nothing is lost
            return set()

    def teach(self) -> dict:
        """Intention: the new lessons taught once each; the adapter kept only when the held-back lessons did not get
        worse. What was taught, the scores and whether it was kept."""
        from warp2.house.tag_lessons import TagLessons
        learn, held = TagLessons.halves(self.lessons.lessons())
        done = self.taught()
        new = [lesson for lesson in learn if lesson["key"] not in done]
        if not new:
            return {"model": self.entry["name"], "did": "nothing", "why": "no new tag lessons since the last turn"}
        from warp2.room.split_load import placement
        placed = placement(self.entry["path"], self._type(), Path(self.entry["path"]).parent / "warp2_offload")
        if placed["where"] == "split to disk":
            return {"model": self.entry["name"], "did": "nothing",
                    "why": f"too big to teach whole in this room ({placed['size'] >> 20} MB)"}
        log = TurnLog(self.adapter)
        turn = log.began(self.entry, self.adapter, new, len(held), placed["where"])
        model, tokenizer = self._load(placed["where"])
        # Intention (Andrew, 2026-11-09 22:53: "All work on the warp should use a set amount of compute and be built
        # to do so"; 2026-11-10 17:10: "Put it in everywhere"; BUILD_LOG 1513): A TURN TEACHES ONLY WHAT FITS IN IT.
        # On 2026-11-11 one turn was handed every new lesson at once and ran 2 h 25 min until the machine went down,
        # keeping nothing. Now each lesson's "before" is scored one by one, and the scoring stops when what is left of
        # the turn holds only what teaching and re-scoring those lessons will take, at this adapter's own measured
        # seconds (TurnCost). The lessons not reached keep their place and come round next turn. No turn open: all.
        cost = TurnCost(self.adapter)
        asked = held[:len(new)]
        check, before = self._score_within(model, tokenizer, asked, cost)
        if len(check) < len(asked):
            new = new[:len(check)]
        began = time.monotonic()
        new = new[:self._learn(model, tokenizer, new)]
        cost.learned(len(new), time.monotonic() - began)
        before_mean = sum(before[:len(check)]) / len(check) if check else 0.0
        after = self._score(model, tokenizer, check)
        kept = after <= before_mean
        if kept:
            from warp2.record.kept_file import write_kept
            model.save_pretrained(str(self.adapter))
            write_kept(self.adapter / "taught.json", sorted(done | {lesson["key"] for lesson in new}))
        result = {"model": self.entry["name"], "did": "taught", "taught": len(new), "checked": len(check),
                  "left": len([lesson for lesson in learn if lesson["key"] not in done]) - len(new),
                  "before": round(before_mean, 4), "after": round(after, 4), "kept": kept, "where": placed["where"],
                  "adapter": str(self.adapter)}
        log.ended(turn, result)
        return result

    def _score_within(self, model, tokenizer, lessons: list, cost: "TurnCost") -> tuple:
        """Intention: (the lessons scored, each one's loss) - scored one by one with nothing learned, stopping while
        the turn still has what teaching and re-scoring the ones scored will take. At least one is always scored."""
        import torch
        from projects.behemoth_eye.eye.turn_clock import current
        clock = current()
        model.eval()
        scored, losses = [], []
        with torch.no_grad():
            for lesson in lessons:
                began = time.monotonic()
                losses.append(float(self._loss(model, tokenizer, lesson)))
                scored.append(lesson)
                cost.scored(time.monotonic() - began)
                left = clock.left() if clock is not None else None
                if left is not None and cost.needs(len(scored) + 1) + cost.score_s >= left:
                    break
        return scored, losses

    @staticmethod
    def _type() -> str:
        """Intention: half precision on a card, full off it."""
        import torch
        return "bfloat16" if torch.cuda.is_available() else "float32"

    def _load(self, where: str):
        """Intention: the base model on the card when it fits there, else in memory, with its adapter carried on."""
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from warp2.train.lora import carry_lora
        tokenizer = AutoTokenizer.from_pretrained(self.entry["path"])
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        model = AutoModelForCausalLM.from_pretrained(self.entry["path"], torch_dtype=getattr(torch, self._type()))
        if where == "card":
            model = model.to("cuda")
        carried = carry_lora(model, str(self.adapter) if (self.adapter / "adapter_config.json").is_file() else "")
        return carried["model"], tokenizer

    @staticmethod
    def _pair(tokenizer, lesson: dict):
        """Intention: (ids, labels) for one lesson - only the answer's tokens are learned."""
        # Intention (BUILD_LOG 1486): taught in the same form it is asked in (warp2/house/text_runner.py chat_text).
        from warp2.house.text_runner import chat_text
        asked = chat_text(tokenizer, lesson["prompt"])
        if not getattr(tokenizer, "chat_template", None):
            asked += "\n"
        head = tokenizer(asked, add_special_tokens=False)["input_ids"]
        tail = tokenizer(lesson["answer"] + (tokenizer.eos_token or ""), add_special_tokens=False)["input_ids"]
        return head + tail, [-100] * len(head) + tail

    def _loss(self, model, tokenizer, lesson: dict):
        """Intention: the model's loss on one lesson's answer."""
        import torch
        ids, labels = self._pair(tokenizer, lesson)
        device = next(model.parameters()).device
        return model(input_ids=torch.tensor([ids], device=device), labels=torch.tensor([labels], device=device)).loss

    def _score(self, model, tokenizer, lessons: list) -> float:
        """Intention: the mean loss on these lessons, with nothing learned."""
        import torch
        if not lessons:
            return 0.0
        model.eval()
        with torch.no_grad():
            total = sum(float(self._loss(model, tokenizer, lesson)) for lesson in lessons)
        return total / len(lessons)

    def _learn(self, model, tokenizer, lessons: list) -> int:
        """Intention: each lesson once, one at a time, on the adapter's own weights only; how many were taught. Stops
        when its turn is over (the first is always taught), so a wrong measure never carries a turn far past its end."""
        import torch
        from projects.behemoth_eye.eye.turn_clock import current, over
        model.train()
        trainable = [p for p in model.parameters() if p.requires_grad]
        optimiser = torch.optim.AdamW(trainable, lr=learning_rate())
        taught = 0
        for lesson in lessons:
            if taught and over(current()):
                break
            optimiser.zero_grad()
            self._loss(model, tokenizer, lesson).backward()
            optimiser.step()
            taught += 1
        model.eval()
        return taught
