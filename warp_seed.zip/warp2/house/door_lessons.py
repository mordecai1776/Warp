# WARP3/warp2/house/door_lessons.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/house/door_lessons.py
#  Used by   : warp2/house/tag_lessons.py (the house models' lessons).
#  Uses      : warp2/train/outputs.py (every answer any model gave, kept with
#              what it was asked), warp2/models/tag_door.py (as_answer_tags),
#              warp2/record/evidence.py, warp2/store/store.py (store_home:
#              where the kept bytes are).
#  Description:
#    THE LORAS TEACH THE MODELS TO WORK IN DEHYDRATED TAGS. Every model the
#    warp asks is asked in dehydrated tags and only its tags are taken
#    (warp2/models/tag_door.py), and each exchange is kept as it went (kind
#    "door"). Each becomes a lesson: what the model was given (tags) in, and
#    the answer in the tag form it should take out - the model's own answer
#    when it was tags, its answer put into tags when it was not. The newest
#    exchanges are taken, so each turn's lessons are what the warp has most
#    lately asked. An answer that says nothing - a model's inside code
#    ("#hidden_100"), one bare <token>, or a line of the prompt given back - is
#    not a lesson (2026-11-20): taught, it taught the models to say codes.
#  User intention (Andrew, 2026-11-15 13:59): "That is the reason why the
#    [LoRAs] were put back in. It was not to make the models better. It was to
#    make the models work with the dehydrated tag system." (2026-11-09 19:05):
#    "add back in loras and training those new models to give adaptation to at
#    least run from compressed tags".
# ============================================================================
"""Lessons from every exchange the warp had with a model: tags in, tags out."""
from __future__ import annotations

import json
import re
from pathlib import Path

# Intention: how far back from the end of the kept answers the lessons are read - the newest exchanges, a tail of
# the record (it grows for ever, and the tag LoRA takes only what is new each turn).
TAIL_BYTES = 4 * 2**20

# Intention (2026-11-20, Claude hourly): one bare angle-bracket token, like "<wt:709033>" or "<tags>".
_BARE_TOKEN = re.compile(r"^<[^<>\s]*>$")


def says_nothing(prompt: str, answer: str) -> bool:
    """True when an answer that was not tags says nothing worth teaching.

    Intention (2026-11-20, Claude hourly; measured in state/training/outputs.jsonl): of the 451 door exchanges in
    the tail the LoRAs teach from, 118 answers were only inside codes ('#"', '#', '#decide:_gate_accepts:_accept',
    '#hidden_100'), and more were one bare "<wt:709033>" or a line of the prompt said back. Each was put into tags
    and taught as the right answer, so the models learned to answer every question with a code - and the 3 wise
    men and the sub-concept guesses heard nothing. Such an answer is passed over; real words are still taught.
    """
    text = str(answer or "").strip()
    if not text:
        return True
    if all(piece.startswith("#") for piece in text.split()):
        return True
    if _BARE_TOKEN.match(text):
        return True
    # Intention: the prompt said back - one of its lines as it was, or one of its [say "..."] lines' words.
    prompt = str(prompt or "")
    return f'"{text}"' in prompt or any(text == line.strip() for line in prompt.split("\n") if line.strip())


def _tail_lines(path: Path) -> list:
    """Intention: the whole lines of the last TAIL_BYTES of a file."""
    try:
        size = path.stat().st_size
    except OSError:  # fault: ok no answers kept yet: no lessons
        return []
    with open(path, "rb") as handle:
        handle.seek(max(0, size - TAIL_BYTES))
        block = handle.read()
    lines = block.split(b"\n")
    return [line for line in (lines[1:] if size > TAIL_BYTES else lines) if line.strip()]


class DoorLessons:
    """Intention: the lessons the kept exchanges give."""

    def __init__(self, state) -> None:
        """Intention: the state folder whose kept answers (training/outputs.jsonl) are read."""
        self.state = Path(state)

    def lessons(self) -> list:
        """Intention: [{key, prompt, answer, kind}] - one for each kept exchange with something asked and answered."""
        from warp2.house.tag_lessons import key
        from warp2.models.tag_door import as_answer_tags
        from warp2.record.evidence import Evidence
        from warp2.store.store import store_home
        evidence = Evidence(store_home(self.state) / "evidence")
        out, seen = [], set()
        for line in _tail_lines(self.state / "training" / "outputs.jsonl"):
            try:
                row = json.loads(line)
            except ValueError:  # fault: ok a torn line at the cut is not a lesson
                continue
            if row.get("e") != "kept" or row.get("kind") != "door" or not row.get("prompt") or not row.get("answer"):
                continue
            try:
                asked, said = evidence.text(row["prompt"]), evidence.text(row["answer"])
            except (OSError, KeyError, ValueError):  # fault: ok an answer whose bytes are gone is not a lesson
                continue
            if key(asked) in seen:
                continue
            if row.get("about") != "taken" and says_nothing(asked, said):
                # Intention: a code, a bare token or the prompt said back is not taught (says_nothing).
                continue
            seen.add(key(asked))
            out.append({"key": key(asked), "prompt": asked, "answer": as_answer_tags(said),
                        "kind": "tags to tags (door)"})
        return out
