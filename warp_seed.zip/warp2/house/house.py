# WARP2/warp2/house/house.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/house.py
#  Used by   : warp2/house/server.py (the house's one process answers through it).
#  Uses      : warp2/house/{shelf,keeper,text_runner,image_runner,
#              reader_runner}.py, warp2/house/held_small/door.py.
#  Description:
#    THE HOUSE ITSELF, without the network: a model asked for by name is
#    loaded if it is not held (room made first, the oldest put down), a
#    language model whose tag adapter was written again since is loaded
#    again, and then it answers (text), draws (a picture saved under
#    state/house/pictures/<model>/) or reads a picture (BUILD_LOG 1485). What is held, what is on the shelf, and
#    putting models down are said the way Ollama says them.
#  User intention (Andrew, 2026-11-09 19:05): "a system that holds models like
#    ollama and comfy could inside the warp". (BUILD_LOG 1484.)
# ============================================================================
"""Models held by name: loaded when asked, answering and drawing, put down when room is needed."""
from __future__ import annotations

import time
from pathlib import Path


class House:
    """The shelf, what is held, and the work asked of them."""

    def __init__(self, root, state, shelf=None, keeper=None) -> None:
        """Intention: the roster's house models and the keeper of what is loaded."""
        from warp2.house.keeper import Keeper
        from warp2.house.shelf import Shelf
        self.root, self.state = Path(root), Path(state)
        self.shelf = shelf or Shelf(root, state)
        self.keeper = keeper or Keeper()

    def runner(self, name: str):
        """Intention: the named model, loaded to fit if it is not held; KeyError when it is not on the shelf."""
        entry = self.shelf.find(name)
        if not entry:
            raise KeyError(f"{name} is not in the house (models.json, \"how\": \"house\")")
        held = self.keeper.get(name)
        if held is not None and getattr(held, "stale", lambda: False)():
            self.keeper.put_down(name)
            held = None
        if held is not None:
            return held
        # Intention (Andrew 2026-11-12 09:09, BUILD_LOG 1562 and BUILD_LOG 1563): every model the house loads is handed the home of
        # the small forms, and loads from there.
        from warp2.house.held_small.door import small_home
        home = small_home(self.state)
        if entry["kind"] == "image":
            from warp2.house.image_runner import ImageRunner
            made = ImageRunner(entry["path"], small_home=home)
        elif entry["kind"] == "reader":
            from warp2.house.reader_runner import ReaderRunner
            made = ReaderRunner(entry["path"], small_home=home)
        else:
            from warp2.house.text_runner import TextRunner
            made = TextRunner(entry["path"], entry["adapter"], small_home=home)
        return self.keeper.load(name, made.need(), made.load)

    def chat(self, name: str, prompt: str, tokens: int = 0) -> dict:
        """Intention: a language model's answer, and where it ran."""
        entry = self.shelf.find(name)
        runner = self.runner(name)
        said = runner.answer(prompt, int(tokens or entry.get("max_tokens") or 0) or 1)
        return {"model": name, "content": said, "where": runner.where}

    def draw(self, name: str, prompt: str, seed: int = 0, steps: int = 0, width: int = 0, height: int = 0) -> dict:
        """Intention: a picture model's picture for the prompt, saved under state/house/pictures/<model>/."""
        from warp2.house.shelf import safe
        runner = self.runner(name)
        out = self.state / "house" / "pictures" / safe(name) / f"{time.strftime('%Y%m%d_%H%M%S')}_{int(seed)}.png"
        return {"model": name, **runner.draw(prompt, out, seed, steps, width, height)}

    def read(self, name: str, image: str, subject: str, reference: str = "") -> dict:
        """Intention (BUILD_LOG 1485): a picture reader's chance that the picture shows the subject."""
        return {"model": name, **self.runner(name).read(image, subject, reference)}

    def ps(self) -> dict:
        """Intention: what is held, as Ollama's /api/ps says it."""
        return {"models": [{"name": r["name"], "size": r["bytes"], "idle_seconds": r["idle_seconds"]}
                           for r in self.keeper.listing()]}

    def tags(self) -> dict:
        """Intention: what is on the shelf, as Ollama's /api/tags says it."""
        return {"models": [{"name": n, "kind": self.shelf.kind(self.shelf.find(n)["path"])} for n in self.shelf.names()]}

    def give_back(self) -> list:
        """Intention (BUILD_LOG 1487): what the keeper put down because the machine had no room left."""
        return self.keeper.give_back()

    def put_down(self, name: str = "") -> dict:
        """Intention: one model put down, or every one when no name is given."""
        names = [name] if name else [r["name"] for r in self.keeper.listing()]
        return {"put_down": [self.keeper.put_down(n) for n in names if n in self.keeper.held]}
