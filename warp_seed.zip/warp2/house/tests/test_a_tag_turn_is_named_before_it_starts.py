# WARP2/warp2/house/tests/test_a_tag_turn_is_named_before_it_starts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_a_tag_turn_is_named_before_it_starts.py
#  Used by   : pytest (run_tests.py), CHECK_FIXES.bat.
#  Uses      : warp2/house/tag_lora.py; torch (a one-weight stand-in model,
#              so no real model is needed).
#  Description:
#    A house model's tag-lesson turn writes which model and which lessons it
#    is about to teach BEFORE the model is loaded. A turn cut off part way
#    (here: teaching raises, as a killed child or a reboot would end it)
#    leaves that "began" line with no "ended" line; a turn that finishes
#    writes both, under the same turn id.
#  User intention (Andrew, 2026-11-09 22:53): "All work on the warp should
#    use a set amount of compute and be built to do so." Codex-423 via
#    Muse-1619: a cut-off candidate must be known without a receipt.
#    BUILD_LOG 1514.
# ============================================================================
"""A tag turn is named before it starts."""
from __future__ import annotations

import json
import sys
import types

import pytest

torch = pytest.importorskip("torch")

from warp2.house import tag_lora  # noqa: E402
from warp2.house.tag_lora import TagLora  # noqa: E402


class _Lessons:
    """Intention: ten tag lessons (five to learn, five held back)."""

    def lessons(self) -> list:
        """Intention: keys in order, as TagLessons gives them."""
        return [{"key": f"k{n:03d}", "prompt": f"p{n}", "answer": f"a{n}", "kind": "tags to tags"} for n in range(10)]


class _Model(torch.nn.Module):
    """Intention: one weight; a lesson's loss is its distance from 1."""

    def __init__(self) -> None:
        """Intention: the weight starts at nought."""
        super().__init__()
        self.weight = torch.nn.Parameter(torch.zeros(1))

    def save_pretrained(self, folder) -> None:
        """Intention: the adapter written as a real one is."""
        from pathlib import Path
        Path(folder).mkdir(parents=True, exist_ok=True)
        (Path(folder) / "adapter_config.json").write_text("{}", encoding="utf-8")


@pytest.fixture
def lora(tmp_path, monkeypatch):
    """Intention: a TagLora over the stand-in model, placed in memory; the adapter folder."""
    fake = types.ModuleType("warp2.room.split_load")
    fake.placement = lambda path, dtype, offload: {"where": "memory", "size": 0}
    monkeypatch.setitem(sys.modules, "warp2.room.split_load", fake)
    monkeypatch.setattr(TagLora, "_load", lambda self, where: (_Model(), None))
    monkeypatch.setattr(TagLora, "_loss", lambda self, model, tokenizer, lesson: ((model.weight - 1.0) ** 2).sum())
    monkeypatch.setattr(TagLora, "_type", staticmethod(lambda: "float32"))
    monkeypatch.setattr(tag_lora, "learning_rate", lambda: 0.1)
    entry = {"name": "tiny", "path": str(tmp_path / "model")}
    return (lambda: TagLora(tmp_path, tmp_path / "state", entry, lessons=_Lessons()),
            tmp_path / "state" / "house" / "adapters" / "tiny")


def _lines(adapter) -> list:
    """Intention: every line of the adapter's turn log."""
    return [json.loads(line) for line in (adapter / "turns.jsonl").read_text(encoding="utf-8").splitlines()]


def test_a_cut_off_turn_leaves_its_model_and_lessons_named(lora, monkeypatch):
    """Intention: teaching dies part way; the log still names the model, path and lessons, with no end line."""
    make, adapter = lora

    def cut(self, model, tokenizer, lessons):
        """Intention: the machine going down mid-lesson."""
        raise KeyboardInterrupt("cut off")

    monkeypatch.setattr(TagLora, "_learn", cut)
    with pytest.raises(KeyboardInterrupt):
        make().teach()
    lines = _lines(adapter)
    assert [line["state"] for line in lines] == ["began"]
    from warp2.house.tag_lessons import TagLessons
    learn, _held = TagLessons.halves(_Lessons().lessons())
    assert lines[0]["model"] == "tiny" and lines[0]["lessons"] == [lesson["key"] for lesson in learn]
    assert lines[0]["held"] == 5 and lines[0]["path"].endswith("model")


def test_a_finished_turn_is_closed_under_the_same_id_and_kept(lora):
    """Intention: a whole turn writes began then ended, same id; the next turn adds lines, never rewrites them."""
    make, adapter = lora
    first = make().teach()
    assert first["did"] == "taught"
    lines = _lines(adapter)
    assert [line["state"] for line in lines] == ["began", "ended"]
    assert lines[0]["turn"] == lines[1]["turn"] and lines[1]["taught"] == first["taught"]
    assert make().teach()["did"] == "nothing"
    assert len(_lines(adapter)) == 2
