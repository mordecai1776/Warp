# WARP2/warp2/house/tests/test_the_house_holds_models_inside_the_warp.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_the_house_holds_models_inside_the_warp.py
#  Used by   : pytest.
#  Uses      : warp2/house/{shelf,keeper,house,server,client,image_runner,
#              text_runner,tag_lessons,tag_lora,fetch_model}.py,
#              warp2/work/side/house_steps.py, warp2/models/roster.py;
#              tiny models made here from configs (nothing downloaded).
#  Description:
#    The house holds the WARP's own models, like Ollama and ComfyUI:
#      - the shelf knows a language model from a picture model;
#      - the keeper puts down the model used longest ago when room is needed;
#      - a tiny language model answers through the house, and over HTTP the
#        way Ollama is asked; a tiny picture model draws a picture;
#      - a house that cannot start says why;
#      - the Eye's mixes and ties become tag lessons both ways, half held back;
#      - a model learns the new lessons once, on its adapter, kept only when
#        the held-back lessons did not get worse, and the house loads the new
#        adapter;
#      - a model is fetched only with an open licence, with its record;
#      - the roster asks a "house" model through the house.
#  User intention (Andrew, 2026-11-09 19:05): "holds models like ollama and comfy
#    could inside the warp ... add back in loras and training those new models
#    ... run from compressed tags like the eye ... keep the bulk on the eye."
#    (BUILD_LOG 1484.)
# ============================================================================
from __future__ import annotations

import json
import threading
import types
from pathlib import Path

import pytest

transformers = pytest.importorskip("transformers")
pytest.importorskip("peft")

MB = 2 ** 20


def _tiny_text(folder: Path) -> Path:
    """Intention: a tiny llama with a word tokenizer, saved as a Hugging Face folder."""
    from tokenizers import Tokenizer, models, pre_tokenizers
    from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast
    words = ["<pad>", "<eos>", "<unk>", "tags:", "->parts", "->whole", "~?", "#cat", "#paw", "#fur", "#dog",
             "Name", "the", "parts", "of", "cat", "as", "tags.", "Say", "in", "words:", "is", "made", "paw,", "fur.",
             "hello", "\n"]
    raw = Tokenizer(models.WordLevel({w: i for i, w in enumerate(words)}, unk_token="<unk>"))
    raw.pre_tokenizer = pre_tokenizers.WhitespaceSplit()
    tok = PreTrainedTokenizerFast(tokenizer_object=raw, pad_token="<pad>", eos_token="<eos>", unk_token="<unk>")
    config = LlamaConfig(vocab_size=len(words), hidden_size=32, intermediate_size=64, num_hidden_layers=2,
                         num_attention_heads=2, num_key_value_heads=2, max_position_embeddings=64,
                         pad_token_id=0, eos_token_id=1, bos_token_id=1)
    LlamaForCausalLM(config).save_pretrained(folder)
    tok.save_pretrained(folder)
    return folder


def _tiny_picture(folder: Path) -> Path:
    """Intention: a tiny Stable Diffusion pipeline, saved as a diffusers folder."""
    pytest.importorskip("diffusers")
    from diffusers import AutoencoderKL, DDIMScheduler, StableDiffusionPipeline, UNet2DConditionModel
    from transformers import CLIPTextConfig, CLIPTextModel, CLIPTokenizer
    folder.mkdir(parents=True)
    vocab = {"<|startoftext|>": 0, "<|endoftext|>": 1, "c</w>": 2, "a</w>": 3, "t</w>": 4, "!": 5}
    (folder / "vocab.json").write_text(json.dumps(vocab), encoding="utf-8")
    (folder / "merges.txt").write_text("#version: 0.2\n", encoding="utf-8")
    tok = CLIPTokenizer(str(folder / "vocab.json"), str(folder / "merges.txt"), model_max_length=77)
    text = CLIPTextModel(CLIPTextConfig(vocab_size=len(vocab), hidden_size=32, intermediate_size=37,
                                        num_attention_heads=4, num_hidden_layers=2, projection_dim=32,
                                        max_position_embeddings=77, bos_token_id=0, eos_token_id=1))
    unet = UNet2DConditionModel(block_out_channels=(32, 64), layers_per_block=1, sample_size=8, in_channels=4,
                                out_channels=4, down_block_types=("DownBlock2D", "CrossAttnDownBlock2D"),
                                up_block_types=("CrossAttnUpBlock2D", "UpBlock2D"), cross_attention_dim=32,
                                norm_num_groups=8, attention_head_dim=4)
    vae = AutoencoderKL(block_out_channels=(8, 16), in_channels=3, out_channels=3, latent_channels=4,
                        down_block_types=("DownEncoderBlock2D", "DownEncoderBlock2D"),
                        up_block_types=("UpDecoderBlock2D", "UpDecoderBlock2D"), norm_num_groups=8, sample_size=16)
    pipe = StableDiffusionPipeline(vae=vae, text_encoder=text, tokenizer=tok, unet=unet, scheduler=DDIMScheduler(),
                                   safety_checker=None, feature_extractor=None, requires_safety_checker=False)
    pipe.save_pretrained(folder / "pipe")
    return folder / "pipe"


def _shelf(tmp_path, entries):
    """Intention: a shelf over these entries, with state in the test's folder."""
    from warp2.house.shelf import Shelf
    return Shelf(tmp_path, tmp_path / "state", entries=entries)


def _roomy():
    """Intention: a budget with plenty of room."""
    from warp2.room.budget import Budget
    return Budget(free=lambda: 64 * 1024 * MB, owed=lambda: 0, held=lambda: 0)


@pytest.fixture(scope="module")
def tiny(tmp_path_factory):
    """Intention: one tiny language model for the module."""
    return _tiny_text(tmp_path_factory.mktemp("models") / "tiny-llama")


def test_the_shelf_knows_each_kind(tmp_path, tiny):
    """Intention: a transformers folder is text, a diffusers folder is image; switched-off models are not on it."""
    (tmp_path / "pic").mkdir()
    (tmp_path / "pic" / "model_index.json").write_text("{}", encoding="utf-8")
    shelf = _shelf(tmp_path, [{"name": "t", "how": "house", "path": str(tiny)},
                              {"name": "p", "how": "house", "path": str(tmp_path / "pic")},
                              {"name": "off", "how": "house", "path": str(tiny), "enabled": False},
                              {"name": "o", "how": "ollama", "path": "x"}])
    assert shelf.names() == ["t", "p"] and shelf.names("image") == ["p"] and shelf.names("text") == ["t"]
    assert shelf.find("t")["adapter"].endswith(str(Path("house") / "adapters" / "t")) and shelf.find("o") == {}


def test_the_model_used_longest_ago_is_put_down_when_room_is_needed():
    """Intention: 300 MB free; a 500 MB model needs two older ones put down, oldest first; the one asked stays."""
    from warp2.house.keeper import Keeper
    from warp2.room.budget import Budget
    free = {"now": 300 * MB}
    clock = iter(range(100))
    keeper = Keeper(budget=Budget(free=lambda: free["now"], owed=lambda: 0, held=lambda: 0),
                    own=lambda: 0, clock=lambda: next(clock))
    for name in ("a", "b", "c"):
        keeper.held[name] = {"thing": types.SimpleNamespace(), "bytes": 100 * MB, "used": next(clock)}
    keeper.get("a")
    released = []
    original = keeper.put_down

    def put_down(name):
        released.append(name)
        free["now"] += 100 * MB
        return original(name)
    keeper.put_down = put_down
    keeper.make_room(500 * MB, keep="c")
    assert released == ["b", "a"] and list(keeper.held) == ["c"]


def test_a_language_model_answers_through_the_house_and_over_http(tmp_path, tiny):
    """Intention: chat in the house, then the same through the server and the client, as Ollama is asked."""
    from warp2.house.client import HouseClient
    from warp2.house.house import House
    from warp2.house.keeper import Keeper
    from warp2.house.server import serve
    state = tmp_path / "state"
    house = House(tmp_path, state, shelf=_shelf(tmp_path, [{"name": "tiny", "how": "house", "path": str(tiny),
                                                           "max_tokens": 3}]), keeper=Keeper(budget=_roomy()))
    said = house.chat("tiny", "hello")
    assert isinstance(said["content"], str) and said["where"] and house.ps()["models"][0]["name"] == "tiny"

    class _Stop:
        up = False

        def raised(self):
            return self.up
    stop = _Stop()
    board = types.SimpleNamespace(register=lambda role: None, unregister=lambda: None)
    unfenced = types.SimpleNamespace(again=lambda: 0)
    thread = threading.Thread(target=serve, args=(tmp_path, state, house, stop, board, unfenced), daemon=True)
    thread.start()
    client = HouseClient(tmp_path, state)
    for _ in range(200):
        if client._base():
            break
        threading.Event().wait(0.05)
    assert isinstance(client.chat("tiny", "hello", 2), str)
    from warp2.house.client import HouseUnreachable
    with pytest.raises(HouseUnreachable):
        client.chat("nobody", "hello")
    assert client.put_down("tiny") == {"put_down": ["tiny"]}
    stop.up = True
    thread.join(timeout=30)
    print("\n  [OK] the tiny model answered in the house and over HTTP; an unknown model said why")


def test_a_house_that_cannot_start_says_why(tmp_path):
    """Intention: started where there is no WARP to run, the process ends and the client says so."""
    from warp2.house.client import HouseClient, HouseUnreachable
    with pytest.raises(HouseUnreachable, match="ended as it started"):
        HouseClient(tmp_path, tmp_path / "state").start()


def test_a_picture_model_draws(tmp_path):
    """Intention: a tiny Stable Diffusion pipeline draws one picture, saved under the house's pictures."""
    from warp2.house.house import House
    from warp2.house.keeper import Keeper
    pipe = _tiny_picture(tmp_path / "sd")
    house = House(tmp_path, tmp_path / "state", shelf=_shelf(tmp_path, [{"name": "sd", "how": "house",
                                                                        "path": str(pipe)}]),
                  keeper=Keeper(budget=_roomy()))
    made = house.draw("sd", "cat", seed=3, steps=2)
    assert Path(made["path"]).is_file() and made["where"] in ("processor", "card", "card, a part at a time")
    print(f"\n  [OK] drawn on the {made['where']}: {Path(made['path']).name} {made['size']}")


def _digest():
    """Intention: what the Eye writes, small: two mixes and a tie."""
    from warp2.app.parts.eye_digest import Relations
    return {"concepts": {"mixes": {"cat": {"parts": {"paw": 0.6, "fur": 0.9}}, "dog": {"parts": {"paw": 0.5}}},
                         "relations": Relations.from_rows([["cat", "dog", 0.8, 1.0]])}}


def test_the_eyes_mixes_and_ties_become_tag_lessons_both_ways():
    """Intention: tags to tags, words to tags, tags to words; a tie; half learned, half held back."""
    from warp2.house.tag_lessons import TagLessons
    lessons = TagLessons(None, digest=_digest()).lessons()
    said = {lesson["prompt"]: lesson["answer"] for lesson in lessons}
    assert said["tags: #cat ->parts"] == "#fur #paw" and said["tags: #fur #paw ->whole"] == "#cat"
    assert said["Name the parts of cat as tags."] == "#fur #paw"
    assert said["Say in words: #cat #fur #paw"] == "cat is made of fur, paw."
    assert said["tags: #cat ~?"] == "#dog" and said["tags: #dog ~?"] == "#cat"
    learn, held = TagLessons.halves(lessons)
    assert len(learn) + len(held) == len(lessons) and not set(l["key"] for l in learn) & set(l["key"] for l in held)


def test_a_model_learns_the_new_tag_lessons_once_and_the_house_loads_its_adapter(tmp_path, tiny, monkeypatch):
    """Intention: taught once, kept only if the held-back loss did not rise; nothing new the second time; the house's
    runner sees the newer adapter."""
    from warp2.house.house import House
    from warp2.house.keeper import Keeper
    from warp2.house.shelf import Shelf
    from warp2.house.tag_lessons import TagLessons
    from warp2.house.tag_lora import TagLora
    import warp2.room.mine as mine
    monkeypatch.setattr(mine, "my_room", lambda: 64 * 1024 * MB)
    entries = [{"name": "tiny", "how": "house", "path": str(tiny), "max_tokens": 2}]
    monkeypatch.setattr(Shelf, "entries", lambda self: entries)
    state = tmp_path / "state"
    house = House(tmp_path, state, keeper=Keeper(budget=_roomy()))
    house.chat("tiny", "hello")
    runner = house.keeper.get("tiny")
    entry = Shelf(tmp_path, state).find("tiny")
    first = TagLora(tmp_path, state, entry, lessons=TagLessons(state, digest=_digest())).teach()
    assert first["did"] == "taught" and first["taught"] >= 1
    if first["kept"]:
        assert (Path(entry["adapter"]) / "adapter_config.json").is_file() and runner.stale()
        house.chat("tiny", "hello")
        assert house.keeper.get("tiny") is not runner
        again = TagLora(tmp_path, state, entry, lessons=TagLessons(state, digest=_digest())).teach()
        assert again["did"] == "nothing"
    print(f"\n  [OK] taught {first['taught']}, held-back loss {first['before']} -> {first['after']}, "
          f"kept: {first['kept']}")


def test_a_model_is_fetched_only_with_an_open_licence(tmp_path):
    """Intention: no licence, nothing downloaded; an open one, only what the house loads, with its record."""
    from warp2.house.fetch_model import Refused, TAKEN, fetch
    got = []
    hub = types.SimpleNamespace(
        model_info=lambda repo: types.SimpleNamespace(card_data={"license": "" if repo == "a/none" else
                                                                 "creativeml-openrail-m"}, author="someone"),
        snapshot_download=lambda **kw: got.append(kw))
    with pytest.raises(Refused):
        fetch("a/none", tmp_path / "none", hub=hub)
    assert not got
    said = fetch("a/sd", tmp_path / "sd", hub=hub)
    assert got[0]["allow_patterns"] == TAKEN and said["licence"] == "creativeml-openrail-m"
    assert json.loads((tmp_path / "sd" / "warp2_source.json").read_text())["author"] == "someone"


def test_the_roster_asks_a_house_model_through_the_house(tmp_path, monkeypatch):
    """Intention: an entry with "how": "house" is enlisted and asked through the house client."""
    from warp2.house.client import HouseClient
    from warp2.models.roster import assemble
    from warp2.store.store import Store
    from warp2.store.tagnet import TagNet
    (tmp_path / "models.json").write_text(json.dumps({"internal_only": True, "models": [
        {"name": "h", "how": "house", "path": "C:/m/h", "kinds": ["build"], "max_tokens": 5}]}), encoding="utf-8")
    monkeypatch.setattr(HouseClient, "chat", lambda self, model, prompt, tokens=0: f"{model}:{prompt}:{tokens}")
    store = Store(tmp_path / "state", run="house", view_path=tmp_path / "view.sqlite3")
    fleet = assemble(tmp_path, TagNet(store), with_worker=False)["fleet"]
    assert "h" in fleet.names()


def test_the_house_draws_a_persons_ask_once(tmp_path, monkeypatch):
    """Intention: the oldest undrawn ask is drawn and told in the thread; the next turn has nothing to draw."""
    from warp2.house.client import HouseClient
    from warp2.house.shelf import Shelf
    from warp2.work.side import asked as asked_module
    from warp2.work.side.house_steps import HouseDrawStep
    told = []
    shared = types.SimpleNamespace(root=tmp_path, state=tmp_path / "state",
                                   tell=lambda words, **kw: told.append((words, kw)))
    folder = types.SimpleNamespace(waiting=lambda kind: [(tmp_path / "r1.json", {"id": "r1", "subject": "a cat"})])
    monkeypatch.setattr(asked_module, "_requests", lambda s: folder)
    monkeypatch.setattr(Shelf, "names", lambda self, kind="": ["sd"] if kind == "image" else ["sd"])
    monkeypatch.setattr(HouseClient, "draw", lambda self, model, prompt, seed=0, **kw: {"path": "p.png",
                                                                                       "where": "card"})
    step = HouseDrawStep(shared)
    assert step.urgent()
    done = step.body()
    assert done["did"] == "drew" and told and told[0][1]["image"] == "p.png"
    assert not step.urgent() and step.body()["did"] == "nothing"
