# WARP2/warp2/house/tests/test_a_tag_lesson_fits_its_turn.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_a_tag_lesson_fits_its_turn.py
#  Used by   : pytest (run_tests.py), CHECK_FIXES.bat.
#  Uses      : warp2/house/tag_lora.py; projects/behemoth_eye/eye/turn_clock.py;
#              torch (a one-weight stand-in model, so no real model is needed).
#  Description:
#    A house model's tag lesson teaches only what fits in its turn: the
#    lessons not reached keep their place and are taught next turn; what one
#    lesson cost is kept beside the adapter; with no turn open every new
#    lesson is taught, as before.
#  User intention (Andrew, 2026-11-09 22:53): "All work on the warp should
#    use a set amount of compute and be built to do so." (2026-11-10 17:10)
#    "Put it in everywhere". BUILD_LOG 1513.
# ============================================================================
"""A tag lesson fits its turn."""
from __future__ import annotations

import json
import sys
import time
import types

import pytest

torch = pytest.importorskip("torch")

from projects.behemoth_eye.eye.turn_clock import turn  # noqa: E402
from warp2.house import tag_lora  # noqa: E402
from warp2.house.tag_lora import TagLora  # noqa: E402

# Intention: what one forward pass of the stand-in costs - slow enough that a short turn holds only a few lessons.
STEP = 0.05


class _Lessons:
    """Intention: forty tag lessons (twenty to learn, twenty held back)."""

    def lessons(self) -> list:
        """Intention: keys in order, as TagLessons gives them."""
        return [{"key": f"k{n:03d}", "prompt": f"p{n}", "answer": f"a{n}", "kind": "tags to tags"} for n in range(40)]


class _Model(torch.nn.Module):
    """Intention: one weight; a lesson's loss is its distance from 1, so teaching lowers every loss."""

    def __init__(self) -> None:
        """Intention: the weight starts at nought."""
        super().__init__()
        self.weight = torch.nn.Parameter(torch.zeros(1))

    def save_pretrained(self, folder) -> None:
        """Intention: the adapter written as a real one is."""
        from pathlib import Path
        Path(folder).mkdir(parents=True, exist_ok=True)
        (Path(folder) / "adapter_config.json").write_text("{}", encoding="utf-8")


def _loss(self, model, tokenizer, lesson):
    """Intention: a slow loss, as a real model's is."""
    time.sleep(STEP)
    return ((model.weight - 1.0) ** 2).sum()


@pytest.fixture
def lora(tmp_path, monkeypatch):
    """Intention: a TagLora over the stand-in model, placed in memory."""
    fake = types.ModuleType("warp2.room.split_load")
    fake.placement = lambda path, dtype, offload: {"where": "memory", "size": 0}
    monkeypatch.setitem(sys.modules, "warp2.room.split_load", fake)
    monkeypatch.setattr(TagLora, "_load", lambda self, where: (_Model(), None))
    monkeypatch.setattr(TagLora, "_loss", _loss)
    monkeypatch.setattr(TagLora, "_type", staticmethod(lambda: "float32"))
    monkeypatch.setattr(tag_lora, "learning_rate", lambda: 0.1)
    entry = {"name": "tiny", "path": str(tmp_path / "model")}
    return lambda: TagLora(tmp_path, tmp_path / "state", entry, lessons=_Lessons())


def test_a_turn_teaches_only_what_fits_and_the_rest_comes_next_turn(lora, tmp_path):
    """Intention: a 1 s turn over twenty lessons at 0.05 s a pass (four passes a lesson) teaches some, not all, ends
    near its turn, and leaves the rest to the next turn."""
    # Intention (BUILD_LOG 1514): the first optimiser step on Windows loads torch's compile machinery cold (seconds,
    # once per process); that is not a lesson's cost, so it is paid before the turn is timed.
    warm = torch.nn.Parameter(torch.zeros(1))
    (warm ** 2).sum().backward()
    torch.optim.AdamW([warm], lr=0.1).step()
    made = lora()
    began = time.monotonic()
    with turn(1.0):
        first = made.teach()
    took = time.monotonic() - began
    assert first["did"] == "taught" and first["kept"]
    assert 1 <= first["taught"] < 20 and first["left"] == 20 - first["taught"]
    # Intention: every lesson at once takes 3 s here (twenty scored, taught, scored again); a turn that fits ends near
    # its 1 s, with room left for a slow first step on a busy machine.
    assert took < 2.2, f"the turn ran {took:.2f} s past a 1 s turn"
    taught = json.loads((tmp_path / "state" / "house" / "adapters" / "tiny" / "taught.json").read_text())
    assert len(taught) == first["taught"]
    cost = json.loads((tmp_path / "state" / "house" / "adapters" / "tiny" / "turn_cost.json").read_text())
    assert cost["teach_seconds"] > 0 and cost["score_seconds"] > 0
    with turn(1.0):
        second = lora().teach()
    assert second["did"] == "taught" and second["taught"] >= 1 and second["left"] == first["left"] - second["taught"]


def test_no_turn_open_teaches_every_new_lesson(lora):
    """Intention: outside a turn nothing changes - every new lesson, checked on as many held back."""
    once = lora().teach()
    assert once["taught"] == 20 and once["checked"] == 20 and once["left"] == 0
    assert lora().teach()["did"] == "nothing"
