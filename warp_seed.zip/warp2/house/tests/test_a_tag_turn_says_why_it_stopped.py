# WARP2/warp2/house/tests/test_a_tag_turn_says_why_it_stopped.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_a_tag_turn_says_why_it_stopped.py
#  Used by   : pytest (run_tests.py), CHECK_FIXES.bat.
#  Uses      : warp2/house/tag_lora.py, projects/behemoth_eye/eye/turn_clock.py;
#              torch (a one-weight stand-in model, so no real model is needed).
#  Description:
#    A tag turn's "ended" line (and its result) says WHY it stopped, apart
#    from the clock reading: "completed_all_offered" when every lesson named
#    in "began" was taught, "forecast_would_not_fit" when the measured cost
#    said the rest would not fit in the time left, "deadline_expired" when
#    teaching stopped because the turn's time was up. clock_over stays the
#    clock read at the end. BUILD_LOG 1522.
#  User intention (Andrew, 2026-11-09 22:53): "All work on the warp should
#    use a set amount of compute and be built to do so." Suggested by Codex-425
#    via Muse-1633 (a contact's suggestion, taken on its merits).
# ============================================================================
"""A tag turn says why it stopped."""
from __future__ import annotations

import json
import sys
import types

import pytest

torch = pytest.importorskip("torch")

from warp2.house import tag_lora  # noqa: E402
from warp2.house.tag_lora import TagLora  # noqa: E402


class _Lessons:
    """Intention: ten tag lessons (five to learn, five held back)."""

    def lessons(self) -> list:
        """Intention: keys in order, as TagLessons gives them."""
        return [{"key": f"k{n:03d}", "prompt": f"p{n}", "answer": f"a{n}", "kind": "tags to tags"} for n in range(10)]


class _Model(torch.nn.Module):
    """Intention: one weight; a lesson's loss is its distance from 1."""

    def __init__(self) -> None:
        """Intention: the weight starts at nought."""
        super().__init__()
        self.weight = torch.nn.Parameter(torch.zeros(1))

    def save_pretrained(self, folder) -> None:
        """Intention: the adapter written as a real one is."""
        from pathlib import Path
        Path(folder).mkdir(parents=True, exist_ok=True)
        (Path(folder) / "adapter_config.json").write_text("{}", encoding="utf-8")


@pytest.fixture
def lora(tmp_path, monkeypatch):
    """Intention: a TagLora over the stand-in model, placed in memory; the adapter folder."""
    fake = types.ModuleType("warp2.room.split_load")
    fake.placement = lambda path, dtype, offload: {"where": "memory", "size": 0}
    monkeypatch.setitem(sys.modules, "warp2.room.split_load", fake)
    monkeypatch.setattr(TagLora, "_load", lambda self, where: (_Model(), None))
    monkeypatch.setattr(TagLora, "_loss", lambda self, model, tokenizer, lesson: ((model.weight - 1.0) ** 2).sum())
    monkeypatch.setattr(TagLora, "_type", staticmethod(lambda: "float32"))
    monkeypatch.setattr(tag_lora, "learning_rate", lambda: 0.1)
    entry = {"name": "tiny", "path": str(tmp_path / "model")}
    return (lambda: TagLora(tmp_path, tmp_path / "state", entry, lessons=_Lessons()),
            tmp_path / "state" / "house" / "adapters" / "tiny")


def _ended(adapter) -> dict:
    """Intention: the turn log's "ended" line."""
    lines = [json.loads(line) for line in (adapter / "turns.jsonl").read_text(encoding="utf-8").splitlines()]
    return [line for line in lines if line["state"] == "ended"][-1]


def test_every_offered_lesson_taught_says_completed(lora):
    """Intention: no clock, every lesson taught: completed_all_offered, in the result and the ended line."""
    make, adapter = lora
    result = make().teach()
    assert result["stop_reason"] == "completed_all_offered"
    assert _ended(adapter)["stop_reason"] == "completed_all_offered"


def test_a_forecast_that_the_rest_would_not_fit_says_so(lora, monkeypatch):
    """Intention: the scoring stopped early on the measured forecast: forecast_would_not_fit, clock not over."""
    from projects.behemoth_eye.eye.turn_clock import turn
    make, adapter = lora
    monkeypatch.setattr(TagLora, "_score_within",
                        lambda self, model, tokenizer, lessons, cost: (lessons[:2], [1.0, 1.0]))
    with turn(600.0):
        result = make().teach()
    ended = _ended(adapter)
    assert result["taught"] == 2 and ended["stop_reason"] == "forecast_would_not_fit"
    assert ended["clock_over"] is False


def test_teaching_stopped_by_the_deadline_says_so(lora, monkeypatch):
    """Intention: teaching stopped because the turn's time was up: deadline_expired, clock over."""
    from projects.behemoth_eye.eye import turn_clock
    make, adapter = lora
    with turn_clock.turn(60.0) as clock:
        def late(self, model, tokenizer, lessons):
            clock.deadline = turn_clock.time.monotonic() - 1.0
            return 1
        monkeypatch.setattr(TagLora, "_learn", late)
        result = make().teach()
    ended = _ended(adapter)
    assert result["stop_reason"] == "deadline_expired"
    assert ended["stop_reason"] == "deadline_expired" and ended["clock_over"] is True
