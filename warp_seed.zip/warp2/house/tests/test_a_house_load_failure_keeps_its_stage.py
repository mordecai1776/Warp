# WARP2/warp2/house/tests/test_a_house_load_failure_keeps_its_stage.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_a_house_load_failure_keeps_its_stage.py
#  Used by   : pytest, CHECK_FIXES.bat
#  Uses      : warp2.house.client, warp2.house.server, warp2.house.text_runner, warp2.room.split_load
#  Description:
#    Proves that a natural house load failure reaches its caller with the
#    original stack and base/adapter stage, without recording prompt text.
#  User intention (Andrew):
#    We want to see the real cause and stage when a house model load fails.
# ============================================================================
"""The HTTP boundary must not erase a house model's failing load stage."""
import sys
import threading
import types
from http.server import HTTPServer

import pytest

from warp2.house.client import HouseClient, HouseUnreachable
from warp2.house.server import _handler
from warp2.house.text_runner import TextRunner


@pytest.mark.parametrize("stage", ["base", "adapter"])
def test_load_failure_reaches_the_caller_with_stage_and_stack(tmp_path, monkeypatch, stage):
    """Intention: exercise both loaders and the real HTTP error-to-exception path."""
    from warp2.room import split_load

    def fail_base(*args, **kwargs):
        """Intention: stand in for the observed safetensors device error at base load."""
        if stage == "base":
            raise ValueError("device disk is invalid")
        return object()

    def fail_adapter(*args, **kwargs):
        """Intention: the same error at adapter load must have a different stage."""
        raise ValueError("device disk is invalid")

    monkeypatch.setitem(sys.modules, "torch", types.SimpleNamespace(float32="float32"))
    monkeypatch.setitem(sys.modules, "transformers", types.SimpleNamespace(
        AutoTokenizer=types.SimpleNamespace(from_pretrained=lambda *a, **k: object()),
        AutoModelForCausalLM=types.SimpleNamespace(from_pretrained=fail_base)))
    monkeypatch.setitem(sys.modules, "peft", types.SimpleNamespace(
        PeftModel=types.SimpleNamespace(from_pretrained=fail_adapter)))
    monkeypatch.setattr(TextRunner, "_type", staticmethod(lambda: "float32"))
    monkeypatch.setattr(split_load, "placement", lambda *a: {
        "where": "split to disk", "kwargs": {"device_map": {"": "disk"}}})
    adapter = tmp_path / "adapter"
    adapter.mkdir()
    (adapter / "adapter_config.json").write_text("{}", encoding="utf-8")
    runner = TextRunner(tmp_path / "tiny-model", adapter)

    class FailedHouse:
        """Intention: a normal chat triggers the loader, never a real inference."""
        def chat(self, model, prompt, tokens):
            """Intention: the request fails naturally inside the selected loader."""
            return runner.load()

    fence = types.SimpleNamespace(again=lambda: None)
    server = HTTPServer(("127.0.0.1", 0), _handler(FailedHouse(), fence))
    thread = threading.Thread(target=server.handle_request)
    thread.start()
    client = HouseClient(tmp_path, tmp_path / "state")
    monkeypatch.setattr(client, "_base", lambda: f"http://127.0.0.1:{server.server_port}")
    try:
        with pytest.raises(HouseUnreachable) as caught:
            client.chat("tiny-model", "PRIVATE_PROMPT_SENTINEL")
    finally:
        thread.join()
        server.server_close()
    said = str(caught.value)
    assert "Traceback (most recent call last)" in said
    assert f"stage={stage}" in said
    assert "model=tiny-model" in said and "placement=split to disk" in said
    assert f"fail_{stage}" in said and "ValueError: device disk is invalid" in said
    assert "PRIVATE_PROMPT_SENTINEL" not in said
