# WARP2/warp2/house/tests/test_a_house_answer_is_the_answer_not_the_thinking.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_a_house_answer_is_the_answer_not_the_thinking.py
#  Used by   : pytest.
#  Uses      : warp2/house/text_runner.py (chat_text, without_thinking).
#  Description:
#    A house model is asked to answer without thinking first (the chat form's
#    own switch), a form with no switch is asked as before, a tokenizer with
#    no chat form gets the plain prompt, and a <think> block - closed, or cut
#    off when the answer's room ran out - is set aside. Measured 2026-11-09:
#    qwen3-1.7b's house answer began "<think>\nOkay, the user is asking".
#  User intention (Andrew, 2026-11-09 21:37): "get ... all the other things you
#    need to get done there". (BUILD_LOG 1486.)
# ============================================================================
from __future__ import annotations

from warp2.house.text_runner import chat_text, without_thinking


class _Tok:
    """Intention: a tokenizer that records how its chat form was asked."""

    chat_template = "x"

    def __init__(self):
        self.asked = {}

    def apply_chat_template(self, messages, **kwargs):
        self.asked = kwargs
        return "<user>" + messages[0]["content"] + "<assistant>"


def test_the_model_is_asked_not_to_think_first():
    """Intention: the chat form's switch is set off; no chat form means the plain prompt."""
    tok = _Tok()
    assert chat_text(tok, "hi") == "<user>hi<assistant>" and tok.asked["enable_thinking"] is False
    assert tok.asked["add_generation_prompt"] is True
    plain = type("Plain", (), {"chat_template": None})()
    assert chat_text(plain, "hi") == "hi"


def test_thinking_is_set_aside_closed_or_cut_off():
    """Intention: only the answer is left."""
    assert without_thinking("<think>\nOkay, the user asks</think>\n\ncat") == "cat"
    assert without_thinking("<think>\nOkay, the user is asking") == ""
    assert without_thinking("cat") == "cat"
