# WARP2/warp2/house/tests/test_the_models_learn_the_graphs_web_tags.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_the_models_learn_the_graphs_web_tags.py
#  Used by   : pytest (run_tests.py), CHECK_FIXES.bat.
#  Uses      : warp2/house/{web_tag_lessons,tag_lessons}.py; warp2/tags/
#              dehydrated/whole_lane.py; warp2/tags/lane.py; warp2/record/journal.py.
#  Description:
#    The house models' lessons include the knowledge graph's own web tags,
#    both ways: a web tag as one token and what it holds, read from the
#    newest page of the graph's small form; none when nothing is held small.
#  User intention (Andrew, 2026-11-10 20:04): "We need to train a lora for
#    the models". BUILD_LOG 1508.
# ============================================================================
"""The models learn the graph's web tags as tokens."""
from __future__ import annotations

from warp2.house.tag_lessons import TagLessons
from warp2.house.web_tag_lessons import WebTagLessons
from warp2.record import journal
from warp2.tags.dehydrated.whole_lane import WholeLane
from warp2.tags.lane import TagLane


def test_web_tags_are_taught_both_ways(tmp_path, monkeypatch):
    """Intention: each web tag of the newest page as a token and what it holds, and back."""
    monkeypatch.setattr(journal, "ROTATE_AFTER_BYTES", 20000)
    state = tmp_path / "state"
    lane = TagLane(state / "store" / "tags" / "tags.jsonl")
    for number in range(300):
        lane.append({"fact": "assert", "row": {"subject": f"part_{number % 5}", "relation": "", "object": "",
                                               "attr": "status", "value": "built", "confidence": 900,
                                               "valid_from": "2026-11-10T04:53:11.121221+00:00", "run": "web",
                                               "stamp": "6cfebf804e787d7f", "proof": 4}})
    WholeLane(state / "store" / "tags", say=lambda text: None, form=2).run()
    lessons = WebTagLessons(state).lessons()
    assert lessons and len(lessons) % 2 == 0
    asks = {one["prompt"]: one["answer"] for one in lessons}
    holds = [p for p in asks if p.endswith("->holds")]
    assert holds and all(asks[f"web tag: {asks[p]} ->token"] == p.split(" ")[2] for p in holds)
    assert set(lesson["key"] for lesson in lessons) <= {one["key"] for one in TagLessons(state, digest={}).lessons()}


def test_nothing_held_small_gives_no_web_tag_lessons(tmp_path):
    """Intention: a state with no small form gives none, and the Eye's own lessons are as before."""
    assert WebTagLessons(tmp_path / "state").lessons() == []
    assert TagLessons(tmp_path / "state", digest={}).lessons() == []


def test_the_tag_lane_and_whole_lane_yield_dehydrated_web_tag_entries_and_alteration_lessons(tmp_path, monkeypatch):
    """Intention (Andrew, 2026-11-12): the KG is read and worked with in its dehydrated web-tag and tag-tree form
    across WholeLane, TagLane, as_fact, and WebTagLessons."""
    from warp2.tags.lane import as_fact
    monkeypatch.setattr(journal, "ROTATE_AFTER_BYTES", 20000)
    state = tmp_path / "state"
    lane = TagLane(state / "store" / "tags" / "tags.jsonl")
    for number in range(300):
        lane.append({"fact": "assert", "row": {"subject": f"part_{number % 5}", "relation": "", "object": "",
                                               "attr": "status", "value": "built", "confidence": 900,
                                               "valid_from": f"2026-11-10T04:53:{number % 60:02d}.121221+00:00",
                                               "run": "web", "stamp": "6cfebf804e787d7f", "proof": 4}})
    whole = WholeLane(state / "store" / "tags", say=lambda text: None, form=2)
    whole.run()
    done = sorted(whole.record())
    assert done
    seg_entries = list(whole.dehydrated_entries(done[0]))
    assert seg_entries and all(e["web_tag"].startswith("<wt:") for e in seg_entries)
    assert any(e["fixed"] and e["alterations"] for e in seg_entries)
    sample = seg_entries[-1]
    only_web_tag = {"seq": sample["seq"], "ts": sample["ts"], "form": sample["form"],
                    "fixed": sample["fixed"], "alterations": sample["alterations"]}
    reconstructed = as_fact(only_web_tag)
    assert reconstructed["fact"] == "assert" and reconstructed["row"]["attr"] == "status"
    all_dehydrated = list(lane.dehydrated_entries())
    assert len(all_dehydrated) == 300
    lessons = WebTagLessons(state).lessons()
    asks = {one["prompt"]: one["answer"] for one in lessons}
    alt_prompts = [p for p in asks if p.startswith("dehydrated entry:") and p.endswith("->tags")]
    assert alt_prompts and all(asks[f"dehydrated entry: {asks[p]} ->web_tag"] == p.removeprefix("dehydrated entry: ").removesuffix(" ->tags")
                               for p in alt_prompts)
