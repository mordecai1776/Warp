# WARP2/warp2/house/tests/test_the_house_reads_pictures.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_the_house_reads_pictures.py
#  Used by   : pytest.
#  Uses      : warp2/house/{shelf,house,keeper,reader_runner,picture_reader,
#              fetch_model}.py, warp2/models/roster.py,
#              projects/centering_image/readers.py (test_searched_image);
#              a tiny CLIP made here from a config (nothing downloaded).
#  Description:
#    The house's own picture reader, in place of Ollama's:
#      - a CLIP folder is a "reader" on the shelf, and is not enlisted to
#        answer prompts;
#      - a tiny CLIP gives a chance that a picture shows a subject, and with a
#        real picture to hand the chance it is the same kind of thing;
#      - the reader gives the evidence every reader gives, so a searched
#        picture is judged: a high chance passes, a low one is "answered no";
#      - only the files named are fetched.
#  User intention (Andrew, 2026-11-09 18:49): "use only internal models".
#    19:05: "holds models like ollama and comfy could inside the warp".
#    (BUILD_LOG 1485.)
# ============================================================================
from __future__ import annotations

import json
import sys
import types
from pathlib import Path

import pytest

pytest.importorskip("transformers")
ROOT = Path(__file__).resolve().parents[3]
MB = 2 ** 20


def _tiny_clip(folder: Path) -> Path:
    """Intention: a tiny CLIP with its tokenizer and picture processor, saved as a Hugging Face folder."""
    from transformers import (CLIPConfig, CLIPImageProcessor, CLIPModel, CLIPProcessor, CLIPTextConfig,
                              CLIPTokenizer, CLIPVisionConfig)
    folder.mkdir(parents=True)
    vocab = {"<|startoftext|>": 0, "<|endoftext|>": 1, "a</w>": 2, "photo</w>": 3, "of</w>": 4, "cat</w>": 5,
             "something</w>": 6, "else</w>": 7}
    (folder / "vocab.json").write_text(json.dumps(vocab), encoding="utf-8")
    (folder / "merges.txt").write_text("#version: 0.2\n", encoding="utf-8")
    tok = CLIPTokenizer(str(folder / "vocab.json"), str(folder / "merges.txt"), model_max_length=77)
    config = CLIPConfig(text_config=CLIPTextConfig(vocab_size=len(vocab), hidden_size=32, intermediate_size=37,
                                                   num_attention_heads=4, num_hidden_layers=2,
                                                   max_position_embeddings=77, bos_token_id=0,
                                                   eos_token_id=1).to_dict(),
                        vision_config=CLIPVisionConfig(hidden_size=32, intermediate_size=37, num_attention_heads=4,
                                                       num_hidden_layers=2, image_size=32, patch_size=8).to_dict(),
                        projection_dim=16)
    CLIPModel(config).save_pretrained(folder)
    CLIPProcessor(image_processor=CLIPImageProcessor(size={"shortest_edge": 32},
                                                     crop_size={"height": 32, "width": 32}),
                  tokenizer=tok).save_pretrained(folder)
    return folder


def _picture(path: Path, colour) -> Path:
    """Intention: a small plain picture."""
    from PIL import Image
    Image.new("RGB", (48, 48), colour).save(path)
    return path


@pytest.fixture(scope="module")
def clip(tmp_path_factory):
    """Intention: one tiny CLIP for the module."""
    return _tiny_clip(tmp_path_factory.mktemp("clip") / "tiny-clip")


def test_a_clip_folder_is_a_reader_and_is_not_enlisted_to_answer(tmp_path, clip):
    """Intention: the shelf says "reader"; the roster skips it with its reason."""
    from warp2.house.shelf import Shelf
    from warp2.models.roster import assemble
    from warp2.store.store import Store
    from warp2.store.tagnet import TagNet
    assert Shelf.kind(clip) == "reader"
    (tmp_path / "models.json").write_text(json.dumps({"internal_only": True, "models": [
        {"name": "eyes", "how": "house", "path": str(clip), "kinds": ["visual_reader"]}]}), encoding="utf-8")
    built = assemble(tmp_path, TagNet(Store(tmp_path / "state", run="r", view_path=tmp_path / "v.sqlite3")),
                     with_worker=False)
    assert "eyes" not in built["fleet"].names() and any(row.get("entry") == "eyes" for row in built["skipped"])


def test_a_tiny_reader_gives_its_chances(tmp_path, clip):
    """Intention: a chance between nought and one for the subject, and one more with a real picture to hand."""
    from warp2.house.house import House
    from warp2.house.keeper import Keeper
    from warp2.house.shelf import Shelf
    from warp2.room.budget import Budget
    house = House(tmp_path, tmp_path / "state",
                  shelf=Shelf(tmp_path, tmp_path / "state", entries=[{"name": "eyes", "how": "house",
                                                                      "path": str(clip)}]),
                  keeper=Keeper(budget=Budget(free=lambda: 64 * 1024 * MB, owed=lambda: 0, held=lambda: 0)))
    made, real = _picture(tmp_path / "made.png", (200, 30, 30)), _picture(tmp_path / "real.png", (30, 30, 200))
    alone = house.read("eyes", str(made), "cat")
    assert 0.0 <= alone["yes_chance"] <= 1.0 and alone["same_chance"] is None
    both = house.read("eyes", str(made), "cat", str(real))
    assert 0.0 <= both["same_chance"] <= 1.0 and both["where"] in ("card", "processor")
    print(f"\n  [OK] chance it shows a cat {alone['yes_chance']:.3f}; same kind as the real one {both['same_chance']:.3f}")


def _client(chance, same=None):
    """Intention: a house that answers a read with these chances."""
    return types.SimpleNamespace(read=lambda model, image, subject, reference="": {
        "yes_chance": chance, "same_chance": same if reference else None, "where": "processor"})


def test_the_reader_gives_the_evidence_a_pass_rule_reads(tmp_path, monkeypatch):
    """Intention: a searched picture is judged by the house reader: 0.97 passes; 0.2 is "answered no"; a real picture
    it is not like is "not like the real picture"."""
    monkeypatch.syspath_prepend(str(ROOT / "projects" / "centering_image"))
    import readers
    from warp2.house.picture_reader import HouseReader
    picture = _picture(tmp_path / "p.png", (120, 120, 120))
    good = HouseReader(tmp_path, tmp_path / "state", "eyes", client=_client(0.97))
    seen = good.read(str(picture), "cat")
    assert seen["score"] == 0.97 and seen["answer"] == "yes" and seen["score_kind"] == "explicit"
    assert seen["judge"].startswith("eyes#") and seen["reference_chance"] is None
    verdict = readers.test_searched_image(picture, "cat", readers=[good])
    assert verdict["judged"] and verdict["passed"] and verdict["score"] == 0.97
    bad = readers.test_searched_image(picture, "cat", readers=[HouseReader(tmp_path, tmp_path / "state", "eyes",
                                                                           client=_client(0.2))])
    assert bad["judged"] and not bad["passed"] and "answered no" in bad["said"]
    unlike = HouseReader(tmp_path, tmp_path / "state", "eyes", client=_client(0.97, same=0.1))
    said = unlike.read(str(picture), {"name": "cat", "data": {"reference": str(picture)}})
    assert said["reference_answer"] == "no" and readers.said_not_there([said], "cat").endswith("real picture")


def test_only_the_files_named_are_fetched(tmp_path):
    """Intention: the reader's one weight file and its configs, not every copy in the repository."""
    from warp2.house.fetch_model import fetch
    got = []
    hub = types.SimpleNamespace(model_info=lambda repo: types.SimpleNamespace(card_data={"license": "mit"},
                                                                             author="laion"),
                                snapshot_download=lambda **kw: got.append(kw))
    said = fetch("laion/x", tmp_path / "x", hub=hub, taken=["*.json", "*.txt", "model.safetensors"])
    assert got[0]["allow_patterns"] == ["*.json", "*.txt", "model.safetensors"] and said["taken"][-1] == "model.safetensors"
