# WARP2/warp2/house/tests/test_a_tag_turn_leaves_room_to_save.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_a_tag_turn_leaves_room_to_save.py
#  Used by   : pytest (run_tests.py), CHECK_FIXES.bat.
#  Uses      : warp2/house/tag_lora.py; projects/behemoth_eye/eye/turn_clock.py;
#              torch (a one-weight stand-in model with a slow save, so no real
#              model is needed).
#  Description:
#    A house model's tag turn times how long saving its adapter takes, keeps
#    that beside the adapter, and leaves room for it next turn, so the turn
#    ends inside its clock and not after it. The first live turn
#    (2026-11-11 19:38) ended 13 s past its clock.
#  User intention (Andrew, 2026-11-09 22:53): "All work on the warp should
#    use a set amount of compute and be built to do so." (2026-11-10 17:10)
#    "Put it in everywhere". BUILD_LOG 1526.
# ============================================================================
"""A tag turn leaves room to save its adapter."""
from __future__ import annotations

import json
import sys
import time
import types
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")

from projects.behemoth_eye.eye.turn_clock import turn  # noqa: E402
from warp2.house import tag_lora  # noqa: E402
from warp2.house.tag_lora import TagLora, TurnCost  # noqa: E402

# Intention: one forward pass of the stand-in, and one save of its adapter - the save is slow, as a real one can be.
STEP = 0.02
SAVE = 0.8


class _Lessons:
    """Intention: two hundred tag lessons (a hundred to learn, a hundred held back) - more than any turn here holds."""

    def lessons(self) -> list:
        """Intention: keys in order, as TagLessons gives them."""
        return [{"key": f"k{n:03d}", "prompt": f"p{n}", "answer": f"a{n}", "kind": "tags to tags"} for n in range(200)]


class _Model(torch.nn.Module):
    """Intention: one weight; a lesson's loss is its distance from 1, so teaching lowers every loss."""

    def __init__(self) -> None:
        """Intention: the weight starts at nought."""
        super().__init__()
        self.weight = torch.nn.Parameter(torch.zeros(1))

    def save_pretrained(self, folder) -> None:
        """Intention: the adapter written as a real one is, and slowly."""
        time.sleep(SAVE)
        Path(folder).mkdir(parents=True, exist_ok=True)
        (Path(folder) / "adapter_config.json").write_text("{}", encoding="utf-8")


def _loss(self, model, tokenizer, lesson):
    """Intention: a slow loss, as a real model's is."""
    time.sleep(STEP)
    return ((model.weight - 1.0) ** 2).sum()


@pytest.fixture
def lora(tmp_path, monkeypatch):
    """Intention: a TagLora over the stand-in model, placed in memory."""
    fake = types.ModuleType("warp2.room.split_load")
    fake.placement = lambda path, dtype, offload: {"where": "memory", "size": 0}
    monkeypatch.setitem(sys.modules, "warp2.room.split_load", fake)
    monkeypatch.setattr(TagLora, "_load", lambda self, where: (_Model(), None))
    monkeypatch.setattr(TagLora, "_loss", _loss)
    monkeypatch.setattr(TagLora, "_type", staticmethod(lambda: "float32"))
    monkeypatch.setattr(tag_lora, "learning_rate", lambda: 0.1)
    entry = {"name": "tiny", "path": str(tmp_path / "model")}
    return lambda: TagLora(tmp_path, tmp_path / "state", entry, lessons=_Lessons())


def test_the_save_is_timed_and_kept_beside_the_adapter(lora, tmp_path):
    """Intention: after a kept turn, turn_cost.json holds how long the save took."""
    first = lora().teach()
    assert first["kept"]
    cost = json.loads((tmp_path / "state" / "house" / "adapters" / "tiny" / "turn_cost.json").read_text())
    assert cost["save_seconds"] >= SAVE - 0.05


def test_the_forecast_leaves_room_for_the_save(tmp_path):
    """Intention: a kept save time is in what the turn says it needs, even for nothing taught."""
    folder = tmp_path / "adapter"
    folder.mkdir()
    (folder / "turn_cost.json").write_text(json.dumps({"score_seconds": 0.1, "teach_seconds": 0.3,
                                                       "save_seconds": 5.0}), encoding="utf-8")
    cost = TurnCost(folder)
    assert cost.needs(0) == pytest.approx(5.0)
    assert cost.needs(2) == pytest.approx(2 * 0.4 + 5.0)


def test_a_turn_with_a_slow_save_ends_inside_its_clock(lora):
    """Intention: once the save is measured, the next 2 s turn ends near 2 s, not a whole save past it."""
    warm = torch.nn.Parameter(torch.zeros(1))
    (warm ** 2).sum().backward()
    torch.optim.AdamW([warm], lr=0.1).step()
    with turn(2.0):
        lora().teach()
    began = time.monotonic()
    with turn(2.0):
        second = lora().teach()
    took = time.monotonic() - began
    assert second["did"] == "taught" and second["kept"]
    # Intention: without room for the save the turn runs about 2.8 s (a whole 0.8 s save past it).
    assert took < 2.0 + 0.35, f"the turn ran {took:.2f} s, past its 2 s turn"
