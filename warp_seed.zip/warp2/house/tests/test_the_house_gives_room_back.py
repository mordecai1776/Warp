# WARP2/warp2/house/tests/test_the_house_gives_room_back.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_the_house_gives_room_back.py
#  Used by   : pytest.
#  Uses      : warp2/house/{keeper,house,server}.py, warp2/room/budget.py.
#  Description:
#    The house keeps its models only while the machine has room: with room
#    for new work nothing is put down; with none, the model used longest ago
#    goes, one a look, until there is room again or nothing is held; and the
#    house's serving loop looks each time it wakes.
#  User intention (Andrew, 2026-11-09 18:37): "if it doesn't have enough, it
#    needs to adjust." 19:05: models kept while there is room. (BUILD_LOG 1487.)
# ============================================================================
from __future__ import annotations

import json
import threading
import urllib.request

from warp2.house.keeper import Keeper
from warp2.room.budget import Budget

GB = 2 ** 30


def _keeper(free):
    """Intention: a keeper whose machine has `free["now"]` bytes and owes two GB to the rest of the machine."""
    ticks = iter(range(100))
    return Keeper(budget=Budget(free=lambda: free["now"], owed=lambda: 2 * GB, held=lambda: 0),
                  own=lambda: 0, clock=lambda: next(ticks))


def test_models_are_kept_while_there_is_room_and_the_longest_unused_goes_first_when_there_is_none():
    """Intention: 8 GB free keeps all three; 1 GB free puts down one a look, oldest first; room back stops it."""
    free = {"now": 8 * GB}
    keeper = _keeper(free)
    for name in ("first", "second", "third"):
        keeper.load(name, GB, lambda: object())
    keeper.get("first")
    assert keeper.give_back() == [] and len(keeper.held) == 3
    free["now"] = GB
    assert keeper.give_back() == ["second"]
    assert keeper.give_back() == ["third"]
    free["now"] = 8 * GB
    assert keeper.give_back() == [] and list(keeper.held) == ["first"]
    free["now"] = 0
    assert keeper.give_back() == ["first"] and keeper.give_back() == []


def test_the_serving_house_looks_each_time_it_wakes(tmp_path):
    """Intention: one request answered, one look at the room after it."""
    from warp2.house import server

    class OneAsk:
        """A stop raised after the first request."""
        seen = 0

        def raised(self):
            return self.seen > 0

    class Dummy:
        """A house that counts its looks."""
        looks = 0

        def ps(self):
            stop.seen += 1
            return {"models": []}

        def give_back(self):
            Dummy.looks += 1
            return []

        def put_down(self, name=""):
            return {"put_down": []}

    class Board:
        def register(self, name): pass
        def unregister(self): pass

    class Unfenced:
        def again(self): pass

    stop = OneAsk()
    serving = threading.Thread(target=server.serve, args=(tmp_path, tmp_path, Dummy(), stop, Board(), Unfenced()),
                               daemon=True)
    serving.start()
    address = server.address_file(tmp_path)
    for _ in range(200):
        if address.exists():
            break
        threading.Event().wait(0.05)
    port = json.loads(address.read_text())["port"]
    assert json.loads(urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ps", timeout=10).read()) == {"models": []}
    serving.join(timeout=30)
    assert not serving.is_alive() and Dummy.looks == 1
