# WARP2/warp2/house/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/__init__.py
#  Used by   : pytest, to import the tests in this directory as a package.
#  Uses      : nothing.
#  Description:
#    Package marker. Empty on purpose — test modules import what they test
#    directly, so nothing here should ever run at collection time.
#  User intention (Andrew):
#    Modular. Tests sit beside the thing they test, and importing one must not
#    drag in the others.
# ============================================================================
