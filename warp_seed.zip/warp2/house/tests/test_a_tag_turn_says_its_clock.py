# WARP2/warp2/house/tests/test_a_tag_turn_says_its_clock.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/tests/test_a_tag_turn_says_its_clock.py
#  Used by   : pytest (run_tests.py), CHECK_FIXES.bat.
#  Uses      : warp2/house/tag_lora.py, projects/behemoth_eye/eye/turn_clock.py;
#              torch (a one-weight stand-in model, so no real model is needed).
#  Description:
#    A tag turn's "began" line says how many seconds its turn had left when it
#    began (remaining_seconds_at_begin; null with no turn open). Its "ended"
#    line, on the same clock, says how long it ran (elapsed_seconds) and
#    whether the turn's time was up (clock_over), so a turn that stopped on
#    its clock reads apart from one that finished early. BUILD_LOG 1518.
#  User intention (Andrew, 2026-11-09 22:53): "All work on the warp should
#    use a set amount of compute and be built to do so." Suggested by Codex-424
#    via Muse-1626 (a contact's suggestion, taken on its merits).
# ============================================================================
"""A tag turn says its clock at its start and its end."""
from __future__ import annotations

import json
import sys
import types

import pytest

torch = pytest.importorskip("torch")

from warp2.house import tag_lora  # noqa: E402
from warp2.house.tag_lora import TagLora  # noqa: E402


class _Lessons:
    """Intention: ten tag lessons (five to learn, five held back)."""

    def lessons(self) -> list:
        """Intention: keys in order, as TagLessons gives them."""
        return [{"key": f"k{n:03d}", "prompt": f"p{n}", "answer": f"a{n}", "kind": "tags to tags"} for n in range(10)]


class _Model(torch.nn.Module):
    """Intention: one weight; a lesson's loss is its distance from 1."""

    def __init__(self) -> None:
        """Intention: the weight starts at nought."""
        super().__init__()
        self.weight = torch.nn.Parameter(torch.zeros(1))

    def save_pretrained(self, folder) -> None:
        """Intention: the adapter written as a real one is."""
        from pathlib import Path
        Path(folder).mkdir(parents=True, exist_ok=True)
        (Path(folder) / "adapter_config.json").write_text("{}", encoding="utf-8")


@pytest.fixture
def lora(tmp_path, monkeypatch):
    """Intention: a TagLora over the stand-in model, placed in memory; the adapter folder."""
    fake = types.ModuleType("warp2.room.split_load")
    fake.placement = lambda path, dtype, offload: {"where": "memory", "size": 0}
    monkeypatch.setitem(sys.modules, "warp2.room.split_load", fake)
    monkeypatch.setattr(TagLora, "_load", lambda self, where: (_Model(), None))
    monkeypatch.setattr(TagLora, "_loss", lambda self, model, tokenizer, lesson: ((model.weight - 1.0) ** 2).sum())
    monkeypatch.setattr(TagLora, "_type", staticmethod(lambda: "float32"))
    monkeypatch.setattr(tag_lora, "learning_rate", lambda: 0.1)
    entry = {"name": "tiny", "path": str(tmp_path / "model")}
    return (lambda: TagLora(tmp_path, tmp_path / "state", entry, lessons=_Lessons()),
            tmp_path / "state" / "house" / "adapters" / "tiny")


def _lines(adapter) -> list:
    """Intention: every line of the adapter's turn log."""
    return [json.loads(line) for line in (adapter / "turns.jsonl").read_text(encoding="utf-8").splitlines()]


def test_began_says_the_seconds_left_and_ended_says_the_time_spent(lora):
    """Intention: inside a 60 s turn, began has about 60 s left; ended has the seconds spent and the clock not over."""
    from projects.behemoth_eye.eye.turn_clock import turn
    make, adapter = lora
    with turn(60.0):
        make().teach()
    began, ended = _lines(adapter)
    assert 0.0 < began["remaining_seconds_at_begin"] <= 60.0
    assert ended["elapsed_seconds"] >= 0.0 and ended["clock_over"] is False


def test_no_turn_open_is_null_not_a_number(lora):
    """Intention: with no turn open there is no budget: null, never a made-up number."""
    make, adapter = lora
    make().teach()
    began, ended = _lines(adapter)
    assert "remaining_seconds_at_begin" in began and began["remaining_seconds_at_begin"] is None
    assert ended["clock_over"] is False and ended["elapsed_seconds"] >= 0.0


def test_a_turn_whose_time_ran_out_says_so(lora, monkeypatch):
    """Intention: the turn's time is up by the end; ended says clock_over true."""
    from projects.behemoth_eye.eye import turn_clock
    make, adapter = lora
    with turn_clock.turn(60.0) as clock:
        def late(self, model, tokenizer, lessons):
            clock.deadline = turn_clock.time.monotonic() - 1.0
            return 1
        monkeypatch.setattr(TagLora, "_learn", late)
        make().teach()
    _began, ended = _lines(adapter)
    assert ended["clock_over"] is True
