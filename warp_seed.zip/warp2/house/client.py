# WARP2/warp2/house/client.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/client.py
#  Used by   : warp2/models/roster.py (a "house" model's answers),
#              warp2/ask/subconcepts.py (the guesses), warp2/house/tag_lora.py
#              (the house puts its models down before a lesson),
#              warp2/house/picture_reader.py (a picture read),
#              warp2/work/side/house_steps.py (the drawings).
#  Uses      : warp2/house/server.py (address_file; started as
#              python -m warp2.house.server), warp2/record/{quiet,kept_file}.py,
#              warp2/record/heartbeat.py (how often to look while it starts);
#              psutil; stdlib json, subprocess, sys, time, urllib.
#  Description:
#    ASKING THE HOUSE. The house is found where it said it listens; when it is
#    not there (never started, or ended), it is started - once - and waited for
#    until it says where it is, or until the process it started has ended (then
#    it says why). There is no clock on an answer: loading a model to fit can
#    take as long as it takes; a house that died is seen as a refused
#    connection.
#  User intention (Andrew, 2026-11-09 19:05): "a system that holds models like
#    ollama and comfy could inside the warp". (BUILD_LOG 1484.)
# ============================================================================
"""Asking the house: found where it listens, started when it is not there."""
from __future__ import annotations

import json
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path


class HouseUnreachable(RuntimeError):
    """Intention: the house could not be found or started, and why."""


class HouseClient:
    """The house, as the rest of the WARP asks it."""

    def __init__(self, root, state, opener=None) -> None:
        """Intention: the WARP's root and state; `opener` is urllib's unless a test gives its own."""
        self.root, self.state = Path(root), Path(state)
        self.opener = opener or urllib.request.urlopen

    def _base(self) -> str:
        """Intention: the house's address when it is listening now; "" when it is not."""
        from warp2.house.server import address_file
        from warp2.record.kept_file import UnreadableKept, read_kept
        try:
            said = read_kept(address_file(self.state), {})
        except UnreadableKept:  # fault: ok - an address being written is read again on the next look
            return ""
        if not said.get("port"):
            return ""
        base = f"http://{said.get('host', '127.0.0.1')}:{int(said['port'])}"
        try:
            with self.opener(urllib.request.Request(base + "/api/ps")) as answer:
                answer.read()
            return base
        except (urllib.error.URLError, OSError):  # fault: ok - nothing listening there means the house is not up
            return ""

    def start(self) -> str:
        """Intention: the house started and waited for; its address. HouseUnreachable when it ended first."""
        from warp2.house.server import address_file
        from warp2.record import heartbeat
        address_file(self.state).unlink(missing_ok=True)
        (self.state / "house").mkdir(parents=True, exist_ok=True)
        log = open(self.state / "house" / "house.log", "a", encoding="utf-8")
        proc = self._spawn(log)
        log.close()
        while True:
            base = self._base()
            if base:
                return base
            if proc.poll() is not None:
                raise HouseUnreachable(f"the house ended as it started (exit {proc.returncode}); "
                                       f"see {self.state / 'house' / 'house.log'}")
            time.sleep(float(heartbeat.BEAT_SECONDS) / 4.0)

    def _spawn(self, log):
        """The house's process, started outside whatever fence the asker is in.

        Intention (BUILD_LOG 1487): the house outlives the step that first asked it; started inside that step's
        fence it would keep that step's room for ever. Where the asker's fence does not let a child leave (one made
        before this build), the house is started the plain way.
        """
        from warp2.record.quiet import quiet
        command = [sys.executable, "-m", "warp2.house.server", str(self.root), str(self.state)]
        plain = quiet()
        away = dict(plain, creationflags=plain.get("creationflags", 0) | getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0))
        for how in (away, plain):
            try:
                return subprocess.Popen(command, cwd=str(self.root), stdout=log, stderr=subprocess.STDOUT,
                                        stdin=subprocess.DEVNULL, **how)
            except OSError:  # fault: ok - a fence that lets nothing leave refuses the first way; the plain way follows
                if how is plain:
                    raise

    def _post(self, path: str, body: dict) -> dict:
        """Intention: one request to the house, starting it when it is not there."""
        base = self._base() or self.start()
        request = urllib.request.Request(base + path, data=json.dumps(body).encode("utf-8"),
                                         headers={"Content-Type": "application/json"})
        try:
            with self.opener(request) as answer:
                return json.loads(answer.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            said = exc.read().decode("utf-8", errors="replace")
            raise HouseUnreachable(f"{exc.code}: {json.loads(said).get('error', said) if said.startswith('{') else said}")

    def chat(self, model: str, prompt: str, tokens: int = 0) -> str:
        """Intention: a house language model's answer."""
        got = self._post("/api/chat", {"model": model, "prompt": str(prompt), "options": {"num_predict": int(tokens)}})
        return str((got.get("message") or {}).get("content") or "")

    def draw(self, model: str, prompt: str, seed: int = 0, steps: int = 0, width: int = 0, height: int = 0) -> dict:
        """Intention: a house picture model's picture, saved by the house; where it is and how it was drawn."""
        return self._post("/api/draw", {"model": model, "prompt": str(prompt), "seed": int(seed), "steps": int(steps),
                                        "width": int(width), "height": int(height)})

    def read(self, model: str, image: str, subject: str, reference: str = "") -> dict:
        """Intention (BUILD_LOG 1485): a house picture reader's chance that the picture shows the subject."""
        return self._post("/api/read", {"model": model, "image": str(image), "subject": str(subject),
                                        "reference": str(reference or "")})

    def put_down(self, model: str = "") -> dict:
        """Intention: one model put down, or all of them; nothing to do when the house is not up."""
        if not self._base():
            return {"put_down": []}
        return self._post("/api/put_down", {"model": model})
