# WARP2/warp2/house/held_small/model_files.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/model_files.py
#  Used by   : warp2/house/held_small/{text_base,reader_base,picture_parts,
#              adapter_on}.py.
#  Uses      : warp2/record/kept_file.py; stdlib pathlib.
#  Description:
#    THE WEIGHT FILES A MODEL FOLDER IS LOADED FROM - the same ones the
#    libraries read, no others that may lie beside them: the shards its
#    index names (model.safetensors.index.json), else the one file of the
#    given name, with its variant (fp16) when asked. An empty list means the
#    folder has no safetensors weights of that name.
#  User intention (Andrew, 2026-11-12 09:09): the internal models "stored and
#    working from the dehydrated tag form". (BUILD_LOG 1563.)
# ============================================================================
"""The weight files a model folder is loaded from: its index's shards, or its one file, with a variant when asked."""
from __future__ import annotations

from pathlib import Path


def _present(path: Path, door=None, root=None) -> bool:
    """Intention: whether this weight file is on disk or held in the small form."""
    return path.is_file() or (door is not None and door.beside(root or path.parent, path).is_file())


def model_files(folder, name: str = "model", variant: str = "", door=None, root=None) -> list:
    """Intention: the safetensors files this folder's model is read from, in order (on disk or held small)."""
    from warp2.record.kept_file import read_kept
    folder = Path(folder)
    stem = f"{name}.{variant}" if variant else name
    index = read_kept(folder / f"{stem}.safetensors.index.json", None)
    if isinstance(index, dict) and isinstance(index.get("weight_map"), dict):
        shards = sorted(set(index["weight_map"].values()))
        return [folder / shard for shard in shards] if all(
            _present(folder / shard, door, root or folder) for shard in shards
        ) else []
    one = folder / f"{stem}.safetensors"
    return [one] if _present(one, door, root or folder) else []
