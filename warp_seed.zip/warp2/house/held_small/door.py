# WARP2/warp2/house/held_small/door.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/door.py
#  Used by   : warp2/house/held_small/{text_base,reader_base,keep}.py, tests/.
#  Uses      : warp2/house/held_small/weights_form.py,
#              projects/behemoth_eye/eye/held_small/book.py (TensorBook),
#              warp2/record/kept_file.py; stdlib os, pathlib, re.
#  Description:
#    THE DOOR BETWEEN A MODEL'S WEIGHT FILES AND THE TENSOR BOOK. A weight
#    file is kept small under <state>/house/models_small/<model>/<file>.json,
#    stamped with the file's size and time; its tensors go to the one book
#    beside (<state>/house/models_small/book). A model is read from the small
#    form only when every one of its weight files has a small form whose
#    stamp is that file's size and time now - a file changed since is read
#    as a file, never from an older small form. The weight files stay where
#    they are: they are the saved copy.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    2026-11-11 18:40: "the important thing is that ours are faster than
#    normal files". (BUILD_LOG 1562.)
# ============================================================================
"""A model's weight files kept small beside the state, and read from there while they still match the files."""
from __future__ import annotations

import os
import re
from pathlib import Path

# Intention: the weight files this door keeps.
WEIGHTS = "*.safetensors"


def stamp_of(file) -> list:
    """Intention: what a weight file is now - its size and the time it was written."""
    now = os.stat(file)
    return [int(now.st_size), int(now.st_mtime_ns)]


def safe(name: str) -> str:
    """Intention: a name as a folder or file name."""
    return re.sub(r"[^A-Za-z0-9._-]+", "_", str(name)).strip("_") or "model"


class WeightsDoor:
    """Intention: one home for every model's small form - its book opened the first time it is needed, then kept."""

    def __init__(self, home) -> None:
        """Intention: where the small forms and their book live."""
        self.home = Path(home)
        self.form = None

    def _form(self):
        """Intention: the book, opened once."""
        if self.form is None:
            from projects.behemoth_eye.eye.held_small.book import TensorBook
            from warp2.house.held_small.weights_form import WeightsForm
            self.form = WeightsForm(TensorBook(self.home / "book"))
        return self.form

    def beside(self, folder, file) -> Path:
        """Intention: where one weight file's small form is kept."""
        inside = "__".join(Path(file).relative_to(folder).parts)
        return self.home / safe(Path(folder).name) / (safe(inside) + ".json")

    def keep(self, folder, file) -> dict:
        """Intention: one weight file kept small and stamped; what was kept."""
        from warp2.record.kept_file import read_kept, write_kept
        stamp = stamp_of(file)
        before = read_kept(self.beside(folder, file), None)
        kept = {"stamp": stamp, **self._form().small(file)}
        write_kept(self.beside(folder, file), kept)
        if isinstance(before, dict):
            # Intention (BUILD_LOG 1568): once the new small form is on disk, the one it replaced lets go of its
            # tensors - an adapter taught again does not make the book grow.
            self._form().let_go(before)
        return kept

    def read(self, folder, file):
        """Intention: a weight file's small form, or None when the file must be read - none kept, or one stamped for
        an older writing of the file. When the original file is no longer on disk, the small form is the copy."""
        from warp2.record.kept_file import read_kept
        kept = read_kept(self.beside(folder, file), None)
        if not isinstance(kept, dict) or "tensors" not in kept:
            return None
        if Path(file).is_file() and kept.get("stamp") != stamp_of(file):
            return None
        return kept

    def fresh(self, folder, file) -> bool:
        """Intention: whether this weight file's small form is kept and still matches it."""
        return self.read(folder, file) is not None

    def whole(self, folder, files) -> dict | None:
        """Intention: every tensor of these weight files by name, from their small forms - None when any one of the
        files has none that still matches it."""
        tensors = {}
        for file in files:
            kept = self.read(folder, file)
            if kept is None:
                return None
            tensors.update(kept["tensors"])
        return tensors

    def still(self, folder, files) -> bool:
        """Intention (BUILD_LOG 1568): whether every one of these files' small forms still matches its file - asked
        AFTER a model was filled, because a file written again meanwhile may have had its tensors' places given to
        others, and a model filled across that is not used."""
        return all(self.fresh(folder, file) for file in files)

    def tensor(self, kept: dict):
        """Intention: one tensor back from the book."""
        return self._form().tensor(kept)

    def close(self) -> None:
        """Intention: the book let go."""
        if self.form is not None:
            self.form.book.close()
            self.form = None


DOORS: dict = {}


def door_of(home) -> WeightsDoor:
    """Intention: one door for each home in this process."""
    key = str(Path(home))
    if key not in DOORS:
        DOORS[key] = WeightsDoor(home)
    return DOORS[key]


def small_home(state) -> Path:
    """Intention: where the house's small forms live."""
    return Path(state) / "house" / "models_small"
