# WARP2/warp2/house/held_small/floating_buffer.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/floating_buffer.py
#  Used by   : warp2/house/held_small/text_base.py (when a model is larger
#              than card + memory and split to disk), tests/.
#  Uses      : warp2/house/held_small/filled.py (device_of, NotFilled);
#              accelerate (set_module_tensor_to_device), torch.
#  Description:
#    FLOATING LAYER BUFFER FROM THE TENSOR BOOK. When a language model does
#    not fit in the card and memory together (`split to disk`), the layers
#    assigned to `"disk"` stay on `meta` (taking zero memory while idle) and
#    each offloaded module streams its tensors directly from the TensorBook
#    just before its forward pass and releases them back to `meta` the moment
#    its forward pass finishes. No second copy of the weights is written to an
#    offload folder, and the model runs even when the original `.safetensors`
#    files have been sent to deep storage.
#  User intention (Andrew, 2026-11-11 17:55, 21:31): "Yes like it has a
#    floating storage that buffers" - "And in some cases you can run the model
#    in one part at a time in the same way so the part can be larger".
#    BUILD_LOG 1581.
# ============================================================================
"""Stream offloaded model layers one part at a time directly from the TensorBook during forward passes."""
from __future__ import annotations

from warp2.house.held_small.filled import NotFilled, device_of


def _first_tensor_device(item, fallback: str = "cpu"):
    """Intention: find the device of the first tensor in args/kwargs so a streamed layer matches its input."""
    import torch
    if torch.is_tensor(item):
        return item.device if item.device.type != "meta" else torch.device(fallback)
    if isinstance(item, (list, tuple)):
        for sub in item:
            found = _first_tensor_device(sub, "")
            if found != "":
                return found
    if isinstance(item, dict):
        for sub in item.values():
            found = _first_tensor_device(sub, "")
            if found != "":
                return found
    return torch.device(fallback) if fallback else ""


class FloatingLayerBuffer:
    """Intention: fill resident parts once and stream `"disk"`-mapped parts from the TensorBook one layer at a time."""

    def __init__(self, door, tensors: dict, kind, device_map: dict) -> None:
        """Intention: remember the TensorBook door, tensor map, target dtype, and device map."""
        self.door = door
        self.tensors = tensors
        self.kind = kind
        self.device_map = dict(device_map)
        self.loads = 0
        self.releases = 0
        self.hooks = []

    def fill_and_attach(self, model) -> int:
        """Intention: validate all model tensors exist in `tensors`, fill non-disk tensors, and hook disk modules."""
        from accelerate.utils import set_module_tensor_to_device
        state_keys = set(model.state_dict().keys())
        own_buffers = {name for name, _value in model.named_buffers()} - state_keys
        strangers = sorted(set(self.tensors) - state_keys - own_buffers)
        if strangers:
            raise NotFilled(f"{len(strangers)} kept tensors are not parts of this model (first: {strangers[0]})")

        # Keep input/output embeddings resident on CPU when tied, so weight tying never points at a meta tensor.
        tied_prefixes = set()
        for getter in ("get_input_embeddings", "get_output_embeddings"):
            fn = getattr(model, getter, None)
            mod = fn() if callable(fn) else None
            if mod is not None:
                for mod_name, candidate in model.named_modules():
                    if candidate is mod and mod_name:
                        tied_prefixes.add(mod_name)

        disk_tensors: dict[str, list[str]] = {}
        filled_count = 0
        for name in state_keys:
            if name not in self.tensors:
                # Check if this is a tied weight whose partner is in self.tensors
                continue
            where = device_of(name, self.device_map)
            is_tied = any(name == p or name.startswith(p + ".") for p in tied_prefixes)
            if str(where) == "disk" and not is_tied:
                mod_prefix = self._disk_module_for(name)
                disk_tensors.setdefault(mod_prefix, []).append(name)
            else:
                target_dev = "cpu" if str(where) == "disk" else where
                val = self.door.tensor(self.tensors[name])
                set_module_tensor_to_device(
                    model,
                    name,
                    target_dev,
                    value=val,
                    dtype=self.kind if val.is_floating_point() else None,
                )
                filled_count += 1

        model.tie_weights()
        # Verify every parameter is either materialized (resident) or registered under a streamed disk module.
        streamed_names = {n for names in disk_tensors.values() for n in names}
        missing = [
            name for name, val in model.state_dict().items()
            if val.is_meta and name not in streamed_names
        ]
        if missing:
            raise NotFilled(f"{len(missing)} parts of the model were not filled (first: {missing[0]})")

        # Attach pre/post forward hooks to each module mapped to disk.
        modules_by_name = dict(model.named_modules())
        for mod_name, tensor_names in disk_tensors.items():
            module = modules_by_name.get(mod_name)
            if module is None:
                raise NotFilled(f"disk module {mod_name!r} not found in model")
            self._hook_module(model, module, tensor_names)

        model._floating_buffer = self
        return filled_count + len(streamed_names)

    def _disk_module_for(self, tensor_name: str) -> str:
        """Intention: find the module name in `device_map` mapped to `'disk'` that owns `tensor_name`."""
        part = tensor_name.rpartition(".")[0]
        while part:
            if part in self.device_map and str(self.device_map[part]) == "disk":
                return part
            part = part.rpartition(".")[0]
        return tensor_name.rpartition(".")[0]

    def _hook_module(self, model, module, tensor_names: list[str]) -> None:
        """Intention: materialize `tensor_names` from the TensorBook before `module.forward` and release after."""
        from accelerate.utils import set_module_tensor_to_device

        def _pre_hook(_mod, args, kwargs):
            """Intention: stream this module's tensors from the book onto the active execution device."""
            dev = _first_tensor_device((args, kwargs), fallback="cpu")
            for full_name in tensor_names:
                val = self.door.tensor(self.tensors[full_name])
                set_module_tensor_to_device(
                    model,
                    full_name,
                    dev,
                    value=val,
                    dtype=self.kind if val.is_floating_point() else None,
                )
            self.loads += 1

        def _post_hook(_mod, _args, _output):
            """Intention: release this module's streamed tensors back to meta immediately after forward."""
            for full_name in tensor_names:
                set_module_tensor_to_device(model, full_name, "meta")
            self.releases += 1

        self.hooks.append(module.register_forward_pre_hook(_pre_hook, with_kwargs=True))
        self.hooks.append(module.register_forward_hook(_post_hook))
