# WARP2/warp2/house/held_small/reader_base.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/reader_base.py
#  Used by   : warp2/house/reader_runner.py (the picture reader the house
#              loads), tests/.
#  Uses      : warp2/house/held_small/{door,filled,model_files}.py;
#              transformers, accelerate, torch (only when it is loaded).
#  Description:
#    THE PICTURE READER (CLIP) LOADED FROM ITS SMALL FORM. Built empty from
#    its config and filled from the tensor book a tensor at a time, in
#    memory, as the kind its files give by default (float32) - the runner
#    then puts it on the card or leaves it, as before. None, and the weight
#    file is read, when it has no small form that still matches or the
#    filling is not whole (said in the log).
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    (BUILD_LOG 1563.)
# ============================================================================
"""The picture reader built empty and filled from its small form; None when its weight file must be read."""
from __future__ import annotations

import logging
from pathlib import Path

SAID = logging.getLogger(__name__)


class ReaderBase:
    """Intention: the picture reader's model, from the book."""

    def __init__(self, door) -> None:
        """Intention: the door its small form is read through."""
        self.door = door

    def load(self, path):
        """Intention: the model in memory, filled; None when its weight file must be read instead."""
        from warp2.house.held_small.model_files import model_files
        files = model_files(path, door=self.door)
        tensors = self.door.whole(path, files) if files else None
        if tensors is None:
            return None
        import torch
        from accelerate import init_empty_weights
        from transformers import CLIPConfig, CLIPModel
        from warp2.house.held_small.filled import Filled
        with init_empty_weights():
            model = CLIPModel(CLIPConfig.from_pretrained(str(path)))
        filled = Filled(self.door)
        filled.fill(model, tensors, torch.float32, {"": "cpu"})
        filled.whole(model)
        if not self.door.still(path, files):   # BUILD_LOG 1568: a weight file written again while this was filled may have had its places given away
            return None
        model.config.name_or_path = str(path)
        return model.eval()


def reader_from_book(path, home):
    """Intention: for the reader runner - the model from its small form, or None to read its weight file. A filling
    that fails is said and the file is read; the file is the saved copy."""
    if not home:
        return None
    from warp2.house.held_small.door import door_of
    try:
        return ReaderBase(door_of(home)).load(path)
    except Exception as err:  # fault: ok - the weight file is the saved copy; the small form is only missed, and said
        SAID.warning("%s not loaded from its small form (%s: %s); its weight file is read",
                     Path(path).name, type(err).__name__, err)
        return None
