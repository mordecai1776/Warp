# WARP2/warp2/house/held_small/text_base.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/text_base.py
#  Used by   : warp2/house/text_runner.py (the base model of a language
#              model the house loads), tests/.
#  Uses      : warp2/house/held_small/{door,filled,model_files}.py; transformers,
#              accelerate, torch (only when a model is loaded).
#  Description:
#    A LANGUAGE MODEL LOADED FROM ITS SMALL FORM. The model is built empty
#    from its config, its layers are given their places (all on the card, or
#    split between the card and memory by the room handed in), and it is
#    filled from the tensor book a tensor at a time. It is then the same
#    model the weight files give: the same kind, the same tied parts, the
#    same way of writing an answer (its generation config). None is handed
#    back - and the weight files are read as before - when the model has no
#    small form that still matches its files, when part of it would have to
#    wait on disk, or when the filling does not come out whole; the last is
#    said in the log.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    (BUILD_LOG 1562.)
# ============================================================================
"""A language model built empty and filled from its small form; None when its weight files must be read."""
from __future__ import annotations

import logging
from pathlib import Path

SAID = logging.getLogger(__name__)

# Intention: how the placement (warp2/room/split_load.py) names a model that does not fit the card and memory.
TO_DISK = "split to disk"


def weight_files(folder, door=None) -> list:
    """Intention: the weight files a language model is loaded from (its index's shards, or its one file)."""
    from warp2.house.held_small.model_files import model_files
    return model_files(folder, door=door)


class TextBase:
    """Intention: one language model's base, from the book."""

    def __init__(self, door) -> None:
        """Intention: the door its small form is read through."""
        self.door = door

    def places(self, model, kind, placed: dict) -> dict:
        """Intention: where each part of the model goes, from the placement already measured."""
        import torch
        asked = placed.get("kwargs") or {}
        if "max_memory" in asked:
            from accelerate import infer_auto_device_map
            return dict(infer_auto_device_map(model, max_memory=asked["max_memory"], dtype=kind,
                                              no_split_module_classes=getattr(model, "_no_split_modules", None)))
        return {"": 0 if asked.get("device_map") == "auto" and torch.cuda.is_available() else "cpu"}

    def load(self, path, load_as: str, placed: dict):
        """Intention: the model, filled and placed (streaming offloaded layers from the book when split to disk);
        None when its weight files must be read instead."""
        files = weight_files(path, door=self.door)
        tensors = self.door.whole(path, files) if files else None
        asked = placed.get("kwargs") or {}
        if tensors is None or (placed.get("where") == TO_DISK and "max_memory" not in asked):
            return None
        import torch
        from accelerate import dispatch_model, init_empty_weights
        from transformers import AutoConfig, AutoModelForCausalLM, GenerationConfig
        from warp2.house.held_small.filled import Filled
        from warp2.house.held_small.floating_buffer import FloatingLayerBuffer
        kind = getattr(torch, load_as)
        config = AutoConfig.from_pretrained(str(path))
        with init_empty_weights():
            model = AutoModelForCausalLM.from_config(config, torch_dtype=kind)
        model.tie_weights()
        device_map = self.places(model, kind, placed)
        if any(str(where) == "disk" for where in device_map.values()):
            FloatingLayerBuffer(self.door, tensors, kind, device_map).fill_and_attach(model)
            if not self.door.still(path, files):
                return None
        else:
            filled = Filled(self.door)
            filled.fill(model, tensors, kind, device_map)
            model.tie_weights()
            filled.whole(model)
            if not self.door.still(path, files):   # BUILD_LOG 1568: a weight file written again while this was filled may have had its places given away
                return None
            if len(set(device_map.values())) == 1:
                model = model.to(next(iter(device_map.values())))
            else:
                model = dispatch_model(model, device_map=device_map)
        model.config.name_or_path = str(path)
        if model.can_generate() and (Path(path) / "generation_config.json").is_file():
            model.generation_config = GenerationConfig.from_pretrained(str(path))
        return model.eval()


def base_from_book(path, load_as: str, placed: dict, home):
    """Intention: for the text runner - the base model from its small form, or None to read its weight files. A
    filling that fails is said and the files are read; the files are the saved copy."""
    if not home:
        return None
    from warp2.house.held_small.door import door_of
    try:
        return TextBase(door_of(home)).load(path, load_as, placed)
    except Exception as err:  # fault: ok - the weight files are the saved copy; the small form is only missed, and said
        SAID.warning("%s not loaded from its small form (%s: %s); its weight files are read",
                     Path(path).name, type(err).__name__, err)
        return None
