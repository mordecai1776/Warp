# WARP2/warp2/house/held_small/picture_parts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/picture_parts.py
#  Used by   : warp2/house/image_runner.py (the picture model the house
#              loads), tests/.
#  Uses      : warp2/house/held_small/{door,filled,model_files}.py,
#              warp2/record/kept_file.py; diffusers, transformers,
#              accelerate, torch (only when it is loaded).
#  Description:
#    THE PICTURE MODEL'S PARTS LOADED FROM THEIR SMALL FORMS. A diffusers
#    pipeline's model_index.json names its parts; each part that has weights
#    (the unet, the vae, the text encoder, the safety checker) is built empty
#    from its own config and filled from the tensor book a tensor at a time,
#    as the kind the pipeline is loaded as. The parts are handed to the
#    pipeline, which then reads none of their weight files. None - and the
#    pipeline reads its files as before - when any part has no small form
#    that still matches, or a filling is not whole (said in the log); never
#    some parts from the book and a part half filled.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    (BUILD_LOG 1563.)
# ============================================================================
"""A picture pipeline's weighted parts built empty and filled from their small forms; None when files must be read."""
from __future__ import annotations

import logging
from pathlib import Path

SAID = logging.getLogger(__name__)

# Intention: the file name each library gives a part's weights.
WEIGHTS_NAME = {"diffusers": "diffusion_pytorch_model"}


class PictureParts:
    """Intention: one pipeline's weighted parts, from the book."""

    def __init__(self, door) -> None:
        """Intention: the door the small forms are read through."""
        self.door = door

    @staticmethod
    def named(path) -> dict:
        """Intention: {part: (library, class name)} for the parts the pipeline's index names with a folder of their own."""
        from warp2.record.kept_file import read_kept
        index = read_kept(Path(path) / "model_index.json", {})
        return {part: tuple(made) for part, made in index.items()
                if isinstance(made, list) and len(made) == 2 and all(made) and (Path(path) / part).is_dir()}

    @staticmethod
    def empty(library: str, kind_name: str, folder):
        """Intention: the part built with empty weights from its own config."""
        from accelerate import init_empty_weights
        if library == "diffusers":
            import diffusers
            made = getattr(diffusers, kind_name)
            with init_empty_weights():
                return made.from_config(made.load_config(str(folder)))
        if library == "transformers":
            import transformers
            made = getattr(transformers, kind_name)
        else:
            from diffusers.pipelines.stable_diffusion import safety_checker
            made = getattr(safety_checker, kind_name)
        with init_empty_weights():
            return made(made.config_class.from_pretrained(str(folder)))

    def load(self, path, variant: str, kind) -> dict | None:
        """Intention: {part: model} for every part with weights, filled as `kind`; None when any must be read from files."""
        from warp2.house.held_small.filled import Filled
        from warp2.house.held_small.model_files import model_files
        parts = {}
        for part, (library, kind_name) in self.named(path).items():
            folder = Path(path) / part
            files = model_files(folder, WEIGHTS_NAME.get(library, "model"), variant, door=self.door, root=path)
            if not files and not any(folder.glob("*.safetensors")) and not any(folder.glob("*.bin")):
                continue
            tensors = self.door.whole(path, files) if files else None   # kept under the pipeline's own folder
            if tensors is None:
                return None
            model = self.empty(library, kind_name, folder)
            filled = Filled(self.door)
            filled.fill(model, tensors, kind, {"": "cpu"})
            filled.whole(model)
            if not self.door.still(path, files):   # BUILD_LOG 1568: a weight file written again while this was filled may have had its places given away
                return None
            parts[part] = model.to(kind).eval()
        return parts or None


def parts_from_book(path, variant: str, kind, home) -> dict:
    """Intention: for the image runner - the weighted parts from their small forms, or {} to read the files. A filling
    that fails is said and the files are read; the files are the saved copy."""
    if not home:
        return {}
    from warp2.house.held_small.door import door_of
    try:
        return PictureParts(door_of(home)).load(path, variant, kind) or {}
    except Exception as err:  # fault: ok - the weight files are the saved copy; the small form is only missed, and said
        SAID.warning("%s not loaded from its small form (%s: %s); its weight files are read",
                     Path(path).name, type(err).__name__, err)
        return {}
