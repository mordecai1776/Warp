# WARP3/warp2/house/held_small/book_linear.py
#
# Pathway   : warp2/house/held_small/book_linear.py
# Used by   : house/held_small/small_fill.py for exact forms without row arithmetic.
# Uses      : torch; the tensor-book door supplied by the loader.
# Description: A frozen linear base reads its exact stored operand only while computing; backward reads it again.
# User intention: Andrew, 2026-11-19: stored parts remain remembered and the working footprint stays small.
# BUILD_LOG 1951h (Claude, hourly run, 2026-11-20): WHILE ONE ANSWER IS BEING MADE, A WEIGHT ONCE READ IS KEPT
#   ON ITS DEVICE, AS FAR AS THE ROOM GOES. Measured 2026-11-20 00:59 UTC (py-spy, state/control/commands/out/
#   house_raw_0110.txt): of the house's time on a qwen3-1.7b answer, 61% was reading each layer's bytes off the
#   book's pages and 28% putting them on the card - again for every token - so answers of usually 71 s took
#   4,000-5,000 s and the main lane waited hours. Now `held_for_an_answer(model)` holds each weight it reads for
#   the rest of that answer while the device keeps at least half the room it had when the answer began (the
#   room the device has, not a set number); every held weight is let go when the answer ends. Between answers,
#   and in training (backward), nothing is held - as before.
#   Andrew 2026-11-10 20:09: "This should dramaticly shorten everything that uses them in the time they take."
#   2026-11-11 18:40: "the important thing is that ours are faster than normal files".
#   2026-11-09 18:37: "if it doesn't have enough, it needs to adjust. If it has more, it needs to adjust to that."
# BUILD_LOG 2271 (Claude, hourly run, 2026-11-26): WHILE AN ADAPTER IS PUT ON, EACH LAYER'S WEIGHT IS READ ONCE.
#   Measured (state/control/commands/out/claude-hourly-1400-adapterprof.txt): putting the coder's tag adapter on
#   read base weights off the book 4,116 times for 196 layers (384 of 392 s) - peft asks each layer's weight about
#   21 times only to learn its device and kind. `held_one_at_a_time(model)` keeps the weight last read until the
#   next layer reads its own, so one layer's weight is held at a time and each is read once.
# BUILD_LOG 2273 (Claude, hourly run, 2026-11-26): WHILE AN ADAPTER IS PUT ON, NO BASE WEIGHT IS READ AT ALL.
#   After 2271 the one read per layer was still most of a load (live: coder adapter 20.7-22.0 s, qwen3 21-25 s,
#   of loads of 22-28 s; profile: 196 reads, ~0.09 s each). peft asks a base weight only for its shape, device and
#   kind while it puts a plain LoRA on. `shapes_only(model)` answers those asks with an unfilled tensor of the
#   weight's shape, device and kind; the book is not read. Used only when the adapter's config says its values
#   are not needed (adapter_on.py `values_unused`); otherwise held_one_at_a_time, as before.
# BUILD_LOG 2349 (Claude, hourly run, 2026-11-28): AN ANSWER LEAVES THE CARD ROOM FOR ITS OWN ATTENTION, AND
#   MEMORY THAT SPILLED PAST THE CARD IS NOT ROOM. Live 2026-11-28 00:21Z (house residency, granite-4.1-3b, 700.9 s,
#   status 500): "CUDA out of memory. Tried to allocate 1.40 GiB. GPU 0 has a total capacity of 7.96 GiB of which 0
#   bytes is free. Of the allocated memory 12.38 GiB is allocated by PyTorch" - in scaled_dot_product_attention,
#   after 617 s of work. Two things let it happen: the floor was only half the room at the start, whatever the
#   prompt's attention needs; and the card's free count can stay up while what torch holds has passed the card.
#   Now `room_on` gives a card's room as the smaller of its free count and its total less what torch has reserved,
#   and `held_for_an_answer(model, keep=...)` keeps at least `keep` bytes free (text_runner.attention_room).
#   Andrew 2026-11-09 18:37: "if it doesn't have enough, it needs to adjust. If it has more, it needs to adjust to
#   that."
"""A linear layer backed by its exact book form, without a persistent dense weight."""
from __future__ import annotations

from contextlib import contextmanager

import torch


def room_on(device) -> int | None:
    """Intention: the bytes free on a device now - the card's own count, or the machine's free memory; None when
    it cannot be read (then nothing is held)."""
    device = torch.device(device)
    try:
        if device.type == "cuda":
            # Intention (BUILD_LOG 2349): what torch holds past the card's size is not room on the card.
            free, total = torch.cuda.mem_get_info(device)
            return max(0, min(int(free), int(total) - int(torch.cuda.memory_reserved(device))))
        import psutil
        return int(psutil.virtual_memory().available)
    except Exception:  # fault: ok - a room that cannot be read holds nothing; the layer reads its weight each time
        return None


class AnswerHold:
    """Intention: the weights held during one answer, and the room each device must keep - half its room at the
    start."""

    def __init__(self, room=room_on, keep: int = 0) -> None:
        """Intention: nothing held; the room reader is given so a test can say the room. BUILD_LOG 2349: `keep` is
        the least room each device keeps free whatever it began with - the room the answer's own work needs."""
        self.room, self.floor, self.layers, self.keep = room, {}, [], max(0, int(keep or 0))

    def keeps(self, device, size: int) -> bool:
        """Intention: whether a weight of `size` bytes may be held on `device` and leave it its floor."""
        key = str(torch.device(device))
        if key not in self.floor:
            start = self.room(device)
            self.floor[key] = None if start is None else max(start // 2, self.keep)
        floor, now = self.floor[key], self.room(device)
        return floor is not None and now is not None and now - int(size) >= floor

    def let_go(self) -> None:
        """Intention: every weight held for this answer let go."""
        for layer in self.layers:
            layer.held = None
        self.layers = []


class OneHeld(AnswerHold):
    """Intention (BUILD_LOG 2271): one weight held at a time - the last one read; a new read lets the others go."""

    def keeps(self, device, size: int) -> bool:
        """Intention: always keep the new weight, after letting go of the one held before."""
        self.let_go()
        return True


class ShapesOnly(AnswerHold):
    """Intention (BUILD_LOG 2273): a weight asked only for its shape, device and kind - nothing read, nothing held."""

    shape_only = True

    def keeps(self, device, size: int) -> bool:
        """Intention: never hold; the weight answered here is an unfilled stand-in."""
        return False


@contextmanager
def shapes_only(model):
    """Intention (BUILD_LOG 2273): during the `with`, each BookLinear's weight is an unfilled tensor of its shape,
    device and kind - for work that asks only those (peft putting a plain LoRA on); the book is not read."""
    with held_by(model, ShapesOnly()) as hold:
        yield hold


@contextmanager
def held_one_at_a_time(model):
    """Intention (BUILD_LOG 2271): during the `with`, the last weight read stays held until the next layer reads its
    own - so work that walks the layers one by one (putting an adapter on) reads each weight once, and holds one."""
    with held_by(model, OneHeld()) as hold:
        yield hold


@contextmanager
def held_for_an_answer(model, room=room_on, keep: int = 0):
    """Intention: during the `with`, each BookLinear in `model` keeps the weight it read while there is room; all
    let go at the end, whatever happened. BUILD_LOG 2349: at least `keep` bytes stay free on each device."""
    with held_by(model, AnswerHold(room, keep)) as hold:
        yield hold


@contextmanager
def held_by(model, hold):
    """Intention: each BookLinear in `model` answers to `hold` during the `with`; all let go at the end, whatever
    happened."""
    layers = [m for m in model.modules() if isinstance(m, BookLinear)] if model is not None else []
    for layer in layers:
        layer.hold, layer.held = hold, None
    try:
        yield hold
    finally:
        hold.let_go()
        for layer in layers:
            layer.hold = None


class _LinearFromBook(torch.autograd.Function):
    """Intention: backward retains a book reference, not every expanded base weight in the model."""

    @staticmethod
    def forward(ctx, inputs, layer):
        """Intention: the exact ordinary linear operation, with only this layer's weight reconstructed."""
        ctx.layer = layer
        ctx.device_type = inputs.device.type
        ctx.autocast_enabled = torch.is_autocast_enabled(ctx.device_type)
        ctx.autocast_dtype = torch.get_autocast_dtype(ctx.device_type)
        return torch.nn.functional.linear(inputs, layer.weight)

    @staticmethod
    def backward(ctx, gradient):
        """Intention: propagate the same input gradient through a frozen base without retaining its dense weight."""
        with torch.autocast(ctx.device_type, enabled=ctx.autocast_enabled, dtype=ctx.autocast_dtype):
            return torch.matmul(gradient, ctx.layer.weight), None


class BookLinear(torch.nn.Linear):
    """Intention: keep the tensor's book reference and reconstruct only the current arithmetic operand."""

    def __init__(self, door, kept: dict, ordinary, kind, device) -> None:
        """Intention: the same linear contract and bias, with a zero-sized device marker instead of base weights."""
        torch.nn.Module.__init__(self)
        self.door, self.reference = door, kept
        self.in_features, self.out_features = ordinary.in_features, ordinary.out_features
        self.bias = ordinary.bias
        self.register_buffer('_location', torch.empty(0, dtype=kind, device=device), persistent=False)
        self.hold = self.held = None   # BUILD_LOG 1951h: set only inside held_for_an_answer

    @property
    def weight(self):
        """Intention: exact values from the stored form, on this layer's current device; never cached whole - except
        held for the rest of one answer while the device has room (BUILD_LOG 1951h)."""
        held = getattr(self, "held", None)
        if held is not None:
            return held
        hold = getattr(self, "hold", None)
        if getattr(hold, "shape_only", False):   # BUILD_LOG 2273: shape, device and kind only - the book is not read
            return torch.empty((self.out_features, self.in_features), dtype=self._location.dtype,
                               device=self._location.device)
        weight = self.door.tensor(self.reference).to(device=self._location.device, dtype=self._location.dtype)
        if hold is not None and hold.keeps(weight.device, weight.numel() * weight.element_size()):
            self.held = weight
            hold.layers.append(self)
        return weight

    def forward(self, inputs):
        """Intention: inference and adapter training use the stored base without holding expanded weights for backward."""
        result = _LinearFromBook.apply(inputs, self)
        return result if self.bias is None else result + self.bias

    def _save_to_state_dict(self, destination, prefix, keep_vars):
        """Intention: explicit model checkpoints still contain every original weight with its ordinary name."""
        super()._save_to_state_dict(destination, prefix, keep_vars)
        destination[prefix + 'weight'] = self.weight
