# WARP2/warp2/house/held_small/weights_form.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/weights_form.py
#  Used by   : warp2/house/held_small/door.py, filled.py, tests/.
#  Uses      : projects/behemoth_eye/eye/held_small/book.py (TensorBook - the
#              same book the Eye's pairs are kept in); safetensors, torch
#              (only when a file is kept or a tensor is read).
#  Description:
#    A WEIGHT FILE AS A LIST OF TAGS. Each tensor of a safetensors file is put
#    in the tensor book (kept once, however many files hold it) and the file
#    is kept as its tensors' names, each with the tensor's whole place and
#    its kind. A tensor is read back from its place exactly - the same kind,
#    the same shape, the same values bit for bit. A kind the book's arrays
#    have no name for (bfloat16) is kept as whole numbers of the same width
#    and read back as its own kind; not one bit changes.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    2026-11-11: the models "As dehydrated tokens ... In the same way and
#    function". (BUILD_LOG 1562.)
# ============================================================================
"""A weight file kept as its tensors' names and places in the tensor book, and each tensor read back exactly."""
from __future__ import annotations

# Intention: the whole-number kind of each width, for a kind numpy has no name for.
WHOLE_OF_WIDTH = {1: "int8", 2: "int16", 4: "int32", 8: "int64"}


def listed(place) -> list:
    """Intention: a tensor's place as plain values a kept file can hold."""
    tag, page, start, size, dtype, shape, form, needs = place
    return [bytes(tag).hex(), page, int(start), int(size), dtype, shape, int(form), bytes(needs).hex()]


def placed(kept) -> tuple:
    """Intention: the place again, as the book reads it."""
    tag, page, start, size, dtype, shape, form, needs = kept
    return (bytes.fromhex(tag), page, int(start), int(size), dtype, shape, int(form), bytes.fromhex(needs))


def as_array(tensor):
    """Intention: the tensor's values as an array, bit for bit - through whole numbers of the same width when the
    kind has no array name."""
    import torch
    tensor = tensor.detach().cpu().contiguous()
    try:
        return tensor.numpy()
    except TypeError:  # fault: ok - a kind numpy cannot name (bfloat16) is kept as whole numbers of its width
        return tensor.view(getattr(torch, WHOLE_OF_WIDTH[tensor.element_size()])).numpy()


class WeightsForm:
    """Intention: weight files held small against one tensor book, and their tensors read back."""

    def __init__(self, book) -> None:
        """Intention: the book every tensor is kept in."""
        self.book = book

    def small(self, file) -> dict:
        """Intention: {"tensors": {name: {"place", "kind"}}, "metadata"} for one safetensors file - one tensor in
        memory at a time, the whole file written to the book as one piece."""
        from safetensors import safe_open
        tensors = {}
        with safe_open(str(file), framework="pt") as source, self.book.writing():
            for name in source.keys():
                tensor = source.get_tensor(name)
                tensors[name] = {"place": listed(self.book.place(as_array(tensor))),
                                 "kind": str(tensor.dtype).replace("torch.", "")}
            metadata = source.metadata() or {}
            self.book.hold(self.tags({"tensors": tensors}))   # BUILD_LOG 1568: this file's small form points at them
        return {"tensors": tensors, "metadata": metadata}

    @staticmethod
    def tags(kept: dict) -> list:
        """Intention (BUILD_LOG 1568): every tag a kept weight file points at, for the book's counting."""
        return [bytes.fromhex(one["place"][0]) for one in (kept.get("tensors") or {}).values()]

    def let_go(self, kept: dict) -> int:
        """Intention (BUILD_LOG 1568): a small form that is replaced stops pointing at its tensors, so the book gives
        their places to the next of their size; how many tensors were left with nothing pointing at them."""
        return self.book.let_go(self.tags(kept))

    def tensor(self, kept: dict):
        """Intention: one tensor back from its place - its own kind, shape and values."""
        import torch
        tensor = torch.from_numpy(self.book.at(placed(kept["place"])))
        kind = getattr(torch, kept["kind"])
        return tensor if tensor.dtype == kind else tensor.view(kind)
