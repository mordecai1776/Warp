# WARP2/warp2/house/held_small/tests/test_floating_buffer_and_deep_storage_models.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_floating_buffer_and_deep_storage_models.py
#  Used by   : pytest.
#  Uses      : warp2/house/held_small/{door,text_base,floating_buffer,keep}.py,
#              warp2/house/image_runner.py; transformers, safetensors, torch.
#  Description:
#    Proves:
#      - when a language model does not fit in card + memory (`split to disk`
#        with `max_memory`), `TextBase` loads it from the TensorBook using
#        `FloatingLayerBuffer` even after `.safetensors` files are deleted;
#      - offloaded layers stay on `meta` while idle, stream from the
#        TensorBook during `forward` / `generate`, release back to `meta`
#        immediately after each forward pass, and produce the exact same
#        logits and generated tokens as the full in-memory model;
#      - `ImageRunner.half()` and `ImageRunner.need()` work from `models_small`
#        when `.safetensors` files have been removed;
#      - `KeepAll.separate_epoch()` runs a separation epoch on the house book.
#  User intention (Andrew, 2026-11-11 17:55, 21:31; 2026-11-12): floating
#    storage that buffers and runs models one part at a time from dehydrated
#    tags. BUILD_LOG 1581.
# ============================================================================
"""Tests for FloatingLayerBuffer streaming from TensorBook and ImageRunner/KeepAll small-form support."""
from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("transformers")
pytest.importorskip("accelerate")
pytest.importorskip("safetensors")


def _tiny_text(folder: Path) -> Path:
    """Intention: build a tiny 2-layer Llama with a word tokenizer in `folder`."""
    from tokenizers import Tokenizer, models, pre_tokenizers
    from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast
    words = ["<pad>", "<eos>", "<unk>", "hello", "cat", "paw", "fur", "the", "is", "made", "of", "\n"]
    raw = Tokenizer(models.WordLevel({w: i for i, w in enumerate(words)}, unk_token="<unk>"))
    raw.pre_tokenizer = pre_tokenizers.WhitespaceSplit()
    tok = PreTrainedTokenizerFast(tokenizer_object=raw, pad_token="<pad>", eos_token="<eos>", unk_token="<unk>")
    config = LlamaConfig(
        vocab_size=len(words),
        hidden_size=32,
        intermediate_size=64,
        num_hidden_layers=2,
        num_attention_heads=2,
        num_key_value_heads=2,
        max_position_embeddings=64,
        pad_token_id=0,
        eos_token_id=1,
        bos_token_id=1,
        tie_word_embeddings=True,
    )
    LlamaForCausalLM(config).save_pretrained(folder)
    tok.save_pretrained(folder)
    return folder


def test_floating_layer_buffer_streams_split_to_disk_model_from_book_without_safetensors(tmp_path):
    """Intention: a model split to disk streams its offloaded layers from the TensorBook during forward/generate and
    releases them back to meta right after, giving the exact same output with `.safetensors` files removed."""
    import torch
    from warp2.house.held_small.door import DOORS, WEIGHTS, WeightsDoor
    from warp2.house.held_small.text_base import TextBase, weight_files

    tiny = _tiny_text(tmp_path / "tiny-llama")
    door = WeightsDoor(tmp_path / "models_small")
    try:
        for file in weight_files(tiny):
            door.keep(tiny, file)
        # Load baseline model in memory before deleting .safetensors
        full_model = TextBase(door).load(tiny, "float32", {"where": "memory", "kwargs": {}})
        assert full_model is not None

        # Delete .safetensors to prove FloatingLayerBuffer needs only the TensorBook!
        for sf in tiny.glob(WEIGHTS):
            sf.unlink()
        assert not list(tiny.glob(WEIGHTS))

        # Force layer 1 onto "disk" by setting a tight CPU max_memory budget in `split to disk` placement.
        placed_disk = {
            "where": "split to disk",
            "kwargs": {"device_map": "auto", "max_memory": {"cpu": 16384}},
        }
        streamed = TextBase(door).load(tiny, "float32", placed_disk)
        assert streamed is not None
        buf = getattr(streamed, "_floating_buffer", None)
        assert buf is not None

        # Offloaded parameters are on meta before forward pass:
        meta_before = [n for n, p in streamed.state_dict().items() if p.is_meta]
        assert len(meta_before) > 0

        asked = torch.tensor([[3, 4, 5, 6]])
        with torch.no_grad():
            expected_logits = full_model(asked).logits
            actual_logits = streamed(asked).logits
            assert torch.equal(expected_logits, actual_logits)
            assert buf.loads > 0 and buf.releases == buf.loads

            # Immediately after forward, streamed layers are back on meta (0 RAM held):
            meta_after = [n for n, p in streamed.state_dict().items() if p.is_meta]
            assert meta_after == meta_before

            # Multi-step autoregressive generation also streams layer-by-layer identically:
            assert torch.equal(
                full_model.generate(asked, max_new_tokens=4, do_sample=False),
                streamed.generate(asked, max_new_tokens=4, do_sample=False),
            )
    finally:
        door.close()
        for d in DOORS.values():
            d.close()
        DOORS.clear()


def test_image_runner_and_keep_all_separate_epoch_work_from_small_forms(tmp_path):
    """Intention: ImageRunner.half() and need() read kept manifests when .safetensors are gone, and KeepAll runs a
    bounded separation epoch over the house TensorBook."""
    import torch
    from safetensors.torch import save_file
    from warp2.house.held_small.door import DOORS, small_home
    from warp2.house.held_small.keep import KeepAll
    from warp2.house.image_runner import ImageRunner
    from warp2.house.shelf import Shelf

    pipe_dir = tmp_path / "sd-pipe"
    unet_dir = pipe_dir / "unet"
    unet_dir.mkdir(parents=True)
    fp16_file = unet_dir / "diffusion_pytorch_model.fp16.safetensors"
    save_file({"w": torch.zeros((16, 16), dtype=torch.float16)}, str(fp16_file))
    expected_size = fp16_file.stat().st_size

    state = tmp_path / "state"
    shelf = Shelf(tmp_path, state, entries=[{"name": "sd", "how": "house", "path": str(pipe_dir)}])
    keeper = KeepAll(tmp_path, state, shelf=shelf, say=lambda _line: None)
    try:
        res = keeper.run()
        assert res["kept"] == 1
        epoch = keeper.separate_epoch(max_tensors=16, time_budget_s=1.0)
        assert epoch["inspected"] >= 1 and epoch["upgraded"] >= 1

        # Remove .safetensors file and check ImageRunner.half() and need() from models_small alone:
        fp16_file.unlink()
        runner = ImageRunner(pipe_dir, small_home=small_home(state))
        assert runner.half() is True
        assert runner.need() == expected_size
    finally:
        for d in DOORS.values():
            d.close()
        DOORS.clear()
