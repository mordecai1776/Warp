# WARP2/warp2/house/held_small/tests/test_the_reader_the_picture_model_and_the_adapter_load_from_their_small_forms.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_the_reader_the_picture_model_and_the_adapter_load_from_their_small_forms.py
#  Used by   : pytest.
#  Uses      : warp2/house/held_small/{door,model_files,reader_base,
#              picture_parts,adapter_on,keep}.py, warp2/house/{text_runner,
#              reader_runner,image_runner}.py; transformers, diffusers, peft,
#              torch (tiny models made in the test's folder).
#  Description:
#    Proves, on tiny models made here:
#      - the weight files of a folder are the ones its index names, or its
#        one file, with the variant when asked - never a stray file beside;
#      - the picture reader from the book equals the one from its file, part
#        for part, and its runner loads from the book;
#      - every weighted part of a picture pipeline from the book equals the
#        part from its files, the runner's pipeline is built from them, and
#        the same seed draws the same picture either way;
#      - a tag adapter put on from the book gives the same model and the
#        same answer as peft reading its file, and peft's own reader is put
#        back afterwards;
#      - with no small form each of them reads its files as before.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    (BUILD_LOG 1563.)
# ============================================================================
from __future__ import annotations

import json
from pathlib import Path

import pytest

pytest.importorskip("transformers")
pytest.importorskip("accelerate")
pytest.importorskip("safetensors")


@pytest.fixture()
def home(tmp_path):
    """Intention: a home for small forms of the test's own; its doors closed afterwards."""
    from warp2.house.held_small.door import DOORS
    yield tmp_path / "models_small"
    for door in DOORS.values():
        door.close()
    DOORS.clear()


def _keep(home, folder) -> int:
    """Intention: every safetensors file under a folder kept small; how many."""
    from warp2.house.held_small.door import WEIGHTS, door_of
    files = sorted(f for f in Path(folder).rglob(WEIGHTS) if f.is_file())
    for file in files:
        door_of(home).keep(folder, file)
    return len(files)


def _same(a, b) -> None:
    """Intention: two models equal part for part - names, kinds and values."""
    import torch
    one, two = a.state_dict(), b.state_dict()
    assert list(one) == list(two)
    for name in one:
        assert one[name].dtype == two[name].dtype and torch.equal(one[name], two[name]), name


def test_the_weight_files_are_the_ones_the_folder_is_loaded_from(tmp_path):
    """Intention: an index's shards; else the one file; the variant when asked; a stray file never."""
    from warp2.house.held_small.model_files import model_files
    for name in ("model.safetensors", "model.fp16.safetensors", "stray.safetensors"):
        (tmp_path / name).write_bytes(b"x")
    assert model_files(tmp_path) == [tmp_path / "model.safetensors"]
    assert model_files(tmp_path, "model", "fp16") == [tmp_path / "model.fp16.safetensors"]
    assert model_files(tmp_path, "adapter_model") == []
    for name in ("model-00001-of-00002.safetensors", "model-00002-of-00002.safetensors"):
        (tmp_path / name).write_bytes(b"x")
    (tmp_path / "model.safetensors.index.json").write_text(json.dumps({"weight_map": {
        "a": "model-00001-of-00002.safetensors", "b": "model-00002-of-00002.safetensors",
        "c": "model-00001-of-00002.safetensors"}}), encoding="utf-8")
    assert [f.name for f in model_files(tmp_path)] == ["model-00001-of-00002.safetensors",
                                                      "model-00002-of-00002.safetensors"]
    print("\n  [OK] the files read are the index's shards or the one file, with the variant when asked")


def test_the_picture_reader_from_the_book_is_the_one_from_its_file(tmp_path, home, monkeypatch):
    """Intention: CLIP built empty and filled equals CLIP from its file; the runner uses the book; none kept, the file."""
    from transformers import CLIPConfig, CLIPModel, CLIPTextConfig, CLIPVisionConfig
    from warp2.house.held_small import reader_base
    from warp2.house.reader_runner import ReaderRunner
    folder = tmp_path / "tiny-clip"
    text = CLIPTextConfig(vocab_size=30, hidden_size=16, intermediate_size=20, num_attention_heads=2,
                          num_hidden_layers=1, projection_dim=8, max_position_embeddings=16)
    vision = CLIPVisionConfig(hidden_size=16, intermediate_size=20, num_attention_heads=2, num_hidden_layers=1,
                              projection_dim=8, image_size=16, patch_size=8)
    CLIPModel(CLIPConfig(text_config=text.to_dict(), vision_config=vision.to_dict(), projection_dim=8)).save_pretrained(folder)
    assert reader_base.reader_from_book(folder, home) is None
    assert _keep(home, folder) == 1
    from_book = reader_base.reader_from_book(folder, home)
    assert from_book is not None
    _same(CLIPModel.from_pretrained(str(folder)).eval(), from_book)
    used = []
    real = reader_base.ReaderBase.load
    monkeypatch.setattr(reader_base.ReaderBase, "load",
                        lambda self, path: used.append(1) or real(self, path))
    monkeypatch.setattr("transformers.CLIPProcessor.from_pretrained", lambda *a, **k: object())
    runner = ReaderRunner(folder, small_home=home).load()
    _same(from_book, runner.model.to("cpu"))
    assert used == [1] and ReaderRunner(folder).load().model is not None and used == [1]
    print("\n  [OK] the picture reader filled from the book equals the one from its file, and its runner uses the book")


def test_the_picture_models_parts_from_the_book_are_the_parts_from_their_files(tmp_path, home):
    """Intention: every weighted part equal; the runner's pipeline is made of the book's parts; the same seed draws
    the same picture from the book as from the files."""
    pytest.importorskip("diffusers")
    import numpy as np
    import torch
    from diffusers import AutoencoderKL, DDIMScheduler, StableDiffusionPipeline, UNet2DConditionModel
    from transformers import CLIPTextConfig, CLIPTextModel, CLIPTokenizer
    from warp2.house.held_small import picture_parts
    from warp2.house.image_runner import ImageRunner
    vocab = {"<|startoftext|>": 0, "<|endoftext|>": 1, "c</w>": 2, "a</w>": 3, "t</w>": 4, "!": 5}
    (tmp_path / "vocab.json").write_text(json.dumps(vocab), encoding="utf-8")
    (tmp_path / "merges.txt").write_text("#version: 0.2\n", encoding="utf-8")
    tok = CLIPTokenizer(str(tmp_path / "vocab.json"), str(tmp_path / "merges.txt"), model_max_length=77)
    text = CLIPTextModel(CLIPTextConfig(vocab_size=len(vocab), hidden_size=32, intermediate_size=37,
                                        num_attention_heads=4, num_hidden_layers=2, projection_dim=32,
                                        max_position_embeddings=77, bos_token_id=0, eos_token_id=1))
    unet = UNet2DConditionModel(block_out_channels=(32, 64), layers_per_block=1, sample_size=8, in_channels=4,
                                out_channels=4, down_block_types=("DownBlock2D", "CrossAttnDownBlock2D"),
                                up_block_types=("CrossAttnUpBlock2D", "UpBlock2D"), cross_attention_dim=32,
                                norm_num_groups=8, attention_head_dim=4)
    vae = AutoencoderKL(block_out_channels=(8, 16), in_channels=3, out_channels=3, latent_channels=4,
                        down_block_types=("DownEncoderBlock2D", "DownEncoderBlock2D"),
                        up_block_types=("UpDecoderBlock2D", "UpDecoderBlock2D"), norm_num_groups=8, sample_size=16)
    folder = tmp_path / "pipe"
    StableDiffusionPipeline(vae=vae, text_encoder=text, tokenizer=tok, unet=unet, scheduler=DDIMScheduler(),
                            safety_checker=None, feature_extractor=None,
                            requires_safety_checker=False).save_pretrained(folder)
    assert picture_parts.parts_from_book(folder, "", torch.float32, home) == {}
    assert _keep(home, folder) == 3
    parts = picture_parts.parts_from_book(folder, "", torch.float32, home)
    assert sorted(parts) == ["text_encoder", "unet", "vae"]
    plain = StableDiffusionPipeline.from_pretrained(str(folder), torch_dtype=torch.float32)
    for part, model in parts.items():
        _same(getattr(plain, part), model)
    from_files = ImageRunner(folder).load()
    from_book = ImageRunner(folder, small_home=home).load()
    for part in parts:
        _same(getattr(from_files.pipe, part), getattr(from_book.pipe, part))
    a = from_files.draw("a cat", tmp_path / "a.png", seed=3, steps=2, width=16, height=16)
    b = from_book.draw("a cat", tmp_path / "b.png", seed=3, steps=2, width=16, height=16)
    from PIL import Image
    assert np.array_equal(np.asarray(Image.open(a["path"])), np.asarray(Image.open(b["path"])))
    print("\n  [OK] the pipeline's unet, vae and text encoder from the book equal the files', and draw the same picture")


def test_a_tag_adapter_put_on_from_the_book_is_the_adapter_from_its_file(tmp_path, home):
    """Intention: the same model and the same answer; peft's own reader put back; none kept, the file is read."""
    pytest.importorskip("peft")
    import peft.peft_model
    import torch
    from peft import LoraConfig, PeftModel, get_peft_model
    from transformers import LlamaConfig, LlamaForCausalLM
    from warp2.house.held_small.adapter_on import adapter_from_book
    config = LlamaConfig(vocab_size=12, hidden_size=32, intermediate_size=64, num_hidden_layers=2,
                         num_attention_heads=2, num_key_value_heads=2, max_position_embeddings=64,
                         pad_token_id=0, eos_token_id=1, bos_token_id=1)
    base = tmp_path / "base"
    LlamaForCausalLM(config).save_pretrained(base)
    adapter = tmp_path / "adapter"
    taught = get_peft_model(LlamaForCausalLM.from_pretrained(str(base)),
                            LoraConfig(r=4, lora_alpha=8, target_modules=["q_proj", "v_proj"], task_type="CAUSAL_LM"))
    for name, value in taught.named_parameters():
        if "lora_B" in name:
            torch.nn.init.normal_(value)
    taught.save_pretrained(str(adapter))
    before = peft.peft_model.load_peft_weights
    assert adapter_from_book(LlamaForCausalLM.from_pretrained(str(base)), adapter, home) is None
    assert _keep(home, adapter) == 1
    from_book = adapter_from_book(LlamaForCausalLM.from_pretrained(str(base)), adapter, home)
    from_file = PeftModel.from_pretrained(LlamaForCausalLM.from_pretrained(str(base)), str(adapter))
    assert from_book is not None and peft.peft_model.load_peft_weights is before
    _same(from_file, from_book)
    asked = torch.tensor([[3, 4, 5, 6]])
    with torch.no_grad():
        assert torch.equal(from_file(asked).logits, from_book(asked).logits)
    plain = LlamaForCausalLM.from_pretrained(str(base))
    with torch.no_grad():
        assert not torch.equal(plain(asked).logits, from_book(asked).logits)
    print("\n  [OK] the adapter put on from the book equals the adapter from its file, and it changes the answer")
