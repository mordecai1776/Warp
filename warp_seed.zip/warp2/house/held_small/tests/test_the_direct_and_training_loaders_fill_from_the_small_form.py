# WARP2/warp2/house/held_small/tests/test_the_direct_and_training_loaders_fill_from_the_small_form.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_the_direct_and_training_loaders_fill_from_the_small_form.py
#  Used by   : pytest.
#  Uses      : warp2/models/backends.py (direct_model), warp2/train/finetune.py
#              (read as text), warp2/house/held_small/{door,text_base}.py;
#              transformers, torch (a tiny model made in the test's folder).
#  Description:
#    Proves that a direct model is filled from its small form when it has
#    one and answers, and is read from its weight files when it has none;
#    and that the LoRA round asks the small form before any weight file is
#    read (read from its source - a whole round is too heavy for a test).
#  User intention (Andrew, 2026-11-12 09:49): "ok now for the models all of
#    them". (BUILD_LOG 1571.)
# ============================================================================
from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("transformers")
pytest.importorskip("accelerate")


def _tiny_text(folder: Path) -> Path:
    """Intention: a tiny llama with a word tokenizer, saved as a Hugging Face folder."""
    from tokenizers import Tokenizer, models, pre_tokenizers
    from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast
    words = ["<pad>", "<eos>", "<unk>", "hello", "cat", "paw", "fur", "the", "is", "made", "of", "\n"]
    raw = Tokenizer(models.WordLevel({w: i for i, w in enumerate(words)}, unk_token="<unk>"))
    raw.pre_tokenizer = pre_tokenizers.WhitespaceSplit()
    # only what every language model takes: the direct backend hands the model whatever its tokenizer gives
    tok = PreTrainedTokenizerFast(tokenizer_object=raw, pad_token="<pad>", eos_token="<eos>", unk_token="<unk>",
                                  model_input_names=["input_ids", "attention_mask"])
    config = LlamaConfig(vocab_size=len(words), hidden_size=32, intermediate_size=64, num_hidden_layers=2,
                         num_attention_heads=2, num_key_value_heads=2, max_position_embeddings=64,
                         pad_token_id=0, eos_token_id=1, bos_token_id=1)
    LlamaForCausalLM(config).save_pretrained(folder)
    tok.save_pretrained(folder)
    return folder


def test_a_direct_model_is_filled_from_its_small_form_and_answers(tmp_path, monkeypatch):
    """Intention: the book loads it when it has a small form; its files do when it has none; it answers either way."""
    from warp2.house.held_small import text_base
    from warp2.house.held_small.door import DOORS, door_of
    from warp2.models import backends
    tiny = _tiny_text(tmp_path / "models" / "tiny-llama")
    home = tmp_path / "models_small"
    monkeypatch.setattr(backends, "small_forms", lambda: home)
    monkeypatch.setattr("warp2.room.split_load.placement", lambda *a, **k: {"where": "memory", "kwargs": {}})
    used = []
    real = text_base.TextBase.load

    def seen(self, path, load_as, placed):
        """Intention: note whether the book loaded it."""
        model = real(self, path, load_as, placed)
        used.append(model is not None)
        return model
    monkeypatch.setattr(text_base.TextBase, "load", seen)
    try:
        backends._LOADED_DIRECT_MODELS.pop(str(tiny), None)
        from_files = backends.direct_model(str(tiny), name="tiny", max_tokens=3, bare=True)("hello cat")
        assert used == [False] and isinstance(from_files, str)
        for file in sorted(tiny.glob("*.safetensors")):
            door_of(home).keep(tiny, file)
        backends._LOADED_DIRECT_MODELS.pop(str(tiny), None)
        from_book = backends.direct_model(str(tiny), name="tiny", max_tokens=3, bare=True)("hello cat")
        assert used == [False, True] and from_book == from_files
    finally:
        backends._LOADED_DIRECT_MODELS.pop(str(tiny), None)
        for door in DOORS.values():
            door.close()
        DOORS.clear()
    print("\n  [OK] a direct model answered the same filled from the book as read from its files")


def test_the_lora_round_asks_the_small_form_before_a_weight_file():
    """Intention: read from the source - the round is too heavy to run here; it must ask the book first."""
    import warp2.train.finetune as finetune
    source = Path(finetune.__file__).read_text(encoding="utf-8")
    asks = source.index("model = base_from_book(model_path")
    reads = source.index("model = AutoModelForCausalLM.from_pretrained(", asks)
    assert asks < reads and "small_home(self.state_dir)" in source[asks:reads]
    assert "if model is None:" in source[asks:reads]
    print("\n  [OK] the LoRA round asks the small form first and reads the weight files only when it has none")
