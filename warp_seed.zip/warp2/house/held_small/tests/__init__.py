# WARP2/warp2/house/held_small/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/__init__.py
#  Used by   : pytest.
#  Uses      : nothing.
#  Description: the tests of the house's models held small.
#  User intention (Andrew): tests sit beside the thing they test. (BUILD_LOG 1562.)
# ============================================================================
"""Tests of the house's models held small."""
