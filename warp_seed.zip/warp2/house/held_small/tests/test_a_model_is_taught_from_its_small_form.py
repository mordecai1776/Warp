# WARP2/warp2/house/held_small/tests/test_a_model_is_taught_from_its_small_form.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_a_model_is_taught_from_its_small_form.py
#  Used by   : pytest.
#  Uses      : warp2/house/tag_lora.py, warp2/house/held_small/{door,keep,
#              text_base}.py, warp2/house/shelf.py; transformers, peft, torch
#              (a tiny model made in the test's folder).
#  Description:
#    Proves that the model a tag lesson teaches is filled from its small
#    form when it has one (the book is what loads it, and it equals the
#    model from its weight files part for part, with a new adapter carried
#    on), and is read from its weight files when it has none.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    (BUILD_LOG 1564.)
# ============================================================================
from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("transformers")
pytest.importorskip("peft")
pytest.importorskip("accelerate")


def _tiny_text(folder: Path) -> Path:
    """Intention: a tiny llama with a word tokenizer, saved as a Hugging Face folder."""
    from tokenizers import Tokenizer, models, pre_tokenizers
    from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast
    words = ["<pad>", "<eos>", "<unk>", "hello", "cat", "paw", "fur", "the", "is", "made", "of", "\n"]
    raw = Tokenizer(models.WordLevel({w: i for i, w in enumerate(words)}, unk_token="<unk>"))
    raw.pre_tokenizer = pre_tokenizers.WhitespaceSplit()
    tok = PreTrainedTokenizerFast(tokenizer_object=raw, pad_token="<pad>", eos_token="<eos>", unk_token="<unk>")
    config = LlamaConfig(vocab_size=len(words), hidden_size=32, intermediate_size=64, num_hidden_layers=2,
                         num_attention_heads=2, num_key_value_heads=2, max_position_embeddings=64,
                         pad_token_id=0, eos_token_id=1, bos_token_id=1)
    LlamaForCausalLM(config).save_pretrained(folder)
    tok.save_pretrained(folder)
    return folder


def test_the_model_a_tag_lesson_teaches_is_filled_from_its_small_form(tmp_path, monkeypatch):
    """Intention: with a small form the book loads the taught model; without one its files do; both the same model."""
    import torch
    from warp2.house.held_small import text_base
    from warp2.house.held_small.door import DOORS
    from warp2.house.held_small.keep import KeepAll
    from warp2.house.shelf import Shelf
    from warp2.house.tag_lora import TagLora
    tiny = _tiny_text(tmp_path / "models" / "tiny-llama")
    state = tmp_path / "state"
    entry = {"name": "tiny", "how": "house", "path": str(tiny)}
    monkeypatch.setattr(TagLora, "_type", staticmethod(lambda: "float32"))
    used = []
    real = text_base.TextBase.load

    def seen(self, path, load_as, placed):
        """Intention: note whether the book loaded it."""
        model = real(self, path, load_as, placed)
        used.append(model is not None)
        return model
    monkeypatch.setattr(text_base.TextBase, "load", seen)
    try:
        from_files, _tok = TagLora(tmp_path, state, entry, lessons=object())._load("memory")
        assert used == [False]
        KeepAll(tmp_path, state, shelf=Shelf(tmp_path, state, entries=[entry]), say=lambda line: None).run()
        from_book, tokenizer = TagLora(tmp_path, state, entry, lessons=object())._load("memory")
        assert used == [False, True] and tokenizer.pad_token_id is not None
        a = {n: v for n, v in from_files.state_dict().items() if "lora_" not in n}
        b = {n: v for n, v in from_book.state_dict().items() if "lora_" not in n}
        assert list(a) == list(b) and a
        for name in a:
            assert a[name].dtype == b[name].dtype and torch.equal(a[name], b[name]), name
        assert any("lora_" in n for n in from_book.state_dict())
    finally:
        for door in DOORS.values():
            door.close()
        DOORS.clear()
    print("\n  [OK] the taught model was filled from the book and equals the model from its files; a new adapter is on it")


def test_a_model_and_its_carried_adapter_work_from_the_small_form_alone(tmp_path, monkeypatch):
    """Intention (Andrew, 2026-11-12): once a model and its adapter are kept in the dehydrated tensor book, they load,
    measure, and carry from the small form even when the safetensors files are removed."""
    import torch
    from warp2.house.held_small.door import DOORS, WEIGHTS, door_of, small_home
    from warp2.house.held_small.keep import KeepAll
    from warp2.house.shelf import Shelf
    from warp2.house.tag_lora import TagLora
    from warp2.room.split_load import weight_bytes
    tiny = _tiny_text(tmp_path / "models" / "tiny-llama")
    state = tmp_path / "state"
    entry = {"name": "tiny", "how": "house", "path": str(tiny)}
    monkeypatch.setattr(TagLora, "_type", staticmethod(lambda: "float32"))
    shelf = Shelf(tmp_path, state, entries=[entry])
    adapter_dir = shelf.adapter("tiny")
    try:
        adapted, _tok = TagLora(tmp_path, state, entry, lessons=object())._load("memory")
        with torch.no_grad():
            for name, param in adapted.named_parameters():
                if "lora_B" in name:
                    param.fill_(0.125)
        adapted.save_pretrained(str(adapter_dir))
        KeepAll(tmp_path, state, shelf=shelf, say=lambda line: None).run()
        expected_bytes = weight_bytes(tiny)
        assert expected_bytes > 0
        for sf in list(tiny.glob(WEIGHTS)) + list(adapter_dir.glob(WEIGHTS)):
            sf.unlink()
        assert not list(tiny.glob(WEIGHTS)) and not list(adapter_dir.glob(WEIGHTS))
        assert door_of(small_home(state)) is not None
        assert weight_bytes(tiny) == expected_bytes
        carried_model, _tok2 = TagLora(tmp_path, state, entry, lessons=object())._load("memory")
        lora_b = [p for n, p in carried_model.named_parameters() if "lora_B" in n]
        assert lora_b and all(torch.allclose(p, torch.full_like(p, 0.125)) for p in lora_b)
    finally:
        for door in DOORS.values():
            door.close()
        DOORS.clear()
