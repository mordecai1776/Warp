# WARP2/warp2/house/held_small/tests/test_an_adapter_is_put_on_within_the_models_limits.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_an_adapter_is_put_on_within_the_models_limits.py
#  Used by   : pytest.
#  Uses      : warp2/house/text_runner.py, warp2/house/held_small/{text_base,
#              adapter_on}.py, warp2/room/split_load.py (stood in for).
#  Description:
#    Proves that when a model was placed within limits (split between the
#    card and memory), the adapter stage is handed those same limits -
#    whether the adapter comes from the book or from its file - and that a
#    model placed with no limits hands none.
#  User intention (Andrew, 2026-11-12 09:49): "ok now for the models all of
#    them". (BUILD_LOG 1572.)
# ============================================================================
from __future__ import annotations

import sys
import types

import pytest


@pytest.mark.parametrize("from_book", [True, False])
def test_the_adapter_stage_is_handed_the_limits_the_model_was_placed_in(tmp_path, monkeypatch, from_book):
    """Intention: peft is never left to place a split model again by its own reckoning."""
    from warp2.house.held_small import adapter_on, text_base
    from warp2.house.text_runner import TextRunner
    from warp2.room import split_load
    limits = {0: 1000, "cpu": 2000}
    handed = []
    model = types.SimpleNamespace(eval=lambda: None)

    def peft_reads(base, adapter, **asked):
        """Intention: peft reading the adapter's file - what it was handed is noted."""
        handed.append(("file", asked))
        return model

    def book_puts_on(base, adapter, home, **asked):
        """Intention: the adapter from the book - what it was handed is noted; None sends the runner to the file."""
        handed.append(("book", asked))
        return model if from_book else None
    monkeypatch.setitem(sys.modules, "torch", types.SimpleNamespace(float32="float32"))
    monkeypatch.setitem(sys.modules, "transformers", types.SimpleNamespace(
        AutoTokenizer=types.SimpleNamespace(from_pretrained=lambda *a, **k: object()),
        AutoModelForCausalLM=types.SimpleNamespace(from_pretrained=lambda *a, **k: model)))
    monkeypatch.setitem(sys.modules, "peft", types.SimpleNamespace(
        PeftModel=types.SimpleNamespace(from_pretrained=peft_reads)))
    monkeypatch.setattr(TextRunner, "_type", staticmethod(lambda: "float32"))
    monkeypatch.setattr(text_base, "base_from_book", lambda *a, **k: model)
    monkeypatch.setattr(adapter_on, "adapter_from_book", book_puts_on)
    adapter = tmp_path / "adapter"
    adapter.mkdir()
    (adapter / "adapter_config.json").write_text("{}", encoding="utf-8")
    monkeypatch.setattr(split_load, "placement", lambda *a: {
        "where": "card and memory", "kwargs": {"device_map": "auto", "max_memory": limits}})
    TextRunner(tmp_path / "tiny", adapter, small_home=tmp_path / "small").load()
    assert handed[0] == ("book", {"max_memory": limits})
    assert handed[1:] == ([] if from_book else [("file", {"max_memory": limits})])
    handed.clear()
    monkeypatch.setattr(split_load, "placement", lambda *a: {"where": "card", "kwargs": {"device_map": "auto"}})
    TextRunner(tmp_path / "tiny", adapter, small_home=tmp_path / "small").load()
    assert handed[0] == ("book", {}) and handed[1:] == ([] if from_book else [("file", {})])
    print("\n  [OK] the adapter stage was handed the model's own limits (%s)" % ("book" if from_book else "file"))
