# WARP2/warp2/house/held_small/tests/test_a_model_is_run_from_the_rows_the_book_keeps.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_a_model_is_run_from_the_rows_the_book_keeps.py
#  Used by   : pytest.
#  Uses      : warp2/house/held_small/{door,text_base,small_fill,filled,keep}.py,
#              warp2/house/{text_runner,house,keeper,shelf}.py,
#              projects/behemoth_eye/eye/held_small/{epochs,forms}.py and
#              small_math/{linear,layers}.py; transformers, torch (a tiny
#              model made in the test's folder, two of its layers and its
#              word table given repeated rows).
#  Description:
#    Proves, end to end on a tiny language model made here:
#      - separation epochs keep the weights whose rows repeat as their
#        distinct rows (form 4), and the model filled the ordinary way from
#        that book is still the model its weight files give, part for part;
#      - asked for the small form, the two layers kept as rows are put in as
#        layers RUN FROM those rows (their weights are never made whole),
#        the model's own word table is left whole and tied, the answers are
#        the same as the whole model's, and the tally says fewer rows were
#        worked than asked for;
#      - the text runner asks for it when the model carries no adapter, and
#        the house says how many layers of each model it holds are run small.
#  User intention (Andrew, 2026-11-13 10:06): "it should have been part of
#    something greater that allowed the models to be used in a dehydrated
#    form. Stop it do all of it and build something for that just to have
#    something in place and then we will alter or refine from there."
#    BUILD_LOG 1600c.
# ============================================================================
"""Intention: a house model's layers kept as distinct rows are run from them, and the answers are the same."""
from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("transformers")
pytest.importorskip("accelerate")
pytest.importorskip("safetensors")

Q_PROJ = "model.layers.0.self_attn.q_proj.weight"
GATE = "model.layers.1.mlp.gate_proj.weight"
TABLE = "model.embed_tokens.weight"


def _tiny_text(folder: Path) -> Path:
    """Intention: a tiny llama with a word tokenizer; two of its layers and its word table have repeated rows."""
    import torch
    from tokenizers import Tokenizer, models, pre_tokenizers
    from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast
    words = ["<pad>", "<eos>", "<unk>", "hello", "cat", "paw", "fur", "the", "is", "made", "of", "\n"]
    raw = Tokenizer(models.WordLevel({w: i for i, w in enumerate(words)}, unk_token="<unk>"))
    raw.pre_tokenizer = pre_tokenizers.WhitespaceSplit()
    tok = PreTrainedTokenizerFast(tokenizer_object=raw, pad_token="<pad>", eos_token="<eos>", unk_token="<unk>")
    config = LlamaConfig(vocab_size=len(words), hidden_size=32, intermediate_size=64, num_hidden_layers=2,
                         num_attention_heads=2, num_key_value_heads=2, max_position_embeddings=64,
                         pad_token_id=0, eos_token_id=1, bos_token_id=1, tie_word_embeddings=True)
    torch.manual_seed(5)
    model = LlamaForCausalLM(config)
    with torch.no_grad():
        parts = dict(model.named_parameters())
        for name, different in ((Q_PROJ, 4), (GATE, 8)):
            weight = parts[name]
            weight.copy_(weight[torch.arange(weight.shape[0]) % different].clone())
        table = parts[TABLE]
        table[10:12] = table[2].clone()
    model.save_pretrained(folder)
    tok.save_pretrained(folder)
    return folder


def _placed() -> dict:
    """Intention: a placement in memory."""
    return {"where": "memory", "kwargs": {}}


def _separate(book, turns: int = 12) -> dict:
    """Intention: separation epochs run down the whole book; how many tensors ended in each form."""
    from projects.behemoth_eye.eye.held_small.epochs import ModelSeparationEpochs
    for _ in range(turns):
        ModelSeparationEpochs(book, max_tensors=8, time_budget_s=30.0).run_epoch()
    return {int(form): int(many) for form, many in book.index.execute("SELECT form, COUNT(*) FROM tensor GROUP BY form")}


def test_layers_kept_as_rows_are_run_from_them_and_the_answers_are_the_same(tmp_path):
    """Intention: the whole path on one model - kept, separated into rows, filled whole, filled small, answered."""
    import torch
    from transformers import AutoModelForCausalLM
    from projects.behemoth_eye.eye.held_small.forms import Rows
    from projects.behemoth_eye.eye.held_small.small_math import linear as worked
    from projects.behemoth_eye.eye.held_small.small_math.layers import SmallLinear
    from warp2.house.held_small.door import WeightsDoor
    from warp2.house.held_small.text_base import TextBase, weight_files
    tiny = _tiny_text(tmp_path / "tiny-llama")
    door = WeightsDoor(tmp_path / "models_small")
    try:
        for file in weight_files(tiny):
            door.keep(tiny, file)
        forms = _separate(door.form.book)
        assert forms.get(Rows.number, 0) == 3, f"the two layers and the word table are kept as rows: {forms}"
        from_files = AutoModelForCausalLM.from_pretrained(str(tiny), torch_dtype=torch.float32,
                                                          low_cpu_mem_usage=True).eval()
        whole = TextBase(door).load(tiny, "float32", _placed())
        assert whole is not None and not hasattr(whole, "small_use")
        a, b = from_files.state_dict(), whole.state_dict()
        assert list(a) == list(b)
        for name in a:
            assert torch.equal(a[name], b[name]), name
        small = TextBase(door, small=True).load(tiny, "float32", _placed())
        assert small is not None
        assert small.small_use == {"layers_run_small": 2, "rows": 32 + 64, "distinct_rows": 4 + 8}
        q_proj = small.model.layers[0].self_attn.q_proj
        gate = small.model.layers[1].mlp.gate_proj
        assert type(q_proj) is SmallLinear and type(gate) is SmallLinear
        assert q_proj.kept.shape == (4, 32) and gate.kept.shape == (8, 32)
        assert Q_PROJ not in small.state_dict() and Q_PROJ.replace("weight", "kept") in small.state_dict()
        assert type(small.model.layers[0].self_attn.k_proj) is torch.nn.Linear, "a layer with no repeated row stays whole"
        assert type(small.get_input_embeddings()) is torch.nn.Embedding, "the model's own word table is left whole"
        assert small.get_output_embeddings().weight is small.get_input_embeddings().weight, "and tied as before"
        asked = torch.tensor([[3, 4, 5, 6]])
        before = worked.TALLY.said()
        with torch.no_grad():
            assert torch.allclose(from_files(asked).logits, small(asked).logits, rtol=1e-4, atol=1e-5)
            assert torch.equal(from_files.generate(asked, max_new_tokens=5, do_sample=False),
                               small.generate(asked, max_new_tokens=5, do_sample=False))
        after = worked.TALLY.said()
        asked_rows = after["rows_asked"] - before["rows_asked"]
        worked_rows = after["rows_worked"] - before["rows_worked"]
        assert asked_rows > 0 and worked_rows * 8 == asked_rows, "12 distinct rows worked for every 96 asked"
        assert after["made_whole"] == before["made_whole"], "no part asked a small layer for its whole weight"
    finally:
        door.close()


def test_the_runner_asks_for_the_small_form_and_the_house_says_what_is_run_small(tmp_path, monkeypatch):
    """Intention: a model with no adapter is loaded with its row-kept layers run small; the house's list of what it
    holds says so, with the count of the small working."""
    from warp2.house.held_small.door import DOORS, door_of, small_home
    from warp2.house.held_small.keep import KeepAll
    from warp2.house.house import House
    from warp2.house.keeper import Keeper
    from warp2.house.shelf import Shelf
    from warp2.house.text_runner import TextRunner
    from warp2.room.budget import Budget
    tiny = _tiny_text(tmp_path / "tiny-llama")
    state = tmp_path / "state"
    shelf = Shelf(tmp_path, state, entries=[{"name": "tiny", "how": "house", "path": str(tiny), "max_tokens": 3}])
    monkeypatch.setattr("warp2.room.split_load.placement", lambda *a, **k: {"where": "memory", "kwargs": {}})
    monkeypatch.setattr(TextRunner, "_type", staticmethod(lambda: "float32"))
    try:
        assert KeepAll(tmp_path, state, shelf=shelf, say=lambda _line: None).run()["kept"] == 1
        assert door_of(small_home(state)) is door_of(str(small_home(state)) + "/"), "one door however the folder is spelled"
        _separate(door_of(small_home(state)).form.book)
        roomy = Budget(free=lambda: 2**40, owed=lambda: 0, held=lambda: 0)
        house = House(tmp_path, state, shelf=shelf, keeper=Keeper(budget=roomy))
        said = house.chat("tiny", "hello cat")
        assert isinstance(said["content"], str)
        held = house.ps()
        assert held["models"][0]["name"] == "tiny"
        assert held["models"][0]["run_small"] == {"layers_run_small": 2, "rows": 96, "distinct_rows": 12}
        assert held["small_math"]["rows_worked"] < held["small_math"]["rows_asked"]
    finally:
        for door in DOORS.values():
            door.close()
        DOORS.clear()
