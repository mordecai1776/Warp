# WARP3/warp2/house/held_small/tests/test_a_small_form_miss_is_said_with_its_trace.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/house/held_small/tests/test_a_small_form_miss_is_said_with_its_trace.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/house/held_small/{text_base,adapter_on,reader_base,picture_parts}.py.
#  Description:
#    When a model, an adapter, a reader or a picture model cannot be filled
#    from its small form, the house still reads its files - and now says the
#    miss WITH its trace. Seen 2026-11-26: house.log said "No module named
#    'behemoth_eye'" 40 times and nothing about where, so every model ran from
#    its weight files and the cause could not be found. BUILD_LOG 2266.
#  User intention (Andrew, 2026-11-12 09:09, BUILD_LOG 1562): "stored and
#    working from the dehydrated tag form".
# ============================================================================
"""Intention: each small-form miss is said with the trace of what failed, and the saved files are still used."""
import logging

import pytest

from warp2.house.held_small import adapter_on, door, picture_parts, reader_base, text_base


class _Fails:
    """Intention: a filler that fails the way the house's did."""

    def __init__(self, *_args, **_kwargs) -> None:
        """Intention: made like the real one."""

    def load(self, *_args, **_kwargs):
        """Intention: the failure seen live."""
        raise ModuleNotFoundError("No module named 'behemoth_eye'")


CASES = [
    (text_base, "TextBase", lambda: text_base.base_from_book("m", "bfloat16", {}, "home"), None),
    (adapter_on, "AdapterOn", lambda: adapter_on.adapter_from_book(object(), "a", "home"), None),
    (reader_base, "ReaderBase", lambda: reader_base.reader_from_book("m", "home"), None),
    (picture_parts, "PictureParts", lambda: picture_parts.parts_from_book("m", "v", None, "home"), {}),
]


@pytest.mark.parametrize("module, name, call, missed", CASES, ids=[case[1] for case in CASES])
def test_a_small_form_miss_is_said_with_its_trace(monkeypatch, caplog, module, name, call, missed):
    monkeypatch.setattr(module, name, _Fails)
    monkeypatch.setattr(door, "door_of", lambda home: object())
    with caplog.at_level(logging.WARNING, logger=module.__name__):
        assert call() == missed
    said = [record for record in caplog.records if record.name == module.__name__]
    assert said and said[-1].exc_info is not None
    assert said[-1].exc_info[0] is ModuleNotFoundError
    assert "_Fails" in caplog.text or "behemoth_eye" in caplog.text
