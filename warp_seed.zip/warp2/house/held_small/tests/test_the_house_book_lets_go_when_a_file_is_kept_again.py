# WARP2/warp2/house/held_small/tests/test_the_house_book_lets_go_when_a_file_is_kept_again.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_the_house_book_lets_go_when_a_file_is_kept_again.py
#  Used by   : pytest.
#  Uses      : warp2/house/held_small/{door,weights_form,adapter_on}.py,
#              projects/behemoth_eye/eye/held_small/book.py; safetensors,
#              torch.
#  Description:
#    Proves that the house's book does not grow each time a weight file is
#    written again (a tag adapter is, by every lesson): kept again and
#    again, the pages stay at two keepings' size and the newest reads back
#    exactly; a tensor two files hold stays while either file does; and a
#    file written again after a model was filled from it is noticed.
#  User intention (Andrew, 2026-11-12 09:49): "ok now for the models all of
#    them". (BUILD_LOG 1568.)
# ============================================================================
from __future__ import annotations

import pytest

pytest.importorskip("safetensors")


def test_a_weight_file_kept_again_and_again_does_not_make_the_book_grow(tmp_path):
    """Intention: an adapter taught again and again costs the book two keepings' room, never more."""
    import torch
    from safetensors.torch import load_file, save_file
    from warp2.house.held_small.door import WeightsDoor
    folder = tmp_path / "adapter"
    folder.mkdir()
    file = folder / "adapter_model.safetensors"
    door = WeightsDoor(tmp_path / "models_small")
    size = lambda: sum(p.stat().st_size for p in (tmp_path / "models_small" / "book").glob("page-*.bin"))
    shared = torch.arange(6, dtype=torch.float32)
    try:
        sizes = []
        for turn in range(8):
            make = torch.Generator().manual_seed(turn)
            save_file({"a": torch.randn(16, 4, generator=make), "b": torch.randn(4, 16, generator=make), "s": shared},
                      str(file))
            door.keep(folder, file)
            sizes.append(size())
        assert sizes[1] == sizes[-1] and sizes[1] < 2 * sizes[0] and door.form.book.count() == 3
        kept = door.read(folder, file)
        for name, value in load_file(str(file)).items():
            assert torch.equal(door.tensor(kept["tensors"][name]), value), name
        assert door.still(folder, [file])
        save_file({"a": torch.zeros(16, 4), "b": torch.zeros(4, 16), "s": shared}, str(file))
        assert not door.still(folder, [file])
    finally:
        door.close()
    print("\n  [OK] eight keepings of one weight file left the book at two keepings' size; a file written again is noticed")
