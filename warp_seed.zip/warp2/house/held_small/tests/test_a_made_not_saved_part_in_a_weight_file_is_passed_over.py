# WARP2/warp2/house/held_small/tests/test_a_made_not_saved_part_in_a_weight_file_is_passed_over.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_a_made_not_saved_part_in_a_weight_file_is_passed_over.py
#  Used by   : pytest.
#  Uses      : warp2/house/held_small/{door,reader_base,filled}.py;
#              transformers, safetensors, torch (a tiny CLIP made here).
#  Description:
#    Proves that a weight file holding a part the model makes for itself and
#    does not save (the picture reader's position counters, as its real file
#    does) still fills the model from the book, equal to the model read from
#    that same file - and that a kept tensor the model has no place for at
#    all still stops the filling.
#  User intention (Andrew, 2026-11-12 09:49): "ok now for the models all of
#    them". (BUILD_LOG 1567.)
# ============================================================================
from __future__ import annotations

import pytest

pytest.importorskip("transformers")
pytest.importorskip("accelerate")
pytest.importorskip("safetensors")


def test_a_made_not_saved_part_is_passed_over_and_a_true_stranger_still_stops(tmp_path):
    """Intention: the reader fills from the book though its file carries position counters; a stranger is refused."""
    import torch
    from safetensors.torch import load_file, save_file
    from transformers import CLIPConfig, CLIPModel, CLIPTextConfig, CLIPVisionConfig
    from warp2.house.held_small.door import WeightsDoor
    from warp2.house.held_small.filled import NotFilled
    from warp2.house.held_small.reader_base import ReaderBase
    folder = tmp_path / "tiny-clip"
    text = CLIPTextConfig(vocab_size=30, hidden_size=16, intermediate_size=20, num_attention_heads=2,
                          num_hidden_layers=1, projection_dim=8, max_position_embeddings=16)
    vision = CLIPVisionConfig(hidden_size=16, intermediate_size=20, num_attention_heads=2, num_hidden_layers=1,
                              projection_dim=8, image_size=16, patch_size=8)
    made = CLIPModel(CLIPConfig(text_config=text.to_dict(), vision_config=vision.to_dict(), projection_dim=8))
    made.save_pretrained(folder)
    file = folder / "model.safetensors"
    held = load_file(str(file))
    counters = {name: value for name, value in made.named_buffers() if name not in made.state_dict()}
    assert counters and not set(counters) & set(held)
    save_file({**held, **{name: value.clone() for name, value in counters.items()}}, str(file), metadata={"format": "pt"})
    door = WeightsDoor(tmp_path / "models_small")
    try:
        door.keep(folder, file)
        from_book = ReaderBase(door).load(folder)
        from_file = CLIPModel.from_pretrained(str(folder)).eval()
        a, b = from_file.state_dict(), from_book.state_dict()
        assert list(a) == list(b)
        for name in a:
            assert torch.equal(a[name], b[name]), name
        for name, value in from_file.named_buffers():
            assert torch.equal(value, dict(from_book.named_buffers())[name]), name
        save_file({**held, "nobody.knows.this": torch.zeros(2)}, str(file), metadata={"format": "pt"})
        door.keep(folder, file)
        with pytest.raises(NotFilled):
            ReaderBase(door).load(folder)
    finally:
        door.close()
    print("\n  [OK] position counters in the file were passed over and the reader filled from the book; a stranger stopped it")
