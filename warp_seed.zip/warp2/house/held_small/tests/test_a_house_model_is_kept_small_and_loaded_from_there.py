# WARP2/warp2/house/held_small/tests/test_a_house_model_is_kept_small_and_loaded_from_there.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/tests/test_a_house_model_is_kept_small_and_loaded_from_there.py
#  Used by   : pytest.
#  Uses      : warp2/house/held_small/{door,weights_form,filled,text_base,keep}.py,
#              warp2/house/{text_runner,house,shelf,keeper}.py; transformers,
#              safetensors, torch (a tiny model made in the test's folder).
#  Description:
#    Proves, on a tiny language model made here:
#      - every tensor of a weight file comes back from the book bit for bit,
#        a kind numpy has no name for (bfloat16) included;
#      - a tensor two files hold is kept once;
#      - the model loaded from the small form is the model its weight files
#        give: every part equal, the same answer to the same prompt;
#      - a weight file changed since it was kept is read as a file, and a
#        model never kept is read from its files;
#      - the text runner loads through the small form when the house hands it
#        the home, and every house model's files are kept by one run that
#        passes over what is already kept.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    (BUILD_LOG 1562.)
# ============================================================================
from __future__ import annotations

import os
from pathlib import Path

import pytest

pytest.importorskip("transformers")
pytest.importorskip("accelerate")
pytest.importorskip("safetensors")


def _tiny_text(folder: Path) -> Path:
    """Intention: a tiny llama with a word tokenizer, saved as a Hugging Face folder."""
    from tokenizers import Tokenizer, models, pre_tokenizers
    from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast
    words = ["<pad>", "<eos>", "<unk>", "hello", "cat", "paw", "fur", "the", "is", "made", "of", "\n"]
    raw = Tokenizer(models.WordLevel({w: i for i, w in enumerate(words)}, unk_token="<unk>"))
    raw.pre_tokenizer = pre_tokenizers.WhitespaceSplit()
    tok = PreTrainedTokenizerFast(tokenizer_object=raw, pad_token="<pad>", eos_token="<eos>", unk_token="<unk>")
    config = LlamaConfig(vocab_size=len(words), hidden_size=32, intermediate_size=64, num_hidden_layers=2,
                         num_attention_heads=2, num_key_value_heads=2, max_position_embeddings=64,
                         pad_token_id=0, eos_token_id=1, bos_token_id=1, tie_word_embeddings=True)
    LlamaForCausalLM(config).save_pretrained(folder)
    tok.save_pretrained(folder)
    return folder


@pytest.fixture(scope="module")
def tiny(tmp_path_factory):
    """Intention: one tiny language model for the module."""
    return _tiny_text(tmp_path_factory.mktemp("models") / "tiny-llama")


@pytest.fixture()
def door(tmp_path):
    """Intention: a door of the test's own, closed afterwards."""
    from warp2.house.held_small.door import WeightsDoor
    made = WeightsDoor(tmp_path / "models_small")
    yield made
    made.close()


def _placed() -> dict:
    """Intention: a placement in memory."""
    return {"where": "memory", "kwargs": {}}


def test_every_tensor_of_a_weight_file_comes_back_bit_for_bit(tmp_path, door):
    """Intention: fractions, whole numbers, bfloat16 and a tensor of no dimensions - the same kind, shape and bits."""
    import torch
    from safetensors.torch import load_file, save_file
    from warp2.house.held_small.weights_form import as_array
    made = {"a": torch.randn(3, 4), "b": torch.randn(5).to(torch.bfloat16), "c": torch.arange(6, dtype=torch.int64),
            "d": torch.tensor(1.5), "e": torch.randn(2, 2).to(torch.float16)}
    folder = tmp_path / "m"
    folder.mkdir()
    save_file(made, str(folder / "model.safetensors"))
    kept = door.keep(folder, folder / "model.safetensors")
    again = load_file(str(folder / "model.safetensors"))
    for name, was in again.items():
        back = door.tensor(kept["tensors"][name])
        assert back.dtype == was.dtype and back.shape == was.shape
        assert as_array(back).tobytes() == as_array(was).tobytes(), name
    print("\n  [OK] five kinds of tensor came back from the book bit for bit")


def test_a_tensor_two_files_hold_is_kept_once(tmp_path, door):
    """Intention: the book keeps each distinct tensor once, however many files hold it."""
    import torch
    from safetensors.torch import save_file
    shared = torch.randn(8, 8)
    folder = tmp_path / "m"
    folder.mkdir()
    save_file({"x": shared, "y": torch.randn(2)}, str(folder / "one.safetensors"))
    save_file({"z": shared}, str(folder / "two.safetensors"))
    door.keep(folder, folder / "one.safetensors")
    before = door.form.book.count()
    door.keep(folder, folder / "two.safetensors")
    assert before == 2 and door.form.book.count() == 2
    print("\n  [OK] a tensor held by two files is in the book once")


def test_the_model_from_the_small_form_is_the_model_from_its_files(tiny, door):
    """Intention: every part equal, and the same answer - loaded from the book, not the files."""
    import torch
    from transformers import AutoModelForCausalLM
    from warp2.house.held_small.text_base import TextBase, weight_files
    for file in weight_files(tiny):
        door.keep(tiny, file)
    from_files = AutoModelForCausalLM.from_pretrained(str(tiny), torch_dtype=torch.float32, low_cpu_mem_usage=True).eval()
    from_book = TextBase(door).load(tiny, "float32", _placed())
    assert from_book is not None
    a, b = from_files.state_dict(), from_book.state_dict()
    assert list(a) == list(b)
    for name in a:
        assert a[name].dtype == b[name].dtype and torch.equal(a[name], b[name]), name
    assert from_book.get_output_embeddings().weight is from_book.get_input_embeddings().weight
    asked = torch.tensor([[3, 4, 5, 6]])
    with torch.no_grad():
        assert torch.equal(from_files(asked).logits, from_book(asked).logits)
        assert torch.equal(from_files.generate(asked, max_new_tokens=5, do_sample=False),
                           from_book.generate(asked, max_new_tokens=5, do_sample=False))
    assert from_files.generation_config.to_dict() == from_book.generation_config.to_dict()
    half = TextBase(door).load(tiny, "bfloat16", _placed())
    half_files = AutoModelForCausalLM.from_pretrained(str(tiny), torch_dtype=torch.bfloat16, low_cpu_mem_usage=True)
    for name, value in half_files.state_dict().items():
        assert half.state_dict()[name].dtype == value.dtype and torch.equal(half.state_dict()[name], value), name
    print("\n  [OK] the model filled from the book equals the model from its files, part for part and answer for answer")


def test_a_changed_file_or_a_model_never_kept_is_read_from_its_files(tmp_path, tiny, door):
    """Intention: an older small form is never used for a newer file; no small form means the files."""
    from warp2.house.held_small.text_base import TextBase, weight_files
    assert TextBase(door).load(tiny, "float32", _placed()) is None
    files = weight_files(tiny)
    for file in files:
        door.keep(tiny, file)
    assert TextBase(door).load(tiny, "float32", _placed()) is not None
    now = os.stat(files[0])
    os.utime(files[0], ns=(now.st_atime_ns, now.st_mtime_ns + 10**9))
    try:
        assert TextBase(door).load(tiny, "float32", _placed()) is None
        assert TextBase(door).load(tiny, "float32", {"where": "split to disk", "kwargs": {}}) is None
    finally:
        os.utime(files[0], ns=(now.st_atime_ns, now.st_mtime_ns))
    print("\n  [OK] a changed weight file, a model never kept, and a model that must wait on disk are read from files")


def test_the_house_keeps_its_models_small_and_its_runner_loads_from_there(tmp_path, tiny, monkeypatch):
    """Intention: one run keeps every house model's files (and passes over them the next time); the text runner,
    handed the home by the house, loads its base from the book."""
    from warp2.house.held_small import text_base
    from warp2.house.held_small.door import DOORS, small_home
    from warp2.house.held_small.keep import KeepAll
    from warp2.house.shelf import Shelf
    from warp2.house.text_runner import TextRunner
    state = tmp_path / "state"
    shelf = Shelf(tmp_path, state, entries=[{"name": "tiny", "how": "house", "path": str(tiny)}])
    said = []
    first = KeepAll(tmp_path, state, shelf=shelf, say=said.append).run()
    again = KeepAll(tmp_path, state, shelf=shelf, say=said.append).run()
    assert first["kept"] == 1 and first["already"] == 0 and again == {"kept": 0, "already": 1, "bytes": 0}
    used = []
    real = text_base.TextBase.load

    def seen(self, path, load_as, placed):
        """Intention: note that the book was used."""
        model = real(self, path, load_as, placed)
        used.append(model is not None)
        return model
    monkeypatch.setattr(text_base.TextBase, "load", seen)
    monkeypatch.setattr("warp2.room.split_load.placement", lambda *a, **k: {"where": "memory", "kwargs": {}})
    monkeypatch.setattr(TextRunner, "_type", staticmethod(lambda: "float32"))
    try:
        runner = TextRunner(tiny, "", small_home=small_home(state)).load()
        assert used == [True] and isinstance(runner.answer("hello cat", 3), str)
        used.clear()
        plain = TextRunner(tiny, "").load()
        assert used == [] and plain.model is not None
    finally:
        for door in DOORS.values():
            door.close()
        DOORS.clear()
    print("\n  [OK] the house's model files were kept once, and the runner loaded its base from the book")
