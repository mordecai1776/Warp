# WARP2/warp2/house/held_small/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/__init__.py
#  Used by   : warp2/house/{house,text_runner,reader_runner}.py,
#              warp2/house/held_small/keep.py.
#  Uses      : nothing of its own.
#  Description:
#    THE HOUSE'S MODELS HELD SMALL. Every weight file of every model the
#    house holds is kept as tags in a tensor book (each distinct tensor
#    once), and the house loads its models from that form.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    (BUILD_LOG 1562.)
# ============================================================================
"""The house's models held small: weight files kept as tags, and models loaded from them."""
