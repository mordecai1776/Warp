# WARP2/warp2/house/held_small/filled.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/filled.py
#  Used by   : warp2/house/held_small/{text_base,reader_base}.py, tests/.
#  Uses      : accelerate (set_module_tensor_to_device), torch.
#  Description:
#    A MODEL BUILT EMPTY AND FILLED FROM THE BOOK, ONE TENSOR AT A TIME. Each
#    tensor is read from its place and put straight where it belongs (the
#    card, or memory), as the kind the model is loaded as - so the model is
#    never in memory twice. A tensor name the model does not have, or a part
#    of the model left empty, stops the filling and is said; nothing half
#    filled is ever handed on.
#  User intention (Andrew, 2026-11-12 09:09): the internal models "stored and
#    working from the dehydrated tag form". 2026-11-11 21:31: memory used in
#    the moment, in smaller parts. (BUILD_LOG 1562.)
# ============================================================================
"""A model built with empty weights and filled from the tensor book, a tensor at a time, onto its devices."""
from __future__ import annotations


class NotFilled(RuntimeError):
    """Intention: the small form does not fill this model whole; the weight files are read instead."""


def device_of(name: str, device_map: dict):
    """Intention: where a tensor goes - the place its nearest named part of the model was given."""
    part = name
    while True:
        if part in device_map:
            return device_map[part]
        if not part:
            raise NotFilled(f"no place was given for {name}")
        part = part.rpartition(".")[0]


class Filled:
    """Intention: the filling of one empty model from a door's small forms."""

    def __init__(self, door) -> None:
        """Intention: the door the tensors are read through."""
        self.door = door

    def fill(self, model, tensors: dict, kind, device_map: dict) -> int:
        """Intention: every kept tensor put where it belongs, as `kind` when it holds fractions; how many."""
        from accelerate.utils import set_module_tensor_to_device
        known = set(model.state_dict().keys())
        # Intention (BUILD_LOG 1567, found on the real picture reader: its weight file holds two position counters the
        # model now makes for itself and does not save): a kept tensor that is one of the model's own made-not-saved
        # parts is passed over, as the library passes it over when it reads the file - the model keeps the one it
        # made. Any other kept tensor the model has no place for still stops the filling.
        own = {name for name, _value in model.named_buffers()} - known
        strangers = sorted(set(tensors) - known - own)
        if strangers:
            raise NotFilled(f"{len(strangers)} kept tensors are not parts of this model (first: {strangers[0]})")
        for name, kept in tensors.items():
            if name in own:
                continue
            value = self.door.tensor(kept)
            set_module_tensor_to_device(model, name, device_of(name, device_map), value=value,
                                        dtype=kind if value.is_floating_point() else None)
        return len(set(tensors) - own)

    @staticmethod
    def whole(model) -> None:
        """Intention: no part of the model left empty - said, with the first part, when one is."""
        empty = [name for name, value in model.state_dict().items() if value.is_meta]
        if empty:
            raise NotFilled(f"{len(empty)} parts of the model were not filled (first: {empty[0]})")
