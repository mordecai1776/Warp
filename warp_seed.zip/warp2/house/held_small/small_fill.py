# WARP2/warp2/house/held_small/small_fill.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/small_fill.py
#  Used by   : warp2/house/held_small/text_base.py (TextBase.load, for a
#              model that carries no adapter), warp2/house/held_small/
#              filled.py (Filled.fill asks `take` for each kept tensor);
#              warp2/house/tests/.
#  Uses      : warp2/house/held_small/filled.py (device_of),
#              warp2/house/held_small/door.py (WeightsDoor.rows_of),
#              projects/behemoth_eye/eye/held_small/small_math/layers.py
#              (SmallLinear, SmallEmbedding); torch.
#  Description:
#    WHILE A MODEL IS FILLED FROM THE BOOK, A LAYER KEPT AS DISTINCT ROWS IS
#    RUN FROM THEM. For each kept weight the filling asks `take`: when the
#    weight belongs to an ordinary layer or table (torch.nn.Linear,
#    torch.nn.Embedding - exactly those, nothing made from them) and the
#    book keeps it as its distinct rows (form 4), a layer that works on those
#    rows is put in its place and the weight is never made whole. Everything
#    else is filled as before.
#    Left whole on purpose: the model's own word tables going in and coming
#    out (the model ties them together and reads their `weight`); and every
#    layer of a model that will carry an adapter (text_runner.py asks for
#    none of this then).
#    `said()` is what it came to: layers run small, their rows and distinct
#    rows.
#  User intention (Andrew, 2026-11-13 10:06): "it should have been part of
#    something greater that allowed the models to be used in a dehydrated
#    form. Stop it do all of it and build something for that just to have
#    something in place and then we will alter or refine from there."
#    BUILD_LOG 1600c.
# ============================================================================
"""While a model is filled from the book, a layer kept as distinct rows is put in as a layer run from them."""
from __future__ import annotations

from warp2.house.held_small.filled import device_of

WEIGHT = ".weight"


class SmallFill:
    """Intention: the layers of one model that are run from their kept rows, decided as it is filled."""

    def __init__(self, door, model, kind, device_map: dict) -> None:
        """Intention: the door the rows come through, the model, the kind its fractions are held as, and where
        each part of it goes."""
        self.door, self.kind, self.device_map = door, kind, dict(device_map)
        self.modules = dict(model.named_modules())
        self.whole = self._tied(model)
        self.layers = 0
        self.rows = 0
        self.distinct = 0

    def _tied(self, model) -> set:
        """Intention: the names of the model's own word tables, going in and coming out - left whole."""
        named = set()
        for asked in ("get_input_embeddings", "get_output_embeddings"):
            getter = getattr(model, asked, None)
            table = getter() if callable(getter) else None
            named.update(name for name, module in self.modules.items() if table is not None and module is table)
        return named

    def take(self, name: str, kept: dict) -> bool:
        """Intention: whether this kept tensor was put in as a layer run from its rows (then it is not filled whole)."""
        import torch
        if not name.endswith(WEIGHT):
            return False
        owner = name[:-len(WEIGHT)]
        module = self.modules.get(owner)
        if type(module) not in (torch.nn.Linear, torch.nn.Embedding) or owner in self.whole:
            return False
        small = self.door.rows_of(kept)
        if small is None:
            return False
        from projects.behemoth_eye.eye.held_small.small_math.layers import SmallEmbedding, SmallLinear
        if small.kept.is_floating_point():
            small = small.to(dtype=self.kind)
        small = small.to(device=device_of(name, self.device_map))
        if type(module) is torch.nn.Linear:
            layer = SmallLinear(small, module.bias)
        else:
            layer = SmallEmbedding(small, module.padding_idx)
        parent, _, leaf = owner.rpartition(".")
        setattr(self.modules[parent], leaf, layer)
        self.modules[owner] = layer
        self.layers += 1
        self.rows += small.rows
        self.distinct += small.distinct
        return True

    def said(self) -> dict:
        """Intention: what it came to, as plain numbers."""
        return {"layers_run_small": self.layers, "rows": self.rows, "distinct_rows": self.distinct}
