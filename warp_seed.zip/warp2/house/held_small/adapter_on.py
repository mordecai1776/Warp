# WARP2/warp2/house/held_small/adapter_on.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/adapter_on.py
#  Used by   : warp2/house/text_runner.py (a language model's tag adapter),
#              tests/.
#  Uses      : warp2/house/held_small/{door,model_files}.py; peft (only when
#              an adapter is put on).
#  Description:
#    A TAG ADAPTER PUT ON FROM ITS SMALL FORM. peft puts the adapter on in
#    its own way, exactly as before; only the one step where it reads the
#    adapter's weight file is answered from the tensor book instead. None -
#    and peft reads the file as before - when the adapter has no small form
#    that still matches its file (a tag lesson writes the adapter again;
#    its small form is kept again by the next keep run), or when anything
#    here fails, which is said in the log.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    (BUILD_LOG 1563.)
# ============================================================================
"""A tag adapter put on by peft with its weights answered from the small form; None when its file must be read."""
from __future__ import annotations

import logging
from contextlib import contextmanager
from pathlib import Path

SAID = logging.getLogger(__name__)

# Intention: the name peft gives an adapter's weights.
ADAPTER = "adapter_model"


@contextmanager
def answered_from(weights: dict):
    """Intention: while an adapter is put on, peft's reading of its weight file is answered with these tensors, moved
    to the device it asks for; put back as it was afterwards, whatever happens."""
    import peft.peft_model as where
    before = where.load_peft_weights

    def from_book(model_id, device=None, **asked):
        """Intention: the adapter's tensors, on the device peft asked for."""
        return {name: value.to(device) if device is not None else value for name, value in weights.items()}
    where.load_peft_weights = from_book
    try:
        yield
    finally:
        where.load_peft_weights = before


class AdapterOn:
    """Intention: one adapter, from the book."""

    def __init__(self, door) -> None:
        """Intention: the door its small form is read through."""
        self.door = door

    def load(self, model, adapter, **limits):
        """Intention: the model with its adapter on; None when the adapter's file must be read instead. `limits`
        (BUILD_LOG 1572) are the limits the model was placed within, handed on to peft so it places nothing past them."""
        from warp2.house.held_small.model_files import model_files
        files = model_files(adapter, ADAPTER, door=self.door)
        tensors = self.door.whole(adapter, files) if files else None
        if tensors is None:
            return None
        from peft import PeftModel
        weights = {name: self.door.tensor(kept) for name, kept in tensors.items()}
        if not self.door.still(adapter, files):   # BUILD_LOG 1568: a weight file written again while this was filled may have had its places given away
            return None
        with answered_from(weights):
            return PeftModel.from_pretrained(model, str(adapter), **limits)


def adapter_from_book(model, adapter, home, **limits):
    """Intention: for the text runner - the adapter put on from its small form, or None to let peft read its file."""
    if not home:
        return None
    from warp2.house.held_small.door import door_of
    try:
        return AdapterOn(door_of(home)).load(model, adapter, **limits)
    except Exception as err:  # fault: ok - the adapter file is the saved copy; the small form is only missed, and said
        SAID.warning("%s adapter not put on from its small form (%s: %s); its file is read",
                     Path(adapter).name, type(err).__name__, err)
        return None
