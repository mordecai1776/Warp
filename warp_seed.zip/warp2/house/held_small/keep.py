# WARP2/warp2/house/held_small/keep.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/held_small/keep.py
#  Used by   : python -m warp2.house.held_small.keep <root> <state>; tests/.
#  Uses      : warp2/house/shelf.py (the house's models),
#              warp2/house/held_small/door.py.
#  Description:
#    EVERY HOUSE MODEL'S WEIGHT FILES KEPT SMALL. For each model on the
#    house's shelf, and its tag adapter when it has one, every safetensors
#    file under its folder that has no small form matching it now is put in
#    the tensor book. A file already kept and unchanged is passed over, so
#    this can be run again at any time. It says each file as it goes.
#  User intention (Andrew, 2026-11-12 09:09): "We need to get the internal
#    models all of them stored and working from the dehydrated tag form".
#    2026-11-09: long work shows itself as it runs. (BUILD_LOG 1562.)
# ============================================================================
"""Every weight file of every house model kept small in the tensor book; files already kept are passed over."""
from __future__ import annotations

import sys
import time
from pathlib import Path


class KeepAll:
    """Intention: the keeping of every house model's weight files."""

    def __init__(self, root, state, shelf=None, say=print) -> None:
        """Intention: the WARP's root and state, the shelf of models, and where progress is said."""
        from warp2.house.held_small.door import door_of, small_home
        from warp2.house.shelf import Shelf
        self.shelf = shelf or Shelf(root, state)
        self.door = door_of(small_home(state))
        self.say = say

    def folders(self) -> list:
        """Intention: every folder that holds a house model's weights - each model, and its adapter when there is one."""
        found = []
        for entry in self.shelf.entries():
            for folder in (Path(entry["path"]), self.shelf.adapter(entry["name"])):
                if folder.is_dir() and folder not in found:
                    found.append(folder)
        return found

    def run(self) -> dict:
        """Intention: {"kept", "already", "bytes"} - each weight file kept or passed over, said as it goes."""
        from warp2.house.held_small.door import WEIGHTS
        done = {"kept": 0, "already": 0, "bytes": 0}
        for folder in self.folders():
            for file in sorted(f for f in folder.rglob(WEIGHTS) if f.is_file()):
                size = file.stat().st_size
                if self.door.fresh(folder, file):
                    done["already"] += 1
                    self.say(f"  already kept: {folder.name}/{file.relative_to(folder)}")
                    continue
                began = time.time()
                kept = self.door.keep(folder, file)
                done["kept"] += 1
                done["bytes"] += size
                self.say(f"  kept: {folder.name}/{file.relative_to(folder)} - {len(kept['tensors'])} tensors, "
                         f"{size / 2**20:.0f} MB in {time.time() - began:.0f} s")
        return done

    def separate_epoch(self, max_tensors: int = 64, time_budget_s: float = 1.5) -> dict:
        """Intention (Andrew, 2026-11-11 22:02-22:25): run one bounded epoch of tensor separation (BaseDiff, Chunked,
        SetGroup) on the house's tensor book, judged by time and byte gain and verified bit-for-bit."""
        from projects.behemoth_eye.eye.held_small.epochs import ModelSeparationEpochs
        book = self.door._form().book
        return ModelSeparationEpochs(book, max_tensors=max_tensors, time_budget_s=time_budget_s).run_epoch()


def main(argv=None) -> int:
    """Intention: the door - the WARP's root and state."""
    argv = list(sys.argv[1:] if argv is None else argv)
    done = KeepAll(argv[0], argv[1], say=lambda line: print(line, flush=True)).run()
    print(f"kept {done['kept']} files ({done['bytes'] / 2**30:.2f} GB), {done['already']} already kept", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
