# WARP2/warp2/house/reader_runner.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/reader_runner.py
#  Used by   : warp2/house/house.py (a picture reader the house holds).
#  Uses      : torch, transformers (CLIPModel, CLIPProcessor), PIL - only when
#              the model is loaded; warp2/room/split_load.py (loaded_bytes,
#              card_free).
#              warp2/tags/media/pictures.py (open_picture - a picture is opened
#              from its small form first; BUILD_LOG 1591c);
#  Description:
#    ONE PICTURE READER (a CLIP model), HELD BY THE HOUSE - the WARP's own eyes
#    on a picture, in place of Ollama's vision models. It answers the one
#    question the readers are asked - does this picture show the subject? -
#    as a chance, from the model's own measure: how alike the picture is to
#    "a photo of <subject>" against "a photo of something else", at the
#    scale the model itself learned. With a real picture of the subject to
#    hand it also says the chance the made picture is the same kind of thing:
#    its likeness to the real picture against its likeness to "something
#    else". On the card when it fits there, else on the processor.
#  User intention (Andrew, 2026-11-09 18:49): "use only internal models".
#    19:05: "holds models like ollama and comfy could inside the warp". With
#    Ollama's readers gone no searched picture could be judged; this is the
#    house's own reader. (BUILD_LOG 1485.)
# ============================================================================
"""One picture reader held by the house: the chance a picture shows a subject, by the model's own measure."""
from __future__ import annotations
from warp2.tags.media.pictures import open_picture

from pathlib import Path

# Intention: what a picture is set against - the plain other answer to "does it show the subject".
OTHER = "a photo of something else"


def asked(subject: str) -> str:
    """Intention: the words the picture is compared with for a subject."""
    return f"a photo of {subject}"


def _unit(got):
    """Intention: the model's directions at length one - newer transformers hand them back inside an output object."""
    got = getattr(got, "pooler_output", got)
    return got / got.norm(dim=-1, keepdim=True)


class ReaderRunner:
    """A CLIP model and its processor, loaded once, reading pictures."""

    def __init__(self, path, small_home=None) -> None:
        """Intention: the model's folder, and where the house's models are held small (BUILD_LOG 1563) - with none,
        the weight file is read; nothing is loaded yet."""
        self.path = Path(path)
        self.small_home = Path(small_home) if small_home else None
        self.model = self.processor = None
        self.where = ""

    def need(self) -> int:
        """Intention: the bytes this model takes as it is loaded."""
        if self.small_home is not None:
            from warp2.house.held_small.door import door_of
            door_of(self.small_home)
        from warp2.room.split_load import loaded_bytes
        return loaded_bytes(self.path, "float32")

    def load(self) -> "ReaderRunner":
        """Intention: the model on the card when it fits there, else on the processor."""
        import torch
        from transformers import CLIPModel, CLIPProcessor
        from warp2.room.split_load import card_free
        self.processor = CLIPProcessor.from_pretrained(str(self.path))
        # Intention (Andrew 2026-11-12 09:09, BUILD_LOG 1563): from its small form; its weight file only when it has none.
        from warp2.house.held_small.reader_base import reader_from_book
        model = reader_from_book(self.path, self.small_home)
        if model is None:
            model = CLIPModel.from_pretrained(str(self.path))
        on_card = torch.cuda.is_available() and self.need() <= card_free()
        self.model = model.to("cuda" if on_card else "cpu").eval()
        self.where = "card" if on_card else "processor"
        return self

    def _pictures(self, paths: list):
        """Intention: each picture's direction in the model's space, length one."""
        import torch
        from PIL import Image
        opened = [open_picture(p).convert("RGB") for p in paths]
        device = next(self.model.parameters()).device
        with torch.no_grad():
            got = self.model.get_image_features(**self.processor(images=opened, return_tensors="pt").to(device))
        return _unit(got)

    def _words(self, words: list):
        """Intention: each phrase's direction in the model's space, length one."""
        import torch
        device = next(self.model.parameters()).device
        with torch.no_grad():
            got = self.model.get_text_features(**self.processor(text=words, return_tensors="pt",
                                                                padding=True, truncation=True).to(device))
        return _unit(got)

    def read(self, image, subject: str, reference: str = "") -> dict:
        """Intention: {"yes_chance", "same_chance"} - the second only with a real picture of the subject to hand."""
        import torch
        scale = self.model.logit_scale.exp().detach()
        pictures = self._pictures([image] + ([reference] if reference else []))
        words = self._words([asked(subject), OTHER])
        made = pictures[0]
        yes = torch.softmax(scale * (made @ words.T), dim=-1)[0]
        same = None
        if reference:
            same = float(torch.softmax(scale * torch.stack([made @ pictures[1], made @ words[1]]), dim=-1)[0])
        return {"yes_chance": float(yes), "same_chance": same, "where": self.where}

    def close(self) -> None:
        """Intention: the model and processor let go."""
        self.model = self.processor = None
