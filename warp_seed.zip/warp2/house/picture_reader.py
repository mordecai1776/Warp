# WARP2/warp2/house/picture_reader.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/picture_reader.py
#  Used by   : warp2/ask/visual.py (_readers: the readers that judge a picture
#              when only internal models are used).
#  Uses      : warp2/house/{client,shelf}.py; projects/centering_image/readers.py
#              (the same evidence shape and helpers every reader gives:
#              _as_tag, _concepts_of, _visual_ops_of, _quality_of),
#              warp2/house/reader_runner.py (asked, OTHER - what it was asked,
#              for its judge id); stdlib hashlib, json, time.
#  Description:
#    A HOUSE PICTURE READER, AS THE PICTURE WORK KNOWS A READER. It has the
#    same `read(image, tag)` the Ollama readers had and gives the same
#    evidence: a score that is the reader's own chance of "yes" (score_kind
#    explicit), its answer (yes when "the subject" is the likelier of the two
#    it was set against, else no), the comparison with a real picture when
#    there is one, the picture's own measurements, and who judged - the
#    model's name and a hash of what it was asked, so its scores are never
#    mixed with another judge's. It cannot describe a picture in words; its
#    observation says plainly what it measured.
#  User intention (Andrew, 2026-11-09 18:49): "use only internal models".
#    Standing: a picture passes only when every reader answered and none said
#    the subject is not there. (BUILD_LOG 1485.)
# ============================================================================
"""A house picture reader with the readers' own shape: read(image, tag) -> the evidence a pass rule reads."""
from __future__ import annotations

import hashlib
import json
import time


def house_readers(root, state) -> list:
    """Intention: one reader per picture-reading model on the house's shelf; none when the shelf has none."""
    from warp2.house.shelf import Shelf
    return [HouseReader(root, state, name) for name in Shelf(root, state).names("reader")]


class HouseReader:
    """One house model that reads pictures, asked through the house."""

    def __init__(self, root, state, name: str, client=None) -> None:
        """Intention: the model's name and the house to ask; a test hands in its own client."""
        from warp2.house.client import HouseClient
        self.name = str(name)
        self.client = client or HouseClient(root, state)

    def judge(self) -> str:
        """Intention: who judged - the model and a hash of what it is asked."""
        from warp2.house.reader_runner import OTHER, asked
        text = json.dumps([asked("{subject}"), OTHER, "likeness to a real picture against " + OTHER])
        return f"{self.name}#{hashlib.sha256(text.encode('utf-8')).hexdigest()[:12]}"

    def read(self, image_path: str, tag) -> dict:
        """Intention: the evidence for one picture, in the shape every reader gives."""
        from readers import _as_tag, _concepts_of, _quality_of, _visual_ops_of
        tag = _as_tag(tag)
        subject = tag["name"]
        reference = str((tag.get("data") or {}).get("reference") or "")
        began = time.monotonic()
        said = self.client.read(self.name, str(image_path), subject, reference)
        chance = float(said["yes_chance"])
        other = 1.0 - chance
        answer = "yes" if chance > other else "no"
        same = said.get("same_chance")
        observation = (f"{self.name} measured the picture against '{subject}' and against something else: "
                       f"chance {chance:.3f} that it shows {subject}.")
        difference = f'Reader answered "{answer}" to whether it shows {subject}'
        visual_ops = _visual_ops_of(image_path, tag)
        return dict(name=self.name, observation=observation, difference=difference, score=round(chance, 6),
                    answer=answer, yes_chance=round(chance, 6), quality=_quality_of(None, visual_ops),
                    reference_answer=("" if same is None else "yes" if float(same) > 1.0 - float(same) else "no"),
                    reference_chance=(None if same is None else round(float(same), 6)),
                    detected_concepts=_concepts_of(None, observation, tag, chance, difference),
                    visual_operations=visual_ops, score_kind="explicit",
                    basis="reader chance of yes (picture against the subject's words and against something else)",
                    raw=observation, model=self.name, judge=self.judge(),
                    duration_seconds=round(time.monotonic() - began, 3))
