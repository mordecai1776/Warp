# WARP2/warp2/house/image_runner.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/image_runner.py
#  Used by   : warp2/house/house.py (a picture model the house holds).
#  Uses      : torch, diffusers (only when the model is loaded);
#              warp2/room/split_load.py (card_free).
#  Description:
#    ONE PICTURE MODEL (a diffusers pipeline, Stable Diffusion 1.5), LOADED
#    TO FIT - the ComfyUI side of the house. Its size is its weight files (the
#    half-size copies when the folder has them). With a card that holds it
#    all, it runs on the card; with a smaller card, each part is moved onto
#    the card only while it works (sequential offload - the AirLLM way for
#    pictures); with no card, on the processor at full precision. A picture is
#    drawn for one prompt with the seed asked - at the model's own size and
#    steps unless others are asked - and saved.
#  User intention (Andrew, 2026-11-09 19:05): "holds models like ollama and
#    comfy could inside the warp" - chosen: SD 1.5. (BUILD_LOG 1484.)
# ============================================================================
"""One picture model, loaded to fit what the machine has, drawing a picture for a prompt."""
from __future__ import annotations

from pathlib import Path

# Intention: the half-size weight files a diffusers folder can hold beside the full ones.
HALF = "fp16"


class ImageRunner:
    """A diffusers pipeline, loaded once, drawing pictures."""

    def __init__(self, path, small_home=None) -> None:
        """Intention: the pipeline's folder, and where the house's models are held small (BUILD_LOG 1563) - with none,
        the weight files are read; nothing is loaded yet."""
        self.path = Path(path)
        self.small_home = Path(small_home) if small_home else None
        self.pipe = None
        self.where = ""

    def half(self) -> bool:
        """Intention: whether the folder holds the half-size weights (on disk or in the small form)."""
        if any(self.path.rglob(f"*.{HALF}.safetensors")):
            return True
        if self.small_home is not None:
            from warp2.house.held_small.door import safe
            kept_dir = self.small_home / safe(self.path.name)
            if kept_dir.is_dir():
                return any(f".{HALF}." in p.name for p in kept_dir.glob("*.json"))
        return False

    def need(self) -> int:
        """Intention: the bytes of the weights that will be loaded - the half-size ones when there are any, from
        disk or from their small forms when only those remain."""
        is_half = self.half()
        pattern = f"*.{HALF}.safetensors" if is_half else "*.safetensors"
        found = [f for f in self.path.rglob(pattern) if f.is_file()]
        if not is_half:
            found = [f for f in found if f".{HALF}." not in f.name]
        on_disk = sum(f.stat().st_size for f in found) or sum(f.stat().st_size for f in self.path.rglob("*.bin"))
        if on_disk or self.small_home is None:
            return on_disk
        from warp2.house.held_small.door import safe
        from warp2.record.kept_file import read_kept
        kept_dir = self.small_home / safe(self.path.name)
        if not kept_dir.is_dir():
            return 0
        total = 0
        for item in kept_dir.glob("*.json"):
            if is_half and f".{HALF}." not in item.name:
                continue
            if not is_half and f".{HALF}." in item.name:
                continue
            stamp = (read_kept(item, {}) or {}).get("stamp") or []
            if stamp:
                total += int(stamp[0])
        return total

    def load(self) -> "ImageRunner":
        """Intention: the pipeline placed on the card, part by part onto it, or on the processor."""
        import torch
        from diffusers import StableDiffusionPipeline
        from warp2.room.split_load import card_free
        card = torch.cuda.is_available()
        kwargs = {"torch_dtype": torch.float16 if card else torch.float32}
        if self.half():
            kwargs["variant"] = HALF
        # Intention (Andrew 2026-11-12 09:09, BUILD_LOG 1563): the parts with weights come from their small forms and
        # the pipeline reads none of their files; with no small form that matches, it reads the files as before.
        from warp2.house.held_small.picture_parts import parts_from_book
        parts = parts_from_book(self.path, kwargs.get("variant", ""), kwargs["torch_dtype"], self.small_home)
        pipe = StableDiffusionPipeline.from_pretrained(str(self.path), **kwargs, **parts)
        if card and self.need() <= card_free():
            pipe = pipe.to("cuda")
            self.where = "card"
        elif card:
            pipe.enable_sequential_cpu_offload()
            self.where = "card, a part at a time"
        else:
            self.where = "processor"
        self.pipe = pipe
        return self

    def draw(self, prompt: str, out, seed: int, steps: int = 0, width: int = 0, height: int = 0) -> dict:
        """Intention: one picture for the prompt, saved at `out`; steps and size are the model's own unless asked."""
        import torch
        asked = {"generator": torch.Generator(device="cpu").manual_seed(int(seed))}
        for name, value in (("num_inference_steps", steps), ("width", width), ("height", height)):
            if int(value) > 0:
                asked[name] = int(value)
        picture = self.pipe(str(prompt), **asked).images[0]
        out = Path(out)
        out.parent.mkdir(parents=True, exist_ok=True)
        picture.save(out)
        return {"path": str(out), "where": self.where, "size": list(picture.size)}

    def close(self) -> None:
        """Intention: the pipeline let go."""
        self.pipe = None
