# WARP2/warp2/house/server.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/server.py
#  Used by   : warp2/house/client.py (starts it: python -m warp2.house.server
#              <root> <state>).
#  Uses      : warp2/house/house.py, warp2/room/own_fence.py,
#              warp2/record/{processes,stop,kept_file}.py; stdlib http.server,
#              json, os, sys.
#  Description:
#    THE HOUSE'S ONE PROCESS. It listens on this machine only (127.0.0.1, a
#    port the machine gives it), says where in state/house/address.json, and
#    answers one request at a time - so two models are never loaded at once
#    by two askers. It is on the WARP's register, so ALL_STOP ends it, and
#    it ends itself when ALL_STOP is raised. It fences itself (on Windows, a
#    job object around its own process) to what it holds plus the room a new
#    piece of work may take, measured again before every request.
#      POST /api/chat     {model, messages | prompt, options.num_predict}
#      POST /api/draw     {model, prompt, seed, steps, width, height}
#      POST /api/read     {model, image, subject, reference}
#      POST /api/put_down {model}            GET /api/ps    GET /api/tags
#  User intention (Andrew, 2026-11-09 19:05): "a system that holds models like
#    ollama and comfy could inside the warp". (BUILD_LOG 1484; its fence is
#    the shared warp2/room/own_fence.py since BUILD_LOG 1485.)
# ============================================================================
"""The house's one process: answers on this machine only, one request at a time, fenced to its room."""
from __future__ import annotations

import json
import os
import sys
import traceback
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path


def address_file(state) -> Path:
    """Intention: where the house says it is listening."""
    return Path(state) / "house" / "address.json"


def _handler(house, fenced):
    """Intention: the request handler bound to this house."""

    class Handler(BaseHTTPRequestHandler):
        """One request: read, answer as JSON."""

        def log_message(self, *args) -> None:
            """Intention: quiet - what was asked is in the answers, not a console."""

        def _send(self, code: int, body: dict) -> None:
            """Intention: one JSON answer."""
            data = json.dumps(body).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:
            """Intention: what is held, and what is on the shelf."""
            if self.path == "/api/ps":
                self._send(200, house.ps())
            elif self.path == "/api/tags":
                self._send(200, house.tags())
            else:
                self._send(404, {"error": f"no {self.path}"})

        def do_POST(self) -> None:
            """Intention: chat, draw, or put down - a model that cannot be had says why."""
            asked = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
            fenced.again()
            try:
                if self.path == "/api/chat":
                    prompt = asked.get("prompt") or "\n".join(str(m.get("content", "")) for m in asked.get("messages", []))
                    got = house.chat(asked["model"], prompt, int((asked.get("options") or {}).get("num_predict") or 0))
                    self._send(200, {"model": got["model"], "where": got["where"],
                                     "message": {"role": "assistant", "content": got["content"]}, "done": True})
                elif self.path == "/api/draw":
                    self._send(200, house.draw(asked["model"], asked.get("prompt", ""), int(asked.get("seed") or 0),
                                               int(asked.get("steps") or 0), int(asked.get("width") or 0),
                                               int(asked.get("height") or 0)))
                elif self.path == "/api/read":
                    self._send(200, house.read(asked["model"], asked["image"], asked.get("subject", ""),
                                               str(asked.get("reference") or "")))
                elif self.path == "/api/put_down":
                    self._send(200, house.put_down(str(asked.get("model") or "")))
                else:
                    self._send(404, {"error": f"no {self.path}"})
            except KeyError as exc:
                self._send(404, {"error": str(exc).strip("'\"")})
            except Exception as exc:  # fault: ok - the asker is told why, and the house goes on serving
                # Intention: keep the failing loader's stack and stage notes across HTTP; no locals or prompts.
                self._send(500, {"error": "".join(traceback.format_exception(exc))})

    return Handler


def serve(root, state, house=None, stop=None, board=None, fenced=None) -> None:
    """Intention: listen, say where, answer one request at a time until ALL_STOP; leave the register on the way out.
    A test hands in its own house, stop, register and fence (BUILD_LOG 1487: a test must not fence the test run)."""
    from warp2.house.house import House
    from warp2.record import heartbeat
    from warp2.record.kept_file import write_kept
    from warp2.record.stop import Halt
    house = house or House(root, state)
    stop = stop or Halt(state)
    if fenced is None:
        from warp2.room.own_fence import OwnFence
        fenced = OwnFence()
    server = HTTPServer(("127.0.0.1", 0), _handler(house, fenced))
    server.timeout = float(heartbeat.BEAT_SECONDS)
    if board is None:
        from warp2.record.processes import Processes
        board = Processes()
    board.register("house")
    write_kept(address_file(state), {"host": "127.0.0.1", "port": server.server_address[1], "pid": os.getpid()})
    try:
        while not stop.raised():
            server.handle_request()
            # Intention (BUILD_LOG 1487): KEPT ONLY WHILE THERE IS ROOM. Each wake - a request answered, or a beat
            # with none - the house looks at the machine's room and puts down its longest-unused model when none is
            # left for new work (warp2/house/keeper.py).
            house.give_back()
    finally:
        server.server_close()
        house.put_down()
        board.unregister()


def main(argv=None) -> int:
    """Intention: the door - the WARP's root and state."""
    argv = list(sys.argv[1:] if argv is None else argv)
    serve(argv[0], argv[1])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
