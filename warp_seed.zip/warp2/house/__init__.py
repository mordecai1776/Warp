# WARP2/warp2/house/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/__init__.py
#  Used by   : warp2/models/roster.py (models reached "how": "house"),
#              warp2/ask/subconcepts.py, warp2/work/side/house_steps.py.
#  Uses      : warp2/house/{shelf,keeper,text_runner,image_runner,house,
#              server,client,tag_lessons,tag_lora,fetch_model}.py.
#  Description:
#    THE MODEL HOUSE: the WARP's own Ollama and ComfyUI. One process of the
#    WARP's (warp2.house.server) holds its models - language models from
#    Hugging Face folders and a picture model (Stable Diffusion 1.5) - and
#    answers on this machine only. A model stays loaded while the room has
#    space for it; the one used longest ago is put down when another needs
#    the room. Every model is loaded to fit (the card, the card and memory,
#    or a layer at a time from disk), and the house fences itself to the
#    room it may hold, re-measured on every request. Its language models
#    carry LoRA adapters taught to read and write the Eye's tags.
#  User intention (Andrew, 2026-11-09 19:05): "lets build out a system that
#    holds models like ollama and comfy could inside the warp and go from
#    there. We should also probably add back in loras and training those new
#    models to give adaptation to at least run from compressed tags like the
#    eye as well as some limited advancement but keep the bulk on the eye
#    still." Chosen: SD 1.5; tags both ways; kept while there is room.
#    (BUILD_LOG 1484.)
# ============================================================================
"""The WARP's own model house: language and picture models held inside the WARP, fitted to its room."""
