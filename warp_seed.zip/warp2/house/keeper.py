# WARP2/warp2/house/keeper.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/keeper.py
#  Used by   : warp2/house/house.py.
#  Uses      : warp2/room/budget.py (the room a new model may take); psutil
#              (what loading a model cost this process).
#  Description:
#    WHAT THE HOUSE HOLDS, AND WHAT GOES WHEN ROOM IS NEEDED. Each loaded
#    model is kept with what loading it cost this process (measured: the
#    working set before and after) and when it was last used. Before a model
#    is loaded, the ones used longest ago are put down until its measured
#    size fits the room a new piece of work may take now - the way Ollama
#    keeps models, but by the WARP's own room, not a set count or a timer.
#    AND GIVEN BACK WHEN THE ROOM GOES. Kept "while there is room" is looked
#    at as the house waits, not only when a model is loaded: when the machine
#    has no room left for a new piece of work, the model used longest ago is
#    put down, one a look, until there is room again or nothing is held.
#  User intention (Andrew, 2026-11-09 19:05): "holds models like ollama ...
#    inside the warp" - chosen: kept while there is room. (BUILD_LOG 1484.)
#    2026-11-09 18:37: "if it doesn't have enough, it needs to adjust."
#    (BUILD_LOG 1487: measured 22:33 - the house held 5.9 GB with 1.4 GB
#    free on the machine, and a test beside it ran past its ten minutes.)
# ============================================================================
"""The models the house holds, what each cost, and the oldest put down when room is needed."""
from __future__ import annotations

import gc
import time


def own_bytes() -> int:
    """Intention: this process's working set now; nought when it cannot be read."""
    try:
        import psutil
        return int(psutil.Process().memory_info().rss)
    except Exception:  # fault: ok - an unread size measures nothing, and nothing is put down by it
        return 0


class Keeper:
    """Loaded models by name: the thing itself, its measured cost, its last use."""

    def __init__(self, budget=None, own=None, clock=time.monotonic) -> None:
        """Intention: the room to fit in, how this process's size is read, and the clock for last use."""
        from warp2.room.budget import Budget
        self.budget = budget or Budget()
        self.own = own or own_bytes
        self.clock = clock
        self.held: dict = {}

    def get(self, name: str):
        """Intention: a loaded model, its use marked now; None when it is not loaded."""
        row = self.held.get(name)
        if row is None:
            return None
        row["used"] = self.clock()
        return row["thing"]

    def load(self, name: str, need: int, make):
        """Intention: room made for `need` bytes, then the model made and kept with what it really cost."""
        self.make_room(need, keep=name)
        before = self.own()
        thing = make()
        cost = max(0, self.own() - before)
        self.held[name] = {"thing": thing, "bytes": cost or int(need), "used": self.clock()}
        return thing

    def make_room(self, need: int, keep: str = "") -> list:
        """Intention: the models used longest ago put down until `need` fits the room; the names put down."""
        gone = []
        while int(need) > self.budget.reading(held=False)["new"]:
            others = sorted((row["used"], n) for n, row in self.held.items() if n != keep)
            if not others:
                break
            gone.append(self.put_down(others[0][1]))
        return gone

    def give_back(self) -> list:
        """Intention (BUILD_LOG 1487): with no room left on the machine for new work, the model used longest ago is
        put down - one a look, so the next look reads the room that gave back; the names put down."""
        if not self.held or self.budget.reading(held=False)["new"] > 0:
            return []
        return [self.put_down(min(self.held, key=lambda n: self.held[n]["used"]))]

    def put_down(self, name: str) -> str:
        """Intention: one model let go, its memory given back."""
        row = self.held.pop(name, None)
        if row is not None:
            close = getattr(row["thing"], "close", None)
            if callable(close):
                close()
            del row
            gc.collect()
            try:
                import torch
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            except Exception:  # fault: ok - with no torch or no card there is no card cache to empty
                pass
        return name

    def listing(self) -> list:
        """Intention: [{name, bytes, idle_seconds}] of what is held, longest unused first."""
        now = self.clock()
        return [{"name": n, "bytes": r["bytes"], "idle_seconds": round(now - r["used"], 1)}
                for n, r in sorted(self.held.items(), key=lambda kv: kv[1]["used"])]
