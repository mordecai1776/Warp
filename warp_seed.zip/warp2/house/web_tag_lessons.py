# WARP2/warp2/house/web_tag_lessons.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/house/web_tag_lessons.py
#  Used by   : warp2/house/tag_lessons.py (the house models' lessons).
#  Uses      : warp2/tags/dehydrated/{book,whole_lane}.py (the knowledge
#              graph held small, its web tags); warp2/house/tag_lessons.py
#              (key); (stdlib) json, pathlib.
#  Description:
#    THE MODELS LEARN THE KNOWLEDGE GRAPH'S OWN DEHYDRATED FORM. A web tag of
#    the lane (a repeated group of tags, kept once) is one token, written
#    "<wt:N>". Each lesson is one web tag both ways: the token and what it
#    holds (its web form with the places it fills, the open places "?"), and
#    what it holds back to the token - so a model reads and writes the same
#    tags the graph and the Eye are made of, as WARP1's net tags were taught
#    as single tokens (WARP\warp\kg\tokens.py). The web tags taught are those
#    of the newest page of the book that made any, so each turn's lessons are
#    what the graph most lately took in.
#  User intention (Andrew, 2026-11-10 20:04): "We need to train a lora for the
#    models". (18:58): "it should learn those tags, sort of like tokens. That
#    way, in fact, exactly like tokens, to include web tags." (2026-07-17,
#    WARP1 tokens.py): "they will act as single tokens to train on that we can
#    train the models to know the meaning of." BUILD_LOG 1508.
# ============================================================================
"""Lessons in the knowledge graph's web tags, both ways."""
from __future__ import annotations

import json
from pathlib import Path


def token(number: int) -> str:
    """Intention: a web tag written as one token."""
    return f"<wt:{int(number)}>"


class WebTagLessons:
    """Intention: lessons from the web tags on the newest page of the knowledge graph's small form."""

    def __init__(self, state) -> None:
        """Intention: the state folder; the small form is in store/tags/dehydrated/web_tagged/."""
        from warp2.store.store import store_home
        self.home = store_home(state) / "tags" / "dehydrated" / "web_tagged"

    def lessons(self) -> list:
        """Intention: [{key, prompt, answer, kind}] for every web tag on the newest page; none when nothing is held small."""
        from warp2.house.tag_lessons import key
        from warp2.tags.dehydrated.book import Book
        record = self.home / "done.json"
        if not record.is_file():
            return []
        done = json.loads(record.read_text(encoding="utf-8"))  # fault: ok the record is written whole by whole_lane; one that cannot be read raises
        if not done:
            return []
        book = Book(reading=True)
        for name in sorted(done):
            book.read_page(self.home / done[name]["page"])
        first, last, newest_name = 0, 0, ""
        for name in reversed(sorted(done)):
            page = json.loads((self.home / done[name]["page"]).read_text(encoding="utf-8"))  # fault: ok a page the record names is there; one that cannot be read raises
            if int(page.get("web_tags") or 0):
                first = int(page.get("web_tags_from", 0))
                last = first + int(page["web_tags"])
                newest_name = name
                break
        out = []
        for number in range(first, last):
            held = self.held(book, number)
            for prompt, answer in ((f"web tag: {token(number)} ->holds", held), (f"web tag: {held} ->token", token(number))):
                out.append({"key": key(prompt), "prompt": prompt, "answer": answer, "kind": "web tags"})
        if newest_name:
            out.extend(self._alteration_lessons(newest_name, first, last))
        return out

    def _alteration_lessons(self, newest_name: str, first: int, last: int) -> list:
        """Intention: for each new web tag on the page, one concrete dehydrated entry (<wt:N> + alterations <-> tags)."""
        from warp2.house.tag_lessons import key
        from warp2.tags.dehydrated.whole_lane import WholeLane
        from warp2.tags.lane import TagLane
        tags_folder = self.home.parent.parent
        entries = (WholeLane(tags_folder, say=lambda _t: None, form=2).dehydrated_entries(newest_name)
                   if newest_name else TagLane(tags_folder / "tags.jsonl").dehydrated_entries())
        seen: set[int] = set()
        out = []
        for entry in entries:
            wt_id = entry.get("web_tag_id")
            if wt_id is None or not (first <= wt_id < last) or wt_id in seen or not entry.get("alterations"):
                continue
            seen.add(wt_id)
            compact = f"{entry['web_tag']} {json.dumps(entry['alterations'], ensure_ascii=False, separators=(',', ':'))}"
            expanded = json.dumps({"act": entry["act"], "tags": entry["tags"]}, ensure_ascii=False, separators=(",", ":"))
            for prompt, answer in ((f"dehydrated entry: {compact} ->tags", expanded),
                                   (f"dehydrated entry: {expanded} ->web_tag", compact)):
                out.append({"key": key(prompt), "prompt": prompt, "answer": answer, "kind": "web tags"})
            if len(seen) >= (last - first):
                break
        return out

    @staticmethod
    def held(book, number: int) -> str:
        """Intention: what a web tag holds - its web form with the places it fills, the open places '?'."""
        form, fixed = book.web_tags[number]
        shape, act, _time_at = json.loads(book.forms[form])
        filled = dict(fixed)
        places, out = 0, []
        for record in shape:
            if record == "s" or (isinstance(record, list) and record and record[0] == "j"):
                out.append(["s", book.signatures[filled[places]] if places in filled else "?"])
                places += 1
            else:
                out.append(record)
        return json.dumps({"act": act, "tags": out}, ensure_ascii=False, separators=(",", ":"))
