# WARP2/warp2/corpus/smooth.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/smooth.py
#  Used by   : warp2/corpus/part.py (each anchor's notation, when it is
#              smaller this way); warp2/corpus/tests/.
#  Uses      : warp2/corpus/varint.py; numpy.
#  Description:
#    SMOOTH CODES: EACH TAG WRITTEN AS LONG AS HOW OFTEN IT IS USED. A number
#    kept as whole bytes costs 8, 16 or 24 bits whatever it is; here every
#    tag costs what its share of the notation says (-log2 of how often it
#    stands there), to the bit - range asymmetric numeral systems (rANS,
#    Duda 2009/2013), the way zstd's and modern codecs' entropy stages work.
#      The model (kept once in the part's corpus): the most used tags, each
#      with its share of 2^16; every other tag is said by one shared "said
#      plainly" share and written beside as plain numbers.
#      A notation is dealt round-robin into lanes - as many lanes as the
#      square root of its length, so the steps to read it and the lanes'
#      closing states grow alike - and the lanes are coded side by side, so
#      reading is a few hundred array steps, not a step a tag.
#      The words the lanes write go to one stream step by step, in the order
#      a reader takes them back (each lane's words last-written first).
#    Exact: the same numbers come back, always.
#  User intention (Andrew; project rules): "smooth. This is where nothing is
#    done in chunks. Everything is done at a gradient that can be weighted or
#    done by exact mathematical principal for the situation." 2026-11-13
#    21:05: "hide higher forms in each things corpus of tags". BUILD_LOG 1623c.
# ============================================================================
"""rANS over many lanes at once: a shared model of shares, notations coded to their information."""
from __future__ import annotations

import numpy as np

from warp2.corpus.varint import first, pack, unpack

SCALE = 16                      # Intention: shares are counted out of 2^16 - the most a 16-bit renorm allows
WHOLE = 1 << SCALE
LOW = np.uint64(1 << 16)        # Intention: a lane's state stays in [2^16, 2^32) - 16 bits in and out at a time


class Model:
    """Intention: the shares of the most used tags, and one share for every tag said plainly."""

    def __init__(self, tags: np.ndarray, shares: np.ndarray) -> None:
        """Intention: tags in order and their shares; the last share is the "said plainly" one."""
        self.tags = np.asarray(tags, dtype=np.int64)
        self.shares = np.asarray(shares, dtype=np.int64)
        self.starts = np.concatenate([[0], np.cumsum(self.shares)[:-1]]).astype(np.int64)
        self.plain = self.tags.size
        self.place = np.repeat(np.arange(self.shares.size), self.shares)   # Intention: a slot back to its place

    @staticmethod
    def of(counts_of: np.ndarray, counts: np.ndarray) -> "Model":
        """Intention: a model from how often each tag stands in the notations - every tag used often enough to earn
        a share of at least one keeps its own; the rest share the one "said plainly" share."""
        order = np.argsort(-counts, kind="stable")
        tags, counts = np.asarray(counts_of, dtype=np.int64)[order], np.asarray(counts, dtype=np.int64)[order]
        total = int(counts.sum())
        kept = min(int(np.sum(counts * (WHOLE - 1) >= total)), WHOLE - 2)  # Intention: room left for the plain share
        plain = total - int(counts[:kept].sum())
        weights = np.concatenate([counts[:kept], [max(plain, 1)]]).astype(np.float64)
        shares = np.maximum(1, np.floor(weights / weights.sum() * WHOLE)).astype(np.int64)
        shares[np.argmax(shares)] += WHOLE - int(shares.sum())
        keep = np.argsort(tags[:kept], kind="stable")
        return Model(tags[:kept][keep], np.concatenate([shares[:kept][keep], shares[kept:]]))

    def written(self) -> list:
        """Intention: the model as notations - its tags as steps, its shares."""
        return [np.diff(self.tags, prepend=0), self.shares]

    @staticmethod
    def read(notations: list) -> "Model":
        """Intention: the model back from what `written` gave."""
        steps, shares = notations
        return Model(np.cumsum(steps), shares)


def lanes_for(count: int) -> int:
    """Intention: the square root of a notation's length - the steps to read it and its lanes' states grow alike."""
    return max(1, int(np.ceil(np.sqrt(count))))


def encode(notation, model: Model) -> bytes:
    """Intention: a notation coded with the model: its length, the tags said plainly, the lanes' closing states and
    the words, in the order a reader takes them back."""
    notation = np.asarray(notation, dtype=np.int64)
    count = notation.size
    if count == 0:
        return pack([0])
    at = np.searchsorted(model.tags, notation)
    at[at >= model.tags.size] = 0
    known = model.tags.size and (model.tags[at] == notation) if model.tags.size else np.zeros(count, dtype=bool)
    places = np.where(known, at, model.plain)
    said_plainly = notation[~known] if model.tags.size else notation
    lanes = lanes_for(count)
    steps = -(-count // lanes)
    state = np.full(lanes, LOW, dtype=np.uint64)
    words = []
    shares = model.shares.astype(np.uint64)
    starts = model.starts.astype(np.uint64)
    for step in range(steps - 1, -1, -1):
        begin = step * lanes
        end = min(count, begin + lanes)
        live = end - begin
        place = places[begin:end]
        share = shares[place]
        here = state[:live]
        full = here >= (share << np.uint64(16))
        if full.any():
            words.append((here[full] & np.uint64(0xFFFF)).astype(np.uint16))
            here[full] >>= np.uint64(16)
        here[:] = ((here // share) << np.uint64(SCALE)) + (here % share) + starts[place]
    stream = np.concatenate(words[::-1]) if words else np.zeros(0, dtype=np.uint16)
    return pack([count, said_plainly.size]) + pack(said_plainly) + state.astype("<u4").tobytes() + \
        stream.astype("<u2").tobytes()


def decode(raw, model: Model) -> np.ndarray:
    """Intention: the notation back from what `encode` gave, with the same model."""
    raw = bytes(raw)
    count, used = first(raw)
    if count == 0:
        return np.zeros(0, dtype=np.int64)
    plainly, more = first(raw[used:])
    at = used + more
    numbers = unpack(raw[at:])[:plainly] if plainly else np.zeros(0, dtype=np.int64)
    at += len(pack(numbers)) if plainly else 0
    lanes = lanes_for(count)
    state = np.frombuffer(raw[at:at + 4 * lanes], dtype="<u4").astype(np.uint64)
    stream = np.frombuffer(raw[at + 4 * lanes:], dtype="<u2").astype(np.uint64)
    shares = model.shares.astype(np.uint64)
    starts = model.starts.astype(np.uint64)
    places = np.empty(count, dtype=np.int64)
    read = 0
    for step in range(-(-count // lanes)):
        begin = step * lanes
        live = min(count, begin + lanes) - begin
        here = state[:live]
        slot = here & np.uint64(WHOLE - 1)
        place = model.place[slot.astype(np.int64)]
        places[begin:begin + live] = place
        here[:] = shares[place] * (here >> np.uint64(SCALE)) + slot - starts[place]
        low = here < LOW
        taking = int(low.sum())
        if taking:
            here[low] = (here[low] << np.uint64(16)) | stream[read:read + taking]
            read += taking
    out = np.empty(count, dtype=np.int64)
    known = places != model.plain
    out[known] = model.tags[places[known]]
    out[~known] = numbers
    return out
