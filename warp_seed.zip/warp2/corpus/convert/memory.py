# WARP2/warp2/corpus/convert/memory.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/memory.py
#  Used by   : warp2/corpus/convert/{kg,state_text}.py; warp2/corpus/tests/.
#  Uses      : (stdlib) ctypes, os; psutil when it is there.
#  Description:
#    HOW MANY TAGS ONE PART CAN BE LIFTED FROM AT ONCE - not a set number:
#    the memory free on the machine right now, half of it left to the warp
#    that is running beside the build, divided by what one tag takes while
#    a part is being made (measured: 88 bytes a number for the KG's record,
#    98 bytes a piece for text, at the peak of the build - BUILD_LOG 1621c).
#  User intention (Andrew; project rules): no hard limits - "the design of
#    the program itself is the limitation needed".
# ============================================================================
"""Free memory now, and how many tags a part can be built from with half of it."""
from __future__ import annotations

import ctypes
import os

BYTES_A_TAG = 100   # Intention: measured peak while a part is made (88 a number, 98 a piece), rounded up


def free_bytes() -> int:
    """Intention: the memory free on this machine right now."""
    try:
        import psutil
        return int(psutil.virtual_memory().available)
    except ImportError:  # fault: ok psutil is not everywhere; the system is asked directly below
        pass
    if os.name == "nt":
        class _Status(ctypes.Structure):
            """Intention: what Windows says of its memory (MEMORYSTATUSEX), to read the free part of it."""
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        status = _Status()
        status.dwLength = ctypes.sizeof(_Status)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
        return int(status.ullAvailPhys)
    with open("/proc/meminfo", encoding="utf-8") as info:
        for line in info:
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) * 1024
    return 0


def tags_that_fit() -> int:
    """Intention: how many tags one part can be lifted from now - half the free memory over what a tag takes."""
    return max(1, free_bytes() // 2 // BYTES_A_TAG)
