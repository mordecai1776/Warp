# WARP2/warp2/corpus/convert/run.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/run.py
#  Used by   : the command lane (python -m warp2.corpus.convert.run <state>);
#              warp2/corpus/tests/.
#  Uses      : warp2/corpus/convert/{kg,state_text,view}.py; warp2/corpus/shelf.py;
#              warp2/record/kept_file.py (write_kept); (stdlib) json, sys,
#              time.
#  Description:
#    EVERYTHING THE WARP HOLDS PUT INTO CORPUS FORM, SAYING HOW FAR IT HAS
#    GOT. The KG's record first, then the state's text, collection by
#    collection, then (asked by name: view) the store's working view of the
#    KG's facts; each line said as it happens, and what it all came to -
#    with every corpus's measures - written to <state>/corpus/converted.json.
#    Nothing is taken away: the files stay where they are; the corpus form
#    is beside them, every thing in it read back the same before it counts.
#  User intention (Andrew, 2026-11-13 21:03): "Do not stop until everything
#    is converted and let me know the significant numbers when your done."
#    BUILD_LOG 1621c.
# ============================================================================
"""python -m warp2.corpus.convert.run <state folder> [kg] [text | text:i/n] [view] - keep everything in corpus form."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

from warp2.corpus.convert.kg import keep_kg
from warp2.corpus.convert.state_text import keep_state_text
from warp2.corpus.convert.view import keep_view, view_of
from warp2.corpus.shelf import RECORD, Shelf
from warp2.record.kept_file import write_kept


def run(state, which=("kg", "text"), say=print) -> dict:
    """Intention: the asked kinds kept in corpus form; what it came to, written beside the corpora."""
    state = Path(state)
    began = time.time()
    done = {"began": time.strftime("%Y-%m-%d %H:%M:%S")}
    if "kg" in which:
        done["kg"] = keep_kg(state / RECORD, say)
    shares = [part.split(":", 1)[1] for part in which if part.startswith("text:")]
    if "text" in which or shares:
        # Intention (1633c): "text:i/n" keeps share i of n of the state's text, so n runs can go side by side.
        mine, of = (int(x) for x in shares[0].split("/")) if shares else (0, 1)
        done["text"] = keep_state_text(state, say, (mine, of))
    if "view" in which:
        view = view_of(state)
        done["view"] = keep_view(view, state / "corpus" / "facts" / view.stem, say)   # Intention (1626c): a folder a view
    done["measures"] = Shelf(state).measures()
    done["seconds"] = round(time.time() - began, 1)
    name = "converted.json" if "text" in which or not shares else f"converted-text-{mine}-of-{of}.json"
    write_kept(state / "corpus" / name, done, indent=1, default=list)
    return done


def main(argv: list) -> int:
    """Intention: run from the command line, each line said as soon as it happens."""
    state = Path(argv[1])
    which = tuple(argv[2:]) or ("kg", "text")
    done = run(state, which, say=lambda line: print(time.strftime("%H:%M:%S"), line, flush=True))
    print(json.dumps(done["measures"], indent=1), flush=True)
    print("took", done["seconds"], "s", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
