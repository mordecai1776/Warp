# WARP2/warp2/corpus/convert/view.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/view.py
#  Used by   : warp2/corpus/convert/run.py ("view"); warp2/corpus/tests/.
#  Uses      : warp2/corpus/columns.py; warp2/corpus/convert/memory.py;
#              warp2/record/kept_file.py; warp2/record/stop.py (runtime_dir);
#              warp2/store/schema.py (fact_key); warp2/util.py
#              (atomic_write_bytes, sha256_hex);
#              (stdlib) datetime, sqlite3, time, pathlib.
#  Description:
#    THE KG'S FACTS IN CORPUS FORM. The store's working view (one SQLite
#    table of every fact with its text in full, and seven indexes over it)
#    read, block by block in the order the facts were written, into columns
#    of tag numbers over one word table a block (columns.py):
#      the words      - subject, relation, object, attr, value, evidence,
#                       reason, run and stamp: every distinct text once
#      the key        - worked out again from the row as the store makes it
#                       (schema.fact_key); only a key that does not is kept
#      the times      - valid_from as steps from the fact before; recorded_at
#                       and valid_to as steps from valid_from; in microseconds
#      the numbers    - confidence, seq (as steps), proof; id as steps
#    A row whose text the numbers do not give back exactly (a time written
#    another way, a key made from a value of another type) keeps that text
#    as an exception - nothing is guessed. A block counts only when every
#    column of it reads back equal to what was packed (and so every row the
#    same as the view holds it; 1630c: checked all at once, column by column,
#    with the rows that carry exceptions rebuilt whole beside the view's).
#    The blocks are as many rows as half the free memory holds now. A block
#    is a picture of its rows when kept; a fact the view closes later (its
#    valid_to set) is read from the view until the store answers from here.
#  User intention (Andrew, 2026-11-13 20:19): "the warp should be working from
#    the dehydrated kg now"; 20:35: "everything needs to be in and run from a
#    fully dehydrated form." BUILD_LOG 1624c.
# ============================================================================
"""The store's working view kept as blocks of columns over word tables, every row read back the same."""
from __future__ import annotations

import datetime
import sqlite3
import time
from pathlib import Path

import numpy as np

from warp2.corpus.columns import Columns, pack_block
from warp2.corpus.convert.memory import free_bytes
from warp2.record.kept_file import read_kept, write_kept
from warp2.util import atomic_write_bytes

COLUMNS = ("id", "key", "subject", "relation", "object", "attr", "value", "evidence", "confidence", "valid_from",
           "valid_to", "reason", "recorded_at", "seq", "run", "stamp", "proof")
WORDS = ("subject", "relation", "object", "attr", "value", "evidence", "reason", "run", "stamp")
BYTES_A_ROW = 1200   # Intention: measured - a row read from the view and turned to columns takes about this at its peak
KEPT = "kept.json"


def view_of(state) -> Path:
    """Intention: the store's working view for this state folder - where the store itself puts it (one name per
    workspace, from where its store folder lives - 1626c: the store names it from state/store, not state)."""
    from warp2.record.stop import runtime_dir
    from warp2.store.store import store_home
    from warp2.util import sha256_hex
    digest = sha256_hex(str(store_home(state).resolve()).encode("utf-8"))   # Intention (1626c): as the store does
    return runtime_dir() / "store" / f"view-{digest[:12]}.sqlite3"  # fault: ok the store's own name for its view (store.py _default_view: the first 12 of the state's sha256)


def _microseconds(text) -> int:
    """Intention: a written time as microseconds since 1970 (UTC)."""
    return int(datetime.datetime.fromisoformat(text).timestamp() * 1_000_000 + 0.5) if text else 0


def _times(texts: list, beside=None) -> np.ndarray:
    """Intention (1632c): a column of written times as microseconds. A text that is not a time at all (one fact of
    the view says "1") takes the time of the fact before it - or, for recorded_at and valid_to, its own valid_from
    (`beside`) - so the steps stay small; it does not come back as written from that, so block_of keeps its text as
    an exception and it comes back exactly. No time (None) is 0."""
    out = np.zeros(len(texts), dtype=np.int64)
    last = 0
    for place, text in enumerate(texts):
        if text is None:
            continue
        try:
            out[place] = _microseconds(text)
        except ValueError:  # fault: ok not a time - stands in as the time beside it; its text is kept as an exception
            out[place] = int(beside[place]) if beside is not None else last
        last = int(out[place])
    return out


def _written(micro: int) -> str:
    """Intention: microseconds back as the time the store writes."""
    return datetime.datetime.fromtimestamp(micro / 1_000_000, datetime.timezone.utc).isoformat()


def _folded(steps: np.ndarray) -> np.ndarray:
    """Intention: steps that may be negative as numbers that are not."""
    return np.where(steps >= 0, steps * 2, -steps * 2 - 1)


def _unfolded(numbers: np.ndarray) -> np.ndarray:
    """Intention: the steps `_folded` was given."""
    return np.where(numbers % 2 == 0, numbers // 2, -(numbers + 1) // 2)


def block_of(rows: list, key_of) -> tuple:
    """Intention: (columns, words, exceptions) of a block of rows - every text a word once, numbers as numbers."""
    words: dict = {}

    def word(text) -> int:
        """Intention: a text's number in this block's word table (0 for no text), added the first time it is seen."""
        if text is None:
            return 0
        if text not in words:
            words[text] = len(words) + 1
        return words[text]
    at = {name: place for place, name in enumerate(COLUMNS)}
    columns = {name: np.fromiter((word(row[at[name]]) for row in rows), dtype=np.int64, count=len(rows))
               for name in WORDS}
    exceptions: dict = {}
    columns["key"] = np.fromiter((0 if key_of(row[at["subject"]], row[at["relation"]], row[at["object"]],
                                              row[at["attr"]], row[at["value"]]) == row[at["key"]]
                                  else word(row[at["key"]]) for row in rows), dtype=np.int64, count=len(rows))
    starts = _times([row[at["valid_from"]] for row in rows])
    recorded = _times([row[at["recorded_at"]] for row in rows], starts)
    ends = _times([row[at["valid_to"]] for row in rows], starts)
    columns["valid_from"] = _folded(np.diff(starts, prepend=0))
    columns["recorded_at"] = _folded(recorded - starts)
    columns["valid_to"] = np.where(ends > 0, _folded(ends - starts) + 1, 0)
    for name in ("valid_from", "recorded_at", "valid_to"):
        for place, row in enumerate(rows):
            text = row[at[name]]
            if text is not None and _written({"valid_from": starts, "recorded_at": recorded,
                                              "valid_to": ends}[name][place]) != text:
                exceptions.setdefault(name, {})[place] = text
    for name in ("confidence", "seq", "proof"):
        values = [row[at[name]] for row in rows]
        plain = np.fromiter((0 if v is None else int(v) + 1 for v in values), dtype=np.int64, count=len(rows))
        columns[name] = _folded(np.diff(plain, prepend=0)) if name == "seq" else plain
        for place, value in enumerate(values):
            if value is not None and not isinstance(value, int):
                exceptions.setdefault(name, {})[place] = value
    columns["id"] = np.diff(np.fromiter((row[at["id"]] for row in rows), dtype=np.int64, count=len(rows)),
                            prepend=0)
    return columns, list(words), exceptions


def rows_of(block: Columns, key_of, places=None) -> list:
    """Intention: a block's rows back, as the view holds them - all of them, or only those at the places asked."""
    words = [None] + block.words()
    exceptions = block.head.get("exceptions") or {}
    texts = {name: [words[n] for n in block.column(name)] for name in WORDS}
    keys = block.column("key")
    starts = np.cumsum(_unfolded(block.column("valid_from")))
    recorded = starts + _unfolded(block.column("recorded_at"))
    ends_raw = block.column("valid_to")
    ends = np.where(ends_raw > 0, starts + _unfolded(np.maximum(ends_raw - 1, 0)), 0)
    numbers = {name: block.column(name) for name in ("confidence", "seq", "proof")}
    numbers["seq"] = np.cumsum(_unfolded(numbers["seq"]))
    ids = np.cumsum(block.column("id"))
    out = []
    for place in (range(ids.size) if places is None else places):
        row = {"id": int(ids[place])}
        for name in WORDS:
            row[name] = texts[name][place]
        row["key"] = key_of(row["subject"], row["relation"], row["object"], row["attr"], row["value"]) \
            if keys[place] == 0 else words[keys[place]]
        for name, values in (("valid_from", starts), ("recorded_at", recorded), ("valid_to", ends)):
            said = exceptions.get(name, {}).get(str(place))
            row[name] = said if said is not None else (_written(int(values[place])) if values[place] else None)
        for name in ("confidence", "seq", "proof"):
            said = exceptions.get(name, {}).get(str(place))
            row[name] = said if said is not None else (None if numbers[name][place] == 0
                                                         else int(numbers[name][place]) - 1)
        out.append(tuple(row[name] for name in COLUMNS))
    return out


def _same(block: Columns, columns: dict, words: list, rows: list, key_of) -> bool:
    """Intention (1630c): whether a packed block gives back every fact - every column read back equal to what was
    packed, all at once, and the word table the same; every text that does not come back from the numbers was
    already kept as an exception when the columns were made (block_of), so equal columns are equal facts. The
    rows that carry exceptions, the first and the last are also rebuilt whole and set beside the view's rows."""
    if block.words() != words or any(not np.array_equal(block.column(name), numbers)
                                     for name, numbers in columns.items()):
        return False
    places = sorted({0, len(rows) - 1} | {int(place) for found in (block.head.get("exceptions") or {}).values()
                                          for place in found})
    return rows_of(block, key_of, places) == [rows[place] for place in places]


def keep_view(view, home, say=print) -> dict:
    """Intention: every fact of the view not yet kept, kept in blocks in `home`, each read back the same."""
    from warp2.store.schema import fact_key
    home = Path(home)
    kept = read_kept(home / KEPT, dict)
    after = max([block["last_id"] for block in kept.values()], default=0)
    done = {"rows": 0, "blocks": [], "bytes": 0, "seconds": 0.0}
    began = time.time()
    view = Path(view)
    source = sqlite3.connect(f"file:{view.as_posix()}?mode=ro", uri=True, timeout=60)
    try:
        # Intention (1625c): the view's own columns - one made before a column was added has no such column; it is
        # read as empty, so every block has every column.
        present = {row[1] for row in source.execute("PRAGMA table_info(fact)")}
        said = ", ".join(name if name in present else f"NULL AS {name}" for name in COLUMNS)
        while True:
            many = max(1, free_bytes() // 2 // BYTES_A_ROW)
            rows = source.execute(f"SELECT {said} FROM fact WHERE id > ? ORDER BY id LIMIT ?", (after, many)).fetchall()
            if not rows:
                break
            say(f"view: {len(rows):,} facts after id {after:,} ...")
            columns, words, exceptions = block_of(rows, fact_key)
            raw = pack_block(columns, words, {"first_id": rows[0][0], "last_id": rows[-1][0], "rows": len(rows),
                                              "exceptions": {name: {str(k): v for k, v in found.items()}
                                                             for name, found in exceptions.items()}})
            if not _same(Columns(raw), columns, words, rows, fact_key):
                raise ValueError(f"the block after id {after} did not read back the same")
            name = f"facts-{len(kept) + 1:04d}.bin"
            atomic_write_bytes(home / name, raw)
            kept[name] = {"first_id": rows[0][0], "last_id": rows[-1][0], "rows": len(rows), "bytes": len(raw)}
            write_kept(home / KEPT, kept, indent=1)
            done["rows"] += len(rows)
            done["bytes"] += len(raw)
            done["blocks"].append(name)
            say(f"view: {name} - {len(rows):,} facts in {len(raw):,} bytes, every one read back the same")
            after = rows[-1][0]
    finally:
        source.close()
    done["seconds"] = round(time.time() - began, 1)
    done["view_bytes"] = view.stat().st_size
    return done
