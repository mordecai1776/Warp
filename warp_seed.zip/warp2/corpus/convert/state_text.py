# WARP2/warp2/corpus/convert/state_text.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/state_text.py
#  Used by   : warp2/corpus/convert/run.py; warp2/corpus/tests/.
#  Uses      : warp2/corpus/{parts,varint}.py; warp2/corpus/convert/{memory,
#              packed}.py; warp2/record/kept_file.py (own_form.json);
#              (stdlib) zlib (crc32 - which share a file falls to);
#              (stdlib) os, time, pathlib.
#  Description:
#    EVERY TEXT FILE OF THE STATE AS AN ANCHOR OVER THE TEXT CORPUS OF ITS
#    COLLECTION (the folder it is in under state/). A file is text when it
#    holds no zero byte and reads as UTF-8; a packed file (gzip, zlib) is
#    taken as its text when it packs back to the very same bytes
#    (packed.py). Its anchor: its path under state/ (identity), its type
#    ("text", "gzip", "zlib") and its notation over the collection's corpus.
#    A file too big to lift with the memory free now is kept in pieces cut at
#    line ends, read back joined. Files that are already in a corpus of their
#    own - the tensor books of the house, the Eye and the pictures, the KG's
#    lane and its record - and files that are not text (pictures, weights, databases,
#    arrays) are not taken here; they are counted, by kind, in what is said.
#    A file already kept, and not written since, is not kept again. A part
#    goes in only when it is smaller than its files on disk (a packed file
#    counts as its packed bytes; packed files go in parts of their own); when
#    it would not be, those files stay in their own form and are noted so,
#    not tried again until written since. After a
#    part goes in, every file in it is given back from the corpus
#    (`file_back`, packed ones packed again) and must be the very bytes of
#    the file, or the run stops and says which.
#  User intention (Andrew, 2026-11-13 20:49): "it should all be just the
#    files with their tags that are incredibly compressed". BUILD_LOG 1621c.
# ============================================================================
"""The state's text files kept as anchors over a text corpus per collection."""
from __future__ import annotations

import os
import time
import zlib
from pathlib import Path

from warp2.corpus.convert.memory import tags_that_fit
from warp2.corpus.convert.packed import GZIP, ZLIB, opened, packed
from warp2.corpus.parts import PIECE, TEXT, Parts
from warp2.corpus.varint import first, pack
from warp2.record.kept_file import read_kept, write_kept

BYTES_A_PIECE = 2.75   # Intention: measured - text of the warp averages 2.75 bytes a piece (word, space or mark)
PACKED = {".gz": GZIP, ".z": ZLIB, ".zlib": ZLIB}
OWN_FORM = "own_form.json"


def corpora_of_their_own(state: Path) -> list:
    """Intention: folders whose files are already kept in a corpus of their own (and this corpus's own folder)."""
    state = Path(state)
    return [state / "corpus", state / "house" / "models_small" / "book", state / "models" / "eye" / "pairs_small",
            state / "store" / "media_small" / "book", state / "store" / "tags"]


def text_parts(state, collection: str) -> Parts:
    """Intention: the text corpus of one collection (the files right in state/ are the collection "_top")."""
    return Parts(Path(state) / "corpus" / "text" / ("_top" if collection == "." else collection))


def taken(path: Path, raw: bytes):
    """Intention: (type, what is kept, the length of its head) for a file kept here, or None when it is not text.
    A packed file is kept as its head's length, its head and its text (packed.py packs it back)."""
    how = PACKED.get(path.suffix.lower())
    if how is not None:
        opened_up = opened(raw, how)
        if opened_up is None:
            return None
        text, head = opened_up
        return how, pack([len(head)]) + head + text, len(head)
    if b"\x00" in raw:
        return None
    try:
        raw.decode("utf-8")
    except UnicodeDecodeError:  # fault: ok bytes that are not UTF-8 are not taken as text
        return None
    return ("text", raw, 0)


def walk(state: Path):
    """Intention: every file under the state outside the corpora of their own: (collection, path)."""
    state = Path(state)
    own = [str(each) for each in corpora_of_their_own(state)]
    for folder, names, files in os.walk(state):
        if any(folder == each or folder.startswith(each + os.sep) for each in own):
            names[:] = []
            continue
        names.sort()
        for name in sorted(files):
            path = Path(folder) / name
            rel = path.relative_to(state)
            yield (rel.parts[0] if len(rel.parts) > 1 else "."), path


def keep_state_text(state, say=print, share: tuple = (0, 1)) -> dict:
    """Intention: every text file of the state not yet kept (or written since), kept; what it came to. A
    collection's plain text and its packed files go in parts of their own (a packed file is measured against its
    packed bytes); a part that would not be smaller than its files on disk is not put in, and its files are noted as
    smaller in their own form (own_form.json beside the parts) so they are not tried again until written since.
    With share (i, n) (1633c), this run keeps only the files whose name falls to share i of n, with an n-th of the
    memory one run would take - n runs side by side keep the state n times as fast on a machine with free cores."""
    state = Path(state)
    began = time.time()
    done = {"files": 0, "bytes_were": 0, "parts": [], "not_text": {}, "written_while_kept": [],
            "own_form_smaller": {"files": 0, "bytes": 0}, "seconds": 0.0}
    groups: dict = {}
    mine, of = share
    for collection, path in walk(state):
        if zlib.crc32(path.relative_to(state).as_posix().encode("utf-8")) % of == mine:
            groups.setdefault((collection, path.suffix.lower() in PACKED), []).append(path)
    # Intention (1629c): the collections that take the least room on disk first - the most of the state comes into
    # corpus form soonest. (1635c) Packed files after every plain one: what they hold is not what they take on disk
    # (the raw captures take 0.58 GB and open to tens of GB of text), so they go last, smallest first among them.
    for collection, is_packed in sorted(groups, key=lambda group: (group[1], _on_disk(groups[group]), group)):
        parts = text_parts(state, collection)
        own = OwnForm(parts.folder)
        group, held, waiting, stamps, worth = [], 0, [], [], 0
        fits = tags_that_fit() // of
        for path in groups[(collection, is_packed)]:
            name = path.relative_to(state).as_posix()
            if (parts.holds(name) and _not_written_since(parts, name, path)) or own.still(name, path):
                continue
            try:
                stamp = path.stat().st_mtime_ns
                raw = path.read_bytes()
            except OSError:  # fault: ok a file in use or gone is left for the next run
                continue
            kept = taken(path, raw)
            if kept is None:
                kind = path.suffix.lower() or "-"
                count, size = done["not_text"].get(kind, (0, 0))
                done["not_text"][kind] = (count + 1, size + len(raw))
                continue
            kind, text, _head = kept
            for piece_name, piece in _pieces(name, text, fits):
                pieces_in = len(piece) / BYTES_A_PIECE
                if group and held + pieces_in > fits:
                    done["parts"].append(_kept(parts, collection, group, stamps, say, state, waiting, done, worth, own))
                    group, held, waiting, stamps, worth, fits = [], 0, [], [], 0, tags_that_fit() // of
                group.append((piece_name, kind, piece))
                stamps.append(stamp)
                held += pieces_in
                worth += len(raw) * len(piece) / max(1, len(text))
            waiting.append((name, path, stamp, len(raw)))
            done["files"] += 1
            done["bytes_were"] += len(raw)
        if group:
            done["parts"].append(_kept(parts, collection, group, stamps, say, state, waiting, done, worth, own))
    done["seconds"] = round(time.time() - began, 1)
    return done


def _on_disk(paths: list) -> int:
    """Intention: the bytes a group of files takes on disk now (a file that cannot be looked at counts as none)."""
    total = 0
    for path in paths:
        try:
            total += path.stat().st_size
        except OSError:  # fault: ok a file gone since the walk adds nothing; it is passed over when kept
            pass
    return total


class OwnForm:
    """Intention: the files of one collection found smaller in their own form than in a part, by the time each was
    written when found so (own_form.json beside the parts) - not tried again until written since."""

    def __init__(self, folder: Path) -> None:
        """Intention: the collection's parts folder; what it says is read once."""
        self.path = Path(folder) / OWN_FORM
        self.found = read_kept(self.path, dict)

    def still(self, name: str, path: Path) -> bool:
        """Intention: whether this file was found smaller in its own form and has not been written since."""
        try:
            return self.found.get(name) == path.stat().st_mtime_ns
        except OSError:  # fault: ok a file that cannot be looked at now is passed over this run
            return True

    def note(self, files: list) -> None:
        """Intention: these files (name, path, stamp, size) found smaller in their own form, kept."""
        for name, _path, stamp, _size in files:
            self.found[name] = stamp
        write_kept(self.path, self.found, separators=(",", ":"))


def _not_written_since(parts: Parts, name: str, path: Path) -> bool:
    """Intention: whether the kept file is still the file on disk - written at the very time it was when kept."""
    try:
        return parts.stamp_of(name) == path.stat().st_mtime_ns
    except OSError:  # fault: ok a file that cannot be looked at now is left as kept
        return True


def _pieces(name: str, text: bytes, fits: int):
    """Intention: the file as one thing, or as pieces cut at line ends when it is more than one part can lift."""
    room = max(1, int(fits * BYTES_A_PIECE))
    if len(text) <= room:
        yield name, text
        return
    at, number = 0, 1
    while at < len(text):
        end = min(len(text), at + room)
        if end < len(text):
            cut = text.rfind(b"\n", at, end)
            end = cut + 1 if cut >= at else end
        yield f"{name}{PIECE}{number}", text[at:end]
        at, number = end, number + 1


def file_back(state, name: str, parts=None) -> bytes:
    """Intention: a kept file of the state (its path under state/) given back from its corpus as the very bytes it
    was - a packed file packed again the way its head says. The collection's Parts may be passed (1624c: kept open
    across many files - opened afresh for each, every part's names were read again for every file)."""
    name = Path(name).as_posix()
    if parts is None:
        parts = text_parts(state, name.split("/", 1)[0] if "/" in name else ".")
    held = parts.read(name)
    kind = parts.type_of(name)
    if kind == "text":
        return held
    length, used = first(held)
    return packed(held[used + length:], held[used:used + length], kind)


def _kept(parts: Parts, collection: str, group: list, stamps: list, say, state, waiting: list, done: dict,
          worth: float, own: OwnForm) -> dict:
    """Intention: one group of files kept as a part when that is smaller than they are on disk, said as it goes;
    then every file whose every piece is now in the corpus given back from it and set beside the file on disk - the
    very bytes, or the run stops and says which. A file written while it was being kept is noted (the next run
    keeps it again), not counted wrong. A group whose part would not be smaller stays in its own form, noted."""
    say(f"text {collection}: lifting {len(group)} files ({sum(len(t) for _n, _k, t in group):,} bytes) ...")
    measures = parts.add(group, TEXT, stamps=stamps, worth=worth)
    measures["collection"] = collection
    if not measures["kept"]:
        own.note(waiting)
        done["own_form_smaller"]["files"] += len(waiting)
        done["own_form_smaller"]["bytes"] += int(worth)
        waiting.clear()
        say(f"text {collection}: {int(worth):,} bytes on disk would be {measures['bytes']:,} in a part - "
            f"left in their own form")
        return measures
    for name, path, stamp, _size in waiting:
        try:
            same_file = path.stat().st_mtime_ns == stamp
            on_disk = path.read_bytes() if same_file else b""
        except OSError:  # fault: ok a file gone since it was read is noted below like one written since
            same_file, on_disk = False, b""
        if not same_file:
            done["written_while_kept"].append(name)
        elif file_back(state, name, parts) != on_disk:
            raise ValueError(f"{name} did not come back from the corpus as the very bytes of the file")
    waiting.clear()
    measures["collection"] = collection
    say(f"text {collection}: {measures['part']} - {measures['hydrated']:,} bytes -> {measures['bytes']:,} bytes, "
        f"every file read back the same")
    return measures
