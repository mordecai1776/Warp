# WARP3/warp2/corpus/convert/in_pieces.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/convert/in_pieces.py
#  Used by   : warp2/corpus/convert/outside.py (BringIn: a file too big to lift), tests.
#  Uses      : warp2/record/kept_file.py, warp2/corpus/convert/memory.py (free_bytes),
#              warp2/corpus/convert/state_text.py (file_back); stdlib hashlib, pathlib.
#  Description:
#    A FILE TOO BIG TO LIFT GOES IN BY PIECES. The file is cut, a piece at a time, into piece files in a folder of
#    its own under the folder being brought in (<folder>/.pieces/<the file's name>/piece-000001 ...), each piece a
#    share of the memory free when it is cut, with a note of the whole (cut.json: its sha256, size and how many
#    pieces) written only once every piece is on disk. The pieces then go in through the same door as every file
#    - dehydrated, coded, proved, removed. When the KG holds every piece, the whole file is named in the KG with
#    its sha256 and its pieces, and only then is the big file removed. A cut that was stopped part way is made
#    again; pieces already in are not put in twice. `whole_back` gives the file back a piece at a time, so reading
#    it never needs more memory than one piece.
#  User intention (Andrew, 2026-11-27 00:21): "well get the last ones done" (big files going in by pieces, so a
#    large file is not left outside for being too big to lift). BUILD_LOG 2312.
# ============================================================================
"""A big file cut into pieces on disk, so it can go in through the door a piece at a time."""
from __future__ import annotations

import hashlib
from pathlib import Path

from warp2.record.kept_file import read_kept, write_kept

FOLDER = ".pieces"
NOTE = "cut.json"


def pieces_folder(root: Path, path: Path) -> Path:
    """Intention: where this file's pieces are, under the folder being brought in."""
    return Path(root) / FOLDER / Path(path).relative_to(root)


def is_piece(root: Path, path: Path) -> bool:
    """Intention: whether a file is one of the pieces (or their note) and not a file of the folder itself."""
    return FOLDER in Path(path).relative_to(root).parts


def piece_names(count: int) -> list:
    """Intention: the names of a file's pieces, in order."""
    return [f"piece-{number:06d}" for number in range(1, count + 1)]


def cut(root: Path, path: Path) -> dict:
    """Intention: the file cut into piece files, each a share of the memory free now; the note of the whole
    ({sha256, bytes, pieces}) - made once, and read again when it is already there."""
    from warp2.corpus.convert.memory import free_bytes
    folder = pieces_folder(root, path)
    note = read_kept(folder / NOTE, dict) or {}
    if note.get("pieces"):
        return note
    folder.mkdir(parents=True, exist_ok=True)
    whole, size, count = hashlib.sha256(), 0, 0
    with Path(path).open("rb") as source:
        while True:
            raw = source.read(max(1, free_bytes() // 2 ** 4))
            if not raw:
                break
            count += 1
            (folder / piece_names(count)[-1]).write_bytes(raw)
            whole.update(raw)
            size += len(raw)
    note = {"sha256": whole.hexdigest(), "bytes": size, "pieces": count}
    write_kept(folder / NOTE, note)
    return note


def whole_back(state, name: str, pieces: int):
    """Intention: a file kept in pieces given back a piece at a time, in order (name: its name in the corpus)."""
    from warp2.corpus.convert.state_text import file_back
    collection, rest = name.split("/", 1)
    for piece in piece_names(int(pieces)):
        yield file_back(state, f"{collection}/{FOLDER}/{rest}/{piece}")


def sha_back(state, name: str, pieces: int) -> str:
    """Intention: the sha256 of a file kept in pieces, worked out from what the KG gives back now."""
    whole = hashlib.sha256()
    for raw in whole_back(state, name, pieces):
        whole.update(raw)
    return whole.hexdigest()
