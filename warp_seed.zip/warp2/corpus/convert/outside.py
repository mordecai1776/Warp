# WARP3/warp2/corpus/convert/outside.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/convert/outside.py
#  Used by   : warp2/room/odd_jobs.py (the transfer, in spare memory); started by hand: python -m warp2.corpus.convert.outside <state> <collection> <folder> [seconds]; tests.
#  Uses      : warp2/corpus/convert/state_text.py (TextTurn - the warp's own keeper of text, text_parts, file_back),
#              warp2/corpus/convert/memory.py (free_bytes), warp2/store/store.py (the KG is told),
#              (stdlib) hashlib, os, sys, time, pathlib. (Since BUILD_LOG 2258 it no longer sends anything to
#              warp2/corpus/kinds - everything is dehydrated by the text keeper first.)
#  Description:
#    THINGS FROM OUTSIDE THE WARP BROUGHT IN THROUGH THE WARP'S OWN SYSTEM. A folder outside the state is walked a
#    folder at a time and its text handed to the same keeper that keeps the state's own text (TextTurn): it is
#    dehydrated into the text corpus of its collection, where the pieces book's turn keeps working on it like on
#    everything else. Nothing is kept here by any way of this file's own, and nothing is zipped. Each file is then
#    given back from the corpus alone; when those are its very bytes (sha256) the KG is told what it is and where
#    it came from, and only then is the file removed from where it was. Left where it is, and counted: a file that
#    is already dehydrated or kept (0235c: by its name or its mark - never dehydrated twice), one that is not
#    text, one the corpus holds no smaller than itself, one too big to lift in the memory free now, and one
#    the corpus does not give back.
#    ALWAYS DEHYDRATED, THEN COMPRESSED (BUILD_LOG 2258): every file - text or not - is dehydrated by the text
#    keeper (TextTurn with every_file: one that is not text is kept as its very bytes), and the part it goes in is
#    then coded to its information (the part's own compression, part.py). Nothing is sent on to be only compressed:
#    the way of 2026-11-21 that sent what the text keeper did not take straight to the keeper of what is not text
#    (warp2/corpus/kinds) is gone from this door. A file whose part would not be smaller than it stays where it is
#    and is tried again next run, beside whatever came in since (never put in bigger - Andrew 2026-11-23). Left
#    where it is: an already dehydrated file, one too big to lift, one not given back, one kept no smaller yet.
#    A HANDFUL AT A TIME (BUILD_LOG 2306): a folder's files go in a handful at a time - as many as the memory free
#    now can lift - each handful proved and removed from outside before the next is read, so the outside folder
#    shrinks as the run goes; between handfuls a `stop` that was passed is asked, and the run ends there cleanly.
#    TOO BIG TO LIFT: BY PIECES (BUILD_LOG 2312): a file bigger than the share of free memory one file may take is
#    cut into piece files (in_pieces.py), the pieces go in like any file, and when the KG holds every piece the
#    whole file is named in the KG with its sha256 and its pieces, and only then removed from outside.
#    NEVER PUT IN TWICE (BUILD_LOG 2305): before a file is handed to the keeper its sha256 is asked of what the KG
#    already holds (AlreadyIn: every kept file the KG names, and the KG's evidence). When the KG gives back those
#    very bytes from there, the file is not put in again - the KG is told this name is the same as that one, and
#    the file is removed from where it was.
#  User intention (Andrew, 2026-11-19 23:35): "It should be using the same system everything else does the same
#    exact system and the system should also constantly be trying to put things into smaller parts." (22:46):
#    "Everything that is compressed should be dehydrated first". (22:31): "we should not be using zip anywhere".
#    BUILD_LOG 0220b. (2026-11-26) "Always dehydrated then compressed never just compressed" (2258).
#    (2026-11-26 23:03) "make sure it is not putting in things that are already in the kg" (2304).
# ============================================================================
"""A folder outside the warp kept by the warp's own text keeper, proved from the corpus, named in the KG, removed."""
from __future__ import annotations

import hashlib
import os
import sys
import time
from pathlib import Path

from warp2.corpus.convert import in_pieces
from warp2.corpus.convert.state_text import TextTurn, file_back, text_parts

# Intention: how often a person watching is told how far it is (Andrew 2026-11-09: "things like this need visuals as
# they run").
SAY_EVERY = 15.0  # fault: ok seconds between progress lines for a person watching; nothing is decided by it


def _folders(root: Path):
    """Intention: every folder under the root that has files of its own, with them as (path, write time, size)."""
    for folder, _inside, names in os.walk(root):
        files = []
        for name in sorted(names):
            path = Path(folder) / name
            # the pieces of a big file are brought in with that file (BringIn._big), never as files of the folder
            if in_pieces.is_piece(root, path):
                continue
            try:
                seen = path.stat()
            except OSError:  # fault: ok a file gone since the folder was listed is not there to bring in
                continue
            files.append((path, seen.st_mtime_ns, seen.st_size))
        if files:
            yield Path(folder), files


def already_dehydrated(path: Path, root: Path) -> bool:
    """Intention (0235c - Andrew 2026-11-20 02:29: "Does it make sure it is not trying to dehydrate already
    dehydrated files"): whether a file is in a dehydrated or kept form already - it says so in its name or in the
    name of a folder it is in, or its first bytes are the mark of a file kept by the function book. Such a file is
    never handed to the keeper to be dehydrated a second time."""
    from warp2.equation_book.kept_files import is_kept
    if any("dehydrated" in part.lower() for part in path.relative_to(root).parts):
        return True
    try:
        with path.open("rb") as handle:
            return is_kept(handle.read(2 ** 6))
    except OSError:  # fault: ok a file that cannot be opened now is not handed on either; it is counted with these
        return True


def _told(store, name: str, raw: bytes, collection: str, came_from: Path) -> None:
    """Intention: the KG told of one file brought in - what it is, its sha256, its size, where it is kept, where it
    came from - so it is a thing of the KG, found and given back by its name."""
    said = {"kind": "kept_file", "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw),
            "kept_in": f"corpus/text/{collection}", "came_from": str(came_from)}
    for attr, value in said.items():
        store.assert_fact(name, "has", attr=attr, value=value)


def _sha_of_file(path: Path) -> str:
    """Intention: a file's sha256 read a piece at a time, so a file of any size is asked about without lifting it."""
    whole = hashlib.sha256()
    with path.open("rb") as handle:
        for piece in iter(lambda: handle.read(2 ** 20), b""):
            whole.update(piece)
    return whole.hexdigest()


def _mine_now() -> int:
    """Intention: the memory that is this process's alone now, in bytes (nought when it cannot be read)."""
    try:
        import psutil
        info = psutil.Process(os.getpid()).memory_info()
        return int(info.rss)   # what it holds in the machine's memory now (not what it has only set aside)
    except Exception:  # fault: ok a process that cannot read itself learns no cost; its handfuls stay small
        return 0


def _most_held() -> int:
    """Intention: the most memory this process has held so far (where the machine says), else what it holds now."""
    try:
        import psutil
        info = psutil.Process(os.getpid()).memory_info()
        return int(getattr(info, "peak_wset", None) or info.rss)
    except Exception:  # fault: ok as _mine_now
        return 0


class AlreadyIn:
    """Intention (BUILD_LOG 2305 - Andrew 2026-11-26 23:03: "make sure it is not putting in things that are already
    in the kg"; 2026-11-19 22:02: "if it is already in the kg we dont need to repeat it in there"): what the KG
    already holds, by sha256 - every kept file it names (and where its corpus keeps it) and its evidence - and the
    proof, read back from there now, that those are the very bytes."""

    def __init__(self, state, store) -> None:
        """Intention: the sha256 of every kept file the KG names, with the name it is kept under, read once."""
        from warp2.record.evidence import Evidence
        from warp2.store.store import store_home
        self.state = Path(state)
        kept = {subject for subject, value in store.attributed("kind") if value == "kept_file"}
        # a name that only says it is the same as another holds no bytes of its own, so it is never where bytes are read from
        twins = {subject for subject, _value in store.attributed("same_as")}
        self.named = {str(value): subject for subject, value in store.attributed("sha256")
                      if subject in kept and subject not in twins}
        # Intention (BUILD_LOG 2312): a file kept in pieces is read back a piece at a time, by how many pieces it has.
        self.pieced = {subject: int(value) for subject, value in store.attributed("pieces") if str(value).isdigit()}
        self.evidence = [Evidence(root) for root in (self.state / "evidence", Path(store_home(self.state)) / "evidence")
                         if root.is_dir()]

    def note(self, sha: str, name: str) -> None:
        """Intention: a file brought in this run is known at once, so its twin later in the run is not put in."""
        self.named.setdefault(sha, name)

    def where(self, sha: str) -> str | None:
        """Intention: where the KG holds these very bytes (a kept file's name, or "evidence:<sha256>"), proved by
        reading them back from there now; None when it does not hold them or does not give them back."""
        name = self.named.get(sha)
        if name is not None:
            try:
                if name in self.pieced:
                    if in_pieces.sha_back(self.state, name, self.pieced[name]) == sha:
                        return name
                elif hashlib.sha256(file_back(self.state, name)).hexdigest() == sha:
                    return name
            except (OSError, KeyError, ValueError):  # fault: ok a kept file not given back is not counted as held; the file is put in
                pass
        for held in self.evidence:
            try:
                if held.has(sha) and hashlib.sha256(bytes(held.get(sha))).hexdigest() == sha:
                    return f"evidence:{sha}"
            except (OSError, RuntimeError, ValueError):  # fault: ok evidence that does not read is not counted as held
                continue
        return None


class BringIn:
    """Intention: one run of bringing a folder in - the warp's keeper, the KG, and the count of what happened."""

    def __init__(self, state, collection: str, root, say=print) -> None:
        """Intention: the state, the collection the folder is kept as, the folder, and where progress is said."""
        from warp2.store.store import Store, store_home
        self.state, self.collection, self.root, self.say = Path(state), collection, Path(root), say
        self.turn = TextTurn(self.state, lambda *_said, **_how: None, roots={collection: self.root}, every_file=True)
        self.store = Store(store_home(self.state))
        self.already = AlreadyIn(self.state, self.store)
        self.twins: list = []
        self.stopped = False
        self.cost = None
        self.done = {"files": 0, "bytes": 0, "not_text": 0, "too_big": 0, "not_given_back": 0, "kept_no_smaller": 0,
                     "already_dehydrated": 0, "already_in_the_kg": 0, "already_in_the_kg_bytes": 0}
        self.began = self.last = time.monotonic()

    def _name(self, path: Path) -> str:
        """Intention: the name a file of the folder has in the corpus."""
        return f"{self.collection}/{path.relative_to(self.root).as_posix()}"

    def _not_held(self, files: list) -> list:
        """Intention (BUILD_LOG 2305): the files the KG does not hold yet. One whose very bytes the KG gives back
        from where it already keeps them is not put in again: the KG is told this name is the same as that one,
        and the file is removed from where it was."""
        new, first = [], {}
        for path, seen, size in files:
            try:
                sha = _sha_of_file(path)
            except OSError:  # fault: ok a file that cannot be read now is left where it is for the next run
                continue
            held = self.already.where(sha)
            if held is None and sha in first:
                # the same bytes twice in one folder: the second waits until the first is in, then is told the same
                self.twins.append((path, seen, size))
                continue
            if held is None or held == self._name(path):
                first[sha] = path
                new.append((path, seen, size))
                continue
            said = {"kind": "kept_file", "sha256": sha, "bytes": size, "same_as": held, "came_from": str(path)}
            for attr, value in said.items():
                self.store.assert_fact(self._name(path), "has", attr=attr, value=value)
            path.unlink(missing_ok=True)
            self.done["already_in_the_kg"] += 1
            self.done["already_in_the_kg_bytes"] += size
            self.progress()
        return new

    def folder(self, files: list, until, stop=None) -> None:
        """Intention: one folder's files brought in a handful at a time (each handful kept, proved and removed
        before the next); ended between handfuls when the time is up or `stop()` says so."""
        from warp2.corpus.convert.memory import free_bytes
        fresh = [f for f in files if not already_dehydrated(f[0], self.root)]
        self.done["already_dehydrated"] += len(files) - len(fresh)
        fits = [f for f in fresh if f[2] <= free_bytes() // 2 ** 3]
        big = [f for f in fresh if f not in fits]
        for hand in self._handfuls(fits):
            if (stop is not None and stop()) or (until is not None and time.monotonic() >= until):
                self.stopped = True
                break
            # Intention (BUILD_LOG 2316): the KG is asked about a handful's files as that handful comes up - before,
            # every file of the folder was read to its end before the first went in, at every start of a run.
            hand = self._not_held(hand)
            if hand:
                before = _mine_now()
                self._hand_in(hand, until)
                self._learn_cost(sum(f[2] for f in hand), before)
        # a twin whose first is now in is told the same and removed; one whose first did not go in waits where it is
        waiting, self.twins = self.twins, []
        self._not_held(waiting)
        self.twins = []
        for big_file in big:
            if self.stopped or (stop is not None and stop()) or (until is not None and time.monotonic() >= until):
                self.stopped = True
                break
            if self._not_held([big_file]):
                self._big(big_file[0], until, stop)

    def _big(self, path: Path, until, stop) -> None:
        """Intention (BUILD_LOG 2312): one file too big to lift - cut into pieces, the pieces brought in like any
        file; when the KG holds every piece and gives back the whole file's sha256, the KG is told the whole (its
        sha256, size and pieces) and the big file and its note are removed. Until then it is counted too big."""
        note = in_pieces.cut(self.root, path)
        folder = in_pieces.pieces_folder(self.root, path)
        names = in_pieces.piece_names(note["pieces"])
        waiting = [folder / n for n in names if (folder / n).is_file()]
        for hand in self._handfuls([(p, p.stat().st_mtime_ns, p.stat().st_size) for p in waiting]):
            if (stop is not None and stop()) or (until is not None and time.monotonic() >= until):
                self.stopped = True
                break
            self._hand_in(hand, until)
        name = self._name(path)
        parts = text_parts(self.state, self.collection)
        all_in = all(parts.holds(self._name(folder / n)) for n in names) and not any((folder / n).exists() for n in names)
        if not all_in or in_pieces.sha_back(self.state, name, note["pieces"]) != note["sha256"]:
            self.done["too_big"] += 1
            return
        said = {"kind": "kept_file", "sha256": note["sha256"], "bytes": note["bytes"], "pieces": note["pieces"],
                "kept_in": f"corpus/text/{self.collection}", "came_from": str(path)}
        for attr, value in said.items():
            self.store.assert_fact(name, "has", attr=attr, value=value)
        self.already.pieced[name] = int(note["pieces"])
        self.already.note(note["sha256"], name)
        path.unlink(missing_ok=True)
        (folder / in_pieces.NOTE).unlink(missing_ok=True)
        self.done["files"] += 1
        self.done["bytes"] += int(note["bytes"])

    def _learn_cost(self, hand_bytes: int, before: int) -> None:
        """Intention (BUILD_LOG 2316): what a byte of a file costs in memory while it is kept, measured - the most
        this process came to hold over what it held before the handful, for each byte of the handful."""
        took = _most_held() - before
        if hand_bytes > 0 and took > 0:
            self.cost = max(self.cost or 0.0, took / hand_bytes)

    def _lift(self) -> int:
        """Intention (BUILD_LOG 2316; seen 2026-11-27: the transfer took 9 GB with 7.7 GB spare, the machine came
        short and the run was stopped after 3 files): how many bytes of files one handful may hold now. Until the
        cost of a byte has been measured it is a share of what this process itself holds; after, as many as half of what is free can pay for at the
        measured cost - never more than the share a single file may be."""
        from warp2.corpus.convert.memory import free_bytes
        if self.cost is None:
            # not measured yet: a first handful as big as a share of what this process itself holds - small beside
            # the machine, and still a handful, so a file nothing shrinks goes in beside the others of its folder
            return min(free_bytes(), _mine_now()) // 2 ** 3
        return min(free_bytes() // 2 ** 3, int(free_bytes() // 2 / max(self.cost, 1.0)))

    def _handfuls(self, files: list):
        """Intention (BUILD_LOG 2306): the files in handfuls - each as many as this run may lift now (`_lift`),
        never fewer than one file."""
        hand, held = [], 0
        for file in files:
            if hand and held + file[2] > self._lift():
                yield hand
                hand, held = [], 0
            hand.append(file)
            held += file[2]
        if hand:
            yield hand

    def _hand_in(self, fits: list, until) -> None:
        """Intention: one handful handed to the keeper and its part put in; each file the corpus now holds given
        back, and when those are its very bytes the KG is told and the file is removed from outside."""
        self.done["not_text"] += len(self.turn.take(self.collection, fits, until))
        self.turn.finish(self.collection)
        parts = text_parts(self.state, self.collection)
        for path, _seen, _size in fits:
            name = self._name(path)
            if not parts.holds(name):
                continue
            try:
                raw = path.read_bytes()
                same = file_back(self.state, name, parts) == raw
            except (OSError, KeyError, ValueError):  # fault: ok a file not given back is left where it is, and counted
                same = False
            if not same:
                self.done["not_given_back"] += 1
                continue
            _told(self.store, name, raw, self.collection, path)
            self.already.note(hashlib.sha256(raw).hexdigest(), name)
            path.unlink(missing_ok=True)
            self.done["files"] += 1
            self.done["bytes"] += len(raw)
            self.progress()

    def progress(self) -> None:
        """Intention: how far it is, said when long enough has passed since it was last said."""
        if time.monotonic() - self.last < SAY_EVERY:
            return
        self.last = time.monotonic()
        rate = self.done["bytes"] / max(time.monotonic() - self.began, 1e-9)
        self.say(f"  {self.done['files']:,} files in and removed, {self.done['bytes'] / 2 ** 30:.2f} GB, {rate / 2 ** 20:.2f} MB a second; "
                 f"{self.done['already_in_the_kg']:,} already in the KG, not put in again")

    def close(self) -> dict:
        """Intention: the keeper and the KG let go; what the run came to (with how big the corpus is now)."""
        took = self.turn.close()
        self.store.close()
        home = self.state / "corpus" / "text" / self.collection
        self.done["corpus_bytes"] = sum(p.stat().st_size for p in home.rglob("*") if p.is_file()) if home.is_dir() else 0
        self.done["kept_no_smaller"] = int(took["own_form_smaller"]["files"])
        return self.done


class OneAtATime:
    """Intention (BUILD_LOG 2306): one run at a time brings a collection in - two at once would write the same
    parts. The run's process number is kept in state/locks/bring_in_<collection>.json while it works."""

    def __init__(self, state, collection: str) -> None:
        """Intention: where this collection's mark is kept."""
        self.file = Path(state) / "locks" / f"bring_in_{collection}.json"

    def other(self) -> int:
        """Intention: the process number of another run still at work on this collection, or nought."""
        from warp2.record.kept_file import read_kept
        try:
            import psutil
            pid = int((read_kept(self.file, dict) or {}).get("pid", 0))
            return pid if pid and pid != os.getpid() and psutil.pid_exists(pid) else 0
        except Exception:  # fault: ok a mark that cannot be read is no proof of another run; this run goes on
            return 0

    def take(self) -> None:
        """Intention: this run marked as the one at work."""
        from warp2.record.kept_file import write_kept
        write_kept(self.file, {"pid": os.getpid(), "since": time.time()})

    def give(self) -> None:
        """Intention: the mark taken away when the run ends."""
        self.file.unlink(missing_ok=True)


def bring_in(state, collection: str, root, say=print, seconds: float | None = None, stop=None) -> dict:
    """Intention: a folder outside the warp brought in as a collection of the text corpus, a folder at a time while
    the time lasts and `stop()` (when passed) does not say to end; what was done. Folders left empty are removed."""
    one = OneAtATime(state, collection)
    if one.other():
        say(f"another run (process {one.other()}) is bringing {collection} in; this one does nothing")
        return {"files": 0, "bytes": 0, "left": sum(1 for p in Path(root).rglob("*") if p.is_file()), "other_run": one.other()}
    one.take()
    run = BringIn(state, collection, root, say)
    until = None if seconds is None else time.monotonic() + seconds
    try:
        for _folder, files in _folders(Path(root)):
            if (until is not None and time.monotonic() >= until) or (stop is not None and stop()) or run.stopped:
                break
            run.folder(files, until, stop)
    finally:
        done = run.close()
        one.give()
    for folder in sorted((p for p in Path(root).rglob("*") if p.is_dir()), reverse=True):
        if not any(folder.iterdir()):
            folder.rmdir()
    done["left"] = sum(1 for p in Path(root).rglob("*") if p.is_file())
    say(f"already in the KG, not put in again: {done['already_in_the_kg']:,} files ({done['already_in_the_kg_bytes'] / 2 ** 30:.2f} GB)")
    say(f"done: {done['files']:,} files brought in and removed ({done['bytes'] / 2 ** 30:.2f} GB); the collection's corpus is "
        f"{done['corpus_bytes'] / 2 ** 30:.2f} GB; left where they are: {done['left']:,} (not text {done['not_text']:,}, "
        f"already dehydrated {done['already_dehydrated']:,}, kept no smaller {done['kept_no_smaller']:,}, too big to lift {done['too_big']:,}, not given back {done['not_given_back']:,})")
    return done


def main(args: list) -> None:
    """Intention: started by hand - `<state> <collection> <folder> [seconds]`; each line said as it happens."""
    seconds = float(args[3]) if len(args) > 3 else None
    bring_in(Path(args[0]), args[1], args[2], say=lambda line: print(time.strftime("%H:%M:%S"), line, flush=True), seconds=seconds)


if __name__ == "__main__":
    main(sys.argv[1:])
