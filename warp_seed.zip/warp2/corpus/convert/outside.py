# WARP3/warp2/corpus/convert/outside.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/convert/outside.py
#  Used by   : started by hand: python -m warp2.corpus.convert.outside <state> <collection> <folder> [seconds]; tests.
#  Uses      : warp2/corpus/convert/state_text.py (TextTurn - the warp's own keeper of text, text_parts, file_back),
#              warp2/corpus/convert/memory.py (free_bytes), warp2/store/store.py (the KG is told),
#              (stdlib) hashlib, os, sys, time, pathlib. (Since BUILD_LOG 2258 it no longer sends anything to
#              warp2/corpus/kinds - everything is dehydrated by the text keeper first.)
#  Description:
#    THINGS FROM OUTSIDE THE WARP BROUGHT IN THROUGH THE WARP'S OWN SYSTEM. A folder outside the state is walked a
#    folder at a time and its text handed to the same keeper that keeps the state's own text (TextTurn): it is
#    dehydrated into the text corpus of its collection, where the pieces book's turn keeps working on it like on
#    everything else. Nothing is kept here by any way of this file's own, and nothing is zipped. Each file is then
#    given back from the corpus alone; when those are its very bytes (sha256) the KG is told what it is and where
#    it came from, and only then is the file removed from where it was. Left where it is, and counted: a file that
#    is already dehydrated or kept (0235c: by its name or its mark - never dehydrated twice), one that is not
#    text, one the corpus holds no smaller than itself, one too big to lift in the memory free now, and one
#    the corpus does not give back.
#    ALWAYS DEHYDRATED, THEN COMPRESSED (BUILD_LOG 2258): every file - text or not - is dehydrated by the text
#    keeper (TextTurn with every_file: one that is not text is kept as its very bytes), and the part it goes in is
#    then coded to its information (the part's own compression, part.py). Nothing is sent on to be only compressed:
#    the way of 2026-11-21 that sent what the text keeper did not take straight to the keeper of what is not text
#    (warp2/corpus/kinds) is gone from this door. A file whose part would not be smaller than it stays where it is
#    and is tried again next run, beside whatever came in since (never put in bigger - Andrew 2026-11-23). Left
#    where it is: an already dehydrated file, one too big to lift, one not given back, one kept no smaller yet.
#  User intention (Andrew, 2026-11-19 23:35): "It should be using the same system everything else does the same
#    exact system and the system should also constantly be trying to put things into smaller parts." (22:46):
#    "Everything that is compressed should be dehydrated first". (22:31): "we should not be using zip anywhere".
#    BUILD_LOG 0220b. (2026-11-26) "Always dehydrated then compressed never just compressed" (2258).
# ============================================================================
"""A folder outside the warp kept by the warp's own text keeper, proved from the corpus, named in the KG, removed."""
from __future__ import annotations

import hashlib
import os
import sys
import time
from pathlib import Path

from warp2.corpus.convert.state_text import TextTurn, file_back, text_parts

# Intention: how often a person watching is told how far it is (Andrew 2026-11-09: "things like this need visuals as
# they run").
SAY_EVERY = 15.0  # fault: ok seconds between progress lines for a person watching; nothing is decided by it


def _folders(root: Path):
    """Intention: every folder under the root that has files of its own, with them as (path, write time, size)."""
    for folder, _inside, names in os.walk(root):
        files = []
        for name in sorted(names):
            path = Path(folder) / name
            try:
                seen = path.stat()
            except OSError:  # fault: ok a file gone since the folder was listed is not there to bring in
                continue
            files.append((path, seen.st_mtime_ns, seen.st_size))
        if files:
            yield Path(folder), files


def already_dehydrated(path: Path, root: Path) -> bool:
    """Intention (0235c - Andrew 2026-11-20 02:29: "Does it make sure it is not trying to dehydrate already
    dehydrated files"): whether a file is in a dehydrated or kept form already - it says so in its name or in the
    name of a folder it is in, or its first bytes are the mark of a file kept by the function book. Such a file is
    never handed to the keeper to be dehydrated a second time."""
    from warp2.equation_book.kept_files import is_kept
    if any("dehydrated" in part.lower() for part in path.relative_to(root).parts):
        return True
    try:
        with path.open("rb") as handle:
            return is_kept(handle.read(2 ** 6))
    except OSError:  # fault: ok a file that cannot be opened now is not handed on either; it is counted with these
        return True


def _told(store, name: str, raw: bytes, collection: str, came_from: Path) -> None:
    """Intention: the KG told of one file brought in - what it is, its sha256, its size, where it is kept, where it
    came from - so it is a thing of the KG, found and given back by its name."""
    said = {"kind": "kept_file", "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw),
            "kept_in": f"corpus/text/{collection}", "came_from": str(came_from)}
    for attr, value in said.items():
        store.assert_fact(name, "has", attr=attr, value=value)


class BringIn:
    """Intention: one run of bringing a folder in - the warp's keeper, the KG, and the count of what happened."""

    def __init__(self, state, collection: str, root, say=print) -> None:
        """Intention: the state, the collection the folder is kept as, the folder, and where progress is said."""
        from warp2.store.store import Store, store_home
        self.state, self.collection, self.root, self.say = Path(state), collection, Path(root), say
        self.turn = TextTurn(self.state, lambda *_said, **_how: None, roots={collection: self.root}, every_file=True)
        self.store = Store(store_home(self.state))
        self.done = {"files": 0, "bytes": 0, "not_text": 0, "too_big": 0, "not_given_back": 0, "kept_no_smaller": 0,
                     "already_dehydrated": 0}
        self.began = self.last = time.monotonic()

    def _name(self, path: Path) -> str:
        """Intention: the name a file of the folder has in the corpus."""
        return f"{self.collection}/{path.relative_to(self.root).as_posix()}"

    def folder(self, files: list, until) -> None:
        """Intention: one folder's files handed to the warp's keeper and its parts put in; then each file the corpus
        now holds is given back, and when those are its very bytes the KG is told and the file is removed."""
        from warp2.corpus.convert.memory import free_bytes
        fresh = [f for f in files if not already_dehydrated(f[0], self.root)]
        self.done["already_dehydrated"] += len(files) - len(fresh)
        fits = [f for f in fresh if f[2] <= free_bytes() // 2 ** 3]
        self.done["too_big"] += len(fresh) - len(fits)
        self.done["not_text"] += len(self.turn.take(self.collection, fits, until))
        self.turn.finish(self.collection)
        parts = text_parts(self.state, self.collection)
        for path, _seen, _size in fits:
            name = self._name(path)
            if not parts.holds(name):
                continue
            try:
                raw = path.read_bytes()
                same = file_back(self.state, name, parts) == raw
            except (OSError, KeyError, ValueError):  # fault: ok a file not given back is left where it is, and counted
                same = False
            if not same:
                self.done["not_given_back"] += 1
                continue
            _told(self.store, name, raw, self.collection, path)
            path.unlink(missing_ok=True)
            self.done["files"] += 1
            self.done["bytes"] += len(raw)
            self.progress()

    def progress(self) -> None:
        """Intention: how far it is, said when long enough has passed since it was last said."""
        if time.monotonic() - self.last < SAY_EVERY:
            return
        self.last = time.monotonic()
        rate = self.done["bytes"] / max(time.monotonic() - self.began, 1e-9)
        self.say(f"  {self.done['files']:,} files in and removed, {self.done['bytes'] / 2 ** 30:.2f} GB, {rate / 2 ** 20:.2f} MB a second")

    def close(self) -> dict:
        """Intention: the keeper and the KG let go; what the run came to (with how big the corpus is now)."""
        took = self.turn.close()
        self.store.close()
        home = self.state / "corpus" / "text" / self.collection
        self.done["corpus_bytes"] = sum(p.stat().st_size for p in home.rglob("*") if p.is_file()) if home.is_dir() else 0
        self.done["kept_no_smaller"] = int(took["own_form_smaller"]["files"])
        return self.done


def bring_in(state, collection: str, root, say=print, seconds: float | None = None) -> dict:
    """Intention: a folder outside the warp brought in as a collection of the text corpus, a folder at a time while
    the time lasts; what was done. Folders left empty are removed."""
    run = BringIn(state, collection, root, say)
    until = None if seconds is None else time.monotonic() + seconds
    try:
        for _folder, files in _folders(Path(root)):
            if until is not None and time.monotonic() >= until:
                break
            run.folder(files, until)
    finally:
        done = run.close()
    for folder in sorted((p for p in Path(root).rglob("*") if p.is_dir()), reverse=True):
        if not any(folder.iterdir()):
            folder.rmdir()
    done["left"] = sum(1 for p in Path(root).rglob("*") if p.is_file())
    say(f"done: {done['files']:,} files brought in and removed ({done['bytes'] / 2 ** 30:.2f} GB); the collection's corpus is "
        f"{done['corpus_bytes'] / 2 ** 30:.2f} GB; left where they are: {done['left']:,} (not text {done['not_text']:,}, "
        f"already dehydrated {done['already_dehydrated']:,}, kept no smaller {done['kept_no_smaller']:,}, too big to lift {done['too_big']:,}, not given back {done['not_given_back']:,})")
    return done


def main(args: list) -> None:
    """Intention: started by hand - `<state> <collection> <folder> [seconds]`; each line said as it happens."""
    seconds = float(args[3]) if len(args) > 3 else None
    bring_in(Path(args[0]), args[1], args[2], say=lambda line: print(time.strftime("%H:%M:%S"), line, flush=True), seconds=seconds)


if __name__ == "__main__":
    main(sys.argv[1:])
