# WARP2/warp2/corpus/convert/packed.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/packed.py
#  Used by   : warp2/corpus/convert/state_text.py; warp2/corpus/shelf.py
#              (a packed file given back); warp2/corpus/tests/.
#  Uses      : (stdlib) gzip, io, struct, zlib.
#  Description:
#    A FILE KEPT PACKED (gzip, zlib) IS TAKEN AS ITS TEXT - the text is what
#    repeats across files, and packing each file alone hides that. It is
#    kept as its text with a short head saying how to pack it again (the
#    gzip head's own bytes, or the zlib level), and it is only taken this
#    way when packing the text again gives the very same bytes as the file
#    (checked here, on this machine's zlib); otherwise it is left as it is.
#  User intention (Andrew, 2026-11-13 20:38): "Every file should just be a
#    group of tags". BUILD_LOG 1621c.
# ============================================================================
"""Packed files opened to their text and packed back to the same bytes."""
from __future__ import annotations

import gzip
import io
import zlib

GZIP, ZLIB = "gzip", "zlib"


def opened(raw: bytes, how: str):
    """Intention: (the text, the head that packs it back) when packing it back gives the same bytes; else None."""
    try:
        text = gzip.decompress(raw) if how == GZIP else zlib.decompress(raw)
    except (OSError, zlib.error, EOFError):  # fault: ok a file that does not open as packed is left as it is
        return None
    for level in (9, 6, 1, 2, 3, 4, 5, 7, 8, 0):
        head = _gzip_head(raw, level) if how == GZIP else bytes([level])
        if head is not None and packed(text, head, how) == raw:
            return text, head
    return None


def _gzip_head(raw: bytes, level: int):
    """Intention: what a gzip file's head says (time, name) with the level to try, as the head kept for it."""
    if len(raw) < 10 or raw[:2] != b"\x1f\x8b":
        return None
    flags = raw[3]
    name = b""
    if flags & 0x08:
        end = raw.index(b"\x00", 10)
        name = raw[10:end]
    if flags & ~0x08 & 0xFF:
        return None  # Intention: heads with more than a name are not packed back here; left as they are
    return bytes([level]) + raw[4:8] + name


def packed(text: bytes, head: bytes, how: str) -> bytes:
    """Intention: the text packed back the way its head says."""
    level = head[0]
    if how == ZLIB:
        return zlib.compress(text, level)
    out = io.BytesIO()
    mtime = int.from_bytes(head[1:5], "little")
    with gzip.GzipFile(filename=head[5:].decode("latin-1"), mode="wb", fileobj=out, compresslevel=level,
                       mtime=mtime) as writer:
        writer.write(text)
    return out.getvalue()
