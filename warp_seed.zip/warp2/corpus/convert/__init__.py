# WARP2/warp2/corpus/convert/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/__init__.py
#  Used by   : warp2/corpus/convert/{memory,kg,state_text,run}.py (the package).
#  Uses      : nothing.
#  Description:
#    WHAT THE WARP HOLDS, PUT INTO CORPUS FORM (BUILD_LOG 1621c).
#      memory.py     - how many tags one part can be lifted from at once
#      kg.py         - the KG's record: each segment an anchor over the KG's
#                      corpus, kept beside the record's own book
#      packed.py     - a file kept packed (gzip, zlib) taken as its text,
#                      and packed back to the very same bytes
#      state_text.py - every text file of the state an anchor over the text
#                      corpus of its collection
#      run.py        - all of it, saying how far it has got
#  User intention (Andrew, 2026-11-13 20:57): "do it and make everything in
#    this form"; 21:03: "Do not stop until everything is converted and let
#    me know the significant numbers when your done."
# ============================================================================
