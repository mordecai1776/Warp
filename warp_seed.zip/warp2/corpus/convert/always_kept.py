# WARP3/warp2/corpus/convert/always_kept.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/convert/always_kept.py
#  Used by   : warp2/corpus/convert/state_text.py (_kept: a part that holds such a file always goes in), tests.
#  Uses      : stdlib pathlib.
#  Description:
#    WHAT IS KEPT NO MATTER WHAT: research papers and the user's intentions. A file is one of these when its name
#    or a folder it is in says so (WORDS), or it is a PDF. Such a file is put in the KG even when its part would
#    be no smaller than the file - the rule "never put in bigger" does not hold for it - so it is never the thing
#    left outside, passed over, or waiting.
#  User intention (Andrew, 2026-11-26 23:45): "it should keep all research papers and users intentions no matter
#    what." BUILD_LOG 2308.
# ============================================================================
"""Research papers and the user's intentions: always put in, whatever the size comes to."""
from __future__ import annotations

from pathlib import PurePosixPath

# Intention: the words in a name or a folder that say a file is a research paper or the user's intention.
WORDS = ("paper", "research", "arxiv", "intention", "andrew_design", "andrews_design", "in_his_words")
# Intention: the kinds of file a paper comes as.
PAPER_KINDS = (".pdf",)


def must_keep(name) -> bool:
    """Intention: whether this file is a research paper or the user's intention - kept no matter what."""
    path = PurePosixPath(str(name).replace("\\", "/").lower())
    return path.suffix in PAPER_KINDS or any(word in part for part in path.parts for word in WORDS)
