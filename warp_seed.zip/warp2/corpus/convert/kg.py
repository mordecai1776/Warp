# WARP2/warp2/corpus/convert/kg.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/convert/kg.py
#  Used by   : warp2/corpus/convert/run.py; warp2/corpus/tests/.
#  Uses      : warp2/corpus/{parts,varint}.py; warp2/corpus/convert/memory.py;
#              warp2/record/kept_file.py (read_kept - the record, or nothing
#              yet); (stdlib) time, pathlib.
#  Description:
#    THE KG'S RECORD IN CORPUS FORM. The record's book already holds every
#    signature, web form and web tag once - the base of the KG's corpus. Each
#    segment of the record (entries-NNNN.bin: for each entry its web tag, its
#    step in order, and what fills its open places) becomes an anchor: its
#    name, its type ("kg entries") and its notation over the KG's corpus,
#    where the runs of numbers that repeat across the record are lifted into
#    higher tags while the whole gets smaller. The parts are kept in
#    <record folder>/corpus/, beside the book, and a segment counts as kept
#    only when its numbers read back from the part and pack to the very bytes
#    of its file. A segment written since is kept by the next run. Kept by
#    the KG's turn, segments wait in their own small files until together
#    they fill a part - what one lift can hold with the memory free now - so
#    the corpus is made of full parts (BUILD_LOG 1622c).
#  User intention (Andrew, 2026-11-13 20:52): "That should be the structure
#    of the knowledge graph itself." 20:19: "the warp should be working from
#    the dehydrated kg now." BUILD_LOG 1621c.
# ============================================================================
"""Each segment of the KG's record kept as an anchor over the KG's corpus."""
from __future__ import annotations

import time
from pathlib import Path

from warp2.corpus.convert.memory import tags_that_fit
from warp2.corpus.parts import NUMBERS, Parts
from warp2.corpus.varint import pack, unpack
from warp2.record.kept_file import read_kept

TYPE = "kg entries"
FOLDER = "corpus"


def kg_parts(record_folder) -> Parts:
    """Intention: the KG's corpus parts, beside the record's book."""
    return Parts(Path(record_folder) / FOLDER)


def keep_kg(record_folder, say=print, every: bool = True) -> dict:
    """Intention: every segment of the record not yet in the KG's corpus, kept (with every=False, only once the
    waiting ones fill a part); what it came to."""
    record_folder = Path(record_folder)
    record = read_kept(record_folder / "done.json", dict)
    parts = kg_parts(record_folder)
    waiting = [record[name]["small"] for name in sorted(record) if not parts.holds(record[name]["small"])]
    done = {"segments": 0, "bytes_were": 0, "parts": [], "left_as_they_are": [], "waiting": 0, "seconds": 0.0}
    began, group, held = time.time(), [], 0
    fits = tags_that_fit()
    for small in waiting:
        raw = (record_folder / small).read_bytes()
        numbers = unpack(raw)
        if pack(numbers) != raw:
            done["left_as_they_are"].append(small)  # Intention: not written as plain numbers; never guessed at
            continue
        if group and held + numbers.size > fits:
            done["parts"].append(_kept(parts, group, say))
            group, held, fits = [], 0, tags_that_fit()
        group.append((small, TYPE, numbers))
        held += numbers.size
        done["segments"] += 1
        done["bytes_were"] += len(raw)
    if group and (every or held >= fits):
        done["parts"].append(_kept(parts, group, say))
    elif group:
        # Intention (1622c): not yet a part's worth - they wait in their own small files, read from there.
        done["segments"] -= len(group)
        done["bytes_were"] -= sum(len(pack(numbers)) for _s, _t, numbers in group)
        done["waiting"] = len(group)
    done["seconds"] = round(time.time() - began, 1)
    return done


def _kept(parts: Parts, group: list, say) -> dict:
    """Intention: one group of segments kept as a part, said as it goes."""
    say(f"kg: lifting {len(group)} segments ({sum(len(n) for _a, _t, n in group):,} numbers) ...")
    measures = parts.add(group, NUMBERS)
    say(f"kg: {measures['part']} - {measures['hydrated']:,} bytes as they were -> {measures['bytes']:,} bytes "
        f"({measures['higher_tags']:,} higher tags), every segment read back the same")
    return measures
