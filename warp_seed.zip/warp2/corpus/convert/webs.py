# WARP3/warp2/corpus/convert/webs.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/convert/webs.py
#  Used by   : warp2/corpus/convert/run.py ("webs"); warp2/webs/home.py (db -
#              the connection web given back when its file is not there);
#              warp2/corpus/shelf.py (where it is kept); warp2/corpus/tests/.
#  Uses      : warp2/corpus/{columns,table}.py; warp2/corpus/convert/memory.py;
#              warp2/record/kept_file.py; warp2/record/stop.py (runtime_dir);
#              warp2/util.py (atomic_write_bytes); (stdlib) os, sqlite3, sys,
#              time, pathlib.
#  Description:
#    THE CONNECTION WEB IN CORPUS FORM. The KG's other part - the webs over
#    the base (state/webs/webs.sqlite3: links, webs, members, readings,
#    proofs, decisions, the practice webs) - kept the way the KG's facts are:
#    every table as blocks of columns of tag numbers (table.py), and every
#    text of every table numbered once in one word table, so a name that is
#    a member in one table and a web in another is one tag. The database is
#    first copied whole the way SQLite copies a live database (its backup:
#    every table as it stood at one moment, even if the warp writes the webs
#    meanwhile), then read from the copy, a block at a time - as many rows
#    as half the free memory holds. A block counts only when every column of
#    it reads back as the same values of the same types; the word table the
#    same. With the database's own words for its tables, views, indexes and
#    triggers, that is the whole database: `give_back` makes it again, row
#    for row. The webs are rewritten every turn, so this is a picture of
#    them as they stood (state/corpus/webs/now/); a newer picture takes its
#    place only once it has read back whole, and the one before is moved to
#    state/corpus/webs/older/ - nothing is thrown away.
#  User intention (Andrew, 2026-11-14 11:16): "lets make sure the connection
#    web that should be over it is dehydrated like it is and that it will be
#    there and working when we get the new kg into the warp." BUILD_LOG 1638c.
# ============================================================================
"""The connection web (state/webs/webs.sqlite3) kept as columns over one word table, and given back from it."""
from __future__ import annotations

import os
import sqlite3
import sys
import time
from pathlib import Path

from warp2.corpus.columns import Columns, pack_block
from warp2.corpus.convert.memory import free_bytes
from warp2.corpus.table import Words, column_back, column_of, same_values
from warp2.record.kept_file import read_kept, write_kept
from warp2.util import atomic_write_bytes

KEPT = "kept.json"
WORDS = "words.bin"
ROWID = "rowid"   # Intention: the column name a table's own row number is kept under, when it has no column for it


def source_of(state) -> Path:
    """Intention: the connection web's database (warp2/webs/home.py keeps it here)."""
    return Path(state) / "webs" / "webs.sqlite3"


def home_of(state) -> Path:
    """Intention: where the connection web's corpus form lives."""
    return Path(state) / "corpus" / "webs"


def kept_now(state) -> dict:
    """Intention: what the picture now kept holds - {} when there is none."""
    return read_kept(home_of(state) / "now" / KEPT, dict)


def _copied(source: Path, say) -> Path:
    """Intention: the database copied whole as it stands, by SQLite's own backup, to a working file of this run."""
    from warp2.record.stop import runtime_dir
    copy = runtime_dir() / "corpus" / f"webs-reading-{os.getpid()}.sqlite3"
    copy.parent.mkdir(parents=True, exist_ok=True)
    reading = sqlite3.connect(f"file:{source.as_posix()}?mode=ro", uri=True, timeout=60)
    writing = sqlite3.connect(str(copy))
    try:
        reading.backup(writing)
    finally:
        writing.close()
        reading.close()
    say(f"webs: copied as it stands ({copy.stat().st_size:,} bytes)")
    return copy


def _tables(con) -> list:
    """Intention: [(table, its columns, whether its row number is kept as a column, the columns it is ordered by)] -
    the `name` table first (every name the held tables point at), then the rest as the database made them."""
    out = []
    for (table,) in con.execute("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY rowid"):
        if table.startswith("sqlite_stat"):
            continue  # Intention: what ANALYZE counted - worked out again by the database, not a thing it holds
        info = list(con.execute(f'PRAGMA table_info("{table}")'))
        names = [row[1] for row in info]
        keys = [row[1] for row in sorted(info, key=lambda row: row[5]) if row[5]]
        without_rowid = "WITHOUT ROWID" in (con.execute("SELECT sql FROM sqlite_master WHERE name = ?",
                                                         (table,)).fetchone()[0] or "").upper()
        own_rowid = len(keys) == 1 and [row[2].upper() for row in info if row[1] == keys[0]] == ["INTEGER"]
        if without_rowid or own_rowid:
            out.append((table, names, False, keys))
        elif table == "sqlite_sequence":
            out.append((table, names, False, ["name"]))
        else:
            out.append((table, [ROWID] + names, True, [ROWID]))
    # Intention: `name` first (every name the held tables point at); sqlite_sequence last, so the counters it keeps
    # are set after every row is back.
    return sorted(out, key=lambda entry: (entry[0] == "sqlite_sequence", entry[0] != "name"))


def _bytes_a_row(rows: list, columns: int) -> int:
    """Intention: what a row of this table takes while its block is made - the rows read, the same again as the
    columns given back to check them, and four arrays of 8-byte numbers a column - measured on rows in hand."""
    sample = rows[0] if rows else ()
    size = sys.getsizeof(sample) + sum(sys.getsizeof(value) for value in sample)
    return 2 * size + 4 * 8 * max(1, columns)


def _pages(con, table: str, names: list, rowid: bool, keys: list):
    """Intention: the table's rows, a block at a time in key order, each block as many rows as half the free
    memory holds now (measured on the first row)."""
    shown = ", ".join(("rowid" if name == ROWID and rowid else f'"{name}"') for name in names)
    ordered = ["rowid" if key == ROWID else f'"{key}"' for key in keys]
    order = ", ".join(ordered)
    after = f"{ordered[0]} > ?" if len(ordered) == 1 else f"({order}) > ({', '.join('?' * len(ordered))})"
    first = con.execute(f'SELECT {shown} FROM "{table}" ORDER BY {order} LIMIT 1').fetchall()
    if not first:
        return
    per_row = _bytes_a_row(first, len(names))
    places = [names.index(key) for key in keys]
    at = None
    while True:
        many = max(1, free_bytes() // 2 // per_row)
        rows = (con.execute(f'SELECT {shown} FROM "{table}" ORDER BY {order} LIMIT ?', (many,)) if at is None else
                con.execute(f'SELECT {shown} FROM "{table}" WHERE {after} ORDER BY {order} LIMIT ?',
                            (*at, many))).fetchall()
        if not rows:
            return
        yield rows
        at = [rows[-1][place] for place in places]


def block_of(table: str, names: list, rows: list, words: Words) -> tuple:
    """Intention: (the packed block, its columns' values) - every column of the rows numbered, packed with a head
    that says how each is kept."""
    values = {name: [row[place] for row in rows] for place, name in enumerate(names)}
    sections, hows = {}, {}
    for name in names:
        made, how = column_of(name, values[name], words)
        sections.update(made)
        hows[name] = how
    raw = pack_block(sections, [], {"table": table, "names": names, "rows": len(rows), "columns": hows})
    return raw, values


def values_of(raw: bytes, words: list) -> dict:
    """Intention: {column: its values} of a packed block - `words` the shared word table with None at place 0."""
    block = Columns(raw)
    head = block.head
    return {name: column_back(block, name, head["columns"][name], words, head["rows"]) for name in head["names"]}


def _same(raw: bytes, values: dict, words: list) -> bool:
    """Intention: whether a packed block gives back every value of every column, as the same type."""
    back = values_of(raw, words)
    return list(back) == list(values) and all(same_values(back[name], values[name]) for name in values)


def keep_webs(state, say=print) -> dict:
    """Intention: the connection web kept in corpus form, every row read back the same - unless the picture kept
    already is of the database as it is now."""
    state = Path(state)
    source = source_of(state)
    if not source.is_file():
        return {"did": "nothing", "why": "there is no connection web yet"}
    now = home_of(state) / "now"
    stat = source.stat()
    kept = kept_now(state)
    if kept.get("db_bytes") == stat.st_size and kept.get("db_mtime_ns") == stat.st_mtime_ns:
        return {"did": "already kept", "bytes": kept.get("bytes", 0), "db_bytes": stat.st_size}
    began = time.time()
    making = home_of(state) / f"making-{os.getpid()}"
    making.mkdir(parents=True, exist_ok=True)
    copy = _copied(source, say)
    con = sqlite3.connect(f"file:{copy.as_posix()}?mode=ro", uri=True)
    words = Words()
    done = {"at": time.strftime("%Y-%m-%d %H:%M:%S"), "db_bytes": stat.st_size, "db_mtime_ns": stat.st_mtime_ns,
            "db_pages": con.execute("PRAGMA page_count").fetchone()[0],
            "db_free_pages": con.execute("PRAGMA freelist_count").fetchone()[0],
            "page_size": con.execute("PRAGMA page_size").fetchone()[0],
            "schema": [list(row) for row in con.execute("SELECT type, name, tbl_name, sql FROM sqlite_master "
                                                         "ORDER BY rowid")],
            "tables": {}}
    try:
        for table, names, rowid, keys in _tables(con):
            entry = done["tables"][table] = {"names": names, "rowid": rowid, "blocks": [], "rows": 0, "bytes": 0}
            for rows in _pages(con, table, names, rowid, keys):
                raw, values = block_of(table, names, rows, words)
                if not _same(raw, values, [None] + words.texts):
                    raise ValueError(f"webs: a block of {table} did not read back the same")
                name = f"{table}-{len(entry['blocks']) + 1:04d}.bin"
                atomic_write_bytes(making / name, raw)
                entry["blocks"].append(name)
                entry["rows"] += len(rows)
                entry["bytes"] += len(raw)
                say(f"webs: {name} - {len(rows):,} rows in {len(raw):,} bytes, every value read back the same")
    finally:
        con.close()
        copy.unlink()  # Intention: the working copy this run made for itself - not a thing the warp keeps
    raw = pack_block({}, words.texts, {"words_of": "the connection web"})
    if Columns(raw).words() != words.texts:
        raise ValueError("webs: the word table did not read back the same")
    atomic_write_bytes(making / WORDS, raw)
    done["words"] = {"count": len(words.texts), "bytes": len(raw)}
    done["bytes"] = len(raw) + sum(entry["bytes"] for entry in done["tables"].values())
    done["rows"] = sum(entry["rows"] for entry in done["tables"].values())
    done["seconds"] = round(time.time() - began, 1)
    write_kept(making / KEPT, done, indent=1)
    if now.is_dir():
        older = home_of(state) / "older" / kept.get("at", "before").replace(":", "-").replace(" ", "_")
        older.parent.mkdir(parents=True, exist_ok=True)
        os.replace(now, older)
    os.replace(making, now)
    say(f"webs: {done['rows']:,} rows of {len(done['tables'])} tables and {len(words.texts):,} words - "
        f"{stat.st_size:,} bytes as a database, {done['bytes']:,} in corpus form ({done['seconds']} s)")
    return {key: value for key, value in done.items() if key != "schema"}


def give_back(state, target=None, say=print) -> Path:
    """Intention: the connection web made again from its corpus form, row for row, at `target` (its own place when
    none is given) - never over a database that is there."""
    state = Path(state)
    now = home_of(state) / "now"
    kept = read_kept(now / KEPT, dict)
    if not kept:
        raise FileNotFoundError(f"no connection web is kept in corpus form under {now}")
    target = Path(target) if target else source_of(state)
    if target.exists():
        raise FileExistsError(f"{target} is there - the connection web is not given back over it")
    target.parent.mkdir(parents=True, exist_ok=True)
    words = [None] + Columns((now / WORDS).read_bytes()).words()
    making = target.with_name(target.name + f".making-{os.getpid()}")
    con = sqlite3.connect(str(making))
    try:
        later = []
        for kind, name, _table, sql in kept["schema"]:
            if not sql:
                continue  # Intention: an index SQLite makes for itself (a key or a unique column) comes with its table
            if kind == "table" and not name.startswith("sqlite_"):
                con.execute(sql)
            elif kind != "table":
                later.append(sql)
        for table, entry in kept["tables"].items():
            columns = ", ".join(("rowid" if name == ROWID and entry["rowid"] else f'"{name}"')
                                for name in entry["names"])
            marks = ", ".join("?" * len(entry["names"]))
            if table == "sqlite_sequence":
                # Intention: the counters of tables that never reuse a row number - set as they were kept, after
                # the rows put back above moved them.
                con.execute("DELETE FROM sqlite_sequence")
            for block in entry["blocks"]:
                values = values_of((now / block).read_bytes(), words)
                con.executemany(f'INSERT INTO "{table}" ({columns}) VALUES ({marks})', zip(*values.values()))
        for sql in later:
            con.execute(sql)
        con.commit()
    finally:
        con.close()
    try:
        # Intention: put in place only where nothing is - a link made where a file already is fails, so a second
        # opener that gave the webs back at the same moment never lays its copy over one already in use.
        os.link(making, target)
    except FileExistsError:
        say(f"webs: {target} was given back by another opener first")
    making.unlink()  # Intention: this run's own making copy - the webs are in place under their name
    say(f"webs: given back from corpus form - {kept.get('rows', 0):,} rows into {target}")
    return target
