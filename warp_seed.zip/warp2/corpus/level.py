# WARP2/warp2/corpus/level.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/level.py
#  Used by   : warp2/corpus/{levels,corpus}.py; warp2/corpus/tests/.
#  Uses      : warp2/corpus/{grammar,fold,varint,expand}.py; numpy.
#  Description:
#    ONE LEVEL OF A CORPUS. From the notations of many things: every value
#    that stands in them becomes a base tag (once); repeats are lifted into
#    higher tags while the whole gets smaller (grammar.py) and the ones that
#    stop paying are folded back (fold.py); then every tag gets its number
#    by how often it is used - the most used get the numbers that take one
#    byte, the next the ones that take two, and so on (the exact cost of a
#    number is the bytes it takes, so only which of those bands a tag falls
#    in matters). Inside a band the base tags come first in the order of
#    their values (so their values can be kept as small steps), then the
#    higher tags.
#    A Level holds: the base tags' values in number order, how many base
#    and higher tags each band has, each higher tag's parts, and the
#    notations in the new numbers. `read` gives a notation back as values.
#  User intention (Andrew, 2026-11-13 20:49-20:56): "a corpus of tags ...
#    will hold the bigger information"; "more and more compressed
#    notation"; the corpus "kept like this with its own corpus". BUILD_LOG 1621c.
# ============================================================================
"""A corpus level: base tags, higher tags by use, and notations in those numbers."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from warp2.corpus.expand import expand
from warp2.corpus.fold import fold
from warp2.corpus.grammar import lift
from warp2.corpus.varint import lengths


@dataclass
class Level:
    """Intention: one level - base values, band table, higher tags' parts, and the notations laid out with gaps."""
    values: np.ndarray        # base tags' values, in number order
    bands: np.ndarray         # rows of (base tags, higher tags), band by band
    offsets: np.ndarray       # higher tag i (in number order) is made of flat[offsets[i]:offsets[i + 1]]
    flat: np.ndarray
    laid: np.ndarray          # the notations in tag numbers, a gap after each

    def kinds(self) -> tuple:
        """Intention: (which numbers are higher tags, each number's row - its base value's place or its parts' row)."""
        return kinds_of(self.bands)

    def read(self, notation) -> np.ndarray:
        """Intention: a notation in tag numbers back as the values it stands for."""
        higher, row = self.kinds()
        opened = expand(notation, higher, self.offsets, self.flat, row)
        return self.values[row[opened]]


def kinds_of(bands: np.ndarray) -> tuple:
    """Intention: from the band table, which numbers are higher tags and each number's row among its kind."""
    bands = np.asarray(bands, dtype=np.int64).reshape(-1, 2)
    is_higher = np.concatenate([np.repeat([False, True], pair) for pair in bands]) if bands.size else np.zeros(0, bool)
    row = np.zeros(is_higher.size, dtype=np.int64)
    row[~is_higher] = np.arange(int((~is_higher).sum()))
    row[is_higher] = np.arange(int(is_higher.sum()))
    return is_higher.astype(bool), row


def make(laid: np.ndarray, say=None) -> Level:
    """Intention: a level from notations laid end to end with a gap after each (values not negative)."""
    laid = np.asarray(laid, dtype=np.int64)
    present = laid >= 0
    values, inverse = np.unique(laid[present], return_inverse=True)
    dense = laid.copy()
    dense[present] = inverse
    base = values.size
    lifted, parts = lift(dense, base, say)
    lifted, offsets, flat, live = fold(lifted, parts, base)
    return _numbered(values, lifted, offsets, flat, live)


def _numbered(values, lifted, offsets, flat, live) -> Level:
    """Intention: every tag numbered by how much it is used, in bands of the bytes its number takes."""
    base, count = values.size, live.size
    total = base + count
    alive = np.concatenate([np.ones(base, dtype=bool), live])
    width = offsets[1:] - offsets[:-1]
    standing = np.concatenate([lifted[lifted >= 0], flat[np.repeat(live, width)]])
    uses = np.bincount(standing, minlength=total)
    ids = np.flatnonzero(alive)
    by_use = ids[np.argsort(-uses[ids], kind="stable")]
    band = np.zeros(total, dtype=np.int64)
    band[by_use] = lengths(np.arange(ids.size))
    higher = np.arange(total) >= base
    order = ids[np.lexsort((ids, higher[ids], band[ids]))]
    new = np.full(total, -1, dtype=np.int64)
    new[order] = np.arange(order.size)
    out = lifted.copy()
    out[lifted >= 0] = new[lifted[lifted >= 0]]
    rules = order[higher[order]] - base
    new_width = width[rules]
    new_offsets = np.concatenate([[0], np.cumsum(new_width)]).astype(np.int64)
    take = np.repeat(offsets[rules], new_width) + (np.arange(int(new_width.sum())) - np.repeat(new_offsets[:-1], new_width))
    new_flat = new[flat[take]] if take.size else np.zeros(0, dtype=np.int64)
    kept_values = values[order[~higher[order]]]
    bands = []
    for each in np.unique(band[order]):
        inside = order[band[order] == each]
        bands.append((int((~higher[inside]).sum()), int(higher[inside].sum())))
    return Level(kept_values, np.asarray(bands, dtype=np.int64).reshape(-1, 2), new_offsets, new_flat, out)
