# WARP2/warp2/corpus/fold.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/fold.py
#  Used by   : warp2/corpus/corpus.py; warp2/corpus/tests/.
#  Uses      : warp2/corpus/{varint,expand}.py; numpy.
#  Description:
#    A TAG THAT STOPS PAYING IS FOLDED BACK. After the repeats are lifted,
#    some higher tags end up used once (a later tag swallowed every place
#    they stood) or so seldom that holding them costs the corpus more than
#    they save. Such a tag is put back by its parts wherever it stands - in
#    the notations and in the tags made of it - so higher tags can be made
#    of more than two parts. Worked out again after every fold, since a
#    fold changes how often the parts are used; a tag is folded before the
#    tags made of it are judged; it stops when every tag left pays for
#    itself.
#  User intention (Andrew, 2026-11-13; design doc rule): a tag enters "only
#    when the whole gets smaller ... a tag that stops paying is folded back
#    into its parts." BUILD_LOG 1621c.
# ============================================================================
"""Higher tags that do not pay for themselves put back by their parts."""
from __future__ import annotations

import numpy as np

from warp2.corpus.expand import expand
from warp2.corpus.varint import lengths


def _csr(parts: np.ndarray) -> tuple:
    """Intention: pairs of parts as (offsets, flat) - every higher tag's parts in one array."""
    flat = parts.reshape(-1).astype(np.int64)
    offsets = np.arange(0, flat.size + 1, 2, dtype=np.int64) if parts.size else np.zeros(1, dtype=np.int64)
    return offsets, flat


def fold(sequence: np.ndarray, parts: np.ndarray, first: int) -> tuple:
    """Intention: (sequence, offsets, flat, live) after every tag that does not pay is folded back. Tag first + i is
    made of flat[offsets[i]:offsets[i + 1]]; `live` says which of them are still in the corpus."""
    offsets, flat = _csr(parts)
    count = offsets.size - 1
    live = np.ones(count, dtype=bool)
    row = np.arange(first + count, dtype=np.int64) - first
    while count:
        used = _uses(sequence, offsets, flat, live, first, count)
        width = offsets[1:] - offsets[:-1]
        running = np.concatenate([[0], np.cumsum(lengths(flat))])
        held = running[offsets[1:]] - running[offsets[:-1]]
        own = lengths(np.arange(first, first + count))
        costs = held + lengths(width)
        letting_go = live & (used * (held - own) <= costs)
        if not letting_go.any():
            break
        letting_go &= ~_holds_one_of(letting_go, offsets, flat, first)
        which = np.zeros(first + count, dtype=bool)
        which[first:] = letting_go
        sequence = expand(sequence, which, offsets, flat, row)
        offsets, flat = _rebuilt(offsets, flat, live & ~letting_go, which, row)
        live &= ~letting_go
    return sequence, offsets, flat, live


def _holds_one_of(marked, offsets, flat, first: int) -> np.ndarray:
    """Intention: which tags hold, among their parts, a tag that is also marked to be let go. Folding a tag and the
    tags inside it at once would judge each as if the other stayed, so the inner ones go first and the outer ones
    are judged again after (a chain of tags each used twice inside the next keeps its upper links this way)."""
    inner = np.concatenate([[False, ], marked])[np.where(flat >= first, flat - first + 1, 0)]
    running = np.concatenate([[0], np.cumsum(inner)])
    return (running[offsets[1:]] - running[offsets[:-1]]) > 0


def _uses(sequence, offsets, flat, live, first: int, count: int) -> np.ndarray:
    """Intention: how many places each higher tag stands in - in the notations and in the live tags made of it."""
    width = offsets[1:] - offsets[:-1]
    in_live = np.repeat(live, width)
    standing = np.concatenate([sequence[sequence >= first], flat[in_live][flat[in_live] >= first]]) - first
    return np.bincount(standing, minlength=count)


def _rebuilt(offsets, flat, keep, which, row) -> tuple:
    """Intention: every kept tag's parts with the tags being let go opened into theirs; the ones let go left empty.
    All tags at once: their parts laid end to end with a gap after each, opened, and cut apart at the gaps."""
    count = offsets.size - 1
    width = np.where(keep, offsets[1:] - offsets[:-1], 0)
    laid = np.full(int(width.sum()) + count, -1, dtype=np.int64)
    begins = np.cumsum(width + 1) - (width + 1)
    taken = np.repeat(keep, offsets[1:] - offsets[:-1])
    laid[np.repeat(begins, width) + (np.arange(int(width.sum())) - np.repeat(np.cumsum(width) - width, width))] = flat[taken]
    opened = expand(laid, which, offsets, flat, row)
    ends = np.flatnonzero(opened < 0)
    new_offsets = np.concatenate([[0], ends - np.arange(count)]).astype(np.int64)
    return new_offsets, opened[opened >= 0]
