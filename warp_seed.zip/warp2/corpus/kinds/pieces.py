# WARP3/warp2/corpus/kinds/pieces.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/pieces.py
#  Used by   : warp2/corpus/kinds/{way,lanes,png}.py (the inner coder of the ways that keep new files);
#              projects/behemoth_eye/eye/turn_clock.py is read for the time left; tests/.
#  Uses      : warp2/pieces_book/one_file.py (keep_one, back_one - the pieces book: the warp's own compression,
#              the system built with the number mine and the vault); projects/behemoth_eye/eye/turn_clock.py
#              (current - the seconds left of the turn this runs in); (stdlib) math.
#  Description:
#    ANY PART OF A FILE KEPT BY THE WARP'S OWN COMPRESSION, AND GIVEN BACK. The inner coder the keeper's ways use
#    in place of LZMA: a part goes through the pieces book and is kept in its form only when that comes out
#    smaller than the part; otherwise the part is kept as it is. One byte in front says which: 0 as it is, 1 the
#    pieces book's form (which carries its own sha256 and is checked when read back). So nothing kept this way is
#    ever bigger than what it was given, by more than that one byte. The pieces book's miner is given the seconds
#    left of the turn it runs in; with no turn it stops by its own rule (when a wider look finds nothing new).
#    Way 6 is the whole file kept this way; the lanes and picture ways use the same coder under their own new
#    numbers (lanes.py, png.py). The old xz ways stay known so what they kept is still read back.
#  User intention (Andrew, 2026-11-19 22:31): "we should not be using zip anywhere we should be using the warps own
#    compression system"; (22:39) every other place that uses zip-style compression moved to the warp's own;
#    (23:31) "it should not be possible for the warp's internal compressor to produce a file bigger than what it was
#    given", and the compressor he means is "the system built with the number mine that breaks things down into
#    functions and uses the vault". (2026-11-21) WARP3 carry item A2.
# ============================================================================
"""Any part of a file kept by the pieces book (the warp's own compression) when that is smaller, and given back."""
from __future__ import annotations

import math

from warp2.pieces_book.one_file import back_one, keep_one

# Intention: the one byte in front of every kept part - fixed, as every kept part says which it is by it.
AS_IT_IS, PIECES = 0, 1


def seconds_left() -> float:
    """Intention: the seconds left of the turn this runs inside (the miner is given them); with no turn or no end
    set, no end here either - the miner then stops by its own rule."""
    from projects.behemoth_eye.eye.turn_clock import current as clock
    left = clock().left() if clock() is not None else None
    return math.inf if left is None else max(float(left), 0.0)


def squeezed(raw) -> bytes:
    """Intention: a part kept by the pieces book when its form is smaller than the part, else the part as it is -
    so a kept part is never bigger than the part by more than its one byte. An empty part is kept as it is (the
    pieces book has nothing to cut)."""
    raw = bytes(raw)
    if raw:
        kept = keep_one(raw, seconds_left())
        if len(kept) < len(raw):
            return bytes([PIECES]) + kept
    return bytes([AS_IT_IS]) + raw


def opened(body) -> bytes:
    """Intention: what `squeezed` kept, given back; the pieces book checks its own sha256 as it reads; a first byte
    that is neither is said, never guessed at."""
    body = bytes(body)
    if not body:
        raise ValueError("a kept part has no first byte to say how it was kept")
    if body[0] == AS_IT_IS:
        return body[1:]
    if body[0] == PIECES:
        return back_one(body[1:])
    raise ValueError(f"a kept part starts with {body[0]}: this was kept by newer code")


class Pieces:
    """Intention: way 6 - the whole file kept by the pieces book (any kind of file; whether it is smaller than the
    file is the chooser's to say, as for every way)."""

    number = 6
    name = "pieces"

    def keep(self, raw, hints: dict) -> tuple | None:
        """Intention: the file through the warp's own compression; it fits every file."""
        return squeezed(raw), {}

    def back(self, body) -> bytes:
        """Intention: the file's bytes again."""
        return opened(body)
