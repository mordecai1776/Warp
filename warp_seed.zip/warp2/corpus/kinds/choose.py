# WARP3/warp2/corpus/kinds/choose.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/choose.py
#  Used by   : warp2/corpus/kinds/keep.py; projects/behemoth_eye/eye/held_small/
#              forms.py (Picture - learned while its process runs); tests/.
#  Uses      : warp2/record/kept_file.py (read_kept, write_kept); (stdlib)
#              random.
#  Description:
#    WHAT WAS LEARNED ABOUT EACH KIND OF FILE, AND THE ORDER IT GIVES. For
#    every kind (its ending and its first bytes, keep.py kind_of) and every
#    way, how often the way was tried and how often it came out smallest;
#    the bytes in and out and the seconds, for the kind as a whole; and the
#    choices inside a way (which recipe made a picture's stream, which form
#    kept its picture). Nothing is set: each way's chance of coming out
#    smallest for the kind is drawn from what was seen (Thompson sampling -
#    a Beta of its wins and losses), the ways are tried in the order drawn,
#    the first always, each other with the chance drawn for it. A new kind
#    has every way tried about half the time; a way that never wins for a
#    kind comes to be tried less and less, never never. The kind's measured
#    seconds a byte say how long a file of it will take (keep.py leaves a
#    file for the next turn when this turn has not the time) and its bytes
#    saved a second say which kinds go first.
#    Kept in state/corpus/kinds/learned.json.
#  User intention (Andrew, project rule "Adaptive": instead of hard limits a
#    design that makes the limit unneeded; 2026-11-14 23:42: "adapt it to
#    everything"). BUILD_LOG 1652c.
# ============================================================================
"""What was learned of each kind of file - which way wins, how long it takes - and the order of ways it gives."""
from __future__ import annotations

import random
from pathlib import Path

from warp2.record.kept_file import read_kept, write_kept


class Learned:
    """Intention: the tallies of every kind, read once and written back when a turn ends."""

    def __init__(self, path, rng: random.Random | None = None) -> None:
        """Intention: where the tallies live (None: kept only while this process runs - the tensor books' picture
        form learns that way); `rng` draws the chances (a seeded one in tests)."""
        self.path = Path(path) if path is not None else None
        self.rng = rng or random.Random()
        self.table = read_kept(self.path, dict) if self.path is not None else {}
        if not isinstance(self.table, dict):
            self.table = {}

    def _kind(self, kind: str) -> dict:
        """Intention: one kind's tallies, made empty the first time it is seen."""
        return self.table.setdefault(kind, {"ways": {}, "files": 0, "in": 0, "out": 0, "seconds": 0.0, "choices": {}})

    def _drawn(self, tally: dict) -> float:
        """Intention: a chance of winning drawn from a tally's wins and losses."""
        tried, won = int(tally.get("tried", 0)), int(tally.get("won", 0))
        return self.rng.betavariate(1 + won, 1 + tried - won)

    def order(self, kind: str, numbers) -> list:
        """Intention: (way number, whether to try it) in the order drawn - the first is always tried (and the keeper
        goes on down the order while none has fitted the file)."""
        ways = self._kind(kind)["ways"]
        drawn = sorted(((self._drawn(ways.get(str(number), {})), number) for number in numbers), reverse=True)
        return [(number, at == 0 or self.rng.random() < chance) for at, (chance, number) in enumerate(drawn)]

    def hints(self, kind: str) -> dict:
        """Intention: what a way is told for this kind - the recipes that matched, most often first, and the picture
        forms in the order drawn, each beyond the first kept only with the chance drawn for it."""
        choices = self._kind(kind)["choices"]
        recipes = choices.get("recipe", {})
        forms = choices.get("form", {})
        drawn = sorted(((self._drawn(forms.get(name, {})), name) for name in ("webp", "rows")), reverse=True)
        # Intention (1653c): a form never yet compared is always tried - with nothing seen, a draw alone left a fresh
        # process keeping a quarter of its photographs by their rows, far bigger than their pixels.
        tried = [name for at, (chance, name) in enumerate(drawn)
                 if at == 0 or not forms.get(name, {}).get("tried") or self.rng.random() < chance]
        return {"recipes": sorted(recipes, key=lambda key: -int(recipes[key].get("won", 0))), "forms": tried}

    def noted(self, kind: str, tried: dict, winner, size: int, seconds: float, used: dict) -> None:
        """Intention: one file's keeping counted - `tried` {way number: bytes out, or None when it did not fit}, the
        winning way (None when no way was smaller than the file), the file's size, the seconds it all took, and what
        each way that ran used inside it ({way number: {"recipe": ..., "form": ..., "forms_tried": [...]}})."""
        tallies = self._kind(kind)
        for number in tried:
            way = tallies["ways"].setdefault(str(number), {"tried": 0, "won": 0})
            way["tried"] += 1
            way["won"] += int(number == winner)
        tallies["files"] += 1
        tallies["in"] += int(size)
        tallies["out"] += int(tried[winner]) if winner is not None else int(size)
        tallies["seconds"] += float(seconds)
        for inside in (used or {}).values():
            self._choices(tallies["choices"], inside)

    def _choices(self, choices: dict, inside: dict) -> None:
        """Intention: the choices one way made inside counted - the recipe that made a stream (each match a win), and,
        when more than one picture form could be made, which came out smallest. A picture only one form fits (a
        16-bit depth has no WebP form) says nothing about which is smaller, so it is not counted (measured
        2026-11-15: counted, the depths taught the photographs to try their rows first, and those came out at 0.88
        of the file against about 0.6 for their pixels)."""
        if inside.get("recipe"):
            tally = choices.setdefault("recipe", {}).setdefault(inside["recipe"], {"tried": 0, "won": 0})
            tally["tried"] += 1
            tally["won"] += 1
        made = inside.get("forms_tried", [])
        for form in (made if len(made) > 1 else []):
            tally = choices.setdefault("form", {}).setdefault(form, {"tried": 0, "won": 0})
            tally["tried"] += 1
            tally["won"] += int(form == inside.get("form"))

    def seconds_for(self, kind: str, size: int) -> float:
        """Intention: how long a file of this kind and size is expected to take - its kind's seconds a byte so far;
        nought for a kind not seen yet (it is tried, and then known)."""
        tallies = self._kind(kind)
        return float(tallies["seconds"]) * int(size) / tallies["in"] if tallies["in"] else 0.0

    def saved_a_second(self, kind: str) -> float:
        """Intention: the bytes this kind has saved for each second spent on it - which kinds go first; a kind not
        seen yet comes before every other (it has to be tried to be known)."""
        tallies = self._kind(kind)
        if not tallies["files"]:
            return float("inf")
        return (tallies["in"] - tallies["out"]) / max(1e-9, tallies["seconds"])

    def save(self) -> None:
        """Intention: the tallies written back, whole, through the tree's one writer of kept files (when they have a
        file)."""
        if self.path is not None:
            write_kept(self.path, self.table, indent=1)
