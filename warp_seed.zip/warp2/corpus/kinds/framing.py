# WARP3/warp2/corpus/kinds/framing.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/framing.py
#  Used by   : warp2/corpus/kinds/{lanes,png,png_chunks}.py.
#  Uses      : warp2/corpus/varint.py (pack, first).
#  Description:
#    PIECES OF BYTES WRITTEN ONE AFTER ANOTHER, EACH WITH ITS LENGTH IN FRONT
#    (a varint), and read back in the same order. Every kept form in this
#    package is a few such pieces, so none of them needs a layout of its own.
#  User intention (Andrew, 2026-11-14 17:06): "for storage we should store the
#    file as a binary" - kept forms are bytes, never text. BUILD_LOG 1652c.
# ============================================================================
"""Pieces of bytes, each with its length in front, joined and taken apart again."""
from __future__ import annotations

from warp2.corpus.varint import first, pack


def joined(pieces) -> bytes:
    """Intention: the pieces one after another, each led by its length - read back by `apart`."""
    return b"".join(pack([len(piece)]) + bytes(piece) for piece in pieces)


def apart(raw) -> list:
    """Intention: the pieces `joined` wrote, in order; an end in the middle of a piece is an error, never a guess."""
    view = memoryview(raw).cast("B")
    pieces, at = [], 0
    while at < len(view):
        length, used = first(view[at:])
        at += used
        if at + length > len(view):
            raise ValueError("a kept form ends inside one of its pieces")
        pieces.append(bytes(view[at:at + length]))
        at += length
    return pieces
