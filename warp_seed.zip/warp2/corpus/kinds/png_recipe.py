# WARP3/warp2/corpus/kinds/png_recipe.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/png_recipe.py
#  Used by   : warp2/corpus/kinds/png.py.
#  Uses      : warp2/corpus/kinds/png_chunks.py; Pillow (the pictures the
#              warp writes itself); (stdlib) io, zlib.
#  Description:
#    HOW A PNG'S STREAM WAS MADE, FOUND - so the very stream can be made
#    again from the rows. A deflate stream is not set by what it holds: the
#    program that wrote it chose a level, a strategy, a window and a memory
#    size, and each choice gives other bytes. Two kinds of recipe:
#      ZLIB  the rows through zlib with (level, strategy, memory, window).
#            Measured on the warp's pictures (2026-11-15): the hypersim
#            pictures and depths were written at level 1 with the RLE
#            strategy (OpenCV's own setting); flickr2k and div2k at level 6
#            with the filtered strategy. The window is read from the
#            stream's own first byte, and its second byte says which band
#            of levels and strategies was used - only those are tried.
#      PIL   the picture saved by Pillow at a level (Pillow packs with its
#            own zlib-ng and chooses its own filters) - the pictures the
#            warp took in itself (curated_media, the "online" ones).
#    The recipes that matched before are tried first (choose.py hands them
#    in): one try for a picture from a known source. A wrong recipe is found
#    wrong at its first block (the stream it makes is compared as it comes),
#    so a picture no recipe makes costs about a block a try (and Pillow is
#    tried only at the levels of the band the stream names). Each recipe
#    says which library made it; the stream it makes is compared with the
#    one kept before anything counts.
#  User intention (Andrew, 2026-11-14 15:59): "Any alterations that can be
#    made to anything in the generation any thing ... The only things that
#    matter are storage space and time to generate from storage." 23:42:
#    "adapt it to everything". BUILD_LOG 1652c.
# ============================================================================
"""How a PNG's stream was made - zlib's settings, or Pillow's level - found, and the stream made again from it."""
from __future__ import annotations

import io
import zlib

import numpy as np

from warp2.corpus.kinds.png_chunks import IDAT, chunks_of

# Intention: the levels in each band the stream's second byte names (zlib's FLEVEL), likeliest first.
BANDS = {0: (1, 0), 1: (2, 3, 4, 5), 2: (6,), 3: (9, 7, 8)}
STRATEGIES = (zlib.Z_DEFAULT_STRATEGY, zlib.Z_FILTERED, zlib.Z_RLE, zlib.Z_HUFFMAN_ONLY, zlib.Z_FIXED)
# Intention: the memory settings tried - zlib's own (8, which libpng and OpenCV use) and the largest.
MEMORIES = (8, 9)


def key_of(recipe: tuple) -> str:
    """Intention: a recipe as words - how it is counted when it matches (choose.py) and named in the kept form."""
    return " ".join(str(part) for part in recipe)


def recipe_of(key: str) -> tuple:
    """Intention: a recipe from its words: ("zlib", level, strategy, memory, window) or ("pil", level)."""
    parts = key.split()
    return (parts[0], *[int(part) for part in parts[1:]])


def band_of(level: int, strategy: int) -> int:
    """Intention: the band zlib writes in a stream's second byte for a level and strategy (zlib's own rule: the
    strategies that do not search for repeats, and levels below 2, are band 0)."""
    if strategy >= zlib.Z_HUFFMAN_ONLY or level < 2:
        return 0
    return 1 if level < 6 else (2 if level == 6 else 3)


def zlib_tries(stream: bytes, known: list) -> list:
    """Intention: the zlib recipes this stream can have been made by - only those of the band its own second byte
    names, with the window its first byte names - those that matched before (in `known`, most often first) first.
    A stream zlib did not make costs the band's few recipes (measured 2026-11-15: every recipe, on a 42 MB picture
    Pillow wrote, was most of a minute and a half)."""
    window = (stream[0] >> 4) + 8 if stream else 15
    band = (stream[1] >> 6) if len(stream) > 1 else 2
    levels = list(BANDS[band]) + [level for level in range(zlib.Z_BEST_COMPRESSION + 1) if level not in BANDS[band]]
    every = [("zlib", level, strategy, memory, window) for level in levels for strategy in STRATEGIES
             for memory in MEMORIES if band_of(level, strategy) == band]
    first = [recipe for recipe in (recipe_of(key) for key in known) if recipe in every]
    return first + [recipe for recipe in every if recipe not in first]


def zlib_matches(rows: bytes, stream: bytes, recipe: tuple) -> bool:
    """Intention: whether this recipe makes this very stream - compared as it comes out, so a wrong one is dropped at
    its first block; the rows are fed in 64 steps."""
    _kind, level, strategy, memory, window = recipe
    maker = zlib.compressobj(level, zlib.DEFLATED, window, memory, strategy)
    step, got = len(rows) // 64 + 1, 0
    for at in range(0, len(rows), step):
        out = maker.compress(rows[at:at + step])
        if out:
            if stream[got:got + len(out)] != out:
                return False
            got += len(out)
    out = maker.flush()
    return got + len(out) == len(stream) and stream[got:] == out


def zlib_made(rows: bytes, recipe: tuple) -> bytes:
    """Intention: the stream this recipe makes from these rows."""
    _kind, level, strategy, memory, window = recipe
    maker = zlib.compressobj(level, zlib.DEFLATED, window, memory, strategy)
    return maker.compress(rows) + maker.flush()


def pil_tries(stream: bytes, known: list) -> list:
    """Intention: the Pillow levels this stream can have been made at - only those of the band its second byte names
    (Pillow's zlib-ng writes that byte as zlib does), those that matched before first. A picture Pillow did not write
    costs at most the band's levels, each a whole save (measured 2026-11-15: trying every level took minutes on a
    large picture no level made)."""
    band = (stream[1] >> 6) if len(stream) > 1 else 2
    every = [("pil", level) for level in BANDS[band]]
    first = [recipe for recipe in (recipe_of(key) for key in known) if recipe in every]
    return first + [recipe for recipe in every if recipe not in first]


def pil_matches(pixels: np.ndarray, stream: bytes, recipe: tuple) -> bool:
    """Intention: whether Pillow at this level makes this very stream (the picture saved whole and compared)."""
    return pil_made(pixels, recipe) == stream


def pil_made(pixels: np.ndarray, recipe: tuple) -> bytes:
    """Intention: the stream Pillow writes for these pixels at this level - its IDAT chunks' data, joined."""
    from PIL import Image
    out = io.BytesIO()
    Image.fromarray(np.ascontiguousarray(pixels)).save(out, "PNG", compress_level=int(recipe[1]))
    return b"".join(data for letters, data in chunks_of(out.getvalue()) if letters == IDAT)


def made_by() -> dict:
    """Intention: which libraries a recipe is made again with here - kept with each form, so a stream that comes out
    otherwise on a newer library is known for what it is."""
    from PIL import __version__, features
    return {"zlib": zlib.ZLIB_RUNTIME_VERSION, "pillow": __version__, "pillow_zlib": features.version("zlib") or ""}
