# WARP3/warp2/corpus/kinds/way.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/way.py
#  Used by   : warp2/corpus/kinds/{keep,choose}.py; tests/.
#  Uses      : warp2/corpus/kinds/{xz,lanes,png,pieces}.py (the ways themselves).
#  Description:
#    THE WAYS, BY THEIR NUMBER. A kept form is one byte - the number of the
#    way that made it - and then that way's own body, so a new way is a new
#    number and nothing kept before has to change. Every way has the same
#    two doors: keep(raw, hints) gives (body, what it used) or None when it
#    does not fit the file (a picture way on a file that is not a picture);
#    back(body) gives the very bytes back. A way says nothing about whether
#    it is smaller - the chooser compares (choose.py), and the bytes back are
#    checked against the file's sha256 before anything counts (keep.py).
#    2026-11-21 (WARP3 carry item A2): `ways` knows every way, so all that
#    was ever kept is given back; `keeping_ways` is what new files are kept
#    by - the warp's own compression inside each (pieces.py), no LZMA.
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything";
#    2026-11-14 15:59: "The only things that matter are storage space and time
#    to generate from storage." BUILD_LOG 1652c. 2026-11-19 22:31: "we
#    should not be using zip anywhere we should be using the warps own
#    compression system".
# ============================================================================
"""The ways a file's bytes can be kept, by number: a kept form is the way's number and its body."""
from __future__ import annotations


def ways() -> dict:
    """Intention: every way known, by its number - the numbers are what kept forms say, so they never change. The
    LZMA ways (1-5) are here so what they kept is still given back; new files are kept only by `keeping_ways`."""
    from warp2.corpus.kinds.lanes import Lanes
    from warp2.corpus.kinds.png import Png
    from warp2.corpus.kinds.xz import Xz
    found = [Xz(), Lanes(2), Lanes(4), Lanes(8), Png(), *keeping_found()]
    return {way.number: way for way in found}


def keeping_found() -> list:
    """Intention (2026-11-21, WARP3 carry item A2): the ways new files are kept by - the warp's own compression
    inside every one (pieces.py), no LZMA."""
    from warp2.corpus.kinds.lanes import Lanes
    from warp2.corpus.kinds.pieces import Pieces
    from warp2.corpus.kinds.png import Png
    return [Pieces(), Lanes(2, "pieces"), Lanes(4, "pieces"), Lanes(8, "pieces"), Png("pieces")]


def keeping_ways() -> dict:
    """Intention: the ways new files are kept by, by their number."""
    return {way.number: way for way in keeping_found()}


def kept_form(number: int, body: bytes) -> bytes:
    """Intention: a way's body with the way's number in front - what is written to the packs."""
    return bytes([int(number)]) + bytes(body)


def given_back(kept: bytes, known: dict | None = None) -> bytes:
    """Intention: the bytes a kept form stands for, by the way its first byte names; a number nobody knows is said."""
    known = known if known is not None else ways()
    number = kept[0]
    if number not in known:
        raise KeyError(f"no way {number} is known here: this was kept by newer code")
    return known[number].back(memoryview(kept)[1:])
