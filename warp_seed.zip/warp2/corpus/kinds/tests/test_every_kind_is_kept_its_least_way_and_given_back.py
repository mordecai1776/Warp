# WARP3/warp2/corpus/kinds/tests/test_every_kind_is_kept_its_least_way_and_given_back.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/tests/test_every_kind_is_kept_its_least_way_and_given_back.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/kinds/{way,png,png_chunks,png_filters,choose,
#              packs,keep}.py; warp2/corpus/convert/rest.py;
#              projects/behemoth_eye/eye/held_small/{book,epochs,forms}.py;
#              Pillow; numpy.
#  Description:
#    Every way gives the very bytes back. A PNG is kept as what it is made
#    of and comes back the very file - written by zlib at any setting, by
#    Pillow, 8-bit or 16-bit, with a palette; one whose stream no recipe
#    makes again is not taken. The turn keeps each new file its least way
#    (the pictures smaller, an array in lanes, noise as it is), gives each
#    back, finds nothing new the second time, waits for a file being
#    written over and over to rest, leaves what another book holds, and
#    learns which way wins. The pictures book's form 6 keeps a picture's
#    bytes as its picture and reads back the same.
#  User intention (Andrew, 2026-11-14 23:42): "Then we need to adapt it to
#    adapt it to everything". BUILD_LOG 1652c.
# ============================================================================
"""Every kind kept its least way, and given back the very bytes."""
import io
import os
import random
import zlib

import numpy as np
from PIL import Image

from warp2.corpus.kinds import keep as keep_module
from warp2.corpus.kinds.choose import Learned
from warp2.corpus.kinds.keep import KindsTurn, file_back, packs_of, settled
from warp2.corpus.kinds.png import Png
from warp2.corpus.kinds.png_chunks import made
from warp2.corpus.kinds.png_filters import refiltered
from warp2.corpus.kinds.way import given_back, kept_form, keeping_ways, ways

SEED = 7


def _photo(height: int, width: int, channels: int) -> np.ndarray:
    """Intention: a picture with shapes and a little grain, as a camera gives - not noise, not flat."""
    grain = np.random.default_rng(SEED).normal(0, 3, (height, width))
    y, x = np.mgrid[0:height, 0:width]
    base = np.sin(x / 9.0) * 60 + np.cos(y / 13.0) * 50 + 128 + grain
    picture = np.stack([np.clip(base + 20 * k, 0, 255) for k in range(channels)], axis=-1).astype(np.uint8)
    return picture[..., 0] if channels == 1 else picture


def _by_zlib(rows: np.ndarray, level: int, strategy: int, depth: int = 8, colour: int = 2, step: int = 3) -> bytes:
    """Intention: a PNG written the way other programs write them - each row filtered in turn, packed by zlib at the
    level and strategy given, cut into IDAT chunks of 8 KiB as libpng cuts them."""
    height = rows.shape[0]
    flat = rows.reshape(height, -1).view(np.uint8).reshape(height, -1)
    kinds = np.arange(height, dtype=np.uint8) % 5
    packer = zlib.compressobj(level, zlib.DEFLATED, 15, 8, strategy)
    stream = packer.compress(refiltered(flat, kinds, step)) + packer.flush()
    width = rows.shape[1]
    head = width.to_bytes(4, "big") + height.to_bytes(4, "big") + bytes([depth, colour, 0, 0, 0])
    cut = 8192
    return made([(b"IHDR", head)] + [(b"IDAT", stream[at:at + cut]) for at in range(0, len(stream), cut)] +
                [(b"IEND", b"")])


def _palette(photo: np.ndarray) -> bytes:
    """Intention: a palette PNG as other programs write it - each pixel a number into a table of colours (PLTE), the
    rows packed by zlib. (Pillow's own palette pictures are packed by zlib-ng, whose stream differs from machine to
    machine; they are kept by another way, as they are - measured on Andrew's machine, 2026-11-15.)"""
    numbers = (photo[..., 0] // 16).astype(np.uint8)
    colours = bytes(np.repeat(np.arange(16, dtype=np.uint8) * 16, 3))
    packer = zlib.compressobj(6, zlib.DEFLATED, 15, 8, zlib.Z_FILTERED)
    rows = refiltered(numbers, np.full(numbers.shape[0], 1, np.uint8), 1)
    stream = packer.compress(rows) + packer.flush()
    height, width = numbers.shape
    head = width.to_bytes(4, "big") + height.to_bytes(4, "big") + bytes([8, 3, 0, 0, 0])
    return made([(b"IHDR", head), (b"PLTE", colours), (b"IDAT", stream), (b"IEND", b"")])


def _by_pillow(picture: np.ndarray, **how) -> bytes:
    """Intention: a PNG as Pillow writes it."""
    out = io.BytesIO()
    Image.fromarray(picture).save(out, "PNG", **how)
    return out.getvalue()


def test_every_way_gives_the_very_bytes_back():
    known = ways()
    chance = np.random.default_rng(SEED)
    every_byte, many = 256, 5000
    samples = [b"", b"x", bytes(range(every_byte)) * 9, chance.integers(0, every_byte, many, dtype=np.uint8).tobytes(),
               (chance.standard_normal(3000).astype(np.float32) * 0.02).tobytes() + b"tail"]
    for raw in samples:
        for number, way in known.items():
            got = way.keep(raw, {})
            if got is None:
                continue
            assert given_back(kept_form(number, got[0]), known) == raw, (way.name, len(raw))


def test_a_png_is_kept_as_what_it_is_made_of_and_comes_back_the_very_file():
    photo = _photo(96, 128, 3)
    depth = (_photo(80, 90, 1).astype(">u2") * 257)
    cases = [_by_zlib(photo, 1, zlib.Z_RLE), _by_zlib(photo, 6, zlib.Z_FILTERED),
             _by_zlib(depth, 1, zlib.Z_RLE, depth=16, colour=0, step=2),
             _by_pillow(photo), _by_pillow(_photo(40, 30, 1), compress_level=9),
             _by_pillow(np.dstack([photo, np.full(photo.shape[:2], 128, np.uint8)])), _palette(photo)]
    for raw in cases:
        got = Png().keep(raw, {})
        assert got is not None
        body, used = got
        assert Png().back(body) == raw and used["recipe"] and used["form"] in ("rows", "webp")
    rows_only = Png().keep(cases[2], {})[1]
    assert rows_only["form"] == "rows"


def test_a_picture_made_by_pillow_comes_back_by_pillow_when_no_zlib_setting_makes_it(monkeypatch):
    import warp2.corpus.kinds.png as png_module
    monkeypatch.setattr(png_module, "zlib_tries", lambda _stream, _known: [])
    raw = _by_pillow(_photo(70, 60, 3))
    body, used = Png().keep(raw, {})
    assert used["recipe"].startswith("pil ") and used["form"] == "webp"
    assert Png().back(body) == raw


def test_a_png_whose_stream_no_recipe_makes_is_not_taken():
    rows = refiltered(_photo(60, 50, 3).reshape(60, -1), np.zeros(60, np.uint8), 3)
    packer = zlib.compressobj(6)
    half = len(rows) // 2
    stream = packer.compress(rows[:half]) + packer.flush(zlib.Z_FULL_FLUSH) + packer.compress(rows[half:]) + packer.flush()
    head = (50).to_bytes(4, "big") + (60).to_bytes(4, "big") + bytes([8, 2, 0, 0, 0])
    raw = made([(b"IHDR", head), (b"IDAT", stream), (b"IEND", b"")])
    assert Png().keep(raw, {}) is None
    assert Png().keep(b"not a picture", {}) is None
    assert Png().keep(raw[:-3] + b"bad", {}) is None


def _state(tmp_path) -> tuple:
    """Intention: a state with a picture, an array, noise, and what the text corpus's walk would hand over for them."""
    state = tmp_path / "state"
    files = {"pictures/a.png": _by_zlib(_photo(120, 160, 3), 6, zlib.Z_FILTERED),
             "pictures/depth.png": _by_zlib(_photo(64, 64, 1).astype(">u2") * 257, 1, zlib.Z_RLE, depth=16, colour=0,
                                            step=2),
             "arrays/w.npy": (np.random.default_rng(SEED).standard_normal(20000).astype(np.float32) * 0.02).tobytes(),
             "arrays/noise.bin": np.random.default_rng(SEED).integers(0, 256, 30000, dtype=np.uint8).tobytes()}
    for name, raw in files.items():
        (state / name).parent.mkdir(parents=True, exist_ok=True)
        (state / name).write_bytes(raw)
    return state, files


def keep_kinds(state, files, say, rng) -> dict:
    """Intention: one turn of the kinds over these files, as the warp's turn runs it - kept, then closed."""
    turn = KindsTurn(state, say, rng)
    turn.keep(files)
    return turn.close()


def _handed(state, names) -> list:
    """Intention: the files as the text corpus's walk hands them on: (collection, name, path, write time, size)."""
    out = []
    for name in names:
        path = state / name
        seen = path.stat()
        out.append((name.split("/")[0], name, path, seen.st_mtime_ns, seen.st_size))
    return out


def test_a_turn_keeps_each_new_file_its_least_way_and_a_second_finds_nothing_new(tmp_path, monkeypatch):
    monkeypatch.setattr(keep_module, "held_elsewhere", lambda _state, _path: "")
    state, files = _state(tmp_path)
    done = keep_kinds(state, _handed(state, files), say=lambda _line: None, rng=random.Random(SEED))
    assert done["files"] == 3 and done["own_form_smaller"]["files"] == 1 and done["bytes_now"] < done["bytes_were"]
    for name in ("pictures/a.png", "pictures/depth.png", "arrays/w.npy"):
        assert file_back(state, name) == files[name]
    assert packs_of(state, "arrays").entry("arrays/noise.bin") is None
    again = keep_kinds(state, _handed(state, files), say=lambda _line: None, rng=random.Random(SEED))
    assert again["files"] == 0 and again["held"] == 4
    learned = Learned(state / "corpus" / "kinds" / "learned.json")
    # Intention (WARP3 A2): pictures are now kept by way 10 - the picture way with the warp's own compression inside.
    assert learned.table[".png"]["ways"]["10"]["won"] == 2 and learned.table[".png"]["choices"]["recipe"]
    # Intention (WARP3 A2; Andrew 2026-11-19 22:31: "we should not be using zip anywhere"): every file kept this turn
    # was kept by a way with no LZMA inside.
    for collection in ("pictures", "arrays"):
        for entry in packs_of(state, collection).index().values():
            assert int(entry["way"]) in keeping_ways()


def test_a_file_written_over_and_over_waits_until_it_rests(tmp_path, monkeypatch):
    monkeypatch.setattr(keep_module, "held_elsewhere", lambda _state, _path: "")
    state, files = _state(tmp_path)
    keep_kinds(state, _handed(state, ["arrays/w.npy"]), say=lambda _line: None, rng=random.Random(SEED))
    path = state / "arrays" / "w.npy"
    was = path.stat().st_mtime_ns
    now = was + 10_000_000_000
    path.write_bytes(files["arrays/w.npy"][::-1])
    os.utime(path, ns=(now, now))
    assert not settled(was, now, now + 1_000_000_000) and settled(was, now, now + 10_000_000_000)
    monkeypatch.setattr(keep_module.time, "time_ns", lambda: now + 1_000_000_000)
    waits = keep_kinds(state, _handed(state, ["arrays/w.npy"]), say=lambda _line: None, rng=random.Random(SEED))
    assert waits["still_being_written"] == 1 and waits["files"] == 0
    monkeypatch.setattr(keep_module.time, "time_ns", lambda: now + 20_000_000_000)
    kept = keep_kinds(state, _handed(state, ["arrays/w.npy"]), say=lambda _line: None, rng=random.Random(SEED))
    assert kept["files"] == 1 and file_back(state, "arrays/w.npy") == files["arrays/w.npy"][::-1]


def test_what_another_book_holds_is_left_to_it(tmp_path, monkeypatch):
    monkeypatch.setattr(keep_module, "held_elsewhere",
                        lambda _state, path: "pictures" if path.suffix == ".png" else "")
    state, files = _state(tmp_path)
    done = keep_kinds(state, _handed(state, files), say=lambda _line: None, rng=random.Random(SEED))
    assert done["in_other_books"] == {"pictures": 2} and done["files"] == 1
    monkeypatch.setattr(keep_module, "held_elsewhere", lambda _state, _path: (_ for _ in ()).throw(AssertionError))
    again = keep_kinds(state, _handed(state, files), say=lambda _line: None, rng=random.Random(SEED))
    assert again["in_other_books"] == {"noted before": 2} and again["held"] == 2


def test_a_way_that_always_wins_for_a_kind_comes_to_be_tried_first(tmp_path):
    learned = Learned(None, rng=random.Random(SEED))
    wins, draws = 60, 200
    for _ in range(wins):
        learned.noted(".npy", {1: 90, 3: 70}, 3, 100, 0.01, {})
    firsts = [learned.order(".npy", [1, 3])[0][0] for _ in range(draws)]
    assert firsts.count(3) > 0.9 * draws
    assert learned.saved_a_second(".npy") > 0 and learned.saved_a_second(".new") == float("inf")


def test_the_pictures_book_keeps_a_picture_as_its_picture_and_reads_back_the_same(tmp_path):
    from projects.behemoth_eye.eye.held_small.book import TensorBook
    from projects.behemoth_eye.eye.held_small.epochs import ModelSeparationEpochs
    from projects.behemoth_eye.eye.held_small.forms import Picture
    raw = _by_zlib(_photo(150, 200, 3), 6, zlib.Z_FILTERED)
    values = np.frombuffer(raw, dtype=np.uint8).copy()
    book = TensorBook(tmp_path / "book")
    try:
        place = book.place(values)
        said = ModelSeparationEpochs(book, max_tensors=4, time_budget_s=60.0, room=lambda: 10**9).run_epoch()
        assert said["by_form"][Picture.number] == 1
        assert int(book.where(place[0])[6]) == Picture.number and int(book.where(place[0])[3]) < len(raw)
        assert book.get(place[0]).tobytes() == raw and book.at(place).tobytes() == raw
    finally:
        book.close()


def test_what_lzma_kept_before_is_still_given_back_and_new_files_never_use_it():
    """Intention (WARP3 A2): the LZMA ways are only read back now - a form one of them kept still gives the very bytes,
    and no way new files are kept by is one of them."""
    raw = (np.random.default_rng(SEED).standard_normal(4000).astype(np.float32) * 0.02).tobytes()
    lzma_numbers = {1, 2, 3, 4, 5}
    for number in lzma_numbers - {5}:
        body, _used = ways()[number].keep(raw, {})
        assert given_back(kept_form(number, body)) == raw
    assert not lzma_numbers & set(keeping_ways())


def test_the_warps_own_coder_never_keeps_a_part_bigger_than_it_was_given():
    """Intention (Andrew, 2026-11-19 23:31: "it should not be possible for the warp's internal compressor to produce a
    file bigger than what it was given"): a part that does not come out smaller is kept as it is, with its one byte."""
    from warp2.corpus.kinds.pieces import opened, squeezed
    noise = np.random.default_rng(SEED).integers(0, 256, 3000, dtype=np.uint8).tobytes()
    for raw in (b"", b"a", noise, b"the same words " * 300):
        kept = squeezed(raw)
        assert len(kept) <= len(raw) + 1 and opened(kept) == raw
