# WARP3/warp2/corpus/kinds/tests/test_a_picture_too_wide_for_webp_is_kept_as_rows.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/tests/test_a_picture_too_wide_for_webp_is_kept_as_rows.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/corpus/kinds/png.py, png_pixels.py; Pillow; numpy.
#  Description:
#    WebP holds at most 16383 pixels a side. On 2026-11-25 14:40 UTC one
#    such picture in the Eye's tensor book made Pillow raise ("Image size
#    exceeds WebP limit of 16383 pixels") and ended the whole
#    keep_eye_book_small turn. A picture too big for WebP must be kept as its
#    rows (or left to another way) and never raise; one that fits still goes to WebP.
#  User intention (Andrew, 2026-11-14 23:42): "adapt it to everything".
#    BUILD_LOG 2245.
# ============================================================================
"""A PNG too wide for WebP is kept as its rows, not raised on; one that fits still tries WebP."""
from __future__ import annotations

import io

import numpy as np
from PIL import Image

from warp2.corpus.kinds.png import Png
from warp2.corpus.kinds.png_pixels import WEBP_MOST_SIDE, webp_holds


def _png(height: int, width: int) -> bytes:
    """Intention: a small, real RGB PNG of the given size, made by Pillow."""
    pixels = (np.arange(height * width * 3, dtype=np.uint32) % 251).astype(np.uint8).reshape(height, width, 3)
    out = io.BytesIO()
    Image.fromarray(pixels).save(out, "PNG")
    return out.getvalue()


def test_webp_holds_up_to_its_side_limit_and_no_further():
    """Intention: the limit is libwebp's own, on either side."""
    assert webp_holds(np.zeros((1, WEBP_MOST_SIDE, 3), np.uint8))
    assert not webp_holds(np.zeros((1, WEBP_MOST_SIDE + 1, 3), np.uint8))
    assert not webp_holds(np.zeros((WEBP_MOST_SIDE + 1, 1, 3), np.uint8))


def test_a_picture_too_wide_for_webp_is_kept_as_rows_and_given_back():
    """Intention: no raise. When this PNG's stream can be made again it is kept as rows and the very file comes back;
    when it cannot (the zlib that made it is not one the recipes know - seen on the PC), it is None: kept another way."""
    raw = _png(1, WEBP_MOST_SIDE + 17)
    kept = Png().keep(raw, {})
    if kept is None:
        return
    body, said = kept
    assert said["form"] == "rows"
    assert "webp" not in said["forms_tried"]
    assert Png().back(body) == raw


def test_a_picture_that_fits_still_tries_webp():
    """Intention: the guard changes nothing for pictures WebP holds."""
    raw = _png(32, 32)
    kept = Png().keep(raw, {})
    assert kept is not None
    body, said = kept
    assert "webp" in said["forms_tried"]
    assert Png().back(body) == raw
