# WARP3/warp2/corpus/kinds/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/kinds/tests/__init__.py
#  Used by   : pytest (the package of the kinds' tests).
#  Uses      : nothing.
#  Description:
#    The tests of every kind kept its least way: each way gives the very
#    bytes back, pictures come back as the very files, the turn keeps what
#    is new and learns which way wins.
#  User intention (Andrew, 2026-11-14 23:42): "Then we need to adapt it to
#    adapt it to everything". BUILD_LOG 1652c.
# ============================================================================
