# WARP2/warp2/corpus/tests/test_the_record_leaves_only_its_corpus_in_the_warp.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/tests/test_the_record_leaves_only_its_corpus_in_the_warp.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/convert/kg.py (keep_kg, kg_parts);
#              warp2/tags/dehydrated/small_to_deep.py (send_small);
#              warp2/tags/lane.py (TagLane); warp2/tags/dehydrated/whole_lane.py
#              (WholeLane); warp2/record/journal.py.
#  Description:
#    The record's segments wait in their own small files until they fill a
#    part (what one lift can hold with the memory free now), then go into the
#    KG's corpus together; a segment held the same in the corpus has its own
#    small file sent to deep storage, checked there, and the lane reads every
#    entry the same from the corpus; with no deep storage said nothing leaves;
#    a file that the corpus does not give back the same stays.
#  User intention (Andrew, 2026-11-12 09:38): "The small form of the kg should
#    be the only thing there"; 2026-11-13 20:35: "everything needs to be in
#    and run from a fully dehydrated form." BUILD_LOG 1622c.
# ============================================================================
"""Intention: the corpus becomes the record's only small form in the warp, the files checked into deep storage."""
import json

from warp2.corpus.convert import kg as kg_convert
from warp2.corpus.convert.kg import keep_kg, kg_parts
from warp2.record import journal
from warp2.tags.dehydrated.small_to_deep import send_small
from warp2.tags.dehydrated.whole_lane import WholeLane
from warp2.tags.lane import TagLane


def _record(tmp_path, monkeypatch):
    """Intention: a lane of 300 entries whose closed segments are written small against web tags."""
    monkeypatch.setattr(journal, "ROTATE_AFTER_BYTES", 20000)
    tags = tmp_path / "state" / "store" / "tags"
    lane = TagLane(tags / "tags.jsonl")
    for number in range(300):
        lane.append({"fact": "assert", "row": {"subject": f"part_{number % 7}", "relation": "", "object": "",
                                               "attr": "status", "value": f"built {number % 3}", "confidence": 900,
                                               "valid_from": "2026-11-10T04:53:11.121221+00:00", "run": "web",
                                               "stamp": "6cfebf804e787d7f", "proof": 4}})
    assert WholeLane(tags, say=lambda text: None, form=2).run(seconds=600.0)["done"] >= 2
    return tags, tags / "dehydrated" / "web_tagged"


def test_segments_wait_until_they_fill_a_part(tmp_path, monkeypatch):
    """Intention: with room for far more than the waiting segments nothing is lifted yet; with less, they go in."""
    _tags, home = _record(tmp_path, monkeypatch)
    monkeypatch.setattr(kg_convert, "tags_that_fit", lambda: 10 ** 9)
    waited = keep_kg(home, say=lambda line: None, every=False)
    assert waited["segments"] == 0 and waited["waiting"] >= 2 and not kg_parts(home).files()
    monkeypatch.setattr(kg_convert, "tags_that_fit", lambda: 10)
    kept = keep_kg(home, say=lambda line: None, every=False)
    assert kept["segments"] == waited["waiting"] and kg_parts(home).files()


def test_the_small_files_go_to_deep_storage_and_the_lane_reads_the_same(tmp_path, monkeypatch):
    """Intention: once held the same in the corpus, each small file is copied to deep storage, checked, taken out;
    the lane gives every entry the same."""
    tags, home = _record(tmp_path, monkeypatch)
    before = list(TagLane(tags / "tags.jsonl").entries())
    record = json.loads((home / "done.json").read_text(encoding="utf-8"))
    assert send_small(home, tmp_path / "deep")["left"] == 0   # nothing is in the corpus yet, so nothing is waiting
    keep_kg(home, say=lambda line: None)
    assert send_small(home, None)["why"] == "no deep storage has been said"
    sent = send_small(home, tmp_path / "deep")
    assert sent == {"sent": len(record), "left": 0, "why": ""}
    assert not list(home.glob("entries-*.bin"))
    assert len(list((tmp_path / "deep" / "kg_small_segments").glob("entries-*.bin"))) == len(record)
    assert list(TagLane(tags / "tags.jsonl").entries()) == before


def test_a_file_the_corpus_does_not_give_back_the_same_stays(tmp_path, monkeypatch):
    """Intention: a small file that differs from its anchor in the corpus is not sent, and the result says which."""
    _tags, home = _record(tmp_path, monkeypatch)
    keep_kg(home, say=lambda line: None)
    first_file = sorted(home.glob("entries-*.bin"))[0]
    first_file.write_bytes(first_file.read_bytes() + b"\x01")
    sent = send_small(home, tmp_path / "deep")
    assert sent["sent"] == 0 and first_file.name in sent["why"] and first_file.exists()
