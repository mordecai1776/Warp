# WARP3/warp2/corpus/tests/test_a_corpus_finds_its_names_without_opening_every_part.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/tests/test_a_corpus_finds_its_names_without_opening_every_part.py
#  Used by   : pytest; CHECK_FIXES.bat.
#  Uses      : warp2/corpus/parts.py (Parts), warp2/corpus/part.py (Part, TEXT), warp2/corpus/names_book.py.
#  Description:
#    BUILD_LOG 2262: dehydrate_what_is_not's whole turn went on opening the
#    7,083 parts of state/corpus/text/archive to learn their names, in every
#    new child. Each part's names are now kept beside the warp by the part's
#    size and write time: a new Parts (a new process) opens no part whose
#    names it already has, opens only a part that is new, and keeps no part
#    open that it opened only for its names.
#  User intention (Andrew, 2026-11-13 20:35): "everything needs to be in and
#    run from a fully dehydrated form."
# ============================================================================
"""Intention: a corpus finds which part holds which name without opening every part each time."""
from warp2.corpus import part as part_module
from warp2.corpus.part import TEXT
from warp2.corpus.parts import Parts


def _count_opens(monkeypatch) -> list:
    """Intention: every part opened from now on, counted (the real opening still done)."""
    opened = []
    real = part_module.Part.__init__

    def counted(self, path, raw=None):
        opened.append(path)
        real(self, path, raw)
    monkeypatch.setattr(part_module.Part, "__init__", counted)
    return opened


def _two_parts(folder):
    """Intention: a corpus of two parts."""
    parts = Parts(folder)
    parts.add([("a.txt", "text", b"alpha beta\n" * 20)], TEXT)
    parts.add([("b.txt", "text", b"gamma delta\n" * 20)], TEXT)
    return parts


def test_a_new_corpus_reader_opens_no_part_it_already_knows(tmp_path, monkeypatch):
    """Intention: once the names are known, a fresh reader (a new process) opens no part to find them."""
    folder = tmp_path / "corpus"
    _two_parts(folder)
    assert Parts(folder).holds("a.txt")
    opened = _count_opens(monkeypatch)
    again = Parts(folder)
    assert again.holds("a.txt") and again.holds("b.txt") and not again.holds("c.txt")
    assert opened == []
    assert again.read("b.txt") == b"gamma delta\n" * 20


def test_only_a_new_part_is_opened_and_none_is_kept_open(tmp_path, monkeypatch):
    """Intention: a part added since is opened for its names, the others are not; and none stays open after."""
    folder = tmp_path / "corpus"
    _two_parts(folder)
    assert Parts(folder).holds("a.txt")
    Parts(folder).add([("c.txt", "text", b"epsilon zeta\n" * 20)], TEXT)
    opened = _count_opens(monkeypatch)
    again = Parts(folder)
    assert again.holds("c.txt") and again.holds("a.txt")
    assert [p.name for p in opened] == ["part-0003.bin"]
    assert again._open == {}
