# WARP2/warp2/corpus/tests/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/tests/__init__.py
#  Used by   : pytest (the package of the corpus's tests).
#  Uses      : nothing.
#  Description:
#    The tests of the corpus of tags: every thing reads back exactly, and the
#    warp's record and text are kept in corpus form and read the same from it.
#  User intention (Andrew, 2026-11-13 21:03): "Do not stop until everything
#    is converted". BUILD_LOG 1621c.
# ============================================================================
