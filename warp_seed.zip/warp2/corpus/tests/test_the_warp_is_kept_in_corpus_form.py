# WARP2/warp2/corpus/tests/test_the_warp_is_kept_in_corpus_form.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/tests/test_the_warp_is_kept_in_corpus_form.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/convert/{kg,state_text,run}.py (run measures
#              through warp2/corpus/shelf.py); warp2/tags/dehydrated/small_bytes.py; warp2/tags/
#              lane.py (TagLane); warp2/tags/dehydrated/whole_lane.py
#              (WholeLane); warp2/record/journal.py.
#  Description:
#    What the warp holds goes into corpus form and runs from it: the KG's
#    record kept as anchors over the KG's corpus, and the lane reads every
#    entry the same when the segments' own files are gone; the state's text
#    files (and packed ones) kept per collection and read back as the very
#    bytes, the files of the tensor books and what is not text left to their
#    own forms; a file written since is kept again; a second run keeps
#    nothing new; the run writes what it came to.
#  User intention (Andrew, 2026-11-13 20:35): "everything needs to be in and
#    run from a fully dehydrated form." 21:03: "Do not stop until everything
#    is converted". BUILD_LOG 1621c.
# ============================================================================
"""Intention: the KG's record and the state's text are kept in corpus form and read the same from it."""
import gzip
import json
import os

from warp2.corpus.convert.kg import keep_kg, kg_parts
from warp2.corpus.convert.run import run
from warp2.corpus.convert.state_text import file_back, keep_state_text, text_parts
from warp2.record import journal
from warp2.tags.dehydrated.small_bytes import segment_bytes
from warp2.tags.dehydrated.whole_lane import WholeLane
from warp2.tags.lane import TagLane


def _small_record(tmp_path, monkeypatch):
    """Intention: a lane with 300 entries whose closed segments are written small against web tags."""
    monkeypatch.setattr(journal, "ROTATE_AFTER_BYTES", 20000)
    tags = tmp_path / "state" / "store" / "tags"
    lane = TagLane(tags / "tags.jsonl")
    for number in range(300):
        lane.append({"fact": "assert", "row": {"subject": f"part_{number % 7}", "relation": "", "object": "",
                                               "attr": "status", "value": f"built {number % 3}", "confidence": 900,
                                               "valid_from": "2026-11-10T04:53:11.121221+00:00", "run": "web",
                                               "stamp": "6cfebf804e787d7f", "proof": 4}})
    done = WholeLane(tags, say=lambda text: None, form=2).run(seconds=600.0)
    assert done["done"] >= 2
    return tags


def test_the_record_runs_from_its_corpus_when_the_segment_files_are_gone(tmp_path, monkeypatch):
    """Intention: every segment kept as an anchor; with the .bin files moved away the lane reads the same entries."""
    tags = _small_record(tmp_path, monkeypatch)
    home = tags / "dehydrated" / "web_tagged"
    before = [entry for entry in TagLane(tags / "tags.jsonl").entries()]
    record = json.loads((home / "done.json").read_text(encoding="utf-8"))
    raw = {kept["small"]: (home / kept["small"]).read_bytes() for kept in record.values()}
    done = keep_kg(home, say=lambda line: None)
    assert done["segments"] == len(record) and len(done["parts"]) == 1
    assert keep_kg(home, say=lambda line: None)["segments"] == 0
    away = tmp_path / "sent"
    away.mkdir()
    for small in raw:
        os.replace(home / small, away / small)
    parts = kg_parts(home)
    assert all(segment_bytes(home, small, parts) == data for small, data in raw.items())
    after = [entry for entry in TagLane(tags / "tags.jsonl").entries()]
    assert after == before and len(after) == 300


def test_the_states_text_is_kept_per_collection_and_reads_back_the_same(tmp_path):
    """Intention: text and packed files kept and read back as the very bytes; books and non-text left alone; a
    packed file whose part would not be smaller than its packed bytes stays in its own form, noted."""
    state = tmp_path / "state"
    files = {"archive/a.json": b'{"x": 1, "y": "same words"}\n' * 300,
             "archive/b.json": b'{"x": 2, "y": "same words"}\n' * 300,
             "journals/j.jsonl": b"".join(b'{"seq": %d, "said": "the same line"}\n' % n for n in range(400)),
             "top.json": b'{"top": true, "words": "the same words again"}\n' * 100,
             "archive/c.json.gz": gzip.compress(b'{"packed": "same words"}\n' * 40, 9, mtime=7),
             "images/p.png": b"\x89PNG\r\n\x1a\n\x00\x00binary",
             "house/models_small/book/index.json": b'{"kept": "in its own book"}'}
    for name, raw in files.items():
        (state / name).parent.mkdir(parents=True, exist_ok=True)
        (state / name).write_bytes(raw)
    done = keep_state_text(state, say=lambda line: None)
    assert done["files"] == 5 and done["not_text"][".png"][0] == 1
    assert done["own_form_smaller"]["files"] == 1   # the small gzip file is smaller as it is
    for name in ["archive/a.json", "archive/b.json", "journals/j.jsonl", "top.json"]:
        assert file_back(state, name) == files[name]
    assert keep_state_text(state, say=lambda line: None)["files"] == 0
    later = os.path.getmtime(state / "archive" / "a.json") + 10
    (state / "archive" / "a.json").write_bytes(b"written since, and long enough to be worth a part\n" * 50)
    os.utime(state / "archive" / "a.json", (later, later))
    assert keep_state_text(state, say=lambda line: None)["files"] == 1
    assert file_back(state, "archive/a.json") == b"written since, and long enough to be worth a part\n" * 50


def test_a_big_packed_file_goes_into_the_corpus_and_packs_back_the_same(tmp_path):
    """Intention: packed files that share their text across files are smaller as one part than packed each alone,
    and each comes back as its very packed bytes."""
    state = tmp_path / "state"
    texts = {f"archive/raw/r{n}.json.gz": b"".join(b'{"frame": %d, "kind": "capture", "said": "the same words"}\n'
                                                    % (n * 1000 + k) for k in range(300)) for n in range(30)}
    packed_files = {name: gzip.compress(text, 9, mtime=1000 + n) for n, (name, text) in enumerate(texts.items())}
    for name, raw in packed_files.items():
        (state / name).parent.mkdir(parents=True, exist_ok=True)
        (state / name).write_bytes(raw)
    done = keep_state_text(state, say=lambda line: None)
    # Intention: a packed file this machine's zlib cannot pack back to the very bytes stays as it is (counted with
    # what is not text); every one taken comes back exactly.
    left = done["not_text"].get(".gz", (0, 0))[0]
    assert done["files"] + left == 30 and done["files"] >= 28 and done["own_form_smaller"]["files"] == 0
    taken_names = [name for name in packed_files if text_parts(state, "archive").holds(name)]
    assert len(taken_names) == done["files"]
    assert all(file_back(state, name) == packed_files[name] for name in taken_names)


def test_a_run_writes_what_everything_came_to(tmp_path, monkeypatch):
    """Intention: the run keeps the record and the text and writes their measures beside the corpora."""
    tags = _small_record(tmp_path, monkeypatch)
    state = tags.parent.parent
    (state / "notes").mkdir()
    (state / "notes" / "n.txt").write_bytes(b"a note that says the same thing again\n" * 100)
    done = run(state, say=lambda line: None)
    written = json.loads((state / "corpus" / "converted.json").read_text(encoding="utf-8"))
    assert written["kg"]["segments"] == done["kg"]["segments"] > 0
    assert written["measures"]["kg record"]["things"] == done["kg"]["segments"]
    assert written["measures"]["text notes"]["things"] == 1


def test_runs_side_by_side_keep_their_own_shares_of_the_text(tmp_path):
    """Intention (1633c): share 0 of 2 and share 1 of 2 keep no file twice and every file between them."""
    state = tmp_path / "state"
    names = [f"notes/n{n}.txt" for n in range(20)]
    for number, name in enumerate(names):
        (state / name).parent.mkdir(parents=True, exist_ok=True)
        (state / name).write_bytes(b"a note that says the same thing again %d\n" % number * 60)
    first = keep_state_text(state, say=lambda line: None, share=(0, 2))
    second = keep_state_text(state, say=lambda line: None, share=(1, 2))
    assert first["files"] + second["files"] == 20 and first["files"] and second["files"]
    assert all(file_back(state, name) == (state / name).read_bytes() for name in names)
    assert keep_state_text(state, say=lambda line: None)["files"] == 0
