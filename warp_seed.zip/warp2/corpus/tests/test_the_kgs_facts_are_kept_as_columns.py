# WARP2/warp2/corpus/tests/test_the_kgs_facts_are_kept_as_columns.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/tests/test_the_kgs_facts_are_kept_as_columns.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/{columns,part}.py; warp2/corpus/convert/view.py;
#              warp2/store/schema.py (DDL, fact_key); (stdlib) sqlite3.
#  Description:
#    The store's working view kept in corpus form: a block of columns gives
#    every column back; a part held in memory reads like one on disk; every
#    fact of a view - keys worked out from the row or kept when they cannot
#    be, times in microseconds or kept as written when written another way,
#    empty fields - comes back exactly; a second run keeps only facts added
#    since; the blocks are a small share of the view; the view is the one
#    the store works from, named as the store names it.
#  User intention (Andrew, 2026-11-13 20:19): "the warp should be working from
#    the dehydrated kg now"; 20:35: "everything needs to be in and run from a
#    fully dehydrated form." BUILD_LOG 1624c.
# ============================================================================
"""Intention: every fact of the store's view comes back exactly from its columns in corpus form."""
import sqlite3

import numpy as np

from warp2.corpus.columns import Columns, pack_block
from warp2.corpus.convert.view import COLUMNS, keep_view
from warp2.corpus.part import TEXT, Part, make
from warp2.store import schema


def _view(path, rows):
    """Intention: a view with the store's own table, holding these rows."""
    con = sqlite3.connect(path)
    for ddl in schema.DDL:
        con.execute(ddl)
    con.executemany(f"INSERT INTO fact ({', '.join(COLUMNS)}) VALUES ({', '.join('?' * len(COLUMNS))})", rows)
    con.commit()
    con.close()


def _row(number: int, **said):
    """Intention: one fact as the store writes it, with anything said put in its place."""
    subject, relation, obj, attr, value = f"point:{number % 9}", "has", None, f"knob:{number % 4}", str(number)
    row = {"id": number, "key": schema.fact_key(subject, relation, obj, attr, value), "subject": subject,
           "relation": relation, "object": obj, "attr": attr, "value": value, "evidence": None,
           "confidence": 900 if number % 3 else None, "valid_from": f"2026-08-28T19:21:{number % 60:02d}.{number:06d}+00:00",
           "valid_to": None, "reason": None, "recorded_at": f"2026-08-28T19:21:{number % 60:02d}.{number + 90:06d}+00:00",
           "seq": number + 1, "run": "projects", "stamp": "6cfebf804e787d7f", "proof": None}
    row.update(said)
    return tuple(row[name] for name in COLUMNS)


def test_a_block_gives_every_column_back_and_a_part_reads_from_memory():
    """Intention: columns and the word table come back exactly; a text part given as bytes reads like a file."""
    columns = {"a": np.arange(100), "b": np.zeros(50, dtype=np.int64)}
    block = Columns(pack_block(columns, ["one", "two é"], {"rows": 100}))
    assert np.array_equal(block.column("a"), columns["a"]) and np.array_equal(block.column("b"), columns["b"])
    assert block.words() == ["one", "two é"]
    part = Part(None, raw=make([("x", "text", b"held in memory")], TEXT))
    assert part.read("x") == b"held in memory"


def test_every_fact_of_the_view_comes_back_exactly(tmp_path):
    """Intention: odd keys, odd times, empty fields and closed facts all come back; a second run keeps only what is
    new; the blocks are far smaller than the view."""
    rows = [_row(n) for n in range(1, 3000)]
    rows.append(_row(3000, key="not-the-worked-out-key", valid_to="2026-09-04T03:23:35.135847+00:00",
                     reason="term is not made of words"))
    rows.append(_row(3001, valid_from="2026-08-28T19:21:58+00:00", recorded_at="2026-08-28 19:21:58.000001+00:00"))
    rows.append(_row(3002, valid_from="1", recorded_at="not a time", valid_to="1"))   # 1632c: texts that are no time
    view = tmp_path / "view.sqlite3"
    _view(view, rows)
    home = tmp_path / "facts"
    done = keep_view(view, home, say=lambda line: None)
    assert done["rows"] == len(rows) and done["bytes"] < view.stat().st_size / 10
    from warp2.corpus.convert.view import rows_of
    back = [row for path in sorted(home.glob("facts-*.bin")) for row in rows_of(Columns(path.read_bytes()),
                                                                                 schema.fact_key)]
    assert back == rows
    _view(view, [_row(n) for n in range(3003, 3100)])
    again = keep_view(view, home, say=lambda line: None)
    assert again["rows"] == 97 and len(list(home.glob("facts-*.bin"))) == 2


def test_the_view_is_found_where_the_store_puts_it(tmp_path):
    """Intention (1626c): the facts are taken from the very view the store works from - named as the store names it."""
    from types import SimpleNamespace
    from warp2.corpus.convert.view import view_of
    from warp2.store.store import Store, store_home
    assert view_of(tmp_path / "state") == Store._default_view(SimpleNamespace(state=store_home(tmp_path / "state")))
