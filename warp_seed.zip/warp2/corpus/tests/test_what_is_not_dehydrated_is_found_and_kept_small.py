# WARP3/warp2/corpus/tests/test_what_is_not_dehydrated_is_found_and_kept_small.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/tests/test_what_is_not_dehydrated_is_found_and_kept_small.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/convert/rest.py, warp2/corpus/convert/state_text.py
#              (file_back), warp2/corpus/convert/{webs,turn_walk}.py,
#              warp2/corpus/kinds/keep.py (file_back), warp2/work/side/
#              dehydrate_rest.py, projects/behemoth_eye/eye/turn_clock.py.
#  Description:
#    The warp's turn of finding what is not dehydrated: the state's text not
#    kept yet is kept and comes back the very bytes; a second turn finds
#    nothing new; a file written since is kept again; a turn whose time is up
#    keeps nothing and leaves the walk for the next; (1652c) a file that is
#    not text is kept by its kind and given back; the walk is carried from
#    turn to turn, a folder at a time; the report is written beside the corpora;
#    the connection web is pictured only when it has changed by at least what
#    a picture takes and the turn has the time; the step runs in a child body
#    that crosses into a spawned process, and says what it kept.
#  User intention (Andrew, 2026-11-14 22:25): "Let's get a system to look for
#    nondehydrated things and dehydrates them and puts them in the smaller
#    kg." BUILD_LOG 1651c. 23:42: "adapt it to everything" (1652c).
# ============================================================================
"""Intention: what is not small yet is found and kept small, inside the turn, and what waits is said."""
import json
import os
import pickle
import random
import time
from types import SimpleNamespace

import pytest

from projects.behemoth_eye.eye.turn_clock import turn
from warp2.corpus.convert import rest as rest_module
from warp2.corpus.convert.rest import DehydrateRest, rest, webs_due
from warp2.corpus.convert.state_text import file_back
from warp2.corpus.convert.turn_walk import StateWalk
from warp2.corpus.kinds.keep import file_back as kinds_file_back
from warp2.corpus.convert.webs import home_of, source_of
from warp2.work.side.dehydrate_rest import DehydrateRestStep

MANY = 400
SEED = 1


@pytest.fixture(autouse=True)
def _seeded_kinds(monkeypatch):
    """Intention (BUILD_LOG 2265): the kinds' chooser draws its chances from a seeded Random here, so what a turn
    keeps is the same every run - unseeded, the 1,024-byte file was kept smaller about 3 runs in 4 (one way makes
    it 1,010 bytes, another not smaller, and the draw decided whether the first was tried)."""
    made = rest_module.KindsTurn
    monkeypatch.setattr(rest_module, "KindsTurn", lambda state, say=print, rng=None: made(state, say, rng or random.Random(SEED)))

LINES = "\n".join(f"line {n}: the warp kept this fact about thing {n % 17} and thing {n % 5}" for n in range(MANY))


def _state(tmp_path):
    state = tmp_path / "state"
    for n in range(6):
        path = state / "notes" / f"note-{n}.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(LINES + f"\nlast line {n}\n", encoding="utf-8")
    every_byte = 256
    (state / "notes" / "weights.bin").write_bytes(bytes(range(every_byte)) * 4)
    return state


def _write_later(path, data: bytes) -> None:
    """Intention: a file written again, with a write time surely after the one it had - Windows' clock moves
    in steps of about 16 ms, so two writes close together can carry the same time; the test is of the
    write being seen, not of the clock."""
    was = path.stat().st_mtime_ns
    path.write_bytes(data)
    later = max(path.stat().st_mtime_ns, was + 1_000_000_000)
    os.utime(path, ns=(later, later))


def test_text_not_kept_yet_is_kept_and_comes_back_the_very_bytes_and_a_second_turn_finds_nothing(tmp_path):
    state = _state(tmp_path)
    first = rest(state)
    assert first["did"] == "kept small" and first["text_files_kept"] == 6
    assert first["text_bytes_now"] < first["text_bytes_were"]
    for n in range(6):
        name = f"notes/note-{n}.txt"
        assert file_back(state, name) == (state / name).read_bytes()
    written = (state / "corpus" / "rest.json").read_text(encoding="utf-8")
    report = json.loads(written)
    assert report["text"]["not_looked_at"] == 0
    assert report["text"]["not_text"][".bin"][0] == 1
    assert first["kinds_files_kept"] == 1 and first["walk_pass_ended"]
    assert kinds_file_back(state, "notes/weights.bin") == (state / "notes" / "weights.bin").read_bytes()
    second = rest(state)
    assert second["did"] == "nothing new" and second["text_files_kept"] == 0
    assert second["not_text_files"] == 1


def test_a_file_that_is_not_text_is_noted_once_and_not_read_again_until_written_since(tmp_path, monkeypatch):
    state = _state(tmp_path)
    rest(state)
    written = (state / "corpus" / "text" / "notes" / "not_text.json").read_text(encoding="utf-8")
    noted = json.loads(written)
    assert list(noted) == ["notes/weights.bin"]
    from warp2.corpus.convert import state_text
    looked = []
    monkeypatch.setattr(state_text, "_zero_in_first_buffer", lambda path: looked.append(path) or True)
    again = rest(state)
    assert looked == [] and again["not_text_files"] == 1
    _write_later(state / "notes" / "weights.bin", bytes(9))
    rest(state)
    assert [path.name for path in looked] == ["weights.bin"]


def test_a_file_written_since_is_kept_again(tmp_path):
    state = _state(tmp_path)
    rest(state)
    changed = state / "notes" / "note-2.txt"
    _write_later(changed, (LINES + "\nwritten again\n").encode("utf-8"))
    again = rest(state)
    assert again["text_files_kept"] == 1
    assert file_back(state, "notes/note-2.txt") == changed.read_bytes()


def test_a_turn_whose_time_is_up_keeps_nothing_and_leaves_the_walk_for_the_next(tmp_path):
    state = _state(tmp_path)
    with turn(1e-6):
        time.sleep(0.01)
        said = rest(state)
    assert said["text_files_kept"] == 0 and said["kinds_files_kept"] == 0
    assert not said["walk_pass_ended"] and said["walk_folders_left"] >= 1
    assert not (state / "corpus" / "text" / "notes").exists() or not any((state / "corpus" / "text" / "notes").iterdir())
    later = rest(state)
    assert later["text_files_kept"] == 6 and later["walk_pass_ended"]


def test_the_walk_is_carried_from_turn_to_turn_a_folder_at_a_time(tmp_path):
    state = _state(tmp_path)
    (state / "more" / "inner").mkdir(parents=True)
    (state / "more" / "inner" / "x.txt").write_text("x", encoding="utf-8")
    walk = StateWalk(state)
    first = next(walk.folders())
    walk.done_with(first[1])
    left = walk.save()
    assert first[0] == "." and not left["pass_ended"] and left["folders_left"] >= 2
    walked = [first[1]]
    for _turn in range(len(list(state.rglob("*")))):
        again = StateWalk(state)
        for collection, folder, _files in again.folders():
            walked.append(folder)
            again.done_with(folder)
            break
        if again.save()["pass_ended"]:
            break
    assert [folder.relative_to(state).as_posix() for folder in walked] == [".", "more", "more/inner", "notes"]
    assert StateWalk(state).passes == 1


def test_the_connection_web_is_pictured_only_when_changed_enough_and_the_turn_has_the_time(tmp_path):
    state = tmp_path / "state"
    assert webs_due(state, None) == (False, "there is no connection web yet")
    source = source_of(state)
    source.parent.mkdir(parents=True)
    source.write_bytes(b"x" * 1000)
    assert webs_due(state, None) == (True, "")
    now = home_of(state) / "now"
    now.mkdir(parents=True)
    stat = source.stat()
    kept = {"db_bytes": stat.st_size, "db_mtime_ns": stat.st_mtime_ns, "bytes": 300, "seconds": 50.0}
    picture = json.dumps(kept)
    (now / "kept.json").write_text(picture, encoding="utf-8")
    assert webs_due(state, None)[0] is False                      # the picture is of the web as it is now
    _write_later(source, b"x" * 1100)
    assert webs_due(state, None)[1].startswith("the web has changed by less")
    source.write_bytes(b"x" * 1400)
    assert webs_due(state, 10.0)[1].startswith("the turn has less left")
    assert webs_due(state, 60.0) == (True, "")
    assert webs_due(state, None) == (True, "")


def test_the_step_is_a_child_body_that_crosses_a_spawn_and_says_what_it_kept(tmp_path):
    state = _state(tmp_path)
    told = []
    step = DehydrateRestStep(SimpleNamespace(state=state, root=state.parent, loop=None, tell=told.append))
    body = step.child()
    assert isinstance(body, DehydrateRest)
    pickle.loads(pickle.dumps(body))
    value = body()
    step.after_child(value)
    assert value["text_files_kept"] == 6 and told and told[0].startswith("Dehydrated: ")
    assert step()["did"] == "nothing new"
    assert len(told) == 1


def test_the_kgs_facts_wait_for_nothing(tmp_path):
    """Intention (BUILD_LOG 1656c): the KG's facts are the record held small - there is no view to copy, so the turn
    keeps nothing for them and says so."""
    state = _state(tmp_path)
    assert rest_module.rest(state)["facts_waiting"] == 0
