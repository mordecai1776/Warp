# WARP3/warp2/corpus/tests/test_outside_folders_come_in_through_the_warps_own_keeper.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/tests/test_outside_folders_come_in_through_the_warps_own_keeper.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/convert/{outside,state_text}.py, warp2/store/store.py.
#  Description:
#    A folder outside the state is kept by the warp's own text keeper as a
#    collection of the text corpus, given back as its very bytes, named in the
#    KG, and only then removed. A file that is not text is dehydrated the same
#    way, as its very bytes (BUILD_LOG 2258) - never sent to be only
#    compressed. Nothing is zipped: the collection is read back by the same
#    door as every other.
#  User intention (Andrew, 2026-11-19 23:35): "It should be using the same
#    system everything else does the same exact system". BUILD_LOG 0220b.
#    (2026-11-26) "Always dehydrated then compressed never just compressed"
#    (BUILD_LOG 2258: the expectations below for the file that is not text
#    changed with it - it now comes back from the text corpus, not the kinds).
# ============================================================================
"""Outside folders come in through the warp's own keeper of text."""
from __future__ import annotations

import os

from warp2.corpus.convert import outside
from warp2.corpus.convert.state_text import file_back, text_parts
from warp2.store.store import Store, store_home


def test_a_folder_outside_is_kept_by_the_warps_keeper_proved_named_and_removed(tmp_path):
    state, source = tmp_path / "state", tmp_path / "deep"
    (source / "run" / "blocks").mkdir(parents=True)
    files = {"notes.txt": b"the same line again and again\n" * 4000,
             "run/log.jsonl": b"".join(b'{"n": %d, "what": "a line of the run"}\n' % k for k in range(5000)),
             "run/blocks/block.json": ("[" + ",".join(str(k * 7) for k in range(30000)) + "]").encode()}
    for name, raw in files.items():
        (source / name).write_bytes(raw)
    weights = os.urandom(5000) + b"\x00" * 10
    (source / "weights.bin").write_bytes(weights)
    (source / "run" / "raw_capture.dehydrated.jsonl").write_bytes(b'{"t": [3, 9, 27]}\n' * 900)   # dehydrated already
    (source / "dehydrated").mkdir()
    (source / "dehydrated" / "lane.jsonl").write_bytes(b'{"t": [1, 2, 3]}\n' * 900)
    done = outside.bring_in(state, "deep_storage", source, say=lambda _line: None)
    # Intention (BUILD_LOG 2258): what is not text comes in too - dehydrated by the same keeper, as its very bytes,
    # beside the text of its folder; nothing goes to the keeper of what is not text to be only compressed.
    assert done["files"] == 4 and done["left"] == 2 and done["not_text"] == 0 and done["already_dehydrated"] == 2
    assert (source / "run" / "raw_capture.dehydrated.jsonl").exists() and (source / "dehydrated" / "lane.jsonl").exists()
    assert not (source / "weights.bin").exists() and not (source / "run" / "blocks").exists()
    assert file_back(state, "deep_storage/weights.bin") == weights
    assert not (state / "corpus" / "kinds" / "deep_storage").exists()
    assert done["corpus_bytes"] < sum(len(raw) for raw in files.values())
    for name, raw in files.items():
        assert file_back(state, f"deep_storage/{name}") == raw                             # the same door as every file
    assert sorted(text_parts(state, "deep_storage").where()) == sorted(f"deep_storage/{name}" for name in [*files, "weights.bin"])
    store = Store(store_home(state))
    try:
        told = {str(f["attr"]): f["value"] for f in store.current(subject="deep_storage/run/log.jsonl") if f.get("attr")}
    finally:
        store.close()
    assert told["kind"] == "kept_file" and int(told["bytes"]) == len(files["run/log.jsonl"]) and told["kept_in"] == "corpus/text/deep_storage"
    again = outside.bring_in(state, "deep_storage", source, say=lambda _line: None)       # nothing new: nothing done
    assert again["files"] == 0 and again["left"] == 2


def test_a_file_the_kg_already_holds_is_not_put_in_again(tmp_path):
    """Intention (BUILD_LOG 2305 - Andrew 2026-11-26 23:03: "make sure it is not putting in things that are already
    in the kg"): a file whose very bytes the KG already keeps - under another name, from another folder, or twice in
    the same run - is not put in a second time; the KG is told it is the same, and it is removed from outside."""
    state, first, second = tmp_path / "state", tmp_path / "first", tmp_path / "second"
    first.mkdir()
    second.mkdir()
    log = b"".join(b'{"n": %d, "what": "a line of the run"}\n' % k for k in range(5000))
    other = b"another file with lines of its own\n" * 3000
    (first / "log.jsonl").write_bytes(log)
    outside.bring_in(state, "first", first, say=lambda _line: None)
    size = sum(p.stat().st_size for p in (state / "corpus" / "text").rglob("*") if p.is_file())
    (second / "the_same_log.jsonl").write_bytes(log)
    (second / "new.txt").write_bytes(other)
    (second / "new_again.txt").write_bytes(other)
    done = outside.bring_in(state, "second", second, say=lambda _line: None)
    assert done["already_in_the_kg"] >= 1 and done["left"] == 0
    assert not text_parts(state, "second").holds("second/the_same_log.jsonl")           # not kept a second time
    held = [n for n in ("second/new.txt", "second/new_again.txt") if text_parts(state, "second").holds(n)]
    assert len(held) == 1 and file_back(state, held[0]) == other                         # the twin in one run: once
    store = Store(store_home(state))
    try:
        told = {str(f["attr"]): f["value"] for f in store.current(subject="second/the_same_log.jsonl") if f.get("attr")}
    finally:
        store.close()
    assert told["same_as"] == "first/log.jsonl" and file_back(state, told["same_as"]) == log
    grew = sum(p.stat().st_size for p in (state / "corpus" / "text").rglob("*") if p.is_file()) - size
    assert grew < len(log)                                                                # only the new file came in


def test_research_papers_and_the_users_intentions_are_kept_no_matter_what(tmp_path):
    """Intention (BUILD_LOG 2308 - Andrew 2026-11-26 23:45: "it should keep all research papers and users intentions
    no matter what"): a paper or an intention whose part would be no smaller still goes in and comes back exactly;
    any other file that would be no smaller waits outside, as before."""
    from warp2.corpus.convert.always_kept import must_keep
    assert must_keep("deep/research/a.bin") and must_keep("x/Paper_2610.35598.txt") and must_keep("a/b.PDF")
    assert must_keep("design/ANDREW_DESIGN.md") and must_keep("docs/user_intention_notes.txt") and not must_keep("run/weights.bin")
    state = tmp_path / "state"
    for folder, name in (("one", "paper.pdf"), ("two", "users_intention.bin"), ("three", "weights.bin")):
        (tmp_path / folder).mkdir()
        (tmp_path / folder / name).write_bytes(os.urandom(4096))          # bytes nothing makes smaller
    raw = {f: (tmp_path / f / n).read_bytes() for f, n in (("one", "paper.pdf"), ("two", "users_intention.bin"))}
    assert outside.bring_in(state, "one", tmp_path / "one", say=lambda _line: None)["files"] == 1
    assert outside.bring_in(state, "two", tmp_path / "two", say=lambda _line: None)["files"] == 1
    assert file_back(state, "one/paper.pdf") == raw["one"] and file_back(state, "two/users_intention.bin") == raw["two"]
    left = outside.bring_in(state, "three", tmp_path / "three", say=lambda _line: None)
    assert left["files"] == 0 and (tmp_path / "three" / "weights.bin").exists()


def test_a_file_too_big_to_lift_goes_in_by_pieces_and_comes_back_whole(tmp_path, monkeypatch):
    """Intention (BUILD_LOG 2312 - Andrew 2026-11-27 00:21: "get the last ones done"): a file bigger than the share
    of free memory one file may take is cut into pieces, the pieces go in, the KG names the whole with its sha256
    and its pieces, and only then is the big file removed; the same bytes later are not put in again."""
    import hashlib
    from warp2.corpus.convert import in_pieces, memory
    monkeypatch.setattr(memory, "free_bytes", lambda: 64 * 1024)                  # one file may take 8 KB; a piece is 4 KB
    state, deep, again = tmp_path / "state", tmp_path / "deep", tmp_path / "again"
    deep.mkdir()
    again.mkdir()
    raw = b"".join(b'{"n": %d, "what": "a line of a long log"}\n' % k for k in range(3000))
    (deep / "long.jsonl").write_bytes(raw)
    (deep / "small.txt").write_bytes(b"a small file\n" * 50)
    done = outside.bring_in(state, "deep", deep, say=lambda _line: None)
    assert not (deep / "long.jsonl").exists() and done["left"] == 0 and done["too_big"] == 0
    store = Store(store_home(state))
    try:
        told = {str(f["attr"]): f["value"] for f in store.current(subject="deep/long.jsonl") if f.get("attr")}
    finally:
        store.close()
    assert told["sha256"] == hashlib.sha256(raw).hexdigest() and int(told["pieces"]) > 1
    assert b"".join(in_pieces.whole_back(state, "deep/long.jsonl", int(told["pieces"]))) == raw
    (again / "the_same_long.jsonl").write_bytes(raw)
    twice = outside.bring_in(state, "again", again, say=lambda _line: None)
    assert twice["already_in_the_kg"] == 1 and twice["left"] == 0

