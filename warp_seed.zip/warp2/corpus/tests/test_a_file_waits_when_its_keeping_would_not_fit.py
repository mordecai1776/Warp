# WARP3/warp2/corpus/tests/test_a_file_waits_when_its_keeping_would_not_fit.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/tests/test_a_file_waits_when_its_keeping_would_not_fit.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/convert/pace.py (Pace), warp2/room/mine.py (my_room, stood in for).
#  Description:
#    The pace learns the memory a byte costs from the files kept so far; a file whose size at that cost does not fit
#    in the room a new piece of work may take now waits; before anything is measured, every file may go (the run goes
#    smallest first).
#  User intention (Andrew, 2026-11-22 00:30): "Keep making improvements" - after the first bring-in ended on a memory
#    error holding 6.4 GB with 1.4 GB free; (2026-11-08) the warp must never take the machine's whole RAM.
# ============================================================================
from __future__ import annotations

from warp2.corpus.convert.pace import Pace
from warp2.room import mine


def test_a_file_whose_keeping_would_not_fit_waits(monkeypatch):
    monkeypatch.setattr(mine, "my_room", lambda: 1_000_000)
    pace = Pace()
    assert pace.fits(10 ** 9)                       # nothing measured yet: the smallest goes first, and teaches the cost
    pace.took(1_000, 0.5, grew=20_000)              # a byte cost 20 bytes
    assert pace.memory_a_byte == 20.0
    assert pace.fits(40_000) and not pace.fits(60_000)
    pace.took(2_000, 0.5, grew=0)                   # a file that did not raise the peak teaches nothing new
    assert pace.memory_a_byte == 20.0
