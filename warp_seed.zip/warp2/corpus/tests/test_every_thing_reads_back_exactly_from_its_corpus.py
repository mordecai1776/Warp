# WARP2/warp2/corpus/tests/test_every_thing_reads_back_exactly_from_its_corpus.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/tests/test_every_thing_reads_back_exactly_from_its_corpus.py
#  Used by   : pytest.
#  Uses      : warp2/corpus/{varint,grammar,fold,expand,level,levels,tokens,
#              smooth,part,parts}.py; warp2/corpus/convert/{packed,memory}.py;
#              numpy.
#  Description:
#    The corpus of tags gives every thing back exactly: numbers as the bytes
#    they take; repeats lifted into higher tags only while the whole gets
#    smaller, tags that stop paying folded back (a chain of runs keeps its
#    links); the corpus kept over a corpus of its own only while that is
#    smaller; text cut into pieces that join to the very bytes; a part's
#    anchors (name, type, notation) read back one at a time; a thing too big
#    for one lift kept in pieces and read back joined; packed files taken as
#    their text only when they pack back to the same bytes; tags coded to
#    their information (smooth codes) read back the same, and are smaller
#    than whole bytes when the tags are skewed; a part that would not be
#    smaller than what its things take where they are is not put in.
#  User intention (Andrew, 2026-11-13 20:49-21:05): files as anchors with a
#    "more and more compressed notation" over "a corpus of tags"; the corpus
#    "kept like this with its own corpus ... until it no longer gives
#    gains"; "hide higher forms in each things corpus of tags". BUILD_LOG 1621c.
# ============================================================================
"""Intention: every thing put in the corpus comes back exactly, and the corpus only grows when the whole shrinks."""
import gzip
import zlib

import numpy as np

from warp2.corpus import smooth, tokens
from warp2.corpus.convert.memory import free_bytes, tags_that_fit
from warp2.corpus.convert.packed import GZIP, ZLIB, opened, packed
from warp2.corpus.grammar import cut_apart, laid_out, lift
from warp2.corpus.level import make as make_level
from warp2.corpus.levels import keep, unkeep
from warp2.corpus.part import NUMBERS, SMOOTH, TEXT, Part, make
from warp2.corpus.parts import Parts
from warp2.corpus.varint import first, pack, size, unpack


def _phrased(seed: int = 3, things: int = 400):
    """Intention: notations made of phrases that repeat across things - what a corpus should lift."""
    rng = np.random.default_rng(seed)
    phrases = [rng.integers(0, 10 ** 9, rng.integers(2, 9)) for _ in range(60)]
    return [np.concatenate([phrases[i] for i in rng.integers(0, 60, rng.integers(1, 30))]) for _ in range(things)]


def test_numbers_are_kept_as_the_bytes_they_take():
    """Intention: varints pack and unpack whole arrays, size says the bytes, first reads a leading number."""
    values = np.array([0, 1, 127, 128, 16383, 16384, 2 ** 21, 2 ** 35 + 5], dtype=np.int64)
    raw = pack(values)
    assert len(raw) == size(values) == 1 + 1 + 1 + 2 + 2 + 3 + 4 + 6
    assert np.array_equal(unpack(raw), values)
    assert first(pack([300]) + b"rest") == (300, 2)


def test_repeats_are_lifted_and_the_notations_read_back_exactly():
    """Intention: the laid-out notations get shorter and every one expands back to what it was."""
    notations = _phrased() + [np.array([], dtype=np.int64), np.array([7] * 9, dtype=np.int64)]
    laid, _starts = laid_out(notations)
    level = make_level(laid)
    assert level.laid[level.laid >= 0].size < laid[laid >= 0].size / 3
    back = [level.read(each) for each in cut_apart(level.laid)]
    assert len(back) == len(notations)
    assert all(np.array_equal(b, n) for b, n in zip(back, notations))
    higher, _row = level.kinds()
    assert higher.sum() == level.offsets.size - 1


def test_a_pair_seen_once_is_never_made_a_tag():
    """Intention: nothing repeats, nothing is lifted - the corpus does not grow when the whole would not shrink."""
    laid, _starts = laid_out([np.arange(50), np.arange(100, 150)])
    lifted, parts = lift(laid, 1000)
    assert parts.shape[0] == 0 and np.array_equal(lifted, laid)


def test_a_chain_of_runs_keeps_its_links_when_tags_are_folded_back():
    """Intention: 5000 of one value become a short chain of tags, not a few wide ones (inner folds judged first)."""
    run = [np.zeros(5000, dtype=np.int64)]
    kept = keep(run)
    assert len(kept) < 80
    assert np.array_equal(unkeep(kept)[0], run[0])


def test_the_corpus_is_kept_over_its_own_corpus_only_while_that_is_smaller():
    """Intention: kept bytes are never more than plain, and read back the same, for any list of notations."""
    for notations in ([], [np.array([], dtype=np.int64)], [np.array([5])], [np.arange(1000)], _phrased(5, 300)):
        kept = keep(notations)
        plain_size = len(pack([len(notations)] + [len(n) for n in notations])) + sum(size(n) for n in notations)
        assert len(kept) <= plain_size + 4
        back = unkeep(kept)
        assert len(back) == len(notations) and all(np.array_equal(b, n) for b, n in zip(back, notations))
    assert len(keep(_phrased(5, 300))) < sum(size(n) for n in _phrased(5, 300)) / 5


def test_text_is_cut_into_pieces_that_join_to_the_very_bytes():
    """Intention: any bytes at all cut and joined give the same bytes."""
    for raw in [b"", b"abc", bytes(range(256)), "héllo wörld\r\n\t x".encode(), b'{"a": [1.5e-3]}\n']:
        assert b"".join(tokens.pieces(raw)) == raw
    distinct, notations = tokens.table([b"one two one", b"two  three\n"])
    assert distinct == sorted(set(distinct)) and tokens.joined(distinct, notations[1]) == b"two  three\n"


def test_a_part_reads_back_each_anchor_alone(tmp_path):
    """Intention: a part of text and a part of numbers each give every thing back by name or place, with its type."""
    things = [(f"folder/file_{n}.json", "text" if n % 2 else "json",
               (b'{"name": "item%d", "kind": "picture"}\n' % n) * (n % 5 + 1)) for n in range(40)]
    (tmp_path / "t.bin").write_bytes(make(things, TEXT))
    part = Part(tmp_path / "t.bin")
    assert part.names()[3] == "folder/file_3.json" and part.type_of(3) == "text" and part.type_of(4) == "json"
    assert all(part.read(name) == held for name, _t, held in things)
    assert part.head["measures"]["hydrated"] == sum(len(h) for _n, _t, h in things)
    part.close()
    numbers = [(f"n{i}", "kg entries", each) for i, each in enumerate(_phrased(7, 50))]
    (tmp_path / "n.bin").write_bytes(make(numbers, NUMBERS))
    part = Part(tmp_path / "n.bin")
    assert all(np.array_equal(part.read(i), held) for i, (_n, _t, held) in enumerate(numbers))
    part.close()


def test_parts_keep_new_things_as_new_parts_and_join_pieces(tmp_path):
    """Intention: each add is a new part that went in only after reading back; pieces read back joined."""
    parts = Parts(tmp_path / "corpus")
    first_part = parts.add([("a.txt", "text", b"alpha beta\n" * 20)], TEXT)
    second = parts.add([("big.txt#1", "text", b"one\ntwo\n"), ("big.txt#2", "text", b"three\n"),
                        ("b.txt", "text", b"beta alpha\n")], TEXT)
    assert first_part["part"] == "part-0001.bin" and second["part"] == "part-0002.bin"
    assert not list((tmp_path / "corpus").glob("*.writing"))
    again = Parts(tmp_path / "corpus")
    assert again.read("a.txt") == b"alpha beta\n" * 20
    assert again.read("big.txt") == b"one\ntwo\nthree\n" and again.holds("big.txt")
    assert again.type_of("b.txt") == "text" and not again.holds("c.txt")


def test_packed_files_are_taken_only_when_they_pack_back_the_same():
    """Intention: gzip and zlib open to their text and pack back to the very bytes; what does not is left alone."""
    text = b"the same line\n" * 200
    for raw, how in [(gzip.compress(text, 9, mtime=12345), GZIP), (zlib.compress(text, 6), ZLIB)]:
        got = opened(raw, how)
        assert got is not None and got[0] == text and packed(got[0], got[1], how) == raw
    assert opened(b"not packed at all", GZIP) is None


def test_a_part_is_as_big_as_the_free_memory_allows():
    """Intention: how many tags a part lifts is worked out from the memory free now, never a set number."""
    assert free_bytes() > 0 and tags_that_fit() >= 1


def test_smooth_codes_read_back_the_same_and_follow_the_information():
    """Intention: rANS over lanes gives the very numbers back for any length, and skewed numbers cost near their
    information, far under whole bytes."""
    rng = np.random.default_rng(11)
    skewed = rng.zipf(1.4, 200000).astype(np.int64)
    tags, counts = np.unique(skewed, return_counts=True)
    model = smooth.Model.of(tags, counts)
    assert model.shares.sum() == smooth.WHOLE and model.shares.min() >= 1
    for count in (0, 1, 2, 3, 17, 1000, 200000):
        assert np.array_equal(smooth.decode(smooth.encode(skewed[:count], model), model), skewed[:count])
    information = -(counts * np.log2(counts / counts.sum())).sum() / 8
    coded = len(smooth.encode(skewed, model))
    assert coded < size(skewed) * 0.85 and coded < information * 1.25
    digits = rng.integers(0, 10, 50000)
    kept = keep([digits])
    assert kept[0] == 2 and len(kept) < 50000 * 0.45 and np.array_equal(unkeep(kept)[0], digits)


def test_a_part_codes_its_notations_smoothly_when_smaller(tmp_path):
    """Intention: numbers in text (digits as tags) come out smaller than their text, through the smooth form."""
    rng = np.random.default_rng(5)
    things = [(f"s{n}.json", "text", ("[" + ", ".join(f"{v:.6f}" for v in rng.random(3000)) + "]").encode())
              for n in range(8)]
    (tmp_path / "f.bin").write_bytes(make(things, TEXT))
    part = Part(tmp_path / "f.bin")
    assert part.head["form"] == SMOOTH
    assert all(part.read(i) == held for i, (_n, _t, held) in enumerate(things))
    assert (tmp_path / "f.bin").stat().st_size < sum(len(h) for _n, _t, h in things) * 0.45
    part.close()


def test_a_part_that_would_not_be_smaller_is_not_put_in(tmp_path):
    """Intention: with the bytes the things take where they are said, a part no smaller than that stays out."""
    parts = Parts(tmp_path / "corpus")
    said = parts.add([("tiny.txt", "text", b"hi\n")], TEXT, worth=3)
    assert said["kept"] is False and not parts.files()
    assert parts.add([("big.txt", "text", b"the same line\n" * 500)], TEXT, worth=7000)["kept"] is True


def test_text_that_repeats_keeps_lifting_past_the_first_numbers():
    """Intention (1628c): a long text of a few words said over and over lifts to a small share of its pieces - new
    tags are priced by how often they stand, not by the order they were made in (which stopped the lift at once
    when the new tags' numbers passed 127)."""
    import zlib
    rng = np.random.default_rng(9)
    words = [b"w" + bytes([97 + n % 26]) * (1 + n // 26) for n in range(100)]   # a hundred base tags, as a capture has
    lines = [b'["' + b'","'.join(words[i] for i in rng.integers(0, 100, 30)) + b'"]\n' for _ in range(500)]
    text = b"".join(lines[i % 500] for i in rng.zipf(1.2, 20000))
    raw = make([("capture", "text", text)], TEXT)
    assert len(raw) < len(zlib.compress(text, 9)) / 7   # measured: 39 K against zlib's 381 K (priced by order: 70 K)
    assert Part(None, raw=raw).read(0) == text


def test_a_file_whose_pieces_lie_in_two_parts_reads_back_whole(tmp_path):
    """Intention (1631c): a part that fills in the middle of a big file leaves its pieces in two parts - both are
    read, in order; a file kept again from its first piece starts again."""
    parts = Parts(tmp_path / "corpus")
    parts.add([("a.txt", "text", b"whole one\n" * 50), ("big#1", "text", b"first half, " * 50)], TEXT)
    parts.add([("big#2", "text", b"second half\n" * 50)], TEXT)
    assert Parts(tmp_path / "corpus").read("big") == b"first half, " * 50 + b"second half\n" * 50
    parts.add([("big#1", "text", b"kept again in one piece\n" * 50)], TEXT)
    assert Parts(tmp_path / "corpus").read("big") == b"kept again in one piece\n" * 50
