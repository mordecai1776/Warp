# WARP2/warp2/corpus/varint.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/varint.py
#  Used by   : warp2/corpus/{grammar,fold,level,levels,part,parts,shelf}.py;
#              warp2/corpus/convert/{kg,state_text}.py; warp2/corpus/tests/.
#  Uses      : numpy.
#  Description:
#    NUMBERS AS THE BYTES THEY TAKE. A tag number is kept as a varint: seven
#    bits a byte, the high bit saying another byte follows - small numbers
#    take one byte, numbers under 16,384 two, under 2,097,152 three. `size`
#    says what a whole array of numbers takes, worked out at once (the
#    measure every "does the whole get smaller" is judged by); `pack` and
#    `unpack` write and read a whole array at once; `first` reads the one
#    number at the start of some bytes (a length before what it measures).
#  User intention (Andrew, 2026-11-13 20:49): the notation "incredibly
#    compressed". BUILD_LOG 1621c.
# ============================================================================
"""Arrays of non-negative numbers as varints, sized, packed and unpacked at once."""
from __future__ import annotations

import numpy as np

STEPS = (1 << 7, 1 << 14, 1 << 21, 1 << 28, 1 << 35, 1 << 42, 1 << 49, 1 << 56)


def lengths(values) -> np.ndarray:
    """Intention: how many bytes each number takes."""
    values = np.asarray(values, dtype=np.uint64)
    out = np.ones(values.shape, dtype=np.int64)
    top = int(values.max()) if values.size else 0
    for step in STEPS:
        if top < step:
            break  # Intention: no number reaches this many bytes - the rest of the steps change nothing
        out += values >= np.uint64(step)
    return out


def size(values) -> int:
    """Intention: the bytes a whole array of numbers takes."""
    return int(lengths(values).sum()) if np.size(values) else 0


def pack(values) -> bytes:
    """Intention: the numbers as one run of varints, in order."""
    values = np.asarray(values, dtype=np.uint64).ravel()
    if values.size == 0:
        return b""
    each = lengths(values)
    ends = np.cumsum(each)
    out = np.zeros(int(ends[-1]), dtype=np.uint8)
    starts = ends - each
    rest = values.copy()
    for byte in range(int(each.max())):
        live = each > byte
        at = starts[live] + byte
        low = (rest[live] & np.uint64(0x7F)).astype(np.uint8)
        more = (each[live] > byte + 1).astype(np.uint8) << 7
        out[at] = low | more
        rest[live] >>= np.uint64(7)
    return out.tobytes()


def unpack(raw: bytes) -> np.ndarray:
    """Intention: a run of varints back to its numbers, in order."""
    data = np.frombuffer(raw, dtype=np.uint8)
    if data.size == 0:
        return np.zeros(0, dtype=np.int64)
    ends = np.flatnonzero((data & 0x80) == 0)
    starts = np.concatenate([[0], ends[:-1] + 1])
    out = np.zeros(ends.size, dtype=np.uint64)
    longest = int((ends - starts).max()) + 1
    for byte in range(longest):
        live = starts + byte <= ends
        out[live] |= (data[starts[live] + byte] & np.uint64(0x7F)).astype(np.uint64) << np.uint64(7 * byte)
    return out.astype(np.int64)


def first(data) -> tuple:
    """Intention: the number at the start of these bytes and how many bytes it took."""
    number = shift = used = 0
    for byte in memoryview(data).cast("B"):
        number |= (byte & 0x7F) << shift
        shift += 7
        used += 1
        if not byte & 0x80:
            break
    return number, used
