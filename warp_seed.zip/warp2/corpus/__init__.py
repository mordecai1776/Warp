# WARP2/warp2/corpus/__init__.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/__init__.py
#  Used by   : warp2/corpus/* and warp2/corpus/convert/* and their tests
#              (the package).
#  Uses      : nothing.
#  Description:
#    THE CORPUS OF TAGS (BUILD_LOG 1621c). Every thing the warp keeps is an
#    anchor: what it is, what kind of information it holds, and its notation
#    - a short list of tag numbers. One corpus of tags holds what the tags
#    stand for: base tags (the smallest pieces of a kind of information) and
#    higher tags, each made of tags already in the corpus. A higher tag is
#    made only when the whole (corpus and every notation) gets smaller for it,
#    and folded back when it stops paying; the corpus is kept the same way
#    over a corpus of its own, level over level, until a level no longer
#    gains. A thing is read back by expanding its notation from the corpus,
#    exactly.
#      varint.py  - numbers as the bytes they take (the measure of everything)
#      grammar.py - repeats lifted into higher tags while the whole gets smaller
#      fold.py    - a tag that stops paying folded back into the tags that use it
#      expand.py  - notations expanded back to base tags, exactly
#      level.py   - one level: base tags, higher tags numbered by use
#      levels.py  - any list of notations kept plain, smooth or lifted over a
#                   corpus of its own, level after level, until nothing gains
#      smooth.py  - tags coded to their information (rANS over lanes)
#      tokens.py  - text cut into words, digits, spaces and single bytes
#      part.py    - a part on disk: the corpus and the anchors (name, type,
#                   notation) over it
#      parts.py   - a corpus's parts in one folder; found by name, read back
#      shelf.py   - every corpus of the warp, with what each measures
#      convert/   - what the warp holds put into corpus form
#  User intention (Andrew, 2026-11-13 20:45-21:03): files as anchors with
#    their web tags as a "more and more and more compressed notation"; "a
#    corpus of tags ... will hold the bigger information, so it's just a
#    matter of decompressing from that corpus"; it "grows slowly over time"
#    while "what it represents keeps getting bigger"; "that should be the
#    structure of the knowledge graph itself", with the connections "still
#    in that kind of structure"; "nest and still be searchable"; "the corpus
#    should also be keept like this with its own corpus ... until it no
#    longer gives gains"; "Do not stop until everything is converted".
#    Design doc: claude/kg_as_tag_corpus_design_2026_11_13.md.
# ============================================================================
