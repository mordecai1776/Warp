# WARP2/warp2/corpus/columns.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/columns.py
#  Used by   : warp2/corpus/convert/view.py (the KG's facts in corpus form);
#              warp2/corpus/tests/.
#  Uses      : warp2/corpus/{levels,part,varint}.py; (stdlib) json.
#  Description:
#    A TABLE AS ANCHORS OVER A CORPUS: each column of a block of rows is a
#    notation of numbers, kept the smallest of the corpus's ways (levels.py:
#    plain, smooth, or lifted over a corpus of its own), and the words the
#    columns point at - every distinct text once - are a text part over the
#    text corpus (part.py), one numbering shared by every column (a subject
#    and an object that are the same word are the same tag). `pack` writes a
#    block; `Columns` opens one and gives each column back, exactly.
#  User intention (Andrew, 2026-11-13 20:52): "That should be the structure
#    of the knowledge graph itself. And then it should have the other part of
#    the knowledge graph on top of it to connect everything. But all those
#    connections should still be in that kind of structure." BUILD_LOG 1624c.
# ============================================================================
"""A block of rows as column notations plus one shared word table, kept in corpus form."""
from __future__ import annotations

import json

import numpy as np

from warp2.corpus.levels import keep, unkeep
from warp2.corpus.part import TEXT, Part, make
from warp2.corpus.varint import first, pack

MAGIC = b"WARP2 CORPUS COLUMNS 1\n"
JOIN = b"\x00"   # Intention: between two words in the word table - a byte no word of the view holds


def pack_block(columns: dict, words: list, head: dict) -> bytes:
    """Intention: a block's bytes - its head, each column kept the smallest way, and its word table as a text part
    (word n is the n-th, counted from 1; 0 is "no word")."""
    sections, body, at = {}, [], 0
    for name, numbers in columns.items():
        raw = keep([np.asarray(numbers, dtype=np.int64)])
        sections[name] = [at, len(raw)]
        body.append(raw)
        at += len(raw)
    table = make([("words", "word table", JOIN.join(word.encode("utf-8", "surrogatepass") for word in words))], TEXT)
    sections["words"] = [at, len(table)]
    body.append(table)
    raw_head = json.dumps({**head, "sections": sections, "words": len(words)}, separators=(",", ":")).encode("utf-8")
    return MAGIC + pack([len(raw_head)]) + raw_head + b"".join(body)


class Columns:
    """Intention: one block opened - its head, and each column or the word table given back when asked."""

    def __init__(self, raw: bytes) -> None:
        """Intention: the block's bytes (read whole: a block is small)."""
        if raw[:len(MAGIC)] != MAGIC:
            raise ValueError("not a block of columns")
        length, used = first(raw[len(MAGIC):])
        start = len(MAGIC) + used
        self.head = json.loads(raw[start:start + length])
        self._raw, self._body = raw, start + length

    def _section(self, name: str) -> bytes:
        """Intention: one section's bytes."""
        at, length = self.head["sections"][name]
        return self._raw[self._body + at:self._body + at + length]

    def column(self, name: str) -> np.ndarray:
        """Intention: one column's numbers, exactly as they were packed."""
        return unkeep(self._section(name))[0]

    def words(self) -> list:
        """Intention: the word table - word n at place n - 1."""
        part = Part(None, raw=self._section("words"))
        text = part.read(0)
        return [word.decode("utf-8", "surrogatepass") for word in text.split(JOIN)] if self.head["words"] else []
