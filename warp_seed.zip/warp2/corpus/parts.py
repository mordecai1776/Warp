# WARP2/warp2/corpus/parts.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/parts.py
#  Used by   : warp2/corpus/convert/{kg,state_text}.py (things kept);
#              warp2/tags/dehydrated/lane_source.py (a KG segment read from
#              its corpus when its own file is not there); warp2/corpus/
#              shelf.py; warp2/corpus/tests/.
#  Uses      : warp2/corpus/part.py; warp2/util.py (atomic_write_bytes,
#              replace - the tree's one writer of whole files); numpy;
#              (stdlib) os, pathlib.
#  Description:
#    A CORPUS ON DISK: the parts in one folder (part-0001.bin, ...). New
#    things go in as a new part, and a part goes in only when it is smaller
#    than what the things take where they are (when that is said - a tag
#    enters only when the whole gets smaller, so a whole part too) and every
#    thing in it reads back exactly as it was given (written beside as .writing first,
#    renamed in after - never half there). A thing too big to be lifted at once is kept as pieces named
#    "<name>#<n>" and read back joined. Which part holds which name is
#    worked out from the parts themselves when first asked.
#  User intention (Andrew, 2026-11-13 21:03): "Do not stop until everything
#    is converted"; 21:05: "hide higher forms in each things corpus of
#    tags". BUILD_LOG 1621c.
# ============================================================================
"""The parts of one corpus in a folder: kept, found by name, read back exactly."""
from __future__ import annotations

import os
from pathlib import Path

import numpy as np

from warp2.corpus.part import NUMBERS, TEXT, Part, make
from warp2.util import atomic_write_bytes, replace

PIECE = "#"


class Parts:
    """Intention: one corpus's parts in one folder."""

    def __init__(self, folder) -> None:
        """Intention: the folder the parts are in (made when the first part is written)."""
        self.folder = Path(folder)
        self._open: dict = {}
        self._where: dict | None = None
        self._seen: tuple = ()

    def files(self) -> list:
        """Intention: the parts on disk, oldest first."""
        return sorted(self.folder.glob("part-*.bin")) if self.folder.is_dir() else []

    def _part(self, path: Path) -> Part:
        """Intention: a part opened once and kept open."""
        if path not in self._open:
            self._open[path] = Part(path)
        return self._open[path]

    def where(self) -> dict:
        """Intention: every name held -> its places [(part, place)]; a thing kept in pieces is under its own name
        with every piece in order - its pieces may lie in more than one part (1631c: a part fills in the middle of
        a big file; taking only the last part's pieces gave half a file back). A thing kept again later (written
        since) starts again from the part that holds it whole or holds its first piece; pieces after that are
        taken from whichever part holds them. Worked out again when the parts on disk have changed. A part another
        run is putting in place this very moment (1634c: Windows will not let it be opened while it is renamed) is
        read the next time; at worst a file is kept once more, and the later part is the one read."""
        files = tuple(self.files())
        if self._where is None or files != self._seen:
            current: dict = {}
            unseen = False
            for path in files:
                here: dict = {}
                try:
                    names = self._part(path).names()
                except PermissionError:  # fault: ok another run is putting this part in place this moment; it is read next time
                    unseen = True
                    continue
                for at, name in enumerate(names):
                    whole, cut, number = name.rpartition(PIECE)
                    if cut and number.isdigit():
                        here.setdefault(whole, {})[int(number)] = (path, at)
                    else:
                        current[name] = {0: (path, at)}
                for whole, pieces in here.items():
                    if 1 in pieces or whole not in current or 0 in current[whole]:
                        current[whole] = dict(pieces)
                    else:
                        current[whole].update(pieces)
            where = {name: [current[name][number] for number in sorted(current[name])] for name in current}
            self._where, self._seen = where, (None if unseen else files)
        return self._where

    def stamp_of(self, name: str) -> int:
        """Intention: the time the thing was written when it was kept (0 when none was said)."""
        path, at = self.where()[str(name)][0]
        return self._part(path).stamp_of(at)

    def holds(self, name: str) -> bool:
        """Intention: whether a thing with this name is kept here."""
        return str(name) in self.where()

    def read(self, name: str):
        """Intention: the thing back exactly - bytes for text, numbers for numbers - joined from its pieces when it
        was kept in pieces."""
        places = self.where().get(str(name))
        if not places:
            raise KeyError(name)
        held = [self._part(path).read(at) for path, at in places]
        if isinstance(held[0], bytes):
            return b"".join(held)
        return np.concatenate(held) if len(held) > 1 else held[0]

    def head(self, path) -> dict:
        """Intention: what a part says of itself - how many things, its measures, its sections."""
        return self._part(Path(path)).head

    def type_of(self, name: str) -> str:
        """Intention: the kind of information the thing with this name holds."""
        places = self.where().get(str(name))
        if not places:
            raise KeyError(name)
        path, at = places[0]
        return self._part(path).type_of(at)

    def add(self, things: list, base: str, say=None, stamps=None, worth=None) -> dict:
        """Intention: things kept as one new part (with the time each was written, when said); the part goes in only
        when every thing reads back the same - and, when `worth` is said (the bytes the things take where they are
        now), only when the part is smaller than that: otherwise their own form is the smaller and they stay in it
        (the measures say "kept": False). Gives the part's measures and its name."""
        raw = make(things, base, say, stamps)
        if worth is not None and len(raw) >= worth:
            return {"kept": False, "bytes": len(raw), "worth": int(worth), "things": len(things)}
        self.folder.mkdir(parents=True, exist_ok=True)
        number = len(self.files()) + 1
        while True:
            final = self.folder / f"part-{number:04d}.bin"
            beside = final.with_suffix(".writing")
            if not final.exists() and _claimed(beside):
                break
            number += 1
        atomic_write_bytes(beside, raw)
        check = Part(beside)
        try:
            for at, (name, _type, held) in enumerate(things):
                back = check.read(at)
                same = back == bytes(held) if base == TEXT else np.array_equal(back, np.asarray(held, dtype=np.int64))
                if not same:
                    raise ValueError(f"{name} did not read back the same from the new part")
            measures = dict(check.head["measures"])
        finally:
            check.close()
        replace(beside, final)
        measures["part"] = final.name
        measures["bytes"] = len(raw)
        measures["kept"] = True
        return measures


def _claimed(path: Path) -> bool:
    """Intention (1622c): this part's number taken by one writer only - two writers (the KG's turn and a
    conversion run) never write the same part; a number already taken is passed over."""
    try:
        os.close(os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
        return True
    except FileExistsError:  # fault: ok another writer holds this number; the caller tries the next
        return False


__all__ = ["Parts", "PIECE", "TEXT", "NUMBERS"]
