# WARP2/warp2/corpus/tokens.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/tokens.py
#  Used by   : warp2/corpus/part.py (a text thing cut into base tags);
#              warp2/corpus/tests/.
#  Uses      : (stdlib) re; numpy.
#  Description:
#    TEXT CUT INTO ITS SMALLEST PIECES, EXACTLY. The base tags of text are
#    its words (letters and _ together), each digit on its own (numbers are
#    made of digit tags, so a corpus of ten tags holds every number - kept
#    whole, measured, each distinct number became a tag of its own and a
#    part of floats came out larger than its text), its runs of white
#    space, and every other byte on its own; laid back side by side they are the
#    very bytes they came from, whatever the bytes are. `table` gives every
#    distinct piece once, in sorted order, and each thing's pieces as places
#    in that table (its notation over base tags).
#  User intention (Andrew, 2026-11-13 20:49): "Every file should just be a
#    group of tags"; the type of information and the file itself are what
#    cannot be reduced. BUILD_LOG 1621c.
# ============================================================================
"""Exact cutting of bytes into word, space and single-byte pieces, and the table of distinct pieces."""
from __future__ import annotations

import re

import numpy as np

_PIECE = re.compile(rb"[A-Za-z_]+|[0-9]|\s+|[^A-Za-z0-9_\s]", re.S)


def pieces(raw: bytes) -> list:
    """Intention: the bytes cut into pieces whose joining is the bytes again."""
    return _PIECE.findall(raw)


def table(things) -> tuple:
    """Intention: (every distinct piece once, sorted; each thing's notation as places in that list)."""
    cut = [pieces(raw) for raw in things]
    seen: dict = {}
    for each in cut:
        for piece in each:
            if piece not in seen:
                seen[piece] = len(seen)
    distinct = sorted(seen)
    place = np.empty(len(seen), dtype=np.int64)
    for at, piece in enumerate(distinct):
        place[seen[piece]] = at
    notations = [place[np.fromiter((seen[p] for p in each), dtype=np.int64, count=len(each))] for each in cut]
    return distinct, notations


def joined(distinct: list, notation) -> bytes:
    """Intention: a notation of places in the table back as its bytes."""
    return b"".join(distinct[int(at)] for at in notation)
