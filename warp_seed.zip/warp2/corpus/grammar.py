# WARP2/warp2/corpus/grammar.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/grammar.py
#  Used by   : warp2/corpus/{corpus,levels}.py; warp2/corpus/tests/.
#  Uses      : warp2/corpus/varint.py; numpy.
#  Description:
#    REPEATS LIFTED INTO HIGHER TAGS WHILE THE WHOLE GETS SMALLER (Re-Pair,
#    Larsson & Moffat 2000, judged by minimum description length).
#    The notations of many things are laid end to end with a gap between
#    them (no tag is made across two things). Each turn: every pair of tags
#    side by side is counted; a pair becomes a higher tag only when what it
#    saves in every notation that holds it is more than what it costs the
#    corpus to hold it (its two parts) - so the corpus grows only when the
#    whole gets smaller. Many pairs are made in one turn, in the order of
#    what they save, as long as no two of them can claim the same place
#    (a pair whose second tag is another pair's first waits for a later
#    turn); a pair of one tag twice (a run) takes every other place. The
#    turns go on until no pair pays - no count, size or turn is set.
#  User intention (Andrew, 2026-11-13 20:49-20:51): "a more and more and
#    more compressed notation"; the corpus "grows slowly over time" while
#    "what it represents keeps getting bigger". BUILD_LOG 1621c.
# ============================================================================
"""Re-Pair over many notations at once, each new tag made only when the whole gets smaller."""
from __future__ import annotations

import numpy as np

from warp2.corpus.varint import lengths

GAP = -1          # Intention: between two things' notations; never part of a tag.
_SHIFT = np.int64(1 << 31)


def laid_out(notations) -> tuple:
    """Intention: the notations end to end with a gap after each, and where each starts (to cut them apart again)."""
    pieces, starts, at = [], [], 0
    for notation in notations:
        notation = np.asarray(notation, dtype=np.int64)
        starts.append(at)
        pieces.append(notation)
        pieces.append(np.array([GAP], dtype=np.int64))
        at += notation.size + 1
    if not pieces:
        return np.zeros(0, dtype=np.int64), np.zeros(0, dtype=np.int64)
    return np.concatenate(pieces), np.asarray(starts, dtype=np.int64)


def cut_apart(sequence: np.ndarray) -> list:
    """Intention: the laid-out notations back as one array each (the gaps say where one ends)."""
    ends = np.flatnonzero(sequence == GAP)
    begins = np.concatenate([[0], ends[:-1] + 1]) if ends.size else np.zeros(0, dtype=np.int64)
    return [sequence[b:e] for b, e in zip(begins, ends)]


def _paying(sequence: np.ndarray, next_tag: int) -> tuple:
    """Intention: the pairs worth a tag this turn - (place of each pair, its key) and the chosen keys in the order
    of what they save. A pair is worth a tag when count x (bytes its two parts take - bytes the new tag takes) is
    more than the bytes the corpus takes to hold it (its two parts and their count) - every tag priced by how often
    it stands (_priced), as it will be numbered."""
    first, second = sequence[:-1], sequence[1:]
    live = np.flatnonzero((first >= 0) & (second >= 0))
    if live.size == 0:
        return live, live, live
    keys = first[live] * _SHIFT + second[live]
    unique, counts = np.unique(keys, return_counts=True)
    left, right = unique // _SHIFT, unique % _SHIFT
    standing = sequence[sequence >= 0]
    cost = _priced(standing)
    used = np.bincount(standing)
    parts = cost(used[left]) + cost(used[right])
    saved = counts * (parts - cost(counts)) - (parts + 1)
    worth = np.flatnonzero((counts > 1) & (saved > 0))
    if worth.size == 0:
        return live, keys, worth
    order = worth[np.argsort(-saved[worth], kind="stable")]
    return live, keys, _apart(unique[order], left[order], right[order])


def _priced(standing: np.ndarray):
    """Intention (1628c): what a tag will cost each place it stands, from how often it stands - every tag is
    numbered by how much it is used in the end (level.py), so a tag used c times takes the bytes of the number of
    tags used more than c. (Priced by the order it was made in, the new tags' numbers passed 127 after the first
    turns and no pair ever paid again: a raw capture of 17.6 MB stopped after 3 turns at 5.2 M tags; gzip 0.18 MB.)"""
    used = np.sort(np.bincount(standing))[::-1]
    used = used[used > 0]

    def cost(count) -> np.ndarray:
        """Intention: the bytes a tag used `count` times will take each place it stands."""
        return lengths(np.searchsorted(-used, -np.asarray(count), side="left"))
    return cost


def _apart(ranked: np.ndarray, left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Intention: of the pairs in the order of what they save, every one that cannot claim the same place as one
    already taken this turn - a pair waits when a taken pair ends with its first tag or begins with its second
    (they could overlap); a pair of one tag twice is taken alone among its tag's pairs and takes every other place
    of a run (_one_turn)."""
    taken, firsts, seconds = [], set(), set()
    for at, (first, second) in enumerate(zip(left.tolist(), right.tolist())):
        if first in seconds or second in firsts:
            continue
        taken.append(at)
        firsts.add(first)
        seconds.add(second)
    return ranked[np.asarray(taken, dtype=np.int64)]


def _one_turn(sequence: np.ndarray, next_tag: int) -> tuple:
    """Intention: one turn - the paying pairs replaced by new tags; (the shorter sequence, the new tags' parts)."""
    live, keys, chosen = _paying(sequence, next_tag)
    if chosen.size == 0:
        return sequence, np.zeros((0, 2), dtype=np.int64)
    sorted_chosen = np.sort(chosen)
    where = np.searchsorted(sorted_chosen, keys)
    where[where >= sorted_chosen.size] = 0
    hit = sorted_chosen[where] == keys
    place = np.zeros(sequence.size, dtype=bool)
    place[live[hit]] = True
    # Intention: a run of one tag twice over (a, a, a) - every other place, from the start of the run.
    begins = place & ~np.concatenate([[False], place[:-1]])
    index = np.arange(sequence.size)
    run_start = np.maximum.accumulate(np.where(begins, index, 0))
    place &= ((index - run_start) % 2) == 0
    new_of_key = np.argsort(chosen, kind="stable")  # Intention: for each key in sorted order, its place by what it saves
    at = np.flatnonzero(place)
    out = sequence.copy()
    found = np.searchsorted(sorted_chosen, sequence[at] * _SHIFT + sequence[at + 1])
    out[at] = next_tag + new_of_key[found]
    drop = np.zeros(sequence.size, dtype=bool)
    drop[at + 1] = True
    parts = np.stack([chosen // _SHIFT, chosen % _SHIFT], axis=1)
    return out[~drop], parts


def lift(sequence: np.ndarray, next_tag: int, say=None) -> tuple:
    """Intention: turns until no pair pays; (the sequence in higher tags, the parts of every new tag in order -
    tag next_tag + i is made of parts[i])."""
    made = []
    turns = 0
    while True:
        sequence, parts = _one_turn(sequence, next_tag)
        if parts.shape[0] == 0:
            break
        made.append(parts)
        next_tag += parts.shape[0]
        turns += 1
        if say is not None:
            say({"turn": turns, "new_tags": int(parts.shape[0]), "left": int(sequence.size)})
    parts = np.concatenate(made) if made else np.zeros((0, 2), dtype=np.int64)
    return sequence, parts
