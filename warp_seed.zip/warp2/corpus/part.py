# WARP2/warp2/corpus/part.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/part.py
#  Used by   : warp2/corpus/{shelf,part_of}.py; warp2/corpus/convert/*.py;
#              warp2/corpus/tests/.
#  Uses      : warp2/corpus/{varint,grammar,level,levels,tokens,expand,smooth}.py;
#              warp2/util.py (atomic_write_bytes); (stdlib) json, mmap.
#  Description:
#    ONE PART OF A CORPUS ON DISK: its tags and the anchors over them.
#      the corpus - the base tags' values (band by band, as steps), the band
#                   table, the higher tags' parts; for text also the table of
#                   pieces (words, spaces, single bytes) the values point at.
#                   All of it kept by levels.py: lifted over a corpus of its
#                   own while that gains.
#      the anchors - each thing's name (its identity) and type (the kind of
#                   information it holds), both kept the same way, and its
#                   notation: the tags it is, in the corpus's numbers - each
#                   notation as whole-byte numbers on its own (one read
#                   without the rest), or all of them coded to their
#                   information as one stream with the part's model of how
#                   often each tag stands (smooth.py, read once when the part
#                   is first asked), whichever is smaller;
#                   and, when said, the time each thing was written when it
#                   was kept.
#    `make` builds the bytes from things; `Part` opens them (mapped, not read
#    whole) and gives a thing back exactly by expanding its notation. The
#    numbers a part is measured by (what its things take as they are, what
#    the corpus takes, what the notations take) are in its head.
#  User intention (Andrew, 2026-11-13 20:49-21:05): "the files with their
#    tags that are incredibly compressed, and the web tags are the
#    signifier of what's in there ... Then there should be a corpus of
#    tags"; "keep the ease of this form but hide higher forms in each
#    things corpus of tags". BUILD_LOG 1621c.
# ============================================================================
"""A corpus part: base and higher tags plus the anchors (name, type, notation) over them."""
from __future__ import annotations

import json
import mmap
from pathlib import Path

import numpy as np

from warp2.corpus import smooth, tokens
from warp2.corpus.expand import expand
from warp2.corpus.grammar import laid_out, cut_apart
from warp2.corpus.level import kinds_of, make as make_level
from warp2.corpus.levels import keep, unkeep
from warp2.corpus.varint import first, pack, unpack

MAGIC = b"WARP2 CORPUS PART 1\n"
TEXT, NUMBERS = "text", "numbers"
PLAIN, SMOOTH = 0, 1   # Intention: a notation kept as whole-byte numbers, or coded to its information (smooth.py)


def _as_numbers(raw: bytes) -> np.ndarray:
    """Intention: bytes as a notation of byte values."""
    return np.frombuffer(raw, dtype=np.uint8).astype(np.int64)


def make(things: list, base: str, say=None, stamps=None) -> bytes:
    """Intention: a part's bytes from things - each (name, type, what it holds): bytes for TEXT, a list of
    numbers (not negative) for NUMBERS - and, when said, the time each was written (so a reader knows whether
    the thing on disk was written since)."""
    names = [str(name) for name, _type, _held in things]
    kinds = sorted({str(kind) for _name, kind, _held in things})
    if base == TEXT:
        distinct, notations = tokens.table([bytes(held) for _n, _t, held in things])
        hydrated = sum(len(held) for _n, _t, held in things)
    else:
        distinct = []
        notations = [np.asarray(held, dtype=np.int64) for _n, _t, held in things]
        hydrated = sum(len(pack(each)) for each in notations)
    laid, _starts = laid_out(notations)
    level = make_level(laid, say)
    ends = np.cumsum(level.bands[:, 0])
    values = [level.values[end - count:end] for count, end in zip(level.bands[:, 0], ends)]
    notations_now = cut_apart(level.laid)
    form, model, written, places = _notations(notations_now, level.laid[level.laid >= 0])
    sections = {
        "values": keep([np.diff(each, prepend=0) if each.size else each for each in values]),
        "bands": pack(level.bands.reshape(-1)),
        "parts": keep([level.flat[level.offsets[i]:level.offsets[i + 1]] for i in range(level.offsets.size - 1)]),
        "pieces": keep([_as_numbers(each) for each in distinct]) if base == TEXT else b"",
        "names": keep([_as_numbers(name.encode("utf-8")) for name in names]),
        "types": pack([kinds.index(str(kind)) for _n, kind, _h in things]),
        "model": keep(model.written()) if form == SMOOTH else b"",
        "places": pack(places),
        "stamps": b"" if stamps is None else pack(_folded(np.diff(np.asarray(stamps, dtype=np.int64), prepend=0))),
        "notations": b"".join(written),
    }
    head, body, at = {"base": base, "things": len(things), "types": kinds, "form": form, "sections": {}}, [], 0
    for name, raw in sections.items():
        head["sections"][name] = [at, len(raw)]
        body.append(raw)
        at += len(raw)
    corpus = sum(len(sections[name]) for name in ("values", "bands", "parts", "pieces", "model"))
    head["measures"] = {"hydrated": int(hydrated), "corpus": int(corpus), "anchors": len(sections["names"]) +
                        len(sections["types"]) + len(sections["places"]), "notations": len(sections["notations"]),
                        "base_tags": int(level.values.size), "higher_tags": int(level.offsets.size - 1)}
    raw_head = json.dumps(head, separators=(",", ":")).encode("utf-8")
    return MAGIC + pack([len(raw_head)]) + raw_head + b"".join(body)


def _folded(steps: np.ndarray) -> np.ndarray:
    """Intention: steps that may be negative as numbers that are not (0, -1, 1, -2 ... as 0, 1, 2, 3 ...)."""
    return np.where(steps >= 0, steps * 2, -steps * 2 - 1)


def _unfolded(numbers: np.ndarray) -> np.ndarray:
    """Intention: the steps `_folded` was given."""
    return np.where(numbers % 2 == 0, numbers // 2, -(numbers + 1) // 2)


def _notations(notations: list, standing: np.ndarray) -> tuple:
    """Intention: (form, model, the notations' bytes, places) - kept as whole-byte numbers each on its own (one read
    without the rest), or all coded to their information as one stream with the part's model of how often each tag
    stands (smooth.py) - whichever is smaller. Places are each notation's bytes (whole-byte) or tags (coded)."""
    plain = [pack(each) for each in notations]
    plain_places = [len(each) for each in plain]
    tags, how_often = np.unique(standing, return_counts=True)
    model = smooth.Model.of(tags, how_often)
    sizes = [each.size for each in notations]
    coded = smooth.encode(np.concatenate(notations) if notations else np.zeros(0, dtype=np.int64), model)
    if len(coded) + len(keep(model.written())) + len(pack(sizes)) < sum(plain_places) + len(pack(plain_places)):
        return SMOOTH, model, [coded], sizes
    return PLAIN, model, plain, plain_places


class Part:
    """Intention: a part opened for reading - the corpus taken in once, each notation read only when asked."""

    def __init__(self, path, raw=None) -> None:
        """Intention: the part at this path, mapped - or a part already in memory, given as its bytes (1624c: a
        part inside a larger file); its head read."""
        self.path = Path(path) if path is not None else None
        if raw is None:
            self._file = open(self.path, "rb")  # fault: ok a part that cannot be opened raises to its caller
            self._map = mmap.mmap(self._file.fileno(), 0, access=mmap.ACCESS_READ)
        else:
            self._file, self._map = None, bytes(raw)
        if self._map[:len(MAGIC)] != MAGIC:
            raise ValueError(f"{self.path.name if self.path else 'these bytes'} are not a corpus part")
        length, used = first(self._map[len(MAGIC):len(MAGIC) + 10])
        start = len(MAGIC) + used
        self.head = json.loads(self._map[start:start + length])
        self._body = start + length
        self._corpus = None
        self._names = None
        self._stamps = None
        self._all = None

    def close(self) -> None:
        """Intention: the mapping and file let go (a part in memory has none)."""
        if self._file is not None:
            self._map.close()
            self._file.close()

    def section(self, name: str) -> bytes:
        """Intention: one section's bytes."""
        at, length = self.head["sections"][name]
        return self._map[self._body + at:self._body + at + length]

    def corpus(self) -> dict:
        """Intention: the corpus of this part (values, kinds, parts, pieces), taken in once."""
        if self._corpus is None:
            bands = unpack(self.section("bands")).reshape(-1, 2)
            steps = unkeep(self.section("values"))
            values = np.concatenate([np.cumsum(each) for each in steps]) if steps else np.zeros(0, dtype=np.int64)
            parts = unkeep(self.section("parts"))
            widths = np.asarray([each.size for each in parts], dtype=np.int64)
            higher, row = kinds_of(bands)
            pieces = [bytes(each.astype(np.uint8)) for each in unkeep(self.section("pieces"))] \
                if self.head["base"] == TEXT else []
            self._corpus = {"values": values, "higher": higher, "row": row, "pieces": pieces,
                            "offsets": np.concatenate([[0], np.cumsum(widths)]).astype(np.int64),
                            "flat": np.concatenate(parts) if parts else np.zeros(0, dtype=np.int64)}
            places = unpack(self.section("places"))
            self._starts = np.concatenate([[0], np.cumsum(places)]).astype(np.int64)
            if self.head.get("form", PLAIN) == SMOOTH:
                model = smooth.Model.read(unkeep(self.section("model")))
                self._all = smooth.decode(self.section("notations"), model)   # Intention: every notation, read once
            self._types = unpack(self.section("types"))
        return self._corpus

    def names(self) -> list:
        """Intention: every anchor's name, in order."""
        if self._names is None:
            self._names = [bytes(each.astype(np.uint8)).decode("utf-8") for each in unkeep(self.section("names"))]
            self._index = {name: at for at, name in enumerate(self._names)}
        return self._names

    def where(self, name: str) -> int:
        """Intention: the place of the anchor with this name; -1 when this part has none."""
        self.names()
        return self._index.get(str(name), -1)

    def type_of(self, at: int) -> str:
        """Intention: the kind of information the anchor at this place holds."""
        self.corpus()
        return self.head["types"][int(self._types[at])]

    def stamp_of(self, at: int) -> int:
        """Intention: the time the thing at this place was written when it was kept; 0 when the part says none."""
        if self._stamps is None:
            raw = self.section("stamps") if "stamps" in self.head["sections"] else b""
            self._stamps = np.cumsum(_unfolded(unpack(raw))) if raw else np.zeros(0, dtype=np.int64)
        return int(self._stamps[at]) if at < self._stamps.size else 0

    def notation(self, at: int) -> np.ndarray:
        """Intention: the tags the anchor at this place is, in the corpus's numbers."""
        self.corpus()
        start, end = self._starts[at], self._starts[at + 1]
        if self.head.get("form", PLAIN) == SMOOTH:
            return self._all[start:end]
        at_notations = self.head["sections"]["notations"][0]
        return unpack(self._map[self._body + at_notations + start:self._body + at_notations + end])

    def read(self, which):
        """Intention: a thing back exactly - bytes for text, its numbers for numbers - by its name or place."""
        at = self.where(which) if isinstance(which, str) else int(which)
        if at < 0:
            raise KeyError(which)
        corpus = self.corpus()
        opened = expand(self.notation(at), corpus["higher"], corpus["offsets"], corpus["flat"], corpus["row"])
        values = corpus["values"][corpus["row"][opened]]
        if self.head["base"] == TEXT:
            return tokens.joined(corpus["pieces"], values)
        return values

