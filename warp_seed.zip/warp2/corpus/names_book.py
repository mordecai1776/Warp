# WARP3/warp2/corpus/names_book.py
#
# ============================================================================
#  Pathway   : WARP3/warp2/corpus/names_book.py
#  Used by   : warp2/corpus/parts.py (Parts.where - which part holds which
#              name); warp2/corpus/tests/test_a_corpus_finds_its_names_without_opening_every_part.py.
#  Uses      : warp2/record/stop.py (runtime_dir - the machine's own runtime
#              folder, not the state); warp2/util.py (atomic_write_bytes);
#              (stdlib) gzip, hashlib, json, pathlib.
#  Description:
#    THE NAMES EACH PART HOLDS, KEPT BESIDE THE WARP SO A NEW PROCESS DOES NOT
#    OPEN EVERY PART TO FIND THEM. Parts.where used to open every part of a
#    corpus (7,083 parts in state/corpus/text/archive) and read its names,
#    once in every new process - and dehydrate_what_is_not runs in a new
#    child each turn, so its whole turn went on that, and it kept nothing for
#    days (BUILD_LOG 2262). Here each part's names are kept with the part's
#    size and write time; a part whose size or write time is not the same is
#    read again. It is a copy of what the parts themselves say, kept in the
#    runtime folder (never in the state, so the state is no bigger); lost or
#    unreadable, it is simply made again from the parts.
#  User intention (Andrew, 2026-11-14 22:25): "Let's get a system to look for
#    nondehydrated things and dehydrates them and puts them in the smaller
#    kg." (2026-11-13 20:35) "everything needs to be in and run from a fully
#    dehydrated form."
# ============================================================================
"""The names each part of a corpus holds, kept beside the warp by the part's size and write time."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path


def book_path(folder) -> Path:
    """Intention: where the names of this corpus folder's parts are kept - the runtime folder, one file per folder."""
    from warp2.record.stop import runtime_dir
    key = hashlib.sha1(str(Path(folder).resolve()).encode("utf-8")).hexdigest()[:16]
    return runtime_dir() / "corpus_names" / f"{key}.json.gz"


class NamesBook:
    """Intention: each part's (size, write time, names), read once from the runtime folder and written back when new."""

    def __init__(self, folder) -> None:
        """Intention: the corpus folder; its book read when first asked."""
        self.folder = Path(folder)
        self._held: dict | None = None
        self._changed = False

    def _book(self) -> dict:
        """Intention: the book as kept; an unreadable or missing one is an empty book (made again from the parts)."""
        if self._held is None:
            try:
                kept = json.loads(gzip.decompress(book_path(self.folder).read_bytes()))
                self._held = kept if isinstance(kept, dict) else {}
            except Exception:  # fault: ok a book lost or half there is made again from the parts themselves
                self._held = {}
        return self._held

    def names(self, path: Path, read_names) -> list:
        """Intention: the names the part at `path` holds - from the book when its size and write time are the same,
        else read from the part (`read_names(path)`) and written in the book."""
        seen = path.stat()
        mark = [int(seen.st_size), int(seen.st_mtime_ns)]
        book = self._book()
        kept = book.get(path.name)
        if isinstance(kept, list) and len(kept) == 3 and kept[:2] == mark:
            return kept[2]
        names = list(read_names(path))
        book[path.name] = [mark[0], mark[1], names]
        self._changed = True
        return names

    def keep(self, files) -> None:
        """Intention: the book written back when it changed - only the parts still there kept in it."""
        if not self._changed or self._held is None:
            return
        there = {Path(each).name for each in files}
        book = {name: held for name, held in self._held.items() if name in there}
        try:
            from warp2.util import atomic_write_bytes
            atomic_write_bytes(book_path(self.folder), gzip.compress(json.dumps(book).encode("utf-8"), 6))
            self._changed = False
        except OSError:  # fault: ok a book that cannot be written now is made again next time; nothing is lost
            pass


__all__ = ["NamesBook", "book_path"]
