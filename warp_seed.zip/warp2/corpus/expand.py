# WARP2/warp2/corpus/expand.py
#
# ============================================================================
#  Pathway   : WARP2/warp2/corpus/expand.py
#  Used by   : warp2/corpus/{fold,corpus}.py; warp2/corpus/tests/.
#  Uses      : numpy.
#  Description:
#    NOTATIONS EXPANDED BACK, EXACTLY. A tag that is made of tags is put in
#    its place by its parts, all such tags at once, again and again until
#    only the tags that are not made of others are left. `which` says which
#    tags to open (all higher tags when reading a thing; only the ones being
#    folded back when the corpus lets a tag go). Nothing is expanded but
#    what is asked for.
#  User intention (Andrew, 2026-11-13 20:49): "it's just a matter of
#    decompressing from that corpus." BUILD_LOG 1621c.
# ============================================================================
"""Higher tags opened into their parts until none that should be opened is left."""
from __future__ import annotations

import numpy as np


def expand(symbols, which: np.ndarray, offsets: np.ndarray, flat: np.ndarray, row: np.ndarray) -> np.ndarray:
    """Intention: the symbols with every tag marked in `which` replaced by its parts, over and over, until none is
    left; tag t's parts are flat[offsets[row[t]]:offsets[row[t] + 1]]. A gap (negative) stays as it is."""
    symbols = np.asarray(symbols, dtype=np.int64)
    while symbols.size:
        safe = np.where(symbols >= 0, symbols, 0)
        opened = (symbols >= 0) & which[safe]
        if not opened.any():
            break
        rows = np.where(opened, row[safe], 0)
        width = np.where(opened, offsets[rows + 1] - offsets[rows], 1)
        source = np.repeat(np.arange(symbols.size), width)
        within = np.arange(source.size) - np.repeat(np.cumsum(width) - width, width)
        from_parts = opened[source]
        out = symbols[source]
        out[from_parts] = flat[offsets[rows[source[from_parts]]] + within[from_parts]]
        symbols = out
    return symbols
