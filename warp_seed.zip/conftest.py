# WARP2/conftest.py
#
# ============================================================================
#  Pathway   : WARP2/conftest.py
#  Used by   : pytest, for every test in the tree. Imported before any of them.
#  Uses      : stdlib only (atexit, os, shutil, socket, tempfile) plus pytest for the
#              per-test fixture; warp2.record.locks and warp2.ui.runner only
#              inside the fixtures, so importing this file still drags nothing in.
#  Description:
#    Points the VOLATILE runtime — the STOP flag, the process register, the
#    lock directory, and anything else resolved through
#    warp2.record.stop.runtime_dir — at a throwaway directory, so running the
#    suite can never reach the live system, AND so no test inherits the
#    volatile state another test left behind.
#  User intention (Andrew, 2026-08-17): "I never ran or hit a all stop."
#    He had not. WARP's own suite raised the REAL stop three times, because a
#    test built an observer with a temporary root and the runtime home was
#    deliberately derived from %LOCALAPPDATA% rather than from the tree — so it
#    resolved to the real one, the test passed, and the live system was left
#    refusing to boot. Fixed HERE, at the environment, and not in any one test:
#    patching the test that did it would leave the next one free to do it again.
#    Set at IMPORT time, before any test module is imported, because the value
#    is read when a module first resolves the runtime directory.
#
#    2026-09-10, THE SAME LESSON ONE LEVEL DOWN. One throwaway directory for the
#    whole session is not isolation, it is a shared one somewhere safer. A test
#    that raises ALL_STOP leaves STOP.json in it and every test that runs after
#    reads a halted machine — measured on the full tree: six failures in
#    test_the_skill_bible.py all saying "ALL_STOP was raised while it ran",
#    and three in test_loop.py that pass when that file runs on its own. So the
#    directory is now PER TEST, for the same reason it was moved out of the
#    live system in the first place: state that outlives what wrote it will
#    eventually be read by something that did not.
#
#    2026-09-18, Andrew: "build things into the right system to keep those
#    from happening again." The session now also fails if a test left
#    anything new in WARP2/ or warp2/ (see the end of this file).
#
#    2026-10-09 (fix 7.5): every test also runs offline — anything but this
#    machine is refused at once (`_offline`).
#    2026-10-25 (BUILD_LOG 596): every test also gets its own raw-capture
#    folder, so no test cascade is filed in the live capture archive.
#    2026-10-25 (BUILD_LOG 645): every test runs with the live memory floor
#    off (`_no_live_memory_floor`), so free RAM cannot fail the start-up tests.
#    2026-11-08: and with the room kept for the rest of the machine measured
#    on a quiet stand-in machine (warp2/work/background_room.py).
# ============================================================================
import atexit
import os
import shutil
import tempfile

import pytest

_SANDBOX = tempfile.mkdtemp(prefix="warp2-test-runtime-")
os.environ["WARP2_RUNTIME_DIR"] = _SANDBOX


@atexit.register
def _remove_sandbox() -> None:
    # Intention: leave nothing behind. A test runtime that survives the session
    # is a stop flag waiting to confuse somebody next week.
    shutil.rmtree(_SANDBOX, ignore_errors=True)


@pytest.fixture(autouse=True)
def _own_volatile_runtime(tmp_path_factory, monkeypatch):
    """Give every test its own volatile runtime, and leave no handles open.

    Intention: `runtime_dir()` reads the environment on every call and caches
    nothing, so pointing it somewhere new is all it takes — which is exactly
    what that one resolver was built for. The lock handles are a second kind of
    leak and need the same treatment: they are cached in a module-level
    dictionary shared by the whole process, so a handle one test left open is a
    handle the next test's tidy closes underneath it. That is what "seek of
    closed file" was, eight times over, in the full-tree run.
    """
    monkeypatch.setenv("WARP2_RUNTIME_DIR", str(tmp_path_factory.mktemp("runtime")))
    # Intention (2026-10-25, BUILD_LOG 596): the Eye's in-flight capture writes
    # under the TREE's state/archive/raw_capture whatever state a test gave
    # it, so test cascades (child marks 6, 7, 14, and pytest pids) were filed
    # as live generations beside the warp's own. Each test gets its own.
    monkeypatch.setenv("WARP2_RAW_CAPTURE_DIR", str(tmp_path_factory.mktemp("raw_capture")))
    yield



class _QuietMachine:
    """A machine with nothing outside the WARP and nothing in use - what a test sees.

    Intention (2026-11-08, BUILD_LOG 1456): so the code is tested, not what the machine runs that moment. Kept here,
    beside the one fixture that uses it, not in warp2/work/background_room.py, where nothing in production called it.
    """

    @staticmethod
    def largest() -> tuple:
        """Intention: nothing runs outside the WARP on a quiet machine."""
        return 0, ""

    @staticmethod
    def free() -> tuple:
        """Intention: all of the real machine's size free, so nothing in use moves a test."""
        from warp2.work.background_room import OutsideLook
        total = OutsideLook.free()[1]
        return total, total

@pytest.fixture(autouse=True)
def _no_live_memory_floor(monkeypatch):
    """Every test runs with the machine's memory floor off, unless it sets one itself.

    Intention (2026-10-25, BUILD_LOG 645): the start-up tests check the CODE,
    not how much RAM the machine has free at that moment. With full-size
    picture lessons (BUILD_LOG 640) five painter tests read the live machine's
    free RAM (about 1.4 GB, the window holding 3 GB) and stopped with
    LowMemory under the 1536 MB floor, so the start-up tests failed and the
    warp stayed down from 20:47 UTC. The floor still guards every live run;
    the floor's own tests set MIN_FREE_MB themselves (test_memory_floor.py,
    test_the_floor_watches_commit.py) and are unchanged. memory_gate is
    imported inside the fixture, so importing this file still drags nothing in.
    """
    import sys
    gate = sys.modules.get("warp2.work.memory_gate")
    if gate is None:
        from warp2.work import memory_gate as gate
    monkeypatch.setattr(gate, "MIN_FREE_MB", 0)
    # Intention (2026-11-08, warp2/work/background_room.py): the room kept for the rest of the machine is measured
    # from the live machine; a test sees a quiet machine instead - nothing outside, nothing used - so neither the
    # floor nor the Eye's pairs move with what the machine runs that moment. Tests of the room set their own.
    from warp2.work import background_room as room
    monkeypatch.setattr(room, "_ROOM", {"": room.BackgroundRoom(None, _QuietMachine())})
    yield
    from warp2.record.locks import close_handles
    close_handles()


@pytest.fixture(autouse=True)
def _no_real_runner(monkeypatch):
    """No test may start a real warp in the background.

    Intention: found 2026-09-24. The cockpit test presses "resume", which calls
    warp2.ui.runner.start — and that launched a REAL continuous warp on the
    test's temp folder, detached, restarting itself after every crash. Two of
    them (one per full test run) were still running hours later, holding the
    graphics card, so every model was squeezed off it and timed out. A test
    may ask for a runner; it gets told one was requested, and nothing starts.
    """
    try:
        from warp2.ui import runner
    except Exception:
        yield
        return
    monkeypatch.setattr(runner, "start",
                        lambda root, state: {"status": "runner requested (test: not started)", "pid": 0})
    yield


# Intention: NOTHING A TEST DOES MAY BE LEFT IN THE TREE. Found 2026-09-18:
# `MagicMock/`, `dummy_state/`, `test_tmp_state/`, `test_tmp_state2/` and
# `test_tmp_tree/` sat in WARP2/ for eight days, left by tests that wrote
# relative to the folder they ran in. This looks at WARP2/ itself and at the
# warp2/ package before and after the whole session, and fails the session
# when something new appeared, naming it. `state/` is not watched here: the
# running machine writes there. What keeps tests out of it is the discipline
# rule that no part keeps its state in the current folder.
_TREE = os.path.dirname(os.path.abspath(__file__))
_SKIP = {"__pycache__", ".pytest_cache", ".ruff_cache", ".git"}


# Intention (2026-10-09, fix 4.2): the Eye keeps two process-wide singletons —
# the reactive policy (refinement passes, last picture health, which also
# steers the painter's size schedule) and the ability balancer. A test that
# adapted them changed the painter and the size schedule for every test after
# it in the same worker: four eye tests failed in a full run and passed alone.
# Each test starts with them unmade; only modules already imported are touched,
# so this file still drags nothing in.
_SINGLETONS = (("eye.reactive_policy", "ReactivePolicy"), ("eye.taxonomy", "AbilityBalancer"))


@pytest.fixture(autouse=True)
def _fresh_process_singletons():
    import sys
    for module_name, module in list(sys.modules.items()):
        for ending, cls_name in _SINGLETONS:
            if module_name.endswith(ending) and hasattr(getattr(module, cls_name, None), "_instance"):
                getattr(module, cls_name)._instance = None
    yield


# Intention (2026-10-09, fix 7.5, check H4): NO TEST REACHES THE INTERNET.
# Tests that ran the loop reached the dataset refine step and read Hugging
# Face page after page — over 40 minutes for one test — and gave different
# answers online and off. Every test now runs with name lookups and
# connections to anything but this machine refused at once, with an error
# that says why; a local model server or a test's own server still works.
_LOCAL = ("localhost", "127.", "::1", "0.0.0.0")


def _is_local(host) -> bool:
    """Intention: this machine's own names and loopback addresses."""
    host = str(host or "").strip("[]").lower()
    return not host or host.startswith(_LOCAL) or host.endswith(".localhost")


def _refuse(host):
    """Intention: the one error a test that reaches out gets, naming where it tried to go."""
    return OSError(f"no test may reach the internet (tried {host}); give the test a stand-in")


@pytest.fixture(autouse=True)
def _offline(monkeypatch):
    import socket
    real_lookup, real_connect, real_connect_ex = (socket.getaddrinfo, socket.socket.connect,
                                                  socket.socket.connect_ex)

    def lookup(host, *args, **kwargs):
        if host is not None and not _is_local(host if isinstance(host, str) else host.decode()):
            raise _refuse(host)
        return real_lookup(host, *args, **kwargs)

    def _checked(sock, address):
        if sock.family in (socket.AF_INET, socket.AF_INET6) and not _is_local(address[0]):
            raise _refuse(address[0])

    def connect(sock, address):
        _checked(sock, address)
        return real_connect(sock, address)

    def connect_ex(sock, address):
        _checked(sock, address)
        return real_connect_ex(sock, address)

    monkeypatch.setattr(socket, "getaddrinfo", lookup)
    monkeypatch.setattr(socket.socket, "connect", connect)
    monkeypatch.setattr(socket.socket, "connect_ex", connect_ex)
    yield


def _tree_now() -> set:
    seen = {name for name in os.listdir(_TREE) if name not in _SKIP}
    for folder, dirs, files in os.walk(os.path.join(_TREE, "warp2")):
        dirs[:] = [d for d in dirs if d not in _SKIP]
        rel = os.path.relpath(folder, _TREE)
        seen.update(os.path.join(rel, name) for name in dirs + files)
    return seen


_TREE_BEFORE = _tree_now()


def pytest_sessionfinish(session, exitstatus):
    """Intention: fail the run, loudly, if the suite left anything in the tree."""
    left = sorted(_tree_now() - _TREE_BEFORE)
    if left:
        print("\nTHE SUITE LEFT THESE IN THE TREE (a test wrote outside its tmp_path):")
        for path in left[:40]:
            print(f"  {path}")
        session.exitstatus = 1
