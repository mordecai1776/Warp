# WARP2/run_tests.py
#
# ============================================================================
#  Pathway   : WARP2/run_tests.py
#  Used by   : RUN_TESTS.bat — run by hand, by Andrew.
#  Uses      : pytest (run as a child process, which loads this file as a
#              plugin to say which test is running); warp2/record/card_turn.py
#              (the start gate has the graphics card alone, BUILD_LOG 1471);
#              stdlib otherwise.
#  Description:
#    Runs every WARP2 test — warp2/ and then each project folder that has
#    tests, each as its own pytest one after another (fix 7.4) — and shows it
#    in the window as it happens (the start-up tests first wait for the
#    warp's running steps to leave the graphics card, then hold it alone,
#    and say so; BUILD_LOG 1471): each
#    test's name, PASSED or FAILED in colour, a running count, and a notice
#    when one test has been going a long time. The same lines, without the
#    colour, go to state/diagnostics/tests.out.txt so they can be read after.
#  User intention (Andrew):
#    2026-09-24: "who builds tests with no visual cues — how do you expect
#    anyone to see when anything goes wrong." A test run must show what it is
#    doing, what failed, and where it is stuck, in the window, while it runs.
#    2026-11-09 22:41: "make the time constraints more adaptive and have it do
#    checks for freezes. We should allow for long times" - a quiet test is cut
#    off when it is frozen (no words and no work), never for being slow
#    (warp2/record/working.py; BUILD_LOG 1489).
#    2026-11-09 22:53: "All work on the warp should use a set amount of
#    compute and be built to do so" - and a quiet test has a set amount of
#    compute, its limit on every processor (BUILD_LOG 1490).
# ============================================================================
from __future__ import annotations

import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

# Intention: where the plain copy of everything the window shows is kept.
OUT = Path("state") / "diagnostics" / "tests.out.txt"

# Intention: how long one test may go quiet before the window says so. Only a
# notice — nothing is stopped; pytest's own faulthandler dumps the stack.
QUIET_SECONDS = float(os.environ.get("WARP2_TEST_QUIET_SECONDS", "60"))

# Intention (BUILD_LOG 661): in the start-up tests only, how long one test may
# go quiet before it is cut off and counted as failed. A hung start-up test
# used to hold the warp's start for ever; now the gate ends, says which test
# hung, and the watcher can try again. The whole run is not cut, only a test
# that has said nothing for this long.
# Intention (Andrew, 2026-11-09 22:41; BUILD_LOG 1489): AND DONE NOTHING. Measured that night: one Eye test worked
# for 4.6 minutes alone and past ten beside a full machine, and was cut off twice while using six processors. The
# limit now bounds how long a test may be FROZEN - no words and no work - and a test that is working is left to it.
TEST_LIMIT_SECONDS = float(os.environ.get("WARP2_PREFLIGHT_TEST_LIMIT_SECONDS", "600"))

# Intention: the test running right now, written by pytest itself through the
# hook below, so the window can name a test that never finishes.
NOW = Path("state") / "diagnostics" / "test_now.txt"

# Intention: pytest's colour codes are for the window, not for the file.
ANSI = re.compile(r"\x1b\[[0-9;]*m")

RED, GREEN, YELLOW, CYAN, RESET = "\x1b[31;1m", "\x1b[32m", "\x1b[33;1m", "\x1b[36m", "\x1b[0m"

# A stack dump can interrupt pytest between the test name and its result.
SPLIT_RESULT = re.compile(r"(?:PASSED|FAILED|ERROR|SKIPPED|XFAIL)(?: \(.*\))?\s+\[\s*\d+%\]")

PREFLIGHT_TESTS = (
    # Intention (Andrew, 2026-10-25; BUILD_LOG 601): his design, in his exact
    # words (design/ANDREW_DESIGN.md), checked first — the warp does not start
    # on code that has drifted from it.
    "design/tests/test_andrews_design.py",
    # Intention (Andrew, 2026-11-07 04:01): no worker adds a fault of the kinds the sweep found
    # (design/RULES_FOR_EVERY_WORKER.md); the warp does not start on code that did.
    "design/tests/test_no_new_faults.py",
    "warp2/app/tests/test_waiting_is_not_progress.py",
    "warp2/control/tests/test_restart.py",
    "warp2/ask/tests/test_picture_judge.py",
    "warp2/chat_learning/tests/test_chat_learning.py::test_scenario_split_is_permanent_across_restart_and_corrupt_state_is_quarantined",
    "warp2/chat_learning/tests/test_chat_learning.py::test_the_eye_learns_to_speak_answers_beside_the_models_and_speaks_when_it_conveys_best",
    "projects/behemoth_eye/eye/tests/test_painter_training.py",
    "projects/behemoth_eye/eye/tests/test_tensegrity_and_warp_eye.py::test_warp_eye_route_traces_and_enforces_the_governed_action_boundary",
    "projects/behemoth_eye/eye/tests/test_tensegrity_and_warp_eye.py::test_a_picture_asked_for_at_a_size_is_drawn_and_measured_at_it",
)


# Intention: folders whose tests are not run: old code kept in an archive.
SKIPPED_PARTS = ("archive", "__pycache__")


def roots(root) -> list:
    """Every folder whose tests run: warp2 first, then each project folder holding a test, in name order.

    Intention (2026-10-09, fix 7.4, check H3): THE PROJECT TESTS RUN TOO.
    Only warp2/ ran; about 130 test files under projects/ never did,
    including the tests of fixes the warp depends on every day. A project
    folder counts when it holds a test_*.py outside an archive.
    """
    root = Path(root)
    found = ["warp2"] if (root / "warp2").is_dir() else []
    projects = root / "projects"
    for folder in sorted(p for p in projects.iterdir() if p.is_dir()) if projects.is_dir() else []:
        tests = (t for t in folder.rglob("test_*.py")
                 if not any(part in SKIPPED_PARTS or part.startswith("_retired")
                            for part in t.relative_to(folder).parts))
        if next(tests, None) is not None:
            found.append(folder.relative_to(root).as_posix())
    return found


def src_paths(root) -> list:
    """Every project's src/ folder, relative to the root, in name order.

    Intention (2026-10-15, fix 7.4): a project that keeps its package in src/
    (uhe, miniapex, adaptive layers, holographic input) is importable in the
    run, and so is a sibling it uses — what each project's own launcher does
    (projects/uhe/run.py puts its src/ and the adaptive layers' src/ first).
    """
    projects = Path(root) / "projects"
    if not projects.is_dir():
        return []
    return [p.relative_to(root).as_posix() for p in sorted(projects.glob("*/src")) if p.is_dir()]


def command_for(*targets, paths=()) -> list:
    """One pytest child for these targets, shown line by line, with this file loaded to name the running test.

    Intention: `paths` are added after the root (pyproject's pythonpath "."),
    so a project's own packages import as its launcher makes them.
    """
    extra = ["-o", "pythonpath=" + " ".join([".", *paths])] if paths else []
    return [sys.executable, "-u", "-B", "-m", "pytest", "-v", "--color=yes",
            "-p", "no:cacheprovider", "-p", "run_tests", "-o", "faulthandler_timeout=600", *extra, *targets]


def pytest_runtest_logstart(nodeid, location):
    """Intention: pytest calls this as each test starts (loaded with -p run_tests)."""
    try:
        NOW.write_text(nodeid, encoding="utf-8")
    except OSError:
        pass


class Counts:
    """How many passed, failed and were skipped so far.

    Intention: the window's running score, read from pytest's own words.
    """

    def __init__(self) -> None:
        self.passed = 0
        self.failed = 0
        self.skipped = 0
        self.failures: list[str] = []

    def read(self, plain: str) -> None:
        """Intention: count one -v result line; remember the name of a failure."""
        if " PASSED" in plain:
            self.passed += 1
        elif " FAILED" in plain or " ERROR" in plain:
            self.failed += 1
            self.failures.append(plain.split(" ")[0])
        elif " SKIPPED" in plain or " XFAIL" in plain:
            self.skipped += 1

    def line(self, started: float) -> str:
        """Intention: the score as one short line, with the time gone."""
        minutes = (time.monotonic() - started) / 60.0
        bad = f"{RED}{self.failed} failed{RESET}" if self.failed else f"{GREEN}0 failed{RESET}"
        return f"{CYAN}[{minutes:5.1f} min]{RESET} {GREEN}{self.passed} passed{RESET}, {bad}, {self.skipped} skipped"


# Intention (BUILD_LOG 1380): how pytest's faulthandler stack dump begins its
# lines. A dump is printed because a test is taking long, so it is not a sign
# the test is alive; counting it as one restarted the quiet clock and the
# start-up cut-off (BUILD_LOG 661) never came.
DUMP_HEADS = ("Timeout (", "Thread 0x", "Current thread 0x", '  File "', "Stack (most recent call first):")


def dump_line(text: str) -> bool:
    """True when this line (or piece of a line) is part of a stack dump, or blank.

    Intention (BUILD_LOG 1380): only real output keeps a start-up test alive.
    A piece of a line that could still grow into a dump line counts as dump.
    """
    line = text.rstrip("\r\n")
    if not line.strip():
        return True
    return any(line.startswith(head) or head.startswith(line) for head in DUMP_HEADS)


class Watch:
    """Says in the window when one test has been running a long time.

    Intention: a stuck test is the thing a silent run hides. This names it.
    """

    def __init__(self, show, limit: float = 0.0) -> None:
        self.show = show
        self.last = time.monotonic()
        self.done = threading.Event()
        # Intention (BUILD_LOG 661): the start-up tests' quiet limit (0 = none),
        # the pytest child it may end, and the test it ended, if any.
        self.limit = limit
        self.child = None
        self.cut = ""
        # Intention (BUILD_LOG 1489): the work the running pytest was last seen doing, and what reads it.
        self.worked = time.monotonic()
        self.working = None
        self.work_said = ""
        # Intention (BUILD_LOG 1490): the processor seconds used since the last words.
        self.compute = 0.0

    def heard(self, plain: str) -> None:
        """Intention: every line is a sign of life — except a stack dump (BUILD_LOG 1380)."""
        if not dump_line(plain):
            self.last = time.monotonic()
            self.compute = 0.0

    def running(self) -> str:
        """Intention: the test pytest last said it started."""
        try:
            return NOW.read_text(encoding="utf-8").strip()
        except OSError:
            return ""

    def look_for_work(self) -> None:
        """Intention (BUILD_LOG 1489): once a quiet minute, read whether the running pytest and all it started did
        work since the last such look; work seen moves the frozen clock, and what was read is kept to be told."""
        child = self.child
        if child is None:
            return
        if self.working is None or self.working.pid != child.pid:
            from warp2.record.working import Working
            self.working = Working(child.pid)
            self.work_said = ""
            return
        moved = self.working.moved()
        self.compute += self.working.used
        if moved:
            self.worked = time.monotonic()
            self.work_said = f"working: {self.working.used:.0f} s of processor since the last look"
        else:
            self.work_said = f"no work seen for {(time.monotonic() - self.worked) / 60.0:.1f} min"

    def frozen_for(self) -> float:
        """Intention: how long there have been neither words nor work."""
        now = time.monotonic()
        return now - max(self.last, self.worked)

    def run(self) -> None:
        """Intention: look every few seconds; speak once per quiet minute; cut off only what is frozen."""
        told = 0
        while not self.done.wait(5.0):
            quiet = time.monotonic() - self.last
            times = int(quiet // QUIET_SECONDS)
            if times > told:
                told = times
                self.look_for_work()
                self.show(f"{YELLOW}... still running after {quiet / 60.0:.1f} min"
                          f"{' (' + self.work_said + ')' if self.work_said else ''}: "
                          f"{self.running() or 'starting up'}{RESET}")
            elif times == 0:
                told = 0
            frozen = self.frozen_for()
            if self.limit and frozen > self.limit and self.child is not None and not self.cut:
                self.cut_off(frozen)
            if self.limit and self.spent_it() and self.child is not None and not self.cut:
                self.cut_off_spent()

    def spent_it(self) -> bool:
        """Intention (Andrew, 2026-11-09 22:53: "All work on the warp should use a set amount of compute";
        BUILD_LOG 1490): a quiet test has used its set amount - its limit on every processor of this machine. A
        test stuck in a loop never looks frozen; it runs out of this."""
        from warp2.record.working import compute_for
        return self.compute >= compute_for(self.limit)

    def cut_off_spent(self) -> None:
        """Intention (BUILD_LOG 1490): end a start-up test that used its set amount of compute, and name it."""
        from warp2.record.working import compute_for
        self.cut = self.running() or "starting up"
        self.show(f"{RED}CUT OFF, used its set amount of compute ({self.compute:.0f} of "
                  f"{compute_for(self.limit):.0f} processor seconds with no words): {self.cut}{RESET}")
        try:
            self.child.kill()
        except OSError:
            pass


    def cut_off(self, quiet: float) -> None:
        """Intention (BUILD_LOG 661): end a start-up test that has hung past its limit, and name it."""
        self.cut = self.running() or "starting up"
        self.show(f"{RED}CUT OFF, frozen {quiet / 60.0:.1f} min (no words, no work): {self.cut}{RESET}")
        try:
            self.child.kill()
        except OSError:
            pass


def lines_of(pipe, watch):
    """Every whole line pytest writes, as it writes it.

    Intention: read in pieces as they come, so any output at all counts as
    a sign of life, even part of a line.
    """
    import codecs
    # Intention: a letter split across two reads is still one letter.
    decode = codecs.getincrementaldecoder("utf-8")("replace").decode
    rest = ""
    while True:
        piece = os.read(pipe.fileno(), 4096)
        if not piece:
            break
        rest += decode(piece).replace("\r\n", "\n")
        *whole, rest = rest.split("\n")
        for line in whole:
            yield line
        watch.heard(rest)
    if rest:
        yield rest


def colour(line: str) -> str:
    """Intention: PASSED green, FAILED red, so a failure stands out at a glance."""
    if " FAILED" in line or " ERROR" in line or line.startswith("FAILED") or line.startswith("E "):
        return RED + ANSI.sub("", line) + RESET
    return line


def verdict(counts: Counts, code: int) -> str:
    """The last word of a run: passed only when every pytest ended well.

    Intention (BUILD_LOG 607): a pytest that crashed (Windows exit
    3221225477), was cut off, or ran no test at all has no FAILED line, so
    the old run said ALL TESTS PASSED over it. A run passes only when no
    test failed, at least one ran, and every pytest ended with code 0;
    otherwise it says INCOMPLETE and the exit code, so nobody reads a crash
    as a pass.
    """
    if counts.failures:
        return f"{counts.failed} FAILED"
    ran = counts.passed + counts.failed + counts.skipped
    if code != 0:
        return f"TESTS INCOMPLETE: pytest ended with code {code} after {ran} tests"
    if ran == 0:
        return "TESTS INCOMPLETE: no test ran"
    return "ALL TESTS PASSED"


def main(preflight: bool = False) -> int:
    """Run pytest, show every line in colour, keep a plain copy, print the score."""
    os.system("")  # Intention: turns on colour in the Windows console.
    OUT.parent.mkdir(parents=True, exist_ok=True)
    counts = Counts()
    lock = threading.Lock()
    held = None
    env = dict(os.environ)
    with open(OUT, "w", encoding="utf-8") as saved:

        def show(line: str) -> None:
            with lock:
                print(line, flush=True)
                saved.write(ANSI.sub("", line) + "\n")
                saved.flush()

        # Intention (BUILD_LOG 1471): THE START GATE JUDGES THE CODE, NOT THE MACHINE. A deploy's gate failed 7
        # tests on "CUDA error: out of memory" while a warp step held the card. The gate now asks for the card,
        # waits for the steps already on it to end (no new one starts meanwhile), holds it alone for the whole
        # test run, and says who it waited for. Its own pytest is inside that turn, so nothing in it asks again.
        if preflight:
            from warp2.record.card_turn import INSIDE_ENV, CardTurn
            held, card_wait, waited_for = CardTurn(OUT.parent.parent).gate("run_tests --preflight", say=show)
            if waited_for:
                show(f"{CYAN}card turn: waited {card_wait:.0f} s for {', '.join(waited_for)}{RESET}")
            env[INSIDE_ENV] = "1"
        started = time.monotonic()
        watch = Watch(show, TEST_LIMIT_SECONDS if preflight else 0.0)
        threading.Thread(target=watch.run, daemon=True).start()
        # Intention (fix 7.4): the preflight is one run; the whole check is one
        # run per root (`roots`), each named in the window as it starts.
        runs = [list(PREFLIGHT_TESTS)] if preflight else [[r] for r in roots(Path.cwd())]
        code = 0
        for targets in runs:
            if not preflight:
                show(f"{CYAN}=== {targets[0]} ==={RESET}")
            paths = src_paths(Path.cwd()) if targets[0].startswith("projects/") else ()
            child = subprocess.Popen(command_for(*targets, paths=paths),
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
            watch.child = child
            for line in lines_of(child.stdout, watch):
                plain = ANSI.sub("", line)
                watch.heard(plain)
                if SPLIT_RESULT.fullmatch(plain):
                    plain = f"{watch.running() or '<unknown>'} {plain}"
                counts.read(plain)
                show(colour(line))
                # Intention: the score after every failure and every 50 tests —
                # often enough to see how it is going, not so often it buries names.
                ran = counts.passed + counts.failed + counts.skipped
                if "::" in plain and (" FAILED" in plain or (ran and ran % 50 == 0)):
                    show(counts.line(started))
            code = max(code, child.wait())
        watch.done.set()
        if held is not None:
            held.take_away()
        if watch.cut:
            # Intention (BUILD_LOG 661): a test cut off for hanging is a failure, by name.
            counts.failed += 1
            counts.failures.append(f"{watch.cut} (cut off: frozen past {TEST_LIMIT_SECONDS:.0f} s, or its set amount of compute used)")
        NOW.unlink(missing_ok=True)  # Intention: leave nothing behind.
        show("")
        show("=" * 60)
        show(counts.line(started))
        if counts.failures:
            show(f"{RED}FAILED TESTS:{RESET}")
            for name in counts.failures:
                show(f"{RED}  {name}{RESET}")
        verdict_line = verdict(counts, code)
        show(f"{GREEN}{verdict_line}{RESET}" if verdict_line == "ALL TESTS PASSED" else f"{RED}{verdict_line}{RESET}")
        show(f"Saved to {OUT}")
    # Intention (BUILD_LOG 661): the exit code agrees with the verdict. A child
    # killed on POSIX ends with a negative code, which max() hid as 0.
    return 0 if verdict_line == "ALL TESTS PASSED" else (code if code > 0 else 1)


if __name__ == "__main__":
    sys.exit(main("--preflight" in sys.argv[1:]))
