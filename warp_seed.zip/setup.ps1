$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
py -3.11 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)"
py -3.11 -m pip install -r requirements-gui.txt
py -3.11 -c "import PySide6, qfluentwidgets, pyqtgraph; print('WARP2 GUI dependencies are ready.')"
