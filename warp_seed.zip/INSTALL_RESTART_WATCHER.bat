@echo off
REM ============================================================================
REM  Pathway   : WARP2/INSTALL_RESTART_WATCHER.bat
REM  Used by   : Andrew, once.
REM  Uses      : INSTALL_RESTART_WATCHER.ps1 (registers and starts the task).
REM  Description:
REM    Installs a per-user scheduled task so the restart watcher starts at every
REM    logon and is retried after failures, then starts it now.
REM  User intention (Andrew, 2026-10-02): Claude must be able to restart the
REM    warp on its own while he is away from home.
REM ============================================================================
setlocal
cd /d "%~dp0"
PowerShell -NoProfile -ExecutionPolicy Bypass -File "%CD%\INSTALL_RESTART_WATCHER.ps1"
if errorlevel 1 (
    echo [WARP2] Watcher task installation failed. See the message above.
    pause
    exit /b 1
)
echo [WARP2] Done. You can close this window.
pause
endlocal
