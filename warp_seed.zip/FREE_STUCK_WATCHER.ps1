# ============================================================================
#  Pathway   : WARP2/FREE_STUCK_WATCHER.ps1
#  Used by   : FREE_STUCK_WATCHER.bat.
#  Uses      : state/control/watcher.beat; Win32_Process; the scheduled task
#              'WARP2 Restart Watcher' (INSTALL_RESTART_WATCHER.ps1); the
#              Task Scheduler and System event logs (why it may have gone),
#              including low-memory rows, each process's chain of parents, and
#              the task's overlap rule and triggers.
#  Description:
#    If the watcher's heartbeat is stale, end that one watcher process (found
#    by the pid in the beat, and only if its command line is the watcher, not
#    the service and not the warp). Its service then starts a new watcher. If
#    no service is running at all, start the scheduled task.
#  User intention (Andrew, 2026-10-16): the warp must never stay down; a stuck
#    watcher (seen 2026-10-17 and 2026-10-18) blocks every restart.
# ============================================================================
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$beat = Join-Path $root 'state\control\watcher.beat'
$taskName = 'WARP2 Restart Watcher'

# Intention: read the beat as (pid, age in seconds); a missing or broken beat reads as very old.
function Read-Beat {
    if (-not (Test-Path -LiteralPath $beat)) { return @{ Pid = 0; Age = 1e9 } }
    $parts = (Get-Content -LiteralPath $beat -Raw).Trim() -split '\s+'
    if ($parts.Count -lt 2) { return @{ Pid = 0; Age = 1e9 } }
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0
    return @{ Pid = [int]$parts[0]; Age = $now - [double]$parts[1] }
}

# Intention: the python processes of one kind, matched by the module in their command line.
function Find-Module([string]$module) {
    Get-CimInstance Win32_Process -Filter "Name like 'py%'" |
        Where-Object { $_.CommandLine -and $_.CommandLine -match [regex]::Escape($module) + '(\s|$)' }
}

$now = Read-Beat
Write-Host ("Watcher beat: pid {0}, {1:N0} s old." -f $now.Pid, $now.Age)
if ($now.Age -lt 120) {
    Write-Host 'The watcher is beating. Nothing to do.'
    exit 0
}

# Intention: the chain of parents above one process (pid and name, up to 8 steps), so the diagnosis
# shows whether the runner sits under the scheduled task's tree at all (Muse, muse-60: a task stop
# can only reach processes in that tree).
function Get-Ancestry([int]$procId) {
    $chain = @()
    $seen = @{}
    for ($i = 0; $i -lt 8 -and $procId -gt 0 -and -not $seen.ContainsKey($procId); $i++) {
        $seen[$procId] = $true
        $p = Get-CimInstance Win32_Process -Filter "ProcessId = $procId" -ErrorAction SilentlyContinue
        if (-not $p) { $chain += "$procId (gone)"; break }
        $chain += "$procId $($p.Name)"
        $procId = [int]$p.ParentProcessId
    }
    return ($chain -join ' <- ')
}

# Intention: say why the service and watcher may have gone with no trace (seen 06:33 and 08:51 UTC
# 2026-10-18): the task's last result and the settings that stop it (battery, idle, time limit, logon),
# the Task Scheduler log rows for this task, and the power/logoff rows of the System log, all since $since.
function Get-DeathReason($since) {
    $rows = @('--- scheduled task')
    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if (-not $task) { return $rows + "task '$taskName' is not registered" }
    $info = Get-ScheduledTaskInfo -TaskName $taskName
    $set = $task.Settings
    $rows += "state $($task.State); last run $($info.LastRunTime); last result $($info.LastTaskResult)"
    # Intention: the overlap rule and every trigger (Muse, muse-61: "stop the existing instance" plus a
    # trigger firing would end the service and watcher together, on a schedule).
    $rows += "multiple instances $($set.MultipleInstances); restart count $($set.RestartCount) every $($set.RestartInterval)"
    foreach ($t in @($task.Triggers)) {
        $rows += "trigger $($t.CimClass.CimClassName) start $($t.StartBoundary) enabled $($t.Enabled) repeat $($t.Repetition.Interval) for $($t.Repetition.Duration) stop at end $($t.Repetition.StopAtDurationEnd)"
    }
    $rows += "logon $($task.Principal.LogonType); stop on battery $($set.StopIfGoingOnBatteries); no start on battery $($set.DisallowStartIfOnBatteries); stop on idle end $($set.IdleSettings.StopOnIdleEnd); time limit $($set.ExecutionTimeLimit)"
    foreach ($b in @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)) {
        $rows += "battery status $($b.BatteryStatus) charge $($b.EstimatedChargeRemaining)%"
    }
    $rows += '--- Task Scheduler log (empty if that log is turned off)'
    Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-TaskScheduler/Operational'; StartTime=$since} -ErrorAction SilentlyContinue |
        Where-Object { $_.Message -match [regex]::Escape($taskName) } | Select-Object -First 30 |
        ForEach-Object { $rows += "task event $($_.Id) $($_.TimeCreated): $(($_.Message -split "`n")[0])" }
    $rows += '--- power and logoff (Kernel-Power 42 sleep, 105 power source, 107 resume; 1074 shutdown; 7002 logoff)'
    Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=$since; Id=42,105,107,1074,7002} -ErrorAction SilentlyContinue |
        Select-Object -First 30 |
        ForEach-Object { $rows += "system event $($_.Id) $($_.TimeCreated): $(($_.Message -split "`n")[0])" }
    $rows += '--- low memory (Resource-Exhaustion-Detector 2004; none near the death is a vote against memory pressure)'
    Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=$since; Id=2004; ProviderName='Microsoft-Windows-Resource-Exhaustion-Detector'} -ErrorAction SilentlyContinue |
        Select-Object -First 30 |
        ForEach-Object { $rows += "low memory event $($_.Id) $($_.TimeCreated): $(($_.Message -split "`n")[0])" }
    return $rows
}

# Intention: before anything is ended, write down what the stuck watcher and its service look like,
# so the cause can be found: alive or gone, thread wait reasons (kernel file I/O shows as Executive or
# Suspended), memory, the machine's commit charge, and any recent python crash in the event log.
function Write-Diagnosis($beatNow) {
    $out = Join-Path $root ("state\diagnostics\watcher_freeze_{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $lines = @("beat pid $($beatNow.Pid), age $([int]$beatNow.Age) s, written $(Get-Date -Format o)")
    $os = Get-CimInstance Win32_OperatingSystem
    $lines += "free RAM MB $([int]($os.FreePhysicalMemory/1024)); commit free MB $([int]($os.FreeVirtualMemory/1024)) of $([int]($os.TotalVirtualMemorySize/1024))"
    foreach ($m in @('warp2.control.watcher', 'warp2.control.watcher_service', 'warp2.control.preflight')) {
        foreach ($p in @(Find-Module $m)) {
            $lines += "--- $m pid $($p.ProcessId) parent $($p.ParentProcessId) started $($p.CreationDate) private MB $([int]($p.PrivatePageCount/1MB))"
            try { $lines += "   parents: $(Get-Ancestry ([int]$p.ProcessId))" } catch { $lines += "   parents not read: $_" }
            $proc = Get-Process -Id $p.ProcessId -ErrorAction SilentlyContinue
            if ($proc) {
                foreach ($t in $proc.Threads) {
                    $why = if ($t.ThreadState -eq 'Wait') { $t.WaitReason } else { '' }
                    $lines += "   thread $($t.Id) $($t.ThreadState) $why cpu $($t.TotalProcessorTime)"
                }
            }
        }
    }
    $since = (Get-Date).AddHours(-12)
    $events = Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$since; Id=1000,1002,1026} -ErrorAction SilentlyContinue |
        Where-Object { $_.Message -match 'python' } | Select-Object -First 10
    foreach ($e in $events) { $lines += "event $($e.Id) $($e.TimeCreated): $(($e.Message -split "`n")[0..2] -join ' | ')" }
    try { $lines += Get-DeathReason $since } catch { $lines += "death reason not read: $_" }
    $lines | Set-Content -LiteralPath $out -Encoding UTF8
    Write-Host "Diagnosis written: $out"
}

try { Write-Diagnosis $now } catch { Write-Host "Diagnosis failed: $_" }

$stuck = Find-Module 'warp2.control.watcher' | Where-Object { $_.ProcessId -eq $now.Pid }
if ($stuck) {
    Write-Host "Ending the stuck watcher (pid $($now.Pid))."
    Stop-Process -Id $now.Pid -Force -ErrorAction SilentlyContinue
} else {
    Write-Host "No watcher process with pid $($now.Pid) is running."
}

$services = @(Find-Module 'warp2.control.watcher_service')
if ($services.Count -eq 0) {
    Write-Host "No watcher service is running; starting the task '$taskName'."
    Start-ScheduledTask -TaskName $taskName
}

$deadline = [DateTime]::UtcNow.AddSeconds(90)
while ([DateTime]::UtcNow -lt $deadline) {
    Start-Sleep -Seconds 3
    $after = Read-Beat
    if ($after.Age -lt 30 -and $after.Pid -ne $now.Pid) {
        Write-Host "A new watcher is beating (pid $($after.Pid)). Fixed."
        exit 0
    }
}
Write-Host 'No new watcher beat after 90 s. If the old one could not die (stuck in a OneDrive'
Write-Host 'file call), a PC restart clears it. Claude will see this on its next run.'
exit 1
